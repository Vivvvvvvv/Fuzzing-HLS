/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3606277021154435292
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_19 = 0x5DL;
static int32_t g_28 = 0x7B1A0949L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint32_t  func_6(int32_t  p_7, const int32_t  p_8, uint64_t  p_9, const int64_t  p_10);
static uint64_t  func_12(int16_t  p_13, int16_t  p_14, uint64_t  p_15, const uint16_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_19 g_28
 * writes: g_28
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_20 = 0x1A969AC54C975158LL;
    const uint32_t l_29 = 0x61943EC3L;
    uint32_t l_32 = 0x9116971DL;
    l_32 = (safe_rshift_func_uint8_t_u_s((((safe_add_func_uint32_t_u_u(func_6(((+(func_12((((((((safe_add_func_uint32_t_u_u(g_19, g_19)) >= g_19) <= l_20) < 0xD9DCEE34EDF6B3E7LL) != 5L) != g_19) < g_19), g_19, l_20, g_19) , 0x2D50L)) < l_20), l_20, l_20, l_29), g_19)) != 3UL) , 2UL), 7));
    g_28 = (safe_mul_func_uint8_t_u_u(((!(safe_lshift_func_int8_t_s_u((-3L), l_20))) == l_20), 1UL));
    g_28 |= ((((~g_19) | g_19) < 1UL) && (-8L));
    return g_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes: g_28
 */
static uint32_t  func_6(int32_t  p_7, const int32_t  p_8, uint64_t  p_9, const int64_t  p_10)
{ /* block id: 4 */
    g_28 = (safe_lshift_func_uint8_t_u_u(9UL, g_19));
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_28
 * writes: g_28
 */
static uint64_t  func_12(int16_t  p_13, int16_t  p_14, uint64_t  p_15, const uint16_t  p_16)
{ /* block id: 1 */
    int8_t l_27 = (-1L);
    g_28 = (safe_sub_func_int64_t_s_s((safe_mod_func_int16_t_s_s((((((g_19 == g_19) , l_27) | l_27) == 0L) | g_19), g_19)), g_19));
    return g_28;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 6
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 22
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 1
   depth: 4, occurrence: 2
   depth: 8, occurrence: 1
   depth: 22, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 29
XXX times a non-volatile is write: 5
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 8

XXX percentage a fresh-made variable is used: 17.1
XXX percentage an existing variable is used: 82.9
********************* end of statistics **********************/

