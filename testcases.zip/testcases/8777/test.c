/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5787800588408665322
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_21 = 0x25D2D915L;/* VOLATILE GLOBAL g_21 */
static uint16_t g_34 = 65535UL;
static const uint32_t g_35 = 4294967295UL;
static uint32_t g_36 = 1UL;
static uint32_t g_48 = 0x61E4171BL;
static int8_t g_58 = 0xD2L;
static int64_t g_65 = 0L;
static uint64_t g_69 = 0UL;
static int32_t g_74[5] = {0x48A9B2A3L,0x48A9B2A3L,0x48A9B2A3L,0x48A9B2A3L,0x48A9B2A3L};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const int32_t  func_2(int8_t  p_3, int32_t  p_4, int32_t  p_5, uint8_t  p_6);
static int8_t  func_7(uint32_t  p_8, const int64_t  p_9);
static uint64_t  func_16(uint16_t  p_17, int16_t  p_18);
static uint64_t  func_26(int64_t  p_27, int64_t  p_28, uint8_t  p_29, int64_t  p_30);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_21 g_34 g_35 g_36 g_69 g_58 g_74
 * writes: g_34 g_36 g_48 g_69 g_74
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_19 = 6L;
    int16_t l_20[3][8][4] = {{{0L,0L,0x0ED3L,0x0ED3L},{0x658EL,0x658EL,0L,0x0ED3L},{4L,0L,4L,0L},{4L,0L,0L,4L},{0x658EL,0L,0x0ED3L,0L},{0L,0L,0x0ED3L,0x0ED3L},{0x658EL,0x658EL,0L,0x0ED3L},{4L,0L,4L,0L}},{{4L,0L,0L,4L},{0x658EL,0L,0x0ED3L,0L},{0L,0x658EL,0L,0L},{0L,0L,4L,0L},{0x0ED3L,0x658EL,0x0ED3L,4L},{0x0ED3L,4L,4L,0x0ED3L},{0L,4L,0L,4L},{4L,0x658EL,0L,0L}},{{0L,0L,4L,0L},{0x0ED3L,0x658EL,0x0ED3L,4L},{0x0ED3L,4L,4L,0x0ED3L},{0L,4L,0L,4L},{4L,0x658EL,0L,0L},{0L,0L,4L,0L},{0x0ED3L,0x658EL,0x0ED3L,4L},{0x0ED3L,4L,4L,0x0ED3L}}};
    uint16_t l_86[1];
    int16_t l_107 = 0x3013L;
    uint32_t l_108[9][3] = {{0xB42EBA38L,18446744073709551615UL,0x992B028AL},{3UL,0x30338E40L,0x30338E40L},{0xB42EBA38L,18446744073709551615UL,0x992B028AL},{3UL,0x30338E40L,0x30338E40L},{0xB42EBA38L,18446744073709551615UL,0x992B028AL},{3UL,0x30338E40L,0x30338E40L},{0xB42EBA38L,18446744073709551615UL,0x992B028AL},{3UL,0x30338E40L,0x30338E40L},{0xB42EBA38L,18446744073709551615UL,0x992B028AL}};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_86[i] = 0xF5ABL;
    if (func_2(func_7((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u(func_16(l_19, l_20[2][7][2]), g_35)) || 0UL), l_20[2][7][2])), l_20[2][7][2])), l_19), l_19, g_35, l_20[2][3][3]))
    { /* block id: 41 */
        int64_t l_85 = (-4L);
        int32_t l_93 = 1L;
        l_86[0] = ((safe_rshift_func_uint8_t_u_u((((safe_mul_func_uint16_t_u_u((((((safe_div_func_uint32_t_u_u((((safe_rshift_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u(0x06A5L, l_20[2][4][0])) <= l_20[1][2][2]), l_20[2][2][1])) <= l_20[2][7][2]) >= 0x67550B10L), l_85)) ^ 0x0A97L) != 0x18L) && 247UL) == 0UL), 0xE9B6L)) , l_19) , g_69), g_35)) == g_36);
        l_19 |= ((4294967292UL < l_20[0][3][2]) == 0xFB035B4089D3BBD1LL);
        l_93 |= (safe_div_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((((safe_add_func_uint32_t_u_u((0xC5L == g_69), l_85)) != l_85) || g_36), l_85)), g_58));
        for (l_19 = 21; (l_19 >= 5); l_19 = safe_sub_func_uint32_t_u_u(l_19, 6))
        { /* block id: 47 */
            int16_t l_98 = (-8L);
            uint32_t l_99 = 0xCAE9FC7DL;
            l_99 = (((safe_mul_func_uint16_t_u_u((l_98 == g_34), g_36)) == l_98) ^ g_74[0]);
            g_74[4] = (0UL >= 0x6755D88DL);
        }
    }
    else
    { /* block id: 51 */
        g_74[4] &= (safe_rshift_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u((+(safe_mul_func_uint8_t_u_u(g_58, 2UL))), l_107)) > 0x43L), l_108[7][0]));
    }
    if (((!((((safe_rshift_func_uint16_t_u_u((((safe_rshift_func_uint8_t_u_u(((((safe_div_func_uint8_t_u_u((l_107 , 0UL), 0x05L)) > l_86[0]) , l_19) != g_74[4]), 7)) ^ l_108[4][1]) && 0x29L), l_108[8][2])) , g_36) < 0x75L) <= g_21)) < 18446744073709551607UL))
    { /* block id: 54 */
        uint8_t l_116 = 246UL;
        l_116--;
        g_74[3] = ((4294967288UL > 0x2EF88E35L) != g_36);
    }
    else
    { /* block id: 57 */
        int16_t l_124 = (-1L);
        int32_t l_125 = 0xB4B7F8BEL;
        if (g_36)
        { /* block id: 58 */
            uint16_t l_119 = 0xDDE4L;
            g_74[4] = 0xB9C827B2L;
            l_119++;
        }
        else
        { /* block id: 61 */
            uint64_t l_130 = 0x6D21B0195B865CE0LL;
            uint32_t l_135 = 0UL;
            g_74[4] = (safe_rshift_func_uint8_t_u_u((0UL == 4294967292UL), 7));
            l_125 = (g_74[3] != l_124);
            l_19 = ((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u(0xE5F0L, l_130)), 0xF297919FL)) < 255UL);
            l_135 |= (safe_div_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(1UL, 2)) , l_124), 0x97L));
        }
    }
    return g_69;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_69 g_34 g_58
 * writes: g_69 g_74
 */
static const int32_t  func_2(int8_t  p_3, int32_t  p_4, int32_t  p_5, uint8_t  p_6)
{ /* block id: 37 */
    g_69 &= g_21;
    g_74[4] = (safe_mod_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u((((g_34 > g_34) , p_6) || p_4), 5)), p_5));
    return g_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_35 g_36
 * writes: g_36 g_48
 */
static int8_t  func_7(uint32_t  p_8, const int64_t  p_9)
{ /* block id: 12 */
    uint8_t l_43 = 0x72L;
    int32_t l_49 = (-6L);
    int32_t l_59 = (-6L);
    int32_t l_60 = (-2L);
    int32_t l_61 = 0L;
    int32_t l_62 = 0L;
    int32_t l_63 = (-1L);
    int32_t l_64 = 1L;
    uint32_t l_66 = 0x640197F5L;
    g_36 = g_34;
    if ((p_8 == g_34))
    { /* block id: 14 */
        uint8_t l_38 = 0x4DL;
        int32_t l_45[9] = {1L,(-1L),(-1L),1L,(-1L),(-1L),1L,(-1L),(-1L)};
        int i;
        if ((p_8 > p_8))
        { /* block id: 15 */
            int32_t l_37 = 0xF914A126L;
            l_37 = ((p_8 || p_8) < p_8);
        }
        else
        { /* block id: 17 */
            uint8_t l_44 = 0x71L;
            l_38 = p_8;
            l_44 = ((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((g_34 > p_8), l_43)), 11)) == g_35);
        }
        l_45[1] = ((0x3C34F97039802EEDLL >= p_9) > l_38);
        for (p_8 = 0; (p_8 <= 46); p_8++)
        { /* block id: 24 */
            g_48 = g_36;
            l_49 = (l_43 < l_45[1]);
            return l_38;
        }
    }
    else
    { /* block id: 29 */
        uint32_t l_50[3][9] = {{0xC58AC374L,0xC58AC374L,8UL,0x12106DF3L,0x999369E1L,4294967295UL,0x84A86307L,4294967295UL,0x999369E1L},{8UL,0xC58AC374L,0xC58AC374L,8UL,0x12106DF3L,0x999369E1L,4294967295UL,0x84A86307L,4294967295UL},{0x84A86307L,0xB5DCFD1FL,8UL,8UL,0xB5DCFD1FL,0x84A86307L,0x1863D476L,0xC58AC374L,0x293E35F2L}};
        int32_t l_51 = 0xD7CCF76EL;
        int i, j;
        l_51 |= (0x674DCCE65120B879LL >= l_50[1][6]);
        l_49 &= (((l_50[0][7] != g_34) < p_9) <= l_50[1][0]);
        l_51 = (safe_add_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(l_43, g_35)), 3)), p_9));
        l_51 = (0UL > 65535UL);
    }
    --l_66;
    return l_60;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_34
 * writes: g_34
 */
static uint64_t  func_16(uint16_t  p_17, int16_t  p_18)
{ /* block id: 1 */
    uint16_t l_25 = 65533UL;
    int8_t l_31 = 0x07L;
    if (g_21)
    { /* block id: 2 */
        uint32_t l_24[10] = {18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL};
        int i;
        l_24[0] = ((safe_div_func_uint64_t_u_u(p_17, g_21)) < 1UL);
    }
    else
    { /* block id: 4 */
        l_25 &= 6L;
        g_34 = (func_26(p_18, l_31, l_25, g_21) && p_17);
    }
    return g_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_21
 * writes:
 */
static uint64_t  func_26(int64_t  p_27, int64_t  p_28, uint8_t  p_29, int64_t  p_30)
{ /* block id: 6 */
    int32_t l_32[3][10][1] = {{{(-2L)},{0x778E10A3L},{2L},{2L},{0x98422518L},{2L},{(-1L)},{2L},{0x98422518L},{2L}},{{2L},{0x778E10A3L},{(-2L)},{0x98422518L},{0x98422518L},{(-2L)},{0x778E10A3L},{2L},{2L},{0x98422518L}},{{2L},{(-1L)},{2L},{0x98422518L},{2L},{2L},{0x778E10A3L},{(-2L)},{0x98422518L},{0x98422518L}}};
    int32_t l_33 = 0x57A23A34L;
    int i, j, k;
    l_33 |= (l_32[0][2][0] && 0x56540F213ED423CBLL);
    return g_21;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_74[i], "g_74[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 44
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 10
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 90
XXX times a non-volatile is write: 34
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 47
XXX percentage of non-volatile access: 95.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 46
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 18
   depth: 2, occurrence: 14

XXX percentage a fresh-made variable is used: 31.9
XXX percentage an existing variable is used: 68.1
********************* end of statistics **********************/

