/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1057029182785800340
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_4 = 0xE0L;/* VOLATILE GLOBAL g_4 */
static const uint64_t g_5 = 1UL;
static uint16_t g_6 = 3UL;
static uint8_t g_10 = 0x41L;
static uint32_t g_11[7] = {0xAAED6B65L,0xAAED6B65L,0xAAED6B65L,0xAAED6B65L,0xAAED6B65L,0xAAED6B65L,0xAAED6B65L};
static uint8_t g_25 = 0UL;
static volatile uint8_t g_28 = 1UL;/* VOLATILE GLOBAL g_28 */
static uint8_t g_49 = 252UL;
static volatile uint16_t g_52 = 65526UL;/* VOLATILE GLOBAL g_52 */


/* --- FORWARD DECLARATIONS --- */
static const int32_t  func_1(void);
static uint32_t  func_12(const uint64_t  p_13, int32_t  p_14, uint32_t  p_15, uint64_t  p_16);
static int32_t  func_17(int32_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_11 g_10 g_6 g_25 g_28 g_52
 * writes: g_6 g_10 g_25 g_28 g_49 g_52
 */
static const int32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_9 = 0x4AL;
    uint16_t l_50 = 65531UL;
    int32_t l_51 = 0x8284A898L;
    g_6 = (safe_mod_func_uint16_t_u_u((7L == g_4), g_5));
    g_10 = ((safe_lshift_func_int8_t_s_u(((9UL || (-4L)) , 0x7DL), l_9)) , l_9);
    for (l_9 = 1; (l_9 <= 6); l_9 += 1)
    { /* block id: 5 */
        int32_t l_57 = 0xE9BECC42L;
        int i;
        l_50 &= (func_12(g_11[l_9], g_11[l_9], g_10, g_11[6]) <= g_11[l_9]);
        g_52++;
        l_57 &= (((safe_div_func_uint16_t_u_u(0x4B91L, l_50)) <= l_50) <= l_51);
    }
    return g_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_25 g_28 g_5 g_11
 * writes: g_6 g_25 g_28 g_49
 */
static uint32_t  func_12(const uint64_t  p_13, int32_t  p_14, uint32_t  p_15, uint64_t  p_16)
{ /* block id: 6 */
    uint32_t l_39 = 0x6F2BA10FL;
    p_14 &= func_17((((safe_sub_func_uint16_t_u_u((p_16 , 65533UL), g_4)) > g_6) , p_16));
    if (g_5)
        goto lbl_40;
lbl_40:
    for (g_25 = (-9); (g_25 == 6); ++g_25)
    { /* block id: 21 */
        uint8_t l_38[2];
        int i;
        for (i = 0; i < 2; i++)
            l_38[i] = 0xEDL;
        p_14 = (!(safe_div_func_uint32_t_u_u((((0xA7967268F57F54ABLL == l_38[1]) || 0x3F079038991F32AFLL) | l_39), l_38[0])));
    }
    for (l_39 = 0; (l_39 <= 6); l_39 += 1)
    { /* block id: 27 */
        int i;
        p_14 = (!((safe_unary_minus_func_uint64_t_u(g_11[l_39])) | 0x05C8L));
        g_49 = (safe_mul_func_uint16_t_u_u((safe_add_func_int8_t_s_s((((safe_rshift_func_int8_t_s_s(g_4, l_39)) | g_11[l_39]) >= 4294967291UL), g_11[l_39])), 1UL));
        return l_39;
    }
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_25 g_28 g_5
 * writes: g_6 g_25 g_28
 */
static int32_t  func_17(int32_t  p_18)
{ /* block id: 7 */
    int32_t l_26 = 0x37D6C505L;
    int32_t l_27[9] = {0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL,0x2D38CA8CL};
    int16_t l_32 = 0xA3A6L;
    int i;
    for (g_6 = 4; (g_6 == 8); g_6++)
    { /* block id: 10 */
        g_25 = (safe_mul_func_int16_t_s_s(((p_18 | 0xA6AEL) , g_6), 0x6619L));
        return g_25;
    }
    if (g_6)
        goto lbl_31;
lbl_31:
    g_28++;
    l_27[4] = (((l_32 && 0x4B05EF13L) >= p_18) && g_5);
    return p_18;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_11[i], "g_11[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 21
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3

XXX total number of pointers: 0

XXX times a non-volatile is read: 35
XXX times a non-volatile is write: 14
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 19
XXX percentage of non-volatile access: 90.7

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 23
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 9

XXX percentage a fresh-made variable is used: 37
XXX percentage an existing variable is used: 63
********************* end of statistics **********************/

