/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16128058931166516626
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
   volatile uint8_t  f1;
   int16_t  f2;
   int16_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x8A87013DL;
static int8_t g_25[8] = {0x84L,0xCBL,0x84L,0x84L,0xCBL,0x84L,0x84L,0xCBL};
static uint32_t g_33[2] = {1UL,1UL};
static struct S0 g_38 = {18446744073709551608UL,0xA4L,0xDEE6L,0xE3E4L};/* VOLATILE GLOBAL g_38 */
static struct S0 g_39 = {0x1A770AACC702B5BDLL,0xDDL,0xD57DL,0x8C46L};/* VOLATILE GLOBAL g_39 */
static struct S0 g_49 = {2UL,1UL,0xDF47L,0x5881L};/* VOLATILE GLOBAL g_49 */
static uint8_t g_56 = 1UL;
static int8_t g_78 = 0xF3L;
static struct S0 g_81 = {0x88526770660D0C57LL,255UL,0xD6BDL,0xDCC6L};/* VOLATILE GLOBAL g_81 */
static int64_t g_82 = (-1L);
static volatile int16_t g_83 = 0xF1BCL;/* VOLATILE GLOBAL g_83 */
static uint8_t g_84 = 0UL;
static struct S0 g_87 = {0x1AB994F54D63FF5ALL,255UL,0x2F17L,-9L};/* VOLATILE GLOBAL g_87 */
static int16_t g_89[5] = {1L,1L,1L,1L,1L};
static volatile uint32_t g_92 = 9UL;/* VOLATILE GLOBAL g_92 */
static uint32_t g_98 = 0x597B072CL;
static struct S0 g_113 = {0xB5F4D78F30ED53B0LL,0x2DL,-1L,0L};/* VOLATILE GLOBAL g_113 */
static struct S0 g_114 = {0UL,2UL,0x7125L,0x8CE6L};/* VOLATILE GLOBAL g_114 */
static struct S0 g_117 = {18446744073709551615UL,0xF6L,-1L,0xF895L};/* VOLATILE GLOBAL g_117 */
static struct S0 g_118[3] = {{5UL,246UL,-1L,-1L},{5UL,246UL,-1L,-1L},{5UL,246UL,-1L,-1L}};
static volatile uint16_t g_120 = 2UL;/* VOLATILE GLOBAL g_120 */
static int16_t g_132 = (-7L);
static uint32_t g_146 = 0x0C9FB339L;
static struct S0 g_153 = {0x5E8599F0A174F72ELL,0x84L,0x7BDFL,9L};/* VOLATILE GLOBAL g_153 */
static uint8_t g_171 = 8UL;
static volatile int32_t g_191 = 0x1D9937ACL;/* VOLATILE GLOBAL g_191 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint16_t  func_9(int32_t  p_10, int32_t  p_11, int16_t  p_12);
static struct S0  func_14(const uint64_t  p_15, const uint32_t  p_16, uint32_t  p_17);
static int16_t  func_18(uint8_t  p_19, uint8_t  p_20, uint64_t  p_21, int16_t  p_22, int8_t  p_23);
static uint16_t  func_42(uint16_t  p_43, int8_t  p_44);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_25 g_33 g_38 g_39 g_49 g_78 g_84 g_87 g_92 g_98 g_56 g_81.f3 g_113 g_117 g_120 g_132 g_81.f2 g_118.f3 g_114.f3 g_89 g_118.f2 g_81.f1 g_153.f3 g_118 g_81.f0 g_114.f0 g_191 g_146
 * writes: g_2 g_33 g_39.f3 g_38.f3 g_56 g_38.f2 g_78 g_81 g_84 g_49 g_92 g_98 g_114 g_87.f2 g_118 g_120 g_132 g_146 g_153 g_171
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_13 = 1L;
    int8_t l_169 = 0x60L;
lbl_173:
    for (g_2 = 16; (g_2 <= 11); g_2 = safe_sub_func_uint8_t_u_u(g_2, 1))
    { /* block id: 3 */
        int64_t l_170 = 0L;
        if (((safe_lshift_func_int8_t_s_u((safe_add_func_uint32_t_u_u((func_9(l_13, g_2, g_2) ^ g_25[3]), l_13)), g_117.f3)) && g_117.f0))
        { /* block id: 100 */
            uint8_t l_168 = 0xD8L;
            l_170 = (safe_mod_func_int64_t_s_s((((safe_mul_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(((safe_sub_func_int32_t_s_s((safe_add_func_int64_t_s_s((safe_sub_func_uint32_t_u_u(((safe_div_func_uint8_t_u_u(g_33[0], l_168)) | g_118[1].f2), l_13)), 1L)), 0x3EDD010AL)) && l_169), g_81.f1)) <= 0x7A280F67D394C19ALL), g_153.f3)) , 0x69498813L) || 4294967293UL), 0xE87E310A61F905A6LL));
        }
        else
        { /* block id: 102 */
            int16_t l_172 = 0x84CAL;
            g_171 = (g_118[2] , l_13);
            return l_172;
        }
        if (g_113.f2)
            goto lbl_173;
    }
    if (l_169)
    { /* block id: 108 */
        g_2 |= (safe_add_func_int64_t_s_s(((safe_add_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s((0x88078DF3L | 0xCF842465L), g_84)) ^ g_38.f2), (-1L))) , l_13), 0xCB87100DB3469156LL));
        return g_39.f3;
    }
    else
    { /* block id: 111 */
        int32_t l_184[6] = {0L,0x9A90B212L,0L,0L,0x9A90B212L,0L};
        int i;
        g_2 = ((safe_div_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_u(l_13, 9)) < l_184[1]), g_118[1].f2)) , g_39.f3);
        g_2 = g_81.f0;
        for (g_114.f0 = (-7); (g_114.f0 >= 38); g_114.f0++)
        { /* block id: 116 */
            g_2 = l_184[1];
            return g_56;
        }
        g_2 = (safe_sub_func_int64_t_s_s((((safe_mod_func_int8_t_s_s((-3L), 0x96L)) < g_191) > g_33[1]), g_146));
    }
    for (g_78 = 0; (g_78 < (-26)); g_78--)
    { /* block id: 124 */
        if (g_81.f2)
            break;
    }
    return g_191;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_2 g_33 g_38 g_39 g_49 g_78 g_84 g_87 g_92 g_98 g_56 g_81.f3 g_113 g_117 g_120 g_132 g_81.f2 g_118.f3 g_114.f3 g_89
 * writes: g_33 g_39.f3 g_38.f3 g_56 g_38.f2 g_78 g_81 g_84 g_49 g_92 g_98 g_114 g_87.f2 g_118 g_120 g_132 g_146 g_153
 */
static uint16_t  func_9(int32_t  p_10, int32_t  p_11, int16_t  p_12)
{ /* block id: 4 */
    int32_t l_24 = 0x4F88039DL;
    const uint16_t l_36 = 0xF433L;
    int32_t l_136 = 0xC2C3437DL;
    int32_t l_145 = 1L;
    g_114 = func_14((func_18(p_10, l_24, l_24, l_24, l_24) , l_24), l_36, g_2);
    for (g_87.f2 = 0; (g_87.f2 > (-6)); g_87.f2--)
    { /* block id: 81 */
        int16_t l_119 = 0x94FAL;
        if (g_39.f2)
        { /* block id: 82 */
            g_118[1] = g_117;
            ++g_120;
        }
        else
        { /* block id: 85 */
            const uint16_t l_131 = 65531UL;
            g_132 |= (safe_div_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_add_func_int32_t_s_s((safe_div_func_uint8_t_u_u(p_10, l_131)), 0L)), 0x6640828DL)), p_11));
            p_11 ^= 1L;
            p_10 = (0x6D738FFA6F56A42CLL < g_81.f2);
            l_136 = (~(((safe_mod_func_uint64_t_u_u(g_118[1].f3, l_131)) && p_12) , 0x9A50L));
        }
    }
    l_136 = p_12;
    if ((~(safe_mod_func_int64_t_s_s((0x80L <= g_114.f3), l_136))))
    { /* block id: 93 */
        return g_25[4];
    }
    else
    { /* block id: 95 */
        uint8_t l_144 = 247UL;
        g_146 = (((safe_div_func_int32_t_s_s((safe_mod_func_uint64_t_u_u((l_144 || p_10), l_145)), l_144)) <= 0x24F8FB3CL) && 0x4B42L);
        g_153 = func_14((((((safe_lshift_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_lshift_func_int16_t_s_s(0L, g_87.f1)), p_12)), p_12)) != g_89[4]) != p_10) && 0xEBAF4236FC2CA393LL) , p_10), p_10, g_49.f3);
    }
    return g_132;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_33 g_38 g_39 g_25 g_49 g_78 g_84 g_87 g_92 g_98 g_56 g_81.f3 g_113
 * writes: g_39.f3 g_38.f3 g_56 g_38.f2 g_78 g_81 g_84 g_49 g_92 g_98
 */
static struct S0  func_14(const uint64_t  p_15, const uint32_t  p_16, uint32_t  p_17)
{ /* block id: 25 */
    int32_t l_37 = (-1L);
    uint8_t l_110 = 253UL;
    if ((((4294967291UL && g_2) && g_33[0]) || l_37))
    { /* block id: 26 */
        if (p_16)
        { /* block id: 27 */
            return g_38;
        }
        else
        { /* block id: 29 */
            return g_39;
        }
    }
    else
    { /* block id: 32 */
lbl_112:
        for (g_39.f3 = 0; (g_39.f3 <= 7); g_39.f3 += 1)
        { /* block id: 35 */
            int32_t l_101[2];
            int i;
            for (i = 0; i < 2; i++)
                l_101[i] = 1L;
            l_101[1] ^= (safe_rshift_func_uint16_t_u_s(func_42(g_25[g_39.f3], g_25[g_39.f3]), g_25[g_39.f3]));
            l_37 = ((+(g_25[g_39.f3] & l_37)) | p_16);
        }
    }
    for (g_49.f2 = (-4); (g_49.f2 < (-12)); g_49.f2--)
    { /* block id: 68 */
        int8_t l_109 = (-6L);
        int32_t l_111 = (-8L);
        for (g_56 = 11; (g_56 != 1); g_56--)
        { /* block id: 71 */
            l_110 |= (safe_div_func_int8_t_s_s(l_109, g_81.f3));
            l_111 = 0xDC7391AFL;
            if (g_2)
                goto lbl_112;
        }
    }
    return g_113;
}


/* ------------------------------------------ */
/* 
 * reads : g_25
 * writes: g_33
 */
static int16_t  func_18(uint8_t  p_19, uint8_t  p_20, uint64_t  p_21, int16_t  p_22, int8_t  p_23)
{ /* block id: 5 */
    int32_t l_28 = 1L;
    int32_t l_32[1];
    int i;
    for (i = 0; i < 1; i++)
        l_32[i] = 0xF9A4D91FL;
    for (p_21 = 0; (p_21 <= 7); p_21 += 1)
    { /* block id: 8 */
        int32_t l_35 = 0x84B52DD8L;
        int i;
        if (g_25[p_21])
        { /* block id: 9 */
            l_28 |= (safe_mul_func_int8_t_s_s((0x8699L <= g_25[2]), p_19));
        }
        else
        { /* block id: 11 */
            uint32_t l_31 = 0x44D4E2B7L;
            l_31 = (safe_lshift_func_uint8_t_u_u(0x8CL, 2));
        }
        l_32[0] = g_25[p_21];
        for (l_28 = 7; (l_28 >= 0); l_28 -= 1)
        { /* block id: 17 */
            uint8_t l_34 = 0x0FL;
            g_33[0] = (65535UL == p_23);
            if (l_34)
                continue;
            l_35 |= g_25[3];
            if (l_32[0])
                break;
        }
    }
    return p_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_49 g_39.f3 g_38.f3 g_39.f2 g_38.f2 g_38.f0 g_25 g_33 g_38.f1 g_78 g_39 g_84 g_87 g_92 g_98
 * writes: g_38.f3 g_56 g_38.f2 g_78 g_81 g_84 g_49 g_92 g_98
 */
static uint16_t  func_42(uint16_t  p_43, int8_t  p_44)
{ /* block id: 36 */
    int64_t l_50[7];
    int32_t l_88 = 0x040CCA84L;
    int32_t l_91 = 0x7434CA83L;
    int32_t l_97 = 0x479F84CDL;
    int i;
    for (i = 0; i < 7; i++)
        l_50[i] = (-8L);
    if ((p_43 & 0x94L))
    { /* block id: 37 */
        int32_t l_51[10];
        int i;
        for (i = 0; i < 10; i++)
            l_51[i] = (-1L);
        l_51[3] = (((safe_mod_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(((((g_49 , 0xDFAC86E89BE308DDLL) && l_50[5]) , p_44) == 0x9CE07B88L), g_39.f3)), g_39.f3)) && l_50[5]) <= 1L);
        for (g_38.f3 = (-23); (g_38.f3 != (-9)); g_38.f3 = safe_add_func_int32_t_s_s(g_38.f3, 1))
        { /* block id: 41 */
            g_56 = ((safe_lshift_func_int8_t_s_s((-1L), 7)) & (-7L));
            if (g_39.f2)
                break;
            if (p_43)
                continue;
        }
        for (g_38.f2 = 0; (g_38.f2 < 11); g_38.f2 = safe_add_func_uint32_t_u_u(g_38.f2, 9))
        { /* block id: 48 */
            uint32_t l_77 = 1UL;
            g_78 |= (!((((safe_add_func_int64_t_s_s((((safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s((safe_add_func_int64_t_s_s((safe_unary_minus_func_uint32_t_u((safe_div_func_uint16_t_u_u((safe_div_func_uint16_t_u_u((((safe_mod_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((((g_38.f0 | (-4L)) < g_38.f2) != p_44), p_43)) || g_25[3]), g_33[1])) < p_43) , l_51[4]), l_77)), 0x3396L)))), 0xE2D7E08CD9178FB6LL)), 10)), g_38.f1)) && g_33[0]) < 0x20D70F0D5DC534F9LL), 18446744073709551615UL)) || 0L) ^ l_51[3]) && g_33[0]));
        }
    }
    else
    { /* block id: 51 */
        int32_t l_90 = 1L;
        int32_t l_95 = 1L;
        int32_t l_96 = (-4L);
        if ((safe_sub_func_int32_t_s_s(0x2FBA83E1L, (-10L))))
        { /* block id: 52 */
            g_81 = g_39;
            g_84--;
            g_49 = g_87;
        }
        else
        { /* block id: 56 */
            ++g_92;
        }
        --g_98;
    }
    return p_43;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_33[i], "g_33[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_38.f0, "g_38.f0", print_hash_value);
    transparent_crc(g_38.f1, "g_38.f1", print_hash_value);
    transparent_crc(g_38.f2, "g_38.f2", print_hash_value);
    transparent_crc(g_38.f3, "g_38.f3", print_hash_value);
    transparent_crc(g_39.f0, "g_39.f0", print_hash_value);
    transparent_crc(g_39.f1, "g_39.f1", print_hash_value);
    transparent_crc(g_39.f2, "g_39.f2", print_hash_value);
    transparent_crc(g_39.f3, "g_39.f3", print_hash_value);
    transparent_crc(g_49.f0, "g_49.f0", print_hash_value);
    transparent_crc(g_49.f1, "g_49.f1", print_hash_value);
    transparent_crc(g_49.f2, "g_49.f2", print_hash_value);
    transparent_crc(g_49.f3, "g_49.f3", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_81.f0, "g_81.f0", print_hash_value);
    transparent_crc(g_81.f1, "g_81.f1", print_hash_value);
    transparent_crc(g_81.f2, "g_81.f2", print_hash_value);
    transparent_crc(g_81.f3, "g_81.f3", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_87.f0, "g_87.f0", print_hash_value);
    transparent_crc(g_87.f1, "g_87.f1", print_hash_value);
    transparent_crc(g_87.f2, "g_87.f2", print_hash_value);
    transparent_crc(g_87.f3, "g_87.f3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_89[i], "g_89[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_113.f0, "g_113.f0", print_hash_value);
    transparent_crc(g_113.f1, "g_113.f1", print_hash_value);
    transparent_crc(g_113.f2, "g_113.f2", print_hash_value);
    transparent_crc(g_113.f3, "g_113.f3", print_hash_value);
    transparent_crc(g_114.f0, "g_114.f0", print_hash_value);
    transparent_crc(g_114.f1, "g_114.f1", print_hash_value);
    transparent_crc(g_114.f2, "g_114.f2", print_hash_value);
    transparent_crc(g_114.f3, "g_114.f3", print_hash_value);
    transparent_crc(g_117.f0, "g_117.f0", print_hash_value);
    transparent_crc(g_117.f1, "g_117.f1", print_hash_value);
    transparent_crc(g_117.f2, "g_117.f2", print_hash_value);
    transparent_crc(g_117.f3, "g_117.f3", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_118[i].f0, "g_118[i].f0", print_hash_value);
        transparent_crc(g_118[i].f1, "g_118[i].f1", print_hash_value);
        transparent_crc(g_118[i].f2, "g_118[i].f2", print_hash_value);
        transparent_crc(g_118[i].f3, "g_118[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    transparent_crc(g_153.f0, "g_153.f0", print_hash_value);
    transparent_crc(g_153.f1, "g_153.f1", print_hash_value);
    transparent_crc(g_153.f2, "g_153.f2", print_hash_value);
    transparent_crc(g_153.f3, "g_153.f3", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_191, "g_191", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 46
   depth: 1, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 20
breakdown:
   depth: 1, occurrence: 70
   depth: 2, occurrence: 18
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 20, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 123
XXX times a non-volatile is write: 43
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 57
XXX percentage of non-volatile access: 96

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 72
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 24
   depth: 2, occurrence: 32

XXX percentage a fresh-made variable is used: 35.2
XXX percentage an existing variable is used: 64.8
********************* end of statistics **********************/

