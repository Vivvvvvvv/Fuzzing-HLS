/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4575118232847556138
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_12 = 0x0BF90A23L;
static uint64_t g_39 = 0UL;
static uint32_t g_40[3] = {1UL,1UL,1UL};
static int32_t g_43[1][6] = {{9L,9L,9L,9L,9L,9L}};
static volatile uint8_t g_44 = 1UL;/* VOLATILE GLOBAL g_44 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint64_t  func_6(uint32_t  p_7, int32_t  p_8, uint8_t  p_9, uint32_t  p_10);
static int32_t  func_18(uint32_t  p_19, const uint32_t  p_20, int64_t  p_21, int64_t  p_22);
static int64_t  func_28(const int16_t  p_29, const uint64_t  p_30);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_39 g_44 g_40 g_43
 * writes: g_12 g_40 g_44 g_43
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2 = (-6L);
    int32_t l_3 = 0x22BA3946L;
    int32_t l_50 = 5L;
    int32_t l_51 = 0L;
    int32_t l_52[10][4][6] = {{{0x46587A76L,4L,1L,(-1L),1L,4L},{0xEE255298L,0xF40839CAL,(-4L),(-1L),0x28597010L,0x94210AB9L},{0x46587A76L,0x94210AB9L,0L,0x94210AB9L,0x46587A76L,4L},{0L,0x94210AB9L,0xEE255298L,(-3L),0x28597010L,(-3L)}},{{(-1L),0xF40839CAL,(-1L),0x94210AB9L,1L,(-3L)},{(-1L),4L,0xEE255298L,(-1L),0xEE255298L,4L},{1L,4L,5L,0xF40839CAL,0x46587A76L,(-3L)},{0xEE255298L,(-3L),0x28597010L,(-3L),0xEE255298L,0x94210AB9L}},{{0L,(-3L),(-1L),(-1L),0x46587A76L,(-1L)},{(-4L),4L,(-4L),(-3L),0L,(-1L)},{1L,0x94210AB9L,(-1L),0xF40839CAL,(-1L),0x94210AB9L},{0L,4L,0x28597010L,0xF40839CAL,(-1L),(-3L)}},{{1L,(-3L),5L,(-3L),1L,0x94210AB9L},{(-4L),(-3L),0L,(-1L),(-1L),(-1L)},{0L,4L,0L,(-3L),(-1L),(-1L)},{0xEE255298L,0x94210AB9L,0L,0xF40839CAL,0L,0x94210AB9L}},{{(-1L),4L,5L,0xF40839CAL,0x46587A76L,(-3L)},{0xEE255298L,(-3L),0x28597010L,(-3L),0xEE255298L,0x94210AB9L},{0L,(-3L),(-1L),(-1L),0x46587A76L,(-1L)},{(-4L),4L,(-4L),(-3L),0L,(-1L)}},{{1L,0x94210AB9L,(-1L),0xF40839CAL,(-1L),0x94210AB9L},{0L,4L,0x28597010L,0xF40839CAL,(-1L),(-3L)},{1L,(-3L),5L,(-3L),1L,0x94210AB9L},{(-4L),(-3L),0L,(-1L),(-1L),(-1L)}},{{0L,4L,0L,(-3L),(-1L),(-1L)},{0xEE255298L,0x94210AB9L,0L,0xF40839CAL,0L,0x94210AB9L},{(-1L),4L,5L,0xF40839CAL,0x46587A76L,(-3L)},{0xEE255298L,(-3L),0x28597010L,(-3L),0xEE255298L,0x94210AB9L}},{{0L,(-3L),(-1L),(-1L),0x46587A76L,(-1L)},{(-4L),4L,(-4L),(-3L),0L,(-1L)},{1L,0x94210AB9L,(-1L),0xF40839CAL,(-1L),0x94210AB9L},{0L,4L,0x28597010L,0xF40839CAL,(-1L),(-3L)}},{{1L,(-3L),5L,(-3L),1L,0x94210AB9L},{(-4L),(-3L),0L,(-1L),(-1L),(-1L)},{0L,4L,0L,(-3L),(-1L),(-1L)},{0xEE255298L,0x94210AB9L,0L,0xF40839CAL,0L,0x94210AB9L}},{{(-1L),4L,5L,0xF40839CAL,0x46587A76L,(-3L)},{0xEE255298L,(-3L),0x28597010L,(-3L),0xEE255298L,0x94210AB9L},{5L,(-1L),0L,0xF40839CAL,1L,0xF40839CAL},{0x28597010L,0x94210AB9L,0x28597010L,(-1L),(-4L),0xF40839CAL}}};
    int i, j, k;
    l_3 |= l_2;
    for (l_3 = 11; (l_3 >= 5); l_3 = safe_sub_func_uint64_t_u_u(l_3, 8))
    { /* block id: 4 */
        uint32_t l_11[2];
        uint16_t l_41 = 0UL;
        int32_t l_42[6][3] = {{0xA50E28ABL,0xA50E28ABL,0x2AEC7F51L},{0x5D1B3002L,0x2AEC7F51L,0x2AEC7F51L},{0x2AEC7F51L,0xEDA7DA9FL,0x9D3B05E2L},{0x5D1B3002L,0xEDA7DA9FL,0x5D1B3002L},{0xA50E28ABL,0x2AEC7F51L,0x9D3B05E2L},{0xA50E28ABL,0xA50E28ABL,0x2AEC7F51L}};
        int i, j;
        for (i = 0; i < 2; i++)
            l_11[i] = 0x1DA622A1L;
        l_41 ^= (func_6(l_11[0], l_2, g_12, l_11[0]) == 0x0212AEAFD71021F5LL);
        if (l_11[1])
        { /* block id: 19 */
            uint8_t l_49 = 6UL;
            int32_t l_53 = 7L;
            int32_t l_54 = (-10L);
            int32_t l_55[6][1][3] = {{{0x533BF952L,(-4L),0x533BF952L}},{{7L,7L,0x1F0B5F9DL}},{{0L,(-4L),0L}},{{7L,0x1F0B5F9DL,0x1F0B5F9DL}},{{0x533BF952L,(-4L),0x533BF952L}},{{7L,7L,0x1F0B5F9DL}}};
            uint8_t l_56[8] = {0x4FL,0x13L,0x4FL,0x4FL,0x13L,0x4FL,0x4FL,0x13L};
            int i, j, k;
            --g_44;
            g_43[0][4] = ((safe_mul_func_uint8_t_u_u((0UL > g_40[1]), l_49)) , g_12);
            l_56[5]++;
            l_52[5][1][4] ^= (safe_add_func_uint64_t_u_u((g_43[0][4] , g_12), l_3));
        }
        else
        { /* block id: 24 */
            g_43[0][4] = (safe_mod_func_uint16_t_u_u((!l_42[4][2]), l_52[2][1][4]));
            g_12 = g_43[0][4];
        }
        return g_43[0][4];
    }
    return l_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_39
 * writes: g_12 g_40
 */
static uint64_t  func_6(uint32_t  p_7, int32_t  p_8, uint8_t  p_9, uint32_t  p_10)
{ /* block id: 5 */
    uint32_t l_16[2][3] = {{0x16501874L,0x8E92EDA8L,0x8E92EDA8L},{0x16501874L,0x8E92EDA8L,0x8E92EDA8L}};
    int32_t l_17 = 0x64F6CBCBL;
    int i, j;
    p_8 = (((4294967295UL <= g_12) > 255UL) ^ 0x13L);
    l_17 = (safe_div_func_uint32_t_u_u((+l_16[0][1]), l_16[1][2]));
    p_8 = func_18(((4294967292UL || 1UL) , 7UL), g_12, g_12, l_16[1][2]);
    g_40[1] = (safe_add_func_uint8_t_u_u((((safe_sub_func_uint64_t_u_u(((((func_28(p_10, l_16[0][1]) , g_12) || 0x4A126529L) || p_9) ^ 1UL), g_39)) || 0x39L) < 255UL), 0x8DL));
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_18(uint32_t  p_19, const uint32_t  p_20, int64_t  p_21, int64_t  p_22)
{ /* block id: 8 */
    uint8_t l_23[2];
    int i;
    for (i = 0; i < 2; i++)
        l_23[i] = 0x89L;
    l_23[0] = (-1L);
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_12
 * writes: g_12
 */
static int64_t  func_28(const int16_t  p_29, const uint64_t  p_30)
{ /* block id: 12 */
    int32_t l_31 = (-1L);
    int32_t l_38[7] = {0xAFA0B2B0L,1L,1L,0xAFA0B2B0L,1L,1L,0xAFA0B2B0L};
    int i;
    g_12 = l_31;
    l_38[2] = (safe_sub_func_uint64_t_u_u(((((((safe_div_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(g_12, p_30)), 1UL)) > l_31) , 255UL) <= p_29) , l_31) , l_31), g_12));
    return l_38[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_40[i], "g_40[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_43[i][j], "g_43[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_44, "g_44", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 27
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 40
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 98.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 22
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 3
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
********************* end of statistics **********************/

