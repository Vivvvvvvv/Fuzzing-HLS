/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7714996875377484445
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 6L;
static int32_t g_37[5] = {1L,1L,1L,1L,1L};
static volatile int32_t g_38 = 1L;/* VOLATILE GLOBAL g_38 */
static volatile int32_t g_40 = 0x49F2B782L;/* VOLATILE GLOBAL g_40 */
static uint16_t g_41 = 0UL;
static int32_t g_82[10][5][1] = {{{1L},{(-1L)},{(-1L)},{(-4L)},{1L}},{{0xABC45AFCL},{1L},{(-4L)},{(-1L)},{(-1L)}},{{1L},{(-1L)},{(-1L)},{(-4L)},{1L}},{{0xABC45AFCL},{1L},{(-4L)},{(-1L)},{(-1L)}},{{1L},{(-1L)},{(-1L)},{(-4L)},{1L}},{{0xABC45AFCL},{1L},{(-4L)},{(-1L)},{(-1L)}},{{1L},{(-1L)},{(-1L)},{(-4L)},{1L}},{{0xABC45AFCL},{1L},{(-4L)},{(-1L)},{(-1L)}},{{1L},{0xABC45AFCL},{(-10L)},{0x803B567AL},{1L}},{{(-4L)},{1L},{0x803B567AL},{(-10L)},{0xABC45AFCL}}};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const uint32_t  func_7(int8_t  p_8);
static uint16_t  func_9(uint32_t  p_10, uint16_t  p_11, int64_t  p_12);
static uint8_t  func_26(const uint16_t  p_27, int32_t  p_28, uint32_t  p_29, uint32_t  p_30, const int64_t  p_31);
static int8_t  func_49(int64_t  p_50, uint64_t  p_51, uint16_t  p_52);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_41 g_38 g_40 g_37 g_82
 * writes: g_2 g_41 g_40 g_82
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_91 = 1UL;
    int32_t l_122 = 7L;
    for (g_2 = (-6); (g_2 > (-4)); g_2 = safe_add_func_uint8_t_u_u(g_2, 2))
    { /* block id: 3 */
        uint32_t l_13 = 18446744073709551607UL;
        int32_t l_120 = 0xB5088466L;
        l_120 = ((safe_mod_func_uint64_t_u_u((func_7(((((func_9(g_2, l_13, g_2) <= l_91) || g_2) >= g_37[1]) <= g_37[1])) ^ g_2), 0x3E15B557241B9AD1LL)) ^ g_37[1]);
        if (l_13)
        { /* block id: 80 */
            int16_t l_121 = 0xAD40L;
            return l_121;
        }
        else
        { /* block id: 82 */
            l_122 &= g_82[4][1][0];
        }
        g_40 &= 4L;
        g_40 = 5L;
    }
    g_2 ^= (l_122 == 0x3D3F511B60CE2261LL);
    return l_91;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_37 g_2 g_82 g_40
 * writes:
 */
static const uint32_t  func_7(int8_t  p_8)
{ /* block id: 52 */
    int32_t l_92 = 0xA6FF1AB1L;
    l_92 = (-7L);
    l_92 = ((safe_lshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(l_92, p_8)), 2)) ^ g_41);
    for (p_8 = (-23); (p_8 >= (-12)); p_8 = safe_add_func_uint64_t_u_u(p_8, 5))
    { /* block id: 57 */
        uint16_t l_101 = 0x8388L;
        int32_t l_107[8][2] = {{0xCB6E431BL,0xCB6E431BL},{5L,0xCB6E431BL},{0xCB6E431BL,5L},{0xCB6E431BL,0xCB6E431BL},{5L,0xCB6E431BL},{0xCB6E431BL,5L},{0xCB6E431BL,0xCB6E431BL},{5L,0xCB6E431BL}};
        int i, j;
        if ((safe_div_func_uint16_t_u_u((l_92 >= 65535UL), 1UL)))
        { /* block id: 58 */
            int64_t l_104 = 0xFBB8A93D2D6DA1B1LL;
            l_101++;
            l_92 &= l_104;
            l_107[6][0] |= (safe_mul_func_uint8_t_u_u(g_37[1], l_101));
        }
        else
        { /* block id: 62 */
            uint64_t l_108[1];
            int32_t l_111 = 0x715EE052L;
            int i;
            for (i = 0; i < 1; i++)
                l_108[i] = 0xC64A1B41FDD29F2DLL;
            --l_108[0];
            l_111 = (p_8 >= l_92);
        }
    }
    for (l_92 = (-10); (l_92 <= 12); ++l_92)
    { /* block id: 69 */
        int8_t l_119 = 0x7EL;
        for (p_8 = 0; (p_8 <= 19); p_8 = safe_add_func_uint32_t_u_u(p_8, 2))
        { /* block id: 72 */
            int32_t l_116 = 0xE4EC2A0AL;
            l_116 = g_2;
            l_116 = g_82[4][1][0];
            l_119 ^= (safe_mod_func_uint32_t_u_u(((((g_41 < 1UL) <= g_40) || l_116) ^ l_116), 0x5FF68F1FL));
        }
    }
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_41 g_38 g_40 g_37 g_82
 * writes: g_41 g_40 g_82
 */
static uint16_t  func_9(uint32_t  p_10, uint16_t  p_11, int64_t  p_12)
{ /* block id: 4 */
    int16_t l_23 = 0x478CL;
    int32_t l_24 = 0xEE0CD979L;
    for (p_11 = (-20); (p_11 < 46); p_11++)
    { /* block id: 7 */
        uint32_t l_46 = 0UL;
        if (((safe_rshift_func_uint16_t_u_u(((((p_12 > 255UL) , 1UL) && 1UL) != g_2), p_11)) && g_2))
        { /* block id: 8 */
            l_24 ^= (safe_rshift_func_uint8_t_u_u((+(safe_sub_func_uint8_t_u_u((l_23 , p_10), p_10))), g_2));
        }
        else
        { /* block id: 10 */
            int64_t l_44 = 0xF0E26A25A9550690LL;
            int32_t l_45[4] = {(-1L),(-1L),(-1L),(-1L)};
            int i;
            g_40 = (+((((func_26(p_11, p_11, g_2, p_11, l_24) == p_10) > 1UL) , p_10) ^ g_38));
            l_46++;
            g_40 = (-7L);
        }
        return p_12;
    }
    g_82[4][1][0] ^= (func_49(p_11, g_2, g_40) , g_38);
    l_24 = ((safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u((l_23 ^ 0x9546ADB2F3DD08C6LL), g_82[9][3][0])) != p_12), g_37[3])), g_37[1])) , 0xDC8D5A9CL);
    for (l_24 = 0; (l_24 == (-29)); l_24--)
    { /* block id: 47 */
        g_40 = 0x515E6AD3L;
        return g_40;
    }
    return p_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_41
 * writes: g_41
 */
static uint8_t  func_26(const uint16_t  p_27, int32_t  p_28, uint32_t  p_29, uint32_t  p_30, const int64_t  p_31)
{ /* block id: 11 */
    int32_t l_36 = (-7L);
    for (p_30 = (-9); (p_30 <= 25); ++p_30)
    { /* block id: 14 */
        int8_t l_39 = 0xB5L;
        for (p_29 = 0; (p_29 >= 50); p_29++)
        { /* block id: 17 */
            l_36 = p_29;
        }
        ++g_41;
    }
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_41 g_37
 * writes: g_40
 */
static int8_t  func_49(int64_t  p_50, uint64_t  p_51, uint16_t  p_52)
{ /* block id: 29 */
    int32_t l_55 = 7L;
    int64_t l_71[9] = {0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL,0xC4D355714A8A5A2DLL};
    int32_t l_81 = 0x9BE8BA66L;
    int i;
    for (p_50 = 29; (p_50 >= (-30)); --p_50)
    { /* block id: 32 */
        const uint64_t l_70 = 0x72F548F9F0AC7725LL;
        int32_t l_72 = 0xF140B356L;
        l_55 = p_50;
        for (l_55 = 7; (l_55 > (-16)); l_55 = safe_sub_func_uint8_t_u_u(l_55, 6))
        { /* block id: 36 */
            const int32_t l_69 = 0L;
            l_72 &= (+((((((safe_rshift_func_uint8_t_u_u(((((+((((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((+(safe_add_func_uint16_t_u_u((p_50 , 7UL), p_50))), l_69)), l_70)) == l_55) >= l_69) > g_2)) , 65535UL) > 65535UL) && g_41), 5)) <= l_71[1]) <= p_51) <= g_37[1]) == l_69) || 0x2CL));
        }
        l_81 = (safe_rshift_func_uint8_t_u_u(((((safe_lshift_func_uint16_t_u_u(((((safe_sub_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((p_52 >= 0xF3L), p_52)), l_70)) > l_55) > l_70) , 0x3FD1L), p_51)) , p_51) && 65535UL) , 0x7EL), 3));
    }
    g_40 = (p_52 <= p_50);
    return p_52;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_37[i], "g_37[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_82[i][j][k], "g_82[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 31
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 17
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 14
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2
   depth: 17, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 88
XXX times a non-volatile is write: 32
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 40
XXX percentage of non-volatile access: 91.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 49
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 15
   depth: 2, occurrence: 16

XXX percentage a fresh-made variable is used: 25.6
XXX percentage an existing variable is used: 74.4
********************* end of statistics **********************/

