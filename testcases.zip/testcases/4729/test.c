/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16190786801494358723
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_5[10] = {0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL,0xAEEF20FE6E3245F1LL};
static uint64_t g_9 = 18446744073709551615UL;
static int32_t g_19[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, uint64_t  p_4);
static uint64_t  func_25(uint32_t  p_26, int16_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_19 g_9
 * writes: g_9 g_19
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_6 = (-1L);
    int32_t l_45 = (-8L);
    l_45 ^= func_2(g_5[5], l_6);
    return g_19[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_19 g_9
 * writes: g_9 g_19
 */
static int32_t  func_2(uint64_t  p_3, uint64_t  p_4)
{ /* block id: 1 */
    int32_t l_10 = (-1L);
    int32_t l_11 = 0x1E468A07L;
    int32_t l_12 = (-1L);
    int32_t l_13 = 0x40EB4495L;
    int32_t l_14 = (-1L);
    int32_t l_15 = 0xEAB1D6A5L;
    int32_t l_16 = (-5L);
    int32_t l_17[2];
    int32_t l_18 = 0x9D3388A0L;
    uint64_t l_20 = 18446744073709551610UL;
    int i;
    for (i = 0; i < 2; i++)
        l_17[i] = 1L;
    g_9 = ((safe_sub_func_int16_t_s_s((g_5[5] == p_4), p_3)) < 0x208373B2L);
    --l_20;
    for (l_18 = 0; (l_18 != (-6)); l_18 = safe_sub_func_int16_t_s_s(l_18, 6))
    { /* block id: 6 */
        int32_t l_44 = 0x911CCFE9L;
        g_19[8] = ((func_25(l_16, p_4, p_3) <= 5L) >= (-3L));
        l_15 |= (safe_mod_func_uint16_t_u_u((safe_div_func_int64_t_s_s(l_44, g_19[2])), 65531UL));
        l_44 &= (g_9 & 4294967295UL);
        if (g_19[5])
            continue;
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes:
 */
static uint64_t  func_25(uint32_t  p_26, int16_t  p_27, uint32_t  p_28)
{ /* block id: 7 */
    uint8_t l_29 = 0x9BL;
    int32_t l_38 = 0xF5B872A6L;
    --l_29;
    for (p_28 = 0; (p_28 <= 9); p_28 += 1)
    { /* block id: 11 */
        int64_t l_34[9] = {(-1L),7L,(-1L),7L,(-1L),7L,(-1L),7L,(-1L)};
        uint16_t l_35 = 65529UL;
        int32_t l_39[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int i;
        for (l_29 = 0; (l_29 <= 9); l_29 += 1)
        { /* block id: 14 */
            int16_t l_32 = (-1L);
            int32_t l_33 = 0xBCFB656DL;
            ++l_35;
            if (l_38)
                continue;
            l_39[3] = 1L;
        }
        if (g_19[4])
            continue;
    }
    return g_19[6];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 12
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 18
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 6
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 46
XXX percentage an existing variable is used: 54
********************* end of statistics **********************/

