/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16547112059240576396
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_4[3][8] = {{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL},{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}};
static uint16_t g_5 = 0xF845L;
static const volatile uint64_t g_12 = 18446744073709551615UL;/* VOLATILE GLOBAL g_12 */
static uint8_t g_23 = 1UL;
static volatile int32_t g_27[7] = {0L,0L,0L,0L,0L,0L,0L};
static uint64_t g_201 = 3UL;
static volatile int8_t g_217 = 2L;/* VOLATILE GLOBAL g_217 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_13(uint8_t  p_14, uint64_t  p_15, uint64_t  p_16);
static uint32_t  func_53(uint8_t  p_54, uint32_t  p_55, int16_t  p_56, uint8_t  p_57);
static uint8_t  func_70(int32_t  p_71);
static uint32_t  func_74(uint64_t  p_75, uint16_t  p_76, uint64_t  p_77, int8_t  p_78);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_12 g_23 g_27 g_201
 * writes: g_5 g_23 g_27 g_201
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_11[2][4][9] = {{{3L,(-8L),1L,(-8L),3L,(-3L),0xD816F93BL,(-1L),0xD816F93BL},{0xA927213EL,(-1L),0x3B6F9B69L,0x3B6F9B69L,(-1L),0xA927213EL,(-4L),(-1L),(-1L)},{0xD816F93BL,(-8L),0x466BC657L,8L,0x466BC657L,(-8L),0xD816F93BL,0x7D50F82BL,(-8L)},{0x3B6F9B69L,(-4L),0x3B6F9B69L,0x5DE1FC65L,0x5DE1FC65L,0x3B6F9B69L,(-4L),0x3B6F9B69L,0x5DE1FC65L}},{{1L,0x7D50F82BL,0x466BC657L,(-1L),3L,(-1L),0x466BC657L,0x7D50F82BL,1L},{0xA927213EL,0x5DE1FC65L,(-1L),0x5DE1FC65L,0xA927213EL,0xA927213EL,0x5DE1FC65L,(-1L),0x5DE1FC65L},{0x466BC657L,(-3L),(-8L),8L,3L,0x7D50F82BL,3L,8L,(-8L)},{0xA927213EL,0xA927213EL,0x5DE1FC65L,(-1L),0x5DE1FC65L,0xA927213EL,0xA927213EL,0x5DE1FC65L,(-1L)}}};
    int i, j, k;
    g_5 = (safe_mod_func_uint16_t_u_u((g_4[0][1] > 254UL), 0x2B16L));
    for (g_5 = (-17); (g_5 != 14); g_5++)
    { /* block id: 4 */
        int16_t l_8 = 1L;
        return l_8;
    }
    if ((((safe_mod_func_uint64_t_u_u(((l_11[0][1][8] == g_12) , 18446744073709551610UL), l_11[0][1][8])) > g_4[0][1]) && l_11[0][1][4]))
    { /* block id: 7 */
        int32_t l_17[10][8] = {{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L},{0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L,0x99EA5D84L,1L}};
        int i, j;
        l_11[0][1][8] = func_13(((l_17[2][5] > 4294967290UL) , l_11[0][1][8]), l_17[2][5], g_4[2][2]);
    }
    else
    { /* block id: 105 */
        int64_t l_208[7][4];
        int32_t l_210 = 2L;
        uint32_t l_211 = 0x68FD03CFL;
        int32_t l_218 = 0L;
        int32_t l_219[10][6] = {{0x08B3C05EL,0L,9L,9L,0L,0x08B3C05EL},{1L,0x4523AABDL,6L,0x3CFDD35DL,0x08B3C05EL,(-1L)},{0L,(-1L),0x9ACC29ECL,0x08B3C05EL,0x9ACC29ECL,(-1L)},{0L,(-1L),0x08B3C05EL,0x3CFDD35DL,6L,0x4523AABDL},{1L,0x08B3C05EL,0L,9L,9L,0L},{0x08B3C05EL,0x08B3C05EL,0x12A338AAL,1L,6L,9L},{(-1L),(-1L),0x3CFDD35DL,0x12A338AAL,0x9ACC29ECL,0x12A338AAL},{0x3CFDD35DL,(-1L),0x3CFDD35DL,0x4523AABDL,0x08B3C05EL,9L},{0x6EA63593L,0x4523AABDL,0x12A338AAL,0xEC8A2884L,0L,0L},{0x08B3C05EL,0xEC8A2884L,0xEC8A2884L,0x08B3C05EL,(-1L),(-1L)}};
        uint64_t l_220[4];
        int i, j;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 4; j++)
                l_208[i][j] = 0L;
        }
        for (i = 0; i < 4; i++)
            l_220[i] = 0x32CC213E5AC41574LL;
        g_201 &= (safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(l_11[0][1][8], l_11[0][3][7])), g_27[1]));
        if ((safe_mul_func_uint8_t_u_u(((((safe_rshift_func_uint8_t_u_u((8UL < 0UL), l_208[2][1])) <= 0x71L) >= 0x6A1A75BCL) == 0x64L), l_208[2][1])))
        { /* block id: 107 */
            uint8_t l_209 = 5UL;
            return l_209;
        }
        else
        { /* block id: 109 */
            int8_t l_214 = 8L;
            int64_t l_215 = 0xCAEB4B55F375361BLL;
            int32_t l_216[10][9][2] = {{{(-1L),0L},{1L,0x8740F6EFL},{(-3L),1L},{(-1L),2L},{(-1L),1L},{(-3L),0x8740F6EFL},{1L,0L},{(-1L),0x14B4C299L},{1L,(-9L)}},{{(-9L),0x9F414069L},{0xD741B982L,1L},{4L,(-1L)},{0x598B75F5L,0x14B4C299L},{0x8DE327F2L,0x91B9568FL},{(-1L),1L},{(-3L),0L},{0xDD5F38A1L,7L},{8L,1L}},{{(-3L),3L},{(-1L),0xC7AD0416L},{(-1L),0x11EFF711L},{0xC7AF72FFL,(-1L)},{1L,0x9F414069L},{0x67DD1925L,(-3L)},{(-9L),4L},{0x598B75F5L,0x11EFF711L},{0xE0B0FEF9L,0L}},{{(-9L),1L},{(-3L),(-1L)},{(-1L),0L},{8L,0L},{0x9F414069L,0x8740F6EFL},{(-9L),0xC7AD0416L},{0x8DE327F2L,0xBC850E0CL},{1L,4L},{1L,1L}},{{0x423C260BL,1L},{1L,4L},{1L,0xBC850E0CL},{0x8DE327F2L,0xC7AD0416L},{(-9L),0x8740F6EFL},{0x9F414069L,0L},{8L,0L},{(-1L),(-1L)},{(-3L),1L}},{{(-9L),0L},{0xE0B0FEF9L,0x11EFF711L},{0x598B75F5L,4L},{(-9L),(-3L)},{0x67DD1925L,0x9F414069L},{1L,(-1L)},{0xC7AF72FFL,0x11EFF711L},{(-1L),0xC7AD0416L},{(-1L),3L}},{{(-3L),1L},{8L,7L},{0xDD5F38A1L,0L},{(-3L),1L},{(-1L),0x91B9568FL},{0x8DE327F2L,0x14B4C299L},{0x598B75F5L,(-1L)},{4L,1L},{0xD741B982L,0x9F414069L}},{{(-9L),(-9L)},{1L,0x14B4C299L},{(-1L),0L},{1L,0x8740F6EFL},{(-3L),1L},{(-1L),2L},{(-1L),1L},{(-3L),0x8740F6EFL},{1L,0L}},{{(-1L),0x14B4C299L},{1L,(-9L)},{(-9L),0x9F414069L},{0xD741B982L,1L},{4L,(-1L)},{0x598B75F5L,0x14B4C299L},{0x8DE327F2L,0x91B9568FL},{(-1L),1L},{(-3L),0L}},{{0xDD5F38A1L,7L},{8L,1L},{(-3L),3L},{(-1L),0xC7AD0416L},{(-1L),0x11EFF711L},{0xC7AF72FFL,(-1L)},{1L,0x9F414069L},{0x67DD1925L,(-3L)},{(-9L),4L}}};
            int i, j, k;
            l_211++;
            l_220[0]--;
        }
    }
    return g_4[0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_5 g_12 g_27 g_4
 * writes: g_23 g_5 g_27
 */
static int32_t  func_13(uint8_t  p_14, uint64_t  p_15, uint64_t  p_16)
{ /* block id: 8 */
    uint16_t l_22[2][2][2] = {{{0xCAF1L,0xCAF1L},{0xCAF1L,0xCAF1L}},{{0xCAF1L,0xCAF1L},{0xCAF1L,0xCAF1L}}};
    int32_t l_24[2];
    int8_t l_29[6] = {1L,0x57L,0x57L,1L,0x57L,0x57L};
    uint8_t l_32 = 0x9DL;
    int32_t l_36 = (-10L);
    uint16_t l_37 = 65534UL;
    uint32_t l_181 = 3UL;
    const uint32_t l_193 = 4294967295UL;
    uint8_t l_194 = 0xABL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_24[i] = 0x769867F5L;
    for (p_16 = 0; (p_16 > 16); p_16++)
    { /* block id: 11 */
        int32_t l_30[10][9][2] = {{{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L},{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L},{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL}},{{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL},{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L},{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L}},{{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL},{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL},{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L}},{{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L},{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL},{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL}},{{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L},{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L},{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL}},{{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL},{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L},{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L}},{{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL},{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL},{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L}},{{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L},{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL},{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL}},{{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L},{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L},{0x0732BAB2L,0xC2C102D1L},{(-1L),0xE1984BBCL},{7L,0xE1984BBCL}},{{(-1L),0xC2C102D1L},{0x0732BAB2L,0x20E5E2E4L},{0xABE4BCA0L,0xE1984BBCL},{0x0732BAB2L,0xA880E1B4L},{(-1L),0x20E5E2E4L},{7L,0x20E5E2E4L},{(-1L),0xA880E1B4L},{0x0732BAB2L,0xE1984BBCL},{0xABE4BCA0L,0x20E5E2E4L}}};
        int16_t l_35 = 0x3155L;
        int i, j, k;
        g_23 |= ((safe_lshift_func_uint16_t_u_u(l_22[0][0][0], 8)) == 0xF1L);
        l_24[0] = 0xECB2EC6FL;
        for (g_5 = 0; (g_5 <= 48); g_5 = safe_add_func_uint32_t_u_u(g_5, 9))
        { /* block id: 16 */
            int32_t l_28 = 0xEB7BFBC3L;
            int32_t l_31[1][3][8] = {{{0x80411BC3L,0x0BF28884L,0x0BF28884L,0xA2AD41D6L,0x0BF28884L,0x0BF28884L,0xA2AD41D6L,0x0BF28884L},{0xA2AD41D6L,0xA2AD41D6L,0x80411BC3L,0xA2AD41D6L,0xA2AD41D6L,0x80411BC3L,0xA2AD41D6L,0xA2AD41D6L},{0x0BF28884L,0xA2AD41D6L,0x0BF28884L,0x0BF28884L,0xA2AD41D6L,0x0BF28884L,0x0BF28884L,0xA2AD41D6L}}};
            int i, j, k;
            l_32++;
            ++l_37;
            l_24[0] |= (safe_add_func_uint8_t_u_u((l_31[0][1][4] <= 0x33783651A330C13FLL), g_5));
            l_31[0][0][7] &= l_22[0][1][1];
        }
        if ((p_16 > l_30[5][7][0]))
        { /* block id: 22 */
            int64_t l_42 = (-4L);
            int32_t l_43 = 0x9887233EL;
            int16_t l_44 = 3L;
            int32_t l_45 = (-1L);
            int32_t l_46 = 0x2706978BL;
            int32_t l_47 = 0x0FD15061L;
            int32_t l_48 = 0xA18187EAL;
            int32_t l_49[5];
            uint32_t l_50 = 3UL;
            int i;
            for (i = 0; i < 5; i++)
                l_49[i] = 0xAAC0CAA6L;
            l_50++;
        }
        else
        { /* block id: 24 */
            uint8_t l_58[3];
            int i;
            for (i = 0; i < 3; i++)
                l_58[i] = 0x99L;
            g_27[1] = (func_53(l_24[0], l_58[2], p_15, g_12) != l_22[1][1][1]);
            return g_27[4];
        }
    }
    g_27[4] = (safe_rshift_func_uint16_t_u_u(l_24[0], 0));
    for (p_15 = 14; (p_15 != 38); ++p_15)
    { /* block id: 96 */
        uint16_t l_176 = 8UL;
        int32_t l_179 = 0x376282E6L;
        int32_t l_180 = 1L;
        ++l_176;
        l_181--;
        l_180 = (safe_lshift_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((!(p_16 || l_29[4])) < 0x43L), g_27[3])), g_5)), 0x393522EF38C47E81LL)), l_193));
        g_27[3] = (((0x7C02C535L >= 1UL) <= g_27[1]) , l_179);
    }
    l_194++;
    return g_27[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_27 g_4 g_5 g_23
 * writes: g_27 g_23 g_5
 */
static uint32_t  func_53(uint8_t  p_54, uint32_t  p_55, int16_t  p_56, uint8_t  p_57)
{ /* block id: 25 */
    uint32_t l_67 = 0x5BDF5850L;
    int32_t l_95[7][1][5] = {{{0x3FB47EBAL,0xB8B245C3L,0xB8B245C3L,0x3FB47EBAL,0xB8B245C3L}},{{0x3FB47EBAL,0x3FB47EBAL,0x3C1E06D6L,0x3FB47EBAL,0x3FB47EBAL}},{{0xB8B245C3L,0x3FB47EBAL,0xB8B245C3L,0xB8B245C3L,0x3FB47EBAL}},{{0x3FB47EBAL,0xB8B245C3L,0xB8B245C3L,0x3FB47EBAL,0xB8B245C3L}},{{0x3FB47EBAL,0x3FB47EBAL,0x3C1E06D6L,0x3FB47EBAL,0x3FB47EBAL}},{{0xB8B245C3L,0x3FB47EBAL,0xB8B245C3L,0xB8B245C3L,0x3FB47EBAL}},{{0x3FB47EBAL,0xB8B245C3L,0xB8B245C3L,0x3FB47EBAL,0xB8B245C3L}}};
    uint32_t l_114 = 0xC145D4FDL;
    uint8_t l_117 = 0xF0L;
    int32_t l_121 = 0x5FCFD512L;
    int64_t l_129 = (-1L);
    int64_t l_134 = 0xBBF4A9A9FA4E0B66LL;
    uint16_t l_135 = 0x7278L;
    uint64_t l_161 = 0x7951488D53BAC825LL;
    int i, j, k;
    if ((65535UL ^ 65535UL))
    { /* block id: 26 */
        volatile int16_t l_59 = 0xEA10L;/* VOLATILE GLOBAL l_59 */
        int32_t l_66 = 1L;
        l_59 = g_12;
        if ((((safe_rshift_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(g_27[1], l_66)), 1)) || 0xD9L) > l_67), 2)) != g_4[0][1]) >= p_57))
        { /* block id: 28 */
            l_95[0][0][4] = (safe_mod_func_uint8_t_u_u(func_70((safe_sub_func_uint32_t_u_u(func_74(p_55, p_56, l_66, g_12), p_55))), l_67));
            l_66 |= g_27[1];
            g_27[6] = ((safe_lshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((((((l_67 >= g_5) >= p_56) > g_5) != g_4[0][6]) <= g_27[1]), 5)), g_4[0][4])) > 1UL);
        }
        else
        { /* block id: 40 */
            uint64_t l_100 = 0x7BB6F3936D73F188LL;
            int32_t l_103 = 0L;
            l_95[6][0][3] = (l_100 , l_100);
            l_103 |= (safe_div_func_uint64_t_u_u(((p_57 != 4294967293UL) , l_59), 0x1B972044F22EBF56LL));
        }
        l_95[0][0][4] |= ((0x27731F37L >= 0x4A51A485L) > l_67);
    }
    else
    { /* block id: 45 */
        g_27[1] &= (-10L);
    }
lbl_115:
    l_95[0][0][4] = (l_67 < g_27[2]);
    if (((p_57 && g_27[1]) ^ p_56))
    { /* block id: 49 */
        int64_t l_109 = 0L;
        l_95[4][0][4] |= 1L;
        l_95[4][0][4] &= 0x8D5A12BEL;
        g_27[1] = ((safe_sub_func_uint8_t_u_u((+(((safe_add_func_uint32_t_u_u(l_67, 0x79B0709CL)) && 0UL) , p_54)), l_109)) < g_27[1]);
        for (l_67 = 16; (l_67 == 52); l_67++)
        { /* block id: 55 */
            uint64_t l_116 = 18446744073709551610UL;
            g_27[1] &= (safe_rshift_func_uint8_t_u_u(l_114, 6));
            if (l_114)
                goto lbl_115;
            l_116 ^= 0xE6589940L;
            return g_27[4];
        }
    }
    else
    { /* block id: 61 */
        int64_t l_118 = (-10L);
        int64_t l_122 = 0x83C1FD706CFD441ELL;
        int32_t l_130 = 0L;
        int32_t l_132[5][2] = {{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}};
        int i, j;
        l_118 = (l_67 != l_117);
        g_27[1] = ((((safe_mul_func_uint16_t_u_u((((p_57 , g_4[0][1]) || g_27[1]) == 0x6AL), g_23)) ^ l_118) , (-5L)) , g_4[1][6]);
        if ((((((l_121 || l_122) > g_23) > l_122) < p_55) != 0x1E81E1FAL))
        { /* block id: 64 */
            int16_t l_131 = 9L;
            int32_t l_133[7][7][2] = {{{0x3CFAA447L,0xCEEBA6CAL},{0xCEEBA6CAL,0xD35E6B1BL},{0x120CF9BFL,0x3CFAA447L},{0xD863CB28L,0x141F5377L},{1L,0x141F5377L},{0xD863CB28L,0x3CFAA447L},{0x120CF9BFL,0xD35E6B1BL}},{{0xCEEBA6CAL,0xCEEBA6CAL},{0x3CFAA447L,1L},{0L,0x0C0C6297L},{(-1L),0L},{1L,(-1L)},{(-2L),0xD863CB28L},{(-2L),(-1L)}},{{1L,0L},{(-1L),0x0C0C6297L},{0L,1L},{0x3CFAA447L,0xCEEBA6CAL},{0xCEEBA6CAL,0xD35E6B1BL},{0x120CF9BFL,0x3CFAA447L},{0xD863CB28L,0x141F5377L}},{{1L,0x141F5377L},{0xD863CB28L,0x3CFAA447L},{0x120CF9BFL,0xD35E6B1BL},{0xCEEBA6CAL,0xCEEBA6CAL},{0x3CFAA447L,1L},{0L,0x0C0C6297L},{(-1L),0L}},{{1L,(-1L)},{(-2L),0xD863CB28L},{(-2L),(-1L)},{1L,0L},{(-1L),0x0C0C6297L},{0L,1L},{0x3CFAA447L,0xCEEBA6CAL}},{{0xCEEBA6CAL,0xD35E6B1BL},{0x120CF9BFL,0x3CFAA447L},{0xD863CB28L,0x141F5377L},{1L,0x141F5377L},{0xD863CB28L,0x3CFAA447L},{0x120CF9BFL,0xD35E6B1BL},{0xCEEBA6CAL,0xCEEBA6CAL}},{{0x3CFAA447L,1L},{0L,0x0C0C6297L},{(-1L),0L},{1L,(-1L)},{(-2L),0xD863CB28L},{(-2L),(-1L)},{1L,0L}}};
            int i, j, k;
            g_27[3] &= (safe_mod_func_uint8_t_u_u(((((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(g_23, l_95[3][0][0])), g_4[1][6])) > l_129) < p_57) , l_95[3][0][0]), 1UL));
            l_135--;
        }
        else
        { /* block id: 67 */
            g_27[6] = (safe_rshift_func_uint8_t_u_u(((18446744073709551608UL == 0xC161824737F3D353LL) >= l_135), 0));
            g_27[6] = (safe_lshift_func_uint16_t_u_u(l_130, 9));
            l_95[3][0][4] = (safe_lshift_func_uint16_t_u_u(l_135, g_27[0]));
        }
        for (g_23 = 0; (g_23 != 60); g_23++)
        { /* block id: 74 */
            const int32_t l_148 = (-1L);
            g_27[6] = (((((safe_mod_func_uint8_t_u_u(((((l_129 == p_55) < 9UL) && 0x593233A8L) >= l_95[3][0][0]), l_95[0][0][4])) != l_135) != l_148) > p_54) == l_95[0][0][4]);
        }
    }
    for (g_5 = 0; (g_5 == 54); g_5++)
    { /* block id: 80 */
        uint8_t l_162 = 3UL;
        for (l_117 = 0; (l_117 < 41); l_117 = safe_add_func_uint8_t_u_u(l_117, 4))
        { /* block id: 83 */
            g_27[4] = (safe_lshift_func_uint16_t_u_u((((safe_div_func_uint64_t_u_u(((safe_div_func_uint8_t_u_u(((((safe_div_func_uint16_t_u_u(65535UL, p_56)) >= 255UL) > 0xFD9DDA32BF4E470BLL) , l_161), l_162)) && p_54), p_54)) , 0xF6267926L) >= l_95[2][0][4]), 9));
            l_95[0][0][4] = (safe_add_func_uint64_t_u_u((safe_div_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((+(4294967291UL > 2UL)) , 65535UL), g_27[3])), p_55)) && 0xDB39EC26L), p_57)), 0xBCB4272C5433B60FLL));
        }
    }
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_70(int32_t  p_71)
{ /* block id: 34 */
    int64_t l_93 = 0x13F98BF106CF207FLL;
    int32_t l_94 = 0L;
    l_94 ^= (l_93 ^ l_93);
    return p_71;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_4
 * writes: g_27
 */
static uint32_t  func_74(uint64_t  p_75, uint16_t  p_76, uint64_t  p_77, int8_t  p_78)
{ /* block id: 29 */
    uint64_t l_79 = 0x46C13A8A9104C899LL;
    int32_t l_92 = 0x2EC59D27L;
    l_79--;
    g_27[3] = (((((+((+((safe_sub_func_uint8_t_u_u((((safe_sub_func_uint8_t_u_u((((l_79 || 1UL) , 18446744073709551615UL) > p_78), g_12)) < l_79) || 0x958FL), l_79)) > 0x0BCD743813938A05LL)) && g_4[0][1])) , 5UL) <= p_76) || 7UL) <= 0UL);
    l_92 = (safe_sub_func_uint32_t_u_u((((safe_div_func_uint64_t_u_u((l_79 || 0x237EL), 0xE8CEC1B3EE271D16LL)) , l_79) < p_78), p_77));
    return p_78;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_4[i][j], "g_4[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_27[i], "g_27[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_201, "g_201", print_hash_value);
    transparent_crc(g_217, "g_217", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 73
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 75
   depth: 2, occurrence: 18
   depth: 3, occurrence: 6
   depth: 4, occurrence: 3
   depth: 6, occurrence: 6
   depth: 7, occurrence: 3
   depth: 8, occurrence: 4
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 118
XXX times a non-volatile is write: 40
XXX times a volatile is read: 21
XXX    times read thru a pointer: 0
XXX times a volatile is write: 15
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 198
XXX percentage of non-volatile access: 81.4

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 72
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 25
   depth: 2, occurrence: 27

XXX percentage a fresh-made variable is used: 13.2
XXX percentage an existing variable is used: 86.8
********************* end of statistics **********************/

