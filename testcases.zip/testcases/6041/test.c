/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15568148743189118614
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 5L;
static uint8_t g_6 = 255UL;
static uint8_t g_28[2][4][5] = {{{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L},{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L},{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L},{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L}},{{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L},{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L},{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L},{0xB9L,0xB9L,0xB9L,0xB9L,0xB9L}}};
static volatile uint64_t g_35 = 18446744073709551615UL;/* VOLATILE GLOBAL g_35 */
static int32_t g_45[7][10] = {{0x2349124CL,0x2349124CL,(-1L),0x2349124CL,0x2349124CL,(-1L),5L,5L,0x2349124CL,5L},{5L,(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L),5L},{(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L)},{5L,5L,0x2349124CL,5L,5L,0x2349124CL,5L,5L,0x2349124CL,5L},{5L,(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L),5L},{(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L)},{5L,5L,0x2349124CL,5L,5L,0x2349124CL,5L,5L,0x2349124CL,5L}};
static uint32_t g_46[4][9] = {{3UL,4294967287UL,0x57E8F534L,4294967289UL,0x57E8F534L,4294967287UL,3UL,1UL,0x2EE8B720L},{0x125DBF60L,0x2EE8B720L,3UL,0x4ADCF861L,1UL,0x4ADCF861L,3UL,0x2EE8B720L,0x125DBF60L},{4294967287UL,0x4ADCF861L,0x125DBF60L,1UL,0x48FE2D58L,0x57E8F534L,0x48FE2D58L,1UL,0x125DBF60L},{0x48FE2D58L,0x48FE2D58L,4294967287UL,0UL,0x2EE8B720L,4294967289UL,0x125DBF60L,4294967289UL,0x2EE8B720L}};
static volatile int8_t g_86 = 0xADL;/* VOLATILE GLOBAL g_86 */
static volatile uint32_t g_90 = 18446744073709551615UL;/* VOLATILE GLOBAL g_90 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint8_t  func_7(int8_t  p_8, int32_t  p_9, const uint32_t  p_10, const uint32_t  p_11);
static int32_t  func_22(uint8_t  p_23);
static uint8_t  func_59(int16_t  p_60, uint8_t  p_61, int8_t  p_62, int16_t  p_63, int64_t  p_64);
static uint16_t  func_102(const uint32_t  p_103, uint16_t  p_104);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_35 g_28 g_46 g_45 g_90 g_86
 * writes: g_2 g_6 g_28 g_35 g_46 g_90
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_12 = 0x2E1DFE00L;
    int8_t l_13[6][6][1] = {{{(-1L)},{0x14L},{0x6BL},{0x33L},{0x6BL},{0x14L}},{{(-1L)},{0x33L},{(-1L)},{0x14L},{0x6BL},{0x33L}},{{0x6BL},{0x14L},{(-1L)},{0x33L},{(-1L)},{0x14L}},{{0x6BL},{0x33L},{0x6BL},{0x14L},{(-1L)},{0x33L}},{{(-1L)},{0x14L},{0x6BL},{0x33L},{0x6BL},{0x14L}},{{(-1L)},{0x33L},{(-1L)},{0x14L},{0x6BL},{0x33L}}};
    int32_t l_56 = 0L;
    int32_t l_65 = 0xA5CD23E8L;
    uint8_t l_66 = 0x26L;
    int i, j, k;
    for (g_2 = 0; (g_2 != (-28)); g_2--)
    { /* block id: 3 */
        const int32_t l_5 = 0x9C5A654FL;
        g_6 = (l_5 == l_5);
    }
    l_56 = (func_7(l_12, l_13[5][5][0], l_12, l_12) || 255UL);
    l_12 |= (safe_mod_func_uint8_t_u_u(func_59(g_45[2][7], l_65, l_56, l_66, l_13[2][3][0]), l_56));
    g_2 = l_66;
    return l_13[2][0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_35 g_28 g_46 g_45
 * writes: g_2 g_28 g_35 g_46
 */
static uint8_t  func_7(int8_t  p_8, int32_t  p_9, const uint32_t  p_10, const uint32_t  p_11)
{ /* block id: 6 */
    uint32_t l_14 = 0UL;
    int32_t l_15 = 0x068CD546L;
    int32_t l_49 = 6L;
    l_15 = (((l_14 < l_14) || 2UL) >= 0x9297L);
    l_49 = ((safe_sub_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((((safe_div_func_uint8_t_u_u((func_22(p_10) , l_49), 0x5AL)) < l_49) || p_10), p_11)), g_45[6][4])) , (-1L));
    l_49 = (safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(func_22(l_49), 1UL)), 2)), 3));
    return g_28[1][3][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_35 g_28 g_46
 * writes: g_2 g_28 g_35 g_46
 */
static int32_t  func_22(uint8_t  p_23)
{ /* block id: 8 */
    uint32_t l_32 = 0x6EA3D881L;
    int32_t l_33 = (-2L);
    int32_t l_34 = 1L;
    int32_t l_42 = 0x5708880DL;
    int32_t l_43 = 0x83781CDFL;
    int32_t l_44 = 0x387C7A50L;
    for (g_2 = 0; (g_2 <= (-17)); g_2 = safe_sub_func_uint32_t_u_u(g_2, 9))
    { /* block id: 11 */
        uint16_t l_29 = 65528UL;
        g_28[0][1][3] = ((safe_mul_func_uint16_t_u_u(0UL, g_6)) , g_6);
        --l_29;
        l_33 |= l_32;
        g_35++;
    }
    g_2 &= g_28[0][1][0];
    g_2 = (safe_rshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u((((l_34 , g_6) , 1UL) <= g_6), 0)) ^ p_23), 1));
    g_46[0][8]++;
    return l_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_46 g_28 g_90 g_86 g_2 g_6
 * writes: g_90 g_2
 */
static uint8_t  func_59(int16_t  p_60, uint8_t  p_61, int8_t  p_62, int16_t  p_63, int64_t  p_64)
{ /* block id: 25 */
    uint8_t l_69[6][6][6] = {{{0x3DL,0x60L,246UL,249UL,0x80L,0xA2L},{0x44L,249UL,250UL,250UL,249UL,0x44L},{250UL,249UL,0x44L,0x60L,0x80L,246UL},{246UL,0x60L,0x3DL,0x60L,246UL,249UL},{246UL,250UL,0x60L,0x60L,0UL,0UL},{250UL,0x80L,0x80L,250UL,0x3DL,0UL}},{{0x44L,0UL,0x60L,249UL,0x60L,249UL},{0x3DL,0x38L,0x3DL,0xA2L,0x60L,246UL},{0x60L,0UL,0x44L,0x3DL,0x3DL,0x44L},{0x80L,0xA2L,0x80L,249UL,246UL,0x60L},{0x38L,0x80L,0x44L,0x60L,0x44L,0x80L},{249UL,0x38L,0x44L,250UL,0xA2L,0x60L}},{{0x3DL,250UL,0x80L,0x80L,250UL,0x3DL},{0x80L,250UL,0x3DL,0UL,0xA2L,0x44L},{0x44L,0x38L,249UL,0x38L,0x44L,250UL},{0x44L,0x80L,0x38L,0UL,246UL,246UL},{0x80L,0xA2L,0xA2L,0x80L,249UL,246UL},{0x3DL,246UL,0x38L,250UL,0UL,250UL}},{{249UL,0x60L,249UL,0x60L,0UL,0x44L},{0x38L,246UL,0x3DL,249UL,249UL,0x3DL},{0xA2L,0xA2L,0x80L,249UL,246UL,0x60L},{0x38L,0x80L,0x44L,0x60L,0x44L,0x80L},{249UL,0x38L,0x44L,250UL,0xA2L,0x60L},{0x3DL,250UL,0x80L,0x80L,250UL,0x3DL}},{{0x80L,250UL,0x3DL,0UL,0xA2L,0x44L},{0x44L,0x38L,249UL,0x38L,0x44L,250UL},{0x44L,0x80L,0x38L,0UL,246UL,246UL},{0x80L,0xA2L,0xA2L,0x80L,249UL,246UL},{0x3DL,246UL,0x38L,250UL,0UL,250UL},{249UL,0x60L,249UL,0x60L,0UL,0x44L}},{{0x38L,246UL,0x3DL,249UL,249UL,0x3DL},{0xA2L,0xA2L,0x80L,249UL,246UL,0x60L},{0x38L,0x80L,0x44L,0x60L,0x44L,0x80L},{249UL,0x38L,0x44L,250UL,0xA2L,0x60L},{0x3DL,250UL,0x80L,0x80L,250UL,0x3DL},{0x80L,250UL,0x3DL,0UL,0xA2L,0x44L}}};
    int32_t l_70 = 0xA80AA4B6L;
    uint32_t l_74 = 9UL;
    int32_t l_83 = 0x2C279A1AL;
    int32_t l_87 = 0x957B0931L;
    int32_t l_88 = (-5L);
    int32_t l_89 = (-3L);
    uint16_t l_101[2];
    int16_t l_130 = 0xA0CFL;
    uint32_t l_131 = 0x4C26F4C7L;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_101[i] = 1UL;
    if (p_62)
    { /* block id: 26 */
        int8_t l_73 = (-3L);
        int32_t l_75 = (-10L);
        l_70 &= ((safe_div_func_uint16_t_u_u((g_45[1][5] , g_45[5][7]), g_46[0][7])) < l_69[0][4][0]);
        l_74 = ((((safe_mul_func_uint16_t_u_u(0x28F6L, 65535UL)) , p_61) >= l_73) > g_28[1][1][3]);
        l_75 = ((p_61 == 0x89L) < g_28[0][0][1]);
    }
    else
    { /* block id: 30 */
        int32_t l_80 = 0xC26FF553L;
        int32_t l_81 = 1L;
        int8_t l_82 = (-1L);
        int32_t l_84 = 9L;
        int32_t l_85[5];
        int i;
        for (i = 0; i < 5; i++)
            l_85[i] = 0x1782E4D7L;
        l_81 &= (safe_rshift_func_uint16_t_u_u(((safe_add_func_uint64_t_u_u(l_80, l_69[5][3][4])) >= 0x3CAE23F1199D3281LL), p_62));
        ++g_90;
        if ((safe_rshift_func_uint8_t_u_u((((0xB0L == l_83) == 18446744073709551606UL) <= p_61), 5)))
        { /* block id: 33 */
            uint64_t l_95 = 4UL;
            l_95 = l_74;
        }
        else
        { /* block id: 35 */
            uint64_t l_96 = 0x355B561D8FC8FA0DLL;
            l_96++;
            l_101[1] = (safe_rshift_func_uint8_t_u_u(g_86, 4));
        }
        if ((func_102(g_45[1][5], p_62) != p_61))
        { /* block id: 46 */
            int16_t l_120 = (-4L);
            l_120 &= 8L;
            g_2 = (safe_div_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u((((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(0x0C7048B0L, p_63)), 2)) == g_46[0][8]) , l_83), g_28[1][3][3])), g_45[2][4]));
            l_130 ^= (!0xDF1EF1A9L);
            return g_90;
        }
        else
        { /* block id: 51 */
            g_2 |= (0UL ^ 0x5B336EB9B4FE2E88LL);
            l_89 = p_62;
            l_85[4] = 0x9FAD1A43L;
            ++l_131;
        }
    }
    return p_61;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_86 g_6
 * writes: g_2
 */
static uint16_t  func_102(const uint32_t  p_103, uint16_t  p_104)
{ /* block id: 39 */
    uint8_t l_119 = 0x23L;
    for (g_2 = 0; (g_2 >= (-2)); g_2 = safe_sub_func_uint16_t_u_u(g_2, 1))
    { /* block id: 42 */
        int8_t l_118 = 7L;
        l_119 |= ((safe_sub_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u((!l_118), 0x9CEEL)) <= p_103), 4294967288UL)), 6)), g_86)), g_6)) >= p_103);
    }
    return p_103;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_28[i][j][k], "g_28[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_35, "g_35", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_45[i][j], "g_45[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_46[i][j], "g_46[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 45
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 51
   depth: 2, occurrence: 6
   depth: 3, occurrence: 2
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 67
XXX times a non-volatile is write: 31
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 31
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 42
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 13
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 37.2
XXX percentage an existing variable is used: 62.8
********************* end of statistics **********************/

