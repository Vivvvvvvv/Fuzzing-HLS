/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14246969308658088067
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   volatile int64_t  f1;
   int32_t  f2;
   uint64_t  f3;
   uint32_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_15[7][8][4] = {{{0x3895L,1UL,0x1CB2L,9UL},{65527UL,0xC694L,1UL,65535UL},{0x1F09L,3UL,0x1F09L,0x7FC0L},{65533UL,0UL,0x7FC0L,3UL},{0xA969L,1UL,4UL,0UL},{0UL,2UL,4UL,9UL},{0xA969L,65527UL,0x7FC0L,4UL},{65533UL,1UL,0x1F09L,0x3895L}},{{0x1F09L,0x3895L,1UL,0x49ECL},{65527UL,1UL,0x1CB2L,0x7FC0L},{0x3895L,9UL,0UL,0UL},{0xA969L,0xA969L,0x7968L,2UL},{0UL,65527UL,0xE4E9L,0x1F09L},{0x9BEAL,0x49ECL,65528UL,0xE4E9L},{0xBF68L,0x49ECL,9UL,0x1F09L},{0x49ECL,65527UL,0x41A6L,2UL}},{{0UL,0x61BFL,0x49ECL,0x2083L},{0x1CB2L,0x3B2CL,4UL,65528UL},{0x9BEAL,65528UL,0x7968L,0UL},{0x7FC0L,0x1F09L,3UL,0x1F09L},{65528UL,0x5231L,0x2083L,3UL},{0xBF68L,0UL,0x49ECL,1UL},{65535UL,65527UL,0x9BEAL,3UL},{65535UL,65528UL,0x49ECL,4UL}},{{0xBF68L,3UL,0x2083L,65528UL},{65528UL,0xE229L,3UL,2UL},{0x7FC0L,0xBF68L,0x7968L,1UL},{0x9BEAL,0x5231L,4UL,0x7968L},{0x1CB2L,0x49ECL,0x49ECL,0x1CB2L},{0UL,0x1F09L,0x41A6L,3UL},{0x49ECL,0xE229L,9UL,0x2083L},{0xBF68L,0x7FC0L,65528UL,0x2083L}},{{0x9BEAL,0xE229L,0xE4E9L,3UL},{0UL,0x1F09L,0x7968L,0x1CB2L},{0x61BFL,0x49ECL,0x2083L,0x7968L},{0x1F09L,0x5231L,9UL,1UL},{0UL,0xBF68L,65528UL,2UL},{65535UL,0xE229L,65535UL,65528UL},{0x1CB2L,3UL,65528UL,4UL},{0x61BFL,65528UL,3UL,3UL}},{{3UL,65527UL,3UL,1UL},{0x61BFL,0UL,65528UL,3UL},{0x1CB2L,0x5231L,65535UL,0x1F09L},{65535UL,0x1F09L,65528UL,0UL},{0UL,65528UL,9UL,65528UL},{0x1F09L,0x3B2CL,0x2083L,0x2083L},{0x61BFL,0x61BFL,0x7968L,2UL},{0UL,65527UL,0xE4E9L,0x1F09L}},{{0x9BEAL,0x49ECL,65528UL,0xE4E9L},{0xBF68L,0x49ECL,9UL,0x1F09L},{0x49ECL,65527UL,0x41A6L,2UL},{0UL,0x61BFL,0x49ECL,0x2083L},{0x1CB2L,0x3B2CL,4UL,65528UL},{0x9BEAL,65528UL,0x7968L,0UL},{0x7FC0L,0x1F09L,3UL,0x1F09L},{65528UL,0x5231L,0x2083L,3UL}}};
static int32_t g_20 = 0xF1EB7E59L;
static volatile int32_t g_38[5] = {0L,0L,0L,0L,0L};
static int16_t g_44 = 0L;
static struct S0 g_89 = {0UL,0x239CA810D8942C1FLL,0xD07FB140L,18446744073709551615UL,0x619A7386L};/* VOLATILE GLOBAL g_89 */
static uint32_t g_142 = 0x74B9946CL;
static struct S0 g_193 = {0xF89097CFL,0L,1L,0x0B6291A48057C8D3LL,4294967295UL};/* VOLATILE GLOBAL g_193 */
static volatile struct S0 g_198 = {4294967294UL,6L,-1L,0x1CA476E1AB4B5E31LL,4294967295UL};/* VOLATILE GLOBAL g_198 */
static volatile struct S0 g_199[6] = {{0x56FB2AC5L,0L,0xDC9C5CF6L,0x8D655E74B05A58BFLL,0x2A532686L},{0x56FB2AC5L,0L,0xDC9C5CF6L,0x8D655E74B05A58BFLL,0x2A532686L},{0x56FB2AC5L,0L,0xDC9C5CF6L,0x8D655E74B05A58BFLL,0x2A532686L},{0x56FB2AC5L,0L,0xDC9C5CF6L,0x8D655E74B05A58BFLL,0x2A532686L},{0x56FB2AC5L,0L,0xDC9C5CF6L,0x8D655E74B05A58BFLL,0x2A532686L},{0x56FB2AC5L,0L,0xDC9C5CF6L,0x8D655E74B05A58BFLL,0x2A532686L}};
static uint16_t g_203 = 0x9774L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_26(uint64_t  p_27, uint32_t  p_28, int32_t  p_29, int16_t  p_30, uint64_t  p_31);
static int32_t  func_45(const int64_t  p_46, int32_t  p_47, uint8_t  p_48, uint32_t  p_49);
static uint8_t  func_52(const int32_t  p_53, const int32_t  p_54, uint32_t  p_55, const uint8_t  p_56);
static int32_t  func_78(int8_t  p_79, uint8_t  p_80, uint16_t  p_81);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_20 g_38 g_44 g_89 g_142 g_193 g_198 g_199.f3 g_203
 * writes: g_20 g_44 g_38 g_142 g_199 g_203 g_89.f2
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_16 = 0x08AFL;
    int32_t l_17 = (-1L);
    l_17 |= (safe_add_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((!(safe_add_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s(((safe_div_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u(0UL, 0UL)), g_15[2][3][3])) , g_15[4][0][1]), l_16)), l_16))), g_15[5][5][1])), l_16));
    l_17 = 0L;
    if (((safe_add_func_uint32_t_u_u(6UL, g_15[5][6][1])) & 0x1857497FL))
    { /* block id: 3 */
        uint64_t l_25 = 18446744073709551615UL;
        g_20 = (g_15[3][2][3] || l_16);
        for (l_16 = 0; (l_16 != 43); l_16 = safe_add_func_uint64_t_u_u(l_16, 1))
        { /* block id: 7 */
            g_20 = (safe_rshift_func_uint16_t_u_s(l_16, l_25));
            if (g_15[2][3][3])
                continue;
            return g_15[2][3][3];
        }
        g_44 &= func_26(g_15[0][1][3], l_17, g_15[0][6][2], l_25, l_17);
        g_203 ^= func_45(l_17, l_17, g_15[5][1][2], g_38[0]);
    }
    else
    { /* block id: 119 */
        const uint64_t l_206[3][1][8] = {{{0x3B51E3D7954E52F0LL,0x55A403EEF275FD97LL,0x67DC3E7CD7632F3CLL,18446744073709551612UL,0x527E9D26971D6334LL,9UL,0x3B51E3D7954E52F0LL,0x3B51E3D7954E52F0LL}},{{0x3B51E3D7954E52F0LL,0x915BE6F43F8A5E6ALL,1UL,1UL,0x915BE6F43F8A5E6ALL,0x3B51E3D7954E52F0LL,0x527E9D26971D6334LL,0x65F41A635642BD77LL}},{{0x3B51E3D7954E52F0LL,1UL,0x55A403EEF275FD97LL,0x915BE6F43F8A5E6ALL,0x527E9D26971D6334LL,0x915BE6F43F8A5E6ALL,0x55A403EEF275FD97LL,1UL}}};
        int i, j, k;
        for (g_89.f2 = (-25); (g_89.f2 >= 18); ++g_89.f2)
        { /* block id: 122 */
            int64_t l_207 = (-4L);
            l_207 = l_206[0][0][3];
            g_38[4] = l_207;
        }
        return g_193.f1;
    }
    return l_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_20 g_38
 * writes:
 */
static int32_t  func_26(uint64_t  p_27, uint32_t  p_28, int32_t  p_29, int16_t  p_30, uint64_t  p_31)
{ /* block id: 12 */
    int16_t l_36[5];
    int32_t l_37[10];
    int i;
    for (i = 0; i < 5; i++)
        l_36[i] = (-7L);
    for (i = 0; i < 10; i++)
        l_37[i] = 0xA324C99FL;
    for (p_30 = 0; (p_30 > (-13)); p_30 = safe_sub_func_uint32_t_u_u(p_30, 1))
    { /* block id: 15 */
        int64_t l_34[5][9] = {{0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L},{6L,6L,6L,6L,6L,6L,6L,6L,6L},{0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L},{6L,6L,6L,6L,6L,6L,6L,6L,6L},{0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L,0x57638FF43993911ELL,0L}};
        int32_t l_35[2][1][6] = {{{0x83D4F39AL,0x83D4F39AL,(-1L),0x83D4F39AL,0x83D4F39AL,(-1L)}},{{0x83D4F39AL,0x83D4F39AL,(-1L),0x83D4F39AL,0x83D4F39AL,(-1L)}}};
        int i, j, k;
        for (p_31 = 0; (p_31 <= 3); p_31 += 1)
        { /* block id: 18 */
            uint8_t l_39[9] = {0x62L,0x62L,0x62L,0x62L,0x62L,0x62L,0x62L,0x62L,0x62L};
            int i;
            --l_39[3];
            return g_15[2][3][3];
        }
        l_37[0] = ((g_20 , l_34[2][3]) == p_30);
        l_35[1][0][0] |= (safe_mod_func_int16_t_s_s(p_31, p_31));
    }
    return g_38[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_38 g_15 g_44 g_89 g_142 g_193 g_198 g_199.f3
 * writes: g_38 g_20 g_142 g_199
 */
static int32_t  func_45(const int64_t  p_46, int32_t  p_47, uint8_t  p_48, uint32_t  p_49)
{ /* block id: 27 */
    const int32_t l_57 = 0x3D8FFFCBL;
    uint8_t l_185 = 1UL;
    int32_t l_186 = 1L;
    uint32_t l_200 = 0x21851E41L;
    if (((safe_sub_func_uint8_t_u_u(func_52((p_48 , l_57), p_49, g_20, p_49), l_57)) != (-1L)))
    { /* block id: 100 */
        uint32_t l_197[9][6][4] = {{{4294967294UL,0x576AB1B5L,1UL,0UL},{0x2670A277L,1UL,0x05B7ECD1L,0UL},{0x0B306029L,0x576AB1B5L,0x0B306029L,0x05B7ECD1L},{4294967295UL,4294967294UL,0x525FB008L,4294967295UL},{0x2670A277L,0x05B7ECD1L,0xD27EE824L,4294967294UL},{0x05B7ECD1L,0x576AB1B5L,0xD27EE824L,0xD27EE824L}},{{0x2670A277L,0x2670A277L,0x525FB008L,0UL},{4294967295UL,0x66F5C53AL,0x0B306029L,4294967294UL},{0x0B306029L,4294967294UL,0x05B7ECD1L,0x0B306029L},{0x2670A277L,4294967294UL,1UL,4294967294UL},{4294967294UL,0x66F5C53AL,0xD27EE824L,0UL},{1UL,0x2670A277L,0x05B7ECD1L,0xD27EE824L}},{{4294967295UL,0x576AB1B5L,7UL,4294967294UL},{4294967295UL,0x05B7ECD1L,0x05B7ECD1L,4294967295UL},{1UL,4294967294UL,0xD27EE824L,0x05B7ECD1L},{4294967294UL,0x576AB1B5L,1UL,0UL},{0x2670A277L,1UL,0x05B7ECD1L,0UL},{0x0B306029L,0x576AB1B5L,0x0B306029L,0x05B7ECD1L}},{{4294967295UL,4294967294UL,0x525FB008L,4294967295UL},{0x2670A277L,0x05B7ECD1L,0xD27EE824L,4294967294UL},{0x05B7ECD1L,0x576AB1B5L,0xD27EE824L,0xD27EE824L},{0x2670A277L,0x2670A277L,0x525FB008L,0UL},{4294967295UL,0x66F5C53AL,0x0B306029L,4294967294UL},{0x0B306029L,4294967294UL,0x05B7ECD1L,0x0B306029L}},{{0x2670A277L,4294967294UL,1UL,4294967294UL},{4294967294UL,0x66F5C53AL,0x63770DE9L,0x66F5C53AL},{0x525FB008L,0x05B7ECD1L,7UL,0x63770DE9L},{0xD27EE824L,1UL,0UL,0x0B306029L},{0xD27EE824L,7UL,7UL,0xD27EE824L},{0x525FB008L,0x0B306029L,0x63770DE9L,7UL}},{{0x0B306029L,1UL,0x576AB1B5L,0x66F5C53AL},{0x05B7ECD1L,0x525FB008L,7UL,0x66F5C53AL},{1UL,1UL,1UL,7UL},{0xD27EE824L,0x0B306029L,4294967295UL,0xD27EE824L},{0x05B7ECD1L,7UL,0x63770DE9L,0x0B306029L},{7UL,1UL,0x63770DE9L,0x63770DE9L}},{{0x05B7ECD1L,0x05B7ECD1L,4294967295UL,0x66F5C53AL},{0xD27EE824L,0x73A90B82L,1UL,0x0B306029L},{1UL,0x0B306029L,7UL,1UL},{0x05B7ECD1L,0x0B306029L,0x576AB1B5L,0x0B306029L},{0x0B306029L,0x73A90B82L,0x63770DE9L,0x66F5C53AL},{0x525FB008L,0x05B7ECD1L,7UL,0x63770DE9L}},{{0xD27EE824L,1UL,0UL,0x0B306029L},{0xD27EE824L,7UL,7UL,0xD27EE824L},{0x525FB008L,0x0B306029L,0x63770DE9L,7UL},{0x0B306029L,1UL,0x576AB1B5L,0x66F5C53AL},{0x05B7ECD1L,0x525FB008L,7UL,0x66F5C53AL},{1UL,1UL,1UL,7UL}},{{0xD27EE824L,0x0B306029L,4294967295UL,0xD27EE824L},{0x05B7ECD1L,7UL,0x63770DE9L,0x0B306029L},{7UL,1UL,0x63770DE9L,0x63770DE9L},{0x05B7ECD1L,0x05B7ECD1L,4294967295UL,0x66F5C53AL},{0xD27EE824L,0x73A90B82L,1UL,0x0B306029L},{1UL,0x0B306029L,7UL,1UL}}};
        int i, j, k;
        if (((safe_mod_func_int32_t_s_s((l_185 != 7L), p_47)) | 0L))
        { /* block id: 101 */
            l_186 = (p_48 && g_20);
        }
        else
        { /* block id: 103 */
            l_186 = ((safe_sub_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((safe_add_func_int64_t_s_s(((g_193 , l_57) || g_193.f4), l_186)), 0xB12DL)), p_46)) , p_47);
        }
        if (g_38[4])
        { /* block id: 106 */
            int32_t l_196 = (-9L);
            l_186 = (safe_mod_func_int32_t_s_s(g_142, p_48));
            l_196 = l_186;
        }
        else
        { /* block id: 109 */
            g_38[2] = ((l_197[8][1][0] >= 0L) <= p_46);
            g_199[0] = g_198;
            l_200 = p_48;
        }
    }
    else
    { /* block id: 114 */
        g_38[1] = (safe_mod_func_int16_t_s_s((p_46 , g_199[0].f3), 0x8087L));
    }
    return l_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_15 g_44 g_20 g_89 g_142
 * writes: g_38 g_20 g_142
 */
static uint8_t  func_52(const int32_t  p_53, const int32_t  p_54, uint32_t  p_55, const uint8_t  p_56)
{ /* block id: 28 */
    int32_t l_60 = 7L;
    int32_t l_61 = 0x848A66BEL;
    int32_t l_63 = 0x949F72E7L;
    int32_t l_64 = 0xB2563844L;
    int32_t l_65[1][8] = {{8L,(-4L),8L,(-4L),8L,(-4L),8L,(-4L)}};
    int8_t l_67 = 0x08L;
    uint64_t l_72 = 0xC16D211A92B6F801LL;
    int64_t l_155 = 7L;
    int i, j;
    if ((safe_div_func_int8_t_s_s((l_60 | p_54), l_60)))
    { /* block id: 29 */
        int64_t l_62 = 8L;
        int32_t l_66 = 1L;
        int32_t l_68 = 0x718D2738L;
        int32_t l_69 = 0x109B52FFL;
        int32_t l_70[8];
        int32_t l_71 = 0xC8807C70L;
        uint32_t l_156 = 1UL;
        int64_t l_157 = 0x93782F4E6B69ECCDLL;
        int i;
        for (i = 0; i < 8; i++)
            l_70[i] = 0xC0F44DC8L;
        l_72--;
        l_70[1] = (safe_lshift_func_uint16_t_u_s(((func_26((((((safe_unary_minus_func_uint8_t_u((func_78(((((((safe_div_func_uint16_t_u_u((((+(safe_mul_func_int16_t_s_s(((l_63 < 0x04BEL) > g_38[4]), g_15[2][3][3]))) && l_61) != 1UL), p_54)) || g_44) >= 0xD755E4DDL) <= l_71) && 0x0205L) , p_53), p_56, g_20) | l_155))) , g_20) , g_89.f1) & p_54) , g_89.f4), g_89.f0, l_156, g_89.f0, l_70[6]) | l_64) | l_157), 15));
        for (l_72 = 0; (l_72 <= 3); l_72 += 1)
        { /* block id: 81 */
            int i;
            if (g_38[(l_72 + 1)])
                break;
            g_20 ^= (safe_rshift_func_uint8_t_u_s((0x3B2D3918L & g_38[l_72]), 1));
            g_38[1] &= (g_15[2][3][3] < l_65[0][0]);
            if (l_65[0][1])
                continue;
        }
    }
    else
    { /* block id: 87 */
        const uint32_t l_171 = 1UL;
        int32_t l_172 = 0x76C0FFB3L;
        int32_t l_182 = 1L;
        g_38[1] = (+0x144FEC2E3E7599D4LL);
        l_172 = (+(safe_add_func_int8_t_s_s((safe_mod_func_int8_t_s_s((!((safe_mod_func_uint32_t_u_u(((safe_lshift_func_int8_t_s_s(0xC6L, 2)) , g_89.f0), 0x12510486L)) >= 0x4B89AB21L)), l_171)), p_55)));
        g_38[4] = (g_89.f0 , l_172);
        for (g_20 = 0; (g_20 >= 13); g_20 = safe_add_func_uint64_t_u_u(g_20, 7))
        { /* block id: 93 */
            uint8_t l_181 = 0xAAL;
            l_182 = ((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s((safe_sub_func_uint32_t_u_u((g_38[1] >= g_89.f2), 0x51C73A80L)), l_181)) >= g_142), p_54)) < l_181);
            if (p_54)
                continue;
            return g_142;
        }
    }
    return p_56;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_20 g_89 g_44 g_15 g_142
 * writes: g_38 g_20 g_142
 */
static int32_t  func_78(int8_t  p_79, uint8_t  p_80, uint16_t  p_81)
{ /* block id: 31 */
    uint32_t l_90[3][7][5] = {{{18446744073709551607UL,0xE90FC208L,9UL,18446744073709551615UL,7UL},{0x65C4EC06L,0xBCF58CCDL,18446744073709551607UL,0UL,0UL},{0UL,0x1624665FL,0x43A6B221L,0x43A6B221L,0x1624665FL},{18446744073709551615UL,3UL,3UL,1UL,6UL},{0xFECAEFE6L,0x22C981DFL,18446744073709551607UL,18446744073709551607UL,0UL},{18446744073709551607UL,5UL,0x6934E6C7L,0x65C4EC06L,0xC73D51CDL},{0xFECAEFE6L,18446744073709551610UL,18446744073709551615UL,0UL,0xDF942F02L}},{{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,3UL},{0UL,18446744073709551615UL,18446744073709551610UL,0xFECAEFE6L,0xBCAC1807L},{0x65C4EC06L,0x6934E6C7L,5UL,18446744073709551607UL,1UL},{18446744073709551607UL,18446744073709551607UL,0x22C981DFL,0xFECAEFE6L,0UL},{1UL,3UL,3UL,18446744073709551615UL,3UL},{0x43A6B221L,0x43A6B221L,0x1624665FL,0UL,18446744073709551607UL},{0UL,18446744073709551607UL,0xBCF58CCDL,0x65C4EC06L,18446744073709551615UL}},{{0x9EB2EF12L,0x9958B7C2L,0x1624665FL,7UL,18446744073709551615UL},{18446744073709551615UL,0x28A6F30DL,5UL,0xBCF58CCDL,3UL},{0xC0B84261L,0UL,7UL,0UL,0xC0B84261L},{18446744073709551607UL,18446744073709551615UL,1UL,0x9E20859FL,6UL},{18446744073709551607UL,0UL,1UL,0x9EB2EF12L,7UL},{1UL,0UL,0x45D42F5FL,18446744073709551615UL,6UL},{18446744073709551615UL,0x9EB2EF12L,18446744073709551607UL,0xC0B84261L,0xC0B84261L}}};
    int8_t l_91 = 0x22L;
    int16_t l_92 = (-1L);
    int32_t l_93 = 0xA977D591L;
    int32_t l_95 = (-1L);
    int32_t l_114[8] = {0xDC735B24L,0xDC735B24L,0xDC735B24L,0xDC735B24L,0xDC735B24L,0xDC735B24L,0xDC735B24L,0xDC735B24L};
    int8_t l_115 = 0x42L;
    int32_t l_116[2][8][4];
    int8_t l_117 = 0x0CL;
    uint16_t l_118 = 0x8FF2L;
    int64_t l_138 = 0xE1AE6350AEA437ACLL;
    uint64_t l_139 = 0x22F82038209D23E5LL;
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
                l_116[i][j][k] = (-4L);
        }
    }
    for (p_81 = 0; (p_81 <= 3); p_81 += 1)
    { /* block id: 34 */
        int32_t l_94[5] = {0xED2AF603L,0xED2AF603L,0xED2AF603L,0xED2AF603L,0xED2AF603L};
        int i;
        g_38[(p_81 + 1)] = (safe_rshift_func_uint8_t_u_s((p_80 || g_38[1]), 1));
        g_38[1] ^= (g_20 > p_81);
        if ((g_89 , l_90[2][1][4]))
        { /* block id: 37 */
            if (g_89.f0)
                break;
        }
        else
        { /* block id: 39 */
            l_91 = (g_89.f0 ^ g_38[3]);
        }
        for (g_20 = 0; (g_20 <= 3); g_20 += 1)
        { /* block id: 44 */
            uint32_t l_96 = 0xA6072D4BL;
            if (l_92)
                break;
            ++l_96;
        }
    }
    for (l_92 = 0; (l_92 <= 9); l_92++)
    { /* block id: 51 */
        uint64_t l_101 = 0x9DD727E68FBA5D09LL;
        int32_t l_108 = 0x7FE5D293L;
        l_101 ^= (p_79 ^ (-1L));
        g_38[0] = ((((safe_add_func_int32_t_s_s((safe_add_func_uint64_t_u_u(g_38[1], l_101)), p_81)) ^ p_81) < l_95) | l_101);
        if (l_101)
        { /* block id: 54 */
            l_108 = (safe_rshift_func_uint16_t_u_s(l_101, g_20));
        }
        else
        { /* block id: 56 */
            uint32_t l_113 = 0xBBF17680L;
            g_38[1] = (g_38[0] == p_81);
            l_113 |= ((safe_rshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((g_44 < 0xD3L), 0x02L)), g_89.f1)) > 7UL);
            if (p_80)
                continue;
            g_38[1] &= 0L;
        }
    }
    --l_118;
    if (((g_38[1] | g_44) >= g_89.f2))
    { /* block id: 64 */
        uint64_t l_121 = 4UL;
        int32_t l_140[1];
        int32_t l_141 = 0x6705FE35L;
        uint32_t l_147 = 18446744073709551607UL;
        int i;
        for (i = 0; i < 1; i++)
            l_140[i] = 0L;
        --l_121;
        l_140[0] = (safe_lshift_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(((safe_mod_func_int32_t_s_s((safe_sub_func_uint16_t_u_u(((safe_mod_func_uint64_t_u_u((((safe_div_func_int64_t_s_s((safe_add_func_uint64_t_u_u((l_115 | l_121), 0xB97F9317D55B7D1ALL)), l_138)) >= (-7L)) && g_38[1]), (-4L))) , p_80), l_139)), p_79)) ^ g_89.f4), g_15[2][3][3])), 4));
        --g_142;
        if ((safe_sub_func_int16_t_s_s(p_80, l_139)))
        { /* block id: 68 */
            --l_147;
        }
        else
        { /* block id: 70 */
            uint8_t l_154 = 0xA1L;
            l_154 = (safe_add_func_int32_t_s_s((safe_add_func_uint16_t_u_u(0x27C6L, 0x018BL)), 0x453CEA57L));
            return g_142;
        }
    }
    else
    { /* block id: 74 */
        l_95 = 2L;
    }
    return l_115;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_15[i][j][k], "g_15[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_20, "g_20", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_38[i], "g_38[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_89.f0, "g_89.f0", print_hash_value);
    transparent_crc(g_89.f1, "g_89.f1", print_hash_value);
    transparent_crc(g_89.f2, "g_89.f2", print_hash_value);
    transparent_crc(g_89.f3, "g_89.f3", print_hash_value);
    transparent_crc(g_89.f4, "g_89.f4", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_193.f0, "g_193.f0", print_hash_value);
    transparent_crc(g_193.f1, "g_193.f1", print_hash_value);
    transparent_crc(g_193.f2, "g_193.f2", print_hash_value);
    transparent_crc(g_193.f3, "g_193.f3", print_hash_value);
    transparent_crc(g_193.f4, "g_193.f4", print_hash_value);
    transparent_crc(g_198.f0, "g_198.f0", print_hash_value);
    transparent_crc(g_198.f1, "g_198.f1", print_hash_value);
    transparent_crc(g_198.f2, "g_198.f2", print_hash_value);
    transparent_crc(g_198.f3, "g_198.f3", print_hash_value);
    transparent_crc(g_198.f4, "g_198.f4", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_199[i].f0, "g_199[i].f0", print_hash_value);
        transparent_crc(g_199[i].f1, "g_199[i].f1", print_hash_value);
        transparent_crc(g_199[i].f2, "g_199[i].f2", print_hash_value);
        transparent_crc(g_199[i].f3, "g_199[i].f3", print_hash_value);
        transparent_crc(g_199[i].f4, "g_199[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_203, "g_203", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 64
   depth: 1, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 28
breakdown:
   depth: 1, occurrence: 79
   depth: 2, occurrence: 23
   depth: 3, occurrence: 9
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 3
   depth: 8, occurrence: 2
   depth: 13, occurrence: 1
   depth: 28, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 135
XXX times a non-volatile is write: 41
XXX times a volatile is read: 18
XXX    times read thru a pointer: 0
XXX times a volatile is write: 12
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 106
XXX percentage of non-volatile access: 85.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 79
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 31
   depth: 2, occurrence: 33

XXX percentage a fresh-made variable is used: 20.6
XXX percentage an existing variable is used: 79.4
********************* end of statistics **********************/

