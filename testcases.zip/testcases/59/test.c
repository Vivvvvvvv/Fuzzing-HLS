/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      934091809837071803
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_9 = 0xBD035C57L;
static uint8_t g_16 = 0x5DL;
static int16_t g_19 = 1L;
static volatile int16_t g_20 = (-4L);/* VOLATILE GLOBAL g_20 */
static volatile uint64_t g_21 = 0x5240CA70051EFDB7LL;/* VOLATILE GLOBAL g_21 */
static uint64_t g_52 = 6UL;
static volatile uint8_t g_64 = 0xA1L;/* VOLATILE GLOBAL g_64 */
static uint16_t g_76 = 0x4B57L;
static uint64_t g_94 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_4(uint32_t  p_5, uint32_t  p_6, uint16_t  p_7);
static const uint8_t  func_39(int8_t  p_40);
static int8_t  func_41(int8_t  p_42, uint32_t  p_43, int64_t  p_44, uint16_t  p_45, int8_t  p_46);
static int32_t  func_49(int8_t  p_50, uint32_t  p_51);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_21 g_16 g_19 g_20 g_52 g_64 g_76 g_94
 * writes: g_9 g_16 g_21 g_19 g_64 g_76 g_94
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_8 = 65533UL;
    int32_t l_87 = 0x519FD4AAL;
    uint64_t l_114 = 0x0C55B62D563F42B1LL;
    int64_t l_115 = (-2L);
    if (((((safe_rshift_func_int8_t_s_s(func_4(l_8, l_8, g_9), g_52)) <= g_52) & g_52) >= 0x05B3L))
    { /* block id: 50 */
        int8_t l_78[1];
        int32_t l_79 = 0x2E4E98E2L;
        int32_t l_93 = 0x4B7FD3A1L;
        uint32_t l_102 = 4294967295UL;
        int i;
        for (i = 0; i < 1; i++)
            l_78[i] = 0x1AL;
        if (((((l_78[0] != 0xD946680AL) || g_76) <= 247UL) <= l_79))
        { /* block id: 51 */
            g_9 |= (safe_sub_func_uint16_t_u_u(g_19, 0xAD09L));
        }
        else
        { /* block id: 53 */
            g_9 = ((safe_add_func_int64_t_s_s(((g_9 ^ l_8) , 0xBB70294BA75048CBLL), g_19)) , l_78[0]);
            if (l_79)
                goto lbl_101;
        }
        g_9 = (safe_lshift_func_int16_t_s_s(g_9, 9));
        if (l_78[0])
        { /* block id: 57 */
            uint8_t l_92 = 255UL;
            int32_t l_98 = 6L;
            l_87 = ((safe_unary_minus_func_int64_t_s(g_21)) & g_19);
            g_9 = ((safe_mod_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u((2L ^ g_52), l_92)), 1L)) <= 0x38L);
            ++g_94;
            l_98 ^= ((safe_unary_minus_func_uint64_t_u(l_87)) || l_78[0]);
        }
        else
        { /* block id: 62 */
lbl_101:
            l_87 = (safe_lshift_func_int16_t_s_u((-7L), 8));
            ++l_102;
        }
    }
    else
    { /* block id: 67 */
        int32_t l_109[4] = {0x0CEACAB8L,0x0CEACAB8L,0x0CEACAB8L,0x0CEACAB8L};
        int i;
        for (g_19 = 0; (g_19 <= (-2)); g_19 = safe_sub_func_int16_t_s_s(g_19, 2))
        { /* block id: 70 */
            l_109[2] |= (((l_8 >= 0L) , 0xFBL) ^ l_8);
        }
        g_9 &= (safe_rshift_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((l_8 >= g_20) ^ g_94), g_52)), l_114));
        g_9 &= g_64;
    }
    return l_115;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_21 g_16 g_19 g_20 g_52 g_64 g_76
 * writes: g_9 g_16 g_21 g_19 g_64 g_76
 */
static int8_t  func_4(uint32_t  p_5, uint32_t  p_6, uint16_t  p_7)
{ /* block id: 1 */
    int64_t l_18 = 0x6E700D62E65251C6LL;
    int32_t l_29 = 0xFEC46BC2L;
    uint8_t l_77[3][3][4] = {{{254UL,254UL,255UL,254UL},{254UL,0x6EL,0x6EL,254UL},{0x6EL,254UL,0x6EL,0x6EL}},{{254UL,254UL,255UL,254UL},{254UL,0x6EL,0x6EL,254UL},{0x6EL,254UL,0x6EL,0x6EL}},{{254UL,254UL,255UL,254UL},{254UL,0x6EL,0x6EL,254UL},{0x6EL,254UL,0x6EL,0x6EL}}};
    int i, j, k;
    for (p_7 = 18; (p_7 > 12); p_7 = safe_sub_func_uint64_t_u_u(p_7, 4))
    { /* block id: 4 */
        const int8_t l_14 = 0xEEL;
        int32_t l_71 = 1L;
        for (g_9 = 0; (g_9 <= 10); ++g_9)
        { /* block id: 7 */
            uint32_t l_15 = 1UL;
            int32_t l_17 = (-1L);
            if (l_14)
                break;
            g_16 = l_15;
            g_21--;
        }
        for (g_16 = 13; (g_16 != 40); g_16++)
        { /* block id: 14 */
            int32_t l_26 = 0x87E3BC4AL;
            uint32_t l_70 = 0xABA13E97L;
            l_26 = p_5;
            l_29 = (safe_lshift_func_uint16_t_u_s(g_16, l_14));
            l_71 = ((safe_lshift_func_int8_t_s_u((~(safe_div_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((safe_div_func_int8_t_s_s((((func_39(func_41(g_19, g_16, g_20, l_26, p_7)) >= 1UL) >= 0xD0L) && l_14), l_18)), l_26)), p_7))), g_52)) || l_70);
        }
        for (g_19 = 0; (g_19 >= (-13)); g_19--)
        { /* block id: 42 */
            return p_5;
        }
        if (p_6)
            break;
    }
    g_76 &= ((((safe_mod_func_uint8_t_u_u(g_64, 254UL)) , g_21) >= g_9) , (-1L));
    for (l_29 = 0; l_29 < 3; l_29 += 1)
    {
        for (g_19 = 0; g_19 < 3; g_19 += 1)
        {
            for (g_16 = 0; g_16 < 4; g_16 += 1)
            {
                l_77[l_29][g_19][g_16] = 0x04L;
            }
        }
    }
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const uint8_t  func_39(int8_t  p_40)
{ /* block id: 36 */
    const int32_t l_69[3][3][1] = {{{(-4L)},{7L},{(-4L)}},{{7L},{(-4L)},{7L}},{{(-4L)},{7L},{(-4L)}}};
    int i, j, k;
    return l_69[1][2][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_52 g_20 g_64
 * writes: g_19 g_64
 */
static int8_t  func_41(int8_t  p_42, uint32_t  p_43, int64_t  p_44, uint16_t  p_45, int8_t  p_46)
{ /* block id: 17 */
    int32_t l_60 = 0x3245E346L;
    int32_t l_61 = 0x8BA54F90L;
    for (g_19 = (-27); (g_19 < (-25)); g_19++)
    { /* block id: 20 */
        int32_t l_53 = (-1L);
        int32_t l_59 = (-9L);
        l_59 = func_49(((g_19 == 0x78B7212908CDAC36LL) >= g_52), l_53);
        if (p_45)
            continue;
    }
    l_61 &= (0x55F5DDA3018177C4LL > l_60);
    l_61 = (g_20 == 0x70L);
    for (p_42 = 0; (p_42 == (-3)); p_42 = safe_sub_func_uint16_t_u_u(p_42, 3))
    { /* block id: 31 */
        int32_t l_67 = 0x0128B80BL;
        int32_t l_68 = 1L;
        g_64--;
        l_68 ^= ((p_44 <= 1L) ^ l_67);
    }
    return g_20;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_49(int8_t  p_50, uint32_t  p_51)
{ /* block id: 21 */
    uint32_t l_56 = 1UL;
    uint32_t l_57 = 4294967295UL;
    int32_t l_58 = (-2L);
    l_58 = (safe_div_func_int8_t_s_s(l_56, l_57));
    return p_51;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 38
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 16
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 6
   depth: 8, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 65
XXX times a non-volatile is write: 29
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 35
XXX percentage of non-volatile access: 90.4

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 45
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 14
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 38.4
XXX percentage an existing variable is used: 61.6
********************* end of statistics **********************/

