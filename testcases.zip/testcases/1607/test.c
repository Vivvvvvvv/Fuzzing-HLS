/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5366237502757518832
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S1 {
   const int32_t  f0;
   volatile uint32_t  f1;
   const uint32_t  f2;
   int64_t  f3;
   uint32_t  f4;
   uint32_t  f5;
};

struct S0 {
   volatile int8_t  f0;
   volatile int16_t  f1;
   const uint64_t  f2;
   volatile uint8_t  f3;
   const uint32_t  f4;
   volatile int32_t  f5;
   volatile int8_t  f6;
   volatile uint16_t  f7;
   const uint8_t  f8;
};

struct S3 {
   volatile struct S0  f0;
   int16_t  f1;
   const int8_t  f2;
   uint8_t  f3;
   int8_t  f4;
   struct S1  f5;
   const int64_t  f6;
   const uint32_t  f7;
   volatile int64_t  f8;
   struct S0  f9;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint64_t g_4 = 18446744073709551615UL;/* VOLATILE GLOBAL g_4 */
static const int16_t g_5 = 0xACD4L;
static int64_t g_8[8] = {0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL,0x9B58331C587C7AB8LL};
static int32_t g_10 = (-1L);
static uint32_t g_11 = 0x09B37D02L;
static uint16_t g_14 = 65535UL;
static volatile int8_t g_40 = 2L;/* VOLATILE GLOBAL g_40 */
static int32_t g_41 = 0L;
static volatile int64_t g_42 = 0xCA7276463A47399DLL;/* VOLATILE GLOBAL g_42 */
static volatile int32_t g_43 = (-7L);/* VOLATILE GLOBAL g_43 */
static uint32_t g_44[7] = {0x5DFEA44EL,0x5DFEA44EL,0x5DFEA44EL,0x5DFEA44EL,0x5DFEA44EL,0x5DFEA44EL,0x5DFEA44EL};
static volatile struct S3 g_63 = {{-1L,0x8BD5L,0UL,0x97L,0UL,-1L,0xA1L,0x536DL,0x7EL},2L,-6L,0UL,-7L,{4L,0xCF5EE2CBL,0x03168F1DL,0x9FA4EE4B4BC07302LL,18446744073709551615UL,4294967295UL},8L,4294967286UL,-10L,{0x77L,5L,0UL,0x07L,0x4B492BB7L,0L,0x68L,65535UL,0xD5L}};/* VOLATILE GLOBAL g_63 */
static struct S1 g_68 = {-1L,0xA7FFF357L,0UL,6L,0xF94FDEA9L,8UL};/* VOLATILE GLOBAL g_68 */
static uint32_t g_71 = 4294967289UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_22(int32_t  p_23, int8_t  p_24, uint32_t  p_25, int16_t  p_26, uint8_t  p_27);
static int32_t  func_31(uint64_t  p_32, int64_t  p_33);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_8 g_10 g_11 g_14 g_44 g_43 g_63 g_68 g_41 g_71
 * writes: g_8 g_10 g_11 g_14 g_44 g_43 g_41 g_71
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_15 = 0UL;
    int32_t l_21 = (-2L);
    int32_t l_96 = 0L;
    if ((safe_rshift_func_int16_t_s_u((g_4 < g_5), g_5)))
    { /* block id: 1 */
        uint32_t l_9 = 0x4129B857L;
        g_8[7] ^= (safe_lshift_func_int8_t_s_s((g_5 <= g_4), 6));
        g_10 = l_9;
        for (g_10 = 0; (g_10 <= 7); g_10 += 1)
        { /* block id: 6 */
            int i;
            if (g_8[g_10])
                break;
            --g_11;
            g_14 = 0xF8E3BF11L;
        }
    }
    else
    { /* block id: 11 */
        int16_t l_20 = 0xBF7CL;
        const uint64_t l_95 = 18446744073709551610UL;
        g_10 ^= l_15;
        l_21 ^= (((safe_sub_func_int64_t_s_s(((safe_add_func_int16_t_s_s(g_4, g_8[7])) & g_11), l_20)) > g_8[0]) == 0x53EA3A7221EBC5F9LL);
        if ((func_22(l_20, g_10, g_8[6], g_10, g_11) , 0xDDCD3E82L))
        { /* block id: 37 */
            l_21 = (safe_lshift_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u((l_21 , 0x272ABD0CL), 0xBC662C87L)) && g_10), 7));
            g_10 = (safe_add_func_int16_t_s_s(l_20, 6UL));
        }
        else
        { /* block id: 40 */
            int32_t l_84[9] = {0x97AAA56DL,0x97AAA56DL,0x97AAA56DL,0x97AAA56DL,0x97AAA56DL,0x97AAA56DL,0x97AAA56DL,0x97AAA56DL,0x97AAA56DL};
            int i;
            l_21 &= g_63.f9.f3;
            g_43 ^= (safe_add_func_int64_t_s_s(((safe_sub_func_int64_t_s_s(l_21, l_84[8])) | l_84[8]), l_15));
            g_41 = ((safe_add_func_uint64_t_u_u((((safe_mod_func_uint64_t_u_u((safe_div_func_uint64_t_u_u(((((((safe_mod_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(l_20, 9)), 0xB9EEL)) & l_84[2]) == 0x9617L) & 0xF3L) == 0xF7ADE520L) , l_84[8]), l_95)), g_8[7])) == l_96) || l_84[8]), (-9L))) == l_15);
        }
    }
    g_10 |= 0xE211E8D5L;
    l_21 ^= ((safe_mul_func_uint8_t_u_u(0x21L, 5L)) & g_63.f9.f1);
    return g_8[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_5 g_44 g_43 g_63 g_68 g_41 g_71
 * writes: g_44 g_43 g_41 g_71
 */
static int32_t  func_22(int32_t  p_23, int8_t  p_24, uint32_t  p_25, int16_t  p_26, uint8_t  p_27)
{ /* block id: 14 */
    int16_t l_30 = 0x5C4BL;
    int32_t l_47[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
    uint16_t l_57 = 1UL;
    int i;
    if ((safe_lshift_func_int16_t_s_s((l_30 & p_24), g_14)))
    { /* block id: 15 */
        g_43 = func_31(p_23, g_5);
        l_47[8] = 0x45C545F0L;
    }
    else
    { /* block id: 21 */
        uint8_t l_48 = 0xF5L;
        l_48--;
        l_47[8] = ((((((safe_rshift_func_int16_t_s_u((safe_add_func_int64_t_s_s((safe_lshift_func_int16_t_s_u(g_43, 2)), 1L)), g_14)) || p_26) ^ (-10L)) <= p_23) < p_26) > l_57);
        g_41 = 1L;
        for (p_26 = (-9); (p_26 <= (-8)); ++p_26)
        { /* block id: 27 */
            uint64_t l_64 = 0x85E685AC0FE8B856LL;
            int32_t l_65 = 0xBD99A0A0L;
            l_65 |= (safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_uint64_t_u((g_63 , l_48))), l_64));
            g_41 = (safe_mul_func_uint8_t_u_u((g_68 , p_27), p_24));
            g_41 ^= 0xC4EAE4C0L;
            g_43 ^= ((((safe_mod_func_int32_t_s_s(0L, g_68.f3)) || l_57) == p_27) | p_25);
        }
    }
    l_47[8] |= (g_63.f5.f0 | p_26);
    --g_71;
    return l_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_44
 * writes: g_44
 */
static int32_t  func_31(uint64_t  p_32, int64_t  p_33)
{ /* block id: 16 */
    int32_t l_34 = (-1L);
    int32_t l_35 = 0xD17BA7DAL;
    int32_t l_36 = (-6L);
    int32_t l_37 = (-1L);
    int32_t l_38[3];
    int32_t l_39 = 0xBAE88B14L;
    int i;
    for (i = 0; i < 3; i++)
        l_38[i] = 0xE3C23917L;
    ++g_44[3];
    return l_38[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_44[i], "g_44[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_63.f0.f0, "g_63.f0.f0", print_hash_value);
    transparent_crc(g_63.f0.f1, "g_63.f0.f1", print_hash_value);
    transparent_crc(g_63.f0.f2, "g_63.f0.f2", print_hash_value);
    transparent_crc(g_63.f0.f3, "g_63.f0.f3", print_hash_value);
    transparent_crc(g_63.f0.f4, "g_63.f0.f4", print_hash_value);
    transparent_crc(g_63.f0.f5, "g_63.f0.f5", print_hash_value);
    transparent_crc(g_63.f0.f6, "g_63.f0.f6", print_hash_value);
    transparent_crc(g_63.f0.f7, "g_63.f0.f7", print_hash_value);
    transparent_crc(g_63.f0.f8, "g_63.f0.f8", print_hash_value);
    transparent_crc(g_63.f1, "g_63.f1", print_hash_value);
    transparent_crc(g_63.f2, "g_63.f2", print_hash_value);
    transparent_crc(g_63.f3, "g_63.f3", print_hash_value);
    transparent_crc(g_63.f4, "g_63.f4", print_hash_value);
    transparent_crc(g_63.f5.f0, "g_63.f5.f0", print_hash_value);
    transparent_crc(g_63.f5.f1, "g_63.f5.f1", print_hash_value);
    transparent_crc(g_63.f5.f2, "g_63.f5.f2", print_hash_value);
    transparent_crc(g_63.f5.f3, "g_63.f5.f3", print_hash_value);
    transparent_crc(g_63.f5.f4, "g_63.f5.f4", print_hash_value);
    transparent_crc(g_63.f5.f5, "g_63.f5.f5", print_hash_value);
    transparent_crc(g_63.f6, "g_63.f6", print_hash_value);
    transparent_crc(g_63.f7, "g_63.f7", print_hash_value);
    transparent_crc(g_63.f8, "g_63.f8", print_hash_value);
    transparent_crc(g_63.f9.f0, "g_63.f9.f0", print_hash_value);
    transparent_crc(g_63.f9.f1, "g_63.f9.f1", print_hash_value);
    transparent_crc(g_63.f9.f2, "g_63.f9.f2", print_hash_value);
    transparent_crc(g_63.f9.f3, "g_63.f9.f3", print_hash_value);
    transparent_crc(g_63.f9.f4, "g_63.f9.f4", print_hash_value);
    transparent_crc(g_63.f9.f5, "g_63.f9.f5", print_hash_value);
    transparent_crc(g_63.f9.f6, "g_63.f9.f6", print_hash_value);
    transparent_crc(g_63.f9.f7, "g_63.f9.f7", print_hash_value);
    transparent_crc(g_63.f9.f8, "g_63.f9.f8", print_hash_value);
    transparent_crc(g_68.f0, "g_68.f0", print_hash_value);
    transparent_crc(g_68.f1, "g_68.f1", print_hash_value);
    transparent_crc(g_68.f2, "g_68.f2", print_hash_value);
    transparent_crc(g_68.f3, "g_68.f3", print_hash_value);
    transparent_crc(g_68.f4, "g_68.f4", print_hash_value);
    transparent_crc(g_68.f5, "g_68.f5", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 1
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 41
   depth: 2, occurrence: 4
   depth: 3, occurrence: 7
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 55
XXX times a non-volatile is write: 24
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 45
XXX percentage of non-volatile access: 87.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 34
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 12
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 29.2
XXX percentage an existing variable is used: 70.8
********************* end of statistics **********************/

