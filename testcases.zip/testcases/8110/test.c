/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9637429836727583790
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_25 = 2L;
static uint64_t g_44 = 0x12A2EF7E291920B2LL;
static int64_t g_52 = 0x1456B8642E5F0E77LL;
static volatile uint32_t g_74[1] = {0UL};
static uint32_t g_83 = 5UL;
static volatile uint16_t g_84 = 0UL;/* VOLATILE GLOBAL g_84 */
static int64_t g_99[7][10] = {{8L,(-1L),0x55490EB022B26CBFLL,1L,4L,0x7A4FD34EA093EA4BLL,5L,(-5L),0x28B7FD9B51ECC885LL,0x5384E059069C78C3LL},{0x11FE8BE9C2C51C80LL,(-1L),5L,(-9L),0x59FE4D3D82F88197LL,0x7A4FD34EA093EA4BLL,(-6L),2L,(-1L),0L},{8L,4L,0xD564CE3E23DE179BLL,2L,(-1L),(-1L),(-1L),(-1L),2L,0xD564CE3E23DE179BLL},{8L,8L,0L,(-1L),2L,(-6L),0x7A4FD34EA093EA4BLL,0x59FE4D3D82F88197LL,(-9L),5L},{0L,2L,0x5384E059069C78C3LL,0x28B7FD9B51ECC885LL,(-5L),(-1L),(-1L),0xDAE8E356D6BBB239LL,2L,0x28B7FD9B51ECC885LL},{0x55490EB022B26CBFLL,(-1L),(-6L),(-1L),(-1L),8L,2L,8L,(-1L),(-1L)},{(-9L),0x5384E059069C78C3LL,(-9L),(-1L),0L,0x55490EB022B26CBFLL,0xD564CE3E23DE179BLL,(-1L),0x59FE4D3D82F88197LL,4L}};
static volatile uint32_t g_109 = 0UL;/* VOLATILE GLOBAL g_109 */
static uint32_t g_115 = 0x228E1FC5L;
static volatile uint8_t g_121 = 252UL;/* VOLATILE GLOBAL g_121 */
static int32_t g_124 = 1L;
static int32_t g_128 = 0xA6A349BDL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_4(uint32_t  p_5, uint8_t  p_6, int16_t  p_7);
static int32_t  func_8(uint64_t  p_9, uint16_t  p_10, int8_t  p_11, uint16_t  p_12, uint32_t  p_13);
static const uint8_t  func_20(uint32_t  p_21, uint8_t  p_22, const int64_t  p_23);
static const uint16_t  func_28(int32_t  p_29, const uint8_t  p_30, int32_t  p_31, uint16_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_25 g_52 g_44 g_74 g_83 g_84 g_99 g_109 g_115 g_121 g_124
 * writes: g_44 g_52 g_74 g_83 g_84 g_99 g_109 g_115 g_121 g_124 g_128
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_24 = 0x4F93L;
    int16_t l_85[2];
    int32_t l_129[1][8][4] = {{{0xC0817FF2L,0xC0817FF2L,(-8L),1L},{1L,1L,0x387E9A70L,0x095B69D6L},{0x427A07EEL,0x387E9A70L,1L,0x387E9A70L},{1L,0x387E9A70L,0x427A07EEL,0x095B69D6L},{0x387E9A70L,1L,1L,1L},{(-8L),0xC0817FF2L,0xC0817FF2L,(-8L)},{(-8L),0x095B69D6L,1L,5L},{0x387E9A70L,(-8L),0x427A07EEL,0x6B9DDBBEL}}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_85[i] = 0x7435L;
    g_128 = (safe_div_func_uint32_t_u_u(func_4((func_8(((safe_add_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(func_20(l_24, g_25, g_25), 7)), l_24)), g_25)) <= g_25), g_25, g_25, g_25, g_25) , 0UL), l_85[1], g_25), l_85[0]));
    l_129[0][7][3] = 0L;
    return g_84;
}


/* ------------------------------------------ */
/* 
 * reads : g_74 g_44 g_25 g_52 g_99 g_109 g_115 g_121 g_83 g_124
 * writes: g_99 g_52 g_109 g_115 g_121 g_124
 */
static uint32_t  func_4(uint32_t  p_5, uint8_t  p_6, int16_t  p_7)
{ /* block id: 24 */
    uint32_t l_92 = 18446744073709551611UL;
    int32_t l_108 = 0x92F0D9F0L;
    for (p_6 = (-27); (p_6 == 8); p_6 = safe_add_func_uint64_t_u_u(p_6, 5))
    { /* block id: 27 */
        uint32_t l_90 = 18446744073709551606UL;
        uint16_t l_91 = 0x4C66L;
        int32_t l_105 = (-5L);
        l_92 |= ((((safe_mod_func_uint64_t_u_u((p_6 , l_90), p_6)) > g_74[0]) && l_91) && g_44);
        g_99[3][4] |= (safe_lshift_func_uint8_t_u_u(((((safe_rshift_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u(p_7, 1UL)) < g_25), 3)) , g_52) , 0xB41E2253L) > 0x040910B8L), 7));
        for (g_52 = 0; (g_52 >= 28); ++g_52)
        { /* block id: 32 */
            uint16_t l_102 = 0x320CL;
            l_102--;
        }
        l_105 &= p_6;
    }
    for (p_5 = 0; (p_5 >= 12); ++p_5)
    { /* block id: 39 */
        int32_t l_114 = 0xA03D0BAEL;
        --g_109;
        if ((247UL == g_52))
        { /* block id: 41 */
            l_114 |= (safe_add_func_uint64_t_u_u(p_7, 18446744073709551615UL));
        }
        else
        { /* block id: 43 */
            l_114 = g_109;
        }
    }
    --g_115;
    for (l_92 = 0; (l_92 == 52); ++l_92)
    { /* block id: 50 */
        int32_t l_120 = 0x5D73B7D9L;
        if ((4294967292UL > g_74[0]))
        { /* block id: 51 */
            uint64_t l_125 = 1UL;
            g_121--;
            l_125--;
            l_120 |= ((g_83 <= 65527UL) , g_74[0]);
        }
        else
        { /* block id: 55 */
            return g_124;
        }
        g_124 &= g_121;
        g_124 = ((((p_5 || 0xD74AL) || g_109) > 65528UL) || p_7);
    }
    return l_108;
}


/* ------------------------------------------ */
/* 
 * reads : g_84 g_25
 * writes: g_84
 */
static int32_t  func_8(uint64_t  p_9, uint16_t  p_10, int8_t  p_11, uint16_t  p_12, uint32_t  p_13)
{ /* block id: 21 */
    g_84 ^= 0x1D1BA057L;
    return g_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_52 g_44 g_74 g_83
 * writes: g_44 g_52 g_74 g_83
 */
static const uint8_t  func_20(uint32_t  p_21, uint8_t  p_22, const int64_t  p_23)
{ /* block id: 1 */
    int64_t l_27 = 1L;
    int32_t l_72 = (-6L);
    int32_t l_73 = 0x3177355AL;
    l_27 = (+g_25);
    l_72 &= (func_28(p_23, l_27, g_25, l_27) != 65532UL);
    g_74[0]--;
    g_83 &= (safe_mul_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u((p_21 == g_74[0]), 6)), g_44)), 0x6BB3L));
    return l_72;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_52 g_44
 * writes: g_44 g_52
 */
static const uint16_t  func_28(int32_t  p_29, const uint8_t  p_30, int32_t  p_31, uint16_t  p_32)
{ /* block id: 3 */
    int8_t l_37[6];
    int32_t l_71[7];
    int i;
    for (i = 0; i < 6; i++)
        l_37[i] = 2L;
    for (i = 0; i < 7; i++)
        l_71[i] = 0x2DB22C08L;
    if ((safe_rshift_func_uint8_t_u_u(0x7AL, 2)))
    { /* block id: 4 */
        p_31 = (safe_mul_func_uint8_t_u_u(((l_37[2] <= p_32) != 0x5FL), g_25));
        for (p_29 = (-10); (p_29 > (-27)); p_29 = safe_sub_func_uint32_t_u_u(p_29, 1))
        { /* block id: 8 */
            g_44 = (safe_div_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u((g_25 <= 0xC4F3L), 4294967290UL)) || g_25), p_29));
        }
    }
    else
    { /* block id: 11 */
        const uint16_t l_51 = 0xB03BL;
        g_52 = (safe_sub_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(g_25, p_30)), l_51)), p_30));
    }
    p_31 = (safe_mul_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(((((safe_mod_func_uint32_t_u_u(((safe_div_func_uint64_t_u_u(((g_25 ^ p_29) && p_31), 18446744073709551608UL)) , g_52), l_37[2])) != 0x361CL) != g_44) <= g_52), g_52)), l_37[5])), l_37[2]));
    l_71[4] = (safe_mul_func_uint32_t_u_u((safe_add_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u(g_52, 7)) > l_37[2]), 0xB1F05996L)), g_44)), 0UL));
    return g_25;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_74[i], "g_74[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_99[i][j], "g_99[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_109, "g_109", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 30
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 9
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 3
   depth: 6, occurrence: 3
   depth: 8, occurrence: 1
   depth: 12, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 67
XXX times a non-volatile is write: 26
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 26
XXX percentage of non-volatile access: 88.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 39
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 12
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 29.4
XXX percentage an existing variable is used: 70.6
********************* end of statistics **********************/

