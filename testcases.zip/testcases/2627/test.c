/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17906216829091631527
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_2 = 0x00D4E793L;/* VOLATILE GLOBAL g_2 */
static int32_t g_17[4] = {0xB0BF2465L,0xB0BF2465L,0xB0BF2465L,0xB0BF2465L};
static volatile int8_t g_39[7] = {3L,3L,0x80L,3L,3L,0x80L,3L};
static volatile int64_t g_51 = 5L;/* VOLATILE GLOBAL g_51 */
static int8_t g_58 = (-1L);
static int32_t g_59 = 0xA9D242ECL;
static int64_t g_61 = (-6L);


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_9(int32_t  p_10, uint16_t  p_11, int64_t  p_12, int32_t  p_13);
static int32_t  func_23(uint32_t  p_24, int16_t  p_25, int32_t  p_26, int16_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_17 g_39 g_59 g_51 g_58
 * writes: g_39 g_51 g_58 g_59 g_61
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_3 = 0x7BE7E550L;
    int32_t l_4 = 0x588E1B61L;
    const int16_t l_60 = 8L;
    l_4 = ((g_2 > 0UL) ^ l_3);
    g_61 = (safe_lshift_func_uint16_t_u_s(((safe_lshift_func_int8_t_s_s(func_9((((safe_sub_func_int8_t_s_s((~4294967295UL), 0UL)) == g_2) , g_2), g_17[2], g_17[2], g_17[2]), l_60)) >= l_4), 12));
    l_4 = ((0x669673C8L || 0xC00EEBEBL) || g_51);
    return g_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_2 g_39 g_59
 * writes: g_39 g_51 g_58 g_59
 */
static int8_t  func_9(int32_t  p_10, uint16_t  p_11, int64_t  p_12, int32_t  p_13)
{ /* block id: 2 */
    int32_t l_29 = (-7L);
    for (p_13 = 0; (p_13 == 28); p_13++)
    { /* block id: 5 */
        int32_t l_38 = (-1L);
        int32_t l_53 = 0xE0E3CEC3L;
        for (p_10 = 0; (p_10 >= 5); p_10 = safe_add_func_uint8_t_u_u(p_10, 5))
        { /* block id: 8 */
            uint16_t l_22 = 0xA84CL;
            l_22 = 0x62F63069L;
        }
        if (p_11)
        { /* block id: 11 */
            l_38 = func_23(((g_17[1] != 0x582BA8D7D2A7E9F2LL) , 1UL), g_17[2], g_2, p_11, l_29);
            if (g_17[2])
                continue;
            g_39[4] = 1L;
        }
        else
        { /* block id: 18 */
            const int32_t l_49[5] = {1L,1L,1L,1L,1L};
            int32_t l_50 = 0xE3BADF38L;
            int i;
            l_50 = (((safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(((((safe_sub_func_uint64_t_u_u((safe_unary_minus_func_uint64_t_u(((((p_12 || p_12) != l_29) , 18446744073709551611UL) ^ l_29))), g_17[2])) , p_12) | p_11) <= 0x8FL), 0x269945C6L)) & 0x87L), p_10)), 8L)) || g_17[2]) == l_49[0]);
            g_51 = 0xE1947684L;
            l_50 = 0x6DE45221L;
            return p_10;
        }
        l_53 = ((safe_unary_minus_func_uint16_t_u((g_39[4] <= l_29))) <= 6UL);
        g_58 = (((safe_mod_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u(g_2, 6)) < 0x67F3E8E036B6A42DLL), p_11)) <= g_17[2]) || 0x57L);
    }
    g_59 ^= (-1L);
    return g_17[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_17
 * writes:
 */
static int32_t  func_23(uint32_t  p_24, int16_t  p_25, int32_t  p_26, int16_t  p_27, uint32_t  p_28)
{ /* block id: 12 */
    uint8_t l_36 = 0UL;
    int32_t l_37 = 8L;
    l_37 &= (safe_div_func_uint64_t_u_u(((safe_mul_func_uint16_t_u_u((((((safe_mul_func_int8_t_s_s((g_2 > p_28), 0x48L)) >= 0UL) < p_25) || g_17[2]) > 1UL), p_26)) > 0xF4C9FF75L), l_36));
    return l_37;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_17[i], "g_17[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 2
   depth: 3, occurrence: 3
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 13
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 24
XXX percentage of non-volatile access: 83.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 4
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 32.1
XXX percentage an existing variable is used: 67.9
********************* end of statistics **********************/

