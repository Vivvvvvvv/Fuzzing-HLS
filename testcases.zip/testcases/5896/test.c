/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13871318470582110902
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_4 = 0x75C19C5AL;/* VOLATILE GLOBAL g_4 */
static int32_t g_9 = 0x2FBB6BC3L;
static uint8_t g_33 = 1UL;
static int32_t g_48 = 1L;
static int32_t g_95 = 0L;
static volatile int16_t g_96 = 1L;/* VOLATILE GLOBAL g_96 */
static volatile uint8_t g_100 = 0xC8L;/* VOLATILE GLOBAL g_100 */
static volatile uint32_t g_107 = 4294967295UL;/* VOLATILE GLOBAL g_107 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint16_t  func_15(int32_t  p_16, int32_t  p_17, uint8_t  p_18, int32_t  p_19);
static int32_t  func_20(const int32_t  p_21, int16_t  p_22);
static int32_t  func_25(const uint32_t  p_26);
static uint16_t  func_30(int32_t  p_31);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_33 g_48 g_100 g_107
 * writes: g_4 g_9 g_48 g_100 g_107
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    volatile int32_t l_6 = 0x72C25FCCL;/* VOLATILE GLOBAL l_6 */
    uint8_t l_28 = 0x68L;
    int32_t l_76 = 1L;
    int32_t l_79 = 3L;
    int32_t l_94 = 3L;
    int32_t l_106[2][5][1] = {{{0x9669FAE0L},{0x1A8B4793L},{0x2DA3065BL},{0x2DA3065BL},{0x1A8B4793L}},{{0x9669FAE0L},{0x1A8B4793L},{0x2DA3065BL},{0x2DA3065BL},{0x1A8B4793L}}};
    int i, j, k;
    if ((safe_div_func_uint64_t_u_u(0x24F01C08901F2C29LL, g_4)))
    { /* block id: 1 */
        int8_t l_5 = 0L;
        uint32_t l_10 = 4294967288UL;
        l_5 = 0x3F467215L;
        l_6 = (l_5 , g_4);
        if ((safe_mod_func_uint16_t_u_u((g_4 == 1UL), g_9)))
        { /* block id: 4 */
            return l_10;
        }
        else
        { /* block id: 6 */
            int16_t l_27[5][1] = {{0L},{0xDEDFL},{0L},{0xDEDFL},{0L}};
            uint32_t l_29 = 0x013CEF33L;
            int32_t l_66 = 0xC43CAE23L;
            int i, j;
            l_66 = (safe_lshift_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((func_15(func_20(((((safe_lshift_func_uint16_t_u_u((func_25(((l_27[2][0] , l_6) ^ l_27[2][0])) , 0UL), l_28)) ^ 9UL) , l_29) >= l_27[2][0]), l_27[0][0]), g_33, l_28, l_5) ^ 0UL), g_33)), 0));
            g_48 = (safe_sub_func_uint32_t_u_u(4294967291UL, 7UL));
            g_9 = (safe_sub_func_uint8_t_u_u(g_33, l_29));
        }
    }
    else
    { /* block id: 33 */
        uint64_t l_71 = 0x31782E4D72E8F988LL;
        --l_71;
        l_76 = (safe_rshift_func_uint16_t_u_u(l_71, g_9));
    }
    l_76 = (((safe_add_func_uint16_t_u_u(g_33, g_4)) && l_28) ^ g_33);
    if (g_33)
    { /* block id: 38 */
        int64_t l_86 = 0xA004931B7303F68CLL;
        int32_t l_87 = 0x904212E2L;
        l_79 = l_28;
        l_87 &= ((safe_rshift_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((((safe_lshift_func_uint16_t_u_u(g_48, 8)) <= g_9) && 0x1D34D3BEL), l_86)), 6)) < 0x644FL);
        l_87 = ((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((l_76 > g_9), 0)), 0xE57EL)) > 4294967288UL);
    }
    else
    { /* block id: 42 */
        int32_t l_97 = (-1L);
        int32_t l_98 = 1L;
        int32_t l_99[6][8][5] = {{{0xABE1F69FL,0xAE1B8E03L,0xABE1F69FL,0xC947AAB4L,0xE6FA96CDL},{0xEB474D9FL,0x20F69DBBL,(-1L),0x767204C5L,(-1L)},{(-1L),0x901E3F2BL,(-9L),(-1L),(-1L)},{3L,2L,(-1L),(-1L),0xA1598D83L},{0xB031E64CL,0L,0xABE1F69FL,0L,(-5L)},{2L,0x767204C5L,0x946A6819L,0x328501D8L,0xDF1EF1A9L},{0x1783C230L,(-1L),(-9L),(-9L),(-1L)},{0x78237234L,(-1L),0x946A6819L,0x0ECAC02DL,0L}},{{0x97827EA9L,8L,0L,0L,0x1783C230L},{0L,0xEB9B4FE2L,(-10L),0xF01E8602L,3L},{0x97827EA9L,1L,0x059AB739L,0x5D16F988L,1L},{0x78237234L,(-1L),0x767204C5L,(-1L),0x20F69DBBL},{0x059AB739L,(-5L),0xD1A43B2DL,0xE91ECAE5L,1L},{0xC56EA18DL,0L,0L,0xC56EA18DL,0xF01E8602L},{0x1783C230L,8L,0xAE1B8E03L,1L,(-5L)},{0x946A6819L,0L,0xF01E8602L,(-1L),0x47606124L}},{{8L,0xE91ECAE5L,0x059AB739L,1L,(-8L)},{6L,0x0ECAC02DL,0xDF1EF1A9L,0xC56EA18DL,0x0ECAC02DL},{1L,0x97827EA9L,0xA077DDA0L,0xE91ECAE5L,0xC947AAB4L},{0L,(-10L),0x946A6819L,(-1L),0x946A6819L},{0xC947AAB4L,0xC947AAB4L,0x901E3F2BL,0x5D16F988L,(-5L)},{(-1L),3L,0x4ABCDCAFL,0xF01E8602L,0x78237234L},{0x5D16F988L,8L,1L,0L,5L},{6L,3L,1L,0x0ECAC02DL,0x20F69DBBL}},{{(-9L),0xC947AAB4L,(-8L),(-9L),0x5D16F988L},{0x47606124L,(-10L),(-1L),0x20F69DBBL,0x6AFD11FFL},{0x1783C230L,0x97827EA9L,0x421AA4DEL,0x97827EA9L,0x1783C230L},{(-10L),0x0ECAC02DL,0x4ABCDCAFL,0x681571CFL,0xEB9B4FE2L},{0xABE1F69FL,0xE91ECAE5L,(-9L),8L,0xE91ECAE5L},{0x78237234L,0L,0xEB474D9FL,0x0ECAC02DL,0xEB9B4FE2L},{0xD1A43B2DL,8L,0xA077DDA0L,(-2L),0x1783C230L},{0xEB9B4FE2L,0L,(-10L),0x78237234L,0x6AFD11FFL}},{{0x97827EA9L,(-5L),(-1L),0x5D16F988L,0x5D16F988L},{0xF01E8602L,(-1L),0xF01E8602L,0x6F4C769FL,0x20F69DBBL},{0xABE1F69FL,1L,0xD1A43B2DL,(-1L),5L},{0xC56EA18DL,0xEB9B4FE2L,0L,0xC56EA18DL,0x78237234L},{0xA077DDA0L,8L,0xD1A43B2DL,5L,(-5L)},{0x47606124L,(-1L),0xF01E8602L,0L,0x946A6819L},{8L,(-1L),(-1L),1L,0xC947AAB4L},{0x4ABCDCAFL,0x0ECAC02DL,(-10L),(-10L),0x0ECAC02DL}},{{0x5D16F988L,0xD1A43B2DL,0xA077DDA0L,(-1L),(-8L)},{0L,0xC56EA18DL,0xEB474D9FL,(-1L),0x47606124L},{(-8L),0xC947AAB4L,(-9L),1L,(-5L)},{0L,0x6AFD11FFL,0x4ABCDCAFL,0x78237234L,0xF01E8602L},{0x5D16F988L,0x201FEAE7L,(-1L),0xD1A43B2DL,1L},{0x767204C5L,0x946A6819L,0x328501D8L,0xDF1EF1A9L,0x6AFD11FFL},{(-8L),0L,0L,(-8L),(-1L)},{0x4ABCDCAFL,0L,(-1L),0x6AFD11FFL,0x946A6819L}}};
        uint64_t l_105[9] = {0xFA2621F7AE5966A8LL,0x2BE68C9B47AF9668LL,0xFA2621F7AE5966A8LL,0xFA2621F7AE5966A8LL,0x2BE68C9B47AF9668LL,0xFA2621F7AE5966A8LL,0xFA2621F7AE5966A8LL,0x2BE68C9B47AF9668LL,0xFA2621F7AE5966A8LL};
        int i, j, k;
        l_94 = (safe_sub_func_uint64_t_u_u(18446744073709551615UL, 1UL));
        if (g_9)
            goto lbl_103;
lbl_103:
        g_100--;
        l_99[0][0][4] = ((!(l_98 ^ 255UL)) && g_9);
        l_76 = ((9UL && l_105[7]) > l_105[7]);
    }
    g_107++;
    return g_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_4 g_48
 * writes: g_9 g_48
 */
static uint16_t  func_15(int32_t  p_16, int32_t  p_17, uint8_t  p_18, int32_t  p_19)
{ /* block id: 16 */
    int32_t l_34[7][5] = {{0xCDFFA870L,0xCDFFA870L,0xCE570888L,(-1L),0xCE570888L},{0x7CC73EE4L,0x7CC73EE4L,(-10L),1L,(-10L)},{0xCDFFA870L,0xCDFFA870L,0xCE570888L,(-1L),0xCE570888L},{0x7CC73EE4L,0x7CC73EE4L,(-10L),1L,(-10L)},{0xCDFFA870L,0xCDFFA870L,0xCE570888L,(-1L),0xCE570888L},{0x7CC73EE4L,0x7CC73EE4L,(-10L),1L,(-10L)},{0xCDFFA870L,0xCDFFA870L,0xCE570888L,(-1L),0xCE570888L}};
    int32_t l_61 = 0xF81A6866L;
    int32_t l_62 = 0x8D42F466L;
    uint64_t l_63 = 8UL;
    int i, j;
    g_9 &= (1UL >= l_34[3][3]);
    if ((((safe_lshift_func_uint16_t_u_u((((l_34[4][3] > 0xD5L) > g_9) <= p_19), 0)) || l_34[3][3]) , 6L))
    { /* block id: 18 */
        int32_t l_41 = 0xBAE5BD57L;
        g_9 = (((l_34[4][1] > g_9) || 0xB036C860L) != g_9);
        p_19 &= ((safe_div_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(p_16, 4)), l_41)) >= p_17);
        p_19 = (safe_div_func_uint16_t_u_u(((safe_add_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u((0x7F1C74F3L ^ l_41), 7)) >= g_4), g_9)) == g_48), g_9));
        g_48 &= (safe_add_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u(0xDFF9L, l_41)), g_9)), 0UL));
    }
    else
    { /* block id: 23 */
        uint32_t l_60 = 1UL;
        p_17 = (safe_add_func_uint64_t_u_u(((p_18 <= 0x4C83B0F6L) < 1UL), 18446744073709551615UL));
        g_9 &= (((!(safe_sub_func_uint32_t_u_u((((4294967295UL < 0xA727FAABL) != l_60) , p_18), 0x872472F8L))) == 0x6697289FL) <= g_4);
    }
    l_63--;
    return l_61;
}


/* ------------------------------------------ */
/* 
 * reads : g_9
 * writes: g_4 g_9
 */
static int32_t  func_20(const int32_t  p_21, int16_t  p_22)
{ /* block id: 9 */
    int8_t l_32 = 1L;
    g_4 = (((func_30(l_32) || l_32) == g_9) >= g_9);
    g_4 = (((l_32 <= p_21) == p_21) , (-4L));
    g_9 = l_32;
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static int32_t  func_25(const uint32_t  p_26)
{ /* block id: 7 */
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_30(int32_t  p_31)
{ /* block id: 10 */
    return p_31;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 42
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 6
   depth: 5, occurrence: 2
   depth: 7, occurrence: 4
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 63
XXX times a non-volatile is write: 22
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 57
XXX percentage of non-volatile access: 86.7

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 38
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 19
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 27
XXX percentage an existing variable is used: 73
********************* end of statistics **********************/

