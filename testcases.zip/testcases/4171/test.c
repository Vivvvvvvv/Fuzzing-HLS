/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9315163218088870492
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int32_t  f0;
   uint8_t  f1;
   int8_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_3 = 0x4B81L;
static uint32_t g_16[4] = {0x80C6548AL,0x80C6548AL,0x80C6548AL,0x80C6548AL};
static uint32_t g_28 = 0x57994279L;
static int64_t g_29[10] = {(-1L),(-1L),0x674643A64E785C2FLL,(-1L),(-1L),0x674643A64E785C2FLL,(-1L),(-1L),0x674643A64E785C2FLL,(-1L)};
static uint16_t g_47 = 0UL;
static int32_t g_50[10] = {0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L,0x5F396434L};
static int16_t g_58 = (-8L);


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int16_t  func_4(const uint32_t  p_5, int32_t  p_6, int32_t  p_7, int8_t  p_8, int16_t  p_9);
static uint16_t  func_31(uint16_t  p_32, const struct S0  p_33, int64_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_16 g_28 g_29 g_50
 * writes: g_3 g_16 g_28 g_29 g_47 g_50 g_58
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2[2];
    int64_t l_10 = 0x374B1B055CC25BFCLL;
    int8_t l_11 = (-1L);
    uint32_t l_17 = 0x2ADAA237L;
    const struct S0 l_35 = {0L,0x43L,1L};
    int i;
    for (i = 0; i < 2; i++)
        l_2[i] = (-2L);
    g_3 &= l_2[0];
    l_17 = (func_4(l_2[0], l_10, l_10, g_3, l_11) && l_11);
    if ((safe_add_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_add_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u(l_2[0], g_16[0])) , g_16[2]), 0x3EL)), 65535UL)), 0xE1B8L)))
    { /* block id: 16 */
        g_28 = (safe_add_func_uint16_t_u_u(g_16[2], l_11));
        g_29[9] = g_16[3];
    }
    else
    { /* block id: 19 */
        uint32_t l_30 = 4294967289UL;
        l_30 = (0x1563L < 0xB6ACL);
    }
    g_58 = ((func_31(g_28, l_35, l_35.f1) , 0xBC40293EL) , 8L);
    return l_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_16
 * writes: g_3 g_16
 */
static int16_t  func_4(const uint32_t  p_5, int32_t  p_6, int32_t  p_7, int8_t  p_8, int16_t  p_9)
{ /* block id: 2 */
    struct S0 l_12[8] = {{0xA969AC54L,0x97L,-1L},{-7L,0x4FL,0xA7L},{0xA969AC54L,0x97L,-1L},{0xA969AC54L,0x97L,-1L},{-7L,0x4FL,0xA7L},{0xA969AC54L,0x97L,-1L},{0xA969AC54L,0x97L,-1L},{-7L,0x4FL,0xA7L}};
    int32_t l_15 = 3L;
    int i;
    for (g_3 = 0; (g_3 <= 7); g_3 += 1)
    { /* block id: 5 */
        for (p_7 = 7; (p_7 >= 0); p_7 -= 1)
        { /* block id: 8 */
            return p_6;
        }
        return g_3;
    }
    g_16[2] ^= (safe_sub_func_int16_t_s_s((0x5FEAF86FL > l_15), 0x51EFL));
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_29 g_28 g_50
 * writes: g_47 g_28 g_50
 */
static uint16_t  func_31(uint16_t  p_32, const struct S0  p_33, int64_t  p_34)
{ /* block id: 22 */
    uint16_t l_51[3];
    int32_t l_57 = 0x526695BDL;
    int i;
    for (i = 0; i < 3; i++)
        l_51[i] = 0x93C2L;
    for (p_34 = 3; (p_34 >= 0); p_34 -= 1)
    { /* block id: 25 */
        uint32_t l_56 = 0x708C9934L;
        int i;
        g_47 = ((safe_unary_minus_func_int32_t_s((((safe_mul_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u(((safe_div_func_uint64_t_u_u((safe_rshift_func_int8_t_s_u(g_16[p_34], g_29[(p_34 + 6)])), (-2L))) , g_29[(p_34 + 6)]), 5)), g_16[2])) , 1UL), g_29[(p_34 + 6)])) != g_29[8]) , g_29[(p_34 + 6)]))) < p_33.f1);
        for (g_28 = 0; (g_28 <= 3); g_28 += 1)
        { /* block id: 29 */
            g_50[3] = (safe_mul_func_int16_t_s_s((0xA6C34309L & g_16[3]), 0xA718L));
            l_51[0] = g_29[(p_34 + 6)];
            l_56 = (((safe_sub_func_uint32_t_u_u((safe_lshift_func_int8_t_s_s((p_33.f1 ^ g_29[(p_34 + 6)]), 2)), p_33.f2)) && g_29[(p_34 + 6)]) , g_29[9]);
        }
    }
    for (p_34 = 0; (p_34 <= 9); p_34 += 1)
    { /* block id: 37 */
        int i;
        if (g_29[p_34])
            break;
        if (g_29[p_34])
            break;
        return g_50[p_34];
    }
    l_57 = ((l_51[0] <= g_16[3]) >= l_51[0]);
    return g_29[8];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_16[i], "g_16[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_29[i], "g_29[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_47, "g_47", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_50[i], "g_50[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_58, "g_58", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 23
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 48
XXX times a non-volatile is write: 17
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 10
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 34.7
XXX percentage an existing variable is used: 65.3
********************* end of statistics **********************/

