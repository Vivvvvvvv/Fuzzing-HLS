/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18054867467654893059
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-3L);
static int64_t g_22 = 0L;
static uint64_t g_23 = 18446744073709551610UL;
static volatile int8_t g_29[8][9] = {{0xDAL,0x9AL,(-7L),0L,0L,(-7L),0x9AL,0xDAL,0xF9L},{0L,0L,0x3CL,0xE5L,0x3CL,0L,0L,0xE5L,0L},{0xDAL,0xCBL,0x9AL,0x9AL,0xCBL,0xDAL,(-7L),0x64L,0xF9L},{0x0BL,0xB7L,(-1L),0xB7L,0x0BL,0xE5L,(-1L),0xE5L,0x0BL},{0L,0x4FL,0x4FL,0L,0xF9L,0x64L,(-7L),0xDAL,0xCBL},{0x3CL,0xE5L,0x3CL,0L,0L,0xE5L,0L,0L,0x3CL},{0xCBL,0xCBL,0x64L,0x4FL,0xF9L,0xDAL,0x9AL,(-7L),0L},{0x0BL,8L,0x4BL,0L,0x0BL,0L,0x4BL,8L,0x0BL}};
static volatile uint64_t g_30 = 0xD4C01E07AD46D232LL;/* VOLATILE GLOBAL g_30 */
static int32_t g_33 = 0xB872A60DL;
static const int32_t g_42 = (-1L);
static volatile uint8_t g_45 = 1UL;/* VOLATILE GLOBAL g_45 */
static uint32_t g_46 = 0xD4E203D7L;
static int32_t g_52 = 3L;
static volatile uint32_t g_102 = 1UL;/* VOLATILE GLOBAL g_102 */
static int8_t g_108 = 0xA6L;
static uint8_t g_110 = 0x28L;
static int64_t g_148 = 0xCC42B5F30761BA64LL;
static int32_t g_149 = (-3L);
static volatile int8_t g_150[5][3][2] = {{{0x5CL,(-1L)},{(-1L),0x5CL},{(-1L),(-1L)}},{{0x5CL,(-1L)},{(-1L),0x5CL},{(-1L),(-1L)}},{{0x5CL,(-1L)},{(-1L),0x5CL},{(-1L),(-1L)}},{{0x5CL,(-1L)},{(-1L),0x5CL},{(-1L),(-1L)}},{{0x5CL,(-1L)},{(-1L),0x5CL},{(-1L),(-1L)}}};
static uint32_t g_151 = 0x0DD9F316L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_15(int32_t  p_16, int64_t  p_17, uint64_t  p_18, int32_t  p_19, int32_t  p_20);
static int32_t  func_34(uint64_t  p_35, const uint32_t  p_36, uint32_t  p_37, uint8_t  p_38);
static uint16_t  func_60(const int32_t  p_61);
static uint8_t  func_65(int64_t  p_66, int64_t  p_67, int16_t  p_68, uint64_t  p_69);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_22 g_23 g_30 g_33 g_42 g_29 g_45 g_46 g_52 g_102 g_108 g_110 g_151
 * writes: g_2 g_22 g_23 g_30 g_33 g_45 g_46 g_52 g_102 g_110 g_151
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_21 = 0xD6L;
    int32_t l_28 = 0L;
    uint64_t l_143 = 0xFF8D21F61EE9ED18LL;
    int64_t l_147 = 0x3F6651D59FB421CFLL;
    uint32_t l_154 = 0xDCF15C88L;
    for (g_2 = 1; (g_2 <= (-5)); g_2 = safe_sub_func_uint64_t_u_u(g_2, 3))
    { /* block id: 3 */
        uint8_t l_13 = 0x63L;
        int32_t l_14 = 0L;
        int32_t l_142 = 5L;
        l_14 = (((safe_div_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_s((g_2 , g_2), 5)) | l_13), g_2)), g_2)) | 0UL) || 0xEE4E91208373B2C5LL);
        if (func_15(((0x44L <= g_2) <= 18446744073709551609UL), l_21, l_21, g_2, l_14))
        { /* block id: 8 */
            g_23++;
            if (g_23)
                continue;
            l_28 |= (safe_mod_func_int8_t_s_s(func_15((0x90635300547507AFLL == g_2), l_13, g_2, g_2, g_23), g_23));
            ++g_30;
        }
        else
        { /* block id: 13 */
            g_33 ^= ((0xD5D51814L < g_23) < g_2);
            if (l_28)
                continue;
            if (l_28)
                continue;
        }
        if (g_33)
        { /* block id: 18 */
            const int64_t l_41 = 5L;
            l_142 &= func_34((safe_mod_func_int64_t_s_s((l_41 < (-1L)), l_14)), g_42, g_23, g_29[4][3]);
        }
        else
        { /* block id: 117 */
            int32_t l_146 = 0x270EC936L;
            ++l_143;
            g_151--;
            return g_42;
        }
    }
    return l_154;
}


/* ------------------------------------------ */
/* 
 * reads : g_22
 * writes: g_22
 */
static int32_t  func_15(int32_t  p_16, int64_t  p_17, uint64_t  p_18, int32_t  p_19, int32_t  p_20)
{ /* block id: 5 */
    g_22 = p_17;
    return g_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_45 g_33 g_29 g_2 g_46 g_52 g_102 g_108 g_23 g_110 g_30 g_42
 * writes: g_22 g_45 g_33 g_46 g_52 g_102 g_110
 */
static int32_t  func_34(uint64_t  p_35, const uint32_t  p_36, uint32_t  p_37, uint8_t  p_38)
{ /* block id: 19 */
    int16_t l_55[6][10] = {{1L,(-3L),0x2A77L,(-3L),1L,0L,(-7L),0x99C8L,1L,6L},{(-7L),(-2L),6L,0L,0xB109L,0x0A04L,0x0A04L,0xB109L,0L,6L},{0L,0L,(-1L),6L,1L,0xBBA6L,0xB109L,0x2A77L,(-1L),(-1L)},{0x2A77L,0x3B30L,0xB109L,1L,(-3L),1L,0xB109L,0x3B30L,0x2A77L,0L},{(-2L),0L,(-1L),1L,(-1L),0x8E04L,0x0A04L,(-3L),(-3L),0x0A04L},{0x3B30L,(-2L),1L,1L,(-2L),0x3B30L,(-7L),0x8E04L,0x2A77L,0xBBA6L}};
    int32_t l_141 = (-6L);
    int i, j;
    for (g_22 = 0; (g_22 >= (-7)); --g_22)
    { /* block id: 22 */
        uint8_t l_121 = 0xA9L;
        g_45 ^= 2L;
        for (g_33 = 5; (g_33 >= 1); g_33 -= 1)
        { /* block id: 26 */
            int32_t l_51[9][9] = {{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L),(-1L),0xE412C219L,(-1L)},{(-1L),0xE412C219L,(-1L),0x149088B5L,(-1L),0x149088B5L,0x149088B5L,(-1L),0x149088B5L}};
            int i, j;
            g_46 = (1UL || 0L);
            g_52 = ((safe_mod_func_int8_t_s_s((safe_mul_func_int16_t_s_s((g_29[(g_33 + 2)][g_33] < l_51[4][5]), 0L)), g_2)) || g_29[(g_33 + 2)][g_33]);
            l_55[3][0] = (safe_add_func_int64_t_s_s(0x0F4EB9534DD9CEC6LL, 0xC8A038AA138A8004LL));
            l_121 = (safe_add_func_int32_t_s_s((safe_rshift_func_uint16_t_u_u(func_60(p_36), g_42)), 0x15E26FEEL));
        }
    }
    if (((safe_mul_func_int16_t_s_s((safe_mod_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(0x84L, p_36)), g_29[4][2])), 65535UL)) && l_55[3][0]))
    { /* block id: 91 */
        uint16_t l_135 = 65535UL;
lbl_130:
        for (p_35 = 0; (p_35 <= 7); p_35 += 1)
        { /* block id: 94 */
            return g_110;
        }
        for (g_33 = 0; (g_33 == 12); g_33 = safe_add_func_int8_t_s_s(g_33, 8))
        { /* block id: 99 */
            uint64_t l_136 = 1UL;
            if (p_36)
                goto lbl_130;
            g_52 |= ((((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_u(0xD46BL, g_22)), l_135)) <= 0xEE130BC2C7D6A203LL) == 0UL) && l_135);
            l_136--;
        }
        for (g_110 = (-10); (g_110 > 25); g_110 = safe_add_func_uint64_t_u_u(g_110, 5))
        { /* block id: 106 */
            l_141 &= p_35;
            return l_55[1][4];
        }
    }
    else
    { /* block id: 110 */
        l_141 = l_55[3][0];
        l_141 = (g_102 ^ p_38);
        g_52 = g_45;
    }
    return g_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_46 g_29 g_2 g_52 g_22 g_102 g_33 g_108 g_23 g_110 g_30 g_42
 * writes: g_46 g_52 g_102 g_110
 */
static uint16_t  func_60(const int32_t  p_61)
{ /* block id: 30 */
    int32_t l_70[2][4] = {{(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L)}};
    int32_t l_120 = 0x0F736FA5L;
    int i, j;
    for (g_46 = 0; (g_46 <= 29); g_46++)
    { /* block id: 33 */
        const uint8_t l_64 = 0x47L;
        uint64_t l_116 = 0x40187A30E5935224LL;
        if (l_64)
        { /* block id: 34 */
            if (g_29[4][2])
                break;
        }
        else
        { /* block id: 36 */
            uint32_t l_111 = 1UL;
            g_110 = (func_65(l_70[0][3], g_2, l_70[0][3], p_61) , p_61);
            return l_111;
        }
        g_52 = (safe_mul_func_uint16_t_u_u(l_70[0][2], p_61));
        g_52 = (((((safe_mod_func_int64_t_s_s(l_116, l_70[0][3])) == l_70[0][0]) | g_23) <= g_102) & (-10L));
    }
    if (((p_61 , 3L) ^ g_22))
    { /* block id: 77 */
        for (g_110 = 0; (g_110 > 48); g_110++)
        { /* block id: 80 */
            int16_t l_119 = 0xB6ABL;
            return l_119;
        }
    }
    else
    { /* block id: 83 */
        return g_2;
    }
    l_120 |= g_30;
    return g_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_22 g_29 g_102 g_33 g_108 g_46
 * writes: g_52 g_102
 */
static uint8_t  func_65(int64_t  p_66, int64_t  p_67, int16_t  p_68, uint64_t  p_69)
{ /* block id: 37 */
    int64_t l_85 = 0x801DA982E55E195DLL;
    int32_t l_91 = 0xD9ACC98CL;
    int32_t l_101[8];
    int i;
    for (i = 0; i < 8; i++)
        l_101[i] = 0xCA6A3F29L;
    for (p_67 = 13; (p_67 <= (-22)); p_67 = safe_sub_func_int32_t_s_s(p_67, 1))
    { /* block id: 40 */
        uint16_t l_75 = 0x381AL;
        uint8_t l_86 = 246UL;
        if ((safe_rshift_func_uint16_t_u_s(p_68, 14)))
        { /* block id: 41 */
            if (p_69)
                break;
        }
        else
        { /* block id: 43 */
            uint16_t l_84 = 1UL;
            l_75 |= 1L;
            l_86 = ((safe_rshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_s((safe_mod_func_int16_t_s_s((((safe_lshift_func_int16_t_s_s((l_84 , 0x70FBL), l_75)) , l_85) == (-1L)), p_67)), l_75)), g_52)) && 0x93945F7E1E514D86LL);
            g_52 |= (safe_add_func_uint32_t_u_u(1UL, 0x8B1902DEL));
            l_91 = (safe_sub_func_uint32_t_u_u((g_22 , 0xB52D1A88L), 0UL));
        }
        g_52 = (safe_mod_func_int8_t_s_s(((safe_sub_func_uint8_t_u_u((safe_div_func_uint8_t_u_u(l_85, 0x53L)), 0x0CL)) == 1UL), 0x65L));
        for (l_91 = 5; (l_91 >= 2); l_91 -= 1)
        { /* block id: 52 */
            int32_t l_100 = (-1L);
            int i, j;
            l_100 &= (safe_mul_func_int16_t_s_s(g_29[l_91][l_91], p_69));
            l_101[6] = (p_66 , p_69);
            g_102--;
        }
        if (((g_33 ^ g_29[0][3]) ^ 0x58L))
        { /* block id: 57 */
            uint32_t l_105 = 0xEEF21D7AL;
            l_101[4] = ((((l_86 != 0xA7386F5C60D0FB0CLL) & g_33) , 0x00L) ^ l_105);
            return l_105;
        }
        else
        { /* block id: 60 */
            g_52 ^= l_86;
            g_52 = (((l_86 & 0x4EL) , g_29[4][3]) ^ p_67);
        }
    }
    for (p_67 = 7; (p_67 >= 2); p_67 -= 1)
    { /* block id: 67 */
        uint64_t l_109[4][2] = {{0UL,1UL},{0UL,0UL},{1UL,0UL},{0UL,1UL}};
        int i, j;
        l_101[p_67] = (safe_mod_func_uint16_t_u_u((((((p_66 == g_108) >= 0xC00EL) & g_46) , 9UL) ^ l_101[3]), l_109[3][0]));
    }
    return p_66;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_29[i][j], "g_29[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_150[i][j][k], "g_150[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_151, "g_151", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 70
   depth: 2, occurrence: 19
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 4
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 3
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 101
XXX times a non-volatile is write: 44
XXX times a volatile is read: 12
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 67
XXX percentage of non-volatile access: 90.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 72
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 21
   depth: 2, occurrence: 37

XXX percentage a fresh-made variable is used: 31.5
XXX percentage an existing variable is used: 68.5
********************* end of statistics **********************/

