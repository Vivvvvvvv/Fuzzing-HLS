/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      479306375084608488
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x8CFF0EA7L;
static int32_t g_6 = 1L;
static uint32_t g_21 = 0xE2DB80EBL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint64_t  func_14(int16_t  p_15, const int32_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_21
 * writes: g_2 g_6 g_21
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_7 = 0UL;
    int32_t l_25 = (-1L);
    for (g_2 = (-18); (g_2 == 7); ++g_2)
    { /* block id: 3 */
        int32_t l_11[5] = {0x407858F9L,0x407858F9L,0x407858F9L,0x407858F9L,0x407858F9L};
        uint32_t l_24 = 0x8407374FL;
        int i;
        if ((0UL && g_2))
        { /* block id: 4 */
            int32_t l_5 = 0L;
            int32_t l_10 = 0x285CE96BL;
            if (g_2)
                break;
            g_6 = l_5;
            l_7 &= l_5;
            l_10 ^= (safe_mul_func_uint16_t_u_u(l_5, 0xD26EL));
        }
        else
        { /* block id: 9 */
            return l_11[1];
        }
        g_21 = (safe_add_func_uint64_t_u_u(func_14((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(g_6, 1)), 7)), g_6), 4UL));
        l_11[1] = l_7;
        l_25 = (safe_sub_func_uint64_t_u_u(0x57F39CEE24B2E809LL, l_24));
    }
    return g_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes: g_6
 */
static uint64_t  func_14(int16_t  p_15, const int32_t  p_16)
{ /* block id: 12 */
    g_6 &= (p_16 == 0x24B5L);
    return g_6;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 5
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 14
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 4
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 38.1
XXX percentage an existing variable is used: 61.9
********************* end of statistics **********************/

