/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8631566018709211023
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_2[5] = {0x7FD5L,0x7FD5L,0x7FD5L,0x7FD5L,0x7FD5L};
static int32_t g_5 = 0xA6B950BAL;
static int32_t g_6[6] = {0L,0L,0L,0L,0L,0L};
static volatile uint8_t g_15[2] = {0x41L,0x41L};
static int32_t g_34[1] = {0x725AC950L};
static int32_t g_35 = (-8L);


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_2 g_5 g_34 g_6 g_35
 * writes: g_15 g_6 g_35
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_3 = (-6L);
    int32_t l_4 = 0x82BD7B1CL;
    int32_t l_7 = 0xFA5FEF9DL;
    int32_t l_8 = 0xC36544D1L;
    int32_t l_9 = 2L;
    int32_t l_10 = (-1L);
    int32_t l_11 = 0xCFAF425FL;
    int32_t l_12 = 1L;
    int32_t l_13[2];
    int32_t l_14 = 0x403CA955L;
    int i;
    for (i = 0; i < 2; i++)
        l_13[i] = 8L;
    g_15[1]--;
    g_6[4] = ((g_2[4] , (-5L)) != l_11);
    for (l_10 = 0; (l_10 <= (-10)); l_10 = safe_sub_func_int8_t_s_s(l_10, 2))
    { /* block id: 5 */
        int32_t l_24[9] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
        int32_t l_36[5];
        int i;
        for (i = 0; i < 5; i++)
            l_36[i] = 0xCCB4F7BCL;
        l_24[4] = (safe_sub_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_u(9UL, 0)) , g_5), 8UL));
        g_35 |= (safe_lshift_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((!l_7), g_34[0])), 12)), g_6[2])), g_5));
        l_36[0] |= g_2[3];
    }
    return l_13[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_15[i], "g_15[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_35, "g_35", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 5
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 93.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 14.9
XXX percentage an existing variable is used: 85.1
********************* end of statistics **********************/

