/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10968532919069772568
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const volatile uint16_t  f0;
   uint32_t  f1;
   volatile int32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static int32_t g_3[3][3][9] = {{{0x4DCC80FCL,1L,0x95A97963L,0xB666A756L,0xDD78F4F8L,0x4DCC80FCL,(-1L),0xAD38DC53L,0xAD38DC53L},{7L,(-1L),0x4C000111L,0xAD38DC53L,0x4C000111L,(-1L),7L,0xE2167FA5L,0xAD38DC53L},{(-7L),0x3367F5EDL,0x1C3C39BAL,4L,0L,0L,0x3367F5EDL,1L,0x4DCC80FCL}},{{0L,0L,4L,0x1C3C39BAL,0x3367F5EDL,(-7L),0xE2167FA5L,0xE2167FA5L,(-7L)},{(-1L),0x4C000111L,0xAD38DC53L,0x4C000111L,(-1L),7L,0xE2167FA5L,0xAD38DC53L,4L},{0x4DCC80FCL,0x3AAF5BFBL,0x3367F5EDL,4L,0xF14EB4C8L,0L,3L,1L,0xDD78F4F8L}},{{0xE2167FA5L,0x4DCC80FCL,1L,1L,1L,4L,4L,1L,1L},{0x95A97963L,(-1L),0x95A97963L,0L,1L,0xB666A756L,(-1L),0x6D4A0D46L,0x1C3C39BAL},{0xAD38DC53L,0L,(-7L),0x95A97963L,0xF14EB4C8L,(-10L),0x1C3C39BAL,1L,0xB666A756L}}};
static volatile int32_t g_6 = 1L;/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7 = 0x509CB0BEL;/* VOLATILE GLOBAL g_7 */
static volatile int32_t g_8 = (-1L);/* VOLATILE GLOBAL g_8 */
static volatile int32_t g_9 = 1L;/* VOLATILE GLOBAL g_9 */
static int32_t g_10 = 1L;
static uint32_t g_60[6] = {4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL,4294967286UL};
static int16_t g_72 = 9L;
static uint64_t g_79 = 0xDA17685C1309E202LL;
static volatile uint16_t g_89[7][2][6] = {{{9UL,0xBFDDL,0xEBF9L,0xBFDDL,9UL,0x36E8L},{0UL,65535UL,0x4987L,1UL,0xEBF9L,0x0335L}},{{0x4987L,0x2B76L,9UL,65535UL,0x54D7L,0x0335L},{0x36E8L,0xE731L,0x4987L,0x4987L,0xE731L,0x36E8L}},{{0x54D7L,0xC3A2L,0xEBF9L,0xDB76L,0UL,0xE731L},{0xC3A2L,9UL,0UL,0UL,0x8973L,0xDF77L}},{{0xC3A2L,1UL,0UL,0xDB76L,0UL,1UL},{0x54D7L,0UL,65535UL,0x4987L,1UL,0xEBF9L}},{{0x36E8L,0xB771L,0xDB76L,65535UL,0x0335L,0UL},{0x4987L,0xB771L,0x2B76L,1UL,1UL,0x2B76L}},{{0UL,0UL,0xB771L,0xBFDDL,0UL,0xC3A2L},{9UL,1UL,0xDF77L,0x36E8L,0x8973L,0xB771L}},{{0x0335L,9UL,0xDF77L,0xC3A2L,0UL,0xC3A2L},{0xB771L,0xC3A2L,0xB771L,0xEBF9L,0xE731L,0x2B76L}}};
static int8_t g_110[5] = {0x36L,0x36L,0x36L,0x36L,0x36L};
static struct S0 g_119 = {0xC539L,0x159496D9L,0xF2D2C60FL};/* VOLATILE GLOBAL g_119 */


/* --- FORWARD DECLARATIONS --- */
static const struct S0  func_1(void);
static int8_t  func_16(uint32_t  p_17);
static uint32_t  func_20(int8_t  p_21, int8_t  p_22, const uint64_t  p_23, int8_t  p_24);
static int32_t  func_27(uint32_t  p_28, uint32_t  p_29, uint64_t  p_30, int16_t  p_31);
static uint32_t  func_32(int32_t  p_33);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_10 g_8 g_7 g_2 g_6 g_9 g_60 g_72 g_79 g_89 g_110 g_119
 * writes: g_3 g_10 g_60 g_6 g_72 g_79 g_2 g_89 g_110 g_119.f2
 */
static const struct S0  func_1(void)
{ /* block id: 0 */
    const uint64_t l_25 = 0xBBE26B5CFDA6C2E3LL;
    const uint8_t l_135 = 255UL;
    for (g_3[2][0][5] = 0; (g_3[2][0][5] >= 17); g_3[2][0][5] = safe_add_func_uint16_t_u_u(g_3[2][0][5], 4))
    { /* block id: 3 */
        uint16_t l_13 = 0x5C0DL;
        for (g_10 = (-8); (g_10 <= (-26)); --g_10)
        { /* block id: 6 */
            uint32_t l_83[8][9] = {{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L,0x5AAB3741L}};
            int32_t l_136 = 4L;
            int i, j;
            l_13--;
            l_136 = ((func_16(((((safe_div_func_uint32_t_u_u(func_20(g_8, g_10, l_25, g_10), l_25)) , g_72) | l_83[7][0]) || 1UL)) , l_13) && l_135);
        }
    }
    if (((((((0xFBL && l_25) & 4294967295UL) > 5UL) || 1L) | 0xE557E69CL) && g_110[4]))
    { /* block id: 95 */
        uint32_t l_139 = 0xE31D69C6L;
        l_139 = (safe_rshift_func_int16_t_s_s(0x8E13L, 12));
    }
    else
    { /* block id: 97 */
        uint32_t l_140 = 1UL;
        l_140 = g_79;
    }
    g_119.f2 = g_89[3][1][3];
    return g_119;
}


/* ------------------------------------------ */
/* 
 * reads : g_89 g_10 g_3 g_60 g_6 g_110 g_119 g_79 g_2 g_72
 * writes: g_89 g_6 g_110 g_2 g_72
 */
static int8_t  func_16(uint32_t  p_17)
{ /* block id: 47 */
    int8_t l_84 = 0x67L;
    int32_t l_85 = (-1L);
    int32_t l_86 = 0x33FD7079L;
    int32_t l_87 = 0L;
    int32_t l_88[2][7];
    int64_t l_101 = 0x41F08C6B94EFEA99LL;
    uint16_t l_109 = 0x0D59L;
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
            l_88[i][j] = 0x0F6DB6A2L;
    }
lbl_130:
    --g_89[3][1][3];
lbl_133:
    if ((safe_rshift_func_int8_t_s_s((safe_mod_func_int8_t_s_s((0x86CBL ^ g_10), l_84)), 1)))
    { /* block id: 49 */
        int64_t l_96[4];
        int32_t l_97 = 0xE75BA722L;
        uint64_t l_98 = 0x916B1FF0AA6A4DFBLL;
        uint8_t l_102 = 0xAEL;
        int i;
        for (i = 0; i < 4; i++)
            l_96[i] = 0xCA7106077EAAE7FFLL;
        --l_98;
        if (((l_98 || 0xE41B645FL) , 0xA0BC11C5L))
        { /* block id: 51 */
            g_6 = ((((g_3[2][0][5] != p_17) , 4294967295UL) < 0xC725F569L) >= g_60[2]);
        }
        else
        { /* block id: 53 */
            l_102 = l_101;
        }
    }
    else
    { /* block id: 56 */
        uint32_t l_107 = 9UL;
lbl_112:
        for (p_17 = 0; (p_17 != 8); ++p_17)
        { /* block id: 59 */
            int16_t l_108 = 0x66E0L;
            int32_t l_111[6] = {1L,1L,1L,1L,1L,1L};
            int i;
            g_110[0] ^= ((((safe_div_func_int32_t_s_s(l_107, g_6)) != l_108) || l_109) == l_108);
            if (l_108)
                goto lbl_112;
            l_111[4] = 0L;
        }
        return l_107;
    }
    for (l_87 = 4; (l_87 >= 0); l_87 -= 1)
    { /* block id: 68 */
        int32_t l_120 = 1L;
        int i;
        l_120 = (safe_mul_func_int16_t_s_s((((((((safe_lshift_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(((g_119 , g_60[l_87]) == g_3[2][0][5]), p_17)), g_119.f1)) , g_119) , p_17) && 0x55L) > 0x81L) & p_17) == g_79), g_3[0][1][0]));
        for (l_86 = 0; (l_86 <= 1); l_86 += 1)
        { /* block id: 72 */
            g_2 |= (safe_div_func_uint16_t_u_u(0xFE66L, 1L));
            l_120 = (safe_lshift_func_uint16_t_u_s(0x2E61L, 7));
        }
        if ((g_119.f1 || l_85))
        { /* block id: 76 */
            l_86 |= (g_89[3][1][3] > l_120);
        }
        else
        { /* block id: 78 */
            int8_t l_129 = 0x5DL;
            int32_t l_131[1];
            int i;
            for (i = 0; i < 1; i++)
                l_131[i] = 0x7BBE786AL;
            l_120 = (safe_mod_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s(((g_119 , p_17) == l_129), 6)), g_119.f1));
            if (g_10)
                goto lbl_130;
            l_131[0] = l_129;
            l_131[0] = (+p_17);
        }
        for (g_72 = 4; (g_72 >= 0); g_72 -= 1)
        { /* block id: 86 */
            int32_t l_134 = (-8L);
            if (l_86)
                goto lbl_133;
            l_134 = ((((p_17 == g_110[0]) >= 1L) <= p_17) , l_134);
        }
    }
    return l_109;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_10 g_2 g_3 g_6 g_9 g_60 g_8 g_72 g_79
 * writes: g_60 g_6 g_72 g_79 g_2
 */
static uint32_t  func_20(int8_t  p_21, int8_t  p_22, const uint64_t  p_23, int8_t  p_24)
{ /* block id: 8 */
    volatile uint32_t l_26 = 0x9C79EBEFL;/* VOLATILE GLOBAL l_26 */
    int32_t l_61 = 0x0087D4E0L;
    uint64_t l_78[8][1][5] = {{{0x9DFF4590BACEAEEFLL,0x1110172C61B7CE84LL,1UL,0xDBEEE9A18863885ELL,0xF0AA60CB97C0B8F9LL}},{{6UL,0x2FCBA4768E4F1A1ELL,0x2FCBA4768E4F1A1ELL,6UL,0x1110172C61B7CE84LL}},{{0xF0AA60CB97C0B8F9LL,0x2FCBA4768E4F1A1ELL,0x8D4FF7D934358B78LL,0UL,6UL}},{{0xDBEEE9A18863885ELL,0x1110172C61B7CE84LL,0xF0AA60CB97C0B8F9LL,0x8CF631B5FDDB2789LL,0x57EB90776C5754D5LL}},{{0x8D4FF7D934358B78LL,8UL,0xEF1402E7910ABA4BLL,0UL,0UL}},{{8UL,0xDBEEE9A18863885ELL,8UL,6UL,0x503A7054D2AC3227LL}},{{8UL,18446744073709551615UL,0x8CF631B5FDDB2789LL,0xDBEEE9A18863885ELL,0xD8BAA40D6DD5741ELL}},{{0x8D4FF7D934358B78LL,0xEF1402E7910ABA4BLL,0x1110172C61B7CE84LL,0x2FCBA4768E4F1A1ELL,18446744073709551615UL}}};
    int16_t l_82 = 1L;
    int i, j, k;
    l_26 = g_7;
    g_72 ^= func_27(func_32(g_10), l_61, g_3[2][0][5], l_61);
    g_79 &= (safe_mul_func_int16_t_s_s((safe_mod_func_int32_t_s_s((((~p_23) != g_2) < p_21), 0x07418113L)), l_78[3][0][1]));
    for (p_21 = 0; (p_21 >= (-9)); --p_21)
    { /* block id: 43 */
        g_2 = ((((6L && g_9) || 1L) <= l_82) , p_22);
    }
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_6 g_8 g_60 g_3
 * writes: g_6
 */
static int32_t  func_27(uint32_t  p_28, uint32_t  p_29, uint64_t  p_30, int16_t  p_31)
{ /* block id: 31 */
    uint8_t l_68 = 255UL;
    int32_t l_71 = 0xCE6FA973L;
    if ((g_7 || 0xECCD2826L))
    { /* block id: 32 */
        uint32_t l_69 = 0x92AC9E04L;
        int32_t l_70[6][6] = {{0L,0L,0x5AEF2735L,0xE5B73647L,0x5AEF2735L,0L},{0x5AEF2735L,0x312ED856L,0xE5B73647L,0xE5B73647L,0x312ED856L,0x5AEF2735L},{0L,0x5AEF2735L,0xE5B73647L,0x5AEF2735L,0L,0L},{(-1L),0x5AEF2735L,0x5AEF2735L,(-1L),0x312ED856L,(-1L)},{(-1L),0x312ED856L,(-1L),0x5AEF2735L,0x5AEF2735L,(-1L)},{0L,0L,0x5AEF2735L,0xE5B73647L,0x5AEF2735L,0L}};
        int i, j;
        l_70[1][2] = (((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_int16_t_s_u((((safe_div_func_int16_t_s_s(((((g_6 , g_8) > 0x8F9F05BB7EAB3286LL) && l_68) >= l_69), 5UL)) || (-8L)) && 0L), 4)) <= g_60[1]), g_3[2][1][6])) != 0x9BL) | (-5L));
    }
    else
    { /* block id: 34 */
        g_6 = 0x7717E41AL;
    }
    l_71 |= (p_30 < 0xB082L);
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_6 g_9 g_10 g_60
 * writes: g_60
 */
static uint32_t  func_32(int32_t  p_33)
{ /* block id: 10 */
    int16_t l_44 = 0L;
    int32_t l_51 = 4L;
    if ((safe_mod_func_int16_t_s_s((safe_add_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((safe_add_func_uint32_t_u_u((0x7A2EL <= p_33), l_44)), p_33)), g_2)), g_3[2][0][5])), 0xA3BBL)))
    { /* block id: 11 */
        int8_t l_45 = (-1L);
        int32_t l_53[8][6][1] = {{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}},{{0x4264A3A2L},{(-1L)},{(-1L)},{0x4264A3A2L},{(-1L)},{(-1L)}}};
        uint32_t l_55 = 4294967295UL;
        int i, j, k;
        if ((((l_45 , g_6) && 0xEC6CL) , l_44))
        { /* block id: 12 */
            uint32_t l_46 = 4294967295UL;
            l_46 = 0x8071081BL;
        }
        else
        { /* block id: 14 */
            l_51 = ((safe_lshift_func_int16_t_s_u(((safe_mod_func_uint32_t_u_u((l_44 , l_44), g_9)) <= 0x8B7DD1456014EFC7LL), p_33)) || p_33);
            l_51 |= (!0x0989L);
        }
        if (l_45)
            goto lbl_54;
        if (g_9)
        { /* block id: 18 */
lbl_54:
            l_53[0][4][0] = p_33;
            return l_55;
        }
        else
        { /* block id: 22 */
            uint16_t l_58[7][5][7] = {{{1UL,65526UL,1UL,1UL,0x7921L,0x8F8DL,0x000BL},{0UL,0xBE56L,0UL,6UL,1UL,1UL,0UL},{0UL,1UL,0x000BL,0x7921L,6UL,0x8F8DL,65535UL},{4UL,0x83ADL,0x2260L,4UL,0x34CEL,0xCABDL,65535UL},{1UL,65535UL,0xB8F5L,0UL,0UL,0xB8F5L,65535UL}},{{0x34CEL,0x2B2FL,65535UL,0x38D5L,0x2260L,65535UL,6UL},{0x8F8DL,1UL,1UL,1UL,1UL,1UL,6UL},{0xDEEAL,65535UL,65533UL,4UL,0xCABDL,0xBE56L,0x6EF3L},{1UL,3UL,0x0ABBL,1UL,1UL,0x8F04L,1UL},{0x4DC4L,4UL,65529UL,65529UL,4UL,0x4DC4L,2UL}},{{0x000BL,6UL,65526UL,0UL,0x8F8DL,1UL,0UL},{6UL,0x7A84L,0xBCD5L,0x2B2FL,2UL,0xDB59L,0xDEEAL},{1UL,6UL,0xB8F5L,0x8F04L,0x000BL,0x0ABBL,1UL},{0x2260L,4UL,0x34CEL,0xCABDL,65535UL,6UL,65535UL},{6UL,3UL,3UL,6UL,0xA4BDL,1UL,1UL}},{{0xC351L,65535UL,0x4DC4L,0xBCD5L,6UL,0x4DC4L,0UL},{1UL,65535UL,0x1475L,0xD3E8L,1UL,1UL,1UL},{65535UL,0xC351L,0xBCD5L,0x6EF3L,0xDB59L,1UL,65535UL},{4UL,0x8F8DL,1UL,0xC2E3L,0UL,0xC2E3L,1UL},{65535UL,65535UL,0x83ADL,6UL,65535UL,0UL,0xDEEAL}},{{1UL,0xC2E3L,0x0ABBL,6UL,0xC2E3L,4UL,0UL},{0xDB59L,0x2260L,0xC351L,2UL,65535UL,0UL,2UL},{1UL,0UL,1UL,1UL,0UL,0x1475L,1UL},{0x6EF3L,65529UL,0xDB59L,0x2B2FL,0xDB59L,65529UL,0x6EF3L},{0x0ABBL,0xD3E8L,4UL,0x1CA9L,1UL,0xB8F5L,3UL}},{{0x2260L,65535UL,6UL,0x2260L,6UL,1UL,0x2B2FL},{65535UL,1UL,4UL,1UL,0xA4BDL,4UL,0x8F8DL},{0xBCD5L,0x6EF3L,0xDB59L,1UL,65535UL,65532UL,65532UL},{0x000BL,65535UL,1UL,65535UL,0x000BL,0UL,1UL},{0xDEEAL,0UL,0xC351L,4UL,2UL,1UL,0x6EF3L}},{{3UL,1UL,0x0ABBL,0xA4BDL,0x8F8DL,0x8F04L,4UL},{0xDEEAL,4UL,0x83ADL,0x2260L,4UL,0x34CEL,0xCABDL},{0x000BL,0x0ABBL,1UL,0UL,1UL,1UL,0UL},{0xBCD5L,0xCF19L,0xBCD5L,65532UL,0xCABDL,0xDB59L,0x4DC4L},{65535UL,6UL,1UL,1UL,4UL,1UL,0UL}}};
            int32_t l_59[4];
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_59[i] = 0x86F270ADL;
            l_59[0] = (((safe_mul_func_int16_t_s_s(g_3[2][1][7], l_58[1][3][0])) == g_9) && 1L);
            l_53[5][4][0] &= ((l_59[0] & g_2) <= 0L);
        }
    }
    else
    { /* block id: 26 */
        g_60[1] = (g_9 || g_10);
        return g_60[5];
    }
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_3[i][j][k], "g_3[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_60[i], "g_60[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_89[i][j][k], "g_89[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_110[i], "g_110[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_119.f0, "g_119.f0", print_hash_value);
    transparent_crc(g_119.f1, "g_119.f1", print_hash_value);
    transparent_crc(g_119.f2, "g_119.f2", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 46
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 60
   depth: 2, occurrence: 15
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 6
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 88
XXX times a non-volatile is write: 33
XXX times a volatile is read: 18
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 62
XXX percentage of non-volatile access: 82.9

XXX forward jumps: 2
XXX backward jumps: 2

XXX stmts: 60
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 19
   depth: 2, occurrence: 23

XXX percentage a fresh-made variable is used: 30.3
XXX percentage an existing variable is used: 69.7
********************* end of statistics **********************/

