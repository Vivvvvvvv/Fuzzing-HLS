/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15798633962307245302
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_4[9][3][8] = {{{65535UL,0x6C31L,0x91DFL,0x9892L,0x3672L,1UL,65535UL,5UL},{0x6C31L,0xFA75L,65533UL,0UL,2UL,0x9892L,0xFA32L,2UL},{0x19C5L,0x9EA4L,0x3D78L,0x19C5L,6UL,0xFBB6L,5UL,0xFA32L}},{{1UL,0xF467L,0x491EL,2UL,0x3672L,2UL,0x491EL,0xF467L},{0x9EA4L,0x3037L,0x9892L,3UL,65533UL,65535UL,0UL,65535UL},{0xFA32L,0x9EA4L,4UL,0x72C2L,0x9EA4L,0x449CL,65535UL,1UL}},{{0x714FL,65535UL,0x654FL,0xDFE0L,0xFA75L,65534UL,4UL,0x3037L},{0xFA75L,65534UL,4UL,0x3037L,0x654FL,0x3D78L,0x491EL,0xDF60L},{65535UL,2UL,0x19C5L,65535UL,65535UL,0x19C5L,2UL,65535UL}},{{0xFBB6L,0x3037L,0x1591L,4UL,2UL,65526UL,0xFCC5L,65533UL},{0xFA75L,0xD2D1L,0xDF60L,1UL,4UL,65526UL,65535UL,0x654FL},{0x491EL,0x3037L,0x6C31L,0x9892L,0x0302L,0x19C5L,0x9892L,1UL}},{{0x654FL,2UL,0xD2D1L,0xFBB6L,0x91DFL,0x3D78L,65534UL,0x491EL},{0x0302L,65534UL,0xDF60L,2UL,0xDF60L,65534UL,0x0302L,0x714FL},{65535UL,65535UL,0x3672L,65535UL,1UL,6UL,2UL,1UL}},{{0x449CL,0x0302L,0xFCC5L,0x449CL,1UL,0xDFE0L,0x714FL,2UL},{65535UL,65526UL,4UL,1UL,0xDF60L,0xD2D1L,0xFA75L,65526UL},{0x0302L,65533UL,6UL,0xFA75L,0x91DFL,0xF467L,65535UL,65535UL}},{{0x654FL,0x0302L,0x3D78L,0x3D78L,0x0302L,0x654FL,0xFBB6L,1UL},{0x491EL,0x3D78L,0x654FL,0x3037L,4UL,65534UL,0xFA75L,0xDFE0L},{0xFA75L,65535UL,0x72C2L,0x3037L,2UL,0x9EA4L,0x491EL,1UL}},{{0xFBB6L,2UL,0xFCC5L,0x3D78L,65535UL,0xFCC5L,0x654FL,65535UL},{65535UL,0xDFE0L,0x1591L,0xFA75L,0x654FL,65526UL,0x0302L,65526UL},{0xFA75L,1UL,5UL,1UL,0xFA75L,0x901FL,65535UL,2UL}},{{0x714FL,0x3037L,0xD2D1L,0x449CL,0x0302L,0xFCC5L,0x449CL,1UL},{2UL,0x654FL,0xD2D1L,65535UL,0x1591L,0x3D78L,65535UL,0x714FL},{0x0302L,65535UL,5UL,2UL,1UL,0UL,0x0302L,0x491EL}}};
static volatile uint8_t g_10[6] = {0x8CL,246UL,0x8CL,0x8CL,246UL,0x8CL};
static volatile uint32_t g_42[6][7][3] = {{{0x84125DBFL,0x7E8F5349L,0x84125DBFL},{0UL,18446744073709551615UL,0UL},{0x84125DBFL,0x7E8F5349L,0x84125DBFL},{0UL,18446744073709551615UL,0UL},{0x84125DBFL,0x7E8F5349L,0x84125DBFL},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L}},{{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL}},{{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L}},{{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL}},{{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L}},{{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL},{0x2EE8B720L,0x84125DBFL,0x2EE8B720L},{0UL,0xB5A40A7BL,0UL}}};
static int64_t g_43[4][7][3] = {{{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L}},{{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L}},{{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L}},{{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,(-1L),9L},{9L,9L,(-10L)},{(-10L),9L,(-10L)}}};
static uint8_t g_45 = 249UL;
static uint64_t g_47 = 0x9E5F9C6A002B50D2LL;
static uint64_t g_51 = 0x93506F8A133A5B7DLL;
static int8_t g_52 = 1L;
static volatile int32_t g_53[7] = {(-4L),0x4A47BFE1L,(-4L),(-4L),0x4A47BFE1L,(-4L),(-4L)};
static int16_t g_58 = 0x3FE6L;
static uint64_t g_59 = 0UL;
static uint64_t g_64 = 18446744073709551615UL;
static int64_t g_77 = 0xE8F98891C1AAD5EALL;
static int64_t g_94 = 8L;
static volatile int64_t g_95 = 0x16D66C253094EEE5LL;/* VOLATILE GLOBAL g_95 */
static uint32_t g_100[1][1][9] = {{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}}};
static volatile int64_t g_103[8][8] = {{0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL,0xCAF5201FEAE78DF1LL,0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL,0xCAF5201FEAE78DF1LL,0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL},{0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL},{0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL},{0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL,0xCAF5201FEAE78DF1LL,0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL,0xCAF5201FEAE78DF1LL,0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL},{0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL},{0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL},{0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL,0xCAF5201FEAE78DF1LL,0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL,0xCAF5201FEAE78DF1LL,0xAE1B8E030C7048B0LL,0xAE1B8E030C7048B0LL},{0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL,0x1FF20F69DBBC9484LL,0x1FF20F69DBBC9484LL,0xAE1B8E030C7048B0LL}};
static volatile int32_t g_104 = 0x11FF246FL;/* VOLATILE GLOBAL g_104 */
static int16_t g_107 = 8L;
static volatile uint32_t g_108 = 4294967286UL;/* VOLATILE GLOBAL g_108 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(uint8_t  p_3);
static int32_t  func_13(int32_t  p_14, int64_t  p_15, const int64_t  p_16);
static uint8_t  func_19(uint64_t  p_20, uint16_t  p_21);
static int32_t  func_35(const int32_t  p_36, int8_t  p_37, const uint64_t  p_38, uint32_t  p_39);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_45 g_42 g_59 g_43 g_51 g_58 g_53 g_94 g_108
 * writes: g_10 g_42 g_43 g_45 g_47 g_51 g_52 g_59 g_64 g_77 g_94 g_95 g_100 g_108
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9 = 1L;
    int32_t l_101 = 0x9328501DL;
    int32_t l_102 = 4L;
    int32_t l_105 = (-1L);
    int32_t l_106 = 0x9B4FE2E8L;
    l_9 = func_2(g_4[5][2][5]);
    g_10[2]--;
    g_100[0][0][7] = func_13(((safe_lshift_func_uint16_t_u_u(func_2((func_19((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(g_4[6][2][1], l_9)), g_10[4])), l_9) < g_4[5][2][5])), 8)) || 0x5ABE1694L), l_9, g_4[5][2][5]);
    g_108--;
    return g_53[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static int32_t  func_2(uint8_t  p_3)
{ /* block id: 1 */
    uint64_t l_7 = 8UL;
    int32_t l_8 = 0L;
    l_8 = (safe_mod_func_uint32_t_u_u(l_7, p_3));
    return g_4[4][1][4];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_13(int32_t  p_14, int64_t  p_15, const int64_t  p_16)
{ /* block id: 37 */
    int8_t l_98 = 0x26L;
    int8_t l_99 = 0x82L;
    l_98 = (((safe_mod_func_uint32_t_u_u(0xA8E06690L, 0x389381DCL)) <= p_15) ^ 0UL);
    l_99 = (-1L);
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_45 g_42 g_59 g_43 g_51 g_58 g_53 g_94
 * writes: g_42 g_43 g_45 g_47 g_51 g_52 g_59 g_64 g_77 g_94 g_95
 */
static uint8_t  func_19(uint64_t  p_20, uint16_t  p_21)
{ /* block id: 6 */
    uint16_t l_26 = 65534UL;
    uint8_t l_34[10] = {0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL,0x2BL};
    int32_t l_54[1][6] = {{2L,(-7L),2L,2L,(-7L),2L}};
    int i, j;
    l_26 ^= p_21;
    for (p_20 = 13; (p_20 < 55); p_20++)
    { /* block id: 10 */
        int16_t l_46 = 0xF79CL;
        uint8_t l_50 = 0xA6L;
        if ((safe_add_func_uint8_t_u_u((!(safe_mod_func_uint16_t_u_u((l_34[2] > g_4[6][1][1]), 0x63C1L))), p_20)))
        { /* block id: 11 */
            g_45 &= func_35((safe_lshift_func_uint16_t_u_u(((g_4[8][2][0] || g_4[5][2][5]) <= g_4[4][1][0]), p_21)), l_34[2], l_34[2], p_20);
            g_47 = (((((p_21 , 0x95L) > p_20) <= l_46) , p_21) < p_20);
            g_51 = ((((safe_sub_func_uint64_t_u_u(g_42[5][2][2], l_50)) < p_21) == p_20) , p_20);
        }
        else
        { /* block id: 19 */
            uint32_t l_55 = 7UL;
            g_52 = 0xBDA2DD44L;
            --l_55;
            --g_59;
            if (g_59)
                continue;
        }
        g_64 = (safe_mod_func_uint32_t_u_u(p_21, g_42[5][2][2]));
        if (g_43[0][3][0])
        { /* block id: 26 */
            int32_t l_74 = 0xE23F1199L;
            l_54[0][3] = ((safe_add_func_uint64_t_u_u(((safe_div_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((safe_add_func_uint16_t_u_u((+(((g_51 > g_58) && 0x6FL) && l_34[2])), l_54[0][4])), l_50)), l_46)) , g_53[6]), p_21)) < l_74);
            l_54[0][4] = (((safe_mul_func_uint16_t_u_u(0xD0E4L, p_21)) <= l_26) , p_20);
        }
        else
        { /* block id: 29 */
            g_77 = l_46;
            l_54[0][0] = ((safe_rshift_func_uint16_t_u_u(0xAD0BL, p_21)) != p_21);
            g_94 ^= (safe_lshift_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u((((safe_mod_func_uint32_t_u_u(((((safe_mod_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((0x8C1355B5L > g_53[3]), l_50)), p_21)), p_21)) , l_34[3]) && p_20) == 0x4931B730L), 1UL)) , g_53[5]) >= 0x3D079042L), 2)), g_45)), 14));
            g_95 = 0x878DFE85L;
        }
    }
    return g_43[2][1][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_10
 * writes: g_42 g_43
 */
static int32_t  func_35(const int32_t  p_36, int8_t  p_37, const uint64_t  p_38, uint32_t  p_39)
{ /* block id: 12 */
    uint32_t l_44 = 4294967295UL;
    g_42[5][2][2] = g_10[2];
    g_43[0][3][0] = 1L;
    return l_44;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_42[i][j][k], "g_42[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_43[i][j][k], "g_43[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_53[i], "g_53[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_100[i][j][k], "g_100[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_103[i][j], "g_103[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 37
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 41
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 58
XXX times a non-volatile is write: 20
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 34
XXX percentage of non-volatile access: 86.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 32
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 3
   depth: 2, occurrence: 13

XXX percentage a fresh-made variable is used: 37.8
XXX percentage an existing variable is used: 62.2
********************* end of statistics **********************/

