/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6853639272737051123
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-3L);
static volatile int32_t g_5 = 0x67A876E6L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = (-3L);/* VOLATILE GLOBAL g_6 */
static int32_t g_7 = 6L;
static volatile int64_t g_26[6] = {0x02891BA80278EE3FLL,0x02891BA80278EE3FLL,0x02891BA80278EE3FLL,0x02891BA80278EE3FLL,0x02891BA80278EE3FLL,0x02891BA80278EE3FLL};
static volatile uint32_t g_28 = 0UL;/* VOLATILE GLOBAL g_28 */
static uint16_t g_31[9][3] = {{5UL,0x22B6L,0x8F27L},{0UL,0x0FF6L,0x22B6L},{0UL,2UL,65534UL},{5UL,0xFC1FL,5UL},{65534UL,2UL,0UL},{0x22B6L,0x0FF6L,0UL},{0x8F27L,0x22B6L,5UL},{1UL,1UL,65534UL},{0x8F27L,65534UL,0x22B6L}};
static uint64_t g_57[8][5] = {{0x4D7D9C74E37A2E34LL,0x0D287709C18003DBLL,0x41177734166DA9A1LL,5UL,0x41177734166DA9A1LL},{0xE148CB42B08F18E0LL,0xE148CB42B08F18E0LL,0x0D287709C18003DBLL,18446744073709551615UL,0xECDE474C77A5C6A8LL},{0x4D7D9C74E37A2E34LL,0xECDE474C77A5C6A8LL,0xA53D1EDBCC772A30LL,0xF9DEAB2DD2C990B5LL,0xF9DEAB2DD2C990B5LL},{0xF9DEAB2DD2C990B5LL,1UL,0xF9DEAB2DD2C990B5LL,0x4D7D9C74E37A2E34LL,0xECDE474C77A5C6A8LL},{18446744073709551615UL,0x41177734166DA9A1LL,1UL,0x0D287709C18003DBLL,0xECDE474C77A5C6A8LL},{0xE148CB42B08F18E0LL,5UL,5UL,0xE148CB42B08F18E0LL,0xF9DEAB2DD2C990B5LL},{0xA53D1EDBCC772A30LL,0xE148CB42B08F18E0LL,1UL,0xECDE474C77A5C6A8LL,0x41177734166DA9A1LL},{0xA53D1EDBCC772A30LL,1UL,0xF9DEAB2DD2C990B5LL,1UL,0xA53D1EDBCC772A30LL}};
static volatile uint16_t g_89 = 0x4F51L;/* VOLATILE GLOBAL g_89 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_19(uint32_t  p_20, int64_t  p_21, uint16_t  p_22);
static int32_t  func_37(uint32_t  p_38, int32_t  p_39, const uint16_t  p_40, uint16_t  p_41, uint16_t  p_42);
static const int16_t  func_50(int64_t  p_51, int8_t  p_52, int8_t  p_53, uint32_t  p_54, int32_t  p_55);
static uint64_t  func_58(int8_t  p_59, uint8_t  p_60, int32_t  p_61, uint8_t  p_62, uint64_t  p_63);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_7 g_6 g_5 g_28 g_31 g_26 g_57 g_89
 * writes: g_2 g_7 g_5 g_6 g_28 g_31 g_89
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_12 = 5L;
    uint32_t l_85 = 0x50E9BCC6L;
    int32_t l_87 = (-6L);
    int32_t l_88[9] = {0x3DA59200L,3L,0x3DA59200L,3L,0x3DA59200L,3L,0x3DA59200L,3L,0x3DA59200L};
    int i;
    for (g_2 = 0; (g_2 <= (-3)); g_2 = safe_sub_func_int16_t_s_s(g_2, 9))
    { /* block id: 3 */
        uint16_t l_18 = 0x32B9L;
        for (g_7 = 0; (g_7 == (-18)); --g_7)
        { /* block id: 6 */
            int32_t l_13 = 0x4F1F13B0L;
            g_5 = (~(((~l_12) , g_6) == g_7));
            g_6 = ((g_5 | g_7) , l_13);
        }
        for (g_7 = 0; (g_7 == (-28)); g_7 = safe_sub_func_int64_t_s_s(g_7, 7))
        { /* block id: 12 */
            uint8_t l_34 = 0x9EL;
            l_18 = (safe_mul_func_uint8_t_u_u(0x2EL, l_12));
            g_31[8][0] ^= func_19(g_5, g_7, g_2);
            if (g_26[4])
                continue;
            g_5 = (((safe_mod_func_uint64_t_u_u(l_18, l_34)) & l_12) == l_12);
        }
        for (l_18 = (-10); (l_18 <= 53); ++l_18)
        { /* block id: 24 */
            return l_12;
        }
        for (g_7 = 2; (g_7 >= 0); g_7 -= 1)
        { /* block id: 29 */
            uint64_t l_45 = 1UL;
            int32_t l_86 = (-1L);
            int i, j;
            l_85 = func_37((safe_rshift_func_uint16_t_u_s((((g_31[(g_7 + 4)][g_7] , g_31[(g_7 + 4)][g_7]) & g_5) >= l_12), 12)), g_2, l_12, l_18, l_45);
            g_89--;
        }
    }
    return g_31[8][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_28
 * writes: g_28
 */
static int32_t  func_19(uint32_t  p_20, int64_t  p_21, uint16_t  p_22)
{ /* block id: 14 */
    uint32_t l_23 = 0UL;
    int32_t l_24 = 1L;
    int32_t l_25 = 0x33C017F2L;
    int32_t l_27 = 1L;
    l_23 = 0x2395E2DEL;
    --g_28;
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_57 g_7 g_26 g_31 g_5
 * writes: g_6
 */
static int32_t  func_37(uint32_t  p_38, int32_t  p_39, const uint16_t  p_40, uint16_t  p_41, uint16_t  p_42)
{ /* block id: 30 */
    int64_t l_56 = 2L;
    int32_t l_71[4] = {(-2L),(-2L),(-2L),(-2L)};
    int64_t l_72 = 0xB7F2DBF905AFB092LL;
    uint16_t l_84 = 4UL;
    int i;
    l_71[0] = (safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(((func_50(p_41, l_56, g_57[6][2], l_56, g_7) & 65529UL) && g_31[8][0]), l_56)), p_38));
    l_71[0] &= (l_72 == g_5);
    for (l_56 = 13; (l_56 > 13); l_56++)
    { /* block id: 41 */
        uint32_t l_83 = 4UL;
        p_39 = (safe_rshift_func_int16_t_s_s((((safe_add_func_int8_t_s_s((safe_rshift_func_int8_t_s_u(((safe_mod_func_uint16_t_u_u(65528UL, 65533UL)) < g_31[8][0]), 1)), p_42)) != l_83) == l_83), 14));
    }
    g_6 = l_84;
    return p_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_57 g_26 g_31 g_5
 * writes:
 */
static const int16_t  func_50(int64_t  p_51, int8_t  p_52, int8_t  p_53, uint32_t  p_54, int32_t  p_55)
{ /* block id: 31 */
    int32_t l_64 = 0x1464E941L;
    int32_t l_70[5][9][1] = {{{0xDEB0CCCFL},{(-1L)},{(-1L)},{0xDEB0CCCFL},{(-1L)},{0x4C1C17FAL},{0xFBAAEEA3L},{(-1L)},{5L}},{{(-1L)},{0xFBAAEEA3L},{0x4C1C17FAL},{(-1L)},{0xDEB0CCCFL},{(-1L)},{(-1L)},{0xDEB0CCCFL},{(-1L)}},{{0x4C1C17FAL},{0xFBAAEEA3L},{(-1L)},{5L},{(-1L)},{0xFBAAEEA3L},{0x4C1C17FAL},{(-1L)},{0xDEB0CCCFL}},{{(-1L)},{(-1L)},{0xDEB0CCCFL},{(-1L)},{0x4C1C17FAL},{0xFBAAEEA3L},{(-1L)},{5L},{(-1L)}},{{0xFBAAEEA3L},{0x4C1C17FAL},{(-1L)},{0xDEB0CCCFL},{(-1L)},{(-1L)},{0xDEB0CCCFL},{(-1L)},{0x4C1C17FAL}}};
    int i, j, k;
    l_70[4][3][0] = (func_58(p_51, p_53, l_64, g_57[3][2], g_26[3]) ^ p_53);
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_26
 * writes:
 */
static uint64_t  func_58(int8_t  p_59, uint8_t  p_60, int32_t  p_61, uint8_t  p_62, uint64_t  p_63)
{ /* block id: 32 */
    int8_t l_69 = 0L;
    p_61 &= ((((safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(l_69, l_69)), 1UL)) || 0xCD6C332E49D2A59ALL) <= l_69) != g_31[8][0]);
    return g_26[4];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_26[i], "g_26[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_31[i][j], "g_31[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_57[i][j], "g_57[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_89, "g_89", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 26
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 26
   depth: 2, occurrence: 8
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 51
XXX times a non-volatile is write: 15
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 34
XXX percentage of non-volatile access: 81.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 5
   depth: 2, occurrence: 9

XXX percentage a fresh-made variable is used: 32.9
XXX percentage an existing variable is used: 67.1
********************* end of statistics **********************/

