/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11878815566399993101
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_16 = 1UL;
static uint32_t g_17 = 0xE864896EL;
static volatile int64_t g_20 = 0xE79753589FE57F6CLL;/* VOLATILE GLOBAL g_20 */
static volatile uint8_t g_24 = 247UL;/* VOLATILE GLOBAL g_24 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint8_t  func_8(int64_t  p_9, int32_t  p_10, uint8_t  p_11, int16_t  p_12, int32_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_16 g_17 g_20 g_24
 * writes: g_24
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2 = 65526UL;
    int32_t l_27 = (-1L);
    l_2++;
    l_27 = (+(safe_mul_func_uint8_t_u_u(func_8((safe_sub_func_uint32_t_u_u(((l_2 , g_16) >= l_2), 0xD947597AL)), l_2, l_2, g_17, l_2), 1UL)));
    return g_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_24
 * writes: g_24
 */
static uint8_t  func_8(int64_t  p_9, int32_t  p_10, uint8_t  p_11, int16_t  p_12, int32_t  p_13)
{ /* block id: 2 */
    int32_t l_18 = 0x2038E85AL;
    int32_t l_19 = 0xF7F3E76EL;
    uint64_t l_21[8] = {0UL,1UL,0UL,0UL,1UL,0UL,0UL,1UL};
    int i;
    --l_21[7];
    if (g_20)
    { /* block id: 4 */
        g_24--;
    }
    else
    { /* block id: 6 */
        return p_11;
    }
    return l_21[5];
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 11
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 3
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 86.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 45
XXX percentage an existing variable is used: 55
********************* end of statistics **********************/

