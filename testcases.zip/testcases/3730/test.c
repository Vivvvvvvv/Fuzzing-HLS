/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6486329133328813425
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3[4] = {0x9E57AD95L,0x9E57AD95L,0x9E57AD95L,0x9E57AD95L};
static uint32_t g_8[2] = {0UL,0UL};


/* --- FORWARD DECLARATIONS --- */
static const int32_t  func_1(void);
static uint32_t  func_9(int32_t  p_10, uint16_t  p_11, uint64_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_8
 * writes: g_3 g_8
 */
static const int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2[4] = {0x204EL,0x204EL,0x204EL,0x204EL};
    int32_t l_21 = (-6L);
    uint8_t l_25 = 255UL;
    int i;
    for (g_3[0] = 3; (g_3[0] >= 0); g_3[0] -= 1)
    { /* block id: 3 */
        int i;
        g_8[1] = (safe_sub_func_uint32_t_u_u(((safe_mod_func_int32_t_s_s(((l_2[g_3[0]] , l_2[g_3[0]]) != 0xD8530DE9BF9F3617LL), l_2[1])) || 0x1BA0L), l_2[0]));
    }
    if ((func_9(((((((g_3[0] | l_2[1]) , l_2[1]) , g_3[1]) && g_3[0]) , 0x2EF703C5764361A6LL) <= g_8[0]), l_2[2], l_2[1]) <= l_2[2]))
    { /* block id: 12 */
        uint16_t l_22 = 0UL;
        l_21 = (safe_lshift_func_uint16_t_u_u((g_8[1] < 0L), g_8[1]));
        l_22++;
    }
    else
    { /* block id: 15 */
        l_21 ^= 0L;
        --l_25;
    }
    l_21 = 0xC6DCFF2FL;
    return g_3[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint32_t  func_9(int32_t  p_10, uint16_t  p_11, uint64_t  p_12)
{ /* block id: 6 */
    uint32_t l_13 = 18446744073709551615UL;
    int32_t l_14[2];
    int8_t l_15 = 7L;
    int i;
    for (i = 0; i < 2; i++)
        l_14[i] = 0L;
    l_14[0] = l_13;
    if (l_13)
        goto lbl_16;
    l_14[0] = ((l_14[0] >= g_3[0]) ^ l_14[0]);
lbl_16:
    l_15 &= g_3[0];
    return p_10;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 21.2
XXX percentage an existing variable is used: 78.8
********************* end of statistics **********************/

