/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5075831837790193669
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-1L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint64_t  func_12(uint32_t  p_13, uint16_t  p_14);
static int8_t  func_17(const int16_t  p_18, uint32_t  p_19, int16_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3
 * writes: g_4 g_3
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2[8] = {0x6CA2L,0x6CA2L,0x6CA2L,0x6CA2L,0x6CA2L,0x6CA2L,0x6CA2L,0x6CA2L};
    int32_t l_7 = 0x2A26F3F1L;
    int32_t l_44 = 0x48F7C4FBL;
    int i;
    for (g_4 = 6; (g_4 >= 1); g_4 -= 1)
    { /* block id: 3 */
        int32_t l_57 = 1L;
        int i;
        g_3 = (safe_mul_func_uint16_t_u_u((5UL > l_2[(g_4 + 1)]), 0x362DL));
        l_7 = l_2[2];
        l_7 = (safe_div_func_uint8_t_u_u((safe_sub_func_int64_t_s_s((func_12(((((((safe_add_func_int64_t_s_s((((((func_17(l_2[(g_4 + 1)], l_2[7], g_4) ^ g_4) | 0x407B094C655EF1C8LL) , g_3) && 0x679F1A7DL) <= 0xEDFCL), 0xC3D34E0BB69233C9LL)) != g_4) ^ 0xA6L) > g_4) , 1UL) == g_4), l_2[1]) | 0UL), g_4)), l_2[(g_4 + 1)]));
        g_3 = (safe_lshift_func_uint16_t_u_s(l_2[(g_4 + 1)], 2));
        for (l_7 = 7; (l_7 >= 0); l_7 -= 1)
        { /* block id: 23 */
            int32_t l_55 = 0x043A44ADL;
            int8_t l_56 = 0x67L;
            l_44 = (safe_sub_func_int64_t_s_s(((g_3 < 0xB590L) & 0x3317L), 0UL));
            l_57 = (((safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u(((l_44 == g_3) , g_4), l_55)) ^ g_4), l_2[(g_4 + 1)])) != g_4), l_56)) , l_7), 0x18L)), 0x2A6F4112L)) && l_2[(g_4 + 1)]) ^ g_4);
            if (g_4)
                continue;
        }
    }
    g_3 = (safe_mod_func_uint32_t_u_u((safe_add_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u((l_44 && 0xAB98CFE46DA0476FLL), l_2[7])), g_4)), 1UL));
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint64_t  func_12(uint32_t  p_13, uint16_t  p_14)
{ /* block id: 17 */
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4
 * writes:
 */
static int8_t  func_17(const int16_t  p_18, uint32_t  p_19, int16_t  p_20)
{ /* block id: 6 */
    const int64_t l_23 = 0L;
    uint8_t l_30[4] = {247UL,247UL,247UL,247UL};
    int32_t l_31 = 0xF3B1AD31L;
    int64_t l_39 = 9L;
    int i;
    if ((safe_mod_func_int32_t_s_s(l_23, 0x0A1434A9L)))
    { /* block id: 7 */
        const uint32_t l_28 = 18446744073709551615UL;
        int32_t l_29[1];
        int i;
        for (i = 0; i < 1; i++)
            l_29[i] = 0x35FF5744L;
        l_29[0] = (((safe_mul_func_uint8_t_u_u(g_3, p_18)) == l_28) > 0L);
        return l_29[0];
    }
    else
    { /* block id: 10 */
        uint32_t l_32 = 3UL;
        l_30[1] &= (p_18 || g_3);
        l_31 = (((((g_4 | 0x7B1AA435C5265879LL) || g_4) | g_3) || p_18) && p_20);
        l_32 |= ((((0x6CE2L && g_3) > 0L) ^ 0xCE85DC32C7527853LL) > g_4);
    }
    l_39 &= (safe_mul_func_uint8_t_u_u((((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((((g_4 , 0xD28A2181L) >= 0x7B34174AL) || (-1L)), 15)), p_18)) && 0UL) && p_20), p_19));
    return l_30[2];
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 20
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1
   depth: 13, occurrence: 1
   depth: 20, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 45
XXX times a non-volatile is write: 11
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 83.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 10
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 19.4
XXX percentage an existing variable is used: 80.6
********************* end of statistics **********************/

