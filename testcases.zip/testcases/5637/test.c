/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4975429820853507849
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_2 = 0xAEL;/* VOLATILE GLOBAL g_2 */
static uint8_t g_3 = 255UL;
static int32_t g_16 = (-1L);
static volatile uint16_t g_19 = 0xC712L;/* VOLATILE GLOBAL g_19 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint32_t  func_6(int32_t  p_7, uint32_t  p_8);
static int32_t  func_12(const int32_t  p_13, uint32_t  p_14);
static uint32_t  func_22(uint64_t  p_23, int32_t  p_24, int32_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_16 g_19
 * writes: g_3 g_16 g_19
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_11 = 0x27L;
    int32_t l_18 = 0L;
    int32_t l_31 = 0x3222C7E1L;
    g_3 |= g_2;
    l_18 ^= (safe_div_func_uint32_t_u_u(func_6((safe_add_func_uint8_t_u_u((g_2 <= g_3), g_3)), l_11), g_3));
    g_19--;
    l_31 &= (func_22(((safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((g_16 == g_3), g_3)), l_18)) != l_11), l_11, l_11) ^ 0UL);
    return l_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_16
 * writes: g_16
 */
static uint32_t  func_6(int32_t  p_7, uint32_t  p_8)
{ /* block id: 2 */
    int8_t l_15 = 0xCDL;
    int32_t l_17[4][1][10] = {{{0L,7L,7L,0L,4L,0x0F2D6273L,4L,0L,7L,7L}},{{4L,7L,0xFA017779L,(-1L),(-1L),0xFA017779L,7L,4L,7L,0xFA017779L}},{{0x0F2D6273L,0L,(-1L),0L,0x0F2D6273L,0xFA017779L,0xFA017779L,0x0F2D6273L,0L,(-1L)}},{{4L,4L,(-1L),0x0F2D6273L,(-2L),0x0F2D6273L,(-1L),4L,4L,(-1L)}}};
    int i, j, k;
    g_16 ^= func_12(((l_15 && 18446744073709551606UL) ^ l_15), l_15);
    p_7 = (-1L);
    l_17[1][0][9] ^= (p_8 <= 2UL);
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int32_t  func_12(const int32_t  p_13, uint32_t  p_14)
{ /* block id: 3 */
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_22(uint64_t  p_23, int32_t  p_24, int32_t  p_25)
{ /* block id: 11 */
    uint16_t l_30 = 0x786CL;
    l_30 = p_23;
    return p_23;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 7
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 90

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 12

XXX percentage a fresh-made variable is used: 31.2
XXX percentage an existing variable is used: 68.8
********************* end of statistics **********************/

