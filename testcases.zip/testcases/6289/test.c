/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10448415683667626056
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_8[7][6] = {{1L,(-7L),(-7L),1L,1L,(-7L)},{1L,1L,(-7L),(-7L),1L,1L},{1L,(-7L),(-7L),1L,1L,(-7L)},{1L,1L,(-7L),(-7L),1L,1L},{1L,(-7L),(-7L),1L,1L,(-7L)},{1L,1L,(-7L),(-7L),1L,1L},{1L,(-7L),(-7L),1L,1L,(-7L)}};


/* --- FORWARD DECLARATIONS --- */
static const uint64_t  func_1(void);
static uint16_t  func_4(int64_t  p_5, uint32_t  p_6);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8
 * writes:
 */
static const uint64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_7 = 0UL;
    int32_t l_10 = 0x85CE96B7L;
    l_10 = (safe_rshift_func_uint16_t_u_u(func_4(l_7, g_8[6][5]), g_8[2][3]));
    return g_8[6][5];
}


/* ------------------------------------------ */
/* 
 * reads : g_8
 * writes:
 */
static uint16_t  func_4(int64_t  p_5, uint32_t  p_6)
{ /* block id: 1 */
    int8_t l_9 = (-8L);
    l_9 = g_8[6][5];
    return p_5;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_8[i][j], "g_8[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 5
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 6
XXX times a non-volatile is write: 2
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 4
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 4

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

