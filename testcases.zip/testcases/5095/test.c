/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7679082175115482807
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_6 = 0x885C6F1BL;
static uint32_t g_28 = 9UL;
static uint16_t g_31 = 0x1C1DL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(int64_t  p_3, uint32_t  p_4, int32_t  p_5);
static int32_t  func_7(uint32_t  p_8, uint16_t  p_9, uint32_t  p_10, int32_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_28 g_31
 * writes: g_6 g_28 g_31
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_32 = (-1L);
    int32_t l_38 = 0x2A6CA0CEL;
    uint32_t l_39 = 0xD10FBF2BL;
    l_32 = func_2(g_6, g_6, g_6);
    if (l_32)
    { /* block id: 21 */
        uint8_t l_33 = 0x3EL;
        l_33++;
    }
    else
    { /* block id: 23 */
        g_6 &= (safe_mul_func_uint16_t_u_u(0x20B2L, 0xB874L));
    }
    l_38 = (g_31 , 0x5E1BFEDAL);
    return l_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_28
 * writes: g_6 g_28 g_31
 */
static int32_t  func_2(int64_t  p_3, uint32_t  p_4, int32_t  p_5)
{ /* block id: 1 */
    int8_t l_12 = 3L;
    g_31 = func_7(g_6, l_12, l_12, g_6);
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_28
 * writes: g_6 g_28
 */
static int32_t  func_7(uint32_t  p_8, uint16_t  p_9, uint32_t  p_10, int32_t  p_11)
{ /* block id: 2 */
    const int16_t l_20 = 0L;
    int32_t l_21 = 0x6E348CC3L;
    int32_t l_25 = 0xB8E136DCL;
    int32_t l_26 = 0x4365DEA3L;
    int32_t l_27 = (-4L);
    for (p_8 = 20; (p_8 <= 21); p_8++)
    { /* block id: 5 */
        int32_t l_15 = 0x29822CB3L;
        if (l_15)
            break;
        l_21 = (safe_add_func_uint32_t_u_u((safe_div_func_uint64_t_u_u(l_15, l_20)), 0xCEF989B1L));
        g_6 ^= (l_20 ^ l_15);
    }
    for (p_9 = 22; (p_9 <= 28); ++p_9)
    { /* block id: 12 */
        int8_t l_24 = 1L;
        g_6 = (-1L);
        l_24 |= g_6;
    }
    ++g_28;
    return g_6;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 12
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 7

XXX percentage a fresh-made variable is used: 41.7
XXX percentage an existing variable is used: 58.3
********************* end of statistics **********************/

