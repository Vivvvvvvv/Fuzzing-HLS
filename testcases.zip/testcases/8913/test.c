/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4773492159693885683
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_2 = 0x9FF60657L;
static volatile int64_t g_16 = 0x4F1F13B01D91E66CLL;/* VOLATILE GLOBAL g_16 */
static int32_t g_29[6][3][9] = {{{(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L),(-4L)},{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)},{(-4L),(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L)}},{{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)},{(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L),(-4L)},{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)}},{{(-4L),(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L)},{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)},{(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L),(-4L)}},{{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)},{(-4L),(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L)},{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)}},{{(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L),(-4L)},{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)},{(-4L),(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L)}},{{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)},{(-4L),3L,3L,(-4L),(-4L),3L,3L,(-4L),(-4L)},{(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L),(-10L),(-1L)}}};
static int32_t g_30 = 0xD32DE9E5L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_3(int32_t  p_4, uint64_t  p_5);
static uint8_t  func_7(uint64_t  p_8);
static int32_t  func_31(int16_t  p_32, uint32_t  p_33, int64_t  p_34, int64_t  p_35, uint64_t  p_36);
static int16_t  func_37(uint8_t  p_38, uint32_t  p_39, uint16_t  p_40);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_16 g_29 g_30
 * writes: g_29 g_30
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_41 = 18446744073709551615UL;
    if (g_2)
    { /* block id: 1 */
        int32_t l_9 = 0xEC79CF18L;
        l_9 = (func_3(((!func_7(l_9)) , (-6L)), g_2) != l_9);
        g_30 = l_9;
    }
    else
    { /* block id: 14 */
        int32_t l_61 = 1L;
        int64_t l_66 = 0x13DB3B8CD6C332E4LL;
        uint8_t l_69[7];
        int i;
        for (i = 0; i < 7; i++)
            l_69[i] = 5UL;
        l_61 = func_31(func_37(g_2, g_29[5][1][0], l_41), g_29[0][1][0], g_2, g_29[3][2][2], g_29[0][2][2]);
        g_30 = (safe_lshift_func_uint8_t_u_u((((safe_div_func_uint64_t_u_u((((l_66 ^ 0UL) , l_61) <= l_41), g_29[3][2][2])) , 0xE360L) , l_41), g_2));
        g_30 = (safe_sub_func_uint32_t_u_u(l_41, l_69[3]));
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_29 g_2
 * writes: g_29
 */
static uint32_t  func_3(int32_t  p_4, uint64_t  p_5)
{ /* block id: 6 */
    int8_t l_20 = (-1L);
    int32_t l_21 = 0xCE028F4EL;
    l_21 = l_20;
    l_21 = (safe_sub_func_uint8_t_u_u(l_21, g_16));
    g_29[3][2][2] &= (safe_mul_func_uint8_t_u_u((safe_add_func_uint16_t_u_u((+4294967295UL), l_20)), g_16));
    l_21 = g_2;
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_7(uint64_t  p_8)
{ /* block id: 2 */
    uint32_t l_10 = 3UL;
    int32_t l_13 = 0L;
    int32_t l_14 = 0L;
    int32_t l_15 = 0xA11015AAL;
    uint16_t l_17 = 0xB3A4L;
    l_10++;
    ++l_17;
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_30
 * writes: g_30
 */
static int32_t  func_31(int16_t  p_32, uint32_t  p_33, int64_t  p_34, int64_t  p_35, uint64_t  p_36)
{ /* block id: 18 */
    uint64_t l_43 = 0x3EDE5C48968F25CELL;
    int32_t l_45 = 0xF2AA787DL;
    uint8_t l_56 = 0x9DL;
    int32_t l_58 = (-3L);
    l_43 ^= p_33;
    if ((0UL < 4294967295UL))
    { /* block id: 20 */
        uint16_t l_44 = 0xF90BL;
        l_45 |= (p_35 ^ l_44);
        for (l_44 = 0; (l_44 < 27); l_44 = safe_add_func_uint32_t_u_u(l_44, 3))
        { /* block id: 24 */
            g_30 &= ((p_33 || g_29[3][2][2]) , 0x77CB11B1L);
        }
    }
    else
    { /* block id: 27 */
        uint32_t l_57[3];
        int i;
        for (i = 0; i < 3; i++)
            l_57[i] = 0x995E148CL;
        l_58 = (((((safe_rshift_func_uint16_t_u_u((((safe_sub_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u(p_33, 0x4DL)) || p_36), g_29[3][2][2])), l_56)) ^ l_56) != 3UL), g_30)) > l_57[0]) < 0xF18E0DA5L) , p_34) < p_36);
        l_45 ^= (((4294967286UL > 0x76DFA536L) && l_57[0]) , (-9L));
        l_45 = (safe_mod_func_uint32_t_u_u(0xDBC55146L, g_30));
    }
    return l_56;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_37(uint8_t  p_38, uint32_t  p_39, uint16_t  p_40)
{ /* block id: 15 */
    uint64_t l_42 = 18446744073709551615UL;
    l_42 ^= 0xEF314D41L;
    return p_39;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_29[i][j][k], "g_29[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_30, "g_30", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 31
   depth: 2, occurrence: 6
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 46
XXX times a non-volatile is write: 19
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 23
XXX percentage of non-volatile access: 97

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 10
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

