/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15793145020859475988
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 7L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 0x5BAF43B7L;
static uint64_t g_33 = 0UL;
static int32_t g_42[7] = {0xF31A33FFL,0xF31A33FFL,0xF31A33FFL,0xF31A33FFL,0xF31A33FFL,0xF31A33FFL,0xF31A33FFL};
static uint64_t g_66 = 0UL;
static volatile int32_t g_77 = (-7L);/* VOLATILE GLOBAL g_77 */
static int16_t g_78[2][3] = {{0L,0L,0L},{0L,0L,0L}};
static uint8_t g_80 = 0x77L;
static uint16_t g_121 = 0x97ADL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_6(int64_t  p_7, int16_t  p_8);
static int64_t  func_9(int8_t  p_10, int32_t  p_11);
static int8_t  func_12(int32_t  p_13);
static int32_t  func_44(uint32_t  p_45);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_33 g_42 g_66 g_80 g_77 g_121 g_78
 * writes: g_3 g_2 g_66 g_33 g_80 g_77 g_121
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_126 = 0xB13B08BCL;
lbl_144:
    for (g_3 = 0; (g_3 == 17); g_3 = safe_add_func_int32_t_s_s(g_3, 5))
    { /* block id: 3 */
        uint64_t l_14 = 0xD7C1188E17B844A7LL;
        int32_t l_127 = 0x8D9C3D7FL;
        l_127 = (((func_6(func_9(func_12(l_14), l_14), g_42[1]) | g_3) == l_14) , l_126);
        g_77 = ((((g_3 || l_126) >= g_2) ^ g_42[6]) && l_126);
    }
    for (g_80 = 0; (g_80 == 57); g_80 = safe_add_func_uint16_t_u_u(g_80, 1))
    { /* block id: 83 */
        uint64_t l_137 = 0x9D16BB71A4F7F709LL;
        int32_t l_143 = 0xABBE6239L;
        if ((((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_u((+(safe_rshift_func_uint16_t_u_u((g_42[4] >= l_137), 11))), l_126)), l_126)) | 4294967286UL) ^ l_126))
        { /* block id: 84 */
            uint8_t l_140 = 1UL;
            l_140 = ((safe_mod_func_int32_t_s_s((g_78[0][1] <= l_126), g_66)) ^ g_77);
            if (l_126)
                continue;
        }
        else
        { /* block id: 87 */
            l_143 = (safe_mul_func_int16_t_s_s(g_121, 0x5739L));
        }
        if (g_80)
            goto lbl_144;
        g_3 = (+(safe_add_func_int64_t_s_s(((safe_rshift_func_int8_t_s_s((-1L), 5)) , 0x2B89924172394782LL), l_126)));
    }
    return l_126;
}


/* ------------------------------------------ */
/* 
 * reads : g_66 g_33 g_80 g_121 g_78
 * writes: g_66 g_2 g_77 g_121
 */
static int8_t  func_6(int64_t  p_7, int16_t  p_8)
{ /* block id: 57 */
    uint16_t l_100 = 65531UL;
    uint8_t l_116 = 255UL;
    int32_t l_117 = 1L;
    int32_t l_120 = 0x1C57EA6FL;
    for (g_66 = (-24); (g_66 >= 9); ++g_66)
    { /* block id: 60 */
        uint32_t l_96[1];
        int i;
        for (i = 0; i < 1; i++)
            l_96[i] = 0x079C9DB8L;
        g_2 = (p_7 || 0xDD30C446L);
        --l_96[0];
        g_77 = ((~l_100) < 0x87C2L);
    }
    for (p_8 = 0; (p_8 >= 3); p_8 = safe_add_func_int64_t_s_s(p_8, 9))
    { /* block id: 67 */
        int64_t l_109 = 4L;
        int32_t l_118 = 0x307078ADL;
        int32_t l_119[2];
        int i;
        for (i = 0; i < 2; i++)
            l_119[i] = 0x18D08C10L;
        for (p_7 = 0; (p_7 <= 1); p_7 = safe_add_func_int64_t_s_s(p_7, 7))
        { /* block id: 70 */
            l_109 = (((safe_rshift_func_int8_t_s_u((safe_lshift_func_int8_t_s_u((0xF5L & 0x7CL), 3)), 7)) & g_33) | p_8);
        }
        l_117 = ((((safe_add_func_int8_t_s_s((safe_div_func_uint8_t_u_u((safe_add_func_uint16_t_u_u((((p_7 , l_109) || g_80) && l_116), g_80)), l_100)), l_116)) == 0x6CA1BE135CA447F7LL) ^ l_100) ^ l_109);
        g_121--;
        l_120 &= (safe_sub_func_uint8_t_u_u(0x2FL, 1L));
    }
    return g_78[1][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_33 g_42 g_66 g_80 g_77
 * writes: g_2 g_66 g_33 g_80
 */
static int64_t  func_9(int8_t  p_10, int32_t  p_11)
{ /* block id: 8 */
    uint32_t l_32 = 0UL;
    int32_t l_76 = (-1L);
    int32_t l_79 = 1L;
lbl_83:
    for (p_11 = (-13); (p_11 != 10); p_11++)
    { /* block id: 11 */
        int64_t l_34 = 0xC82104667120DD93LL;
        int64_t l_35 = 0L;
        int32_t l_75[7][9] = {{(-1L),0x0C33ADB5L,0xC6425F0FL,0x8105A18AL,0x8105A18AL,0xC6425F0FL,0x0C33ADB5L,(-1L),0xC6425F0FL},{(-1L),0x0C33ADB5L,0xC6425F0FL,0x8105A18AL,0x8105A18AL,0xC6425F0FL,0x0C33ADB5L,(-1L),0xC6425F0FL},{(-1L),0x0C33ADB5L,0xC6425F0FL,0x8105A18AL,0x8105A18AL,0xC6425F0FL,0x0C33ADB5L,(-1L),0xC6425F0FL},{(-1L),0x0C33ADB5L,0xC6425F0FL,0x8105A18AL,0x8105A18AL,0xC6425F0FL,0L,0xB2332F7FL,0x8105A18AL},{0xB2332F7FL,0L,0x8105A18AL,0x7F92971DL,0x7F92971DL,0x8105A18AL,0L,0xB2332F7FL,0x8105A18AL},{0xB2332F7FL,0L,0x8105A18AL,0x7F92971DL,0x7F92971DL,0x8105A18AL,0L,0xB2332F7FL,0x8105A18AL},{0xB2332F7FL,0L,0x8105A18AL,0x7F92971DL,0x7F92971DL,0x8105A18AL,0L,0xB2332F7FL,0x8105A18AL}};
        int i, j;
        g_2 = func_12(p_11);
        if (g_3)
        { /* block id: 13 */
            uint8_t l_36 = 4UL;
            l_35 |= (safe_sub_func_int8_t_s_s((safe_div_func_uint32_t_u_u(((((safe_sub_func_uint32_t_u_u((safe_div_func_int32_t_s_s((safe_sub_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((p_11 , p_11), 9UL)), l_32)), g_2)), g_33)) >= l_34) , 18446744073709551612UL) > g_3), 2UL)), 0x19L));
            return l_36;
        }
        else
        { /* block id: 16 */
            int64_t l_39 = 0L;
            int64_t l_40 = 0xA6D7D04549C4B05ELL;
            volatile int32_t l_41[5][6][8] = {{{4L,0xE9BECC42L,0xE9BECC42L,4L,(-1L),1L,7L,0L},{(-7L),0L,0L,0x68F57F54L,0xD4D864B9L,(-1L),0L,5L},{0x633EF28FL,0L,0x4DBB9A2FL,(-1L),0L,1L,0x68266C09L,3L},{0x7EEDF667L,0xE9BECC42L,(-5L),0x075F97E6L,0x0FC5A51FL,0L,6L,4L},{1L,0x6A86E60EL,(-1L),0L,0L,0xFF74B76FL,0x075F97E6L,(-1L)},{(-5L),3L,(-7L),0L,(-7L),3L,(-5L),(-1L)}},{{5L,(-1L),0L,0xC8A2DB63L,0x4DBB9A2FL,(-1L),3L,3L},{0xDA7D8E2DL,0x68266C09L,(-1L),0x7EEDF667L,0x4DBB9A2FL,5L,0x0FC5A51FL,0L},{5L,0L,6L,3L,(-7L),0xE9BECC42L,0xC8A2DB63L,(-1L)},{(-5L),0x633EF28FL,(-6L),0xDA7D8E2DL,0L,0x075F97E6L,0xD8284A89L,0x68F57F54L},{1L,1L,0L,(-6L),0x0FC5A51FL,0x0FC5A51FL,(-6L),0L},{0x7EEDF667L,0x7EEDF667L,(-1L),0x4F412F3AL,0L,0L,0x633EF28FL,7L}},{{0x633EF28FL,(-7L),0xEA6CBABAL,0x4DBB9A2FL,0xD4D864B9L,0xDA7D8E2DL,0xE9BECC42L,7L},{(-7L),0x18EB0BADL,0x075F97E6L,0x4F412F3AL,(-1L),0L,(-1L),0L},{4L,0xEA6CBABAL,0xD4D864B9L,(-6L),(-5L),(-1L),1L,0x68F57F54L},{0xD4D864B9L,0L,0x18EB0BADL,0xDA7D8E2DL,7L,(-1L),(-7L),(-1L)},{(-6L),3L,0L,3L,(-6L),0x6A86E60EL,(-1L),0L},{0xE9BECC42L,(-5L),1L,0x7EEDF667L,0x18EB0BADL,4L,(-1L),3L}},{{0x4F412F3AL,0x68F57F54L,1L,0xC8A2DB63L,(-5L),0xEA6CBABAL,(-1L),(-1L)},{0x18EB0BADL,0xFF74B76FL,0L,0L,0x6A86E60EL,1L,(-7L),(-1L)},{0L,0x68266C09L,(-5L),5L,(-1L),0xE9BECC42L,0L,(-6L)},{6L,(-5L),0xD8284A89L,0x6A86E60EL,0x6A86E60EL,0xD8284A89L,(-5L),6L},{0x68266C09L,0x4DBB9A2FL,0x6A86E60EL,(-5L),(-1L),(-1L),0x0FC5A51FL,(-1L)},{0L,(-1L),0x1C064292L,0x18EB0BADL,(-5L),(-1L),0xE9BECC42L,0L}},{{7L,0x4DBB9A2FL,0L,(-6L),0x1C064292L,0xD8284A89L,0xC8A2DB63L,(-7L)},{0L,(-5L),0L,7L,0xD4D864B9L,0xE9BECC42L,0x68266C09L,(-1L)},{4L,0x68266C09L,0xC8A2DB63L,(-5L),0x7EEDF667L,7L,0x7EEDF667L,(-5L)},{0x46B4C01FL,4L,0x46B4C01FL,(-1L),6L,0x1C064292L,0x4F412F3AL,0x4DBB9A2FL},{0xDA7D8E2DL,0x18EB0BADL,0L,0xD4D864B9L,0L,(-6L),6L,0L},{0xDA7D8E2DL,0x68F57F54L,5L,0L,6L,3L,(-7L),0xE9BECC42L}}};
            int i, j, k;
            if (l_32)
                break;
            l_41[4][5][2] = (((safe_div_func_uint64_t_u_u((((g_33 , l_35) != l_39) , l_40), l_40)) != g_2) , g_2);
            if (g_3)
                continue;
            if (l_35)
                goto lbl_83;
        }
        for (l_32 = 0; (l_32 <= 6); l_32 += 1)
        { /* block id: 23 */
            int32_t l_43 = 0x17922C1EL;
            int i;
            l_43 &= ((g_42[l_32] , g_42[l_32]) >= g_3);
            l_43 = func_44((safe_unary_minus_func_int16_t_s((safe_mul_func_int16_t_s_s(g_3, p_10)))));
            if (p_11)
                break;
            --g_80;
        }
    }
    l_79 &= ((p_10 | 0x568EBAD55379293ELL) || 18446744073709551615UL);
    if ((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((!((safe_mod_func_int32_t_s_s(2L, l_32)) >= 65533UL)), l_32)), 0x5F43L)))
    { /* block id: 51 */
        uint16_t l_91 = 65531UL;
        --l_91;
    }
    else
    { /* block id: 53 */
        return g_77;
    }
    return l_79;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_12(int32_t  p_13)
{ /* block id: 4 */
    uint8_t l_15 = 0UL;
    p_13 = 1L;
    l_15--;
    return l_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_2 g_42 g_3 g_66
 * writes: g_66 g_2 g_33
 */
static int32_t  func_44(uint32_t  p_45)
{ /* block id: 25 */
    const int64_t l_67 = 0x242223AA5B3E5B60LL;
    int32_t l_72 = 2L;
    uint32_t l_74 = 18446744073709551615UL;
    if ((safe_sub_func_int8_t_s_s((!(safe_unary_minus_func_uint32_t_u((p_45 && 0x345D18A9L)))), p_45)))
    { /* block id: 26 */
        int64_t l_64 = 7L;
        int64_t l_65 = 9L;
        int32_t l_68 = 5L;
        g_66 &= ((!((((((safe_add_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_s(((((safe_add_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u((0UL > p_45), g_33)) == g_33), (-6L))) || g_2), g_42[0])) && 0xDD2C8CC2L) != g_42[1]) ^ g_33), p_45)) != 0x0013L), g_3)) || l_64) , g_33) < 0L) && g_42[1]) >= l_65)) != g_33);
        if ((((g_2 != 4294967295UL) && p_45) != p_45))
        { /* block id: 28 */
            g_2 ^= (l_64 || l_67);
        }
        else
        { /* block id: 30 */
            return g_33;
        }
        l_68 = ((l_67 | g_2) != 0xB4ADL);
    }
    else
    { /* block id: 34 */
        uint32_t l_71[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
        int32_t l_73 = 0xA386FCCFL;
        int i;
        for (g_33 = 0; (g_33 >= 56); g_33 = safe_add_func_int8_t_s_s(g_33, 4))
        { /* block id: 37 */
            l_72 &= (l_71[6] | p_45);
            g_2 = (p_45 , p_45);
            l_73 |= 1L;
        }
    }
    return l_74;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_42[i], "g_42[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_78[i][j], "g_78[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 41
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 50
   depth: 2, occurrence: 16
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 97
XXX times a non-volatile is write: 29
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 56
XXX percentage of non-volatile access: 88.7

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 55
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 21
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 28.5
XXX percentage an existing variable is used: 71.5
********************* end of statistics **********************/

