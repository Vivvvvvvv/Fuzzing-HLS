/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18009306614580482174
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_2[3][9] = {{4294967291UL,1UL,4294967291UL,4294967291UL,1UL,4294967291UL,4294967291UL,1UL,4294967291UL},{0xE713A473L,1UL,0xE713A473L,0xE713A473L,1UL,0xE713A473L,0xE713A473L,1UL,0xE713A473L},{4294967291UL,1UL,4294967291UL,4294967291UL,1UL,4294967291UL,4294967291UL,1UL,4294967291UL}};
static uint8_t g_5 = 0x31L;
static uint16_t g_45 = 65535UL;
static uint32_t g_54[6][10][2] = {{{0x28DFE901L,4294967295UL},{4294967294UL,1UL},{1UL,0x28DFE901L},{4294967295UL,0x72C6516EL},{0x0C7F43A4L,4294967295UL},{4294967294UL,4294967295UL},{8UL,0x350B8378L},{0x8795192CL,0xF5F1E611L},{1UL,0x8BF325E6L},{4294967295UL,0x72C6516EL}},{{0x8BF325E6L,0x8795192CL},{8UL,0x8795192CL},{0x8BF325E6L,0x72C6516EL},{0x49DD6285L,9UL},{0x28DFE901L,0x8FCBD0D7L},{0UL,4294967294UL},{4294967295UL,4294967295UL},{0xF5F1E611L,0x49DD6285L},{0x8795192CL,4294967295UL},{0xEC28D216L,4294967295UL}},{{1UL,1UL},{1UL,0x711A46C4L},{4294967295UL,0xF5F1E611L},{4UL,4294967295UL},{0x0C7F43A4L,4UL},{0x72C6516EL,1UL},{0x72C6516EL,4UL},{0x0C7F43A4L,4294967295UL},{4UL,0xF5F1E611L},{4294967295UL,0x711A46C4L}},{{1UL,1UL},{1UL,4294967295UL},{0xEC28D216L,4294967295UL},{0x8795192CL,0x49DD6285L},{0xF5F1E611L,4294967295UL},{4294967295UL,4294967294UL},{0UL,0x8FCBD0D7L},{0x28DFE901L,9UL},{0x49DD6285L,0x72C6516EL},{0x8BF325E6L,0x8795192CL}},{{8UL,0x8795192CL},{0x8BF325E6L,0x72C6516EL},{0x49DD6285L,9UL},{0x28DFE901L,0x8FCBD0D7L},{0UL,4294967294UL},{4294967295UL,4294967295UL},{0xF5F1E611L,0x49DD6285L},{0x8795192CL,4294967295UL},{0xEC28D216L,4294967295UL},{1UL,1UL}},{{1UL,0x711A46C4L},{4294967295UL,0xF5F1E611L},{4UL,4294967295UL},{0x0C7F43A4L,4UL},{0x72C6516EL,1UL},{0x72C6516EL,4UL},{0x0C7F43A4L,4294967295UL},{4UL,0xF5F1E611L},{4294967295UL,0x711A46C4L},{1UL,1UL}}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_8(uint16_t  p_9, int8_t  p_10, uint32_t  p_11);
static int32_t  func_14(int32_t  p_15, int32_t  p_16, int16_t  p_17, uint8_t  p_18, uint32_t  p_19);
static int32_t  func_20(int32_t  p_21, uint16_t  p_22, uint32_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_45 g_54
 * writes: g_2 g_5 g_45 g_54
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_12 = 0x7BL;
    int32_t l_55 = (-3L);
    --g_2[0][8];
    ++g_5;
    g_54[1][3][1] |= func_8(l_12, g_2[0][8], g_2[0][7]);
    l_55 = func_20(g_5, l_12, l_12);
    return g_54[2][1][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_45
 * writes: g_45
 */
static int32_t  func_8(uint16_t  p_9, int8_t  p_10, uint32_t  p_11)
{ /* block id: 3 */
    uint8_t l_13 = 255UL;
    int32_t l_49 = 7L;
    l_13 = (g_2[0][8] > p_10);
    l_49 ^= func_14(g_5, l_13, l_13, l_13, p_11);
    for (p_9 = 10; (p_9 <= 24); ++p_9)
    { /* block id: 33 */
        uint32_t l_52[10] = {0xD9B6EF54L,0x7E5571BEL,0xD9B6EF54L,0xD9B6EF54L,0x7E5571BEL,0xD9B6EF54L,0xD9B6EF54L,0x7E5571BEL,0xD9B6EF54L,0xD9B6EF54L};
        int32_t l_53 = (-1L);
        int i;
        l_53 = (0x01A7L >= l_52[5]);
    }
    return g_45;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_45
 * writes: g_45
 */
static int32_t  func_14(int32_t  p_15, int32_t  p_16, int16_t  p_17, uint8_t  p_18, uint32_t  p_19)
{ /* block id: 5 */
    int32_t l_28[3][2];
    int32_t l_46 = 8L;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
            l_28[i][j] = 0L;
    }
    l_46 ^= func_20((safe_sub_func_uint32_t_u_u(((safe_add_func_uint32_t_u_u((((g_5 != 0x7006986DL) >= p_15) , g_2[0][8]), 0xAB79AE4FL)) ^ l_28[2][0]), l_28[1][0])), g_2[1][6], l_28[2][0]);
    l_46 = ((safe_sub_func_uint32_t_u_u(l_46, g_2[1][0])) >= l_46);
    return l_28[1][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_45
 * writes: g_45
 */
static int32_t  func_20(int32_t  p_21, uint16_t  p_22, uint32_t  p_23)
{ /* block id: 6 */
    uint64_t l_33[8][4];
    int32_t l_34 = 0xD786FF52L;
    int i, j;
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
            l_33[i][j] = 0x4ED09EB818F8F6A1LL;
    }
lbl_40:
    l_33[7][2] = ((safe_add_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(p_22, p_23)) <= p_23), p_23)) || 0xA191A83ACDD711A5LL);
    for (p_22 = 0; (p_22 <= 3); p_22 += 1)
    { /* block id: 10 */
        return g_2[2][5];
    }
    l_34 &= 0xA5659CDEL;
    if (((!((((safe_lshift_func_uint16_t_u_u(g_5, g_2[0][8])) , g_2[0][8]) && 0x054F86FC3314648ALL) < l_33[5][0])) , 0xB00B7228L))
    { /* block id: 14 */
        for (p_23 = 17; (p_23 == 17); p_23 = safe_add_func_uint16_t_u_u(p_23, 2))
        { /* block id: 17 */
            if (g_5)
                goto lbl_40;
            if (g_5)
                break;
            l_34 ^= 0L;
        }
        return g_5;
    }
    else
    { /* block id: 23 */
        g_45 ^= (safe_sub_func_uint8_t_u_u(((safe_lshift_func_uint16_t_u_u((g_5 < p_22), 3)) <= p_22), 0x4BL));
    }
    return l_33[1][3];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_54[i][j][k], "g_54[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 45
XXX times a non-volatile is write: 16
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 25
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 5
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 25.5
XXX percentage an existing variable is used: 74.5
********************* end of statistics **********************/

