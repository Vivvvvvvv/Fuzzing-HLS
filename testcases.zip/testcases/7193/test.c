/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14342941499035490202
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint8_t g_10 = 0x8FL;
static volatile uint32_t g_28 = 0x5C829ED8L;/* VOLATILE GLOBAL g_28 */
static int8_t g_32 = 0x8FL;
static int32_t g_48[3] = {0x7283A38CL,0x7283A38CL,0x7283A38CL};
static int32_t g_64 = (-2L);


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint64_t  func_4(const uint32_t  p_5, int8_t  p_6, const int64_t  p_7, uint64_t  p_8, int32_t  p_9);
static uint16_t  func_19(uint32_t  p_20, uint32_t  p_21, int64_t  p_22);
static int16_t  func_36(const int32_t  p_37);
static uint16_t  func_38(int32_t  p_39, int32_t  p_40, uint32_t  p_41, uint8_t  p_42);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_28 g_32 g_48
 * writes: g_28 g_32 g_48
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_11 = 0xEBL;
    int32_t l_62 = 0L;
    int32_t l_63[3];
    uint16_t l_65[1][4][8] = {{{0xD959L,1UL,0xD959L,65527UL,0x142AL,65527UL,0xD959L,1UL},{0x142AL,65527UL,0xD959L,1UL,0xD959L,65527UL,0x142AL,65527UL},{0x142AL,1UL,0x4DB7L,1UL,0x142AL,65528UL,0x142AL,1UL},{0xD959L,1UL,0xD959L,65527UL,0x142AL,65527UL,0xD959L,1UL}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_63[i] = 0L;
    if ((safe_add_func_uint64_t_u_u(func_4(g_10, g_10, g_10, g_10, l_11), g_10)))
    { /* block id: 24 */
        l_62 = (safe_add_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u(g_32, g_28)) , g_48[2]), 1UL));
        g_48[0] = (1UL && 0x695EA989989A98E5LL);
    }
    else
    { /* block id: 27 */
        l_62 = 0L;
    }
    --l_65[0][0][0];
    return g_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_28 g_32 g_48
 * writes: g_28 g_32 g_48
 */
static uint64_t  func_4(const uint32_t  p_5, int8_t  p_6, const int64_t  p_7, uint64_t  p_8, int32_t  p_9)
{ /* block id: 1 */
    uint32_t l_31 = 0xCADD6352L;
    int32_t l_35 = 0xFF06982BL;
    g_32 = (safe_mod_func_uint16_t_u_u((!(safe_mod_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_u(func_19(g_10, p_6, p_9), g_10)) >= 0xC8D46758L), 0xE434392F20920A6FLL))), l_31));
    l_35 = (safe_sub_func_uint8_t_u_u((((p_5 > g_10) != p_6) >= 0xEA3DE81D534A2C93LL), 250UL));
    l_35 = (func_36(p_7) , g_32);
    return g_48[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_28
 * writes: g_28
 */
static uint16_t  func_19(uint32_t  p_20, uint32_t  p_21, int64_t  p_22)
{ /* block id: 2 */
    uint32_t l_25 = 0xE4145C17L;
    int32_t l_26 = (-1L);
    int32_t l_27 = 0xD1AFD061L;
    l_25 = (g_10 ^ 0UL);
    g_28--;
    return g_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_28
 * writes: g_48 g_32
 */
static int16_t  func_36(const int32_t  p_37)
{ /* block id: 8 */
    int16_t l_45[9];
    uint64_t l_46 = 0x479EA4087B332E0CLL;
    int32_t l_49[2][3] = {{0L,0L,0L},{0xDA1E1CF2L,0xDA1E1CF2L,0xDA1E1CF2L}};
    uint8_t l_57[10][3] = {{255UL,0UL,0x59L},{0xF7L,0UL,2UL},{0x59L,2UL,0xA5L},{250UL,2UL,0UL},{0UL,2UL,2UL},{0x59L,2UL,0xA5L},{250UL,2UL,0UL},{0UL,2UL,2UL},{0x59L,2UL,0xA5L},{250UL,2UL,0UL}};
    int i, j;
    for (i = 0; i < 9; i++)
        l_45[i] = 0x5387L;
    l_49[1][0] = (func_38((((safe_sub_func_uint32_t_u_u(l_45[0], p_37)) ^ l_45[0]) , l_45[7]), l_46, p_37, p_37) > 65535UL);
    for (g_32 = 4; (g_32 == 20); g_32 = safe_add_func_uint16_t_u_u(g_32, 1))
    { /* block id: 15 */
        int32_t l_54 = (-1L);
        l_49[1][0] &= (safe_lshift_func_uint8_t_u_u((((p_37 ^ l_54) < g_28) <= 0x97D6L), 7));
        if (l_49[1][0])
            continue;
    }
    l_49[1][0] = (safe_div_func_uint64_t_u_u(l_57[5][0], p_37));
    l_49[1][0] = (-1L);
    return l_57[5][0];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_48
 */
static uint16_t  func_38(int32_t  p_39, int32_t  p_40, uint32_t  p_41, uint8_t  p_42)
{ /* block id: 9 */
    uint32_t l_47 = 0x1E69D086L;
    g_48[0] = (l_47 < 1UL);
    return l_47;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_48[i], "g_48[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_64, "g_64", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 37
XXX times a non-volatile is write: 14
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 32
XXX percentage of non-volatile access: 92.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 22
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 22.7
XXX percentage an existing variable is used: 77.3
********************* end of statistics **********************/

