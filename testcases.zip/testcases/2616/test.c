/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      519235693913292308
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_7 = 0x9C4C8D3CL;
static uint64_t g_8[3] = {6UL,6UL,6UL};
static int32_t g_13 = 0xB27FA3DFL;
static volatile uint32_t g_15[4] = {0xF1C946B4L,0xF1C946B4L,0xF1C946B4L,0xF1C946B4L};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint8_t  func_2(int32_t  p_3, int32_t  p_4, int16_t  p_5);
static int32_t  func_9(uint32_t  p_10, uint16_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_8 g_13 g_15
 * writes: g_8 g_13 g_15
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_6 = 18446744073709551614UL;
    int32_t l_18 = (-7L);
    g_8[2] = ((func_2((l_6 , g_7), g_7, l_6) && l_6) < g_7);
    l_18 = func_9(g_8[0], g_8[2]);
    l_18 = (((l_18 , g_15[3]) >= 0x55L) , g_7);
    return g_8[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes:
 */
static uint8_t  func_2(int32_t  p_3, int32_t  p_4, int16_t  p_5)
{ /* block id: 1 */
    p_3 |= p_5;
    p_3 = g_7;
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_15
 * writes: g_13 g_15
 */
static int32_t  func_9(uint32_t  p_10, uint16_t  p_11)
{ /* block id: 6 */
    int64_t l_12 = 0x2568108531D14CD4LL;
    int32_t l_14[4];
    int i;
    for (i = 0; i < 4; i++)
        l_14[i] = 0L;
    l_12 = (0x43C6FE23A266D210LL || p_10);
    g_13 |= g_8[2];
    --g_15[3];
    return l_14[3];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13, "g_13", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_15[i], "g_15[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 7
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 92.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 11

XXX percentage a fresh-made variable is used: 26.7
XXX percentage an existing variable is used: 73.3
********************* end of statistics **********************/

