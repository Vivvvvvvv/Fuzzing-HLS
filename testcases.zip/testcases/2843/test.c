/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9154001844420857001
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_2 = 1L;/* VOLATILE GLOBAL g_2 */
static uint16_t g_5[3] = {65532UL,65532UL,65532UL};
static int32_t g_8[8] = {0x76B87D0FL,4L,0x76B87D0FL,0x76B87D0FL,4L,0x76B87D0FL,0x76B87D0FL,4L};
static int32_t g_14 = (-1L);


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_8 g_14
 * writes: g_5 g_8 g_14
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_3[7] = {(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L)};
    int32_t l_4[7];
    uint8_t l_25 = 6UL;
    int32_t l_28 = 0x8BC698DCL;
    uint8_t l_29 = 0x72L;
    int i;
    for (i = 0; i < 7; i++)
        l_4[i] = (-3L);
lbl_26:
    l_4[1] = (g_2 != l_3[0]);
    ++g_5[2];
lbl_27:
    for (g_8[2] = 11; (g_8[2] > (-12)); --g_8[2])
    { /* block id: 5 */
        int8_t l_13 = 0L;
        g_14 |= (safe_div_func_uint8_t_u_u(l_13, g_5[2]));
        if (l_3[3])
            break;
        for (l_13 = 6; (l_13 >= 0); l_13 -= 1)
        { /* block id: 10 */
            int i;
            l_4[l_13] = (safe_lshift_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_s((~(~(safe_div_func_int32_t_s_s((safe_add_func_uint32_t_u_u(l_4[l_13], g_5[2])), l_25)))), l_4[l_13])) , 0xE2F7L) != g_5[2]), 12));
            l_4[l_13] = ((-1L) ^ g_5[0]);
            if (g_2)
                continue;
            if (l_13)
                goto lbl_27;
        }
        if (l_25)
            goto lbl_26;
    }
    ++l_29;
    return l_3[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_14, "g_14", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 5
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 8
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 12
XXX percentage of non-volatile access: 91.3

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 4
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 37.5
XXX percentage an existing variable is used: 62.5
********************* end of statistics **********************/

