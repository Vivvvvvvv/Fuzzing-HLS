/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7970793929370233028
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_4 = 0x4F46DB50L;
static int32_t g_31 = 0xF6F49C23L;
static volatile uint8_t g_35 = 0x5FL;/* VOLATILE GLOBAL g_35 */
static volatile int16_t g_40 = 3L;/* VOLATILE GLOBAL g_40 */
static uint32_t g_41 = 4UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint64_t  func_11(int64_t  p_12, uint32_t  p_13, uint32_t  p_14, int32_t  p_15, int32_t  p_16);
static uint8_t  func_23(uint16_t  p_24, uint32_t  p_25);
static int32_t  func_27(int32_t  p_28, int16_t  p_29);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_31 g_35 g_41
 * writes: g_31 g_35 g_41
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_5 = 0x68L;
    int32_t l_6 = 0x8BAC04EEL;
    int32_t l_34[5] = {0x04204102L,0x04204102L,0x04204102L,0x04204102L,0x04204102L};
    int32_t l_45 = 3L;
    int i;
    l_6 = (safe_rshift_func_uint16_t_u_u(g_4, l_5));
    for (l_6 = (-5); (l_6 < (-30)); l_6 = safe_sub_func_uint8_t_u_u(l_6, 6))
    { /* block id: 4 */
        int32_t l_39 = (-6L);
        int64_t l_44 = 0xADB51FD9AB8A87EALL;
        for (l_5 = 0; (l_5 != 7); l_5 = safe_add_func_uint64_t_u_u(l_5, 7))
        { /* block id: 7 */
            int8_t l_38 = 6L;
            l_34[4] = (func_11(g_4, g_4, l_6, g_4, l_6) >= 0UL);
            ++g_35;
            if (l_38)
                continue;
            ++g_41;
        }
        if (l_44)
            continue;
    }
    l_45 = func_27(l_6, g_4);
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_31
 * writes: g_31
 */
static uint64_t  func_11(int64_t  p_12, uint32_t  p_13, uint32_t  p_14, int32_t  p_15, int32_t  p_16)
{ /* block id: 8 */
    uint32_t l_26 = 0x9ADB8213L;
    int32_t l_32 = 0x6595AD33L;
    uint16_t l_33[6] = {0x16E2L,0xD8D9L,0xD8D9L,0x16E2L,0xD8D9L,0xD8D9L};
    int i;
    l_32 = (((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(func_23((g_4 , 0x694DL), l_26), 0UL)), g_4)), 4)) != l_26) < 0xEF9A8551L);
    g_31 = (g_4 , p_14);
    return l_33[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_31
 * writes: g_31
 */
static uint8_t  func_23(uint16_t  p_24, uint32_t  p_25)
{ /* block id: 9 */
    int16_t l_30 = 0xB166L;
    g_31 |= func_27(l_30, p_25);
    return g_31;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_27(int32_t  p_28, int16_t  p_29)
{ /* block id: 10 */
    return p_28;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 97.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 42.1
XXX percentage an existing variable is used: 57.9
********************* end of statistics **********************/

