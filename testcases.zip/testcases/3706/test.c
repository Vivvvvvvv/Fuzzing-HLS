/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11004114063641290042
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint32_t g_9[4] = {0xFD1E814BL,0xFD1E814BL,0xFD1E814BL,0xFD1E814BL};
static int8_t g_15 = (-7L);
static uint32_t g_18 = 0UL;
static uint16_t g_23 = 7UL;
static int32_t g_26 = 0xFEDEDC87L;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(uint32_t  p_3, uint8_t  p_4, uint32_t  p_5, const int64_t  p_6, uint16_t  p_7);
static int8_t  func_16(int64_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_15
 * writes: g_15 g_18 g_23 g_26
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_8 = (-6L);
    uint64_t l_25 = 18446744073709551615UL;
    uint32_t l_27 = 0x8F9611CAL;
    uint16_t l_28[10] = {0xB72BL,0xB72BL,0xB72BL,0xB72BL,0xB72BL,0xB72BL,0xB72BL,0xB72BL,0xB72BL,0xB72BL};
    int i;
    if (func_2(l_8, l_8, l_8, g_9[2], g_9[3]))
    { /* block id: 11 */
        return l_25;
    }
    else
    { /* block id: 13 */
        g_26 = l_8;
    }
    l_27 = 0xAB430688L;
    return l_28[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_9
 * writes: g_15 g_18 g_23
 */
static int32_t  func_2(uint32_t  p_3, uint8_t  p_4, uint32_t  p_5, const int64_t  p_6, uint16_t  p_7)
{ /* block id: 1 */
    int32_t l_12[9];
    uint16_t l_13[2];
    int32_t l_14 = (-8L);
    int64_t l_24 = 0x4A2C930F888C5540LL;
    int i;
    for (i = 0; i < 9; i++)
        l_12[i] = 0x7182ABBFL;
    for (i = 0; i < 2; i++)
        l_13[i] = 0xAD5AL;
    l_14 ^= (safe_mod_func_int32_t_s_s(((l_12[1] , 0x253A34C865B49D58LL) < (-1L)), l_13[1]));
    g_15 |= l_14;
    l_24 = (func_16(l_13[1]) | 0xA3L);
    return l_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_9
 * writes: g_18 g_23
 */
static int8_t  func_16(int64_t  p_17)
{ /* block id: 4 */
    uint32_t l_19[1];
    int32_t l_20[9] = {0xDD635290L,0xDD635290L,0xDD635290L,0xDD635290L,0xDD635290L,0xDD635290L,0xDD635290L,0xDD635290L,0xDD635290L};
    int i;
    for (i = 0; i < 1; i++)
        l_19[i] = 18446744073709551615UL;
    g_18 = (g_15 , p_17);
    l_20[7] ^= (p_17 < l_19[0]);
    g_23 = (((safe_lshift_func_uint8_t_u_u(l_19[0], 2)) > g_9[1]) , g_9[2]);
    return l_19[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 51.7
XXX percentage an existing variable is used: 48.3
********************* end of statistics **********************/

