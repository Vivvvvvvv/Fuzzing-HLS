/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5049423616025568262
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xF7E2799AL;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0x94801897L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4[1][10][6] = {{{0xAE4B9A73L,0x89A69576L,0L,0x89A69576L,0xAE4B9A73L,0x55B7CEFAL},{0xB64B5C6FL,0x55B7CEFAL,0x173BF38CL,0xAE4B9A73L,0x162C9CC1L,0x12B57E8BL},{(-5L),0x819570A5L,0x162C9CC1L,0x55B7CEFAL,0x12B57E8BL,0x12B57E8BL},{0x2FA4AD74L,0x173BF38CL,0x173BF38CL,0x2FA4AD74L,0xB5F0B101L,0x55B7CEFAL},{0x12B57E8BL,(-10L),0L,0x14D2EDC7L,0x89A69576L,0x162C9CC1L},{0L,(-5L),(-1L),0x819570A5L,0x89A69576L,0x819570A5L},{(-1L),(-10L),(-1L),6L,0xB5F0B101L,(-5L)},{0x55B7CEFAL,0x173BF38CL,0xAE4B9A73L,0x162C9CC1L,6L,(-10L)},{0x2FA4AD74L,(-5L),0xB64B5C6FL,0xAE4B9A73L,0xAE4B9A73L,0xB64B5C6FL},{0L,0L,0x819570A5L,0xB64B5C6FL,(-1L),0xB5F0B101L}}};
static volatile int32_t g_5 = (-1L);/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = 0xB8BFFBEFL;
static int32_t g_81 = (-1L);
static int16_t g_122 = 0L;
static uint32_t g_194 = 0x90A85126L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int64_t  func_25(uint16_t  p_26);
static int32_t  func_31(uint64_t  p_32, const uint32_t  p_33, const int8_t  p_34);
static uint32_t  func_41(uint32_t  p_42);
static uint64_t  func_72(uint32_t  p_73, uint16_t  p_74, uint64_t  p_75, int32_t  p_76, int64_t  p_77);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_4 g_2 g_3 g_5 g_81 g_122 g_194
 * writes: g_6 g_4 g_3 g_2 g_81 g_122 g_5 g_194
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_16 = 1L;
    int32_t l_17 = (-1L);
    uint64_t l_148 = 0x7407BC3B03AC48BBLL;
    int32_t l_152 = 1L;
    int32_t l_153 = 1L;
    int32_t l_155 = (-10L);
    int32_t l_160 = 0x5F86D9A3L;
    int32_t l_161 = 0x3EE4706FL;
    for (g_6 = 0; (g_6 != (-24)); g_6 = safe_sub_func_uint32_t_u_u(g_6, 8))
    { /* block id: 3 */
        uint32_t l_9 = 0xEED1E12AL;
        int32_t l_134 = (-7L);
        l_9--;
        l_17 = (safe_mod_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u(0xFEL, l_16)), g_4[0][9][5]));
        if (((safe_add_func_uint16_t_u_u(g_2, g_6)) && 248UL))
        { /* block id: 6 */
            uint16_t l_20 = 0xE74AL;
            return l_20;
        }
        else
        { /* block id: 8 */
            l_17 = ((safe_add_func_uint8_t_u_u(g_3, g_6)) >= g_6);
            if (g_2)
                break;
            g_4[0][7][4] = 2L;
        }
        l_134 |= (safe_mul_func_uint16_t_u_u((func_25(g_3) , g_4[0][7][4]), 0UL));
    }
    if ((((safe_sub_func_uint64_t_u_u(((safe_add_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_u((((((l_17 ^ 255UL) <= g_81) , l_17) ^ g_122) != 0UL), l_16)) , l_17), l_17)) == 0xF07F5898L), 0x1A71D37E9AE4E8F9LL)) > g_122) ^ g_81))
    { /* block id: 68 */
        uint32_t l_147 = 0xE97851F5L;
        int32_t l_149 = 0xECDD1267L;
        l_148 = (safe_lshift_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(l_16, l_147)), g_81)) || g_81), 5));
        g_2 = (0xDCL > g_6);
        l_149 |= 0L;
    }
    else
    { /* block id: 72 */
        int64_t l_151 = 0xA4C7201BE58EEB3FLL;
        int32_t l_156 = (-4L);
        int32_t l_157 = 0x5E26C2FEL;
        int32_t l_158 = (-7L);
        uint8_t l_162 = 249UL;
        uint64_t l_183 = 0x582C1F3011294E48LL;
        uint32_t l_184 = 8UL;
        int32_t l_187 = (-4L);
        int64_t l_190 = 0xB28C7E9381029D39LL;
        int16_t l_191[5][5][2] = {{{0L,0x5A11L},{0L,0x409FL},{(-9L),(-9L)},{0L,(-9L)},{(-9L),0x409FL}},{{0L,0x5A11L},{0L,0L},{0x5A11L,0x409FL},{0x5A11L,0L},{0L,0x5A11L}},{{0L,0x409FL},{(-9L),(-9L)},{0L,(-9L)},{(-9L),0x409FL},{0L,0x5A11L}},{{0L,0L},{0x5A11L,0x409FL},{0x5A11L,0L},{0L,0x5A11L},{0L,0x409FL}},{{(-9L),(-9L)},{0L,(-9L)},{(-9L),0x409FL},{0L,0x5A11L},{0L,0L}}};
        int i, j, k;
        if ((l_16 , g_5))
        { /* block id: 73 */
            int16_t l_150[10][7][3] = {{{0L,(-1L),0xD00BL},{0xEDF5L,0x8D45L,0L},{0xEDF5L,0x2E5DL,0x4EA7L},{0L,0xEDF5L,0x2014L},{0x4EA7L,0L,0xAA1AL},{0xA384L,0x4C99L,(-1L)},{6L,6L,0x979CL}},{{0x2E5DL,(-1L),(-4L)},{0x2014L,0x9C0AL,0x624FL},{0x624FL,0xFFDCL,0x4EA7L},{0x2C18L,0x2014L,0x624FL},{0x94EEL,0x0691L,(-4L)},{0xA384L,0x7A9AL,0x979CL},{(-5L),0x4EA7L,(-1L)}},{{0xFFDCL,(-1L),0xAA1AL},{0x07B6L,0x94EEL,0x2014L},{6L,0xEDFFL,0x4EA7L},{0x4C99L,0x07B6L,0L},{0x9C0AL,0x07B6L,0xD00BL},{0xA384L,0xEDFFL,1L},{0x8B5CL,0x94EEL,0xE52FL}},{{0xEDFFL,(-1L),(-3L)},{0x0691L,0x4EA7L,0x0691L},{0L,0x7A9AL,0x4EA7L},{0x7A9AL,0x0691L,0x07B6L},{0x8D45L,0x2014L,0L},{0xA384L,0xFFDCL,(-4L)},{0x8D45L,0x9C0AL,0x4373L}},{{0x7A9AL,(-1L),0xD76AL},{0L,6L,6L},{0x0691L,0x4C99L,0x4EA7L},{0xEDFFL,0L,0xEDF5L},{0x8B5CL,0xEDF5L,0x04EAL},{0xA384L,0x2E5DL,0x303BL},{0x9C0AL,0x8D45L,0x303BL}},{{0x4C99L,(-1L),0x04EAL},{6L,(-5L),0xEDF5L},{0x07B6L,0x2C18L,0x4EA7L},{0xFFDCL,6L,6L},{(-5L),0x624FL,0xD76AL},{0xA384L,0L,0x4373L},{0x94EEL,0x8B5CL,(-4L)}},{{0x2C18L,(-4L),0xE52FL},{0x8AF1L,0L,(-1L)},{(-9L),6L,0x5321L},{0x2014L,0x8AF1L,0x8C2DL},{0x6EDFL,0xD416L,0x979CL},{0xD76AL,0x07B6L,0x94EEL},{0x5321L,1L,6L}},{{6L,(-4L),(-4L)},{0xA384L,0xB398L,0x3EB7L},{0xA384L,0x2014L,0x5321L},{6L,0xA384L,(-9L)},{0x5321L,0x3EB7L,0x303BL},{0xD76AL,0x624FL,(-5L)},{0x6EDFL,0x6EDFL,0x9C0AL}},{{0x2014L,(-4L),(-1L)},{(-9L),0x6885L,0x8AF1L},{0x8AF1L,0L,0x5321L},{0x07B6L,(-9L),0x8AF1L},{0L,0x8C2DL,(-1L)},{0xD76AL,0x0691L,0x9C0AL},{1L,0x5321L,(-5L)}},{{0L,(-4L),0x303BL},{(-1L),0L,(-9L)},{0xD416L,0xEDF5L,0x5321L},{0x624FL,(-1L),0x3EB7L},{0x6885L,(-1L),(-4L)},{0xD76AL,0xEDF5L,6L},{0L,0L,0x94EEL}}};
            int32_t l_154 = (-1L);
            int32_t l_159 = 0x2ACB64CFL;
            int i, j, k;
            g_2 = g_5;
            ++l_162;
            g_81 = ((+(g_4[0][7][4] == g_122)) && l_160);
        }
        else
        { /* block id: 77 */
            int8_t l_173 = 0xF2L;
            g_5 = (!(safe_lshift_func_uint8_t_u_u(g_2, 5)));
            g_4[0][7][4] = (safe_sub_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u((1UL ^ 0x4DL), g_122)), l_173));
            return g_81;
        }
        g_81 ^= (-1L);
        if ((safe_rshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(((g_6 , l_157) != 0xF3CCL), g_4[0][7][1])) && 0x3560D2B7L), g_6)))
        { /* block id: 83 */
            uint64_t l_182 = 0xDD4C34E27C4DB56ALL;
            l_184 |= ((safe_mod_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u((0x190DBC92L || l_157), 65530UL)) && l_182), l_182)) , l_183);
        }
        else
        { /* block id: 85 */
            int32_t l_188 = (-1L);
            int32_t l_192 = 0x11373275L;
            int32_t l_193 = 0L;
            g_4[0][9][0] = ((safe_mod_func_uint16_t_u_u(l_187, g_122)) && l_17);
            if (l_16)
                goto lbl_189;
lbl_189:
            l_156 = l_188;
            ++g_194;
        }
    }
    l_153 = (((safe_mul_func_uint8_t_u_u(g_81, l_16)) > g_194) < 0x76D6D69B0F209FDCLL);
    l_161 &= ((safe_mul_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(0x2CL, 2)), 15)) > l_17), 0x12L)) || l_160), 0x738BL)) ^ g_194);
    return l_148;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_2 g_3 g_6 g_81 g_122
 * writes: g_3 g_4 g_2 g_81 g_122
 */
static int64_t  func_25(uint16_t  p_26)
{ /* block id: 13 */
    const int32_t l_27 = 0x3C3AE507L;
    int32_t l_28 = 0x62B50098L;
    const uint32_t l_120[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
    int32_t l_129 = 0x8B969CE4L;
    int32_t l_130[1];
    uint16_t l_131 = 65529UL;
    int i;
    for (i = 0; i < 1; i++)
        l_130[i] = 0xFF7E3BC0L;
    if (((l_27 > l_28) >= p_26))
    { /* block id: 14 */
        g_3 = (safe_lshift_func_uint16_t_u_u(((l_27 ^ g_5) < 0xD748AEE5L), l_27));
        g_122 ^= func_31((safe_lshift_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(((safe_mod_func_uint32_t_u_u(func_41(g_4[0][9][3]), l_27)) , g_4[0][2][0]), 0UL)), 6)), l_120[3], g_6);
    }
    else
    { /* block id: 59 */
        int8_t l_127 = (-1L);
        int32_t l_128 = 0xD77F32F3L;
        l_127 = (safe_add_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u(1UL, g_6)) || g_6), 0xA468L));
        l_128 = 0x8C049E58L;
    }
    l_28 = (p_26 || 0x6C1A719620DE4005LL);
    --l_131;
    return l_120[1];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_31(uint64_t  p_32, const uint32_t  p_33, const int8_t  p_34)
{ /* block id: 55 */
    uint32_t l_121 = 0x8926895FL;
    l_121 |= p_33;
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_4 g_6 g_81
 * writes: g_4 g_2 g_81
 */
static uint32_t  func_41(uint32_t  p_42)
{ /* block id: 16 */
    int16_t l_45[8][3][6] = {{{1L,0x884AL,9L,0x7F6FL,0x7E8FL,(-1L)},{0x4FCFL,0x447FL,1L,(-1L),0x94FCL,0xB5F2L},{0x4FCFL,6L,0x7F6FL,0x7F6FL,6L,0x4FCFL}},{{1L,0x7E8FL,0L,0x7F6FL,0x3986L,1L},{0x4FCFL,1L,0x879AL,(-1L),0x447FL,9L},{0x4FCFL,0x8E16L,(-1L),0x7F6FL,0x8E16L,1L}},{{1L,0x3986L,0xB5F2L,0x7F6FL,0x884AL,0x7F6FL},{0x4FCFL,0x94FCL,0x4FCFL,(-1L),1L,0L},{0x4FCFL,0L,1L,0x7F6FL,0L,0x879AL}},{{1L,0x884AL,9L,0x7F6FL,0x7E8FL,(-1L)},{0x4FCFL,0x447FL,1L,(-1L),0x94FCL,0xB5F2L},{0x4FCFL,6L,0x7F6FL,0x7F6FL,6L,0x4FCFL}},{{1L,0x7E8FL,0L,0x7F6FL,0x3986L,1L},{0x4FCFL,1L,0x879AL,(-1L),0x447FL,9L},{0x4FCFL,0x8E16L,(-1L),0x7F6FL,0x8E16L,1L}},{{1L,0x3986L,0xB5F2L,0x7F6FL,0x884AL,0x7F6FL},{0x4FCFL,0x94FCL,0x4FCFL,(-1L),0xB5F2L,0xD85AL},{0x9D76L,0x7F6FL,0L,0x8CFBL,0x7F6FL,1L}},{{(-1L),1L,(-1L),0x8CFBL,0x4FCFL,0xC5ABL},{0x9D76L,9L,(-1L),0xC5ABL,0L,0L},{0x9D76L,1L,0x8CFBL,0x8CFBL,1L,0x9D76L}},{{(-1L),0x4FCFL,0xD85AL,0x8CFBL,0x879AL,0L},{0x9D76L,0xB5F2L,1L,0xC5ABL,9L,(-1L)},{0x9D76L,(-1L),0xC5ABL,0x8CFBL,(-1L),(-1L)}}};
    int32_t l_49[6][2] = {{0L,(-8L)},{(-8L),0L},{(-8L),(-8L)},{0L,(-8L)},{(-8L),0L},{(-8L),(-8L)}};
    uint16_t l_51 = 0xC6B0L;
    uint8_t l_64 = 252UL;
    int8_t l_105 = (-1L);
    uint8_t l_117 = 255UL;
    int i, j, k;
    if (g_2)
    { /* block id: 17 */
        int32_t l_46 = 1L;
        int32_t l_48 = 0x0C30F141L;
        int32_t l_50 = 0xCF37692AL;
        int32_t l_58 = (-1L);
        int32_t l_59 = 1L;
        int32_t l_60[4] = {0xA09F94EBL,0xA09F94EBL,0xA09F94EBL,0xA09F94EBL};
        uint16_t l_61[2];
        int i;
        for (i = 0; i < 2; i++)
            l_61[i] = 0UL;
lbl_67:
        if (((safe_lshift_func_uint16_t_u_u(0xC19AL, p_42)) , g_3))
        { /* block id: 18 */
            int32_t l_47 = 0L;
            g_4[0][7][4] = (0xA8L <= p_42);
            --l_51;
            if (l_51)
                goto lbl_116;
            g_2 = 0xD9F6C850L;
            return g_4[0][0][0];
        }
        else
        { /* block id: 23 */
            int32_t l_54 = 0x6E0E3F56L;
            int32_t l_55 = 0L;
            int32_t l_56 = (-3L);
            int32_t l_57[3][4] = {{0x87092E0EL,0x87092E0EL,0L,0x87092E0EL},{0x87092E0EL,0x01105CA7L,0x01105CA7L,0x87092E0EL},{0x01105CA7L,0x87092E0EL,0x01105CA7L,0x01105CA7L}};
            int i, j;
            --l_61[0];
            if (l_51)
                goto lbl_67;
            l_46 = 0x4E3C6AA5L;
            l_49[0][0] ^= 0xB049BDD3L;
            l_64++;
        }
        l_49[2][1] = (safe_add_func_uint32_t_u_u(p_42, g_2));
        g_81 &= ((safe_div_func_uint64_t_u_u(((func_72(((safe_div_func_uint8_t_u_u(p_42, p_42)) , l_46), g_4[0][7][4], l_46, g_6, g_6) <= 0x897626F057967921LL) <= 0xF5L), l_64)) >= p_42);
        g_4[0][8][1] = 0L;
    }
    else
    { /* block id: 35 */
        int16_t l_84 = (-1L);
        for (l_51 = (-3); (l_51 != 34); l_51++)
        { /* block id: 38 */
            uint8_t l_85 = 246UL;
            int16_t l_98 = 0xCDC6L;
            int32_t l_99 = 0x3582EBD2L;
            int32_t l_100 = 0L;
            int32_t l_101 = 0x46C46319L;
            uint64_t l_102 = 7UL;
            --l_85;
            l_100 = (safe_mul_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((((((safe_rshift_func_uint16_t_u_u((((0xE8A9L ^ 0xC189L) ^ g_81) <= g_3), l_84)) || 0x6214041400369CA9LL) != l_49[0][0]) , 1UL) == l_98), 0x62ABL)), l_99)), p_42)), p_42));
            ++l_102;
        }
        l_49[2][0] = (0xEA97F26D1EE2074ALL < l_105);
        l_49[2][0] = p_42;
        if (((safe_mod_func_uint32_t_u_u(g_4[0][7][4], g_6)) ^ p_42))
        { /* block id: 45 */
            uint64_t l_114 = 0xB1DC04404CF58845LL;
            int32_t l_115[5] = {0x9C141FE1L,0x9C141FE1L,0x9C141FE1L,0x9C141FE1L,0x9C141FE1L};
            int i;
            l_115[2] = (safe_sub_func_uint32_t_u_u((safe_div_func_uint32_t_u_u(((safe_sub_func_uint16_t_u_u(0x3B42L, 0x9203L)) <= l_114), p_42)), l_84));
        }
        else
        { /* block id: 47 */
            return g_4[0][7][4];
        }
    }
lbl_116:
    l_49[4][1] |= (g_81 , g_3);
    l_117--;
    return g_4[0][0][2];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint64_t  func_72(uint32_t  p_73, uint16_t  p_74, uint64_t  p_75, int32_t  p_76, int64_t  p_77)
{ /* block id: 31 */
    uint16_t l_80 = 65530UL;
    return l_80;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_194, "g_194", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 71
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 81
   depth: 2, occurrence: 10
   depth: 3, occurrence: 8
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 86
XXX times a non-volatile is write: 37
XXX times a volatile is read: 24
XXX    times read thru a pointer: 0
XXX times a volatile is write: 10
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 151
XXX percentage of non-volatile access: 78.3

XXX forward jumps: 3
XXX backward jumps: 0

XXX stmts: 68
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 22
   depth: 2, occurrence: 30

XXX percentage a fresh-made variable is used: 19.6
XXX percentage an existing variable is used: 80.4
********************* end of statistics **********************/

