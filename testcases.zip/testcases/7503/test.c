/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12529752789521261862
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2 = 0xACL;
static int32_t g_3 = 0L;
static uint32_t g_9 = 0xE4B9A733L;
static int16_t g_11 = (-1L);
static uint16_t g_17[9][4][5] = {{{0xFBDEL,0xB66EL,1UL,65535UL,65532UL},{0xFBDEL,65535UL,0x0506L,0x0506L,65535UL},{0x41B4L,0xB66EL,0x0506L,0xE737L,0xE2CFL},{0xB1A8L,65532UL,1UL,0x0506L,0xE2CFL}},{{0xB604L,1UL,0xE737L,65535UL,65535UL},{0xB1A8L,1UL,0xC1B0L,0x483BL,65532UL},{0x41B4L,65532UL,0xE737L,0x483BL,0x5917L},{0xFBDEL,0xB66EL,1UL,65535UL,65532UL}},{{0xFBDEL,65535UL,0x0506L,0x0506L,65535UL},{0x41B4L,0xB467L,0xE2CFL,65532UL,3UL},{9UL,65535UL,65535UL,0xE2CFL,3UL},{0UL,0x45DCL,65532UL,0xB66EL,0x5657L}},{{9UL,0x45DCL,0x5917L,0UL,65535UL},{1UL,65535UL,65532UL,0UL,0xE0CDL},{0xE74AL,0xB467L,65535UL,0xB66EL,65535UL},{0xE74AL,0x5657L,0xE2CFL,0xE2CFL,0x5657L}},{{1UL,0xB467L,0xE2CFL,65532UL,3UL},{9UL,65535UL,65535UL,0xE2CFL,3UL},{0UL,0x45DCL,65532UL,0xB66EL,0x5657L},{9UL,0x45DCL,0x5917L,0UL,65535UL}},{{1UL,65535UL,65532UL,0UL,0xE0CDL},{0xE74AL,0xB467L,65535UL,0xB66EL,65535UL},{0xE74AL,0x5657L,0xE2CFL,0xE2CFL,0x5657L},{1UL,0xB467L,0xE2CFL,65532UL,3UL}},{{9UL,65535UL,65535UL,0xE2CFL,3UL},{0UL,0x45DCL,65532UL,0xB66EL,0x5657L},{9UL,0x45DCL,0x5917L,0UL,65535UL},{1UL,65535UL,65532UL,0UL,0xE0CDL}},{{0xE74AL,0xB467L,65535UL,0xB66EL,65535UL},{0xE74AL,0x5657L,0xE2CFL,0xE2CFL,0x5657L},{1UL,0xB467L,0xE2CFL,65532UL,3UL},{9UL,65535UL,65535UL,0xE2CFL,3UL}},{{0UL,0x45DCL,65532UL,0xB66EL,0x5657L},{9UL,0x45DCL,0x5917L,0UL,65535UL},{1UL,65535UL,65532UL,0UL,0xE0CDL},{0xE74AL,0xB467L,65535UL,0xB66EL,65535UL}}};
static volatile uint8_t g_45 = 0x62L;/* VOLATILE GLOBAL g_45 */
static uint64_t g_61 = 18446744073709551610UL;
static volatile int8_t g_77 = (-1L);/* VOLATILE GLOBAL g_77 */
static volatile int32_t g_78 = 0L;/* VOLATILE GLOBAL g_78 */
static int32_t g_85 = 0L;
static volatile uint32_t g_86 = 0UL;/* VOLATILE GLOBAL g_86 */
static uint16_t g_91 = 1UL;
static volatile uint16_t g_92 = 1UL;/* VOLATILE GLOBAL g_92 */
static volatile uint32_t g_95 = 0xE4ADB81CL;/* VOLATILE GLOBAL g_95 */
static int16_t g_100 = 0xEE73L;
static int64_t g_116[8] = {0x4DE641B022312402LL,0x4DE641B022312402LL,0x4DE641B022312402LL,0x4DE641B022312402LL,0x4DE641B022312402LL,0x4DE641B022312402LL,0x4DE641B022312402LL,0x4DE641B022312402LL};
static volatile uint8_t g_117 = 0x0EL;/* VOLATILE GLOBAL g_117 */
static uint32_t g_136 = 18446744073709551606UL;
static volatile int32_t g_139 = (-1L);/* VOLATILE GLOBAL g_139 */
static volatile uint16_t g_140 = 0x1148L;/* VOLATILE GLOBAL g_140 */
static volatile uint32_t g_150 = 1UL;/* VOLATILE GLOBAL g_150 */
static uint64_t g_155 = 0x7E3BC08C7137E7E5LL;
static uint32_t g_195 = 0x85C49E2CL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint16_t  func_26(int64_t  p_27, int32_t  p_28, uint16_t  p_29, int8_t  p_30, uint64_t  p_31);
static uint16_t  func_37(int8_t  p_38);
static int32_t  func_48(int32_t  p_49, int16_t  p_50, uint32_t  p_51, uint32_t  p_52, int8_t  p_53);
static uint32_t  func_62(int32_t  p_63, int8_t  p_64, uint16_t  p_65, uint32_t  p_66);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_9 g_11 g_17 g_45 g_86 g_91 g_92 g_95 g_117 g_100 g_136 g_140 g_150 g_155 g_116 g_139 g_77 g_85 g_195
 * writes: g_3 g_9 g_11 g_17 g_45 g_61 g_2 g_86 g_91 g_92 g_95 g_100 g_117 g_136 g_140 g_150 g_155 g_139 g_195
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_8 = 0xAC196A16L;
    int32_t l_13 = 7L;
    int32_t l_14 = 1L;
    int32_t l_15 = 0x0FC36FE5L;
    int32_t l_16 = 0L;
    uint8_t l_32[3];
    int i;
    for (i = 0; i < 3; i++)
        l_32[i] = 0x62L;
    g_3 = g_2;
    if ((safe_mul_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((l_8 , l_8), l_8)) < 0x2FL), g_2)))
    { /* block id: 2 */
lbl_12:
        g_9 &= ((g_3 ^ 0UL) , g_3);
    }
    else
    { /* block id: 4 */
        int16_t l_10 = 1L;
        l_10 = (g_9 != 6UL);
        g_11 |= g_9;
        if (g_11)
            goto lbl_12;
    }
    g_17[3][3][3]++;
    g_195 |= (safe_sub_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(func_26(g_17[6][1][2], l_16, l_15, g_2, l_32[0]), l_16)), 9)), 0x2BL));
    return l_32[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_17 g_2 g_45 g_11 g_86 g_3 g_91 g_92 g_95 g_117 g_100 g_136 g_140 g_150 g_155 g_116 g_139 g_77 g_85
 * writes: g_45 g_61 g_2 g_86 g_3 g_91 g_92 g_95 g_100 g_117 g_136 g_140 g_150 g_155 g_139
 */
static uint16_t  func_26(int64_t  p_27, int32_t  p_28, uint16_t  p_29, int8_t  p_30, uint64_t  p_31)
{ /* block id: 10 */
    int16_t l_162 = 0x7C52L;
    int32_t l_166 = 0xC4CAD9DDL;
    uint16_t l_194 = 65535UL;
    l_162 = (safe_add_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(func_37((safe_mod_func_uint64_t_u_u(g_9, g_17[0][3][0]))), p_30)) , p_27), 0x880BL));
    if (p_27)
    { /* block id: 75 */
        for (p_30 = 14; (p_30 != (-25)); p_30--)
        { /* block id: 78 */
            int32_t l_165 = 0x63BBE5BFL;
            l_166 ^= (((l_165 , 0UL) , 0UL) >= l_165);
        }
    }
    else
    { /* block id: 81 */
        int32_t l_169 = (-5L);
        l_169 = (safe_lshift_func_uint16_t_u_u(((((((g_100 >= 65530UL) , p_30) == p_31) < g_150) == p_29) == 0UL), g_116[6]));
        l_169 = (((safe_lshift_func_uint16_t_u_u(0x3A27L, l_166)) != p_29) , g_139);
        l_169 = (((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u((((((safe_sub_func_uint16_t_u_u(((safe_lshift_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u(l_169, p_30)) <= p_28), p_29)) , l_169), 0xE9C0L)) < g_77) >= 0UL) > p_28) , 0x4F74L), l_162)) && l_162), 1)), p_28)) , l_169) < 18446744073709551615UL);
    }
    g_139 = (safe_mul_func_uint16_t_u_u(((((((((safe_add_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((l_194 && l_166), 1)), g_77)), l_162)) && 65530UL) && 0UL) ^ g_116[1]) >= 0xDDL) <= g_85) || g_155) && l_194), p_28));
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_45 g_11 g_86 g_3 g_91 g_92 g_95 g_117 g_17 g_100 g_136 g_140 g_150 g_155 g_9
 * writes: g_45 g_61 g_2 g_86 g_3 g_91 g_92 g_95 g_100 g_117 g_136 g_140 g_150 g_155 g_139
 */
static uint16_t  func_37(int8_t  p_38)
{ /* block id: 11 */
    uint16_t l_42 = 65529UL;
    if (g_2)
    { /* block id: 12 */
        int32_t l_41 = (-6L);
        l_42++;
        g_45++;
    }
    else
    { /* block id: 15 */
        uint64_t l_56 = 1UL;
        g_139 = func_48((safe_rshift_func_uint16_t_u_u(l_56, l_56)), p_38, l_42, l_42, l_42);
    }
    return g_100;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_45 g_2 g_86 g_3 g_91 g_92 g_95 g_117 g_17 g_100 g_136 g_140 g_150 g_155 g_9
 * writes: g_61 g_2 g_86 g_3 g_91 g_92 g_95 g_100 g_117 g_136 g_140 g_150 g_155
 */
static int32_t  func_48(int32_t  p_49, int16_t  p_50, uint32_t  p_51, uint32_t  p_52, int8_t  p_53)
{ /* block id: 16 */
    int8_t l_59 = 0xE9L;
    int32_t l_101[2][7][10] = {{{5L,(-1L),0xCFC51725L,0L,3L,(-1L),5L,0x16196426L,0xE43225DEL,0x2CB3A568L},{0x2CB3A568L,(-1L),0x4248A5E3L,9L,(-1L),(-9L),0x123FB112L,1L,0x68B84F8CL,(-1L)},{0x3821FDCAL,7L,0x100029D1L,(-1L),1L,1L,0x16196426L,3L,9L,0L},{3L,0xEC4AE7C4L,9L,0x05796792L,0xD28FF552L,(-1L),0x721E4501L,1L,2L,1L},{0x100029D1L,0xCFC51725L,0x9312FBD8L,0x50BF12BFL,0x9312FBD8L,0xCFC51725L,0x100029D1L,0x9AC72693L,6L,0x13C76A60L},{0x0C234542L,8L,5L,3L,0xD28FF552L,0x68B84F8CL,0L,9L,(-8L),(-4L)},{1L,8L,0xE171BA0DL,0x05796792L,0xE43225DEL,(-1L),0xAFF43A56L,0x13C76A60L,0L,0x721E4501L}},{{3L,0x977ACE7FL,(-9L),(-1L),0L,0L,0x4248A5E3L,1L,0x05796792L,(-1L)},{0x16196426L,9L,0x100029D1L,0x3977A87EL,1L,9L,0x50BF12BFL,(-1L),2L,5L},{1L,0L,0xE43225DEL,9L,3L,0x50BF12BFL,0x16196426L,0xD28FF552L,0xD28FF552L,0x16196426L},{0xEC4AE7C4L,1L,0x0C234542L,0x0C234542L,1L,0xEC4AE7C4L,5L,0x721E4501L,0x123FB112L,0xCFC51725L},{0x4248A5E3L,0x123FB112L,0x50BF12BFL,0L,0L,0L,7L,1L,9L,0xD28FF552L},{0x4248A5E3L,(-1L),(-4L),0x13C76A60L,0x05796792L,0xEC4AE7C4L,0xD28FF552L,0L,7L,6L},{0xEC4AE7C4L,0xD28FF552L,0L,7L,6L,0x50BF12BFL,0L,0xEDAB18E1L,0x16196426L,1L}}};
    int32_t l_110 = 0x7285EB11L;
    int32_t l_111 = 0x6C064F7AL;
    int32_t l_134 = 0x18605C96L;
    int32_t l_135 = (-10L);
    uint64_t l_148 = 0xA468D3B5AAABC806LL;
    int i, j, k;
    if (((safe_mul_func_uint16_t_u_u((0x5BL != 255UL), 7UL)) == g_11))
    { /* block id: 17 */
        uint32_t l_67 = 0xD45EB447L;
        uint16_t l_108 = 4UL;
        int32_t l_113 = 1L;
        int32_t l_114 = 1L;
        int32_t l_115[5] = {0xD9707E28L,0xD9707E28L,0xD9707E28L,0xD9707E28L,0xD9707E28L};
        int i;
        if (l_59)
        { /* block id: 18 */
            int8_t l_60 = 0x23L;
            int32_t l_109 = 0x400D3BC8L;
            int32_t l_112[1][6][6] = {{{6L,0x48970CE4L,7L,3L,1L,0x97F26D1EL},{0x97F26D1EL,0xAEFF72AEL,0x48970CE4L,0x48970CE4L,0xAEFF72AEL,0x97F26D1EL},{3L,(-1L),7L,(-9L),0x97F26D1EL,5L},{0xAEFF72AEL,6L,0L,0x97F26D1EL,0L,6L},{0xAEFF72AEL,5L,0x97F26D1EL,(-9L),7L,(-1L)},{3L,0x97F26D1EL,0xAEFF72AEL,0x48970CE4L,0x48970CE4L,0xAEFF72AEL}}};
            int i, j, k;
            g_61 = l_60;
            l_101[0][4][4] = ((func_62(l_67, l_60, p_53, p_51) == 4294967295UL) || p_49);
            p_49 &= (safe_mod_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(((safe_mod_func_uint8_t_u_u(((0x9DF9L || 0x1CF2L) < l_108), l_60)) , p_53), p_53)), p_51));
            --g_117;
        }
        else
        { /* block id: 47 */
            uint32_t l_127 = 0xE94EDE48L;
            p_49 = (safe_add_func_uint8_t_u_u(((!(safe_lshift_func_uint16_t_u_u(((+g_3) <= g_86), 9))) >= l_101[0][4][4]), g_2));
            l_127 |= (+g_17[0][1][2]);
            p_49 = 0xB9DD5306L;
        }
        for (g_100 = 0; (g_100 >= 13); g_100 = safe_add_func_uint8_t_u_u(g_100, 1))
        { /* block id: 54 */
            int8_t l_132 = 0x97L;
            int32_t l_133 = 0xD7775BE2L;
            p_49 = (safe_rshift_func_uint8_t_u_u(1UL, 2));
            l_133 = (g_86 , l_132);
            ++g_136;
        }
        g_140--;
    }
    else
    { /* block id: 60 */
        uint16_t l_147 = 0xA4CDL;
        int32_t l_153 = (-1L);
        int32_t l_154 = 0x98B969CEL;
        if ((safe_div_func_uint16_t_u_u((((safe_sub_func_uint32_t_u_u((l_59 == p_49), 0xA0AEB11FL)) || l_147) <= l_148), p_50)))
        { /* block id: 61 */
            return g_2;
        }
        else
        { /* block id: 63 */
            int8_t l_149 = 0xC0L;
            p_49 = ((g_86 , 18446744073709551606UL) > l_149);
            --g_150;
        }
        --g_155;
        l_153 = (safe_mul_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(l_101[0][4][4], l_154)), p_50));
    }
    return g_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_2 g_86 g_3 g_11 g_91 g_92 g_95
 * writes: g_2 g_86 g_3 g_91 g_92 g_95 g_100
 */
static uint32_t  func_62(int32_t  p_63, int8_t  p_64, uint16_t  p_65, uint32_t  p_66)
{ /* block id: 20 */
    volatile int8_t l_68[6][2] = {{0xA4L,0x1CL},{0xA4L,0x1CL},{0xA4L,0x1CL},{0xA4L,0x1CL},{0xA4L,0x1CL},{0xA4L,0x1CL}};
    int32_t l_80 = 1L;
    int32_t l_83 = 0xC8B64E3CL;
    int i, j;
    l_68[4][1] = g_45;
    for (g_2 = 0; (g_2 == 58); g_2 = safe_add_func_uint32_t_u_u(g_2, 5))
    { /* block id: 24 */
        int16_t l_75 = 0x3935L;
        int32_t l_84[6] = {0xB049BDD3L,0xB049BDD3L,0xB049BDD3L,0xB049BDD3L,0xB049BDD3L,0xB049BDD3L};
        int i;
        for (p_64 = 0; (p_64 <= (-19)); p_64 = safe_sub_func_uint64_t_u_u(p_64, 2))
        { /* block id: 27 */
            uint32_t l_74 = 0xE7029BB2L;
            int32_t l_76 = 0L;
            int32_t l_79 = 1L;
            int32_t l_81 = 0L;
            int32_t l_82[5][9][5] = {{{(-3L),0xF40AC15CL,0L,0x292777EFL,0L},{(-10L),0L,0x6C5FA607L,0xA0179E4CL,0x4EB44D53L},{(-2L),0xF40AC15CL,0x2FD4AE77L,(-10L),0x225D6239L},{(-2L),1L,0x6E08938CL,0L,0x9571DA88L},{(-10L),0x72FAF722L,0xEE4D5011L,0x9D133480L,0x225D6239L},{(-3L),5L,1L,0x9D133480L,0x4EB44D53L},{1L,0x6E08938CL,5L,0L,0L},{(-2L),(-5L),1L,(-10L),0x6CE7EF2AL},{7L,1L,0L,0L,(-1L)}},{{(-6L),0x292777EFL,0x292777EFL,(-6L),0x1DF381B9L},{7L,(-2L),0xF60D197AL,3L,0x1DF381B9L},{(-1L),(-2L),(-3L),0xE1357373L,(-1L)},{0xE1357373L,0xA0179E4CL,0x822E7BB9L,3L,(-8L)},{0x7E09FA00L,0x799115BAL,0x822E7BB9L,(-6L),1L},{1L,0x822E7BB9L,(-3L),0L,0xACFA70DAL},{3L,0x799115BAL,0xF60D197AL,1L,(-1L)},{3L,0xA0179E4CL,0x292777EFL,(-1L),(-5L)},{1L,(-2L),0L,0x91208AFAL,(-1L)}},{{0x7E09FA00L,(-2L),0xA0179E4CL,0x91208AFAL,0xACFA70DAL},{0xE1357373L,0x292777EFL,(-2L),(-1L),1L},{(-1L),1L,0xA0179E4CL,1L,(-8L)},{7L,1L,0L,0L,(-1L)},{(-6L),0x292777EFL,0x292777EFL,(-6L),0x1DF381B9L},{7L,(-2L),0xF60D197AL,3L,0x1DF381B9L},{(-1L),(-2L),(-3L),0xE1357373L,(-1L)},{0xE1357373L,0xA0179E4CL,0x822E7BB9L,3L,(-8L)},{0x7E09FA00L,0x799115BAL,0x822E7BB9L,(-6L),1L}},{{1L,0x822E7BB9L,(-3L),0L,0xACFA70DAL},{3L,0x799115BAL,0xF60D197AL,1L,(-1L)},{3L,0xA0179E4CL,0x292777EFL,(-1L),(-5L)},{1L,(-2L),0L,0x91208AFAL,(-1L)},{0x7E09FA00L,(-2L),0xA0179E4CL,0x91208AFAL,0xACFA70DAL},{0xE1357373L,0x292777EFL,(-2L),(-1L),1L},{(-1L),1L,0xA0179E4CL,1L,(-8L)},{7L,1L,0L,0L,(-1L)},{(-6L),0x292777EFL,0x292777EFL,(-6L),0x1DF381B9L}},{{7L,(-2L),0xF60D197AL,3L,0x1DF381B9L},{(-1L),(-2L),(-3L),0xE1357373L,(-1L)},{0xE1357373L,0xA0179E4CL,0x822E7BB9L,3L,(-8L)},{0x7E09FA00L,0x799115BAL,0x822E7BB9L,(-6L),1L},{1L,0x822E7BB9L,(-3L),0L,0xACFA70DAL},{3L,0x799115BAL,0xF60D197AL,1L,(-1L)},{3L,0xA0179E4CL,0x292777EFL,(-1L),(-5L)},{1L,(-2L),0L,0x91208AFAL,(-1L)},{0x7E09FA00L,(-2L),0xA0179E4CL,0x91208AFAL,0xACFA70DAL}}};
            int i, j, k;
            l_74 = (!((18446744073709551615UL != p_65) == 0xC30FL));
            --g_86;
            return p_65;
        }
        for (g_3 = 15; (g_3 >= (-25)); g_3--)
        { /* block id: 34 */
            g_91 &= (l_75 != g_11);
            ++g_92;
            l_80 = l_84[5];
            ++g_95;
        }
        g_100 = ((safe_mul_func_uint16_t_u_u(0xD236L, 0x7F80L)) > p_64);
        l_80 = 0x39521466L;
    }
    return p_65;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_17[i][j][k], "g_17[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_116[i], "g_116[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_150, "g_150", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_195, "g_195", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 70
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 69
   depth: 2, occurrence: 9
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 13, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 98
XXX times a non-volatile is write: 34
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 10
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 47
XXX percentage of non-volatile access: 88

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 58
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 21
   depth: 2, occurrence: 21

XXX percentage a fresh-made variable is used: 37.4
XXX percentage an existing variable is used: 62.6
********************* end of statistics **********************/

