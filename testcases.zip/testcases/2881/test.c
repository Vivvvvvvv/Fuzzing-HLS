/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16348504357853013079
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[7] = {8L,0xB9F9B319L,8L,8L,0xB9F9B319L,8L,8L};
static volatile int32_t g_3[3] = {0x5C6F1BF5L,0x5C6F1BF5L,0x5C6F1BF5L};
static volatile int32_t g_4[4] = {0xCEAFD94FL,0xCEAFD94FL,0xCEAFD94FL,0xCEAFD94FL};
static int32_t g_5 = 0xD00693E9L;
static int32_t g_8 = 1L;
static uint16_t g_46 = 0x7675L;
static uint16_t g_76 = 0UL;
static uint8_t g_77 = 0x94L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_17(int64_t  p_18, uint8_t  p_19, int64_t  p_20);
static uint16_t  func_25(int16_t  p_26, int64_t  p_27, int32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_8 g_3 g_2 g_4 g_76 g_77
 * writes: g_5 g_8 g_4 g_46 g_3 g_2 g_76 g_77
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_9 = 0L;
    int32_t l_42 = 2L;
    for (g_5 = 8; (g_5 <= 1); g_5 = safe_sub_func_int32_t_s_s(g_5, 9))
    { /* block id: 3 */
        int64_t l_10 = 0L;
        int32_t l_12 = 4L;
        int32_t l_13 = (-9L);
        for (g_8 = 0; (g_8 <= 6); g_8 += 1)
        { /* block id: 6 */
            int32_t l_11 = 0xB4456E34L;
            uint16_t l_14 = 0UL;
            int i;
            l_14++;
        }
        g_8 = 1L;
        g_77 ^= func_17((safe_mul_func_int8_t_s_s((safe_div_func_uint16_t_u_u((func_25(g_3[0], g_5, l_9) & 0L), l_42)), 0x87L)), l_9, g_8);
        if (l_10)
            break;
    }
    g_8 ^= ((((safe_rshift_func_int16_t_s_u(l_9, 14)) ^ g_4[3]) && l_9) <= 0UL);
    g_3[0] = (safe_mul_func_uint16_t_u_u(((-7L) && g_5), l_42));
    return l_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_3 g_2 g_4 g_5 g_76
 * writes: g_8 g_4 g_46 g_3 g_2 g_76
 */
static int32_t  func_17(int64_t  p_18, uint8_t  p_19, int64_t  p_20)
{ /* block id: 13 */
    int32_t l_45[8] = {(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L)};
    uint32_t l_53 = 0xD94485E0L;
    int i;
    for (g_8 = 0; (g_8 < 23); g_8 = safe_add_func_uint8_t_u_u(g_8, 5))
    { /* block id: 16 */
        g_4[3] = (p_19 && l_45[1]);
    }
    g_46 = (l_45[1] | l_45[1]);
    if ((p_18 < g_3[0]))
    { /* block id: 20 */
        uint16_t l_51[4];
        uint16_t l_52 = 65535UL;
        int32_t l_58 = 0L;
        int i;
        for (i = 0; i < 4; i++)
            l_51[i] = 0x5DAEL;
        l_53 = (safe_mod_func_int16_t_s_s(((safe_div_func_int8_t_s_s(0L, l_51[1])) >= 0x3B91L), l_52));
        l_58 ^= (safe_mul_func_uint8_t_u_u(((safe_rshift_func_int16_t_s_u(0xFE0CL, 13)) || 0xF83BF0B62E56CDAALL), p_18));
        g_3[0] = ((safe_sub_func_int32_t_s_s((0UL < 0L), g_8)) , g_2[3]);
    }
    else
    { /* block id: 24 */
        uint16_t l_64 = 0x0C1AL;
        l_45[1] |= (safe_sub_func_uint64_t_u_u((!(l_64 ^ g_4[3])), l_64));
        for (g_8 = 0; (g_8 <= 6); g_8 += 1)
        { /* block id: 28 */
            int32_t l_71 = 5L;
            int i;
            g_2[g_8] = (safe_rshift_func_uint16_t_u_s((safe_sub_func_int16_t_s_s(0x4491L, g_2[g_8])), 12));
            l_71 &= (((safe_rshift_func_uint16_t_u_s(((((((g_2[g_8] || l_53) & 9L) > 1UL) , g_2[g_8]) | 0x1489D4C8L) | p_19), 14)) >= l_45[7]) , 0x0CD78DC7L);
            g_76 |= (safe_mul_func_uint8_t_u_u(((safe_lshift_func_int16_t_s_u((-1L), 6)) , g_5), g_3[1]));
            g_4[3] = (-3L);
        }
    }
    g_4[0] = (-6L);
    return l_45[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_8 g_5
 * writes:
 */
static uint16_t  func_25(int16_t  p_26, int64_t  p_27, int32_t  p_28)
{ /* block id: 10 */
    int32_t l_41 = (-4L);
    l_41 = (safe_mod_func_uint64_t_u_u((((safe_mod_func_uint32_t_u_u((safe_div_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((safe_add_func_int64_t_s_s((((((safe_lshift_func_int16_t_s_s((l_41 , g_2[3]), 12)) && l_41) && p_26) | (-1L)) <= g_8), p_26)) , p_27), p_27)), g_8)), g_8)) < l_41) > g_8), g_5));
    return p_26;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 10, occurrence: 2
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 44
XXX times a non-volatile is write: 15
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 25
XXX percentage of non-volatile access: 78.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 10
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 23.7
XXX percentage an existing variable is used: 76.3
********************* end of statistics **********************/

