/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4868143970314144744
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_8 = 18446744073709551613UL;/* VOLATILE GLOBAL g_8 */
static int64_t g_9 = 6L;
static uint32_t g_16 = 0xA4C924B5L;
static int64_t g_17 = 0xFFD8143836745799LL;
static volatile uint32_t g_23[10][2] = {{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL},{0UL,0UL}};
static uint32_t g_26 = 0xC12D4938L;
static int16_t g_32 = (-1L);
static int16_t g_36 = 0x2D78L;
static int16_t g_38 = 0x8B50L;
static uint64_t g_40 = 0x9F139888327BC4A6LL;
static uint16_t g_47 = 0x887EL;
static uint32_t g_70 = 0xE1C37891L;
static volatile uint32_t g_94 = 1UL;/* VOLATILE GLOBAL g_94 */
static uint8_t g_101 = 1UL;
static uint8_t g_109 = 255UL;
static uint64_t g_114[2][4] = {{0UL,0x53783AD51AC0D59BLL,0x53783AD51AC0D59BLL,0UL},{0x53783AD51AC0D59BLL,0UL,0x53783AD51AC0D59BLL,0x53783AD51AC0D59BLL}};
static volatile int8_t g_115 = 0xA6L;/* VOLATILE GLOBAL g_115 */
static volatile uint32_t g_116 = 1UL;/* VOLATILE GLOBAL g_116 */
static uint8_t g_119 = 0xDDL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint16_t  func_4(uint16_t  p_5);
static uint16_t  func_6(int32_t  p_7);
static uint16_t  func_49(const int32_t  p_50, const uint32_t  p_51, int16_t  p_52, int8_t  p_53);
static uint8_t  func_56(uint64_t  p_57, int16_t  p_58, uint8_t  p_59, uint8_t  p_60, const uint8_t  p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_9 g_23 g_17 g_26 g_16 g_32 g_38 g_47 g_70 g_94 g_40 g_101 g_116
 * writes: g_16 g_23 g_26 g_32 g_36 g_38 g_40 g_47 g_70 g_94 g_101 g_17 g_109 g_114 g_116 g_119
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_10 = 0L;
    int32_t l_39 = 1L;
    if (((safe_sub_func_uint16_t_u_u(func_4(func_6((((g_8 > g_9) <= l_10) <= l_10))), g_9)) == g_17))
    { /* block id: 13 */
        const uint16_t l_37 = 0xA065L;
        if ((g_8 && 0x8DAD4F6CL))
        { /* block id: 14 */
            uint16_t l_31 = 65534UL;
            g_26 = 0L;
            g_32 = (((safe_div_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_u(((func_6(g_17) , 3UL) != 0xD9L), 2)) && g_26), 0x64E48C0CL)) > l_31) ^ g_23[0][0]);
        }
        else
        { /* block id: 17 */
            int32_t l_33 = 0L;
            l_33 = g_16;
        }
        g_36 = ((((safe_mod_func_uint64_t_u_u(((((g_26 , l_10) <= 18446744073709551612UL) != 4294967295UL) != g_17), 0x59018101BC642EE1LL)) < g_9) , 5UL) < g_23[2][1]);
        g_38 = (func_4((l_37 || 0x7C2923F8C0E5C5CCLL)) , g_32);
        l_39 = 0x20B25230L;
    }
    else
    { /* block id: 23 */
        uint64_t l_46 = 0xAA07078C3FCEEEC8LL;
        if ((g_16 && l_10))
        { /* block id: 24 */
            uint32_t l_45 = 8UL;
            g_40 = ((4294967293UL < g_16) && 8UL);
            l_46 = func_6((safe_sub_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((func_6(l_45) || g_8), 0xAE87L)), 0UL)));
            g_47 = (-6L);
        }
        else
        { /* block id: 28 */
            uint32_t l_48 = 0x16A5C54CL;
            int32_t l_102 = 6L;
            l_48 = 0xE7732C35L;
            l_102 &= (func_49((safe_rshift_func_uint8_t_u_u((((func_56((safe_mul_func_uint8_t_u_u(5UL, 0UL)), g_8, g_38, g_47, l_48) ^ l_48) , l_46) > g_47), 3)), l_46, g_47, l_46) > 65531UL);
        }
        for (g_17 = 27; (g_17 <= 23); g_17 = safe_sub_func_uint32_t_u_u(g_17, 8))
        { /* block id: 54 */
            uint64_t l_107 = 0x336AE2794C0DA393LL;
            uint8_t l_108 = 0UL;
            l_108 = (safe_sub_func_uint32_t_u_u(((l_39 <= l_39) <= l_39), l_107));
            g_109 = l_107;
            g_114[1][3] = (safe_mul_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u(0x3F5AL, g_23[0][0])) && g_23[1][0]), l_39));
        }
    }
    ++g_116;
    g_119 = 0x5121EC5DL;
    return l_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_23
 * writes: g_16 g_23
 */
static uint16_t  func_4(uint16_t  p_5)
{ /* block id: 4 */
    int32_t l_18[2][6][5] = {{{0x0EBBD485L,2L,(-10L),0x4B5E4957L,0x4B5E4957L},{0xB4AF7BDDL,1L,0xB4AF7BDDL,1L,7L},{0x0EBBD485L,0x3EC58F55L,0x11721670L,0x4B5E4957L,(-9L)},{(-1L),1L,7L,0xB4AF7BDDL,0xB4AF7BDDL},{0x2F37FC03L,0L,0x2F37FC03L,(-10L),0x11721670L},{0x0881DDA8L,0L,0xCD833989L,0xB4AF7BDDL,7L}},{{(-1L),0L,(-1L),0x11721670L,0x11721670L},{0xCD833989L,0xF29C214FL,0xCD833989L,7L,0xB4AF7BDDL},{(-1L),0L,0x2F37FC03L,0x11721670L,(-10L)},{0x0881DDA8L,0xF29C214FL,(-5L),0xB4AF7BDDL,0xB4AF7BDDL},{0x2F37FC03L,0L,0x2F37FC03L,(-10L),0x11721670L},{0x0881DDA8L,0L,0xCD833989L,0xB4AF7BDDL,7L}}};
    uint64_t l_19[6] = {0UL,0UL,0UL,0UL,0UL,0UL};
    int32_t l_22 = (-4L);
    int i, j, k;
    for (p_5 = 0; (p_5 >= 59); p_5 = safe_add_func_uint8_t_u_u(p_5, 3))
    { /* block id: 7 */
        g_16 = (safe_rshift_func_uint8_t_u_u(((0UL == 0UL) && p_5), p_5));
    }
    l_19[4]++;
    g_23[0][0]++;
    return l_18[1][4][4];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_6(int32_t  p_7)
{ /* block id: 1 */
    uint8_t l_11[10];
    int i;
    for (i = 0; i < 10; i++)
        l_11[i] = 0x83L;
    p_7 = l_11[8];
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_70 g_94 g_16 g_40 g_101
 * writes: g_94 g_101
 */
static uint16_t  func_49(const int32_t  p_50, const uint32_t  p_51, int16_t  p_52, int8_t  p_53)
{ /* block id: 45 */
    uint64_t l_93 = 1UL;
    int32_t l_95 = 0xC8A6F198L;
    g_94 ^= (((safe_sub_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(p_51, 0x93L)), g_70)) , l_93) , 0x961BCE71L);
    l_95 |= g_16;
    g_101 |= (((safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((+p_51), 0UL)), g_70)) || g_40) >= 4294967286UL);
    return p_52;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_8 g_70 g_47 g_23 g_17
 * writes: g_16 g_70
 */
static uint8_t  func_56(uint64_t  p_57, int16_t  p_58, uint8_t  p_59, uint8_t  p_60, const uint8_t  p_61)
{ /* block id: 30 */
    uint64_t l_66 = 0x9526DE3FE27FCE2ELL;
    int64_t l_78 = 0x23BA0E38899A8624LL;
    int32_t l_87 = (-6L);
    int8_t l_88 = 5L;
    for (g_16 = 1; (g_16 > 55); g_16 = safe_add_func_uint32_t_u_u(g_16, 2))
    { /* block id: 33 */
        uint32_t l_79[8][9] = {{1UL,1UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL,1UL,1UL,0UL},{0xC7D6112DL,0x79556C6CL,18446744073709551612UL,18446744073709551611UL,18446744073709551611UL,18446744073709551612UL,0x79556C6CL,0xC7D6112DL,18446744073709551612UL},{1UL,1UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL,1UL,1UL,0UL},{0xC7D6112DL,0x79556C6CL,18446744073709551612UL,18446744073709551611UL,18446744073709551611UL,18446744073709551612UL,0x79556C6CL,0xC7D6112DL,18446744073709551612UL},{1UL,1UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL,1UL,1UL,0UL},{0xC7D6112DL,0x79556C6CL,18446744073709551612UL,18446744073709551611UL,18446744073709551611UL,18446744073709551612UL,0x79556C6CL,0xC7D6112DL,18446744073709551612UL},{1UL,1UL,0UL,18446744073709551610UL,18446744073709551610UL,0UL,1UL,1UL,0UL},{0xC7D6112DL,0x79556C6CL,18446744073709551612UL,18446744073709551611UL,18446744073709551611UL,18446744073709551612UL,0x79556C6CL,0xC7D6112DL,18446744073709551612UL}};
        int32_t l_84 = 5L;
        int i, j;
        if ((l_66 , g_8))
        { /* block id: 34 */
            int8_t l_69 = 0x4EL;
            l_69 = (safe_sub_func_uint16_t_u_u(l_66, p_57));
            --g_70;
        }
        else
        { /* block id: 37 */
            uint32_t l_80 = 9UL;
            int32_t l_81 = 7L;
            l_81 = ((((safe_sub_func_uint16_t_u_u((+((safe_sub_func_uint16_t_u_u((g_47 , l_78), l_79[5][5])) < 0xAFL)), l_80)) , g_23[8][1]) , l_80) && 4294967295UL);
            l_84 = ((safe_rshift_func_uint8_t_u_u(p_61, p_61)) , p_59);
            l_81 = ((safe_add_func_uint16_t_u_u((g_23[0][0] || l_81), l_80)) == 5UL);
            l_87 = g_17;
        }
    }
    return l_88;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_23[i][j], "g_23[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_109, "g_109", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_114[i][j], "g_114[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 45
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 66
XXX times a non-volatile is write: 29
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 45
XXX percentage of non-volatile access: 87.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 8
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 41.7
XXX percentage an existing variable is used: 58.3
********************* end of statistics **********************/

