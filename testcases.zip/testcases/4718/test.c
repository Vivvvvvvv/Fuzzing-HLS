/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10496088740054803040
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint64_t  f0;
   uint32_t  f1;
   int32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_18[7] = {0x977A1245L,0x977A1245L,0x977A1245L,0x977A1245L,0x977A1245L,0x977A1245L,0x977A1245L};
static int32_t g_19 = 0x3C67EE39L;
static int8_t g_21 = 0xB9L;
static struct S0 g_22 = {0x71A05132D7AF2C9ALL,0x30DFDDAEL,-2L};/* VOLATILE GLOBAL g_22 */
static uint32_t g_38[3] = {4294967295UL,4294967295UL,4294967295UL};
static int8_t g_41 = 0x94L;
static int32_t g_42 = (-3L);
static volatile uint32_t g_43 = 0x458230B5L;/* VOLATILE GLOBAL g_43 */
static volatile int64_t g_46 = (-4L);/* VOLATILE GLOBAL g_46 */
static volatile int32_t g_47 = 4L;/* VOLATILE GLOBAL g_47 */
static int8_t g_48 = 0x2EL;
static int8_t g_49 = 1L;
static int32_t g_50 = (-1L);
static volatile uint8_t g_51[2] = {6UL,6UL};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint32_t  func_5(int32_t  p_6, uint8_t  p_7, uint32_t  p_8);
static int32_t  func_9(uint64_t  p_10, int16_t  p_11, uint32_t  p_12, int16_t  p_13, uint64_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_18 g_19 g_22 g_21 g_38 g_43 g_51 g_41 g_42
 * writes: g_21 g_38 g_41 g_43 g_51 g_47
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_2 = 0xDBL;
    int16_t l_20 = 9L;
    int32_t l_26[2];
    int32_t l_56 = 6L;
    int32_t l_58 = 0x8DBEC8B2L;
    int i;
    for (i = 0; i < 2; i++)
        l_26[i] = 0xB2FAA963L;
    l_2++;
    l_26[1] = ((func_5(func_9((+((safe_add_func_uint8_t_u_u(0x41L, g_18[3])) | l_2)), l_2, g_19, l_20, g_19), g_19, l_20) | l_2) , g_21);
    if (((safe_mul_func_int16_t_s_s((safe_add_func_int64_t_s_s((safe_div_func_int32_t_s_s((safe_add_func_uint8_t_u_u((0UL & 0L), g_22.f0)), l_26[1])), l_26[1])), 0x3DDBL)) , l_20))
    { /* block id: 17 */
        uint16_t l_37[8] = {0x6A75L,0x6A75L,0x6A75L,0x6A75L,0x6A75L,0x6A75L,0x6A75L,0x6A75L};
        int i;
        g_38[2] ^= ((safe_mod_func_int16_t_s_s(((((0x8F94L != 0x0187L) , l_37[4]) , g_22.f1) < 0xDC4B54C5L), 65533UL)) || l_37[0]);
        g_41 = (safe_div_func_uint8_t_u_u(g_22.f2, 0xDFL));
        g_43--;
        --g_51[0];
    }
    else
    { /* block id: 22 */
        const uint16_t l_57 = 0x71C2L;
        l_58 = (((safe_mod_func_uint8_t_u_u(((((0UL ^ l_56) < l_57) >= l_26[1]) | l_57), g_38[2])) | g_51[1]) <= g_41);
        g_47 = (g_41 , l_57);
        g_47 = (safe_add_func_uint64_t_u_u(l_57, 0L));
        return l_56;
    }
    return g_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_22.f0 g_22.f1
 * writes:
 */
static uint32_t  func_5(int32_t  p_6, uint8_t  p_7, uint32_t  p_8)
{ /* block id: 6 */
    int16_t l_24 = 0x5CC7L;
    int32_t l_25 = 0xD23C5AD0L;
    for (p_8 = 1; (p_8 <= 6); p_8 += 1)
    { /* block id: 9 */
        return l_24;
    }
    l_25 = ((((-3L) >= p_7) ^ l_24) | 6L);
    l_25 = g_22.f0;
    l_25 = g_22.f1;
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_22
 * writes: g_21
 */
static int32_t  func_9(uint64_t  p_10, int16_t  p_11, uint32_t  p_12, int16_t  p_13, uint64_t  p_14)
{ /* block id: 2 */
    int8_t l_23 = 0xAEL;
    g_21 = g_19;
    l_23 = ((g_22 , g_22.f2) < 0x1F38L);
    return p_10;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_22.f0, "g_22.f0", print_hash_value);
    transparent_crc(g_22.f1, "g_22.f1", print_hash_value);
    transparent_crc(g_22.f2, "g_22.f2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_38[i], "g_38[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_51[i], "g_51[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 23
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 37
XXX times a non-volatile is write: 11
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 9

XXX percentage a fresh-made variable is used: 39.3
XXX percentage an existing variable is used: 60.7
********************* end of statistics **********************/

