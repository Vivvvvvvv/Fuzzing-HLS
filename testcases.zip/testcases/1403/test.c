/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17291816082125292293
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 0xAB274BF9L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0xCAD2086BL;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 1L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6[3][8][10] = {{{0x30A4CCFDL,(-1L),5L,2L,(-1L),0L,0x112DEF90L,7L,2L,0L},{(-1L),0x50315362L,0x6BB2F144L,7L,4L,0x34A938F7L,4L,7L,0x6BB2F144L,0x50315362L},{8L,0x112DEF90L,5L,0xF29C8DDAL,7L,0xBD52A284L,4L,5L,0x4F9DBC9BL,4L},{0x30A4CCFDL,0x50315362L,0x4F9DBC9BL,2L,0x50315362L,0xBD52A284L,0x112DEF90L,0xC1D6B3BFL,5L,0L},{8L,(-1L),0x6BB2F144L,0xC1D6B3BFL,0x50315362L,0x34A938F7L,0x17D0B0A3L,7L,0x50315362L,0x4F63ABEFL},{(-7L),0xAAB72B21L,(-5L),0L,(-10L),1L,0xAB39E224L,1L,1L,0xAB39E224L},{0xF27D2703L,0x4F63ABEFL,(-5L),(-5L),0x4F63ABEFL,0xF27D2703L,0xAAB72B21L,7L,1L,0xD5D70512L},{0x8F585950L,0x4F63ABEFL,0x50315362L,7L,0x17D0B0A3L,0x6C4A87FCL,0xAB39E224L,0L,0x50315362L,0x17D0B0A3L}},{{0x8F585950L,0xAAB72B21L,1L,0x112DEF90L,(-10L),0xF27D2703L,0x17D0B0A3L,1L,(-5L),0x17D0B0A3L},{0xF27D2703L,0x17D0B0A3L,1L,(-5L),0x17D0B0A3L,1L,0xAAB72B21L,0x112DEF90L,(-5L),0xD5D70512L},{(-7L),0xAB39E224L,0x50315362L,0x112DEF90L,0x4F63ABEFL,0x6C4A87FCL,0x4F63ABEFL,0x112DEF90L,0x50315362L,0xAB39E224L},{5L,0xAAB72B21L,1L,7L,(-10L),0x145BA13BL,0x4F63ABEFL,1L,1L,0x4F63ABEFL},{0xF27D2703L,0xAB39E224L,1L,(-5L),0xAB39E224L,0x145BA13BL,0xAAB72B21L,0L,1L,0xD5D70512L},{5L,0x17D0B0A3L,0x50315362L,0L,0xAB39E224L,0x6C4A87FCL,0x17D0B0A3L,7L,0x50315362L,0x4F63ABEFL},{(-7L),0xAAB72B21L,(-5L),0L,(-10L),1L,0xAB39E224L,1L,1L,0xAB39E224L},{0xF27D2703L,0x4F63ABEFL,(-5L),(-5L),0x4F63ABEFL,0xF27D2703L,0xAAB72B21L,7L,1L,0xD5D70512L}},{{0x8F585950L,0x4F63ABEFL,0x50315362L,7L,0x17D0B0A3L,0x6C4A87FCL,0xAB39E224L,0L,0x50315362L,0x17D0B0A3L},{0x8F585950L,0xAAB72B21L,1L,0x112DEF90L,(-10L),0xF27D2703L,0x17D0B0A3L,1L,(-5L),0x17D0B0A3L},{0xF27D2703L,0x17D0B0A3L,1L,(-5L),0x17D0B0A3L,1L,0xAAB72B21L,0x112DEF90L,(-5L),0xD5D70512L},{(-7L),0xAB39E224L,0x50315362L,0x112DEF90L,0x4F63ABEFL,0x6C4A87FCL,0x4F63ABEFL,0x112DEF90L,0x50315362L,0xAB39E224L},{5L,0xAAB72B21L,1L,7L,(-10L),0x145BA13BL,0x4F63ABEFL,1L,1L,0x4F63ABEFL},{0xF27D2703L,0xAB39E224L,1L,(-5L),0xAB39E224L,0x145BA13BL,0xAAB72B21L,0L,1L,0xD5D70512L},{5L,0x17D0B0A3L,0x50315362L,0L,0xAB39E224L,0x6C4A87FCL,0x17D0B0A3L,7L,0x50315362L,0x4F63ABEFL},{(-7L),0xAAB72B21L,(-5L),0L,(-10L),1L,0xAB39E224L,(-2L),(-2L),0x39ECF4A4L}}};
static int32_t g_7 = 0x5604491DL;
static int32_t g_53 = 5L;
static int64_t g_68[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
static volatile int32_t g_108 = 0L;/* VOLATILE GLOBAL g_108 */
static uint32_t g_136 = 0x4898B4B1L;
static volatile uint64_t g_179 = 0x88053D1B3A134931LL;/* VOLATILE GLOBAL g_179 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint16_t  func_15(const int32_t  p_16, uint64_t  p_17, int8_t  p_18, int32_t  p_19);
static int32_t  func_26(uint64_t  p_27, int32_t  p_28, uint8_t  p_29, uint16_t  p_30);
static uint64_t  func_31(uint32_t  p_32, int32_t  p_33, int8_t  p_34, const uint8_t  p_35);
static uint32_t  func_36(uint64_t  p_37, int32_t  p_38, int32_t  p_39, uint32_t  p_40, int32_t  p_41);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_3 g_4 g_6 g_5 g_53 g_68 g_136 g_108 g_179
 * writes: g_7 g_4 g_53 g_6 g_3 g_136 g_108
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[1][3][10] = {{{0x51DBA339L,0xFB871C7BL,0x51DBA339L,0x51DBA339L,0xFB871C7BL,0x51DBA339L,0x51DBA339L,0xFB871C7BL,0x51DBA339L,0x51DBA339L},{0xFB871C7BL,0xFB871C7BL,0L,0xFB871C7BL,0xFB871C7BL,0L,0xFB871C7BL,0xFB871C7BL,0L,0xFB871C7BL},{0xFB871C7BL,0x51DBA339L,0x51DBA339L,0xFB871C7BL,0x51DBA339L,0x51DBA339L,0xFB871C7BL,0x51DBA339L,0x51DBA339L,0xFB871C7BL}}};
    uint32_t l_159 = 18446744073709551608UL;
    int32_t l_193 = (-5L);
    int i, j, k;
lbl_147:
    for (g_7 = 0; (g_7 >= 0); g_7 -= 1)
    { /* block id: 3 */
        uint32_t l_8 = 4294967288UL;
        l_8--;
        for (l_8 = 0; (l_8 <= 0); l_8 += 1)
        { /* block id: 7 */
            uint32_t l_135 = 0x43A831FEL;
            g_136 |= (safe_sub_func_int32_t_s_s((safe_mod_func_int8_t_s_s(((func_15(g_3, g_7, g_7, g_7) >= 8L) <= 0x6123D7B4L), l_135)), l_135));
            return g_7;
        }
        for (g_53 = 0; (g_53 >= 0); g_53 -= 1)
        { /* block id: 84 */
            uint32_t l_137 = 5UL;
            --l_137;
            g_3 = (l_8 <= 0xC270F0C57F21A038LL);
            g_3 |= g_68[8];
        }
    }
    if ((safe_lshift_func_int8_t_s_u(g_108, l_2[0][1][2])))
    { /* block id: 90 */
        uint32_t l_142 = 0x7C32A718L;
        int32_t l_143 = 7L;
        int32_t l_149 = (-1L);
        int32_t l_151[3];
        uint32_t l_152 = 18446744073709551615UL;
        int8_t l_157[6][6][7] = {{{0x4AL,0x56L,0xD0L,0x7AL,(-10L),0xADL,0x58L},{0x4AL,(-1L),0x7FL,0xD0L,0x7FL,(-1L),0x4AL},{0x58L,0xADL,(-10L),0x7AL,0xD0L,0x56L,0x4AL},{0xD0L,0x4AL,(-1L),(-1L),0x4AL,0xD0L,0x58L},{(-1L),(-1L),(-10L),0x58L,0L,0xD0L,0xD0L},{0x7AL,0L,0x7FL,0L,0x7AL,0x56L,(-1L)}},{{1L,(-1L),0xD0L,0xADL,0x7AL,(-1L),0x7AL},{0xA5L,0x4AL,0x4AL,0xA5L,0L,0xADL,1L},{1L,0xADL,0L,0xA5L,0x4AL,0x4AL,0xA5L},{0x7AL,(-1L),0x7AL,0xADL,0xD0L,(-1L),1L},{(-1L),0x56L,0x7AL,0L,0x7FL,0L,0x7AL},{0xD0L,0xD0L,0L,0x58L,(-10L),(-1L),(-1L)}},{{0x58L,0xD0L,0x4AL,(-1L),(-1L),0x4AL,0xD0L},{0x4AL,0x56L,0xD0L,0x7AL,(-10L),0xADL,0x58L},{0x4AL,(-1L),0x7FL,0xD0L,0x7FL,(-1L),0x4AL},{0x58L,0xADL,(-10L),0x7AL,0xD0L,0x56L,0x4AL},{0xD0L,0x4AL,(-1L),(-1L),0x4AL,0xD0L,0x58L},{(-1L),(-1L),(-10L),0x58L,0L,0xD0L,0xD0L}},{{0x7AL,0L,0x7FL,0L,0x7AL,0x56L,(-1L)},{1L,(-1L),0xD0L,0xADL,0x7AL,(-1L),0x7AL},{0xA5L,0x4AL,0x4AL,0xA5L,0L,0xADL,1L},{1L,0x56L,(-1L),0xD0L,0xA5L,0xA5L,0xD0L},{(-1L),0x58L,(-1L),0x56L,0L,0x4AL,0x7AL},{0x58L,(-10L),(-1L),(-1L),1L,(-1L),(-1L)}},{{0L,0L,(-1L),0xADL,0x7FL,0x4AL,0x58L},{0xADL,0L,0xA5L,0x4AL,0x4AL,0xA5L,0L},{0xA5L,(-10L),0L,(-1L),0x7FL,0x56L,0xADL},{0xA5L,0x58L,1L,0L,1L,0x58L,0xA5L},{0xADL,0x56L,0x7FL,(-1L),0L,(-10L),0xA5L},{0L,0xA5L,0x4AL,0x4AL,0xA5L,0L,0xADL}},{{0x58L,0x4AL,0x7FL,0xADL,(-1L),0L,0L},{(-1L),(-1L),1L,(-1L),(-1L),(-10L),0x58L},{0x7AL,0x4AL,0L,0x56L,(-1L),0x58L,(-1L)},{0xD0L,0xA5L,0xA5L,0xD0L,(-1L),0x56L,0x7AL},{0x7AL,0x56L,(-1L),0xD0L,0xA5L,0xA5L,0xD0L},{(-1L),0x58L,(-1L),0x56L,0L,0x4AL,0x7AL}}};
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_151[i] = 0x874B77E7L;
lbl_155:
        if (l_142)
        { /* block id: 91 */
            uint8_t l_144 = 0x85L;
            l_143 = (g_53 < 0x04L);
            --l_144;
            if (l_144)
                goto lbl_155;
        }
        else
        { /* block id: 94 */
            int64_t l_148 = 0L;
            int32_t l_150[6][9][1] = {{{0x14A8FFE7L},{0x3CBD2EE5L},{(-4L)},{0x182A6E03L},{0x58BC3E6DL},{0x957ECFBFL},{1L},{1L},{0x957ECFBFL}},{{0x58BC3E6DL},{0x182A6E03L},{(-4L)},{0x3CBD2EE5L},{0x14A8FFE7L},{0x58BC3E6DL},{0x61964D51L},{0x99F2ADBEL},{0xFF152E6DL}},{{0x079DBC9DL},{0x58BC3E6DL},{0x079DBC9DL},{0xFF152E6DL},{0x99F2ADBEL},{0x61964D51L},{0x58BC3E6DL},{0x14A8FFE7L},{0x3CBD2EE5L}},{{(-4L)},{0x182A6E03L},{0x58BC3E6DL},{0x957ECFBFL},{1L},{1L},{0x957ECFBFL},{0x58BC3E6DL},{0x182A6E03L}},{{(-4L)},{0x3CBD2EE5L},{0x14A8FFE7L},{0x58BC3E6DL},{0x61964D51L},{0x99F2ADBEL},{0xFF152E6DL},{0x079DBC9DL},{0x58BC3E6DL}},{{0x079DBC9DL},{0xFF152E6DL},{0x99F2ADBEL},{0x61964D51L},{0x58BC3E6DL},{0x14A8FFE7L},{0x3CBD2EE5L},{(-4L)},{0x182A6E03L}}};
            int i, j, k;
            if (g_53)
                goto lbl_147;
            l_152++;
        }
        if (((g_4 >= l_2[0][1][7]) , g_68[2]))
        { /* block id: 99 */
            g_6[1][2][0] |= (g_68[7] >= 8UL);
            g_4 = g_4;
            l_2[0][0][0] = g_136;
        }
        else
        { /* block id: 103 */
            int32_t l_156 = 0x55F038DDL;
            int32_t l_158 = 0x3CC302F6L;
            g_53 = 0xB6DA4907L;
            --l_159;
        }
        if (l_152)
        { /* block id: 107 */
            int64_t l_162 = 0xA08B820AD96D95FFLL;
            uint8_t l_163 = 255UL;
            uint64_t l_178 = 18446744073709551612UL;
            int32_t l_180 = 0x76B8D06BL;
            g_7 = g_5;
            if (l_152)
                goto lbl_181;
            ++l_163;
lbl_181:
            l_180 ^= (safe_lshift_func_uint8_t_u_u((((safe_mul_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((safe_sub_func_int8_t_s_s(((safe_add_func_int64_t_s_s((safe_mul_func_uint8_t_u_u(l_2[0][1][4], l_2[0][1][6])), l_178)) != g_4), (-6L))), l_142)), g_68[8])) & l_149) , g_179), 5));
            return l_178;
        }
        else
        { /* block id: 113 */
            uint64_t l_182 = 0x571BFDB4B204B197LL;
            return l_182;
        }
    }
    else
    { /* block id: 116 */
        uint32_t l_191 = 1UL;
        uint8_t l_192[1][7][2] = {{{0xFCL,9UL},{0x49L,9UL},{0xFCL,2UL},{2UL,0xFCL},{9UL,0x49L},{9UL,0xFCL},{2UL,2UL}}};
        int i, j, k;
        l_193 |= (safe_mul_func_uint8_t_u_u(((+((safe_mul_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((((+g_5) , g_4) , l_191), g_7)), l_159)) <= l_192[0][1][0])) , g_179), l_2[0][0][7]));
        for (l_159 = 0; (l_159 != 24); ++l_159)
        { /* block id: 120 */
            uint64_t l_196 = 0xB7F7EF872575A83ELL;
            g_108 = ((l_196 > 255UL) != l_192[0][2][1]);
        }
    }
    return l_159;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_7 g_5 g_53 g_3 g_68
 * writes: g_4 g_53 g_6 g_3
 */
static uint16_t  func_15(const int32_t  p_16, uint64_t  p_17, int8_t  p_18, int32_t  p_19)
{ /* block id: 8 */
    volatile uint16_t l_25 = 0xD0CDL;/* VOLATILE GLOBAL l_25 */
    uint32_t l_56 = 0x453D1DD1L;
    int32_t l_69[3][10] = {{0L,0L,5L,(-2L),5L,0L,0L,5L,(-2L),5L},{0L,0L,5L,(-2L),5L,0L,0L,5L,(-2L),0L},{5L,5L,0L,(-4L),0L,5L,5L,0L,(-4L),0L}};
    uint32_t l_70 = 0x6F411269L;
    int64_t l_109 = (-1L);
    int16_t l_110 = (-10L);
    uint32_t l_114 = 0UL;
    int i, j;
    if (g_4)
    { /* block id: 9 */
        uint8_t l_44 = 0UL;
        for (p_19 = 0; (p_19 <= (-13)); p_19--)
        { /* block id: 12 */
            int16_t l_22 = 1L;
            return l_22;
        }
        for (p_19 = 0; (p_19 == 21); p_19 = safe_add_func_uint8_t_u_u(p_19, 7))
        { /* block id: 17 */
            uint16_t l_42 = 0x4FD1L;
            int32_t l_43 = 0xEFBE72F2L;
            uint32_t l_49 = 18446744073709551615UL;
            l_25 = g_4;
            g_53 |= func_26(func_31(func_36(g_6[2][6][0], l_42, l_43, g_7, l_44), l_49, p_18, p_17), g_7, g_7, l_42);
            if (g_7)
                break;
        }
    }
    else
    { /* block id: 31 */
        int8_t l_57 = 2L;
        int32_t l_58[4] = {0x58ECE9E6L,0x58ECE9E6L,0x58ECE9E6L,0x58ECE9E6L};
        int i;
        for (p_19 = 2; (p_19 >= 0); p_19 -= 1)
        { /* block id: 34 */
            return p_19;
        }
        if ((safe_mul_func_int16_t_s_s(g_6[1][1][4], l_56)))
        { /* block id: 37 */
            uint32_t l_59 = 0x604811E3L;
            l_59++;
        }
        else
        { /* block id: 39 */
            l_69[0][1] = ((safe_lshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_u((((safe_div_func_uint32_t_u_u((((((p_17 | 0x76B242CFF427032CLL) ^ l_58[2]) && g_6[1][0][4]) && p_19) && g_3), l_56)) >= 0L) < p_17), g_68[2])), 4)) ^ g_7);
        }
        ++l_70;
    }
lbl_126:
    for (p_19 = 0; (p_19 != 9); p_19 = safe_add_func_int16_t_s_s(p_19, 3))
    { /* block id: 46 */
        uint8_t l_77 = 8UL;
        int32_t l_98 = 0x81933AC3L;
        int32_t l_103 = 0x43FBE49EL;
        int32_t l_105 = 0L;
        int32_t l_106 = 0xB10DF2DAL;
        int32_t l_107[7];
        int64_t l_111 = 0L;
        int8_t l_112 = 0x62L;
        int32_t l_113 = 0xBF5F1DF6L;
        int i;
        for (i = 0; i < 7; i++)
            l_107[i] = 0xC087C3A5L;
        for (l_56 = 0; (l_56 >= 59); ++l_56)
        { /* block id: 49 */
            uint64_t l_85 = 0x6F66B510C19ED05CLL;
            l_77 |= p_18;
            g_6[1][0][4] = ((safe_mod_func_uint64_t_u_u((((((safe_mod_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((+(9L && l_77)), l_85)), g_68[7])) , g_6[2][7][4]) & g_7) || l_85) ^ 0xE175A398L), g_7)) < p_19);
        }
        if ((safe_unary_minus_func_uint16_t_u(((((((safe_div_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((((((((safe_mod_func_uint32_t_u_u((((((((g_7 && l_69[0][1]) != l_25) , p_19) <= l_69[1][9]) , g_5) && p_16) > p_17), l_56)) , 0UL) & 0xDBD19AA3L) | g_68[3]) >= 0x30FA2875F205D52ALL) & g_68[5]) , l_77), (-1L))), g_68[2])) | p_17) <= p_18) && l_77) && g_3) < 0x4CC67FDBL))))
        { /* block id: 53 */
            g_3 = (p_19 < p_16);
            l_98 ^= (safe_mul_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u(((((!l_77) & p_18) > g_7) , p_17), p_16)) | g_68[2]), g_6[1][6][7]));
            g_6[2][0][1] = (safe_div_func_int16_t_s_s((-1L), g_5));
            if (g_6[0][1][7])
                continue;
        }
        else
        { /* block id: 58 */
            int8_t l_101 = 0xDCL;
            int32_t l_102[5] = {0x184C7448L,0x184C7448L,0x184C7448L,0x184C7448L,0x184C7448L};
            int32_t l_104[4][2] = {{0x1FECA717L,0x1FECA717L},{0x1FECA717L,0x1FECA717L},{0x1FECA717L,0x1FECA717L},{0x1FECA717L,0x1FECA717L}};
            int i, j;
            ++l_114;
            if (g_7)
                break;
            g_4 ^= 0L;
            g_6[1][0][4] = (g_6[0][4][5] , (-5L));
        }
        l_69[2][3] |= ((((0L | p_19) || (-10L)) & g_68[2]) < p_17);
    }
    for (p_17 = 18; (p_17 < 48); p_17++)
    { /* block id: 68 */
        uint32_t l_133 = 0x0B125740L;
        if ((safe_div_func_int8_t_s_s((safe_add_func_int16_t_s_s((safe_div_func_uint32_t_u_u((~(0UL > 1UL)), (-1L))), 0xEAEFL)), (-1L))))
        { /* block id: 69 */
            int32_t l_134 = (-8L);
            if (g_7)
                goto lbl_126;
            if (p_17)
                break;
            l_134 = (safe_add_func_int64_t_s_s((((safe_lshift_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_s(((l_133 & l_134) & p_17), p_16)) & l_133), p_16)) , g_6[1][0][4]) | l_134), (-1L)));
            if (l_133)
                break;
        }
        else
        { /* block id: 74 */
            return g_4;
        }
    }
    return p_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes:
 */
static int32_t  func_26(uint64_t  p_27, int32_t  p_28, uint8_t  p_29, uint16_t  p_30)
{ /* block id: 25 */
    uint32_t l_50 = 4294967289UL;
    ++l_50;
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes: g_4
 */
static uint64_t  func_31(uint32_t  p_32, int32_t  p_33, int8_t  p_34, const uint8_t  p_35)
{ /* block id: 22 */
    g_4 &= p_33;
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint32_t  func_36(uint64_t  p_37, int32_t  p_38, int32_t  p_39, uint32_t  p_40, int32_t  p_41)
{ /* block id: 19 */
    uint8_t l_47[6] = {0x33L,0x33L,2UL,0x33L,0x33L,2UL};
    int32_t l_48 = 0x2FEA2765L;
    int i;
    l_48 = (safe_mod_func_int8_t_s_s(0x7FL, l_47[5]));
    return g_6[2][5][1];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_68[i], "g_68[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    transparent_crc(g_179, "g_179", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 62
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 22
breakdown:
   depth: 1, occurrence: 78
   depth: 2, occurrence: 19
   depth: 3, occurrence: 2
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 2
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 22, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 110
XXX times a non-volatile is write: 34
XXX times a volatile is read: 28
XXX    times read thru a pointer: 0
XXX times a volatile is write: 12
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 195
XXX percentage of non-volatile access: 78.3

XXX forward jumps: 2
XXX backward jumps: 2

XXX stmts: 74
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 17
   depth: 2, occurrence: 44

XXX percentage a fresh-made variable is used: 16.1
XXX percentage an existing variable is used: 83.9
********************* end of statistics **********************/

