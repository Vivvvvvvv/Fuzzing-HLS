/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8998274295334247974
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_2 = 18446744073709551607UL;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[2] = {0x897A4A12L,0x897A4A12L};
static volatile int32_t g_4[9][4][1] = {{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}},{{0x2FD4914DL},{(-1L)},{0x2FD4914DL},{(-1L)}}};
static int32_t g_5 = 0x9D19AC19L;
static volatile int8_t g_69 = 0xE5L;/* VOLATILE GLOBAL g_69 */
static const volatile uint8_t g_153 = 0UL;/* VOLATILE GLOBAL g_153 */
static int32_t g_199 = 0xA306168AL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_10(int32_t  p_11, uint32_t  p_12);
static uint64_t  func_19(int32_t  p_20);
static uint64_t  func_24(const uint32_t  p_25, const int16_t  p_26, int16_t  p_27, uint16_t  p_28, uint32_t  p_29);
static uint8_t  func_38(uint64_t  p_39, int32_t  p_40);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_4 g_3 g_69 g_153 g_199
 * writes: g_2 g_5 g_4 g_3
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_9 = 0L;
    int32_t l_191 = 8L;
    int32_t l_192 = 0x6E377ABBL;
    int32_t l_193 = 0L;
    int32_t l_194 = 0x3768AC48L;
    int32_t l_195[5][2];
    uint32_t l_196 = 9UL;
    int i, j;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
            l_195[i][j] = 0xBEB80319L;
    }
lbl_8:
    g_2 = 1L;
    for (g_5 = 20; (g_5 < 15); g_5 = safe_sub_func_uint64_t_u_u(g_5, 4))
    { /* block id: 4 */
        if (g_5)
            goto lbl_8;
        g_4[6][1][0] = l_9;
        return g_2;
    }
    l_191 ^= func_10(g_4[8][3][0], l_9);
    ++l_196;
    return g_199;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_4 g_5 g_69 g_153
 * writes: g_4 g_5 g_3
 */
static int32_t  func_10(int32_t  p_11, uint32_t  p_12)
{ /* block id: 9 */
    int64_t l_18 = 0xF04B064BAE0FC36FLL;
    int32_t l_157 = (-1L);
    int32_t l_161 = 0x5CDDFB24L;
    int32_t l_164 = 0x78E667A4L;
    int32_t l_169 = 0x19620DE4L;
    int32_t l_171 = (-6L);
    int32_t l_172 = 0x000C4D80L;
    int32_t l_173 = 0x2E6A1E35L;
    for (p_12 = (-19); (p_12 > 19); p_12 = safe_add_func_uint32_t_u_u(p_12, 5))
    { /* block id: 12 */
        uint32_t l_17 = 0x4272BA75L;
        int32_t l_158 = 0xFB31ACB9L;
        int32_t l_163 = 0L;
        int32_t l_170[5][4][7] = {{{1L,0L,1L,0xE31AC302L,0xBF7460F0L,0x935D89A0L,0L},{1L,0xE8F995CBL,0xE7E5D39AL,(-1L),0x266C56F7L,0L,(-8L)},{0x248B132FL,3L,(-1L),1L,(-10L),(-7L),0x935D89A0L},{(-6L),1L,0L,0x1412115AL,0L,1L,(-6L)}},{{0xBF7460F0L,(-1L),1L,3L,0xE31AC302L,0L,1L},{0x898A221AL,0x266C56F7L,0xACC10BF7L,0x7E3BC08CL,0L,(-2L),0x266C56F7L},{1L,(-10L),1L,0x1D37E9AEL,1L,1L,1L},{0xACC10BF7L,0L,0L,0xACC10BF7L,(-1L),(-8L),0x84259954L}},{{1L,0xE31AC302L,(-1L),0L,1L,0x9ADAB8F0L,0xBF7460F0L},{(-1L),0L,0xE7E5D39AL,0x0F894422L,1L,1L,0x84259954L},{(-9L),1L,1L,1L,1L,1L,1L},{0L,(-1L),1L,0xDBEEBB44L,(-8L),0L,0x266C56F7L}},{{0x26852E78L,1L,0x935D89A0L,1L,3L,0x248B132FL,1L},{1L,1L,0x84259954L,0xDBEEBB44L,0x0F894422L,(-6L),(-6L)},{0xE31AC302L,1L,0L,1L,0xE31AC302L,0xBF7460F0L,0x935D89A0L},{0x2D96163BL,(-8L),0xACC10BF7L,0x0F894422L,0x84259954L,0x898A221AL,(-8L)}},{{1L,3L,0x208AC86FL,0L,(-6L),1L,(-10L)},{0x2D96163BL,0x0F894422L,0L,0xACC10BF7L,0x2AB5F7C5L,0xACC10BF7L,0L},{0xE31AC302L,0xE31AC302L,1L,0x1D37E9AEL,0x935D89A0L,1L,0xBF7460F0L},{1L,0x84259954L,(-1L),0x7E3BC08CL,1L,(-1L),0x0F894422L}}};
        uint32_t l_190 = 0xD92B7DB2L;
        int i, j, k;
        l_18 = ((safe_sub_func_uint64_t_u_u(l_17, p_12)) , 0xED1E12AAL);
        if ((((func_19((l_17 > 0x1BL)) || l_18) <= 0xB9DD5306L) , 1L))
        { /* block id: 65 */
            int64_t l_152 = 0xEA432D78657CAC61LL;
            if (g_3[1])
                break;
            return l_152;
        }
        else
        { /* block id: 68 */
            uint32_t l_156 = 0xC28C3218L;
            int32_t l_159 = 7L;
            int32_t l_160 = 0xB9EA2DD6L;
            int32_t l_162 = (-2L);
            int32_t l_165 = 0L;
            int32_t l_166 = (-1L);
            int32_t l_167 = 0L;
            int32_t l_168[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
            int8_t l_174 = 0x67L;
            uint32_t l_175[9][3] = {{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL},{0x551306FFL,4294967287UL,4294967287UL}};
            int i, j;
            g_5 |= (g_153 ^ l_17);
            g_5 = (safe_add_func_uint8_t_u_u((p_11 >= l_156), p_11));
            l_175[8][0]--;
            l_164 = l_168[3];
        }
        if (((((p_12 ^ 1UL) , p_12) && p_12) != p_12))
        { /* block id: 74 */
            uint32_t l_178 = 4294967295UL;
            int32_t l_181 = 0x0D76A68AL;
            l_178 = (l_158 != l_171);
            l_181 = (((safe_add_func_uint64_t_u_u(p_12, 0xC979CE062718EDF5LL)) ^ l_170[4][3][6]) , 0L);
            l_181 ^= ((g_4[2][3][0] < 0x0B73L) && g_4[6][2][0]);
            p_11 = ((safe_add_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u(((safe_div_func_uint8_t_u_u(p_11, g_4[1][3][0])) >= 0xA347L), l_181)) ^ 0x2BE0499FL), l_158)) , (-1L));
        }
        else
        { /* block id: 79 */
            p_11 |= (safe_rshift_func_uint8_t_u_u(((p_12 ^ l_190) || 0xE26C2FE1L), l_163));
            if (g_3[0])
                break;
        }
    }
    p_11 = (p_12 , g_4[8][3][0]);
    l_171 = (l_18 , 0xF25517FAL);
    g_3[0] ^= (-3L);
    return l_172;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_4 g_5 g_69
 * writes: g_4 g_5 g_3
 */
static uint64_t  func_19(int32_t  p_20)
{ /* block id: 14 */
    uint32_t l_23 = 0x8F59172DL;
    const uint16_t l_30 = 3UL;
    uint32_t l_111 = 3UL;
    uint16_t l_121 = 0x29D1L;
    int32_t l_123 = 1L;
    uint32_t l_126[4][4] = {{18446744073709551615UL,0xF0AF6214L,0xF0AF6214L,18446744073709551615UL},{0xF0AF6214L,18446744073709551615UL,0xF0AF6214L,0xF0AF6214L},{18446744073709551615UL,18446744073709551615UL,2UL,18446744073709551615UL},{18446744073709551615UL,0xF0AF6214L,0xF0AF6214L,18446744073709551615UL}};
    int32_t l_133 = 0L;
    int32_t l_134 = (-1L);
    int32_t l_135 = (-1L);
    int32_t l_136 = 1L;
    int16_t l_140 = 1L;
    int i, j;
    if ((safe_mul_func_uint16_t_u_u((p_20 , l_23), p_20)))
    { /* block id: 15 */
        uint32_t l_106[7] = {0xD82068EEL,4294967295UL,0xD82068EEL,0xD82068EEL,4294967295UL,0xD82068EEL,0x52146605L};
        int32_t l_122 = 0L;
        int32_t l_124 = (-1L);
        int32_t l_125[2][4] = {{0x3F78960EL,0x3F78960EL,0xA9312FBDL,0x3F78960EL},{0x3F78960EL,(-1L),(-1L),0x3F78960EL}};
        const int32_t l_131 = 3L;
        int16_t l_132 = 4L;
        uint32_t l_137 = 0UL;
        int i, j;
        p_20 = ((func_24((0xD5EC7E01L || g_3[1]), l_30, p_20, p_20, p_20) || l_30) && 1UL);
        l_106[5] = (-1L);
        if ((safe_add_func_uint8_t_u_u((((((safe_lshift_func_uint8_t_u_u((((l_23 ^ 1UL) >= p_20) < l_111), 0)) && 0x84F8L) ^ 0x821FL) < 0xAA39L) <= g_5), l_23)))
        { /* block id: 43 */
            p_20 |= (safe_mul_func_uint8_t_u_u(255UL, 255UL));
        }
        else
        { /* block id: 45 */
            const int32_t l_120 = 2L;
            g_4[7][2][0] = l_106[5];
            l_121 = ((safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(((p_20 , g_3[0]) , l_120), l_106[5])), p_20)), p_20)) >= p_20);
            ++l_126[2][2];
            l_123 = (((safe_mod_func_uint64_t_u_u(p_20, g_4[1][1][0])) , l_131) , 0x013582EBL);
        }
        ++l_137;
    }
    else
    { /* block id: 52 */
        volatile uint32_t l_148 = 0x84595356L;/* VOLATILE GLOBAL l_148 */
        int32_t l_151 = 0xE94EDE48L;
        g_3[1] = l_140;
        g_5 = (safe_div_func_uint32_t_u_u(0xEE2074A6L, l_23));
        for (l_134 = 0; (l_134 > 3); l_134++)
        { /* block id: 57 */
            uint64_t l_147 = 0xEE17268510E35A52LL;
            p_20 = p_20;
            p_20 = (((safe_sub_func_uint8_t_u_u(252UL, p_20)) , l_147) , 0xED343B42L);
            l_148 = ((g_3[0] , g_4[8][3][0]) , g_3[0]);
            l_151 ^= ((safe_div_func_uint32_t_u_u(p_20, 0xACF09C14L)) , l_126[2][2]);
        }
    }
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_5 g_3 g_69
 * writes: g_4 g_5 g_3
 */
static uint64_t  func_24(const uint32_t  p_25, const int16_t  p_26, int16_t  p_27, uint16_t  p_28, uint32_t  p_29)
{ /* block id: 16 */
    const uint16_t l_35 = 0x5119L;
    uint32_t l_41[9];
    int32_t l_89[5];
    uint32_t l_104 = 0xF288C1B9L;
    int i;
    for (i = 0; i < 9; i++)
        l_41[i] = 0x6C146DF8L;
    for (i = 0; i < 5; i++)
        l_89[i] = 1L;
    g_4[7][0][0] = (safe_mul_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((((1UL < g_2) ^ 2UL) < 0x1CF7L), 0x9257L)), l_35));
    l_89[3] &= (safe_mod_func_uint8_t_u_u(func_38(p_26, l_41[0]), 255UL));
    if (l_35)
        goto lbl_105;
lbl_105:
    l_89[3] = (safe_mul_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((((safe_rshift_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((((safe_sub_func_uint32_t_u_u(((safe_mul_func_uint8_t_u_u(g_69, l_35)) , l_41[1]), l_104)) ^ p_27) >= 0x07DECC76L) <= g_5), l_89[3])), l_35)) <= p_26), g_5)) , 0xD0F0L) , 0x0DL), l_35)), 65535UL));
    l_89[3] = l_89[3];
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_3 g_69
 * writes: g_5 g_4 g_3
 */
static uint8_t  func_38(uint64_t  p_39, int32_t  p_40)
{ /* block id: 18 */
    uint64_t l_43 = 18446744073709551615UL;
    int32_t l_44 = 0xC4E69A45L;
    int32_t l_62 = 0x14E288A3L;
    int32_t l_70 = 0x0E3F56F6L;
    int32_t l_71 = 1L;
    uint32_t l_72 = 0xF72239D1L;
    if ((!l_43))
    { /* block id: 19 */
        uint64_t l_45 = 1UL;
        int32_t l_64 = 0x8E7029BBL;
        int32_t l_67 = (-3L);
        int32_t l_68 = 0x87E8D9F6L;
        l_45--;
        g_5 &= ((safe_mod_func_uint32_t_u_u(((safe_div_func_uint8_t_u_u((l_43 >= p_40), 0xBCL)) ^ l_43), g_4[7][2][0])) < 0xEE8C4B0538FD2320LL);
        if (((safe_div_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(((l_43 == g_3[0]) >= 4294967289UL), p_39)), p_40)) , l_45))
        { /* block id: 22 */
            int64_t l_63 = 0xE206C165AAE70C30LL;
            int32_t l_65 = (-7L);
            int32_t l_66[2];
            int i;
            for (i = 0; i < 2; i++)
                l_66[i] = 0x95D6068DL;
            g_4[8][3][0] = ((safe_div_func_uint64_t_u_u((safe_div_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(l_62, 255UL)), p_40)), l_45)) , p_40);
            l_72++;
        }
        else
        { /* block id: 25 */
            l_68 = (safe_div_func_uint32_t_u_u(0UL, 0xA70DAEE1L));
        }
    }
    else
    { /* block id: 28 */
        const uint32_t l_85 = 0x7A58E81DL;
        uint64_t l_88 = 0x360B9F0A6C5FA607LL;
        l_71 &= (((safe_mul_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(l_85, l_43)), g_69)), p_40)) ^ p_40), g_5)) > g_5) < p_39);
        l_71 = p_39;
        l_88 = (safe_div_func_uint16_t_u_u(p_40, g_3[0]));
        p_40 = l_85;
    }
    g_3[0] = (g_4[4][3][0] && l_62);
    return p_40;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_153, "g_153", print_hash_value);
    transparent_crc(g_199, "g_199", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 78
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 74
   depth: 2, occurrence: 12
   depth: 3, occurrence: 7
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 4
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 102
XXX times a non-volatile is write: 39
XXX times a volatile is read: 22
XXX    times read thru a pointer: 0
XXX times a volatile is write: 9
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 92
XXX percentage of non-volatile access: 82

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 65
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 20
   depth: 2, occurrence: 24

XXX percentage a fresh-made variable is used: 26.5
XXX percentage an existing variable is used: 73.5
********************* end of statistics **********************/

