/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      949633066404029092
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_2[1] = {4UL};
static volatile uint16_t g_16[2][5] = {{1UL,1UL,1UL,1UL,1UL},{0x5E3EL,0x5E3EL,0x5E3EL,0x5E3EL,0x5E3EL}};
static int32_t g_17 = 0L;
static int32_t g_78[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
static volatile int32_t g_93 = 0x64BD89D4L;/* VOLATILE GLOBAL g_93 */
static uint16_t g_99 = 65535UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_5(int8_t  p_6, uint64_t  p_7, const uint32_t  p_8, int32_t  p_9, int16_t  p_10);
static int32_t  func_19(uint8_t  p_20, int32_t  p_21, uint16_t  p_22, int32_t  p_23, int8_t  p_24);
static uint64_t  func_31(uint16_t  p_32, const uint32_t  p_33, int64_t  p_34, int8_t  p_35, int64_t  p_36);
static uint8_t  func_38(int8_t  p_39, uint64_t  p_40);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_16 g_17 g_78 g_99 g_93
 * writes: g_17 g_99 g_78
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    volatile int16_t l_3 = 1L;/* VOLATILE GLOBAL l_3 */
    volatile int32_t l_4 = 0xC8FC558BL;/* VOLATILE GLOBAL l_4 */
    int32_t l_13 = 7L;
    int32_t l_164 = (-1L);
    l_3 = g_2[0];
    l_4 = g_2[0];
    l_164 |= func_5((safe_mod_func_uint64_t_u_u(g_2[0], 18446744073709551615UL)), l_13, l_13, l_13, l_13);
    return l_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_17 g_2 g_78 g_99 g_93
 * writes: g_17 g_99 g_78
 */
static int32_t  func_5(int8_t  p_6, uint64_t  p_7, const uint32_t  p_8, int32_t  p_9, int16_t  p_10)
{ /* block id: 3 */
    volatile int64_t l_18 = (-1L);/* VOLATILE GLOBAL l_18 */
    int32_t l_25 = 7L;
    int32_t l_143 = 0xBC9B9D56L;
    uint32_t l_163 = 18446744073709551615UL;
    g_17 ^= (safe_sub_func_uint16_t_u_u(g_16[1][1], 0x4E76L));
    l_18 = g_2[0];
    p_9 = p_9;
    if ((p_8 >= l_18))
    { /* block id: 7 */
        uint64_t l_144 = 0xBD69BE9E0A6E090ALL;
        int32_t l_154 = (-1L);
        p_9 = func_19(p_8, l_18, l_25, g_17, p_7);
        --l_144;
lbl_153:
        for (p_6 = (-7); (p_6 <= (-13)); p_6--)
        { /* block id: 75 */
            p_9 = (safe_mul_func_uint16_t_u_u(((0UL && p_8) , 0x5D11L), 0xFA52L));
            if (g_99)
                goto lbl_153;
            p_9 |= ((safe_sub_func_uint32_t_u_u(0UL, 4294967293UL)) <= g_2[0]);
        }
        l_154 = (l_143 != 1UL);
    }
    else
    { /* block id: 81 */
        p_9 = p_7;
        if (((safe_lshift_func_uint8_t_u_u(p_10, p_9)) , p_10))
        { /* block id: 83 */
            l_143 = (safe_sub_func_uint64_t_u_u(p_10, p_8));
        }
        else
        { /* block id: 85 */
            p_9 ^= (safe_mul_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((l_163 || 0x3A3D88CFL), 0x1CL)) ^ l_143), 247UL));
        }
    }
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_17 g_2 g_78 g_99 g_93
 * writes: g_17 g_99 g_78
 */
static int32_t  func_19(uint8_t  p_20, int32_t  p_21, uint16_t  p_22, int32_t  p_23, int8_t  p_24)
{ /* block id: 8 */
    int32_t l_28 = 0xEF9A8551L;
    const uint32_t l_37 = 0x074DEFC7L;
    int32_t l_117[8][10][3] = {{{0x07CF5158L,0x07CF5158L,6L},{4L,1L,(-1L)},{1L,0L,0xDE7A79C0L},{0xC138C491L,0x3EB03636L,0x58E251D0L},{9L,1L,0xDE7A79C0L},{2L,(-8L),(-1L)},{0L,0xA34357C3L,6L},{0x476EADDFL,0x759302C5L,0x0109A6A1L},{0x61D6041FL,0L,(-9L)},{0x3428438DL,0xD6C83836L,0x3EB03636L}},{{0xCCFF5D34L,6L,0L},{(-8L),0xA0CA3772L,0xC138C491L},{0x61D20EA3L,(-5L),0x3F2F4379L},{0x3E18B63CL,1L,1L},{6L,(-3L),0x3F2F4379L},{0x3428438DL,0x3428438DL,0xC138C491L},{0L,0xE6105D75L,0L},{(-6L),(-1L),0x3EB03636L},{0x1B885798L,(-5L),0xFEFFA272L},{0xB355BA67L,(-6L),0x3EB03636L}},{{6L,0xCCFF5D34L,0L},{(-8L),0xD6C83836L,0xC138C491L},{(-3L),6L,0x3F2F4379L},{(-8L),(-1L),1L},{0x8A3390C0L,0x61D20EA3L,0x3F2F4379L},{0xB355BA67L,0xCB7661C5L,0xC138C491L},{(-10L),(-3L),0L},{0xD6C83836L,6L,0x3EB03636L},{0L,6L,0xFEFFA272L},{0xCB7661C5L,0xA0CA3772L,0x3EB03636L}},{{0x8A3390C0L,0x8A3390C0L,0L},{0x3E18B63CL,(-6L),0xC138C491L},{0xE6105D75L,0x3B544FA2L,0x3F2F4379L},{(-8L),6L,1L},{0xCCFF5D34L,0xE6105D75L,0x3F2F4379L},{0xCB7661C5L,0xB355BA67L,0xC138C491L},{0x1B885798L,0x61D20EA3L,0L},{0xA0CA3772L,1L,0x3EB03636L},{(-10L),0x3B544FA2L,0xFEFFA272L},{0x3428438DL,0xD6C83836L,0x3EB03636L}},{{0xCCFF5D34L,6L,0L},{(-8L),0xA0CA3772L,0xC138C491L},{0x61D20EA3L,(-5L),0x3F2F4379L},{0x3E18B63CL,1L,1L},{6L,(-3L),0x3F2F4379L},{0x3428438DL,0x3428438DL,0xC138C491L},{0L,0xE6105D75L,0L},{(-6L),(-1L),0x3EB03636L},{0x1B885798L,(-5L),0xFEFFA272L},{0xB355BA67L,(-6L),0x3EB03636L}},{{6L,0xCCFF5D34L,0L},{(-8L),0xD6C83836L,0xC138C491L},{(-3L),6L,0x3F2F4379L},{(-8L),(-1L),1L},{0x8A3390C0L,0x61D20EA3L,0x3F2F4379L},{0xB355BA67L,0xCB7661C5L,0xC138C491L},{(-10L),(-3L),0L},{0xD6C83836L,6L,0x3EB03636L},{0L,6L,0xFEFFA272L},{0xCB7661C5L,0xA0CA3772L,0x3EB03636L}},{{0x8A3390C0L,0x8A3390C0L,0L},{0x3E18B63CL,(-6L),0xC138C491L},{0xE6105D75L,0x3B544FA2L,0x3F2F4379L},{(-8L),6L,1L},{0xCCFF5D34L,0xE6105D75L,0x3F2F4379L},{0xCB7661C5L,0xB355BA67L,0xC138C491L},{0x1B885798L,0x61D20EA3L,0L},{0xA0CA3772L,1L,0x3EB03636L},{(-10L),0x3B544FA2L,0xFEFFA272L},{0x3428438DL,0xD6C83836L,0x3EB03636L}},{{0xCCFF5D34L,6L,0L},{(-8L),0xA0CA3772L,0xC138C491L},{0x61D20EA3L,(-5L),(-5L)},{3L,(-1L),0x6C3E8AFAL},{(-9L),3L,(-5L)},{1L,1L,(-8L)},{0x0BEEA7B1L,0xDE7A79C0L,0x1B885798L},{0x0109A6A1L,0xC4F008F7L,6L},{0x7EE4AC10L,0x002CDD91L,0xD4F09919L},{(-1L),0x0109A6A1L,6L}}};
    uint32_t l_118 = 0UL;
    int i, j, k;
    l_28 = (((safe_mul_func_uint16_t_u_u(0x3DD9L, l_28)) && 1UL) < p_24);
    if (p_23)
    { /* block id: 10 */
        return g_16[0][4];
    }
    else
    { /* block id: 12 */
        uint64_t l_109 = 0x4EA8159E33F92C7FLL;
        int32_t l_114 = (-1L);
        int32_t l_115[1][9][5];
        int32_t l_116[2][1];
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 9; j++)
            {
                for (k = 0; k < 5; k++)
                    l_115[i][j][k] = 4L;
            }
        }
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 1; j++)
                l_116[i][j] = 0xA50C6050L;
        }
        l_109 = (safe_mod_func_uint64_t_u_u(func_31(g_16[0][2], l_37, p_21, g_17, g_17), l_28));
        g_78[4] = ((safe_add_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u(g_2[0], g_17)), p_23)) != p_22);
        --l_118;
        l_115[0][4][4] &= ((7UL != p_23) && p_20);
    }
    l_28 = ((((safe_add_func_uint8_t_u_u(9UL, l_28)) < 0x7A201F268CC48AF1LL) == 4294967287UL) != g_16[1][1]);
    if ((((((((safe_div_func_uint32_t_u_u((+(safe_div_func_uint64_t_u_u((((safe_add_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((p_21 && 3UL), p_23)), g_2[0])), 65529UL)) <= p_20) ^ p_20), g_17))), 4294967295UL)) , 0x63DAB8F45AC62A2ELL) , l_117[1][0][1]) , 18446744073709551615UL) > g_17) , g_93) > 6UL))
    { /* block id: 54 */
        g_78[3] = 1L;
    }
    else
    { /* block id: 56 */
        uint16_t l_136[8];
        int i;
        for (i = 0; i < 8; i++)
            l_136[i] = 0xE825L;
        for (p_24 = 6; (p_24 > 17); p_24 = safe_add_func_uint32_t_u_u(p_24, 5))
        { /* block id: 59 */
            return l_136[3];
        }
        if (((0x76L ^ g_2[0]) >= g_78[4]))
        { /* block id: 62 */
            l_117[1][8][2] = (safe_mod_func_uint16_t_u_u(p_22, l_37));
            g_78[4] = p_20;
            return p_21;
        }
        else
        { /* block id: 66 */
            uint32_t l_142 = 0x7E789F1AL;
            l_142 ^= (safe_mod_func_uint8_t_u_u((+(((p_21 ^ 0x42F87E49L) , p_24) != 0x94L)), p_23));
        }
    }
    return g_2[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_16 g_17 g_78 g_99
 * writes: g_17 g_99
 */
static uint64_t  func_31(uint16_t  p_32, const uint32_t  p_33, int64_t  p_34, int8_t  p_35, int64_t  p_36)
{ /* block id: 13 */
    uint64_t l_47 = 0x3B19D88C83B91359LL;
    g_99 &= (func_38(((safe_lshift_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u(p_36, 13)), g_2[0])) || 0xEA82L), 12)) && l_47), l_47) > g_78[1]);
    for (p_34 = 0; (p_34 >= (-17)); p_34 = safe_sub_func_uint8_t_u_u(p_34, 6))
    { /* block id: 39 */
        for (g_99 = 0; (g_99 <= 37); g_99++)
        { /* block id: 42 */
            uint16_t l_104 = 0xEF3AL;
            --l_104;
        }
        g_17 = (safe_rshift_func_uint16_t_u_u(0xAAE3L, p_33));
    }
    return g_99;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_2 g_17 g_78
 * writes: g_17
 */
static uint8_t  func_38(int8_t  p_39, uint64_t  p_40)
{ /* block id: 14 */
    int32_t l_52 = 0x7E05AF84L;
    uint8_t l_53 = 0xCDL;
    int32_t l_54 = 1L;
    int32_t l_79 = 0x59021B0AL;
    int32_t l_80 = (-1L);
    int32_t l_81 = 0x5683D526L;
    int32_t l_82 = 9L;
    int32_t l_83 = 0xC4E1B820L;
    int32_t l_84[6][8][5] = {{{(-1L),6L,0xCACAAAB2L,0L,0x5427816DL},{(-1L),0x0CEF6D7BL,0xC855A404L,(-1L),1L},{(-1L),(-6L),0x1704BE3CL,7L,0x60CE0BB6L},{0L,0xCD07D1F8L,0x9C4BD7DAL,0xC2D9EA4CL,1L},{1L,(-1L),0x06BCA32DL,0xA62FBF91L,0x5427816DL},{0x0CEF6D7BL,7L,0x7F8E4820L,0xC2D9EA4CL,0x7F8E4820L},{1L,1L,0xCACAAAB2L,7L,8L},{(-1L),0L,0x7F8E4820L,(-1L),(-8L)}},{{6L,(-6L),0x06BCA32DL,0L,0x60CE0BB6L},{0xCD07D1F8L,0L,0x9C4BD7DAL,(-7L),1L},{1L,1L,0x1704BE3CL,0xA62FBF91L,0L},{0xCD07D1F8L,7L,0xC855A404L,7L,0x7F8E4820L},{6L,(-1L),0xCACAAAB2L,(-4L),0L},{(-1L),0xCD07D1F8L,3L,(-1L),1L},{1L,(-6L),0x60CE0BB6L,(-4L),0x60CE0BB6L},{0x0CEF6D7BL,0x0CEF6D7BL,0x9C4BD7DAL,7L,(-8L)}},{{1L,6L,0x60CE0BB6L,0xA62FBF91L,8L},{0L,7L,3L,(-7L),0x7F8E4820L},{(-1L),6L,0xCACAAAB2L,0L,0x5427816DL},{(-1L),0x0CEF6D7BL,0xC855A404L,(-1L),1L},{(-1L),(-6L),0x1704BE3CL,7L,0x60CE0BB6L},{0L,0xCD07D1F8L,0x9C4BD7DAL,0xC2D9EA4CL,1L},{1L,(-1L),0x06BCA32DL,0xA62FBF91L,0x5427816DL},{0x0CEF6D7BL,7L,0x7F8E4820L,0xC2D9EA4CL,0x7F8E4820L}},{{1L,1L,0xCACAAAB2L,7L,8L},{(-1L),0L,0x7F8E4820L,(-1L),(-8L)},{6L,(-6L),0x06BCA32DL,0L,0x60CE0BB6L},{0xCD07D1F8L,0L,0x9C4BD7DAL,(-7L),1L},{1L,1L,0x1704BE3CL,0xA62FBF91L,0L},{0xCD07D1F8L,7L,0xC855A404L,7L,0x7F8E4820L},{6L,(-1L),0xCACAAAB2L,(-4L),0L},{(-1L),0xCD07D1F8L,3L,(-1L),1L}},{{1L,(-6L),0x60CE0BB6L,(-4L),0x60CE0BB6L},{0x0CEF6D7BL,0x0CEF6D7BL,0x9C4BD7DAL,1L,0xD1830F2BL},{5L,0x60CE0BB6L,0xF34F21D6L,4L,3L},{0x7F8E4820L,0x9C4BD7DAL,0L,0xB30C50D1L,1L},{0x1704BE3CL,0x60CE0BB6L,(-1L),(-1L),0xA1D01971L},{(-6L),3L,3L,(-1L),1L},{0x1704BE3CL,0xCACAAAB2L,0x1BE15C8DL,1L,0xF34F21D6L},{0x7F8E4820L,0xC855A404L,0L,0x8A300FF6L,1L}},{{5L,0x1704BE3CL,0L,4L,0xA1D01971L},{3L,0x9C4BD7DAL,1L,0x8A300FF6L,1L},{0x06BCA32DL,0x06BCA32DL,(-1L),1L,3L},{(-6L),0x7F8E4820L,1L,(-1L),0xD1830F2BL},{0x60CE0BB6L,0xCACAAAB2L,0L,(-1L),0xF34F21D6L},{0xC855A404L,0x7F8E4820L,0L,0xB30C50D1L,(-1L)},{5L,0x06BCA32DL,0x1BE15C8DL,4L,0L},{0xC855A404L,0x9C4BD7DAL,3L,1L,1L}}};
    uint32_t l_90 = 0x643A2F0FL;
    int32_t l_94 = 0x6B8F8F02L;
    int16_t l_95 = (-6L);
    uint16_t l_96 = 0xEDA7L;
    int i, j, k;
    if ((((safe_div_func_uint32_t_u_u((((safe_mod_func_uint64_t_u_u(((g_16[1][0] != p_40) , l_52), 4UL)) > l_53) , g_16[0][2]), p_39)) == l_52) || 1UL))
    { /* block id: 15 */
lbl_57:
        l_54 &= 1L;
    }
    else
    { /* block id: 17 */
        int32_t l_75 = (-1L);
        int32_t l_76 = 0L;
        int32_t l_77[5][2][10] = {{{0x37531468L,0x37531468L,(-3L),0xC6596AADL,0x0F9AB13FL,0xC6596AADL,(-3L),0x37531468L,0x37531468L,(-3L)},{0xA4961F08L,0xC6596AADL,(-4L),(-4L),0xC6596AADL,0xA4961F08L,(-3L),0xA4961F08L,0xC6596AADL,(-4L)}},{{0x62BE9700L,0x37531468L,0x62BE9700L,(-4L),(-3L),(-3L),(-4L),0x62BE9700L,0x37531468L,0x62BE9700L},{0x62BE9700L,0xA4961F08L,0x37531468L,0xC6596AADL,0x37531468L,0xA4961F08L,0x62BE9700L,0x62BE9700L,0xA4961F08L,0x37531468L}},{{0xA4961F08L,0x62BE9700L,0x62BE9700L,0xA4961F08L,0x37531468L,0xC6596AADL,0x37531468L,0xA4961F08L,0x62BE9700L,0x62BE9700L},{0x37531468L,0x62BE9700L,(-4L),(-3L),(-3L),(-4L),0x62BE9700L,0x37531468L,0x62BE9700L,(-4L)}},{{0xC6596AADL,0xA4961F08L,(-3L),0xA4961F08L,0xC6596AADL,(-4L),(-4L),0xC6596AADL,0xA4961F08L,(-3L)},{0x37531468L,0x37531468L,(-3L),0xC6596AADL,0x0F9AB13FL,0xC6596AADL,(-3L),0x37531468L,0x37531468L,(-3L)}},{{0xA4961F08L,0xC6596AADL,(-4L),(-4L),0xC6596AADL,0xA4961F08L,(-3L),0xA4961F08L,0xC6596AADL,(-4L)},{0x62BE9700L,0x37531468L,0x62BE9700L,(-4L),(-3L),(-3L),(-4L),0x62BE9700L,0x37531468L,0x62BE9700L}}};
        int64_t l_85[3];
        int8_t l_86 = 1L;
        uint32_t l_87 = 0UL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_85[i] = 0xBA7F7E758ACF152CLL;
        for (p_40 = 0; (p_40 < 41); p_40++)
        { /* block id: 20 */
            uint64_t l_66 = 0x7E7924A04C7C9A7BLL;
            if (p_40)
                goto lbl_57;
            g_17 = (safe_sub_func_uint16_t_u_u(((((safe_sub_func_uint64_t_u_u(((safe_add_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u(p_39, l_66)), 0x50A0C201L)) , 18446744073709551615UL), 0xA1AEA07874D2D97BLL)) || g_2[0]) != g_17) == 0x32L), g_17));
        }
        for (p_39 = (-6); (p_39 < 14); ++p_39)
        { /* block id: 26 */
            return p_40;
        }
        l_75 &= ((safe_mod_func_uint16_t_u_u(((!(safe_sub_func_uint64_t_u_u((!0xE8E2L), g_16[1][1]))) , 65535UL), 0xE444L)) && l_53);
        ++l_87;
    }
    l_90--;
    g_17 |= (((l_84[4][7][1] >= l_81) != g_78[4]) > 0UL);
    --l_96;
    return l_54;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_16[i][j], "g_16[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_78[i], "g_78[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_99, "g_99", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 48
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 60
   depth: 2, occurrence: 12
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 9, occurrence: 3
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 78
XXX times a non-volatile is write: 37
XXX times a volatile is read: 22
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 100
XXX percentage of non-volatile access: 82.1

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 57
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 22
   depth: 1, occurrence: 21
   depth: 2, occurrence: 14

XXX percentage a fresh-made variable is used: 15.4
XXX percentage an existing variable is used: 84.6
********************* end of statistics **********************/

