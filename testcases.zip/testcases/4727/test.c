/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      995385053528799314
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_5 = 0xA87013DCE9D05BA7LL;
static uint16_t g_26[2] = {0x95CDL,0x95CDL};
static uint8_t g_34 = 1UL;
static uint32_t g_37 = 3UL;
static volatile int16_t g_38[6] = {3L,1L,1L,3L,1L,1L};
static int32_t g_39[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static volatile uint32_t g_40 = 0x8EA47160L;/* VOLATILE GLOBAL g_40 */
static int8_t g_55 = 6L;
static uint32_t g_57 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int8_t  func_7(uint8_t  p_8, uint32_t  p_9);
static int32_t  func_14(uint8_t  p_15, uint16_t  p_16, int8_t  p_17, uint64_t  p_18, int64_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_26 g_34 g_40 g_38 g_39 g_37
 * writes: g_5 g_26 g_34 g_37 g_40 g_55 g_57
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_36[4] = {0xD8607F47L,0xD8607F47L,0xD8607F47L,0xD8607F47L};
    int16_t l_56 = (-7L);
    int i;
    if ((+(safe_sub_func_uint32_t_u_u(g_5, 0UL))))
    { /* block id: 1 */
        int8_t l_6[10] = {0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL};
        int i;
        for (g_5 = 0; (g_5 <= 9); g_5 += 1)
        { /* block id: 4 */
            int i;
            l_36[3] = (func_7(((((safe_sub_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(l_6[g_5], g_5)), g_5)) >= g_5) != g_5) != g_5), g_5) & l_6[1]);
            g_37 = (l_6[g_5] == l_6[g_5]);
            ++g_40;
        }
    }
    else
    { /* block id: 21 */
        int8_t l_47 = 0xDDL;
        if ((safe_mul_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((((((-9L) || g_38[0]) >= g_39[5]) >= l_47) , 3UL), l_36[2])), l_36[3])))
        { /* block id: 22 */
            uint32_t l_48 = 0x268D9A65L;
            return l_48;
        }
        else
        { /* block id: 24 */
            g_55 = (((safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint16_t_u_u((g_38[2] <= 0x221EB1ED309061E9LL), 2)), 4)), 0L)) < g_37) == 0x5BL);
        }
    }
    g_57 = (((0x32BCL != g_26[0]) & l_56) | (-1L));
    return g_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_26 g_34
 * writes: g_26 g_34
 */
static int8_t  func_7(uint8_t  p_8, uint32_t  p_9)
{ /* block id: 5 */
    uint8_t l_25 = 0xB2L;
    int32_t l_30 = (-2L);
    uint32_t l_35 = 4294967288UL;
    l_30 = func_14(((!((safe_rshift_func_int16_t_s_u((((safe_rshift_func_uint8_t_u_u(((l_25 <= p_8) <= p_9), 2)) & g_5) == 0xB5L), l_25)) || p_9)) , 0x9DL), g_5, g_5, l_25, p_8);
    for (p_8 = 0; (p_8 < 49); p_8++)
    { /* block id: 12 */
        int16_t l_33 = (-7L);
        g_34 = (g_26[1] , l_33);
        l_35 = g_34;
    }
    return l_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_26
 * writes: g_26
 */
static int32_t  func_14(uint8_t  p_15, uint16_t  p_16, int8_t  p_17, uint64_t  p_18, int64_t  p_19)
{ /* block id: 6 */
    int32_t l_29 = 9L;
    g_26[0]--;
    return l_29;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_26[i], "g_26[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_38[i], "g_38[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 5
   depth: 4, occurrence: 1
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 10
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 8
XXX percentage of non-volatile access: 92

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 4
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 38.3
XXX percentage an existing variable is used: 61.7
********************* end of statistics **********************/

