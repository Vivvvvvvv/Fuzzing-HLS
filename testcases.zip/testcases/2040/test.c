/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2313419527893390115
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile int64_t g_2[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
static int16_t g_12 = 0x1A62L;
static uint8_t g_22[6] = {254UL,254UL,254UL,254UL,254UL,254UL};
static int8_t g_28 = 0xB9L;
static uint8_t g_29[3] = {0x9CL,0x9CL,0x9CL};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int8_t  func_13(int32_t  p_14, int64_t  p_15, int16_t  p_16, uint32_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_12 g_22 g_29 g_28
 * writes: g_12 g_28 g_29
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_6 = 0x23E64F147909B792LL;
    if (g_2[2])
    { /* block id: 1 */
        uint64_t l_5 = 3UL;
        int32_t l_7[8] = {0x989D221EL,0xD63A88E0L,0x989D221EL,0x989D221EL,0xD63A88E0L,0x989D221EL,0x989D221EL,0xD63A88E0L};
        int i;
        l_7[1] = (safe_mod_func_int32_t_s_s((((l_5 < g_2[2]) , l_6) || 0x1CEDL), l_5));
        for (l_5 = 0; (l_5 >= 8); l_5 = safe_add_func_int16_t_s_s(l_5, 7))
        { /* block id: 5 */
            g_12 = (safe_rshift_func_uint8_t_u_s(g_2[7], 7));
            return g_2[4];
        }
    }
    else
    { /* block id: 9 */
        uint16_t l_23 = 0x51BBL;
        int32_t l_32 = 0x4FB7D476L;
        l_32 = (func_13(((((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((g_2[2] != g_12), 255UL)), g_22[1])) , 0x208AL) , l_23) , g_22[1]), g_22[1], g_22[5], g_22[1]) & l_23);
    }
    return g_22[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_22 g_29 g_28
 * writes: g_28 g_29
 */
static int8_t  func_13(int32_t  p_14, int64_t  p_15, int16_t  p_16, uint32_t  p_17)
{ /* block id: 10 */
    uint32_t l_27 = 0xE5950169L;
    g_28 = (safe_mul_func_uint8_t_u_u(((safe_unary_minus_func_uint16_t_u(((0xEDL ^ g_2[2]) >= 0xD4B0L))) != g_22[1]), l_27));
    --g_29[1];
    return g_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_29[i], "g_29[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 2
   depth: 5, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 16
XXX times a non-volatile is write: 6
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 8
XXX percentage of non-volatile access: 78.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 3
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 42.3
XXX percentage an existing variable is used: 57.7
********************* end of statistics **********************/

