/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2721455399430414551
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 6L;
static volatile int64_t g_59 = (-1L);/* VOLATILE GLOBAL g_59 */
static int32_t g_62 = 0x6B6C30C2L;
static volatile int16_t g_63 = 0x8DC0L;/* VOLATILE GLOBAL g_63 */
static uint32_t g_68 = 0xDC0DC4BEL;
static volatile uint32_t g_71 = 0x8DAF57E0L;/* VOLATILE GLOBAL g_71 */
static int32_t g_82 = 0x0674BD75L;
static volatile int8_t g_117 = 0x3FL;/* VOLATILE GLOBAL g_117 */
static volatile uint16_t g_120 = 5UL;/* VOLATILE GLOBAL g_120 */
static volatile uint8_t g_134 = 255UL;/* VOLATILE GLOBAL g_134 */
static int32_t g_162 = 0xAE1DC5D4L;
static int64_t g_163 = (-1L);
static volatile uint32_t g_164 = 0x04719F17L;/* VOLATILE GLOBAL g_164 */
static volatile int32_t g_168 = 0xAB1E9DD0L;/* VOLATILE GLOBAL g_168 */
static uint16_t g_170 = 0xF96AL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int16_t  func_8(uint32_t  p_9, int16_t  p_10, int32_t  p_11, uint64_t  p_12);
static uint32_t  func_13(uint64_t  p_14, int8_t  p_15, int64_t  p_16, int8_t  p_17);
static int64_t  func_22(uint8_t  p_23, uint8_t  p_24);
static int8_t  func_27(uint32_t  p_28, uint64_t  p_29);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_68 g_71 g_59 g_82 g_120 g_63 g_117 g_62 g_134 g_164 g_170 g_162 g_163 g_168
 * writes: g_3 g_68 g_71 g_82 g_120 g_134 g_62 g_164 g_170 g_162 g_163
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[4] = {0xF9B3198AL,0xF9B3198AL,0xF9B3198AL,0xF9B3198AL};
    int32_t l_250[2][7] = {{5L,5L,0x249E6F10L,5L,5L,0x249E6F10L,5L},{5L,(-3L),(-3L),5L,(-3L),(-3L),5L}};
    int i, j;
    for (g_3 = 0; g_3 < 4; g_3 += 1)
    {
        l_2[g_3] = 0x6F1BF506L;
    }
    for (g_3 = 0; (g_3 == 2); ++g_3)
    { /* block id: 4 */
        int64_t l_249 = 1L;
        l_250[1][4] = ((safe_mul_func_uint16_t_u_u(((func_8(func_13((((l_2[2] , (-1L)) > g_3) , g_3), g_3, g_3, g_3), l_2[3], g_3, l_2[1]) | l_249) > l_2[1]), g_3)) , l_2[2]);
        return g_59;
    }
    for (g_3 = 0; (g_3 != 0); ++g_3)
    { /* block id: 163 */
        int8_t l_264 = 2L;
        if (g_62)
            break;
        for (g_163 = (-23); (g_163 > (-27)); g_163--)
        { /* block id: 167 */
            uint32_t l_255[3][10][4] = {{{0xB8C51BF3L,6UL,0xF4FCCFE6L,0xB8C51BF3L},{0xD22ADB03L,0UL,5UL,0xD450CAA9L},{0x67CC5C42L,0UL,0UL,0x8833187DL},{0x437AF737L,0xB4788FA9L,18446744073709551612UL,0x7CD7A234L},{0x297D261BL,0xD450CAA9L,0x94971777L,0xD450CAA9L},{0x92476270L,0x050AC26CL,0UL,0xA73BDA03L},{0UL,6UL,0UL,0x5CF0B89FL},{0UL,1UL,0x297D261BL,0x437AF737L},{0UL,0x1FE9FD4BL,5UL,0x2D84668BL},{0x94971777L,0x437AF737L,18446744073709551615UL,1UL}},{{0x22663ACAL,0x7CD7A234L,0UL,0xB8C51BF3L},{0x2D84668BL,0xE2F61E5CL,18446744073709551606UL,0x050AC26CL},{18446744073709551615UL,5UL,0x94971777L,0xF516C413L},{5UL,0x7CD7A234L,18446744073709551615UL,0x496A5FA5L},{0xF4FCCFE6L,0x94971777L,0x6637A45AL,0x2D84668BL},{18446744073709551613UL,0xF4FCCFE6L,1UL,0x94971777L},{0xB8C51BF3L,1UL,0xD22ADB03L,0UL},{0x96496B39L,0x6637A45AL,0x6637A45AL,0x96496B39L},{0x1FE9FD4BL,0xB8C51BF3L,0xE2F61E5CL,8UL},{5UL,0UL,0xF32714C3L,1UL}},{{0x050AC26CL,18446744073709551609UL,18446744073709551606UL,1UL},{5UL,0UL,18446744073709551615UL,8UL},{0x22663ACAL,0xB8C51BF3L,0x8833187DL,0x96496B39L},{0x437AF737L,0x6637A45AL,5UL,0UL},{18446744073709551609UL,1UL,0x3590E6B1L,0x94971777L},{0UL,0xF4FCCFE6L,0x67CC5C42L,0x2D84668BL},{0x437AF737L,0x94971777L,18446744073709551615UL,0x496A5FA5L},{18446744073709551607UL,0x7CD7A234L,18446744073709551615UL,0xF516C413L},{0x2D84668BL,5UL,18446744073709551615UL,0x050AC26CL},{0x050AC26CL,0xE2F61E5CL,0x94971777L,0xB8C51BF3L}}};
            int32_t l_266 = 0x31731C5FL;
            int i, j, k;
            l_255[0][2][1]--;
            l_250[1][4] = (safe_mul_func_int16_t_s_s((safe_mod_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((0x2EL != g_120), l_264)), g_3)), g_3));
            l_266 = (!g_168);
        }
    }
    return g_164;
}


/* ------------------------------------------ */
/* 
 * reads : g_120 g_170 g_3 g_134 g_62 g_117 g_59 g_68 g_63
 * writes: g_162 g_82
 */
static int16_t  func_8(uint32_t  p_9, int16_t  p_10, int32_t  p_11, uint64_t  p_12)
{ /* block id: 122 */
    uint64_t l_199[7] = {3UL,0xC4DA857B670F1B27LL,3UL,3UL,0xC4DA857B670F1B27LL,3UL,3UL};
    int32_t l_225 = (-7L);
    int16_t l_226 = 0x760CL;
    int32_t l_239 = (-1L);
    int i;
lbl_243:
    if ((((l_199[3] != l_199[1]) , g_120) , g_170))
    { /* block id: 123 */
        uint32_t l_205 = 0x4E8207C4L;
        int32_t l_214 = 0x3D2FB577L;
        uint64_t l_233[6];
        int i;
        for (i = 0; i < 6; i++)
            l_233[i] = 6UL;
        if ((safe_mod_func_int64_t_s_s((!(safe_sub_func_uint16_t_u_u((((((l_199[2] > 0xCAAA0D67L) && 0x95721FC9L) != p_11) > p_9) == 4294967295UL), l_205))), p_12)))
        { /* block id: 124 */
            l_214 = (safe_lshift_func_uint16_t_u_s(((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s((((((safe_add_func_int64_t_s_s(0x24732960E54F6E66LL, g_170)) != 1UL) | 18446744073709551611UL) , 0L) >= 0x71D7L), 2)) <= 3L), g_3)) == g_3), g_134));
            l_214 = 0x09421487L;
            g_162 = (safe_rshift_func_int16_t_s_u(g_62, 11));
        }
        else
        { /* block id: 128 */
            int8_t l_224[4][3] = {{0L,0xEAL,0L},{5L,5L,5L},{0L,0xEAL,0L},{5L,5L,5L}};
            int32_t l_227 = 0L;
            int i, j;
            l_214 = ((safe_lshift_func_uint16_t_u_s((p_11 & 0x4C1E5BB9C9052CF8LL), g_117)) != p_10);
            l_214 = 0x376F68FCL;
            g_82 = (((+0UL) != 0x45D2L) > p_9);
            l_227 = ((((safe_rshift_func_int8_t_s_u((safe_sub_func_int8_t_s_s(p_12, l_224[1][2])), g_59)) | l_225) , l_226) , (-3L));
        }
        g_82 = g_117;
        if ((safe_rshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_s((p_10 & p_10), p_10)), 3)))
        { /* block id: 135 */
            int8_t l_232 = 0x27L;
            return l_232;
        }
        else
        { /* block id: 137 */
            int32_t l_236 = 0xBA1BEA94L;
            l_233[3]++;
            l_225 |= ((((g_117 | 0xD6ADL) ^ l_236) ^ 0xD8L) != l_233[4]);
        }
    }
    else
    { /* block id: 141 */
        uint32_t l_240 = 0x75011F42L;
        g_162 = (safe_mul_func_uint8_t_u_u(p_10, g_68));
        l_240--;
    }
    for (p_11 = 6; (p_11 >= 2); p_11 -= 1)
    { /* block id: 147 */
        int32_t l_248 = 0x654C1739L;
        for (p_9 = 0; (p_9 <= 6); p_9 += 1)
        { /* block id: 150 */
            uint32_t l_244[1];
            int32_t l_245[3];
            int i;
            for (i = 0; i < 1; i++)
                l_244[i] = 18446744073709551607UL;
            for (i = 0; i < 3; i++)
                l_245[i] = 4L;
            if (l_225)
                goto lbl_243;
            l_244[0] = (-2L);
            l_245[0] = l_199[p_9];
            l_239 &= (((safe_div_func_int16_t_s_s((l_199[p_11] | (-3L)), 65528UL)) || 0xDFL) , l_248);
        }
    }
    return g_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_68 g_71 g_59 g_82 g_120 g_63 g_117 g_62 g_134 g_164 g_170 g_162 g_163
 * writes: g_68 g_71 g_82 g_120 g_134 g_62 g_164 g_170 g_162
 */
static uint32_t  func_13(uint64_t  p_14, int8_t  p_15, int64_t  p_16, int8_t  p_17)
{ /* block id: 5 */
    uint32_t l_180[4];
    int32_t l_181 = 1L;
    int i;
    for (i = 0; i < 4; i++)
        l_180[i] = 0x9767DC16L;
    l_181 &= ((safe_rshift_func_int8_t_s_s((safe_add_func_uint8_t_u_u((func_22((safe_sub_func_int8_t_s_s(func_27(g_3, p_17), g_3)), g_3) , l_180[3]), 0x12L)), g_163)) , 0xADD202CBL);
    g_162 = (safe_div_func_uint32_t_u_u((((-9L) != g_63) > l_181), 4294967289UL));
    if ((((-1L) == g_59) == 1UL))
    { /* block id: 105 */
        int64_t l_184 = (-6L);
        int32_t l_185 = 0x6B8FCFDFL;
        l_185 = ((((p_15 , 0x35DA1870280360E7LL) == g_3) , l_180[3]) , l_184);
        l_185 = (!((safe_rshift_func_uint8_t_u_s(l_180[2], l_185)) == g_164));
        for (p_14 = 9; (p_14 != 22); p_14++)
        { /* block id: 110 */
            return g_170;
        }
    }
    else
    { /* block id: 113 */
        int8_t l_193 = 0L;
        if ((safe_rshift_func_uint8_t_u_u((l_193 > p_15), 3)))
        { /* block id: 114 */
            uint32_t l_194 = 0xBE6229C2L;
            ++l_194;
        }
        else
        { /* block id: 116 */
            g_162 = (((!(((((!((((p_14 == p_17) && g_163) , p_15) , g_59)) != 255UL) == p_17) || p_15) != l_193)) || l_180[3]) && 0xAF36540EL);
        }
    }
    l_181 = (-6L);
    return l_180[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_71 g_62 g_63 g_120 g_134 g_82 g_68 g_117 g_164 g_170 g_162 g_163
 * writes: g_82 g_134 g_62 g_164 g_170 g_162
 */
static int64_t  func_22(uint8_t  p_23, uint8_t  p_24)
{ /* block id: 70 */
    uint64_t l_133[7][1][5] = {{{0x438CBB9BCF21FBBDLL,18446744073709551611UL,0x438CBB9BCF21FBBDLL,0x4B165B360EF7B9C6LL,0x438CBB9BCF21FBBDLL}},{{0x6291BC3C69C585CDLL,18446744073709551611UL,0xF185F0ADDF9D14FDLL,0xF185F0ADDF9D14FDLL,18446744073709551611UL}},{{0x3213DDA549CE4963LL,0x4B165B360EF7B9C6LL,6UL,0x4B165B360EF7B9C6LL,0x3213DDA549CE4963LL}},{{18446744073709551611UL,0xF185F0ADDF9D14FDLL,0xF185F0ADDF9D14FDLL,18446744073709551611UL,0x6291BC3C69C585CDLL}},{{0x438CBB9BCF21FBBDLL,0x4B165B360EF7B9C6LL,0x438CBB9BCF21FBBDLL,18446744073709551611UL,0x438CBB9BCF21FBBDLL}},{{18446744073709551611UL,18446744073709551611UL,0x980C733F41E0092ALL,0xF185F0ADDF9D14FDLL,0x6291BC3C69C585CDLL}},{{0x3213DDA549CE4963LL,18446744073709551611UL,6UL,18446744073709551611UL,0x3213DDA549CE4963LL}}};
    int32_t l_156 = (-3L);
    int32_t l_169 = 2L;
    int i, j, k;
    g_82 = ((((safe_lshift_func_int8_t_s_u(g_71, g_62)) , g_63) , g_120) == 0x3BB8E87DE450C1D2LL);
    for (p_24 = 0; (p_24 <= 0); p_24 += 1)
    { /* block id: 74 */
        g_134--;
        for (g_82 = 0; (g_82 >= 0); g_82 -= 1)
        { /* block id: 78 */
            return p_23;
        }
    }
    for (g_62 = (-30); (g_62 > 9); g_62 = safe_add_func_int8_t_s_s(g_62, 6))
    { /* block id: 84 */
        uint8_t l_154[3];
        int32_t l_157[5];
        int8_t l_167[2];
        int i;
        for (i = 0; i < 3; i++)
            l_154[i] = 249UL;
        for (i = 0; i < 5; i++)
            l_157[i] = 0x096FE6C6L;
        for (i = 0; i < 2; i++)
            l_167[i] = 0L;
        if ((((safe_lshift_func_uint8_t_u_u(((((safe_lshift_func_uint16_t_u_s(((((safe_add_func_int64_t_s_s(((safe_mod_func_int8_t_s_s((!((((((safe_add_func_uint32_t_u_u((safe_add_func_uint16_t_u_u((safe_mod_func_int8_t_s_s((p_23 || 255UL), g_68)), g_68)), g_117)) >= 0x081A23FA78A7768BLL) & l_133[6][0][2]) & 65533UL) & l_133[5][0][0]) & g_82)), 0x5AL)) , l_154[2]), l_154[2])) & p_24) , l_154[1]) , g_117), 7)) <= 0x51L) <= p_24) , l_154[2]), 7)) >= l_154[2]) , p_24))
        { /* block id: 85 */
            int32_t l_155 = (-8L);
            l_155 &= (p_23 , 0x8005EDC9L);
            return g_68;
        }
        else
        { /* block id: 88 */
            uint64_t l_158 = 0x39F4849B7B0AB9F4LL;
            int32_t l_161[5][7] = {{0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL},{0x23AF5180L,0xDDDCD2A6L,0x23AF5180L,0xDDDCD2A6L,0x23AF5180L,0xDDDCD2A6L,0x23AF5180L},{0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL},{0x23AF5180L,0xDDDCD2A6L,0x23AF5180L,0xDDDCD2A6L,0x23AF5180L,0xDDDCD2A6L,0x23AF5180L},{0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL,0x3A49E77FL}};
            int i, j;
            l_158--;
            --g_164;
        }
        if (l_154[2])
        { /* block id: 92 */
            g_82 = 1L;
            g_170--;
            l_156 = ((-4L) || p_23);
        }
        else
        { /* block id: 96 */
            l_169 |= ((safe_sub_func_uint16_t_u_u((!(((g_162 && g_120) , 18446744073709551613UL) > p_24)), p_24)) || 9UL);
            g_162 &= p_24;
            l_157[4] = ((safe_div_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((g_163 > g_170) & g_170), l_169)), 1L)) , g_162);
        }
    }
    return p_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_68 g_71 g_59 g_82 g_120 g_63 g_117
 * writes: g_68 g_71 g_82 g_120
 */
static int8_t  func_27(uint32_t  p_28, uint64_t  p_29)
{ /* block id: 6 */
    uint16_t l_53 = 65532UL;
    int32_t l_58 = 0x58094BF1L;
    int32_t l_64 = 0xD2EAD1D3L;
    int32_t l_65 = 0x92153B37L;
    int32_t l_118[1];
    int i;
    for (i = 0; i < 1; i++)
        l_118[i] = 0x4AFCFED7L;
    if ((((p_29 <= p_28) , g_3) & 0x4AL))
    { /* block id: 7 */
        uint64_t l_40[4][10][4] = {{{0x43DA4AA2EEDF2191LL,18446744073709551608UL,0x1EFB40ACB4886636LL,0x4473CA56B74084DALL},{0x8949F0E3FDF4734ALL,0x203F87D51EEA2DBBLL,1UL,8UL},{0x9CCD29D3EAFCA19ALL,0x43DA4AA2EEDF2191LL,0x43DA4AA2EEDF2191LL,0x47D9BA7415234D5ELL},{1UL,18446744073709551615UL,1UL,18446744073709551612UL},{0UL,0x47D9BA7415234D5ELL,18446744073709551615UL,0x233DF555A6F0ED5CLL},{8UL,0xC8FE30C1ABDDA6A1LL,18446744073709551615UL,1UL},{1UL,0x02D6FA87DC7FB053LL,0x30F0C86797B69E0DLL,18446744073709551608UL},{0x02D6FA87DC7FB053LL,0x47D9BA7415234D5ELL,0UL,0xE6E92ECD44262C44LL},{18446744073709551612UL,1UL,1UL,0x47D9BA7415234D5ELL},{0x1EFB40ACB4886636LL,0xAB65697B4E6B2E54LL,0xAB65697B4E6B2E54LL,0x1EFB40ACB4886636LL}},{{0xE6E92ECD44262C44LL,18446744073709551608UL,0UL,0x30F0C86797B69E0DLL},{0xC8FE30C1ABDDA6A1LL,0x1CD4EE3B919D6B80LL,8UL,0UL},{1UL,1UL,0x84BB8686B464BBCDLL,0UL},{0xAB65697B4E6B2E54LL,0x1CD4EE3B919D6B80LL,18446744073709551615UL,0x30F0C86797B69E0DLL},{0x83B01F688490A13ELL,18446744073709551608UL,1UL,0x1EFB40ACB4886636LL},{1UL,0xAB65697B4E6B2E54LL,0xBE618B2576953C53LL,0x47D9BA7415234D5ELL},{18446744073709551615UL,1UL,1UL,0xE6E92ECD44262C44LL},{0x83B01F688490A13ELL,0x47D9BA7415234D5ELL,0xB3257B06F8616691LL,18446744073709551608UL},{8UL,0x02D6FA87DC7FB053LL,0x84BB8686B464BBCDLL,1UL},{0x30F0C86797B69E0DLL,0xC8FE30C1ABDDA6A1LL,0x30F0C86797B69E0DLL,0x233DF555A6F0ED5CLL}},{{0xC8FE30C1ABDDA6A1LL,0x47D9BA7415234D5ELL,0UL,18446744073709551612UL},{18446744073709551612UL,18446744073709551615UL,0xAB65697B4E6B2E54LL,0x47D9BA7415234D5ELL},{9UL,8UL,0xAB65697B4E6B2E54LL,9UL},{18446744073709551612UL,18446744073709551608UL,0UL,1UL},{0xC8FE30C1ABDDA6A1LL,18446744073709551615UL,0x30F0C86797B69E0DLL,0UL},{0x30F0C86797B69E0DLL,0UL,0x84BB8686B464BBCDLL,1UL},{8UL,0x1CD4EE3B919D6B80LL,0xB3257B06F8616691LL,1UL},{0x83B01F688490A13ELL,0x233DF555A6F0ED5CLL,1UL,0x1EFB40ACB4886636LL},{18446744073709551615UL,8UL,0xBE618B2576953C53LL,0xBE618B2576953C53LL},{1UL,1UL,1UL,18446744073709551612UL}},{{0x83B01F688490A13ELL,0xBE618B2576953C53LL,18446744073709551615UL,18446744073709551608UL},{0xAB65697B4E6B2E54LL,0xC8FE30C1ABDDA6A1LL,0x84BB8686B464BBCDLL,18446744073709551615UL},{1UL,0xC8FE30C1ABDDA6A1LL,8UL,18446744073709551608UL},{0xC8FE30C1ABDDA6A1LL,0xBE618B2576953C53LL,0UL,18446744073709551612UL},{0xE6E92ECD44262C44LL,1UL,0xAB65697B4E6B2E54LL,0xBE618B2576953C53LL},{0x1EFB40ACB4886636LL,8UL,1UL,0x1EFB40ACB4886636LL},{18446744073709551612UL,0x233DF555A6F0ED5CLL,0UL,1UL},{0x02D6FA87DC7FB053LL,0x1CD4EE3B919D6B80LL,0x30F0C86797B69E0DLL,1UL},{1UL,0UL,18446744073709551615UL,0UL},{8UL,18446744073709551615UL,18446744073709551615UL,1UL}}};
        int32_t l_52 = 0xB12BF80AL;
        int32_t l_60 = 0x2C623687L;
        int32_t l_61 = 0xE3ABF990L;
        int32_t l_66 = 0x69DFF36FL;
        int32_t l_67 = 0x5B7EE776L;
        int i, j, k;
        if (((safe_rshift_func_int16_t_s_u(0xFD0AL, 2)) < p_29))
        { /* block id: 8 */
            uint8_t l_38[6][8][5] = {{{7UL,0xA7L,0xFFL,0x10L,0x6BL},{0UL,5UL,0UL,0xB6L,1UL},{1UL,0xB0L,0x32L,0x92L,249UL},{255UL,3UL,0UL,0xFFL,4UL},{3UL,7UL,255UL,0UL,4UL},{0xADL,0xE8L,250UL,0x6DL,249UL},{1UL,0x6DL,1UL,249UL,1UL},{0x88L,0x88L,249UL,0xD3L,0x6BL}},{{0UL,0x10L,0xB0L,3UL,0xBFL},{1UL,0x92L,0UL,0x87L,0x66L},{0xFEL,0x10L,4UL,255UL,0x88L},{249UL,0x4DL,0xE6L,249UL,255UL},{0UL,1UL,247UL,6UL,7UL},{0xE6L,3UL,0x0DL,0x32L,0x6BL},{0x6BL,0x19L,1UL,0x32L,0x50L},{0UL,0xADL,0xD3L,6UL,0x19L}},{{3UL,0x92L,249UL,249UL,0x92L},{0xBFL,0x66L,0xFFL,255UL,1UL},{0xD3L,0x6BL,0x66L,0x87L,7UL},{0UL,255UL,7UL,3UL,0x32L},{0xD3L,0UL,0x0DL,0xB1L,1UL},{0xBFL,0x0DL,4UL,0UL,0x50L},{3UL,249UL,0xADL,1UL,0xFEL},{0UL,0x92L,255UL,0xFFL,0xB1L}},{{0x6BL,0xB0L,255UL,255UL,247UL},{0xE6L,0xBFL,0xADL,4UL,0xA7L},{0UL,5UL,4UL,5UL,0UL},{249UL,0UL,0x0DL,0x66L,0x4DL},{0xFEL,1UL,7UL,0x92L,0x50L},{1UL,0xD3L,0x66L,0UL,0x4DL},{0UL,0x92L,0xFFL,250UL,0UL},{0x4DL,0xE6L,249UL,255UL,0xA7L}},{{0xB0L,0xFEL,0xD3L,255UL,247UL},{0UL,6UL,1UL,0UL,0xB1L},{0xADL,6UL,0x0DL,7UL,0xFEL},{1UL,0xFEL,247UL,0UL,0x50L},{255UL,0xE6L,0xE6L,255UL,1UL},{6UL,0x92L,4UL,0UL,0x32L},{0x19L,0xD3L,0UL,255UL,7UL},{0x66L,1UL,0xB0L,0UL,1UL}},{{0UL,0UL,0xA7L,255UL,0x92L},{0x10L,5UL,0x0DL,0UL,0x19L},{0x0DL,0xBFL,0x88L,7UL,0x50L},{5UL,0xB0L,249UL,0UL,0x6BL},{5UL,0x92L,250UL,255UL,7UL},{0x0DL,249UL,0x87L,255UL,255UL},{0x10L,0UL,0x66L,0x88L,0x4DL},{0xFFL,0xE6L,1UL,0x10L,249UL}}};
            int32_t l_39 = 0xE0A4D2C6L;
            int i, j, k;
            l_38[0][1][2] = ((safe_mod_func_int32_t_s_s((safe_mod_func_int8_t_s_s((safe_add_func_uint8_t_u_u((g_3 , g_3), 0xF9L)), 8UL)), g_3)) , g_3);
            l_40[2][0][2]++;
        }
        else
        { /* block id: 11 */
            uint16_t l_51 = 0x4528L;
            l_52 = (safe_div_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((((safe_mod_func_int64_t_s_s(((safe_mod_func_int32_t_s_s(((65529UL < 1UL) , g_3), p_28)) | g_3), l_51)) & p_28) > p_28), 7UL)), p_29));
            l_52 = (p_28 < g_3);
            l_53 = (g_3 <= g_3);
        }
        for (p_29 = 0; (p_29 <= 3); p_29 += 1)
        { /* block id: 18 */
            l_58 |= (safe_mod_func_uint64_t_u_u((safe_mod_func_int32_t_s_s(g_3, g_3)), l_53));
        }
        ++g_68;
    }
    else
    { /* block id: 22 */
lbl_105:
        g_71++;
    }
lbl_113:
    if ((((safe_add_func_int8_t_s_s(p_28, 247UL)) > 0xD26C8B9CL) , g_3))
    { /* block id: 25 */
        uint16_t l_79 = 0x71B2L;
        for (l_53 = (-24); (l_53 < 41); l_53++)
        { /* block id: 28 */
            int8_t l_78[8];
            int i;
            for (i = 0; i < 8; i++)
                l_78[i] = 0xFBL;
            l_78[4] &= (((0xC29D91FBEB5A7EB3LL || g_71) <= 0x59095518L) <= 4294967293UL);
            if (l_79)
                continue;
            l_64 = 0x696E83D7L;
            g_82 = (((((safe_lshift_func_int16_t_s_s(((4294967290UL | g_59) , l_58), 4)) , p_28) <= 0x9A1150147E15CB46LL) ^ g_68) && g_59);
        }
        for (l_79 = 0; (l_79 <= 8); ++l_79)
        { /* block id: 36 */
            return p_28;
        }
    }
    else
    { /* block id: 39 */
        uint8_t l_85 = 0x87L;
        --l_85;
        l_64 &= (p_28 < p_29);
    }
    for (l_53 = 0; (l_53 == 42); l_53 = safe_add_func_int8_t_s_s(l_53, 8))
    { /* block id: 45 */
        int64_t l_94 = 0x90FFCBD1596F457ELL;
        int32_t l_101 = (-1L);
        int32_t l_114 = 0L;
        int32_t l_116 = (-8L);
        int32_t l_119 = 0xA6F42BAFL;
        if (((safe_mod_func_uint32_t_u_u(((safe_div_func_uint32_t_u_u((l_94 & g_59), p_28)) & p_28), p_28)) | g_82))
        { /* block id: 46 */
            int32_t l_104 = 0x96152EF7L;
            l_101 |= (safe_add_func_uint64_t_u_u((((safe_lshift_func_int8_t_s_u((safe_rshift_func_int8_t_s_u(0xCFL, g_68)), g_82)) > p_29) > l_94), g_82));
            l_104 = ((safe_add_func_int32_t_s_s((0x69D754EFL != p_29), g_3)) , 0x8811EA0AL);
            l_101 = ((0x07L && 6UL) <= g_3);
            if (p_28)
                continue;
        }
        else
        { /* block id: 51 */
            if (p_28)
                goto lbl_105;
            l_101 = l_101;
            l_101 &= ((((safe_add_func_uint16_t_u_u((0xEB578CF17765441CLL & g_82), l_58)) > p_29) && 0UL) >= g_3);
        }
        for (l_65 = 0; (l_65 != 0); l_65 = safe_add_func_int64_t_s_s(l_65, 7))
        { /* block id: 58 */
            int32_t l_112 = 0xC81B4F39L;
            int32_t l_115[3];
            int i;
            for (i = 0; i < 3; i++)
                l_115[i] = (-4L);
            l_112 = ((safe_sub_func_int8_t_s_s((p_28 , l_94), 0x1DL)) & (-6L));
            if (p_29)
                goto lbl_113;
            ++g_120;
        }
        if (((safe_add_func_int16_t_s_s(((((safe_mul_func_uint8_t_u_u(9UL, g_63)) > g_82) & 0xFBCF3A28AA747B88LL) == l_94), p_28)) | l_118[0]))
        { /* block id: 63 */
            g_82 = ((0x0C58L & g_63) && g_3);
        }
        else
        { /* block id: 65 */
            l_118[0] = ((safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(4L, 2)), g_117)) < l_116);
        }
    }
    return l_65;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_168, "g_168", print_hash_value);
    transparent_crc(g_170, "g_170", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 73
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 23
breakdown:
   depth: 1, occurrence: 102
   depth: 2, occurrence: 21
   depth: 3, occurrence: 8
   depth: 4, occurrence: 10
   depth: 5, occurrence: 5
   depth: 6, occurrence: 7
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 10, occurrence: 2
   depth: 11, occurrence: 2
   depth: 16, occurrence: 1
   depth: 23, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 175
XXX times a non-volatile is write: 69
XXX times a volatile is read: 28
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 111
XXX percentage of non-volatile access: 88.4

XXX forward jumps: 0
XXX backward jumps: 3

XXX stmts: 103
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 29
   depth: 2, occurrence: 54

XXX percentage a fresh-made variable is used: 24.3
XXX percentage an existing variable is used: 75.7
********************* end of statistics **********************/

