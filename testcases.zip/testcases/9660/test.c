/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8941672922403112267
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_7 = 0x00L;
static int16_t g_22[6][4] = {{(-7L),0xB0ADL,(-8L),(-4L)},{0L,1L,0L,(-4L)},{(-8L),0xB0ADL,(-7L),0xAD94L},{(-2L),(-4L),0xB0ADL,0xB0ADL},{0x8FE7L,0x8FE7L,0xB0ADL,0L},{(-2L),(-10L),(-7L),(-4L)}};
static int64_t g_27 = 0x20B50F6B34C266D8LL;
static uint16_t g_37[1] = {0x600EL};
static int32_t g_38 = 0x76DBD8D4L;
static uint32_t g_46 = 1UL;
static volatile uint16_t g_47[9][6][4] = {{{0xD4CCL,65535UL,0x8C9EL,65535UL},{65535UL,0x33C5L,65535UL,65535UL},{65535UL,65535UL,0x265DL,0x265DL},{9UL,9UL,0x8C9EL,0xD4CCL},{9UL,0x33C5L,0x265DL,9UL},{65535UL,0x33C5L,1UL,1UL}},{{0x265DL,0x33C5L,9UL,65535UL},{0x33C5L,0x8C9EL,0x8C9EL,0x33C5L},{1UL,65535UL,0x8C9EL,1UL},{0x33C5L,0x265DL,9UL,0x265DL},{0x265DL,0x8C9EL,1UL,0x265DL},{1UL,0x265DL,1UL,1UL}},{{65535UL,65535UL,9UL,0x33C5L},{65535UL,0x8C9EL,1UL,65535UL},{1UL,0x33C5L,1UL,1UL},{0x265DL,0x33C5L,9UL,65535UL},{0x33C5L,0x8C9EL,0x8C9EL,0x33C5L},{1UL,65535UL,0x8C9EL,1UL}},{{0x33C5L,0x265DL,9UL,0x265DL},{0x265DL,0x8C9EL,1UL,0x265DL},{1UL,0x265DL,1UL,1UL},{65535UL,65535UL,9UL,0x33C5L},{65535UL,0x8C9EL,1UL,65535UL},{1UL,0x33C5L,1UL,1UL}},{{0x265DL,0x33C5L,9UL,65535UL},{0x33C5L,0x8C9EL,0x8C9EL,0x33C5L},{1UL,65535UL,0x8C9EL,1UL},{0x33C5L,0x265DL,9UL,0x265DL},{0x265DL,0x8C9EL,1UL,0x265DL},{1UL,0x265DL,1UL,1UL}},{{65535UL,65535UL,9UL,0x33C5L},{65535UL,0x8C9EL,1UL,65535UL},{1UL,0x33C5L,1UL,1UL},{0x265DL,0x33C5L,9UL,65535UL},{0x33C5L,0x8C9EL,0x8C9EL,0x33C5L},{1UL,65535UL,0x8C9EL,1UL}},{{0x33C5L,0x265DL,9UL,0x265DL},{0x265DL,0x8C9EL,1UL,0x265DL},{1UL,0x265DL,1UL,1UL},{65535UL,65535UL,9UL,0x33C5L},{65535UL,0x8C9EL,1UL,65535UL},{1UL,0x33C5L,1UL,1UL}},{{0x265DL,0x33C5L,9UL,65535UL},{0x33C5L,0x8C9EL,0x8C9EL,0x33C5L},{1UL,65535UL,0x8C9EL,1UL},{0x33C5L,0x265DL,9UL,0x265DL},{0x265DL,0x8C9EL,1UL,0x265DL},{1UL,0x265DL,1UL,1UL}},{{65535UL,65535UL,9UL,0x33C5L},{65535UL,0x8C9EL,1UL,65535UL},{1UL,0x33C5L,1UL,1UL},{0x265DL,0x33C5L,9UL,65535UL},{0x33C5L,0x8C9EL,0x8C9EL,0x33C5L},{65535UL,1UL,9UL,0xD4CCL}}};
static int8_t g_74 = 0x5CL;
static int16_t g_75 = 0L;
static uint16_t g_76[3] = {0x07C1L,0x07C1L,0x07C1L};
static int16_t g_80 = (-9L);
static uint64_t g_81 = 0xB2907242BEB92859LL;
static uint16_t g_84[5] = {65535UL,65535UL,65535UL,65535UL,65535UL};
static uint32_t g_88[9] = {18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL};
static volatile int8_t g_96 = 0xF4L;/* VOLATILE GLOBAL g_96 */
static volatile uint64_t g_97 = 0x53CE469C6BC52267LL;/* VOLATILE GLOBAL g_97 */
static int8_t g_100 = 0x05L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static const int32_t  func_2(uint64_t  p_3, int64_t  p_4);
static int32_t  func_12(int8_t  p_13, uint16_t  p_14);
static uint16_t  func_19(const int8_t  p_20);
static int32_t  func_28(uint8_t  p_29, uint64_t  p_30, uint16_t  p_31);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_22 g_38 g_47 g_27 g_37 g_76 g_80 g_81 g_88 g_97
 * writes: g_22 g_27 g_37 g_38 g_7 g_46 g_47 g_76 g_80 g_81 g_84 g_88 g_97 g_100
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_8 = 0xE187L;
    g_100 = func_2(((safe_mul_func_uint8_t_u_u(g_7, l_8)) , g_7), g_7);
    return g_47[8][1][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_22 g_38 g_47 g_27 g_37 g_76 g_80 g_81 g_88 g_97
 * writes: g_22 g_27 g_37 g_38 g_7 g_46 g_47 g_76 g_80 g_81 g_84 g_88 g_97
 */
static const int32_t  func_2(uint64_t  p_3, int64_t  p_4)
{ /* block id: 1 */
    uint32_t l_9 = 4294967295UL;
    int32_t l_91 = (-6L);
    int32_t l_92 = 0x81B99281L;
    int32_t l_93[1][10] = {{0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L,0x49BCD996L}};
    int i, j;
    l_9--;
    if (g_7)
    { /* block id: 3 */
        g_84[3] = func_12((safe_add_func_uint32_t_u_u((safe_add_func_uint16_t_u_u(func_19(g_7), l_9)), l_9)), p_4);
    }
    else
    { /* block id: 40 */
        int32_t l_94 = 1L;
        int32_t l_95 = 0xFF7E953CL;
        g_88[6] = (!(safe_mod_func_uint8_t_u_u(0x4FL, l_9)));
        l_91 |= (safe_mul_func_uint16_t_u_u(g_88[6], 0xB40DL));
        g_97--;
    }
    return l_93[0][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_22 g_27 g_37 g_76 g_80 g_81
 * writes: g_38 g_76 g_80 g_81
 */
static int32_t  func_12(int8_t  p_13, uint16_t  p_14)
{ /* block id: 24 */
    uint32_t l_63[7] = {0x8FFEA059L,0x8FFEA059L,18446744073709551615UL,0x8FFEA059L,0x8FFEA059L,18446744073709551615UL,0x8FFEA059L};
    int32_t l_71 = (-3L);
    int i;
    for (g_38 = 0; (g_38 == 15); g_38 = safe_add_func_uint64_t_u_u(g_38, 7))
    { /* block id: 27 */
        uint8_t l_64 = 0x6AL;
        int32_t l_65 = 1L;
        l_65 = ((safe_div_func_uint64_t_u_u((((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(((+(safe_lshift_func_uint8_t_u_u(253UL, 7))) <= p_14), l_63[4])) , g_38), 2)), g_22[0][2])) , 0UL) && p_14), g_27)) != l_64);
        l_71 = (((safe_add_func_uint16_t_u_u((!((safe_div_func_uint16_t_u_u((g_37[0] <= 4294967287UL), 1UL)) < l_65)), l_63[3])) , 4294967295UL) != 0UL);
        if ((((((((safe_mod_func_uint64_t_u_u(18446744073709551614UL, l_64)) ^ 0UL) > l_63[5]) , p_13) < 0UL) < l_63[4]) >= p_13))
        { /* block id: 30 */
            int32_t l_79 = (-2L);
            ++g_76[1];
            l_79 = (p_13 && p_13);
        }
        else
        { /* block id: 33 */
            g_80 &= (-1L);
        }
    }
    g_81++;
    return g_37[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_22 g_38 g_47
 * writes: g_22 g_27 g_37 g_38 g_7 g_46 g_47
 */
static uint16_t  func_19(const int8_t  p_20)
{ /* block id: 4 */
    uint64_t l_21 = 1UL;
    int32_t l_42 = 2L;
    if (l_21)
    { /* block id: 5 */
        int32_t l_26 = 0xDF2EF51AL;
        g_22[0][2] = p_20;
        g_27 = (!(safe_mul_func_uint16_t_u_u(l_26, 5UL)));
        l_42 = func_28(((l_21 < l_26) != 0xFACD4A79L), p_20, p_20);
    }
    else
    { /* block id: 19 */
        const int16_t l_45[6][9] = {{0x9656L,1L,0x0833L,(-1L),0L,0x1DA8L,0L,(-1L),0x0833L},{(-1L),(-1L),0x6EAFL,0x680DL,0x6EAFL,(-1L),(-1L),0x6EAFL,0x680DL},{0x83BEL,1L,0x83BEL,0x1DA8L,0x9656L,0xAB59L,0L,0xAB59L,0x9656L},{0x2926L,0x6EAFL,0x6EAFL,0x2926L,0xAEFCL,0x2926L,0x6EAFL,0x6EAFL,0x2926L},{0x30AFL,0x1DA8L,0x0833L,0x1DA8L,0x30AFL,0L,0x9656L,(-1L),0x9656L},{0x6EAFL,0xAEFCL,0x680DL,0x680DL,0xAEFCL,0x6EAFL,0xAEFCL,0x680DL,0x680DL}};
        int i, j;
        g_46 = (safe_lshift_func_uint16_t_u_u((l_45[4][5] <= g_22[5][3]), g_7));
        g_47[4][2][2]--;
    }
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_22 g_38
 * writes: g_37 g_38 g_7
 */
static int32_t  func_28(uint8_t  p_29, uint64_t  p_30, uint16_t  p_31)
{ /* block id: 8 */
    int16_t l_32[10][4] = {{0x5AD3L,0xFDDFL,1L,0x5AD3L},{3L,0xB18BL,3L,1L},{(-5L),0xB18BL,(-1L),0x5AD3L},{0xB18BL,0xFDDFL,0xFDDFL,0xB18BL},{3L,0x5AD3L,0xFDDFL,1L},{0xB18BL,(-5L),(-1L),(-5L)},{(-5L),0xFDDFL,3L,(-5L)},{3L,(-5L),1L,1L},{0x5AD3L,0x5AD3L,(-1L),0xB18BL},{0x5AD3L,0xFDDFL,1L,0x5AD3L}};
    int32_t l_41 = 7L;
    int i, j;
    l_32[8][3] = ((((g_7 == p_29) , 0xA165F5C9B8DB370CLL) <= 0x0783518F4C6F4446LL) , g_22[0][2]);
    g_37[0] = (safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((65534UL <= 0xA051L), 65535UL)), l_32[2][0]));
    g_38 ^= (l_32[8][3] ^ 5UL);
    for (g_7 = 0; (g_7 == (-30)); --g_7)
    { /* block id: 14 */
        l_41 = 0x52B8909FL;
    }
    return g_22[0][2];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_22[i][j], "g_22[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_37[i], "g_37[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_47[i][j][k], "g_47[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_76[i], "g_76[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_84[i], "g_84[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_88[i], "g_88[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 35
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 36
   depth: 2, occurrence: 7
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 49
XXX times a non-volatile is write: 21
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 95.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 31
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 13
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 40.7
XXX percentage an existing variable is used: 59.3
********************* end of statistics **********************/

