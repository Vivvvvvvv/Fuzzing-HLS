/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13247004626870758825
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int8_t  f0;
   int16_t  f1;
   int64_t  f2;
   uint32_t  f3;
   uint16_t  f4;
   volatile uint32_t  f5;
   int32_t  f6;
   const int8_t  f7;
   int16_t  f8;
   int64_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_6 = 0xCD4431FAL;
static uint64_t g_11 = 0x81320F2D6273D594LL;
static int32_t g_30 = 0xE12FD89DL;
static volatile uint32_t g_33[10][10] = {{0xD469F41AL,0xA49E864AL,0xD469F41AL,0x7A95534FL,0xA49E864AL,6UL,6UL,0xA49E864AL,0x7A95534FL,0xD469F41AL},{18446744073709551614UL,18446744073709551614UL,0xEC767DBFL,0xA49E864AL,0x4F509E13L,0xEC767DBFL,0x4F509E13L,0xA49E864AL,0xEC767DBFL,18446744073709551614UL},{0x4F509E13L,6UL,0xD469F41AL,0x4F509E13L,0x7A95534FL,0x7A95534FL,0x4F509E13L,0xD469F41AL,6UL,0x4F509E13L},{0xD469F41AL,18446744073709551614UL,6UL,0x7A95534FL,18446744073709551614UL,0x7A95534FL,6UL,18446744073709551614UL,0xD469F41AL,0xD469F41AL},{0x4F509E13L,0xA49E864AL,0xEC767DBFL,18446744073709551614UL,18446744073709551614UL,0xEC767DBFL,6UL,0x7A95534FL,18446744073709551614UL,0x7A95534FL},{0xD469F41AL,0xEC767DBFL,0x726F2C0EL,0xD469F41AL,0x726F2C0EL,0xEC767DBFL,0xD469F41AL,18446744073709551615UL,18446744073709551615UL,0xD469F41AL},{18446744073709551615UL,0x7A95534FL,0x726F2C0EL,0x726F2C0EL,0x7A95534FL,18446744073709551615UL,0xEC767DBFL,0x7A95534FL,0xEC767DBFL,18446744073709551615UL},{6UL,0x7A95534FL,18446744073709551614UL,0x7A95534FL,6UL,18446744073709551614UL,0xD469F41AL,0xD469F41AL,18446744073709551614UL,6UL},{6UL,0xEC767DBFL,0xEC767DBFL,6UL,0x726F2C0EL,18446744073709551615UL,6UL,18446744073709551615UL,0x726F2C0EL,6UL},{18446744073709551615UL,6UL,18446744073709551615UL,0x726F2C0EL,6UL,0xEC767DBFL,0xEC767DBFL,6UL,0x726F2C0EL,18446744073709551615UL}};
static int16_t g_39 = 0x53A6L;
static uint32_t g_40[7][9] = {{0xF575434BL,0UL,0xA8E8B88BL,0xA8A623B0L,0x669D5996L,0x9805F634L,0x726993C4L,0UL,3UL},{0x51854E46L,8UL,0x8DE77BF6L,1UL,4294967291UL,0xA8A623B0L,0UL,3UL,0x452C7957L},{0x5737FB64L,0UL,0x452C7957L,0xA8E8B88BL,0xA8E8B88BL,0x452C7957L,0UL,0x5737FB64L,8UL},{0x9805F634L,0xA8A623B0L,1UL,8UL,4294967295UL,0x5737FB64L,0x726993C4L,0x7A5E2B19L,8UL},{8UL,0x51854E46L,4294967291UL,3UL,0x3DAD933BL,4294967295UL,4294967295UL,0x726993C4L,8UL},{8UL,1UL,0x9805F634L,0x452C7957L,0x1B2B1506L,1UL,1UL,0x1B2B1506L,0x452C7957L},{4294967295UL,1UL,4294967295UL,8UL,0x726993C4L,4294967295UL,4294967295UL,0x3DAD933BL,3UL}};
static int32_t g_43[2][7][8] = {{{3L,(-1L),0x2E546EC7L,0x325A4489L,0x763FF636L,0x70902054L,0xD465C301L,0x70902054L},{0x325A4489L,(-1L),1L,(-1L),0x325A4489L,0x70902054L,1L,0x763FF636L},{0x3F4458B9L,(-1L),(-1L),0xC884E0B5L,0xD465C301L,0xD465C301L,0xC884E0B5L,(-1L)},{0x763FF636L,0x763FF636L,(-1L),3L,0x2E546EC7L,0x40306456L,1L,0x3F4458B9L},{0xD465C301L,1L,1L,0x763FF636L,1L,1L,0xD465C301L,0x3F4458B9L},{1L,0x40306456L,0x2E546EC7L,3L,(-1L),0x763FF636L,0x763FF636L,(-1L)},{0xC884E0B5L,0xD465C301L,0xD465C301L,0xC884E0B5L,(-1L),(-1L),0x3F4458B9L,0x763FF636L}},{{1L,0x70902054L,0x325A4489L,(-1L),1L,(-1L),0x325A4489L,0x70902054L},{0xD465C301L,0x70902054L,0x763FF636L,0x325A4489L,0x2E546EC7L,(-1L),3L,3L},{0x763FF636L,0xD465C301L,0xD465C301L,0xD465C301L,0xC884E0B5L,(-1L),(-1L),0x3F4458B9L},{0x325A4489L,0xD465C301L,(-1L),0x70902054L,0x40306456L,3L,0x40306456L,0x70902054L},{0x40306456L,3L,0x40306456L,0x70902054L,(-1L),0xD465C301L,0x325A4489L,0x3F4458B9L},{(-1L),(-1L),0xC884E0B5L,0xD465C301L,0xD465C301L,0xC884E0B5L,(-1L),(-1L)},{(-1L),0x70902054L,1L,0x40306456L,(-1L),0x2E546EC7L,0xC884E0B5L,0x2E546EC7L}}};
static volatile uint64_t g_51 = 0xFDA63E176CBFBCC8LL;/* VOLATILE GLOBAL g_51 */
static volatile int8_t g_68 = 0x13L;/* VOLATILE GLOBAL g_68 */
static int8_t g_71 = 0xDAL;
static uint8_t g_72 = 0x5FL;
static volatile uint32_t g_83 = 0xD5FEEC88L;/* VOLATILE GLOBAL g_83 */
static const struct S0 g_86[2] = {{0x88L,2L,2L,4294967291UL,0x86D3L,1UL,0x59CB3797L,0x6CL,0x2205L,0xF02031241CAE3A4BLL},{0x88L,2L,2L,4294967291UL,0x86D3L,1UL,0x59CB3797L,0x6CL,0x2205L,0xF02031241CAE3A4BLL}};


/* --- FORWARD DECLARATIONS --- */
static const struct S0  func_1(void);
static int32_t  func_4(int16_t  p_5);
static uint16_t  func_25(const uint16_t  p_26);
static int32_t  func_55(uint16_t  p_56, uint32_t  p_57, uint8_t  p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_11 g_30 g_33 g_40 g_39 g_51 g_72 g_43 g_83 g_86
 * writes: g_11 g_30 g_6 g_33 g_39 g_40 g_43 g_51 g_72 g_83
 */
static const struct S0  func_1(void)
{ /* block id: 0 */
    int16_t l_47 = 0xD9B3L;
    int32_t l_49[4];
    int i;
    for (i = 0; i < 4; i++)
        l_49[i] = 0x980DF3AEL;
    if ((!((65535UL && 9UL) || (-1L))))
    { /* block id: 1 */
        uint64_t l_3 = 18446744073709551611UL;
        l_3 &= 0x401D1B98L;
        g_40[4][4] = func_4(g_6);
        g_43[1][6][4] = func_25((func_25((safe_sub_func_int8_t_s_s(g_40[4][4], 252UL))) < g_40[0][2]));
    }
    else
    { /* block id: 28 */
        uint32_t l_46 = 0xB54C1CE2L;
        const int16_t l_48 = 0xDE0DL;
        uint32_t l_59 = 4294967295UL;
        int32_t l_77 = (-1L);
        l_47 = (safe_div_func_int8_t_s_s((g_6 >= l_46), g_39));
        if (g_6)
            goto lbl_50;
lbl_50:
        l_49[3] &= func_25(l_48);
        g_51--;
        l_77 = ((+func_55(l_59, g_33[9][6], l_59)) | g_43[1][6][4]);
    }
    for (g_39 = (-8); (g_39 >= 5); g_39 = safe_add_func_uint16_t_u_u(g_39, 7))
    { /* block id: 46 */
        const int8_t l_82 = 0x9CL;
        g_30 = ((safe_add_func_uint8_t_u_u(l_82, l_82)) > l_47);
    }
    --g_83;
    return g_86[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_30 g_6 g_33
 * writes: g_11 g_30 g_6 g_33 g_39
 */
static int32_t  func_4(int16_t  p_5)
{ /* block id: 3 */
    uint32_t l_9[2][2] = {{0x9A7B445AL,0x9A7B445AL},{0x9A7B445AL,0x9A7B445AL}};
    int32_t l_10 = 0x85DC1B6EL;
    int32_t l_14 = 5L;
    int64_t l_38[5] = {0x0936A74B4FBF646DLL,0x0936A74B4FBF646DLL,0x0936A74B4FBF646DLL,0x0936A74B4FBF646DLL,0x0936A74B4FBF646DLL};
    int i, j;
    g_11 |= (safe_div_func_int64_t_s_s(l_9[0][0], l_10));
    for (p_5 = (-15); (p_5 == 14); p_5 = safe_add_func_int8_t_s_s(p_5, 3))
    { /* block id: 7 */
        for (l_10 = 0; (l_10 <= 1); l_10 += 1)
        { /* block id: 10 */
            int i, j;
            l_14 |= 0x42628217L;
            g_39 = (safe_add_func_int16_t_s_s((safe_sub_func_int32_t_s_s(((safe_div_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(func_25(l_9[l_10][l_10]), l_38[0])), g_11)) != g_11), g_11)) < p_5), p_5)), 65528UL));
            l_14 = l_14;
        }
    }
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_30 g_6 g_33
 * writes: g_30 g_6 g_33
 */
static uint16_t  func_25(const uint16_t  p_26)
{ /* block id: 12 */
    int64_t l_29 = 0xC786C7A88FF7673ELL;
    g_30 ^= (((safe_rshift_func_uint8_t_u_s(0x68L, 2)) & l_29) , p_26);
    for (g_6 = 0; (g_6 > 38); g_6++)
    { /* block id: 16 */
        uint32_t l_37 = 0xA51C18CCL;
        ++g_33[9][6];
        l_37 ^= ((+0UL) | g_6);
    }
    return l_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_72
 * writes: g_6 g_30 g_72
 */
static int32_t  func_55(uint16_t  p_56, uint32_t  p_57, uint8_t  p_58)
{ /* block id: 33 */
    int32_t l_62 = 0xDF11966DL;
    int32_t l_65 = 7L;
    int32_t l_66 = 0x2FCAAFA3L;
    int32_t l_67 = 0x02F5F5C3L;
    int32_t l_69 = 9L;
    int32_t l_70 = 0L;
    int32_t l_76 = 0L;
    for (g_6 = 0; (g_6 >= 50); g_6 = safe_add_func_uint8_t_u_u(g_6, 6))
    { /* block id: 36 */
        int8_t l_63 = 0x50L;
        int32_t l_64[5];
        int i;
        for (i = 0; i < 5; i++)
            l_64[i] = (-7L);
        g_30 = 0xCC562928L;
        --g_72;
        g_30 = ((safe_unary_minus_func_int16_t_s(0x9CCAL)) > g_6);
    }
    return l_76;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_33[i][j], "g_33[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_39, "g_39", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_40[i][j], "g_40[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_43[i][j][k], "g_43[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_86[i].f0, "g_86[i].f0", print_hash_value);
        transparent_crc(g_86[i].f1, "g_86[i].f1", print_hash_value);
        transparent_crc(g_86[i].f2, "g_86[i].f2", print_hash_value);
        transparent_crc(g_86[i].f3, "g_86[i].f3", print_hash_value);
        transparent_crc(g_86[i].f4, "g_86[i].f4", print_hash_value);
        transparent_crc(g_86[i].f5, "g_86[i].f5", print_hash_value);
        transparent_crc(g_86[i].f6, "g_86[i].f6", print_hash_value);
        transparent_crc(g_86[i].f7, "g_86[i].f7", print_hash_value);
        transparent_crc(g_86[i].f8, "g_86[i].f8", print_hash_value);
        transparent_crc(g_86[i].f9, "g_86[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 32
   depth: 2, occurrence: 10
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 21
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 93.4

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 30
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 15
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 49.3
XXX percentage an existing variable is used: 50.7
********************* end of statistics **********************/

