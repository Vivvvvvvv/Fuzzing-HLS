/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2066053010360233286
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_7[3] = {250UL,250UL,250UL};
static uint64_t g_22 = 0x46E74A6E8F59172DLL;
static int16_t g_48 = 0x7DBCL;
static uint32_t g_55 = 4UL;
static volatile uint32_t g_64 = 0UL;/* VOLATILE GLOBAL g_64 */
static uint64_t g_67 = 18446744073709551615UL;
static int32_t g_69 = 0x799115BAL;
static int32_t g_75[3][10] = {{0xECA365B0L,0xD8D86F2FL,0xECA365B0L,(-1L),(-1L),0xECA365B0L,0xD8D86F2FL,0xECA365B0L,(-1L),(-1L)},{0xECA365B0L,0xD8D86F2FL,0xECA365B0L,(-1L),(-1L),0xECA365B0L,0xD8D86F2FL,0xECA365B0L,(-1L),(-1L)},{0xECA365B0L,0xD8D86F2FL,0xECA365B0L,(-1L),(-1L),0xECA365B0L,0xD8D86F2FL,0xECA365B0L,(-1L),(-1L)}};
static int8_t g_76 = 0L;
static volatile int16_t g_77 = (-7L);/* VOLATILE GLOBAL g_77 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_4(uint8_t  p_5, const uint8_t  p_6);
static uint32_t  func_13(int32_t  p_14, int32_t  p_15, int64_t  p_16, uint16_t  p_17);
static int32_t  func_38(int16_t  p_39, uint8_t  p_40, int8_t  p_41, int8_t  p_42);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_22 g_48 g_55 g_64 g_67 g_69 g_75
 * writes: g_22 g_48 g_55 g_64 g_67 g_69 g_75
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    const int16_t l_8 = 0x0887L;
    int32_t l_70 = 3L;
    int32_t l_78 = 1L;
    int32_t l_79 = 0xE07DECC7L;
    uint32_t l_80 = 0xA9A6AE6CL;
    if ((safe_div_func_int64_t_s_s(func_4(g_7[1], l_8), g_7[1])))
    { /* block id: 61 */
        l_70 = g_69;
    }
    else
    { /* block id: 63 */
        int8_t l_74 = (-1L);
        l_70 &= g_48;
        g_75[1][7] ^= ((safe_unary_minus_func_uint32_t_u(((safe_lshift_func_int16_t_s_s(func_38((g_7[1] != g_48), g_69, g_7[0], g_22), l_74)) && (-4L)))) > 2L);
        l_80++;
        g_69 &= ((((safe_unary_minus_func_uint8_t_u(g_22)) == l_80) > g_7[1]) , 0x66DF6EF7L);
    }
    l_70 = g_67;
    return g_69;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_22 g_48 g_55 g_64 g_67
 * writes: g_22 g_48 g_55 g_64 g_67 g_69
 */
static int64_t  func_4(uint8_t  p_5, const uint8_t  p_6)
{ /* block id: 1 */
    int8_t l_20 = 1L;
    int32_t l_63 = (-7L);
    for (p_5 = 0; (p_5 >= 50); p_5 = safe_add_func_int32_t_s_s(p_5, 1))
    { /* block id: 4 */
        int32_t l_19 = 0L;
        if ((safe_sub_func_uint8_t_u_u((g_7[1] , 7UL), p_5)))
        { /* block id: 5 */
            l_19 = (func_13(p_5, g_7[2], p_6, g_7[1]) | g_7[1]);
            return p_5;
        }
        else
        { /* block id: 10 */
            uint16_t l_21 = 1UL;
            l_20 = ((g_7[0] & g_7[0]) != 18446744073709551615UL);
            return l_21;
        }
    }
    g_22 = g_7[1];
    for (l_20 = 0; (l_20 < 10); ++l_20)
    { /* block id: 18 */
        int16_t l_43 = (-4L);
        for (g_22 = 0; (g_22 <= 7); g_22 = safe_add_func_int32_t_s_s(g_22, 1))
        { /* block id: 21 */
            uint32_t l_57 = 0x9BB2D3F5L;
            int32_t l_58[5][2][1] = {{{0xE8A086CCL},{1L}},{{1L},{0xE8A086CCL}},{{1L},{1L}},{{0xE8A086CCL},{1L}},{{1L},{0xE8A086CCL}}};
            int i, j, k;
            l_58[2][1][0] = (safe_add_func_int64_t_s_s((safe_div_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u(((func_13((func_13(((safe_mul_func_int16_t_s_s((safe_add_func_uint8_t_u_u((safe_unary_minus_func_int32_t_s(func_38((l_43 , l_43), l_20, g_7[0], l_43))), g_7[1])), l_43)) & 18446744073709551610UL), g_7[1], p_6, g_22) < 0x95A2E206C165AAE7LL), g_22, p_6, l_57) ^ p_6) & 0x352AL), l_43)) || p_5), p_6)), 1L));
        }
        for (l_43 = (-6); (l_43 < 5); ++l_43)
        { /* block id: 46 */
            return g_48;
        }
        if (((safe_add_func_uint16_t_u_u(((l_20 >= g_22) & l_20), 0xAF72L)) && g_48))
        { /* block id: 49 */
            --g_64;
            g_67 = func_13(p_6, g_48, l_63, l_63);
        }
        else
        { /* block id: 52 */
            uint64_t l_68[3];
            int i;
            for (i = 0; i < 3; i++)
                l_68[i] = 18446744073709551610UL;
            if (g_55)
                break;
            g_69 = (((g_67 , l_43) & l_68[0]) ^ 0xCBL);
            l_63 &= func_13(g_55, l_43, l_20, g_22);
            if (g_22)
                continue;
        }
        if (g_7[0])
            break;
    }
    return g_67;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_13(int32_t  p_14, int32_t  p_15, int64_t  p_16, uint16_t  p_17)
{ /* block id: 6 */
    uint16_t l_18 = 65535UL;
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_48 g_22 g_55
 * writes: g_48 g_55
 */
static int32_t  func_38(int16_t  p_39, uint8_t  p_40, int8_t  p_41, int8_t  p_42)
{ /* block id: 22 */
    uint32_t l_47[7][8] = {{8UL,4294967293UL,4294967288UL,0UL,0xC19AC4E6L,4294967293UL,0UL,0x7F77771FL},{0x89188B9AL,0xA8B742D6L,0x86989626L,3UL,4294967287UL,3UL,0x86989626L,0xA8B742D6L},{0xA8B742D6L,4294967289UL,0x758A8CE9L,0xC19AC4E6L,0x86989626L,0x758A8CE9L,0x7F77771FL,0x89188B9AL},{0x7F77771FL,0x20F84B0FL,0x6DF80008L,0x8A514227L,0xA8B742D6L,8UL,0x7F77771FL,0x7F77771FL},{4294967288UL,0x8A514227L,0x758A8CE9L,0x758A8CE9L,0x8A514227L,4294967288UL,0x86989626L,0x20F84B0FL},{0x8A514227L,4294967288UL,0x86989626L,0x20F84B0FL,3UL,0x758A8CE9L,0UL,3UL},{0x20F84B0FL,0x7F77771FL,4294967290UL,0x20F84B0FL,0xA8B742D6L,4294967287UL,0xA8B742D6L,0x20F84B0FL}};
    int32_t l_56 = 6L;
    int i, j;
    for (p_39 = 0; (p_39 != 21); p_39++)
    { /* block id: 25 */
        uint32_t l_46 = 1UL;
        l_46 = p_41;
        return l_47[2][5];
    }
    g_48 = (p_39 && l_47[0][5]);
    if (((safe_lshift_func_int16_t_s_s(g_48, l_47[2][5])) != g_48))
    { /* block id: 30 */
        return g_22;
    }
    else
    { /* block id: 32 */
        for (p_42 = 14; (p_42 > 6); p_42--)
        { /* block id: 35 */
            if (g_48)
                break;
            g_55 = ((safe_mul_func_int8_t_s_s(g_48, 0x26L)) != l_47[2][5]);
        }
    }
    l_56 = (func_13(p_40, g_55, l_47[2][1], g_55) && g_55);
    return l_47[2][5];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_75[i][j], "g_75[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 28
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 24
breakdown:
   depth: 1, occurrence: 38
   depth: 2, occurrence: 7
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 9, occurrence: 1
   depth: 24, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 89
XXX times a non-volatile is write: 23
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 26
XXX percentage of non-volatile access: 99.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 14
   depth: 2, occurrence: 14

XXX percentage a fresh-made variable is used: 25.9
XXX percentage an existing variable is used: 74.1
********************* end of statistics **********************/

