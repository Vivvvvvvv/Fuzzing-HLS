/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3684056149886128868
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_5 = 0x06L;/* VOLATILE GLOBAL g_5 */
static uint32_t g_14 = 4294967295UL;
static volatile int32_t g_33 = 1L;/* VOLATILE GLOBAL g_33 */
static int32_t g_34[8] = {0L,0L,0L,0L,0L,0L,0L,0L};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int8_t  func_8(uint8_t  p_9, const int32_t  p_10, int16_t  p_11, uint64_t  p_12, int32_t  p_13);
static int16_t  func_20(int8_t  p_21, int8_t  p_22, int32_t  p_23, int32_t  p_24);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_14 g_33 g_34
 * writes: g_5 g_33 g_34
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2 = 18446744073709551615UL;
    uint32_t l_15[5] = {0xAC12265EL,0xAC12265EL,0xAC12265EL,0xAC12265EL,0xAC12265EL};
    int32_t l_59[7] = {0x516035E9L,0x516035E9L,0x516035E9L,0x516035E9L,0x516035E9L,0x516035E9L,0x516035E9L};
    int i;
    l_2--;
    g_5 = (-8L);
    l_59[2] = (safe_rshift_func_int8_t_s_s(func_8(((g_5 > g_14) == 0x90069F30L), l_2, g_14, g_14, l_15[2]), 7));
    return g_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_14 g_33 g_34
 * writes: g_33 g_34
 */
static int8_t  func_8(uint8_t  p_9, const int32_t  p_10, int16_t  p_11, uint64_t  p_12, int32_t  p_13)
{ /* block id: 3 */
    uint16_t l_31 = 1UL;
    int32_t l_49 = 0x2E26A8ACL;
    uint8_t l_57 = 254UL;
    g_34[1] |= (safe_mul_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_u(((((func_20(((safe_mod_func_uint8_t_u_u(((safe_lshift_func_int16_t_s_s(((safe_div_func_uint64_t_u_u(g_5, g_14)) <= l_31), 6)) , 0x23L), 0x39L)) && 1UL), g_14, l_31, g_14) && l_31) , l_31) != l_31) , p_9), 4)) < p_10), l_31));
    for (p_9 = 0; (p_9 > 26); p_9 = safe_add_func_uint16_t_u_u(p_9, 7))
    { /* block id: 12 */
        int32_t l_39 = 0xA82BC906L;
        int32_t l_51 = 0xA7FAD540L;
        int32_t l_58 = 0x7E7924A0L;
        if ((safe_lshift_func_int16_t_s_s((l_39 == p_12), 5)))
        { /* block id: 13 */
            uint64_t l_44 = 0UL;
            l_44 = (((safe_add_func_uint32_t_u_u(((safe_add_func_uint8_t_u_u(p_12, p_11)) & l_39), p_11)) ^ 0xA737B78FL) <= g_5);
        }
        else
        { /* block id: 15 */
            int32_t l_50 = 1L;
            uint32_t l_52 = 0xE3C48971L;
            g_34[1] = (safe_sub_func_uint32_t_u_u((safe_rshift_func_int8_t_s_s(l_39, p_11)), p_11));
            --l_52;
            g_34[6] = (safe_mod_func_uint32_t_u_u(l_31, p_9));
            if (g_34[1])
                break;
        }
        l_58 &= ((l_51 | l_57) , 0xC012777FL);
        if (g_33)
            break;
    }
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_33 g_5
 * writes: g_33
 */
static int16_t  func_20(int8_t  p_21, int8_t  p_22, int32_t  p_23, int32_t  p_24)
{ /* block id: 4 */
    int16_t l_32[3];
    int i;
    for (i = 0; i < 3; i++)
        l_32[i] = 0L;
    for (p_22 = 0; p_22 < 3; p_22 += 1)
    {
        l_32[p_22] = (-1L);
    }
    p_24 = ((g_14 < p_23) && 0x4D8D955AL);
    g_33 &= 0L;
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 21
   depth: 2, occurrence: 2
   depth: 3, occurrence: 4
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 35
XXX times a non-volatile is write: 10
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 86.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 19
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 3
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 26.7
XXX percentage an existing variable is used: 73.3
********************* end of statistics **********************/

