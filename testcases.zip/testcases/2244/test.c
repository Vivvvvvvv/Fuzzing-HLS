/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5359687007546159946
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 6L;
static uint32_t g_18 = 0UL;
static int32_t g_30 = (-7L);
static uint64_t g_37 = 0x31E34F9A325CF162LL;
static int32_t g_40 = 2L;
static volatile uint8_t g_52 = 2UL;/* VOLATILE GLOBAL g_52 */
static int64_t g_58[10] = {0x99369E1D62101101LL,0x65120B879B6842A4LL,0x99369E1D62101101LL,0x99369E1D62101101LL,0x65120B879B6842A4LL,0x99369E1D62101101LL,0x99369E1D62101101LL,0x65120B879B6842A4LL,0x99369E1D62101101LL,0x99369E1D62101101LL};
static volatile int8_t g_65 = 0xBCL;/* VOLATILE GLOBAL g_65 */
static volatile uint32_t g_69 = 0x82859701L;/* VOLATILE GLOBAL g_69 */
static uint8_t g_72 = 0x25L;
static volatile uint32_t g_76 = 2UL;/* VOLATILE GLOBAL g_76 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint8_t  func_9(uint16_t  p_10);
static uint16_t  func_21(int32_t  p_22);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_18 g_37 g_40 g_30 g_52 g_69 g_72 g_76 g_58
 * writes: g_2 g_18 g_37 g_40 g_52 g_69 g_72
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_11 = 0xD3C1L;
    int32_t l_83[2];
    int i;
    for (i = 0; i < 2; i++)
        l_83[i] = 0x1F0B5F9DL;
    for (g_2 = 0; (g_2 == (-23)); g_2--)
    { /* block id: 3 */
        int32_t l_77 = 0x49608984L;
        l_77 = (((safe_sub_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u(func_9((l_11 != 3UL)), 2)) ^ 0L), l_11)) || g_76) < g_2);
    }
    l_83[0] = (((safe_lshift_func_uint8_t_u_s((+((safe_mul_func_int16_t_s_s(l_11, l_11)) >= l_11)), 7)) , 0xB7286010944B0CECLL) | l_11);
    return g_58[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_2 g_37 g_40 g_30 g_52 g_69 g_72
 * writes: g_18 g_37 g_40 g_52 g_69 g_72
 */
static uint8_t  func_9(uint16_t  p_10)
{ /* block id: 4 */
    int8_t l_14 = 3L;
    int32_t l_41 = 0x996E1580L;
    int32_t l_51 = 0xD3B05E26L;
    int32_t l_59 = (-8L);
    int32_t l_67 = (-9L);
    int16_t l_75[5] = {0x29C6L,0x29C6L,0x29C6L,0x29C6L,0x29C6L};
    int i;
    for (p_10 = (-20); (p_10 <= 22); ++p_10)
    { /* block id: 7 */
        uint64_t l_17 = 18446744073709551615UL;
        if (l_14)
            break;
        l_17 = ((safe_mul_func_int8_t_s_s((((-1L) >= (-1L)) | 0L), (-5L))) < (-1L));
        g_18 ^= l_17;
    }
    l_41 &= (safe_rshift_func_uint8_t_u_s((func_21((safe_div_func_uint16_t_u_u(g_2, p_10))) , p_10), g_30));
    if ((((safe_mod_func_uint32_t_u_u((((safe_lshift_func_uint16_t_u_u((g_2 || (-5L)), p_10)) | (-1L)) | l_14), g_40)) >= p_10) > 0x49562184L))
    { /* block id: 21 */
        uint8_t l_48 = 246UL;
        int16_t l_50 = 0x5D1BL;
        int32_t l_57 = (-1L);
        int32_t l_68[5] = {(-4L),(-4L),(-4L),(-4L),(-4L)};
        int i;
        for (l_14 = 13; (l_14 >= (-10)); l_14 = safe_sub_func_int32_t_s_s(l_14, 3))
        { /* block id: 24 */
            uint32_t l_49[3];
            int i;
            for (i = 0; i < 3; i++)
                l_49[i] = 0x9FC5C2DAL;
            l_48 = p_10;
            l_41 = 0x8B293C34L;
            l_49[2] |= g_2;
        }
        --g_52;
        l_57 = (safe_div_func_uint16_t_u_u((65529UL < g_52), 0x5794L));
        for (p_10 = 0; (p_10 <= 9); p_10 += 1)
        { /* block id: 33 */
            uint64_t l_60[2];
            int32_t l_63 = 0x76E5F377L;
            int32_t l_64 = (-2L);
            int32_t l_66 = 0x286E0DAEL;
            int i;
            for (i = 0; i < 2; i++)
                l_60[i] = 18446744073709551607UL;
            l_57 = (-2L);
            --l_60[1];
            ++g_69;
            g_72--;
        }
    }
    else
    { /* block id: 39 */
        return l_75[3];
    }
    return l_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_37 g_40
 * writes: g_37 g_40
 */
static uint16_t  func_21(int32_t  p_22)
{ /* block id: 12 */
    uint8_t l_25[8] = {253UL,0x88L,0x88L,253UL,0x88L,0x88L,253UL,0x88L};
    int32_t l_28 = (-1L);
    int32_t l_29 = (-10L);
    int32_t l_34 = 0L;
    int32_t l_35 = 0x2C3B03C3L;
    int i;
    for (p_22 = 2; (p_22 <= 7); p_22 += 1)
    { /* block id: 15 */
        int64_t l_26 = (-1L);
        int32_t l_27 = 0x95DBC2A4L;
        int32_t l_31 = 0x45BEAC3EL;
        int32_t l_32 = 0x56540F21L;
        int32_t l_33 = 0xCB8E0045L;
        int32_t l_36[10] = {0L,(-1L),0L,0x4A0435E4L,0x4A0435E4L,0L,(-1L),0L,0x4A0435E4L,0x4A0435E4L};
        int i;
        g_37++;
        g_40 &= l_25[p_22];
    }
    return l_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_58[i], "g_58[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 38
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 32
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 19
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 92.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 27
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 11
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 46.9
XXX percentage an existing variable is used: 53.1
********************* end of statistics **********************/

