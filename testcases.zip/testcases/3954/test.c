/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5881589334178169377
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint64_t g_5 = 0x93EE327439CB61D2LL;
static int8_t g_17 = (-1L);
static int16_t g_27 = 0x5E3AL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_11(uint32_t  p_12, int64_t  p_13, uint16_t  p_14, uint16_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_17 g_27
 * writes: g_17 g_27
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_4 = 0xCBL;
    uint64_t l_7 = 18446744073709551607UL;
    int32_t l_10 = 0xFA318711L;
    if ((((safe_div_func_uint32_t_u_u((((l_4 > 1UL) || l_4) > g_5), l_4)) && l_4) <= g_5))
    { /* block id: 1 */
        uint64_t l_6[9] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
        int i;
        return l_6[4];
    }
    else
    { /* block id: 3 */
        l_7++;
    }
    l_10 = l_7;
    g_27 = func_11(g_5, l_10, l_7, g_5);
    l_10 = l_7;
    return g_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_5
 * writes: g_17
 */
static int32_t  func_11(uint32_t  p_12, int64_t  p_13, uint16_t  p_14, uint16_t  p_15)
{ /* block id: 7 */
    int16_t l_16 = (-1L);
    int32_t l_18[1];
    uint8_t l_26[9];
    int i;
    for (i = 0; i < 1; i++)
        l_18[i] = 0xF1EDD1EDL;
    for (i = 0; i < 9; i++)
        l_26[i] = 0UL;
lbl_21:
    g_17 ^= ((0x382E5809L == l_16) <= p_13);
    l_18[0] = (p_13 <= 0x467B47E0L);
    for (g_17 = 27; (g_17 >= 1); g_17 = safe_sub_func_uint16_t_u_u(g_17, 1))
    { /* block id: 12 */
        if (p_13)
            goto lbl_21;
    }
    l_26[2] |= ((safe_sub_func_int8_t_s_s((safe_mul_func_int16_t_s_s((0xBD53D2AE45661C44LL ^ 0x18264D9248E6BAE0LL), g_17)), g_5)) , 0xFA9DFEEEL);
    return p_13;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 37
XXX percentage an existing variable is used: 63
********************* end of statistics **********************/

