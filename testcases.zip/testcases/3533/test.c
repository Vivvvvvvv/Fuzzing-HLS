/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7586634414104210873
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3[5] = {0xBE1D925BL,0xBE1D925BL,0xBE1D925BL,0xBE1D925BL,0xBE1D925BL};
static volatile int8_t g_10 = 9L;/* VOLATILE GLOBAL g_10 */
static volatile int32_t g_12 = 0xE7CCC895L;/* VOLATILE GLOBAL g_12 */
static volatile int32_t g_13 = 1L;/* VOLATILE GLOBAL g_13 */
static volatile uint8_t g_14 = 3UL;/* VOLATILE GLOBAL g_14 */
static uint64_t g_64 = 0xAA30D26BC8B8ECDELL;
static volatile int32_t g_67[7] = {1L,(-7L),(-7L),1L,(-7L),(-7L),1L};
static int32_t g_77 = 0x6079B8BCL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint32_t  func_23(uint16_t  p_24, int32_t  p_25, int8_t  p_26, uint64_t  p_27, uint16_t  p_28);
static int8_t  func_37(const uint32_t  p_38, const uint32_t  p_39, uint64_t  p_40, const uint8_t  p_41);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_14 g_13 g_10 g_12 g_64 g_67
 * writes: g_3 g_14 g_64 g_67 g_77
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0xF9C28ADEL;
    int64_t l_8 = 0xC9ED9BA07E4FC228LL;
    int32_t l_9 = 0x9EE1C974L;
    int32_t l_11[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
    int8_t l_34 = 0x4DL;
    int8_t l_63 = (-3L);
    int i;
    g_3[1] = l_2;
    if ((safe_div_func_int16_t_s_s((safe_add_func_int64_t_s_s(1L, l_8)), g_3[1])))
    { /* block id: 2 */
        int32_t l_33 = 1L;
        int32_t l_61 = 0x202EAB38L;
        g_14++;
        for (l_2 = 0; (l_2 <= (-13)); --l_2)
        { /* block id: 6 */
            const int16_t l_19[4] = {0xFF12L,0xFF12L,0xFF12L,0xFF12L};
            int32_t l_20 = 0x00D5493EL;
            int i;
            l_20 = ((l_19[0] == l_19[0]) ^ 18446744073709551612UL);
            l_61 |= (safe_mod_func_uint32_t_u_u(func_23(((safe_div_func_int64_t_s_s(((safe_mod_func_uint64_t_u_u(l_33, g_3[0])) , l_19[3]), l_2)) | g_3[1]), l_19[0], l_34, g_13, l_33), l_20));
        }
        l_33 = (((((g_14 || l_8) <= l_33) , 1UL) && 255UL) <= g_3[0]);
    }
    else
    { /* block id: 35 */
        int8_t l_62 = 5L;
        uint16_t l_71 = 65535UL;
        int32_t l_72 = (-1L);
        g_64 |= (((((((0L > 0xBEL) , g_14) & l_62) == l_63) & 0xED4B89D5L) > l_62) && g_12);
        if (l_62)
            goto lbl_68;
        if ((((((g_10 , 0xD2CCL) || g_3[3]) ^ g_3[2]) && g_14) & l_63))
        { /* block id: 37 */
            l_11[0] = ((safe_add_func_uint8_t_u_u(g_13, 0xD1L)) & g_64);
            g_67[6] = 0L;
        }
        else
        { /* block id: 40 */
lbl_68:
            g_67[2] = 0xDF3DC494L;
            l_72 = (safe_mod_func_uint64_t_u_u(l_2, l_71));
        }
        l_9 = ((safe_sub_func_uint8_t_u_u((((0xFCL | 1L) , g_10) < g_3[0]), 250UL)) && 0L);
        l_11[0] = (((((g_14 , g_10) & 1UL) > l_62) & 0xBDL) >= 0x16L);
    }
    g_67[4] = (safe_mod_func_uint64_t_u_u(l_8, g_67[6]));
    g_77 = 0x8A7D7D4BL;
    return g_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_13 g_14 g_10 g_12
 * writes:
 */
static uint32_t  func_23(uint16_t  p_24, int32_t  p_25, int8_t  p_26, uint64_t  p_27, uint16_t  p_28)
{ /* block id: 8 */
    int32_t l_55 = (-4L);
    int32_t l_56 = 0x955E3164L;
    l_56 &= ((((((safe_mul_func_int16_t_s_s((func_37(p_26, p_26, g_3[1], p_27) , p_28), l_55)) ^ p_27) , g_14) , g_10) & p_25) && 18446744073709551615UL);
    l_56 = 0xDBC0BA88L;
    if ((~(((l_55 , 1L) | p_27) , g_3[1])))
    { /* block id: 22 */
        return p_24;
    }
    else
    { /* block id: 24 */
        uint8_t l_58 = 8UL;
        if ((l_58 , g_14))
        { /* block id: 25 */
            uint32_t l_60 = 0x7DFBF73EL;
            l_60 = ((((safe_unary_minus_func_uint8_t_u((((l_56 > 0x5DE30EA3L) >= 0xE756L) | g_3[0]))) != 0UL) | l_56) > g_12);
        }
        else
        { /* block id: 27 */
            p_25 = (p_26 ^ 0xFAAB93B5L);
        }
    }
    return g_3[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_13
 * writes:
 */
static int8_t  func_37(const uint32_t  p_38, const uint32_t  p_39, uint64_t  p_40, const uint8_t  p_41)
{ /* block id: 9 */
    int32_t l_47 = 0L;
    uint32_t l_54 = 0UL;
lbl_48:
    for (p_40 = 0; (p_40 <= 4); p_40 += 1)
    { /* block id: 12 */
        uint32_t l_42 = 1UL;
        int i;
        l_42 = 0L;
        return g_3[p_40];
    }
    l_47 = ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_s(0xA1L, l_47)), 13)) > p_40);
    if (l_47)
        goto lbl_48;
    l_47 = ((((safe_mod_func_uint32_t_u_u(((+(p_38 ^ g_13)) && p_39), p_41)) > l_54) || 0L) , l_54);
    return p_41;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_67[i], "g_67[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_77, "g_77", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 28
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 35
   depth: 2, occurrence: 6
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 6, occurrence: 4
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 58
XXX times a non-volatile is write: 19
XXX times a volatile is read: 17
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 35
XXX percentage of non-volatile access: 78.6

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 34
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 12
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 28.6
XXX percentage an existing variable is used: 71.4
********************* end of statistics **********************/

