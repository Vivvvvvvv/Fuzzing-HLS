/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14165278845918504985
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_2 = 0UL;
static volatile int32_t g_5 = 0xFAAFE30FL;/* VOLATILE GLOBAL g_5 */
static uint64_t g_7[1] = {0xB7D8CF4C59CDC345LL};
static uint64_t g_48 = 0xB883EB999C826FFELL;
static int16_t g_55 = 0xBE2FL;
static volatile uint64_t g_56 = 4UL;/* VOLATILE GLOBAL g_56 */
static int8_t g_59 = (-9L);
static volatile uint64_t g_60 = 0x75688AFC007DFDCBLL;/* VOLATILE GLOBAL g_60 */
static uint32_t g_68 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_11(uint64_t  p_12, int16_t  p_13, uint32_t  p_14, int64_t  p_15);
static uint16_t  func_18(int16_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_7 g_5 g_48 g_56 g_60 g_55 g_68
 * writes: g_7 g_48 g_56 g_60 g_5 g_55
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_3 = 0xF2887CF2L;
    int32_t l_4 = (-7L);
    int32_t l_6 = 0xC97412DFL;
    l_4 = (((g_2 <= 1UL) < l_3) <= l_3);
    if (g_2)
        goto lbl_10;
lbl_10:
    --g_7[0];
    g_5 = func_11((safe_sub_func_uint16_t_u_u(func_18((safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s((((-1L) == l_6) == g_5), l_6)), 2)), l_4))), (-9L))), l_6, g_7[0], l_4);
    for (g_55 = 0; (g_55 != 0); g_55 = safe_add_func_int32_t_s_s(g_55, 3))
    { /* block id: 33 */
        uint32_t l_65[6];
        int i;
        for (i = 0; i < 6; i++)
            l_65[i] = 0x2FC23FAAL;
        ++l_65[1];
        return g_68;
    }
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_5 g_48 g_2 g_56 g_60
 * writes: g_48 g_56 g_60
 */
static int32_t  func_11(uint64_t  p_12, int16_t  p_13, uint32_t  p_14, int64_t  p_15)
{ /* block id: 6 */
    uint64_t l_34 = 0xF390F3BD791F9E6ALL;
    int32_t l_35 = 2L;
    const uint16_t l_40 = 0x40C8L;
    int32_t l_44 = 0L;
    int32_t l_45 = (-1L);
    int32_t l_46[4] = {0x927DB404L,0x927DB404L,0x927DB404L,0x927DB404L};
    int i;
    for (p_15 = 0; (p_15 <= 0); p_15 += 1)
    { /* block id: 9 */
        int32_t l_29 = (-7L);
        int i;
        l_29 = ((safe_mod_func_int8_t_s_s(g_7[p_15], 0xD6L)) ^ g_7[p_15]);
        for (p_13 = 0; (p_13 >= 0); p_13 -= 1)
        { /* block id: 13 */
            int16_t l_41[3];
            int i;
            for (i = 0; i < 3; i++)
                l_41[i] = 0xD127L;
            l_35 = (safe_add_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u(0UL, 6)), l_34));
            l_29 = (safe_rshift_func_int8_t_s_s(((safe_lshift_func_int8_t_s_u(((0xB659BAAA4F69A750LL <= g_7[0]) , p_12), g_5)) , p_12), l_40));
            l_29 = l_41[2];
        }
    }
    l_35 &= 0x5B167D3DL;
    for (p_13 = 17; (p_13 != (-13)); p_13 = safe_sub_func_uint32_t_u_u(p_13, 3))
    { /* block id: 22 */
        int16_t l_47 = 0xA2C1L;
        int32_t l_53 = 0xDC75DF64L;
        int32_t l_54[6] = {0x376A9523L,0x376A9523L,0x376A9523L,0x376A9523L,0x376A9523L,0x376A9523L};
        int i;
        g_48++;
        l_46[3] = p_14;
        l_53 = (((safe_mod_func_int32_t_s_s(l_44, p_13)) , g_2) < p_15);
        g_56--;
    }
    --g_60;
    return l_46[3];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_18(int16_t  p_19)
{ /* block id: 4 */
    uint8_t l_26[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    int i;
    return l_26[6];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 25
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 27
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 15
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 19
XXX percentage of non-volatile access: 90

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 23
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 8
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 36.8
XXX percentage an existing variable is used: 63.2
********************* end of statistics **********************/

