/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3105455206546277055
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_4 = 0UL;
static uint16_t g_10[2] = {1UL,1UL};
static uint16_t g_12[1] = {0UL};
static int32_t g_21 = 0x9F42C60EL;
static uint32_t g_36 = 0x64F6B903L;
static uint32_t g_62 = 0xACAF8A8FL;
static uint32_t g_75[3] = {0x0B1E1499L,0x0B1E1499L,0x0B1E1499L};
static uint32_t g_79[5] = {1UL,1UL,1UL,1UL,1UL};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint64_t  func_2(uint32_t  p_3);
static uint8_t  func_6(const int32_t  p_7, uint8_t  p_8);
static int32_t  func_13(uint8_t  p_14, uint16_t  p_15, int16_t  p_16, int32_t  p_17, int32_t  p_18);
static uint64_t  func_26(uint64_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_12 g_21 g_36 g_62 g_75 g_79
 * writes: g_4 g_12 g_21 g_36 g_62 g_75 g_79
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_85 = 0x471A24E3L;
    int32_t l_98 = 0L;
lbl_87:
    g_79[0] |= ((func_2(g_4) != g_10[0]) > 0UL);
    for (g_62 = 14; (g_62 > 25); g_62++)
    { /* block id: 56 */
        uint32_t l_84 = 0x411E181FL;
        int32_t l_86 = 0L;
        if (((((((safe_rshift_func_uint16_t_u_u(g_12[0], 4)) > l_84) , l_84) >= 1UL) != l_84) <= 1UL))
        { /* block id: 57 */
            l_86 = (((((g_75[2] || g_21) != 18446744073709551615UL) , g_12[0]) < 18446744073709551611UL) && l_85);
        }
        else
        { /* block id: 59 */
            if (g_36)
                goto lbl_87;
        }
    }
    for (g_4 = 0; (g_4 < 24); g_4++)
    { /* block id: 65 */
        int16_t l_97 = 0xED8AL;
        int32_t l_101 = 0xDD85FC26L;
        l_98 = (!(safe_rshift_func_uint16_t_u_u((safe_div_func_uint32_t_u_u((((safe_mod_func_uint64_t_u_u((l_85 ^ 0x6936L), 18446744073709551615UL)) , g_10[1]) , g_4), g_12[0])), l_97)));
        l_98 = 0x8ABD3BCAL;
        for (l_98 = 0; (l_98 != (-28)); l_98 = safe_sub_func_uint64_t_u_u(l_98, 1))
        { /* block id: 70 */
            return g_4;
        }
        l_101 ^= 7L;
    }
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_12 g_21 g_36 g_62 g_75
 * writes: g_4 g_12 g_21 g_36 g_62 g_75
 */
static uint64_t  func_2(uint32_t  p_3)
{ /* block id: 1 */
    const int32_t l_9 = (-2L);
    int32_t l_78 = 0xC76156DDL;
    g_12[0] = (+func_6(l_9, l_9));
    l_78 = func_13((safe_add_func_uint8_t_u_u(g_10[1], 0x23L)), g_12[0], g_12[0], p_3, p_3);
    return g_75[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_10
 * writes: g_4
 */
static uint8_t  func_6(const int32_t  p_7, uint8_t  p_8)
{ /* block id: 2 */
    int64_t l_11 = 2L;
    for (g_4 = 0; (g_4 <= 1); g_4 += 1)
    { /* block id: 5 */
        int i;
        if (g_10[g_4])
            break;
    }
    return l_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_21 g_4 g_10 g_36 g_62 g_75
 * writes: g_21 g_36 g_4 g_62 g_75
 */
static int32_t  func_13(uint8_t  p_14, uint16_t  p_15, int16_t  p_16, int32_t  p_17, int32_t  p_18)
{ /* block id: 10 */
    int16_t l_47 = 0x6DFEL;
    int16_t l_73 = 1L;
    int32_t l_74[3][10][1] = {{{1L},{5L},{0x23F84E0FL},{5L},{1L},{0xE2E8C41CL},{0xE2E8C41CL},{1L},{5L},{0x23F84E0FL}},{{5L},{1L},{0xE2E8C41CL},{0xE2E8C41CL},{1L},{5L},{0x23F84E0FL},{5L},{1L},{0xE2E8C41CL}},{{0xE2E8C41CL},{1L},{5L},{0x23F84E0FL},{5L},{1L},{0xE2E8C41CL},{0xE2E8C41CL},{1L},{5L}}};
    int i, j, k;
    g_21 = p_17;
    for (p_16 = 0; (p_16 < (-3)); --p_16)
    { /* block id: 14 */
        l_47 |= (safe_div_func_uint16_t_u_u((func_26(g_12[0], p_18) != g_12[0]), p_18));
        p_18 &= (safe_add_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(p_14, p_16)), 1UL));
        p_17 &= ((p_18 == 0xD2BAB91EL) != p_16);
    }
    for (l_47 = (-13); (l_47 > 22); l_47 = safe_add_func_uint64_t_u_u(l_47, 1))
    { /* block id: 37 */
        uint32_t l_60 = 0x3CA5AAD5L;
        int32_t l_63 = 0xF11EAE52L;
        int32_t l_72 = 0L;
        for (p_16 = 13; (p_16 != 19); p_16 = safe_add_func_uint16_t_u_u(p_16, 6))
        { /* block id: 40 */
            int32_t l_61 = 0x764E38B1L;
            g_62 |= (((safe_mul_func_uint16_t_u_u(((((((safe_mul_func_uint16_t_u_u((p_14 > g_21), l_60)) != 18446744073709551611UL) || p_15) , g_21) , 65532UL) ^ l_61), p_15)) , 0x6D172E30E5DEFA76LL) == 18446744073709551615UL);
            if (p_16)
                break;
            l_63 = (g_10[0] <= 0x32L);
            return g_4;
        }
        g_21 &= g_4;
        l_73 = (safe_add_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_u(1UL, l_72)) , l_63), 0x64EA5F7267713999LL)), 2)), 4UL));
    }
    ++g_75[2];
    return l_74[2][6][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_12 g_4 g_10 g_36
 * writes: g_21 g_36 g_4
 */
static uint64_t  func_26(uint64_t  p_27, uint32_t  p_28)
{ /* block id: 15 */
    int64_t l_37 = 0x4BCA925F321EE01ELL;
    int32_t l_38 = 0xD7C1543FL;
    for (g_21 = 0; (g_21 >= 0); g_21 -= 1)
    { /* block id: 18 */
        int32_t l_31 = (-9L);
        int i;
        l_31 = (((safe_lshift_func_uint8_t_u_u(0x85L, 4)) ^ g_12[g_21]) ^ 0xE7L);
        g_36 = (safe_mul_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(g_12[g_21], g_4)), p_27));
    }
    l_38 = (l_37 <= 0x836EA0E4L);
    for (g_4 = 0; (g_4 != 54); g_4 = safe_add_func_uint16_t_u_u(g_4, 9))
    { /* block id: 25 */
        l_38 = (safe_add_func_uint64_t_u_u(((safe_add_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_u(0xBBL, 1)) ^ p_27), g_10[0])) >= g_21), p_27));
        return g_10[0];
    }
    l_38 = g_36;
    return p_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_75[i], "g_75[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_79[i], "g_79[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 26
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 38
   depth: 2, occurrence: 11
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 3
   depth: 7, occurrence: 3
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 71
XXX times a non-volatile is write: 30
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 42
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 16
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 29.9
XXX percentage an existing variable is used: 70.1
********************* end of statistics **********************/

