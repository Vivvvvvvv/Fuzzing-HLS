/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8311066385689713947
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_6 = 9UL;
static uint16_t g_39[7] = {0xB739L,0xD0C0L,0xB739L,0xB739L,0xD0C0L,0xB739L,0xB739L};
static int64_t g_43 = 9L;
static volatile uint64_t g_51 = 18446744073709551613UL;/* VOLATILE GLOBAL g_51 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int16_t  p_4, uint16_t  p_5);
static int32_t  func_8(int8_t  p_9);
static int8_t  func_10(int8_t  p_11);
static uint32_t  func_20(uint32_t  p_21, const uint32_t  p_22, int8_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_39 g_43
 * writes: g_6 g_39 g_43 g_51
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_7 = 0xE8C9F369L;
    int32_t l_55 = 9L;
    l_55 &= (func_2(g_6, g_6, l_7) , 0x0BF567D7L);
    return l_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_39 g_43
 * writes: g_6 g_39 g_43 g_51
 */
static int32_t  func_2(int32_t  p_3, int16_t  p_4, uint16_t  p_5)
{ /* block id: 1 */
    uint32_t l_12 = 0xE4B7834DL;
    int32_t l_54 = 0xE34605DDL;
    l_54 = func_8(func_10(l_12));
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_39 g_43
 * writes: g_6 g_39 g_43 g_51
 */
static int32_t  func_8(int8_t  p_9)
{ /* block id: 5 */
    uint32_t l_15[9] = {0x0246C382L,0x0D62E652L,0x0246C382L,0x0D62E652L,0x0246C382L,0x0D62E652L,0x0246C382L,0x0D62E652L,0x0246C382L};
    int32_t l_53 = 0x86397847L;
    int i;
    if (g_6)
    { /* block id: 6 */
lbl_50:
        l_15[0] = func_10((g_6 , p_9));
        return l_15[0];
    }
    else
    { /* block id: 9 */
        uint8_t l_42 = 252UL;
        for (g_6 = 3; (g_6 < 55); ++g_6)
        { /* block id: 12 */
            uint64_t l_44 = 0UL;
            int32_t l_47 = 0L;
            g_43 = ((safe_sub_func_uint32_t_u_u(func_20(((0x45B3659EA4D59FF4LL != p_9) != p_9), g_6, g_6), g_6)) , l_42);
            if (l_15[0])
                continue;
            l_44--;
            l_47 = l_44;
        }
        for (g_6 = 0; (g_6 != 28); g_6 = safe_add_func_uint32_t_u_u(g_6, 7))
        { /* block id: 32 */
            return l_42;
        }
        if (l_42)
            goto lbl_50;
        g_51 = 1L;
    }
    l_53 = (!g_43);
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static int8_t  func_10(int8_t  p_11)
{ /* block id: 2 */
    int32_t l_13[5] = {3L,3L,3L,3L,3L};
    int8_t l_14 = (-1L);
    int i;
    l_13[3] = (p_11 && g_6);
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_39
 * writes: g_39
 */
static uint32_t  func_20(uint32_t  p_21, const uint32_t  p_22, int8_t  p_23)
{ /* block id: 13 */
    uint32_t l_26 = 0x1031C36BL;
    int32_t l_31 = (-10L);
    l_26 = (safe_mul_func_uint16_t_u_u(0xF172L, p_23));
    if (p_23)
        goto lbl_32;
lbl_32:
    l_31 &= ((safe_mod_func_uint64_t_u_u((safe_add_func_uint32_t_u_u(g_6, g_6)), g_6)) <= g_6);
    g_39[3] = (safe_div_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((((safe_add_func_uint32_t_u_u(l_26, 0xBB5A2755L)) , p_21) < g_6), g_6)), p_22));
    for (l_26 = 0; (l_26 < 1); l_26 = safe_add_func_uint32_t_u_u(l_26, 6))
    { /* block id: 20 */
        if (g_39[2])
            break;
        l_31 &= p_22;
    }
    return g_6;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 30
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 40
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 98.2

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 8
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 34
XXX percentage an existing variable is used: 66
********************* end of statistics **********************/

