/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3339155624961634274
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_11[6] = {4L,4L,4L,4L,4L,4L};
static int16_t g_12 = 0xD697L;
static int64_t g_14[6] = {1L,0xDE9E843631E19E95LL,1L,1L,0xDE9E843631E19E95LL,1L};
static int16_t g_15 = (-6L);
static volatile uint16_t g_19 = 0x8AB9L;/* VOLATILE GLOBAL g_19 */
static int16_t g_24 = 1L;
static int32_t g_25 = 2L;


/* --- FORWARD DECLARATIONS --- */
static const int32_t  func_1(void);
static int32_t  func_2(uint32_t  p_3, uint16_t  p_4);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_19 g_15 g_14 g_11 g_24
 * writes: g_19 g_24 g_25 g_15
 */
static const int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_5 = 253UL;
    g_25 = func_2((1UL == 255UL), l_5);
    for (g_15 = (-29); (g_15 > 18); ++g_15)
    { /* block id: 13 */
        uint8_t l_31 = 0x7CL;
        for (l_5 = 0; (l_5 <= 5); l_5 += 1)
        { /* block id: 16 */
            int32_t l_28 = 0x7A68FAB8L;
            int i;
            l_28 = ((18446744073709551610UL || g_14[l_5]) && g_11[l_5]);
            l_31 = (safe_mod_func_uint16_t_u_u((g_11[l_5] <= g_24), g_11[l_5]));
        }
    }
    return l_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes: g_19 g_24
 */
static int32_t  func_2(uint32_t  p_3, uint16_t  p_4)
{ /* block id: 1 */
    int64_t l_6 = (-1L);
    int32_t l_7 = 0x7C8748AFL;
    int32_t l_8 = 3L;
    int32_t l_9 = 0x6D058A83L;
    int32_t l_10 = 0L;
    int32_t l_13 = 0x9F8D19C9L;
    int32_t l_16 = 0x14A5EA96L;
    int32_t l_17 = 0L;
    int32_t l_18 = 4L;
    --g_19;
    l_7 ^= p_4;
    for (l_16 = 0; (l_16 > (-11)); --l_16)
    { /* block id: 6 */
        g_24 = ((p_4 != 0UL) && 65532UL);
    }
    return p_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_11[i], "g_11[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 19
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 3
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 95.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 2
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 73.1
XXX percentage an existing variable is used: 26.9
********************* end of statistics **********************/

