/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4349615770472704289
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[6] = {8L,8L,8L,8L,8L,8L};
static int32_t g_16[3][7][1] = {{{(-1L)},{3L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{3L}},{{(-1L)},{3L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{3L}},{{(-1L)},{3L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{3L}}};
static volatile int32_t g_53 = (-7L);/* VOLATILE GLOBAL g_53 */
static volatile int32_t g_57[5] = {5L,5L,5L,5L,5L};
static uint32_t g_65 = 0x63943E12L;
static int32_t g_70 = 0x00147550L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint64_t  func_14(uint32_t  p_15);
static uint32_t  func_28(int16_t  p_29, int8_t  p_30, int32_t  p_31);
static int32_t  func_76(int32_t  p_77, int32_t  p_78, uint8_t  p_79, uint32_t  p_80, int16_t  p_81);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_16 g_53 g_65 g_70 g_57
 * writes: g_2 g_16 g_65 g_70
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_7 = 18446744073709551615UL;
    int8_t l_17 = 0xF9L;
    int8_t l_36[5][2] = {{0x4EL,0x3AL},{0x4EL,0x4EL},{0x3AL,0x4EL},{0x4EL,0x3AL},{0x4EL,0x4EL}};
    int32_t l_54 = (-1L);
    int32_t l_56 = 1L;
    int32_t l_58 = 0x7D1D410AL;
    int64_t l_84 = (-1L);
    int i, j;
    if (g_2[0])
    { /* block id: 1 */
        return g_2[0];
    }
    else
    { /* block id: 3 */
        int16_t l_5 = 0x836CL;
        int32_t l_18 = 0x09974082L;
        int32_t l_51 = 0x62131AC6L;
        int32_t l_52[3];
        int8_t l_55 = 0L;
        uint32_t l_59 = 0xC0C90B22L;
        int32_t l_71[6][10] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
        int i, j;
        for (i = 0; i < 3; i++)
            l_52[i] = 0xB9ACCE30L;
        if (((safe_rshift_func_uint8_t_u_u(253UL, l_5)) == g_2[1]))
        { /* block id: 4 */
            uint8_t l_6 = 0x3EL;
            l_6 = (-3L);
            g_2[1] = l_7;
            l_18 = (((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(func_14(l_7), 0UL)), l_6)) >= g_16[1][6][0]), l_17)) || g_16[1][6][0]) >= l_5);
        }
        else
        { /* block id: 11 */
            uint16_t l_25 = 0x1C58L;
            l_25 = ((safe_sub_func_uint16_t_u_u(((+(!(safe_mod_func_uint64_t_u_u(g_16[1][6][0], g_16[0][3][0])))) || 0UL), g_16[1][6][0])) , l_18);
            l_18 |= (4UL < g_2[0]);
            g_16[1][6][0] = l_5;
        }
        g_2[0] = ((safe_rshift_func_uint8_t_u_u(func_14(func_28((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(g_16[0][0][0], l_36[0][1])), l_36[0][1])), g_2[0], l_5)), l_36[0][1])) && l_36[0][1]);
        if (g_2[0])
        { /* block id: 20 */
            g_16[1][6][0] = (safe_lshift_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u((((safe_add_func_uint64_t_u_u((!((safe_mul_func_uint16_t_u_u(6UL, 0xA420L)) , g_2[0])), g_16[1][6][0])) || 18446744073709551615UL) != 65535UL), l_7)), g_16[1][6][0]));
            l_18 &= (safe_sub_func_uint16_t_u_u((g_16[2][6][0] ^ 0x04L), g_2[5]));
        }
        else
        { /* block id: 23 */
            int32_t l_49 = 0xBC5F2630L;
            int32_t l_50[6] = {7L,1L,7L,7L,1L,7L};
            int i;
            l_59--;
            l_56 = l_50[0];
            g_65 &= (safe_sub_func_uint32_t_u_u((+(((g_53 , 1UL) && l_50[0]) ^ g_16[2][3][0])), 4294967294UL));
            l_71[4][5] |= (safe_div_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u(l_54, l_49)) && g_70), 255UL));
        }
    }
    g_70 = (safe_rshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(0x9720L, l_58)) , g_53), 11));
    l_54 = func_76((safe_mod_func_uint64_t_u_u(g_57[1], 0xCC17BCF7A535ACB9LL)), l_7, g_70, g_65, l_84);
    g_2[2] &= (l_17 , g_65);
    return g_16[1][6][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static uint64_t  func_14(uint32_t  p_15)
{ /* block id: 7 */
    g_2[0] = (-1L);
    return g_2[0];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_28(int16_t  p_29, int8_t  p_30, int32_t  p_31)
{ /* block id: 16 */
    int16_t l_37 = 1L;
    l_37 = ((p_29 && 3UL) ^ 1UL);
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_53
 * writes:
 */
static int32_t  func_76(int32_t  p_77, int32_t  p_78, uint8_t  p_79, uint32_t  p_80, int16_t  p_81)
{ /* block id: 31 */
    uint32_t l_85 = 0x2485FC01L;
    p_78 = (g_53 >= 1UL);
    return l_85;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_16[i][j][k], "g_16[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_53, "g_53", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_57[i], "g_57[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 26
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 32
   depth: 2, occurrence: 3
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 40
XXX times a non-volatile is write: 15
XXX times a volatile is read: 13
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 56
XXX percentage of non-volatile access: 76.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 27
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 21.1
XXX percentage an existing variable is used: 78.9
********************* end of statistics **********************/

