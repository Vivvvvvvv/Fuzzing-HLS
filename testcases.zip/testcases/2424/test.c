/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5505572248749890921
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2 = 0x0AL;
static uint8_t g_11 = 0x41L;
static uint32_t g_12 = 0x5047C4D1L;
static int8_t g_14 = 0x3EL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_11 g_12
 * writes: g_2 g_11 g_12 g_14
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_9 = 0UL;
lbl_15:
    ++g_2;
    if (g_2)
        goto lbl_13;
lbl_13:
    for (g_2 = 0; (g_2 == 37); g_2 = safe_add_func_uint32_t_u_u(g_2, 2))
    { /* block id: 4 */
        if (g_2)
        { /* block id: 5 */
            int32_t l_10 = 0x4AA0D722L;
            l_10 = ((safe_mod_func_int16_t_s_s(0xA00FL, l_9)) ^ 255UL);
            if (g_2)
                break;
        }
        else
        { /* block id: 8 */
            g_11 ^= g_2;
            if (g_11)
                goto lbl_13;
        }
        g_12 = g_11;
    }
    g_14 = (((g_12 || g_2) ^ (-9L)) == l_9);
    if (l_9)
        goto lbl_15;
    return l_9;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 6
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 2
XXX backward jumps: 1

XXX stmts: 12
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 42.9
XXX percentage an existing variable is used: 57.1
********************* end of statistics **********************/

