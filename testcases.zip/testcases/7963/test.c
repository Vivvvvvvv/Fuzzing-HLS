/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13088846464379212267
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_31 = 0x0FL;
static uint16_t g_73 = 0xF623L;
static uint32_t g_76 = 1UL;
static int32_t g_97 = 0xEF54216EL;
static int64_t g_99[1] = {0x591E88D44B5E4FDELL};
static int16_t g_101 = 0L;
static uint32_t g_102 = 0x86933D78L;
static volatile int32_t g_129 = 0L;/* VOLATILE GLOBAL g_129 */
static uint8_t g_147[2] = {248UL,248UL};
static volatile int16_t g_149 = 0x663CL;/* VOLATILE GLOBAL g_149 */
static int64_t g_150[5][1][5] = {{{0xB1443286D5588B07LL,0x1C9B9BB54825C2B0LL,0xB1443286D5588B07LL,5L,5L}},{{0xEE7B83AFE1A9EECALL,(-1L),0xEE7B83AFE1A9EECALL,8L,8L}},{{0xB1443286D5588B07LL,0x1C9B9BB54825C2B0LL,0xB1443286D5588B07LL,5L,5L}},{{0xEE7B83AFE1A9EECALL,(-1L),0xEE7B83AFE1A9EECALL,8L,8L}},{{0xB1443286D5588B07LL,0x1C9B9BB54825C2B0LL,0xB1443286D5588B07LL,5L,5L}}};
static volatile int32_t g_151 = (-1L);/* VOLATILE GLOBAL g_151 */
static volatile int8_t g_152[5][10][5] = {{{0L,(-1L),0L,0x0EL,0xD2L},{1L,0x9BL,0xF4L,(-1L),(-1L)},{0xEBL,0x77L,0L,0xD5L,1L},{(-1L),(-1L),1L,0x20L,0x4FL},{1L,0L,0L,0x78L,0x6DL},{(-9L),0x2EL,1L,0xABL,1L},{0x4FL,0x94L,0L,0L,0x6DL},{(-7L),0xABL,0L,0L,0x4FL},{0x6DL,0L,0x78L,0xDCL,0x78L},{0xF9L,0x76L,0x3BL,0x7BL,0xF4L}},{{0x44L,1L,0L,0x78L,1L},{0x26L,0xD7L,0x15L,(-1L),0xB0L},{0x77L,1L,0L,0x02L,0x94L},{0L,0x76L,(-4L),5L,0x52L},{1L,0L,0L,1L,0xA0L},{0xF4L,0xABL,(-1L),0x76L,1L},{0x44L,0x94L,0x7AL,0xA0L,0x77L},{1L,0x2EL,0x79L,0x76L,0xB0L},{0xDCL,0L,(-1L),1L,0x4FL},{(-7L),0x20L,0xB0L,5L,0x26L}},{{1L,0xADL,1L,0x02L,0x78L},{(-1L),(-1L),(-1L),(-1L),(-9L)},{1L,0xDCL,0xADL,0x78L,0L},{(-1L),0x2EL,0x25L,0x7BL,1L},{1L,1L,0L,0xDCL,0xDCL},{(-7L),0L,(-7L),0L,(-1L)},{0xDCL,0L,0xA0L,0L,0x78L},{1L,3L,0x3BL,0xABL,0xADL},{0x44L,0x02L,0xA0L,0x78L,0x02L},{0xF4L,0xD7L,(-7L),0x20L,0xB0L}},{{1L,0x4FL,0L,0x4FL,1L},{0L,0x26L,0x25L,5L,0xF9L},{0x77L,0L,0xADL,0x77L,0xA0L},{0x26L,0x7BL,(-1L),0x26L,0xF9L},{0x44L,0x77L,1L,0xA0L,1L},{0xF9L,0x2EL,0xB0L,3L,0xB0L},{0x6DL,0x6DL,(-1L),0x94L,0x02L},{(-7L),(-1L),0x79L,5L,0xADL},{0x4FL,0xADL,0x7AL,1L,0x78L},{(-9L),(-1L),(-1L),(-1L),(-1L)}},{{1L,0x6DL,0L,0x78L,0xDCL},{0x4FL,0x2EL,(-4L),0L,0L},{0xA0L,0xADL,0L,0x7AL,0x44L},{0xDDL,0x2EL,0x1FL,0x4DL,1L},{0x44L,0x04L,0x0EL,0x7AL,0xF4L},{0L,0L,0x52L,0xD6L,0x79L},{0xD2L,0L,0xF4L,0xF4L,0L},{0xB0L,0xE7L,(-1L),0L,(-1L)},{0L,0xA0L,0L,0x78L,0xADL},{(-1L),8L,(-1L),1L,(-7L)}}};
static uint32_t g_163 = 6UL;
static int32_t g_175 = 2L;
static uint64_t g_177 = 0x1889444261DAF295LL;
static volatile int32_t g_190 = 0x50948135L;/* VOLATILE GLOBAL g_190 */
static uint32_t g_191 = 0xDBB4373CL;
static uint32_t g_199 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint32_t  func_2(int32_t  p_3, uint64_t  p_4);
static uint8_t  func_9(uint64_t  p_10, int16_t  p_11, uint32_t  p_12, int32_t  p_13, int16_t  p_14);
static uint64_t  func_15(int32_t  p_16, uint16_t  p_17, uint32_t  p_18);
static uint16_t  func_21(uint32_t  p_22, uint16_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_31 g_73 g_76 g_97 g_99 g_102 g_150 g_149 g_152 g_177 g_191 g_101 g_163
 * writes: g_73 g_76 g_97 g_99 g_102 g_147 g_163 g_175 g_177 g_191 g_199
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_19 = 0x43ACL;
    uint16_t l_198 = 65529UL;
    g_199 = (func_2(((safe_rshift_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((func_9(func_15(l_19, l_19, l_19), l_19, l_19, g_150[2][0][4], g_150[3][0][2]) > 0UL), l_19)), 1)) && 0x8EFCL), l_19) == l_198);
    return g_163;
}


/* ------------------------------------------ */
/* 
 * reads : g_97 g_191 g_101 g_99 g_163
 * writes: g_97 g_191
 */
static uint32_t  func_2(int32_t  p_3, uint64_t  p_4)
{ /* block id: 70 */
    int8_t l_185 = 6L;
    int32_t l_186 = 0x2C6849BAL;
    int32_t l_187 = 1L;
    int32_t l_188 = (-1L);
    int32_t l_189 = 0L;
    for (p_3 = 0; (p_3 == (-23)); p_3 = safe_sub_func_uint64_t_u_u(p_3, 8))
    { /* block id: 73 */
        for (g_97 = 0; (g_97 != 20); g_97++)
        { /* block id: 76 */
            uint32_t l_182 = 1UL;
            l_182--;
        }
    }
    --g_191;
    l_186 = g_191;
    l_189 = ((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((0x2D8A0161L ^ g_101), p_3)), g_99[0])) < l_186);
    return g_163;
}


/* ------------------------------------------ */
/* 
 * reads : g_152 g_177
 * writes: g_175 g_177
 */
static uint8_t  func_9(uint64_t  p_10, int16_t  p_11, uint32_t  p_12, int32_t  p_13, int16_t  p_14)
{ /* block id: 66 */
    int64_t l_176[10][6][4] = {{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL},{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL}},{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL},{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL}},{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL},{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL}},{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL},{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL}},{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL},{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL}},{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL},{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,(-2L),0x5B4DF5B9D5BC0B0CLL,0x5B4DF5B9D5BC0B0CLL},{(-2L),(-2L),0xF9B22F94FB6A1FD8LL,0x84FA4B9057EADA15LL}},{{(-2L),1L,0x5B4DF5B9D5BC0B0CLL,0x84FA4B9057EADA15LL},{1L,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL},{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL}},{{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL},{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL}},{{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL},{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL}},{{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL},{1L,0x3161055672CA53BELL,0xF9B22F94FB6A1FD8LL,0x5B4DF5B9D5BC0B0CLL},{0x3161055672CA53BELL,1L,0xF9B22F94FB6A1FD8LL,0xF9B22F94FB6A1FD8LL},{1L,1L,0x84FA4B9057EADA15LL,0x5B4DF5B9D5BC0B0CLL}}};
    int i, j, k;
    g_175 = 0x80DE7F7EL;
    g_177 ^= (g_152[0][5][0] >= l_176[8][5][1]);
    return p_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_73 g_76 g_97 g_99 g_102 g_150 g_149 g_152
 * writes: g_73 g_76 g_97 g_99 g_102 g_147 g_163
 */
static uint64_t  func_15(int32_t  p_16, uint16_t  p_17, uint32_t  p_18)
{ /* block id: 1 */
    uint32_t l_118 = 4294967295UL;
    uint64_t l_124 = 0UL;
    int32_t l_148 = 0x27EFC0AEL;
    int32_t l_153 = 0x1819652DL;
    uint8_t l_162 = 1UL;
    p_16 = (+func_21(p_17, p_17));
    if ((safe_div_func_uint8_t_u_u(((((safe_add_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(l_118, 0xE7FFL)), 5)), l_118)) >= 65533UL) == 4294967292UL), g_76)) ^ l_118) , l_118) < g_97), g_99[0])))
    { /* block id: 34 */
        int32_t l_123 = 0xCAC6B420L;
        uint32_t l_130 = 0xBC33642CL;
        if ((safe_rshift_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((l_118 != l_118), g_76)), 5)))
        { /* block id: 35 */
            l_123 = p_17;
            p_16 ^= l_124;
            p_16 &= (safe_mul_func_uint16_t_u_u(g_99[0], 0x86F9L));
        }
        else
        { /* block id: 39 */
            int32_t l_127[8][4] = {{0xF46BED5EL,0x03590CCAL,0xF46BED5EL,(-10L)},{0xF46BED5EL,(-10L),(-10L),0xF46BED5EL},{0xBEB08D42L,(-10L),0x7646EDF8L,(-10L)},{(-10L),0x03590CCAL,0x7646EDF8L,0x7646EDF8L},{0xBEB08D42L,0xBEB08D42L,(-10L),0x7646EDF8L},{0xF46BED5EL,0x03590CCAL,0xF46BED5EL,(-10L)},{0xF46BED5EL,(-10L),(-10L),0xF46BED5EL},{0xBEB08D42L,(-10L),0x7646EDF8L,(-10L)}};
            int32_t l_128 = (-1L);
            int i, j;
            l_130++;
        }
        if ((p_16 , p_17))
        { /* block id: 42 */
            uint8_t l_145 = 0x5FL;
            int32_t l_146 = 0xB199FB15L;
            int32_t l_154 = 0x945F2B69L;
            uint32_t l_155 = 0UL;
            l_146 = (safe_div_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u((safe_add_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u((0x892AB80D1030EC2ALL <= g_97), l_145)) && 0xFD36L), p_18)), g_102)) <= 5UL), g_76)), 0x6B11L)), g_31));
            g_147[1] = (p_18 && 0xE2E8L);
            --l_155;
            l_162 |= ((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(1UL, 15)), 0xC4A3L)) < 7UL);
        }
        else
        { /* block id: 47 */
            l_123 |= p_16;
        }
        l_123 = (g_73 ^ g_150[0][0][4]);
        g_163 = g_99[0];
    }
    else
    { /* block id: 52 */
        for (g_76 = 0; (g_76 != 42); g_76 = safe_add_func_uint16_t_u_u(g_76, 2))
        { /* block id: 55 */
            p_16 = (safe_rshift_func_uint8_t_u_u((!(p_17 & 0UL)), l_153));
            p_16 = (0x9BFDL < 0xC46BL);
        }
        if ((safe_mod_func_uint16_t_u_u((((safe_mod_func_uint16_t_u_u((g_149 ^ g_99[0]), p_16)) && g_152[1][8][0]) ^ g_73), g_99[0])))
        { /* block id: 59 */
            return p_17;
        }
        else
        { /* block id: 61 */
            return g_99[0];
        }
    }
    return l_153;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_73 g_76 g_97 g_99 g_102
 * writes: g_73 g_76 g_97 g_99 g_102
 */
static uint16_t  func_21(uint32_t  p_22, uint16_t  p_23)
{ /* block id: 2 */
    int32_t l_32[5][10][5] = {{{4L,0x352FB29DL,0x19195C58L,0xEABFD090L,0x19195C58L},{1L,1L,0xCBB24ADCL,0x9FACD4A7L,1L},{3L,(-5L),0x2A41536CL,1L,0xF4C6F444L},{1L,0xD8FF8CD3L,1L,0xA0CD95FFL,0x2DC71837L},{(-1L),(-5L),0L,(-3L),(-6L)},{0xC5D177CCL,1L,0xEF5F9BA4L,0xBA70A1EEL,0L},{0x199F2DC8L,0x352FB29DL,0xCB5C7460L,0xF9584830L,0xFCB6EA41L},{0L,3L,0xF4C6F444L,0xA5A165F5L,0x19195C58L},{0xF82EA917L,0xCE34AAFBL,9L,0x2DC71837L,8L},{(-7L),0x9B8DB370L,0xC5D177CCL,0x352FB29DL,0xCE34AAFBL}},{{1L,0xA5A165F5L,(-4L),0xEBE66343L,6L},{0xD33D2AFDL,0xC5D177CCL,(-4L),(-5L),6L},{0xEF5F9BA4L,1L,0xC5D177CCL,1L,5L},{0xA5A165F5L,5L,9L,0x9B8DB370L,0xEBE66343L},{0x680DD333L,0L,0xEB1F0CFAL,0L,1L},{0x6A093958L,(-1L),0x2EE72C34L,0xBA70A1EEL,5L},{0xEF5F9BA4L,0xEABFD090L,0xEABFD090L,0xEF5F9BA4L,0xEB1F0CFAL},{0x2A41536CL,1L,(-5L),5L,(-4L)},{0L,0xD8FF8CD3L,(-3L),0x2EE72C34L,(-1L)},{6L,0L,0x9FACD4A7L,5L,0x1804524BL}},{{1L,0xC5D177CCL,1L,0xEF5F9BA4L,0xBA70A1EEL},{0x680DD333L,0L,0L,0xBA70A1EEL,0x1A078351L},{(-1L),8L,(-1L),0L,(-7L)},{0x2467468EL,0xEABFD090L,6L,0x9B8DB370L,(-1L)},{0L,(-4L),0L,(-3L),0xEBE66343L},{0xEB1F0CFAL,0x2DC71837L,(-3L),0xD33D2AFDL,0xBACD6BCEL},{0x9FACD4A7L,(-1L),0xD8FF8CD3L,0xCBB24ADCL,0xBACD6BCEL},{1L,0x2467468EL,0x1804524BL,0xEF5F9BA4L,0xEBE66343L},{4L,0xEF5F9BA4L,(-1L),0L,(-1L)},{0L,(-1L),0xCE34AAFBL,0x7C3387DDL,(-7L)}},{{0xEF5F9BA4L,0xD552B890L,0x9FACD4A7L,(-5L),0x1A078351L},{3L,0xBA70A1EEL,0x36EAF0ABL,0x36EAF0ABL,0xBA70A1EEL},{0xEB1F0CFAL,0xD8FF8CD3L,9L,0xF82EA917L,0x1804524BL},{0xD8FF8CD3L,8L,4L,0xCB5C7460L,(-1L)},{0xA0CD95FFL,0x2467468EL,1L,0x9B8DB370L,(-4L)},{0xD8FF8CD3L,0L,0x6A093958L,0xEBE66343L,0xEB1F0CFAL},{0xEB1F0CFAL,0xBD8D46C6L,0xCE34AAFBL,0L,5L},{3L,0x199F2DC8L,0xD8FF8CD3L,0xC5D177CCL,1L},{0xEF5F9BA4L,0xA0CD95FFL,(-5L),0x36EAF0ABL,0xEBE66343L},{0L,6L,(-5L),0xBACD6BCEL,0x19195C58L}},{{4L,(-1L),0x680DD333L,(-5L),(-1L)},{1L,0xC5D177CCL,0xF4C6F444L,(-5L),0xA0CD95FFL},{0x9FACD4A7L,0xC5D177CCL,8L,1L,0L},{0xEB1F0CFAL,(-1L),(-1L),0xBA70A1EEL,0x29656D29L},{0L,6L,4L,4L,0L},{0x2467468EL,0xA0CD95FFL,0x36EAF0ABL,(-3L),(-4L)},{(-1L),0x199F2DC8L,0L,0xCE34AAFBL,0xCE34AAFBL},{0x680DD333L,0xBD8D46C6L,0x680DD333L,0xCB5C7460L,0xBACD6BCEL},{1L,0L,0x2EE72C34L,0xC5D177CCL,0L},{6L,0x2467468EL,0x1A078351L,1L,0xEB1F0CFAL}}};
    int32_t l_46[6][5][8] = {{{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L}},{{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L}},{{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L}},{{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L}},{{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L}},{{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L},{1L,0x73BE97B5L,0x73BE97B5L,1L,1L,0x73BE97B5L,0x73BE97B5L,1L}}};
    int32_t l_58 = (-6L);
    uint32_t l_105 = 18446744073709551615UL;
    int i, j, k;
    if ((safe_mod_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((+(p_22 <= p_22)) != 0xD73DF2EF51AE9A07LL), p_22)), g_31)), l_32[3][7][4])))
    { /* block id: 3 */
        uint8_t l_33[7][6] = {{8UL,0xF9L,255UL,8UL,255UL,0xF9L},{250UL,0xF9L,0xC9L,250UL,255UL,255UL},{0x1BL,0xF9L,0xF9L,0x1BL,255UL,0xC9L},{8UL,0xF9L,255UL,8UL,255UL,0xF9L},{250UL,0xF9L,0xC9L,250UL,255UL,255UL},{0x1BL,0xF9L,0xF9L,0x1BL,255UL,0xC9L},{8UL,0xF9L,255UL,8UL,255UL,0xF9L}};
        int i, j;
        l_33[6][0] |= 0x89A03083L;
    }
    else
    { /* block id: 5 */
        uint16_t l_42 = 7UL;
        uint32_t l_43[8][10] = {{0xC41E7D42L,0xC41E7D42L,0x6FE6C8CEL,0xCF859E22L,0x748928FFL,4UL,0UL,0xE08268A7L,1UL,0xD3B62B76L},{1UL,0UL,4UL,0xA7C888BCL,4294967292UL,0UL,0UL,3UL,1UL,0xD0C5DF97L},{0xA059E615L,0xC41E7D42L,4294967292UL,0xE562A08DL,0xD3B62B76L,0xE08268A7L,0xD3B62B76L,0xE562A08DL,4294967292UL,0xC41E7D42L},{4294967295UL,0xA7C888BCL,0UL,0xE08268A7L,4UL,0xC41E7D42L,4294967295UL,0xDF54D984L,0UL,1UL},{0x748928FFL,3UL,1UL,4294967292UL,0UL,0xC41E7D42L,4294967292UL,0xD0C5DF97L,4294967295UL,0xA059E615L},{4294967295UL,0xD353AE79L,0x7C72F714L,0xD0C5DF97L,0xE08268A7L,0xE08268A7L,0xD0C5DF97L,0x7C72F714L,0xD353AE79L,4294967295UL},{0xA059E615L,4294967295UL,0xD0C5DF97L,4294967292UL,0xC41E7D42L,0UL,4294967292UL,1UL,3UL,0x748928FFL},{1UL,0UL,0xDF54D984L,4294967295UL,0xC41E7D42L,4UL,0xE08268A7L,0UL,0xA7C888BCL,4294967295UL}};
        int64_t l_51 = 1L;
        int32_t l_59 = (-2L);
        uint64_t l_68 = 0x469C6BC52267D0ECLL;
        int i, j;
        if ((safe_add_func_uint32_t_u_u((((((safe_add_func_uint64_t_u_u((((safe_mod_func_uint64_t_u_u((safe_div_func_uint8_t_u_u(l_42, g_31)), 18446744073709551615UL)) , l_43[1][9]) < 5UL), 18446744073709551615UL)) ^ p_22) > p_22) == g_31) > l_32[3][7][4]), p_22)))
        { /* block id: 6 */
            l_46[2][2][1] = (safe_sub_func_uint8_t_u_u(g_31, 0xC1L));
            l_46[2][2][1] = (safe_lshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((0x43L < l_51) && 1UL), 0xEDC62992L)), g_31));
            l_58 &= (safe_sub_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u(((safe_mod_func_uint16_t_u_u((p_22 <= 0xECC2D12977B08CCFLL), 65535UL)) || p_22), 0x907242BEL)), g_31));
            l_59 &= (((((255UL == l_32[3][7][4]) > g_31) < g_31) != g_31) >= l_43[1][9]);
        }
        else
        { /* block id: 11 */
            uint16_t l_67 = 0x7FF7L;
            int32_t l_69 = 0xA390A414L;
            l_69 = (safe_lshift_func_uint16_t_u_u((((((+((safe_mul_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(l_67, g_31)) , p_23), g_31)) < l_67)) || g_31) ^ l_68) >= 0x1CD86053C14B3F58LL) <= p_22), 5));
            l_69 = ((safe_rshift_func_uint16_t_u_u(((l_69 == 0UL) , 0xEA71L), l_59)) <= l_46[2][2][1]);
        }
        if (p_22)
        { /* block id: 15 */
            uint8_t l_72 = 255UL;
            g_73 &= (g_31 <= l_72);
            g_76 ^= (safe_rshift_func_uint16_t_u_u((l_72 , g_31), 7));
        }
        else
        { /* block id: 18 */
            const int8_t l_95 = 6L;
            int32_t l_96 = 1L;
            g_97 = ((safe_lshift_func_uint16_t_u_u(((safe_mod_func_uint32_t_u_u((safe_div_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((safe_mod_func_uint64_t_u_u((((safe_mod_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u(l_46[0][4][2], p_23)), l_43[1][9])) , l_95), 246UL)) != l_58) || p_23), 18446744073709551615UL)) , g_73), 0x7BAE7F845CBE7429LL)), p_23)) ^ g_76), p_23)), 4294967295UL)) >= l_96), 10)) && g_73);
        }
        l_59 = 0L;
        if (l_32[3][3][4])
        { /* block id: 22 */
            uint64_t l_98 = 0x4D0EF1DBD4BE37C8LL;
            g_99[0] &= ((((0xF96B43B7L < 0xE56077E5L) , 0xD4209ED7L) , g_97) >= l_98);
            return g_31;
        }
        else
        { /* block id: 25 */
            uint8_t l_100 = 0x72L;
            l_100 = p_23;
            ++g_102;
        }
    }
    l_46[1][1][6] = 0xBA1F43B5L;
    l_105--;
    return p_22;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_99[i], "g_99[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_147[i], "g_147[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_149, "g_149", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_150[i][j][k], "g_150[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_151, "g_151", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_152[i][j][k], "g_152[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_175, "g_175", print_hash_value);
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_190, "g_190", print_hash_value);
    transparent_crc(g_191, "g_191", print_hash_value);
    transparent_crc(g_199, "g_199", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 58
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 17
breakdown:
   depth: 1, occurrence: 63
   depth: 2, occurrence: 11
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 4
   depth: 6, occurrence: 4
   depth: 10, occurrence: 2
   depth: 11, occurrence: 2
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 117
XXX times a non-volatile is write: 40
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 31
XXX percentage of non-volatile access: 98.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 56
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 12
   depth: 2, occurrence: 27

XXX percentage a fresh-made variable is used: 33
XXX percentage an existing variable is used: 67
********************* end of statistics **********************/

