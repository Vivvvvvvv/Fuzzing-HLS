/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1408606776571201326
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 2L;
static int64_t g_26 = 0x26C4F32B7B88CDF8LL;
static int16_t g_45 = 0x5761L;
static volatile int8_t g_46 = 0x40L;/* VOLATILE GLOBAL g_46 */
static const uint32_t g_47 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static const int8_t  func_1(void);
static int8_t  func_13(int32_t  p_14, const int32_t  p_15, int32_t  p_16);
static uint32_t  func_17(uint32_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_26 g_46 g_47 g_45
 * writes: g_2 g_26 g_45
 */
static const int8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_3 = 0xCDBEL;
    int32_t l_8 = 0xD00585B7L;
    --l_3;
    g_2 = l_3;
    l_8 = (safe_sub_func_int16_t_s_s((g_2 , l_3), l_3));
    for (l_3 = 0; (l_3 < 25); l_3 = safe_add_func_uint32_t_u_u(l_3, 6))
    { /* block id: 6 */
        uint64_t l_19 = 18446744073709551615UL;
        for (l_8 = (-28); (l_8 != (-26)); l_8 = safe_add_func_int16_t_s_s(l_8, 2))
        { /* block id: 9 */
            int32_t l_52[10] = {0xAF4084F7L,0L,0xA0C94A74L,0xA0C94A74L,0L,0xAF4084F7L,0L,0xA0C94A74L,0xA0C94A74L,0L};
            int i;
            l_52[3] ^= (func_13((((func_17(l_19) == g_46) > g_47) & 0x1739BB5FL), g_47, g_47) & g_47);
            g_2 = (g_45 , 1L);
        }
        g_2 = (safe_mul_func_uint8_t_u_u((((!(safe_add_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_u(((((safe_mod_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((l_19 & l_3), g_47)), l_19)), l_19)) <= g_46) == l_19) >= 0xC2C51C80F86AEFBDLL), 5)) , g_45), l_19))) >= l_8) == (-10L)), g_45));
    }
    return l_3;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_13(int32_t  p_14, const int32_t  p_15, int32_t  p_16)
{ /* block id: 36 */
    int8_t l_51 = (-1L);
    p_16 = (safe_sub_func_uint8_t_u_u((safe_unary_minus_func_uint16_t_u(l_51)), l_51));
    return l_51;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_26
 * writes: g_2 g_26 g_45
 */
static uint32_t  func_17(uint32_t  p_18)
{ /* block id: 10 */
    uint32_t l_20 = 4294967293UL;
    int32_t l_21 = 0xE10E5E53L;
lbl_37:
    l_21 = ((((p_18 || l_20) > (-1L)) , 4294967289UL) && p_18);
    g_2 = (g_2 < g_2);
    if ((safe_mod_func_uint8_t_u_u((((safe_lshift_func_uint8_t_u_s(0UL, 6)) || 0xFBL) < 65535UL), p_18)))
    { /* block id: 13 */
        int32_t l_27 = 0L;
        g_26 = g_2;
        if (g_2)
            goto lbl_28;
lbl_28:
        l_27 = (((p_18 , 18446744073709551615UL) <= g_26) < 0x3090L);
        l_27 = (((safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((p_18 == g_2), 7)), 255UL)) > p_18) , (-6L));
        l_27 ^= ((((safe_lshift_func_int8_t_s_s(p_18, 0)) != p_18) && 1UL) >= g_2);
    }
    else
    { /* block id: 19 */
        int64_t l_42 = 0x2ADE89B93B3BBBB5LL;
        for (l_20 = 26; (l_20 > 31); l_20++)
        { /* block id: 22 */
            if (p_18)
                goto lbl_37;
            l_21 = ((safe_add_func_int16_t_s_s((((safe_mul_func_uint16_t_u_u(l_42, 0xEAA4L)) < p_18) < 0x60L), 1L)) || l_21);
        }
        g_2 &= (safe_div_func_int64_t_s_s(((p_18 > l_20) <= p_18), l_20));
        l_21 = ((g_26 > g_2) | 0x1F317735L);
        if ((((g_26 <= 65535UL) , p_18) , p_18))
        { /* block id: 28 */
            l_21 = ((((0UL <= p_18) && l_42) ^ 0xE71CL) <= 1UL);
            g_45 = (p_18 != 0UL);
        }
        else
        { /* block id: 31 */
            return p_18;
        }
    }
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 27
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
   depth: 6, occurrence: 2
   depth: 9, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 59
XXX times a non-volatile is write: 21
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 97.6

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 29
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 11
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 18.2
XXX percentage an existing variable is used: 81.8
********************* end of statistics **********************/

