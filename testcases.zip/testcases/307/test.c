/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9371622718825481008
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   uint32_t  f1;
   volatile uint64_t  f2;
   volatile uint8_t  f3;
   uint32_t  f4;
   int32_t  f5;
   uint64_t  f6;
   int8_t  f7;
   uint8_t  f8;
};

struct S1 {
   int32_t  f0;
   const volatile uint32_t  f1;
   const uint8_t  f2;
   uint32_t  f3;
   const uint16_t  f4;
   volatile uint32_t  f5;
   uint8_t  f6;
   int32_t  f7;
   int32_t  f8;
   uint32_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 1L;
static volatile int8_t g_15 = 9L;/* VOLATILE GLOBAL g_15 */
static uint32_t g_17 = 0x21EBC5F9L;
static struct S1 g_44 = {0xEC37461BL,4UL,0UL,0UL,8UL,3UL,0xB8L,0xF51449BAL,0xE4A9FF1DL,0x06D673C0L};/* VOLATILE GLOBAL g_44 */
static struct S0 g_49 = {1UL,0xD07A1253L,0xDE7EBAC3F408375FLL,0x8AL,18446744073709551609UL,0xEE2CBD03L,2UL,0x1DL,0x9FL};/* VOLATILE GLOBAL g_49 */
static struct S0 g_50 = {0xE2962DE1L,0x453F4779L,0x4D42BE3C69BB0CEALL,0xF5L,1UL,0xB16E5D1CL,18446744073709551613UL,0x80L,0xAEL};/* VOLATILE GLOBAL g_50 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_5(uint32_t  p_6, uint32_t  p_7, int32_t  p_8, uint32_t  p_9, uint64_t  p_10);
static struct S0  func_20(int16_t  p_21, int32_t  p_22, uint16_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_17 g_15 g_44 g_49 g_50
 * writes: g_2 g_17
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_13[7][6][3] = {{{0x95342363L,0xB9628EAFL,0x42FF18C9L},{18446744073709551610UL,0x9B58331CL,0x7209C399L},{0xF4E55B65L,0x9B58331CL,0x01C77DCDL},{0xB9628EAFL,0xB9628EAFL,18446744073709551609UL},{18446744073709551610UL,0x4CC511ECL,0xF4E55B65L},{0xB37D0226L,0x7209C399L,1UL}},{{5UL,0xF4E55B65L,1UL},{0UL,0xB37D0226L,1UL},{0x9B58331CL,0xB30477AEL,0xF4E55B65L},{0x42FF18C9L,0x68F928D9L,18446744073709551609UL},{0x3BF118C8L,18446744073709551613UL,0x01C77DCDL},{1UL,0x01C77DCDL,0x7209C399L}},{{1UL,0x42FF18C9L,0x42FF18C9L},{0x3BF118C8L,1UL,0xA5F27A41L},{0x42FF18C9L,18446744073709551610UL,3UL},{0x9B58331CL,0x01C77DCDL,1UL},{0x01C77DCDL,0xB9628EAFL,18446744073709551612UL},{0xB30477AEL,0x01C77DCDL,1UL}},{{18446744073709551609UL,0x4CC511ECL,0xF62C4DF8L},{0xF62C4DF8L,18446744073709551610UL,0x4CC511ECL},{0xC4779D44L,5UL,0x95342363L},{18446744073709551610UL,0x68F928D9L,0x95342363L},{0x4CC511ECL,0xB89BDD77L,0x4CC511ECL},{9UL,3UL,0xF62C4DF8L}},{{0x42FF18C9L,0UL,1UL},{0xF4E55B65L,18446744073709551609UL,18446744073709551612UL},{0x3BF118C8L,18446744073709551610UL,1UL},{0xF4E55B65L,0xA5F27A41L,1UL},{0x42FF18C9L,0xB37D0226L,0xB9628EAFL},{9UL,0xC4779D44L,5UL}},{{0x4CC511ECL,18446744073709551612UL,0xA5F27A41L},{18446744073709551610UL,18446744073709551612UL,0x68F928D9L},{0xC4779D44L,0xC4779D44L,0xF4E55B65L},{0xF62C4DF8L,0xB37D0226L,18446744073709551610UL},{18446744073709551609UL,0xA5F27A41L,0x7209C399L},{0xB30477AEL,18446744073709551610UL,18446744073709551610UL}},{{0x01C77DCDL,18446744073709551609UL,0x7209C399L},{18446744073709551612UL,0UL,18446744073709551610UL},{5UL,3UL,0xF4E55B65L},{18446744073709551613UL,0xB89BDD77L,0x68F928D9L},{0x7209C399L,0x68F928D9L,0xA5F27A41L},{0x7209C399L,5UL,5UL}}};
    int32_t l_52 = (-1L);
    int i, j, k;
    for (g_2 = 0; (g_2 <= 17); g_2 = safe_add_func_int16_t_s_s(g_2, 2))
    { /* block id: 3 */
        uint16_t l_33 = 0xC4D7L;
        uint32_t l_55 = 4UL;
        if (func_5((safe_add_func_int64_t_s_s(0x0B4EF66B17B722BALL, (-1L))), l_13[4][1][1], l_13[4][1][1], g_2, g_2))
        { /* block id: 7 */
            uint16_t l_32 = 0xE82BL;
            int32_t l_51 = 3L;
            l_51 |= ((func_20((safe_mod_func_int16_t_s_s(func_5((safe_div_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(((safe_mul_func_int16_t_s_s(g_2, 0x6DAEL)) == l_13[4][1][1]), 13)), l_13[4][1][1])), g_2, l_32, l_33, g_15), 1L)), l_13[4][1][1], g_2) , g_50.f7) & g_44.f4);
            l_52 = (0UL < l_33);
        }
        else
        { /* block id: 22 */
            l_55 = (safe_lshift_func_uint8_t_u_s(l_52, g_44.f4));
            if (l_33)
                break;
            if (g_49.f4)
                break;
        }
    }
    return l_13[6][3][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_15
 * writes: g_17
 */
static int32_t  func_5(uint32_t  p_6, uint32_t  p_7, int32_t  p_8, uint32_t  p_9, uint64_t  p_10)
{ /* block id: 4 */
    int16_t l_14 = 0xBF7CL;
    int32_t l_16 = 1L;
    ++g_17;
    return g_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_44 g_17 g_49 g_50
 * writes:
 */
static struct S0  func_20(int16_t  p_21, int32_t  p_22, uint16_t  p_23)
{ /* block id: 8 */
    uint32_t l_47 = 0xD357DCCCL;
    int32_t l_48[2];
    int i;
    for (i = 0; i < 2; i++)
        l_48[i] = 4L;
    for (p_21 = 0; (p_21 > (-2)); p_21 = safe_sub_func_int32_t_s_s(p_21, 5))
    { /* block id: 11 */
        uint8_t l_45[7];
        uint8_t l_46 = 0x39L;
        int i;
        for (i = 0; i < 7; i++)
            l_45[i] = 1UL;
        if ((0xA7276463L & p_22))
        { /* block id: 12 */
            l_48[1] |= (!(((((safe_rshift_func_uint8_t_u_s(((safe_lshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((!(g_44 , l_45[1])), l_45[3])), 4)) & g_17), l_46)) & l_47) | 0x08EAF535L) , (-9L)) < 0x15D4L));
            return g_49;
        }
        else
        { /* block id: 15 */
            return g_50;
        }
    }
    return g_49;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_44.f0, "g_44.f0", print_hash_value);
    transparent_crc(g_44.f1, "g_44.f1", print_hash_value);
    transparent_crc(g_44.f2, "g_44.f2", print_hash_value);
    transparent_crc(g_44.f3, "g_44.f3", print_hash_value);
    transparent_crc(g_44.f4, "g_44.f4", print_hash_value);
    transparent_crc(g_44.f5, "g_44.f5", print_hash_value);
    transparent_crc(g_44.f6, "g_44.f6", print_hash_value);
    transparent_crc(g_44.f7, "g_44.f7", print_hash_value);
    transparent_crc(g_44.f8, "g_44.f8", print_hash_value);
    transparent_crc(g_44.f9, "g_44.f9", print_hash_value);
    transparent_crc(g_49.f0, "g_49.f0", print_hash_value);
    transparent_crc(g_49.f1, "g_49.f1", print_hash_value);
    transparent_crc(g_49.f2, "g_49.f2", print_hash_value);
    transparent_crc(g_49.f3, "g_49.f3", print_hash_value);
    transparent_crc(g_49.f4, "g_49.f4", print_hash_value);
    transparent_crc(g_49.f5, "g_49.f5", print_hash_value);
    transparent_crc(g_49.f6, "g_49.f6", print_hash_value);
    transparent_crc(g_49.f7, "g_49.f7", print_hash_value);
    transparent_crc(g_49.f8, "g_49.f8", print_hash_value);
    transparent_crc(g_50.f0, "g_50.f0", print_hash_value);
    transparent_crc(g_50.f1, "g_50.f1", print_hash_value);
    transparent_crc(g_50.f2, "g_50.f2", print_hash_value);
    transparent_crc(g_50.f3, "g_50.f3", print_hash_value);
    transparent_crc(g_50.f4, "g_50.f4", print_hash_value);
    transparent_crc(g_50.f5, "g_50.f5", print_hash_value);
    transparent_crc(g_50.f6, "g_50.f6", print_hash_value);
    transparent_crc(g_50.f7, "g_50.f7", print_hash_value);
    transparent_crc(g_50.f8, "g_50.f8", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 5
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 32
XXX times a non-volatile is write: 7
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 42.5
XXX percentage an existing variable is used: 57.5
********************* end of statistics **********************/

