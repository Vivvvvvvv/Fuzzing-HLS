/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16167285817516352193
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_2 = 253UL;/* VOLATILE GLOBAL g_2 */
static int32_t g_5 = 0xBAB0C3E5L;
static int64_t g_6 = 0L;
static volatile uint32_t g_7 = 18446744073709551613UL;/* VOLATILE GLOBAL g_7 */
static int32_t g_37 = 0x9C1F6213L;
static int32_t g_51 = 1L;
static uint32_t g_57 = 4294967295UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_10(int32_t  p_11, int8_t  p_12);
static int32_t  func_13(int32_t  p_14, const int16_t  p_15, int64_t  p_16, uint64_t  p_17);
static uint64_t  func_18(uint8_t  p_19, const uint32_t  p_20, int64_t  p_21);
static int32_t  func_24(int8_t  p_25, uint16_t  p_26, int64_t  p_27, const int32_t  p_28, uint8_t  p_29);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_7 g_5 g_6 g_37 g_57 g_51
 * writes: g_7 g_37 g_57 g_51
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_3 = 0x91F782A1L;
    int32_t l_4[9][4][4] = {{{0x87110E6BL,0xAA8E55A4L,0x2AE45661L,1L},{0xBB000E2EL,0xAA8E55A4L,0x7B47E0FAL,0xA61FC2DAL},{0x34283644L,0x82E58099L,0x82E58099L,0x34283644L},{0x87110E6BL,(-8L),0x82E58099L,1L}},{{0x34283644L,0x629AA810L,0x7B47E0FAL,0xBB000E2EL},{0xBB000E2EL,0x82E58099L,0x2AE45661L,0xBB000E2EL},{0x87110E6BL,0x629AA810L,(-8L),1L},{0xA61FC2DAL,(-8L),0x7B47E0FAL,0x34283644L}},{{0xA61FC2DAL,0x82E58099L,(-8L),0xA61FC2DAL},{0x87110E6BL,0xAA8E55A4L,0x2AE45661L,1L},{0xBB000E2EL,0xAA8E55A4L,0x7B47E0FAL,0xA61FC2DAL},{0x34283644L,0x82E58099L,0x7B47E0FAL,(-1L)}},{{(-1L),0x2AE45661L,0x7B47E0FAL,1L},{(-1L),(-8L),(-8L),1L},{1L,0x7B47E0FAL,0xDEB94592L,1L},{(-1L),(-8L),(-9L),1L}},{{0x87110E6BL,0x2AE45661L,(-8L),(-1L)},{0x87110E6BL,0x7B47E0FAL,(-9L),0x87110E6BL},{(-1L),0x82E58099L,0xDEB94592L,1L},{1L,0x82E58099L,(-8L),0x87110E6BL}},{{(-1L),0x7B47E0FAL,0x7B47E0FAL,(-1L)},{(-1L),0x2AE45661L,0x7B47E0FAL,1L},{(-1L),(-8L),(-8L),1L},{1L,0x7B47E0FAL,0xDEB94592L,1L}},{{(-1L),(-8L),(-9L),1L},{0x87110E6BL,0x2AE45661L,(-8L),(-1L)},{0x87110E6BL,0x7B47E0FAL,(-9L),0x87110E6BL},{(-1L),0x82E58099L,0xDEB94592L,1L}},{{1L,0x82E58099L,(-8L),0x87110E6BL},{(-1L),0x7B47E0FAL,0x7B47E0FAL,(-1L)},{(-1L),0x2AE45661L,0x7B47E0FAL,1L},{(-1L),(-8L),(-8L),1L}},{{1L,0x7B47E0FAL,0xDEB94592L,1L},{(-1L),(-8L),(-9L),1L},{0x87110E6BL,0x2AE45661L,(-8L),(-1L)},{0x87110E6BL,0x7B47E0FAL,(-9L),0x87110E6BL}}};
    int i, j, k;
    l_3 = ((4294967295UL || g_2) || g_2);
    --g_7;
    l_4[7][1][0] = func_10(func_13(((func_18((safe_add_func_uint32_t_u_u(g_5, g_5)), g_2, l_4[2][0][0]) || 0UL) != l_3), l_4[4][3][0], g_5, l_4[4][3][0]), g_5);
    g_37 = (l_4[4][3][0] , l_3);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_6
 * writes: g_37
 */
static int32_t  func_10(int32_t  p_11, int8_t  p_12)
{ /* block id: 23 */
    uint32_t l_75 = 18446744073709551615UL;
    g_37 = (safe_rshift_func_uint8_t_u_u(((safe_sub_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(0x62L, p_12)), g_7)) >= 0x88L), l_75));
    p_11 = (g_6 , (-1L));
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_57 g_37 g_5 g_7 g_6 g_51
 * writes: g_57 g_51
 */
static int32_t  func_13(int32_t  p_14, const int16_t  p_15, int64_t  p_16, uint64_t  p_17)
{ /* block id: 12 */
    int64_t l_46 = 0L;
    int32_t l_47 = 0x19D5A33BL;
    int32_t l_48 = 0xF01E8351L;
    int32_t l_49 = 1L;
    int32_t l_50 = 9L;
    int32_t l_52 = (-1L);
    int32_t l_53 = (-1L);
    int32_t l_54 = 0x7D1D410AL;
    int32_t l_55 = 0x5618A321L;
    int32_t l_56 = (-1L);
    int16_t l_68 = 0xF81CL;
    l_46 = (safe_div_func_uint32_t_u_u(4294967295UL, g_2));
    --g_57;
    for (p_17 = (-11); (p_17 == 7); p_17 = safe_add_func_uint32_t_u_u(p_17, 8))
    { /* block id: 17 */
        g_51 = ((safe_sub_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(g_37, p_14)), 0x63FEL)), g_5)) , g_7);
        g_51 &= (l_55 == g_6);
    }
    l_48 ^= ((((65526UL < g_57) < 255UL) , l_68) || g_51);
    return g_51;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_7 g_37
 * writes: g_37
 */
static uint64_t  func_18(uint8_t  p_19, const uint32_t  p_20, int64_t  p_21)
{ /* block id: 3 */
    int32_t l_30 = 0x675E6D99L;
    uint32_t l_31 = 0x1F04FECCL;
    int32_t l_38 = 1L;
    uint8_t l_43 = 0UL;
    l_38 = func_24(l_30, l_31, p_20, g_6, l_30);
    g_37 ^= p_21;
    l_43 &= (safe_sub_func_uint8_t_u_u(((safe_lshift_func_uint16_t_u_u(p_19, p_19)) , g_7), p_19));
    return p_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_37
 * writes: g_37
 */
static int32_t  func_24(int8_t  p_25, uint16_t  p_26, int64_t  p_27, const int32_t  p_28, uint8_t  p_29)
{ /* block id: 4 */
    int64_t l_36 = 1L;
    l_36 = (safe_rshift_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u(0xD345464CL, p_28)) != 0xD967AAC3BC5F2630LL) , g_7), 3));
    g_37 |= (l_36 == p_29);
    return p_29;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 26
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 38
XXX times a non-volatile is write: 16
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 31
XXX percentage of non-volatile access: 84.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 22
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 32.1
XXX percentage an existing variable is used: 67.9
********************* end of statistics **********************/

