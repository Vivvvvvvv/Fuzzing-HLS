/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6495965735546716916
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_7[10] = {0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L,0x20E32CF4L};
static uint8_t g_19 = 0x3BL;
static uint64_t g_34 = 0x06A9BEBB6F2BA10FLL;
static uint32_t g_43 = 0x01F903A7L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_8(uint16_t  p_9);
static uint16_t  func_10(const int32_t  p_11, uint8_t  p_12, const int64_t  p_13, uint32_t  p_14, int32_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes: g_7 g_19 g_34 g_43
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_6 = 0x3248C66F5A9C4C8DLL;
    g_7[7] = (safe_add_func_int16_t_s_s(((((safe_mul_func_int8_t_s_s(l_6, l_6)) , 0xF8F0L) && 9UL) > (-1L)), 0x17B8L));
    g_34 = func_8(func_10((((safe_sub_func_int32_t_s_s(((l_6 && 0xD5BEFA1E1C5A3D7FLL) , g_7[7]), g_7[5])) ^ 5L) & g_7[7]), l_6, l_6, g_7[7], l_6));
    g_43 = (safe_add_func_int8_t_s_s((safe_sub_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_div_func_uint32_t_u_u((g_7[9] < g_7[6]), g_7[2])), 2)), 0x77F0L)), 0x61L));
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes:
 */
static int32_t  func_8(uint16_t  p_9)
{ /* block id: 7 */
    const uint16_t l_31[10] = {0xAB39L,0xAB39L,65535UL,0xAB39L,0xAB39L,65535UL,0xAB39L,0xAB39L,65535UL,0xAB39L};
    int32_t l_32 = 0x8BA79672L;
    uint32_t l_33 = 0xF3F07903L;
    int i;
    l_32 = (p_9 != l_31[9]);
    l_32 ^= (l_31[1] > 4294967295UL);
    l_32 |= l_33;
    return g_7[9];
}


/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes: g_19
 */
static uint16_t  func_10(const int32_t  p_11, uint8_t  p_12, const int64_t  p_13, uint32_t  p_14, int32_t  p_15)
{ /* block id: 2 */
    uint8_t l_18 = 0x20L;
    int32_t l_30 = 5L;
    l_18 = (((p_13 , p_12) < 0x51FAL) , g_7[6]);
    g_19 = (0x0866L > 0x3FE6L);
    l_30 ^= (safe_add_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_s(((safe_add_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_s(((safe_mod_func_uint8_t_u_u(l_18, p_12)) || 0L), 4)) < p_14), l_18)) <= p_13), 0)) & 0x13L), l_18));
    return l_30;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 3
   depth: 4, occurrence: 1
   depth: 6, occurrence: 2
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 29
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 12

XXX percentage a fresh-made variable is used: 26.3
XXX percentage an existing variable is used: 73.7
********************* end of statistics **********************/

