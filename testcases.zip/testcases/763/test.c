/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6136195443918078909
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int16_t  f0;
   int64_t  f1;
   int32_t  f2;
   int16_t  f3;
   uint32_t  f4;
   int64_t  f5;
   int8_t  f6;
   int32_t  f7;
};

struct S1 {
   uint64_t  f0;
   uint8_t  f1;
   uint32_t  f2;
   uint8_t  f3;
   struct S0  f4;
   int16_t  f5;
   int32_t  f6;
   uint32_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_2[3][8] = {{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L,0L,0L}};
static struct S1 g_4 = {18446744073709551612UL,5UL,0UL,0xFFL,{0xE584L,1L,0xCB667F5AL,2L,18446744073709551615UL,0x96A0B59785734CB4LL,0x17L,-8L},0xE404L,0L,18446744073709551615UL};/* VOLATILE GLOBAL g_4 */


/* --- FORWARD DECLARATIONS --- */
static struct S1  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4
 * writes:
 */
static struct S1  func_1(void)
{ /* block id: 0 */
    uint16_t l_3 = 65531UL;
    l_3 = (g_2[0][6] >= 0x92280643B8A277EBLL);
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4.f0, "g_4.f0", print_hash_value);
    transparent_crc(g_4.f1, "g_4.f1", print_hash_value);
    transparent_crc(g_4.f2, "g_4.f2", print_hash_value);
    transparent_crc(g_4.f3, "g_4.f3", print_hash_value);
    transparent_crc(g_4.f4.f0, "g_4.f4.f0", print_hash_value);
    transparent_crc(g_4.f4.f1, "g_4.f4.f1", print_hash_value);
    transparent_crc(g_4.f4.f2, "g_4.f4.f2", print_hash_value);
    transparent_crc(g_4.f4.f3, "g_4.f4.f3", print_hash_value);
    transparent_crc(g_4.f4.f4, "g_4.f4.f4", print_hash_value);
    transparent_crc(g_4.f4.f5, "g_4.f4.f5", print_hash_value);
    transparent_crc(g_4.f4.f6, "g_4.f4.f6", print_hash_value);
    transparent_crc(g_4.f4.f7, "g_4.f4.f7", print_hash_value);
    transparent_crc(g_4.f5, "g_4.f5", print_hash_value);
    transparent_crc(g_4.f6, "g_4.f6", print_hash_value);
    transparent_crc(g_4.f7, "g_4.f7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 0
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 2
   depth: 2, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 1
XXX times a non-volatile is write: 1
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 66.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 100
XXX percentage an existing variable is used: 0
********************* end of statistics **********************/

