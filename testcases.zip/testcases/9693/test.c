/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16549393114792308200
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_5[4] = {255UL,255UL,255UL,255UL};
static uint64_t g_44[3][3][7] = {{{0UL,0x058B506EE4F120B2LL,0xE4340421A16747B1LL,0x11659018101BC642LL,0x8791B167519BA600LL,6UL,6UL},{0x058B506EE4F120B2LL,0UL,0x923F8C0E5C5CC99CLL,0UL,0x058B506EE4F120B2LL,6UL,0xAEB9D3763964E48CLL},{0xE7FB108F98093AF8LL,0UL,18446744073709551609UL,0x8791B167519BA600LL,0xE4340421A16747B1LL,0x7D3E67B33DF123EFLL,0UL}},{{18446744073709551613UL,0xE1E3C1DC0AC77ACALL,0x32DC1B2D863E3202LL,0xF5D3CC114FF6A91ALL,0x20CF68020C2888A0LL,18446744073709551613UL,18446744073709551610UL},{0xE7FB108F98093AF8LL,0x8791B167519BA600LL,18446744073709551613UL,18446744073709551609UL,18446744073709551610UL,18446744073709551609UL,18446744073709551613UL},{0x058B506EE4F120B2LL,0x058B506EE4F120B2LL,18446744073709551613UL,0xB05D09421A0E57C1LL,0xAEB9D3763964E48CLL,0x47D05199242039CELL,6UL}},{{0xAEB9D3763964E48CLL,0x005767A065BBD97CLL,0x603F559CDE89C674LL,0xE7FB108F98093AF8LL,18446744073709551613UL,0xE4340421A16747B1LL,0xC80EABF554C62B41LL},{0x923F8C0E5C5CC99CLL,0UL,0x32DC1B2D863E3202LL,0x005767A065BBD97CLL,0xE7FB108F98093AF8LL,0x11659018101BC642LL,0UL},{0x7D3E67B33DF123EFLL,0x058B506EE4F120B2LL,18446744073709551610UL,18446744073709551610UL,0x058B506EE4F120B2LL,0x7D3E67B33DF123EFLL,0UL}}};
static uint32_t g_47 = 3UL;
static uint32_t g_48 = 0xC4F31BC4L;
static volatile uint16_t g_55 = 0x74CAL;/* VOLATILE GLOBAL g_55 */
static int32_t g_60 = (-1L);
static int32_t g_63 = 0xC685B35AL;
static uint16_t g_65 = 0x7566L;
static uint32_t g_66 = 18446744073709551608UL;
static int64_t g_67 = (-5L);
static int16_t g_74 = 0xECF3L;
static volatile int32_t g_77[4][4] = {{0x72B8ADFEL,0x6D3DFDFBL,0x72B8ADFEL,0x6D3DFDFBL},{0x72B8ADFEL,0x6D3DFDFBL,0x72B8ADFEL,0x6D3DFDFBL},{0x72B8ADFEL,0x6D3DFDFBL,0x72B8ADFEL,0x6D3DFDFBL},{0x72B8ADFEL,0x6D3DFDFBL,0x72B8ADFEL,0x6D3DFDFBL}};
static int32_t g_87 = 0x198232C3L;
static int32_t g_88 = 0xF4830711L;
static volatile int32_t g_89 = (-1L);/* VOLATILE GLOBAL g_89 */
static int32_t g_94 = 0x32462667L;
static volatile uint16_t g_96 = 65528UL;/* VOLATILE GLOBAL g_96 */
static volatile int32_t g_108 = (-1L);/* VOLATILE GLOBAL g_108 */
static volatile uint32_t g_113 = 0UL;/* VOLATILE GLOBAL g_113 */
static volatile uint8_t g_116 = 0UL;/* VOLATILE GLOBAL g_116 */
static uint8_t g_130 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const int32_t  func_2(uint32_t  p_3, uint64_t  p_4);
static uint8_t  func_7(int8_t  p_8, int32_t  p_9, uint32_t  p_10, uint32_t  p_11, int64_t  p_12);
static uint8_t  func_15(int64_t  p_16);
static uint16_t  func_25(int64_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_47 g_44 g_55 g_60 g_48 g_65 g_77 g_66 g_96 g_87 g_67 g_94 g_113 g_116 g_108 g_63 g_130
 * writes: g_44 g_48 g_55 g_60 g_63 g_65 g_66 g_67 g_74 g_77 g_87 g_96 g_113 g_116 g_108 g_130
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_6 = 0x8256L;
    int32_t l_133 = 0x1142F3EDL;
    l_133 = func_2(g_5[2], l_6);
    return l_133;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_47 g_44 g_55 g_60 g_48 g_65 g_77 g_66 g_96 g_87 g_67 g_94 g_113 g_116 g_108 g_63 g_130
 * writes: g_44 g_48 g_55 g_60 g_63 g_65 g_66 g_67 g_74 g_77 g_87 g_96 g_113 g_116 g_108 g_130
 */
static const int32_t  func_2(uint32_t  p_3, uint64_t  p_4)
{ /* block id: 1 */
    uint32_t l_13 = 0xD94B4B13L;
    int32_t l_99 = 0xDA393972L;
    int32_t l_109 = 0x88EED364L;
    l_99 = (func_7(l_13, g_5[2], g_5[2], p_4, l_13) || 0xE2L);
    for (g_67 = 0; (g_67 <= 2); g_67 += 1)
    { /* block id: 50 */
        int64_t l_107 = 0x5121EC5D866FAEDDLL;
        int32_t l_110[1];
        int i;
        for (i = 0; i < 1; i++)
            l_110[i] = 0L;
        if (((safe_mod_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(1UL, p_3)) && g_77[0][0]), g_44[2][1][0])) != p_4))
        { /* block id: 51 */
            uint8_t l_106 = 0UL;
            int32_t l_111 = 0xFF9C57FFL;
            int32_t l_112 = 0xC10F06FBL;
            g_87 = (((((((safe_mod_func_uint16_t_u_u(g_94, g_5[2])) < g_60) ^ p_4) != p_4) , l_106) , p_4) , l_107);
            --g_113;
            --g_116;
        }
        else
        { /* block id: 55 */
            g_108 &= ((safe_mul_func_uint8_t_u_u(g_60, g_87)) ^ 0xB2B09B68L);
            g_108 = (safe_sub_func_uint8_t_u_u((+l_109), g_55));
            g_87 = (!g_63);
            return g_77[2][2];
        }
        for (g_63 = 0; (g_63 <= 2); g_63 += 1)
        { /* block id: 63 */
            int32_t l_129 = 0xA5B394F6L;
            g_87 = (safe_add_func_uint64_t_u_u((safe_div_func_uint32_t_u_u(0x172F119EL, g_116)), p_3));
            ++g_130;
            return p_3;
        }
    }
    l_109 |= (l_13 < l_99);
    return g_94;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_47 g_44 g_55 g_60 g_48 g_65 g_77 g_66 g_96 g_87
 * writes: g_44 g_48 g_55 g_60 g_63 g_65 g_66 g_67 g_74 g_77 g_87 g_96
 */
static uint8_t  func_7(int8_t  p_8, int32_t  p_9, uint32_t  p_10, uint32_t  p_11, int64_t  p_12)
{ /* block id: 2 */
    uint32_t l_14[1][7] = {{0x9C25B054L,0UL,0UL,0x9C25B054L,0UL,0UL,0x9C25B054L}};
    int64_t l_85 = 0x18FFE4DFDC5D4999LL;
    int32_t l_86 = 1L;
    int32_t l_90 = 1L;
    int32_t l_91 = 0xD8B2F8DCL;
    int32_t l_92 = (-7L);
    int32_t l_93[4][2] = {{1L,1L},{1L,1L},{1L,1L},{1L,1L}};
    int32_t l_95 = 0xB6F1E529L;
    int i, j;
    if ((3UL > l_14[0][2]))
    { /* block id: 3 */
        int32_t l_75 = 0x9F6C9230L;
        int32_t l_76 = 0x48C15133L;
        l_76 = (func_15(g_5[3]) != l_75);
        g_77[2][0] |= 0x0A77380AL;
        for (g_66 = 16; (g_66 != 34); g_66 = safe_add_func_uint8_t_u_u(g_66, 9))
        { /* block id: 37 */
            l_86 = (safe_add_func_uint64_t_u_u((safe_mod_func_uint8_t_u_u((!g_77[2][0]), l_85)), p_9));
            l_76 &= p_12;
        }
        l_86 = (l_75 < 0xBBL);
    }
    else
    { /* block id: 42 */
        g_87 = l_86;
    }
    g_96--;
    return g_87;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_47 g_44 g_55 g_60 g_48 g_65
 * writes: g_44 g_48 g_55 g_60 g_63 g_65 g_66 g_67 g_74
 */
static uint8_t  func_15(int64_t  p_16)
{ /* block id: 4 */
    uint32_t l_31[2];
    int i;
    for (i = 0; i < 2; i++)
        l_31[i] = 4294967286UL;
    g_74 = (safe_mod_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(func_25((safe_div_func_uint32_t_u_u(((((((((safe_mul_func_uint16_t_u_u(1UL, 0x2E80L)) ^ 65535UL) && g_5[2]) == g_5[0]) != l_31[1]) && g_5[0]) ^ 0x846B51F0EF2F37FCLL) , 0x3D4752E4L), 0xC4EB0A11L))), p_16)), g_47)) && g_65), l_31[1])), g_5[1]));
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_47 g_44 g_55 g_60 g_48
 * writes: g_44 g_48 g_55 g_60 g_63 g_65 g_66 g_67
 */
static uint16_t  func_25(int64_t  p_26)
{ /* block id: 5 */
    const int64_t l_43 = 1L;
    int32_t l_54 = 1L;
    int64_t l_72 = (-1L);
    int32_t l_73 = 0xBBF13354L;
    if ((g_5[3] || 1UL))
    { /* block id: 6 */
        int32_t l_32 = 0L;
        l_32 |= ((g_5[2] != p_26) , g_5[0]);
        for (l_32 = 1; (l_32 <= 22); l_32++)
        { /* block id: 10 */
            uint8_t l_39 = 0UL;
            int32_t l_40 = 9L;
            l_40 = ((safe_sub_func_uint16_t_u_u((((safe_lshift_func_uint16_t_u_u(g_5[2], g_5[1])) && l_39) == 4294967295UL), g_5[2])) && p_26);
        }
        for (p_26 = (-9); (p_26 <= (-9)); ++p_26)
        { /* block id: 15 */
            int64_t l_53 = 0x03350090E7AF8257LL;
            g_44[2][1][0] = (p_26 || l_43);
            g_48 = (((((safe_rshift_func_uint16_t_u_u(g_47, 9)) <= 0x791A13C5L) < g_5[3]) , g_5[1]) == g_5[2]);
            l_53 &= (safe_mod_func_uint16_t_u_u((((safe_add_func_uint8_t_u_u(((((g_5[2] == 0xE9L) != p_26) > g_44[0][1][2]) , p_26), p_26)) && 0x359916A5C54CD8D2LL) , 0xD735L), p_26));
            if (g_5[2])
                break;
        }
        g_55++;
    }
    else
    { /* block id: 22 */
        int64_t l_64 = 0x3FE27FCE2E6445A0LL;
        g_60 |= (safe_add_func_uint8_t_u_u(1UL, p_26));
        g_63 = ((safe_add_func_uint32_t_u_u(g_5[2], p_26)) <= 0x7642L);
        g_65 = l_64;
    }
    g_66 = 0L;
    g_67 = (((0x7153L ^ 0UL) , g_60) , l_54);
    l_73 &= (((((safe_mod_func_uint64_t_u_u((((safe_sub_func_uint16_t_u_u(l_43, g_55)) >= g_60) ^ l_72), g_48)) <= 0x6C4CL) < 0xDD0FL) , l_54) == l_43);
    return p_26;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_44[i][j][k], "g_44[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_77[i][j], "g_77[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 52
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 50
   depth: 2, occurrence: 12
   depth: 3, occurrence: 7
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 87
XXX times a non-volatile is write: 29
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 48
XXX percentage of non-volatile access: 89.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 47
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 14
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 34
XXX percentage an existing variable is used: 66
********************* end of statistics **********************/

