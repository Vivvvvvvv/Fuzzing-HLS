/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2856584271949105924
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_6[6][5][7] = {{{0x05B40194L,0x3DD972C4L,(-1L),0xCEEF9A85L,0x737A9A97L,(-1L),0L},{(-4L),0x5D367296L,1L,0x1B32E265L,(-1L),0x38EB16E2L,4L},{0x6BA47C9DL,0L,0x3AF72B57L,0x76E1EE67L,0x3AF72B57L,0L,0x6BA47C9DL},{0x3380EE91L,(-7L),0x80DB959CL,0xA5B04204L,4L,0L,0x23EDB395L},{1L,0x76E1EE67L,1L,0x737A9A97L,0x83C8FC55L,0L,1L}},{{(-1L),0x23EDB395L,0x80DB959CL,(-1L),0xB2391CB4L,0x9ADB8213L,3L},{0x05B40194L,0x66C1932EL,0x3AF72B57L,0x3AF72B57L,0xB8F5F499L,0x4D2B5F79L,0L},{0xB2391CB4L,0x7822E6E7L,(-7L),0xCC2FDCBAL,0x9ADB8213L,(-7L),0x23EDB395L},{0xB8F5F499L,0L,5L,0x3AF72B57L,0xA61940C9L,0xCB5AF9F7L,0x3AF72B57L},{0xEE7D214CL,0x7822E6E7L,0xB2AEE5A9L,(-1L),0x80DB959CL,4L,4L}},{{0x9BF5E4D8L,0xB8F5F499L,1L,0xB8F5F499L,0x9BF5E4D8L,0x76E1EE67L,0x05B40194L},{0x3380EE91L,4L,(-1L),0x9ADB8213L,8L,1L,0x3380EE91L},{(-1L),0x64BA8B35L,0L,0xA61940C9L,0x05B40194L,0x3EDFA831L,1L},{0x3380EE91L,0x9ADB8213L,(-1L),0x80DB959CL,0L,(-7L),0L},{0x9BF5E4D8L,1L,1L,0x9BF5E4D8L,0x3EDFA831L,(-1L),(-1L)}},{{0xEE7D214CL,0xA5B04204L,(-4L),8L,0xA5B04204L,(-1L),1L},{0xB8F5F499L,0L,1L,0x05B40194L,(-1L),1L,(-1L)},{0xB2391CB4L,1L,0xEE7D214CL,0L,8L,8L,0L},{0x4D2B5F79L,0x9BF5E4D8L,0x4D2B5F79L,0x3EDFA831L,0L,1L,1L},{0x23EDB395L,0xB2391CB4L,(-7L),0xA5B04204L,0x7822E6E7L,(-1L),0x3380EE91L}},{{0x05B40194L,1L,0xCB5AF9F7L,(-1L),0xA61940C9L,1L,0x05B40194L},{0xB2AEE5A9L,0xCC2FDCBAL,4L,8L,0x3380EE91L,8L,4L},{(-1L),(-1L),0x76E1EE67L,0L,0xCEEF9A85L,1L,0x3AF72B57L},{0x7822E6E7L,4L,1L,0x7822E6E7L,(-1L),(-1L),0x23EDB395L},{0x4D2B5F79L,0xCEEF9A85L,0x3EDFA831L,0xA61940C9L,0xCEEF9A85L,(-1L),0L}},{{0xA5B04204L,0x80DB959CL,(-7L),0x3380EE91L,0x3380EE91L,(-7L),0x80DB959CL},{0x3AF72B57L,0L,(-1L),0xCEEF9A85L,0xA61940C9L,0x3EDFA831L,0xCEEF9A85L},{0xEE7D214CL,0x23EDB395L,(-1L),(-1L),0x7822E6E7L,1L,4L},{(-1L),0x3AF72B57L,1L,0xCEEF9A85L,0L,0x76E1EE67L,(-1L)},{0xCC2FDCBAL,4L,8L,0x3380EE91L,8L,4L,0xCC2FDCBAL}}};
static volatile int64_t g_45 = 0xBE98DEB2300A9085LL;/* VOLATILE GLOBAL g_45 */
static uint64_t g_64[4] = {18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL};
static uint8_t g_67 = 1UL;
static volatile uint32_t g_164 = 0xC1667867L;/* VOLATILE GLOBAL g_164 */
static const uint32_t g_174 = 0x057B354AL;
static int32_t g_198 = 0x82F8B99FL;
static int8_t g_206 = (-4L);
static uint8_t g_229[5] = {248UL,248UL,248UL,248UL,248UL};
static volatile int8_t g_261 = 0xA4L;/* VOLATILE GLOBAL g_261 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int32_t  p_4);
static uint64_t  func_9(uint32_t  p_10, uint16_t  p_11, int16_t  p_12);
static uint32_t  func_19(int32_t  p_20, uint32_t  p_21);
static uint64_t  func_25(int16_t  p_26, int32_t  p_27, int32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_45 g_64 g_67 g_164 g_174 g_198 g_206 g_229
 * writes: g_64 g_67 g_6 g_164 g_198 g_206 g_229
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_5 = 0xDB505206L;
    int32_t l_235 = 0x43FC71EBL;
    int8_t l_236[3][7][7] = {{{0x92L,0xE1L,0L,0L,7L,(-1L),(-7L)},{0x9FL,0L,(-8L),0xA9L,1L,(-1L),2L},{0xF0L,0x30L,1L,(-1L),1L,1L,(-7L)},{(-1L),1L,0x87L,0x15L,(-1L),(-1L),0x9FL},{(-2L),2L,0x9FL,1L,(-1L),(-1L),1L},{(-1L),0L,0L,0x15L,(-1L),0xA9L,0xA9L},{7L,1L,0x53L,1L,7L,0L,0x9FL}},{{(-8L),(-1L),(-1L),(-1L),0L,1L,(-1L)},{2L,(-1L),0x30L,0x8BL,0L,2L,0xE1L},{(-8L),(-1L),(-1L),(-1L),1L,(-1L),(-1L)},{7L,7L,2L,(-1L),0x9FL,(-1L),0L},{(-1L),0L,0L,0xABL,0L,2L,(-1L)},{(-2L),0L,1L,0xDEL,0x9FL,0x39L,0L},{(-1L),1L,0x6FL,0x6FL,1L,(-1L),0L}},{{0x39L,0x9FL,0xDEL,1L,0L,(-2L),0xF0L},{2L,0L,0xABL,0L,0L,(-1L),0xA9L},{(-1L),0x9FL,(-1L),2L,7L,7L,2L},{(-1L),1L,(-1L),(-1L),(-1L),(-8L),1L},{2L,0L,0x8BL,0x30L,(-1L),2L,0x92L},{1L,0L,(-1L),(-1L),(-1L),(-8L),0xABL},{0L,7L,1L,0x53L,1L,7L,0L}}};
    int32_t l_238 = 0x89151E2CL;
    int8_t l_247 = 0xBDL;
    int32_t l_248 = 0x2C08282AL;
    int32_t l_252 = 0xE44F534FL;
    uint32_t l_254[6];
    int32_t l_257 = 0x5523CCB4L;
    int64_t l_259 = 0x953933E596526118LL;
    int16_t l_260[3][1][4] = {{{0x5D7CL,0x5D7CL,0x5D7CL,0x5D7CL}},{{0x5D7CL,0x5D7CL,0x5D7CL,0x5D7CL}},{{0x5D7CL,0x5D7CL,0x5D7CL,0x5D7CL}}};
    int32_t l_262 = (-7L);
    int32_t l_263 = 1L;
    int32_t l_264 = (-1L);
    uint8_t l_265 = 249UL;
    uint16_t l_268 = 65535UL;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_254[i] = 0xDDEFED59L;
    g_229[4] ^= func_2(l_5, g_6[1][0][3]);
    l_235 = (((+(safe_sub_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u(l_5, 255UL)), l_5))) ^ g_6[1][0][3]) > 18446744073709551612UL);
    for (g_67 = 0; (g_67 <= 3); g_67 += 1)
    { /* block id: 108 */
        int8_t l_237[5][2];
        int32_t l_239 = (-9L);
        int32_t l_245 = (-2L);
        int64_t l_246 = 0xA31B5F08C032CB9FLL;
        int32_t l_253 = 7L;
        int32_t l_258[8] = {0xAA11DC3BL,(-1L),0xAA11DC3BL,0xAA11DC3BL,(-1L),0xAA11DC3BL,0xAA11DC3BL,(-1L)};
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 2; j++)
                l_237[i][j] = 4L;
        }
        g_198 |= g_64[2];
        if (l_5)
        { /* block id: 110 */
            l_235 = ((g_45 <= l_236[1][0][3]) != 0UL);
            l_237[4][0] |= g_229[4];
            g_6[2][1][4] = 0L;
        }
        else
        { /* block id: 114 */
            uint64_t l_240 = 0xD16C8E1A1BED76A3LL;
            int32_t l_243 = (-1L);
            int32_t l_244 = (-10L);
            int32_t l_249 = 0x60146208L;
            int32_t l_250 = 0x84264799L;
            int32_t l_251 = 0x3310F7C1L;
            g_6[1][0][3] = g_229[4];
            l_240--;
            l_254[3]++;
        }
        l_252 = (-3L);
        l_265--;
        for (l_246 = 3; (l_246 >= 0); l_246 -= 1)
        { /* block id: 123 */
            if (l_265)
                break;
        }
    }
    return l_268;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_45 g_64 g_67 g_164 g_174 g_198 g_206
 * writes: g_64 g_67 g_6 g_164 g_198 g_206
 */
static int32_t  func_2(int32_t  p_3, int32_t  p_4)
{ /* block id: 1 */
    int32_t l_13 = 0x58CDC14CL;
    int32_t l_215 = 0x7803D3D6L;
    uint16_t l_228 = 65534UL;
    g_206 ^= ((safe_lshift_func_uint16_t_u_u((func_9(l_13, g_6[1][0][3], l_13) && 1UL), l_13)) >= g_174);
    for (l_13 = 0; (l_13 == (-19)); l_13 = safe_sub_func_uint8_t_u_u(l_13, 7))
    { /* block id: 99 */
        l_215 = (safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((p_4 > p_4), p_3)), g_206)), l_13));
    }
    l_13 = (safe_add_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(p_3, p_4)), 1UL)), g_206)), 4UL)) , 0UL), 3)) == l_228), 0x0AE8L));
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_45 g_64 g_67 g_164 g_174 g_198
 * writes: g_64 g_67 g_6 g_164 g_198
 */
static uint64_t  func_9(uint32_t  p_10, uint16_t  p_11, int16_t  p_12)
{ /* block id: 2 */
    int32_t l_16 = 2L;
    int32_t l_175 = 0xB8C824B9L;
    uint16_t l_179 = 1UL;
    int32_t l_202 = 0xE4403DE6L;
    uint8_t l_203[10] = {0x8EL,0x39L,252UL,0x39L,0x8EL,0x8EL,0x39L,252UL,0x39L,0x8EL};
    int i;
    l_16 ^= (safe_sub_func_uint16_t_u_u(0xDB51L, p_12));
    l_175 = (((safe_mod_func_uint8_t_u_u(((func_19((p_12 != 0x394AL), p_12) , l_16) ^ g_174), 1UL)) , 252UL) > g_174);
    if (p_10)
    { /* block id: 71 */
        uint32_t l_176 = 1UL;
        int32_t l_180 = 1L;
        l_176 = p_12;
        l_180 = (safe_mod_func_uint8_t_u_u(((p_11 ^ 18446744073709551615UL) == l_176), l_179));
        l_175 = l_176;
    }
    else
    { /* block id: 75 */
        uint32_t l_186 = 0xD836B3EBL;
        volatile int32_t l_187 = 0xB9C2B1DAL;/* VOLATILE GLOBAL l_187 */
        if (((0x31099B1EL <= l_175) || p_10))
        { /* block id: 76 */
            uint32_t l_181 = 0x4B50EF8EL;
            --l_181;
            l_186 = (((safe_rshift_func_uint8_t_u_u(((l_179 , g_67) || g_67), 6)) ^ 0xF91F7841CAC8D62DLL) , 1L);
            l_187 = g_164;
            l_187 = (((p_10 && p_10) && g_174) && 0x2CL);
        }
        else
        { /* block id: 81 */
            uint64_t l_191 = 18446744073709551615UL;
            l_187 = (safe_sub_func_uint32_t_u_u((!(((l_16 > p_12) , 0L) , g_64[2])), 0x2C72399DL));
            --l_191;
            g_6[1][0][3] = ((safe_rshift_func_uint16_t_u_u((((g_174 , 0x5AB4L) , 0x09L) , 0xA7C9L), 9)) == 5UL);
        }
        if ((((0x5B17L != p_12) , l_187) == p_12))
        { /* block id: 86 */
            l_175 |= g_6[2][0][4];
            g_198 |= (safe_div_func_uint8_t_u_u(g_6[1][4][4], p_12));
        }
        else
        { /* block id: 89 */
            uint64_t l_199 = 18446744073709551608UL;
            l_199--;
            l_175 = p_12;
        }
        ++l_203[6];
    }
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_45 g_64 g_67 g_164
 * writes: g_64 g_67 g_6 g_164
 */
static uint32_t  func_19(int32_t  p_20, uint32_t  p_21)
{ /* block id: 4 */
    uint16_t l_29[9][2] = {{0xDD1FL,65528UL},{0x8D40L,5UL},{0x8D40L,65528UL},{0xDD1FL,0x8D40L},{65528UL,5UL},{0xEF10L,0xEF10L},{0xDD1FL,0xEF10L},{0xEF10L,5UL},{65528UL,0x8D40L}};
    int32_t l_72[1];
    int32_t l_83[6][10][4] = {{{3L,0xF5B55EC7L,0x04533268L,(-1L)},{(-1L),0x496710E1L,0L,0xF5B55EC7L},{0xC28B900DL,1L,0x7F8C634FL,0x302D848DL},{(-2L),0L,0x70B0F04EL,0x215F63DAL},{0x04533268L,(-2L),(-1L),(-1L)},{6L,0xA4619C91L,0x399E5F1CL,(-1L)},{0x7A201F26L,0L,0xBCAD55B1L,4L},{0x2FD341E3L,(-1L),0xC28B900DL,(-1L)},{0x7F8C634FL,0xAB2E08F3L,2L,1L},{0x399E5F1CL,0L,(-8L),0x00A6551CL}},{{0L,(-1L),(-1L),8L},{0L,(-4L),(-8L),0x2FD341E3L},{0x399E5F1CL,8L,2L,6L},{0x7F8C634FL,1L,0xC28B900DL,(-2L)},{0x2FD341E3L,(-9L),0xBCAD55B1L,(-1L)},{0x7A201F26L,6L,0x399E5F1CL,0xAB2E08F3L},{6L,1L,(-1L),3L},{0x04533268L,0x399E5F1CL,0x70B0F04EL,0x2FD341E3L},{0x215F63DAL,0x04533268L,6L,0x399E5F1CL},{(-2L),(-1L),0x496710E1L,(-1L)}},{{1L,0x70B0F04EL,0x70B0F04EL,1L},{(-4L),(-2L),(-9L),0xA4619C91L},{6L,(-1L),0xF95BEDFBL,(-1L)},{(-1L),0L,0xBCAD55B1L,(-1L)},{(-8L),(-1L),0x7A201F26L,0xA4619C91L},{0x7F8C634FL,(-2L),0x89111B8BL,1L},{8L,0x70B0F04EL,(-8L),(-1L)},{0L,(-1L),0x00A6551CL,0x399E5F1CL},{0L,0x04533268L,0xC7242945L,0x2FD341E3L},{8L,0x399E5F1CL,2L,3L}},{{0L,1L,0x7A201F26L,0xAB2E08F3L},{0x2FD341E3L,6L,0x302D848DL,(-1L)},{(-1L),(-9L),0x399E5F1CL,(-2L)},{(-9L),1L,(-9L),6L},{0x04533268L,8L,0xBE5584E0L,0x2FD341E3L},{1L,(-4L),6L,8L},{0xAB2E08F3L,(-1L),6L,0x00A6551CL},{1L,0L,0xBE5584E0L,1L},{0x04533268L,0xAB2E08F3L,(-9L),(-1L)},{(-9L),(-1L),0x399E5F1CL,4L}},{{(-1L),0L,0x302D848DL,(-1L)},{0x2FD341E3L,0xA4619C91L,0x7A201F26L,(-1L)},{0L,(-2L),2L,0x215F63DAL},{8L,0L,0xC7242945L,(-1L)},{0L,4L,0x00A6551CL,8L},{0L,0x04533268L,(-8L),(-8L)},{8L,8L,0x89111B8BL,3L},{0x7F8C634FL,2L,0x7A201F26L,(-2L)},{(-8L),6L,0xBCAD55B1L,0x7A201F26L},{(-1L),6L,0xF95BEDFBL,(-2L)}},{{6L,2L,(-9L),3L},{0xBE5584E0L,0x7A201F26L,0x302D848DL,(-1L)},{0L,0x70B0F04EL,0x04533268L,0x7A201F26L},{0x215F63DAL,0x22A3D401L,0xB69EBD4FL,(-8L)},{0x7DADB20BL,0xBCAD55B1L,0x302D848DL,0x7DADB20BL},{0x70B0F04EL,0x215F63DAL,0x1B78C417L,0x399E5F1CL},{0x0E507156L,0xF95BEDFBL,0xC28B900DL,0L},{(-1L),0xA4619C91L,(-1L),0x22A3D401L},{(-9L),0x399E5F1CL,(-2L),0x399E5F1CL},{6L,(-1L),0x8AF1FBA9L,0L}}};
    int32_t l_84[2][5];
    uint16_t l_121[7][3][8] = {{{7UL,7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL},{0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL,1UL,1UL},{1UL,65529UL,0x9A6AL,0x9A6AL,65529UL,1UL,65529UL,0x9A6AL}},{{0x5E0FL,65529UL,0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL},{7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL,0x9A6AL},{7UL,7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL}},{{0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL,1UL,1UL},{1UL,65529UL,0x9A6AL,0x9A6AL,65529UL,1UL,65529UL,0x9A6AL},{0x5E0FL,65529UL,0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL}},{{7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL,0x9A6AL},{7UL,7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL},{0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL,1UL,1UL}},{{1UL,65529UL,0x9A6AL,0x9A6AL,65529UL,1UL,65529UL,0x9A6AL},{0x5E0FL,65529UL,0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL},{7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL,0x9A6AL}},{{7UL,7UL,1UL,0x9A6AL,1UL,7UL,7UL,1UL},{0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL,1UL,1UL},{1UL,65529UL,0x9A6AL,0x9A6AL,65529UL,1UL,65529UL,0x9A6AL}},{{0x5E0FL,65529UL,0x5E0FL,1UL,1UL,0x5E0FL,65529UL,0x5E0FL},{7UL,1UL,0x9A6AL,0x5E0FL,1UL,1UL,0x5E0FL,65529UL},{1UL,1UL,0x5E0FL,65529UL,0x5E0FL,1UL,1UL,0x5E0FL}}};
    uint32_t l_151 = 4294967295UL;
    uint16_t l_169 = 65535UL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_72[i] = 1L;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
            l_84[i][j] = (-8L);
    }
    g_67 ^= ((!(safe_div_func_uint64_t_u_u(func_25((p_21 > p_20), p_20, l_29[6][1]), g_6[1][0][3]))) <= 0x98AFL);
    if ((((g_64[3] <= l_29[6][1]) > g_6[3][1][6]) != l_29[2][0]))
    { /* block id: 19 */
        uint8_t l_85[4];
        int32_t l_88 = 0L;
        int i;
        for (i = 0; i < 4; i++)
            l_85[i] = 5UL;
        l_72[0] = ((safe_sub_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(g_64[2], 0x20075B0AL)), p_20)) == p_21);
        l_72[0] = ((safe_add_func_uint8_t_u_u(4UL, g_6[1][0][3])) || g_45);
        g_6[5][1][1] = (((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((((safe_add_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((0xC91FL && p_20), l_83[1][2][3])), g_64[2])) || 65528UL) ^ 0UL), 0x26D26517L)), l_84[1][4])) , l_83[1][1][0]) == l_85[2]);
        l_88 &= (safe_lshift_func_uint8_t_u_u(p_20, 0));
    }
    else
    { /* block id: 24 */
        g_6[1][0][3] = (g_6[4][0][0] , p_20);
        if ((0xC8C82E53L != g_67))
        { /* block id: 26 */
            return g_45;
        }
        else
        { /* block id: 28 */
            int64_t l_93 = 0L;
            l_93 = (safe_mod_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u(g_45, 3)), 7UL));
            return p_21;
        }
    }
    p_20 ^= (safe_mul_func_uint8_t_u_u(((((safe_div_func_uint32_t_u_u((((!(safe_sub_func_uint32_t_u_u((((safe_mod_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u(((g_45 ^ g_64[0]) ^ 1UL), g_64[3])) ^ g_6[1][3][1]), 1UL)) || g_64[2]) >= l_84[1][4]), l_29[6][1]))) , p_21) != 0x5D11L), p_21)) <= 0xA14B9FDE94E36BB2LL) && 252UL) , l_29[7][1]), 0xD0L));
    if (((p_21 , 0x377B0656L) , 1L))
    { /* block id: 34 */
        int8_t l_106 = (-7L);
        int16_t l_107 = 0x986FL;
        int16_t l_122 = (-1L);
        int32_t l_123 = 2L;
        g_6[1][0][3] = g_45;
        l_107 = (!(l_106 , 18446744073709551615UL));
        l_72[0] = (((+((safe_div_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u((((safe_mul_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((((safe_mul_func_uint8_t_u_u((((((safe_div_func_uint64_t_u_u(g_6[1][0][3], l_29[6][1])) <= g_6[1][0][3]) , p_20) , 0xD2B290D558BC8799LL) , 0UL), 0xBBL)) , 0x32L) > l_121[4][2][2]), l_83[1][2][3])), g_64[1])) == l_84[1][4]) >= 0x20L), 11)), p_20)) <= g_67)) , p_20) && 0x723561A8A250D85CLL);
        if ((4294967294UL == p_20))
        { /* block id: 38 */
            p_20 |= (l_106 != 1UL);
            l_123 = l_122;
            g_6[1][0][3] = (p_21 , l_122);
        }
        else
        { /* block id: 42 */
            uint8_t l_126 = 0x03L;
            uint8_t l_127 = 2UL;
            g_6[1][0][3] = ((((safe_rshift_func_uint8_t_u_u(l_126, 0)) <= 65528UL) <= p_20) ^ p_20);
            --l_127;
            g_6[1][0][3] &= ((g_64[1] >= 9UL) ^ 18446744073709551615UL);
        }
    }
    else
    { /* block id: 47 */
        uint64_t l_134 = 0UL;
        uint8_t l_159 = 0x6BL;
        int32_t l_163[3];
        int i;
        for (i = 0; i < 3; i++)
            l_163[i] = 0xA364DE6CL;
        if ((safe_rshift_func_uint16_t_u_u(p_20, g_6[2][4][1])))
        { /* block id: 48 */
            l_72[0] |= (safe_mod_func_uint8_t_u_u(0x28L, p_20));
            --l_134;
        }
        else
        { /* block id: 51 */
            uint16_t l_141[6] = {65526UL,65526UL,65526UL,65526UL,65526UL,65526UL};
            int32_t l_142 = (-1L);
            int i;
            l_142 = (safe_lshift_func_uint16_t_u_u(((((safe_div_func_uint64_t_u_u((l_141[5] == p_20), p_20)) , g_64[1]) >= p_20) , g_64[2]), 11));
            l_142 = (p_20 < p_21);
        }
        l_84[0][3] ^= (((safe_div_func_uint8_t_u_u(5UL, p_21)) , 1L) , 1L);
        g_6[1][0][3] = ((safe_sub_func_uint16_t_u_u(((((((safe_sub_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u(l_134, l_121[4][2][2])) == 0UL), p_20)) , l_134) > p_21) , 8UL) && 0x4BBCL) , l_151), 0x2E1FL)) > g_64[3]);
        if ((safe_lshift_func_uint8_t_u_u(0xE8L, g_6[1][0][3])))
        { /* block id: 57 */
            uint64_t l_154 = 0x452188D95DDA2071LL;
            int32_t l_160[2][3][5] = {{{0xAF234C5EL,0xAF234C5EL,1L,0L,0x29C00FFBL},{0x0A6E4D9EL,0xABF4803AL,0xABF4803AL,0x0A6E4D9EL,0x523401E5L},{(-7L),0L,0L,0L,0L}},{{0x523401E5L,0xABF4803AL,(-9L),0L,0L},{0xAC3CE05EL,0xAF234C5EL,0xAC3CE05EL,0L,1L},{0x49070C8BL,0x0A6E4D9EL,0L,0x0A6E4D9EL,0x49070C8BL}}};
            int i, j, k;
            l_154 = g_67;
            l_160[0][2][3] = (((safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u(((((g_64[0] <= 0xFF32E4EAL) < g_67) , p_21) , l_159), 12)), g_67)) || l_154) , g_6[1][2][3]);
            l_160[0][0][0] |= ((safe_mul_func_uint8_t_u_u(l_84[0][1], l_159)) == 0x94EB943AL);
            p_20 = l_159;
        }
        else
        { /* block id: 62 */
            int8_t l_167 = 9L;
            int32_t l_168 = (-5L);
            g_164++;
            p_20 = (1UL || g_164);
            ++l_169;
            g_6[1][0][3] &= ((safe_rshift_func_uint8_t_u_u(0x5EL, 0)) , 0x5683CA58L);
        }
    }
    return l_169;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_45 g_64
 * writes: g_64
 */
static uint64_t  func_25(int16_t  p_26, int32_t  p_27, int32_t  p_28)
{ /* block id: 5 */
    int64_t l_36 = 0x046E0AEE481DB3AALL;
    uint16_t l_37[3][2][7];
    uint32_t l_40 = 0x5A4C4AE3L;
    int32_t l_43 = 0x8196E547L;
    int32_t l_44[8][8][4] = {{{0x81186C96L,0x9BE1704BL,0xE582B275L,0xF6818A95L},{(-6L),(-1L),0L,0L},{(-2L),(-2L),0xDEBCD590L,0xFF6575EBL},{0x6B3EC5F6L,0xD4860CE0L,3L,(-5L)},{4L,0x93F77403L,0x5CEFCB9DL,3L},{0xCD07D1F8L,0x93F77403L,0L,(-5L)},{0x93F77403L,0xD4860CE0L,0x28EE66DBL,0xFF6575EBL},{1L,(-2L),0x6AC9C4BDL,0L}},{{1L,(-1L),0x8AE343BBL,0xF6818A95L},{0x0CEF6D7BL,0x9BE1704BL,0x1A916490L,0xE758ACF1L},{9L,0xD6FFC8DFL,0xB30C50D1L,(-1L)},{0x89E4144DL,0x8AE343BBL,0x9BE1704BL,0L},{0x7098D290L,0L,1L,0x4E1B820FL},{0xCB43529AL,1L,0x7098D290L,1L},{(-5L),1L,6L,(-1L)},{0xCDF46991L,0xFA1D5754L,1L,0x050D6AE9L}},{{0xD4ECAD78L,0L,0L,0xCB43529AL},{0x7F8E4820L,0xD1E91BE6L,0xD6FFC8DFL,(-1L)},{0x423D3ABBL,0x2CE29BE9L,0xFA1D5754L,0L},{3L,0xEA18A5AFL,0x68C86622L,0x3C25347FL},{(-1L),9L,0x443EFFA9L,0xD4ECAD78L},{0L,0L,3L,0x7098D290L},{0L,0L,1L,0x91D7193AL},{(-1L),0x81186C96L,0xE7FB9BE9L,6L}},{{2L,0L,0x050D6AE9L,0x6B3EC5F6L},{1L,0xF6818A95L,(-5L),2L},{1L,1L,0xD5D228C8L,0x54B5300FL},{(-1L),0xF325EC3EL,(-1L),0x7816D4D4L},{0xD3B6D3E8L,(-1L),1L,(-1L)},{(-1L),0L,0xCD07D1F8L,(-6L)},{0x3892391BL,0x30CB0470L,0xD1E91BE6L,0x5AFEF71AL},{0xF6818A95L,(-2L),2L,0x9BFF34F2L}},{{0xF6818A95L,1L,0xD1E91BE6L,0x89868D59L},{0x3892391BL,0x9BFF34F2L,0xCD07D1F8L,0x15C8DD58L},{(-1L),0x46FFD3C4L,1L,0x9BE1704BL},{0xD3B6D3E8L,0x3AA3630DL,0xD4860CE0L,0x3594313DL},{1L,0x3AA3630DL,0x89868D59L,0L},{0x423D3ABBL,0x28EE66DBL,1L,0x4E1B820FL},{(-3L),0x050D6AE9L,(-10L),0x93F77403L},{7L,0L,0xCDF46991L,1L}},{{0xD4860CE0L,0x81186C96L,0x423D3ABBL,0xDEBCD590L},{0x9BE1704BL,7L,0x91D7193AL,4L},{0x4E1B820FL,(-2L),0x93F77403L,0x3AA3630DL},{0x443EFFA9L,0x41278827L,0xA1D01971L,0xA62FBF91L},{0x91D7193AL,0x93F77403L,2L,6L},{0xE7FB9BE9L,0x415C855AL,0x2CE29BE9L,0x050D6AE9L},{0xDEBCD590L,0x6B3EC5F6L,0x1A916490L,0xD5D228C8L},{0x9BFF34F2L,0x54B5300FL,0x5CEFCB9DL,0x7098D290L}},{{0x7F8E4820L,0x89868D59L,0xB30C50D1L,0x28EE66DBL},{1L,0xF6818A95L,2L,0xCB43529AL},{0L,0L,9L,0x1A916490L},{2L,0x423D3ABBL,0L,1L},{0x41278827L,1L,4L,0xF325EC3EL},{0x06BCA32DL,(-1L),0x8AE343BBL,0x15C8DD58L},{0x30CB0470L,1L,0xFF6575EBL,(-2L)},{1L,0x2B0E7447L,0x2B0E7447L,1L}},{{0L,1L,(-1L),0xCDF46991L},{0L,0x3594313DL,0x9BE1704BL,2L},{0x050D6AE9L,0xD4ECAD78L,0xD5D228C8L,2L},{0xA62FBF91L,0x3594313DL,0x81186C96L,0xCDF46991L},{0x53DC1765L,1L,0xF325EC3EL,1L},{0x7098D290L,0x2B0E7447L,0xD6FFC8DFL,(-2L)},{0xD3B6D3E8L,1L,0x89E4144DL,0x15C8DD58L},{(-6L),(-1L),0x044A2B86L,0xF325EC3EL}}};
    int32_t l_46 = 0x19D3565FL;
    uint32_t l_48 = 4294967288UL;
    int32_t l_57 = 0x7FAAE3D9L;
    int32_t l_62[3][1][7] = {{{1L,1L,0xF5FB703AL,0xF5FB703AL,1L,1L,0xF5FB703AL}},{{(-1L),0x6B3F764AL,(-1L),0x6B3F764AL,(-1L),0x6B3F764AL,(-1L)}},{{1L,0xF5FB703AL,0xF5FB703AL,1L,1L,0xF5FB703AL,0xF5FB703AL}}};
    int32_t l_63 = 8L;
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 7; k++)
                l_37[i][j][k] = 0x937DL;
        }
    }
    if (((safe_mul_func_uint16_t_u_u((((safe_mod_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u((l_36 < 0x777FC3FE767E7924LL), 0xA7B2L)) >= g_6[5][0][0]) , g_6[1][0][3]), l_36)) , p_28) > g_6[1][0][3]), p_28)) || l_37[0][0][6]))
    { /* block id: 6 */
        int16_t l_38[8] = {0xD922L,0xFD71L,0xD922L,0xFD71L,0xD922L,0xFD71L,0xD922L,0xFD71L};
        int32_t l_39[6][1][5] = {{{0xD72D30A9L,(-1L),0xD72D30A9L,(-1L),(-1L)}},{{0xBB7762BEL,0xD9F1AA49L,0xD9F1AA49L,0xBB7762BEL,0xD9F1AA49L}},{{(-1L),(-1L),0x05C6596AL,(-1L),(-1L)}},{{0xD9F1AA49L,0xBB7762BEL,0xD9F1AA49L,0xD9F1AA49L,0xBB7762BEL}},{{(-1L),(-1L),0xD72D30A9L,(-1L),0xD72D30A9L}},{{0xBB7762BEL,0xBB7762BEL,0xFD1FA943L,0xBB7762BEL,0xBB7762BEL}}};
        int16_t l_47[3][2][2] = {{{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)}},{{(-1L),(-1L)},{(-1L),(-1L)}}};
        int i, j, k;
        p_28 = (((((g_6[1][0][3] && g_6[1][0][3]) || g_6[1][0][3]) <= 0xEBB67A0786CB52F5LL) >= g_6[1][0][3]) == l_37[0][0][6]);
        ++l_40;
        --l_48;
    }
    else
    { /* block id: 10 */
        p_28 ^= (g_45 || p_27);
        return g_6[1][0][3];
    }
    p_28 &= ((safe_add_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(((((safe_div_func_uint64_t_u_u(((((l_46 <= p_27) , 0UL) >= 0x0CCCL) >= l_36), 0x8EE9F968BF4733EFLL)) > g_45) , l_57) && g_6[3][4][4]), 1)), 0xC4L)) , g_6[4][2][4]);
    l_43 &= (safe_add_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_u(l_37[0][0][6], g_6[1][0][3])) >= 0UL), 1UL));
    g_64[2]--;
    return p_27;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_45, "g_45", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_64[i], "g_64[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_174, "g_174", print_hash_value);
    transparent_crc(g_198, "g_198", print_hash_value);
    transparent_crc(g_206, "g_206", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_229[i], "g_229[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_261, "g_261", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 91
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 108
   depth: 2, occurrence: 18
   depth: 3, occurrence: 9
   depth: 4, occurrence: 7
   depth: 5, occurrence: 4
   depth: 6, occurrence: 3
   depth: 7, occurrence: 3
   depth: 9, occurrence: 3
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 172
XXX times a non-volatile is write: 68
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 164
XXX percentage of non-volatile access: 94.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 92
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 22
   depth: 1, occurrence: 31
   depth: 2, occurrence: 39

XXX percentage a fresh-made variable is used: 17.9
XXX percentage an existing variable is used: 82.1
********************* end of statistics **********************/

