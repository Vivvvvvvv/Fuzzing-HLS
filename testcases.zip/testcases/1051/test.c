/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15412374174507778488
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_10 = 1UL;
static int8_t g_18 = 0xA5L;
static uint32_t g_21[7] = {0x813C27F3L,1UL,0x813C27F3L,0x813C27F3L,1UL,0x813C27F3L,0x813C27F3L};
static volatile int16_t g_24 = 2L;/* VOLATILE GLOBAL g_24 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const uint16_t  func_4(uint64_t  p_5);
static uint64_t  func_6(uint32_t  p_7, uint32_t  p_8);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_24
 * writes: g_18 g_21
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_9 = 0xA3L;
    int32_t l_28 = 0xA7BF748BL;
    l_28 &= (safe_sub_func_uint16_t_u_u(func_4(func_6((((l_9 <= 1L) == l_9) , g_10), l_9)), l_9));
    return g_24;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const uint16_t  func_4(uint64_t  p_5)
{ /* block id: 6 */
    uint32_t l_25 = 0x38009552L;
    l_25--;
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_10
 * writes: g_18 g_21
 */
static uint64_t  func_6(uint32_t  p_7, uint32_t  p_8)
{ /* block id: 1 */
    uint64_t l_11 = 1UL;
    const int16_t l_17 = 0x509CL;
    int32_t l_19 = 0x0DE450BBL;
    int32_t l_20 = 0x4D07DDBFL;
    l_11 = ((p_7 <= p_7) == 0xE3FF14EBL);
    g_18 = ((((!((safe_rshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s((l_11 < l_17), p_8)), 15)) , 0xBBB4L)) <= 0x6CL) != l_17) > (-2L));
    ++g_21[0];
    return g_10;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_21[i], "g_21[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_24, "g_24", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 10
   depth: 3, occurrence: 1
   depth: 8, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 5
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 94.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 8

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

