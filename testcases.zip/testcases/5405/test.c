/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14649853749046912869
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_7 = 6L;/* VOLATILE GLOBAL g_7 */
static uint64_t g_10 = 1UL;
static int32_t g_19 = 0x6FD5D705L;
static int32_t g_25 = 0x9DBC9B78L;
static uint64_t g_27 = 3UL;
static volatile int64_t g_33 = 1L;/* VOLATILE GLOBAL g_33 */
static uint64_t g_45 = 0x0CD8A6CE2E7C525ALL;
static int32_t g_50 = 0xFD1A6840L;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint32_t  func_51(uint32_t  p_52, int64_t  p_53);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_10 g_19 g_27 g_25 g_33 g_45
 * writes: g_10 g_19 g_27 g_25 g_45 g_50
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_6 = 0xDBL;
    uint16_t l_17[10] = {0xA17DL,0xC1D6L,0xA17DL,0xA17DL,0xC1D6L,0xA17DL,0xA17DL,0xC1D6L,0xA17DL,0xA17DL};
    int32_t l_30 = (-1L);
    int32_t l_34 = 0L;
    int i;
    if ((((safe_div_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(l_6, 1UL)), 252UL)) ^ l_6) < g_7))
    { /* block id: 1 */
        int16_t l_18 = 9L;
        g_10 ^= (safe_sub_func_uint64_t_u_u(l_6, 18446744073709551611UL));
        g_19 = (safe_add_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u(l_6, l_17[4])), l_18)), 18446744073709551615UL));
    }
    else
    { /* block id: 4 */
        return l_6;
    }
    for (l_6 = (-1); (l_6 == 55); ++l_6)
    { /* block id: 9 */
        int64_t l_31 = 1L;
        int32_t l_32[5] = {0L,0L,0L,0L,0L};
        uint32_t l_35[5][1] = {{4294967293UL},{0x935FF574L},{4294967293UL},{0x935FF574L},{4294967293UL}};
        int i, j;
        for (g_19 = (-9); (g_19 > (-22)); g_19 = safe_sub_func_uint8_t_u_u(g_19, 1))
        { /* block id: 12 */
            int64_t l_24 = 0xDDAC0FAAB39E2240LL;
            int32_t l_26 = 0x52A28486L;
            l_24 = g_19;
            ++g_27;
            --l_35[3][0];
        }
        g_25 ^= g_7;
        for (g_25 = 0; (g_25 != 12); g_25 = safe_add_func_uint16_t_u_u(g_25, 4))
        { /* block id: 20 */
            int16_t l_44 = 0xF850L;
            l_32[2] ^= g_19;
            g_45 |= (((safe_mul_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u((((g_33 < 8UL) > 7UL) > g_19), l_44)) , l_44), l_44)) == l_44) || 0x2535B5B0L);
            g_50 = (safe_rshift_func_uint16_t_u_u(((safe_mod_func_uint16_t_u_u(0xE906L, l_17[4])) == g_33), g_19));
        }
        l_30 = (func_51(l_34, l_17[4]) , l_35[4][0]);
    }
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_51(uint32_t  p_52, int64_t  p_53)
{ /* block id: 25 */
    int16_t l_57 = 3L;
    int32_t l_58 = 0xF1C8D212L;
    l_57 = (safe_rshift_func_uint16_t_u_u(((+0x33DC28BF2FEA2765LL) ^ p_52), 6));
    l_58 = l_57;
    l_58 = 0x3772679FL;
    l_58 = (-1L);
    return l_58;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 21
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 17
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 16
XXX percentage of non-volatile access: 91.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 7
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 42
XXX percentage an existing variable is used: 58
********************* end of statistics **********************/

