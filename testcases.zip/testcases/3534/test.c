/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14715518375988047163
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_9 = 18446744073709551615UL;
static int8_t g_27 = 0x10L;
static uint32_t g_28[4] = {4294967290UL,4294967290UL,4294967290UL,4294967290UL};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(uint32_t  p_3, uint16_t  p_4, uint16_t  p_5, int8_t  p_6, int32_t  p_7);
static const uint32_t  func_17(int32_t  p_18, int64_t  p_19, int16_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_28
 * writes: g_28
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_8 = 0x1BD97A888ADAE8C9LL;
    int32_t l_31 = 0L;
    l_31 |= func_2(l_8, g_9, g_9, g_9, g_9);
    return g_28[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_28
 * writes: g_28
 */
static int32_t  func_2(uint32_t  p_3, uint16_t  p_4, uint16_t  p_5, int8_t  p_6, int32_t  p_7)
{ /* block id: 1 */
    uint64_t l_10[3];
    uint32_t l_21[9] = {0xD62E6525L,0xD62E6525L,0UL,0xD62E6525L,0xD62E6525L,0UL,0xD62E6525L,0xD62E6525L,0UL};
    int32_t l_26[7] = {7L,7L,0x6BC22736L,7L,7L,0x6BC22736L,7L};
    int i;
    for (i = 0; i < 3; i++)
        l_10[i] = 18446744073709551609UL;
    --l_10[2];
lbl_25:
    for (p_6 = 0; (p_6 > (-22)); p_6--)
    { /* block id: 5 */
        uint32_t l_23[2];
        int32_t l_24 = (-9L);
        int i;
        for (i = 0; i < 2; i++)
            l_23[i] = 0UL;
        if ((safe_mul_func_uint8_t_u_u(255UL, 0xDAL)))
        { /* block id: 6 */
            return g_9;
        }
        else
        { /* block id: 8 */
            l_23[1] = (func_17(g_9, l_21[3], g_9) >= 0x415FB57AL);
        }
        l_24 = (p_5 || g_9);
        if (p_5)
            goto lbl_25;
        if (p_7)
            continue;
    }
    g_28[2]++;
    return g_28[1];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const uint32_t  func_17(int32_t  p_18, int64_t  p_19, int16_t  p_20)
{ /* block id: 9 */
    uint16_t l_22 = 0x0051L;
    l_22 |= 0L;
    return p_20;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_28[i], "g_28[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 16
XXX times a non-volatile is write: 7
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 4
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 37.9
XXX percentage an existing variable is used: 62.1
********************* end of statistics **********************/

