/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6953308281545529769
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_6 = 1UL;
static volatile uint16_t g_35[9][7] = {{65535UL,0x834DL,0xE07FL,0xE07FL,0x834DL,65535UL,65535UL},{0x6FDEL,0x053AL,65535UL,0x6FDEL,65529UL,65533UL,0x053AL},{0UL,1UL,65535UL,0x1694L,65535UL,1UL,0UL},{0x737FL,0x053AL,0xE0ADL,1UL,65534UL,0x737FL,1UL},{0x646DL,0x834DL,0UL,1UL,1UL,0UL,0x834DL},{0x053AL,1UL,0xE0ADL,0x2B15L,1UL,1UL,65529UL},{65527UL,1UL,65535UL,65527UL,1UL,0x0274L,0UL},{1UL,1UL,0x6FDEL,1UL,65534UL,0x053AL,1UL},{65535UL,0UL,1UL,65527UL,0xF9C8L,0xF9C8L,65527UL}};
static uint64_t g_60 = 0x44AAF27CECC56292LL;
static uint64_t g_70 = 1UL;
static int64_t g_75[7] = {0xD30D066B32335DC6LL,0xD30D066B32335DC6LL,0xD30D066B32335DC6LL,0xD30D066B32335DC6LL,0xD30D066B32335DC6LL,0xD30D066B32335DC6LL,0xD30D066B32335DC6LL};
static uint32_t g_84 = 0x6306CF3CL;
static volatile uint64_t g_108 = 0x635786DE445E70CALL;/* VOLATILE GLOBAL g_108 */
static uint32_t g_111 = 1UL;
static volatile int16_t g_112 = 0xADDFL;/* VOLATILE GLOBAL g_112 */
static uint16_t g_118 = 65534UL;
static uint32_t g_121 = 0x8A167226L;
static volatile uint8_t g_126 = 0xAEL;/* VOLATILE GLOBAL g_126 */
static int64_t g_135 = 0x5633C59A757E7574LL;
static uint16_t g_151 = 0xEC86L;
static int16_t g_182 = 4L;
static volatile uint32_t g_191 = 18446744073709551609UL;/* VOLATILE GLOBAL g_191 */
static int64_t g_210 = 0x3D635B3F4353AD90LL;
static volatile int8_t g_222 = (-7L);/* VOLATILE GLOBAL g_222 */
static int32_t g_223 = (-10L);
static int32_t g_225 = 1L;
static volatile int32_t g_228 = 0x8A8856AFL;/* VOLATILE GLOBAL g_228 */
static volatile int8_t g_229 = 7L;/* VOLATILE GLOBAL g_229 */
static int16_t g_231 = 0x28BCL;
static volatile uint16_t g_232 = 65528UL;/* VOLATILE GLOBAL g_232 */
static uint8_t g_267[6][5][5] = {{{249UL,255UL,0x67L,255UL,249UL},{0x68L,1UL,0UL,4UL,1UL},{249UL,0UL,0UL,249UL,4UL},{255UL,249UL,0x67L,1UL,1UL},{0x68L,249UL,0x68L,4UL,249UL}},{{1UL,0UL,4UL,1UL,4UL},{1UL,1UL,0x67L,249UL,255UL},{0x68L,255UL,4UL,4UL,255UL},{255UL,0UL,0x68L,255UL,4UL},{249UL,255UL,0x67L,255UL,249UL}},{{0x68L,1UL,0UL,4UL,1UL},{249UL,0UL,0UL,249UL,4UL},{255UL,249UL,0x67L,1UL,1UL},{0x68L,249UL,0x68L,4UL,249UL},{1UL,0UL,4UL,1UL,4UL}},{{1UL,1UL,0x67L,249UL,255UL},{0x68L,255UL,4UL,4UL,255UL},{255UL,0UL,0x68L,255UL,4UL},{249UL,255UL,0x67L,255UL,249UL},{0x68L,1UL,0UL,4UL,1UL}},{{249UL,0UL,0UL,249UL,4UL},{255UL,249UL,0x67L,1UL,1UL},{0x68L,249UL,0x68L,4UL,249UL},{1UL,0UL,4UL,1UL,4UL},{1UL,1UL,0x67L,249UL,255UL}},{{0x68L,255UL,4UL,4UL,255UL},{255UL,0UL,0x68L,255UL,4UL},{249UL,255UL,0x67L,255UL,249UL},{0x68L,1UL,0UL,4UL,1UL},{249UL,0UL,0UL,249UL,4UL}}};
static int8_t g_293[8] = {0x19L,0x19L,(-7L),0x19L,0x19L,(-7L),0x19L,0x19L};
static int8_t g_294 = 1L;
static uint64_t g_319 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int64_t  func_11(uint8_t  p_12, int16_t  p_13, uint8_t  p_14);
static uint64_t  func_20(int16_t  p_21);
static int32_t  func_22(uint8_t  p_23, uint32_t  p_24, const int64_t  p_25);
static int32_t  func_41(const int32_t  p_42, int32_t  p_43, int8_t  p_44, int32_t  p_45, int32_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_35 g_60 g_75 g_84 g_70 g_108 g_111 g_118 g_121 g_126 g_135 g_112 g_151 g_182 g_191 g_210 g_232 g_223 g_267 g_228 g_222 g_229 g_293 g_225 g_319
 * writes: g_6 g_35 g_70 g_75 g_60 g_84 g_108 g_111 g_118 g_126 g_135 g_151 g_121 g_182 g_191 g_210 g_232 g_225 g_267 g_319
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_3 = 1UL;
    int32_t l_8 = (-8L);
    uint8_t l_15[4] = {251UL,251UL,251UL,251UL};
    int64_t l_275 = 0xAC2C7B452A9382D2LL;
    int32_t l_296 = 0x606840BBL;
    int i;
    l_3 ^= (!0L);
    for (l_3 = (-9); (l_3 == 30); l_3 = safe_add_func_int64_t_s_s(l_3, 5))
    { /* block id: 4 */
        uint8_t l_16 = 0xA0L;
        int32_t l_259 = 0xE9621522L;
        uint32_t l_264 = 9UL;
        if (((g_6 , g_6) == 248UL))
        { /* block id: 5 */
            uint64_t l_7[3];
            int i;
            for (i = 0; i < 3; i++)
                l_7[i] = 0x5166941FC9A57B5BLL;
            if (g_6)
                break;
            l_8 ^= ((l_7[2] > g_6) != 0xCDL);
            l_259 = ((safe_mod_func_uint16_t_u_u(((func_11(l_15[0], l_16, g_6) , g_232) , 5UL), 1UL)) > l_16);
        }
        else
        { /* block id: 170 */
            int32_t l_262 = (-1L);
            int32_t l_263 = 0xC684A527L;
            l_262 ^= (((safe_lshift_func_uint8_t_u_u(g_35[0][1], g_151)) || 1L) <= g_118);
            if (l_16)
                continue;
            l_264++;
        }
    }
    --g_267[3][1][2];
    if ((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s((((+(255UL <= l_8)) , g_75[0]) > 0x7AL), l_275)), g_84)))
    { /* block id: 177 */
        int64_t l_287 = 1L;
        int32_t l_295 = 0x7031B13CL;
        uint16_t l_297 = 0x462FL;
        if (((safe_mod_func_int64_t_s_s((!0x07D9A1DDL), g_228)) && g_75[0]))
        { /* block id: 178 */
            g_225 = (safe_rshift_func_uint8_t_u_s((((safe_sub_func_int16_t_s_s((safe_sub_func_uint32_t_u_u(((safe_mul_func_int8_t_s_s(g_267[4][0][1], l_287)) ^ l_3), l_15[0])), g_182)) == 0xF6L) , g_222), g_267[3][1][2]));
            l_8 = (safe_sub_func_uint8_t_u_u(((((-2L) != g_229) , l_287) > g_6), (-1L)));
            l_8 |= (0x2DFBD6A78B015109LL | g_6);
        }
        else
        { /* block id: 182 */
            uint64_t l_290 = 0x106D382288B616A7LL;
            g_225 = g_84;
            g_225 = (g_118 != 0x3F66L);
            l_290--;
            return l_290;
        }
        g_225 = g_182;
        ++l_297;
    }
    else
    { /* block id: 190 */
        int32_t l_317 = 0xD65BC54DL;
        int32_t l_318[1][8][7] = {{{0x55DC2D2AL,0x8055A96BL,3L,0x14D613FCL,0x15BDAC5FL,0x55DC2D2AL,3L},{0x66A7A55DL,3L,3L,0x66A7A55DL,0x6C95B063L,0x14D613FCL,0xB23D83A0L},{0x14D613FCL,3L,0x8055A96BL,0x55DC2D2AL,0x00AAEA3AL,0x6C95B063L,1L},{0xB23D83A0L,0x920C041AL,0x14D613FCL,0x4974D66FL,0x14D613FCL,0x920C041AL,0xB23D83A0L},{0x15BDAC5FL,0x4974D66FL,0x920C041AL,1L,0x14D613FCL,0xE5F60006L,3L},{(-1L),0xE5F60006L,0x55DC2D2AL,0x14D613FCL,0x00AAEA3AL,0x00AAEA3AL,0x14D613FCL},{0x920C041AL,0x04F5D172L,0x920C041AL,0x0F169524L,0x6C95B063L,(-1L),0xE5F60006L},{0x920C041AL,1L,0x14D613FCL,0xE5F60006L,3L,0x04F5D172L,(-1L)}}};
        int i, j, k;
        if ((safe_mod_func_int32_t_s_s((safe_lshift_func_int16_t_s_s((0L < g_293[7]), 2)), g_191)))
        { /* block id: 191 */
            g_225 |= (safe_div_func_int32_t_s_s(((0xD0L < l_15[0]) && g_35[0][1]), 1L));
        }
        else
        { /* block id: 193 */
            int64_t l_308[8][5][6] = {{{0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L)},{0x65E9CBFC775A24C5LL,0x774B25CBC684671BLL,0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L},{1L,0x65E9CBFC775A24C5LL,(-9L),0x65E9CBFC775A24C5LL,1L,0xC745169D787DB018LL},{0x65E9CBFC775A24C5LL,1L,0xC745169D787DB018LL,0xC745169D787DB018LL,1L,0x65E9CBFC775A24C5LL},{0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L,0x6A8D5824C6D288F8LL,0x65E9CBFC775A24C5LL}},{{0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L),0xC745169D787DB018LL},{0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL,(-9L),1L,0x67D9A33A07E61623LL,1L},{0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L)},{0x65E9CBFC775A24C5LL,0x774B25CBC684671BLL,0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L},{1L,0x65E9CBFC775A24C5LL,(-9L),0x65E9CBFC775A24C5LL,1L,0xC745169D787DB018LL}},{{0x65E9CBFC775A24C5LL,1L,0xC745169D787DB018LL,0xC745169D787DB018LL,1L,0x65E9CBFC775A24C5LL},{0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L,0x6A8D5824C6D288F8LL,0x65E9CBFC775A24C5LL},{0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L),0xC745169D787DB018LL},{0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL,(-9L),1L,0x67D9A33A07E61623LL,1L},{0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L)}},{{0x65E9CBFC775A24C5LL,0x774B25CBC684671BLL,0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L},{1L,0x65E9CBFC775A24C5LL,(-9L),0x65E9CBFC775A24C5LL,1L,0xC745169D787DB018LL},{0x65E9CBFC775A24C5LL,1L,0xC745169D787DB018LL,0xC745169D787DB018LL,1L,0x65E9CBFC775A24C5LL},{0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L,0x6A8D5824C6D288F8LL,0x65E9CBFC775A24C5LL},{0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L),0xC745169D787DB018LL}},{{0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL,(-9L),1L,0x67D9A33A07E61623LL,1L},{0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L)},{0x65E9CBFC775A24C5LL,0x774B25CBC684671BLL,0x774B25CBC684671BLL,0x65E9CBFC775A24C5LL,0x6A8D5824C6D288F8LL,1L},{1L,0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L)},{0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L),0xC745169D787DB018LL,0x774B25CBC684671BLL}},{{1L,0x774B25CBC684671BLL,0x67D9A33A07E61623LL,0xC745169D787DB018LL,0x67D9A33A07E61623LL,0x774B25CBC684671BLL},{0x67D9A33A07E61623LL,1L,(-9L),0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL,(-9L)},{0x67D9A33A07E61623LL,0x67D9A33A07E61623LL,0x6A8D5824C6D288F8LL,0xC745169D787DB018LL,0x65E9CBFC775A24C5LL,0xC745169D787DB018LL},{1L,0x67D9A33A07E61623LL,1L,(-9L),0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL},{0x774B25CBC684671BLL,1L,1L,0x774B25CBC684671BLL,0x67D9A33A07E61623LL,0xC745169D787DB018LL}},{{0xC745169D787DB018LL,0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L)},{0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L),0xC745169D787DB018LL,0x774B25CBC684671BLL},{1L,0x774B25CBC684671BLL,0x67D9A33A07E61623LL,0xC745169D787DB018LL,0x67D9A33A07E61623LL,0x774B25CBC684671BLL},{0x67D9A33A07E61623LL,1L,(-9L),0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL,(-9L)},{0x67D9A33A07E61623LL,0x67D9A33A07E61623LL,0x6A8D5824C6D288F8LL,0xC745169D787DB018LL,0x65E9CBFC775A24C5LL,0xC745169D787DB018LL}},{{1L,0x67D9A33A07E61623LL,1L,(-9L),0x6A8D5824C6D288F8LL,0x6A8D5824C6D288F8LL},{0x774B25CBC684671BLL,1L,1L,0x774B25CBC684671BLL,0x67D9A33A07E61623LL,0xC745169D787DB018LL},{0xC745169D787DB018LL,0x774B25CBC684671BLL,0x6A8D5824C6D288F8LL,0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L)},{0x774B25CBC684671BLL,0xC745169D787DB018LL,(-9L),(-9L),0xC745169D787DB018LL,0x774B25CBC684671BLL},{1L,0x774B25CBC684671BLL,0x67D9A33A07E61623LL,0xC745169D787DB018LL,0x67D9A33A07E61623LL,0x774B25CBC684671BLL}}};
            int i, j, k;
            l_308[3][3][3] = (safe_div_func_uint16_t_u_u(0x94A9L, (-9L)));
        }
        l_8 ^= (safe_div_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u((((l_317 < 0xE0FE807BL) == g_112) , g_229), 0xCBL)) ^ 0x0F085550C3F117C1LL), (-6L))), l_296)), 0x4EF0DABAL));
        l_296 = g_210;
        if ((g_70 , l_296))
        { /* block id: 198 */
            g_319++;
            return l_296;
        }
        else
        { /* block id: 201 */
            l_318[0][3][1] = ((g_60 > (-9L)) && (-1L));
            g_225 ^= ((+(0x8379ABE34B0513A6LL ^ g_210)) > g_210);
        }
    }
    return g_267[2][2][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_35 g_60 g_75 g_84 g_70 g_108 g_111 g_118 g_121 g_126 g_135 g_112 g_151 g_182 g_191 g_210 g_232 g_223
 * writes: g_6 g_35 g_70 g_75 g_60 g_84 g_108 g_111 g_118 g_126 g_135 g_151 g_121 g_182 g_191 g_210 g_232 g_225
 */
static int64_t  func_11(uint8_t  p_12, int16_t  p_13, uint8_t  p_14)
{ /* block id: 8 */
    int32_t l_17[3][7] = {{0x85DC1B6EL,0xCEE61780L,0x85DC1B6EL,0x85DC1B6EL,0xCEE61780L,0x85DC1B6EL,0x85DC1B6EL},{0xCEE61780L,0xCEE61780L,4L,0xCEE61780L,0xCEE61780L,4L,0xCEE61780L},{0xCEE61780L,0x85DC1B6EL,0x85DC1B6EL,0xCEE61780L,0x85DC1B6EL,0x85DC1B6EL,0xCEE61780L}};
    int32_t l_218 = 0x14CF4170L;
    int32_t l_219 = 0x58E9FEB4L;
    int32_t l_221 = 0xC5A3C14FL;
    int32_t l_227[2][9][3];
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
                l_227[i][j][k] = 0x9A14F9FCL;
        }
    }
    for (g_6 = 0; (g_6 <= 2); g_6 += 1)
    { /* block id: 11 */
        uint8_t l_217 = 0xA5L;
        int32_t l_220 = 0xED6128A6L;
        int32_t l_226 = 0x224AD8BEL;
        int32_t l_230[4][7] = {{0xDF08DB16L,6L,6L,0xDF08DB16L,0x3EDA3869L,0xACACCE18L,1L},{1L,0xACACCE18L,0x3EDA3869L,0xDF08DB16L,6L,6L,0xDF08DB16L},{0L,0x4DBB215AL,0L,0xACACCE18L,0x61937B28L,3L,1L},{0x4DBB215AL,0x44750127L,0L,0x3EDA3869L,0xFEF85CD5L,0x3EDA3869L,0L}};
        int16_t l_247 = 0xE8B4L;
        int i, j;
        if ((((p_14 , g_6) , p_14) & 4294967295UL))
        { /* block id: 12 */
            uint64_t l_26 = 8UL;
            int32_t l_216 = 0xFC7E913CL;
            int32_t l_224[5] = {0xBEE2B736L,0xBEE2B736L,0xBEE2B736L,0xBEE2B736L,0xBEE2B736L};
            int i;
            l_216 = (safe_mod_func_uint16_t_u_u((func_20((func_22(p_13, l_26, p_14) , p_12)) < g_6), l_26));
            if (g_75[4])
                break;
            l_217 = (1L > p_13);
            ++g_232;
        }
        else
        { /* block id: 145 */
            int16_t l_248 = 0x4451L;
            g_225 = (((((safe_mod_func_uint64_t_u_u((safe_rshift_func_int8_t_s_s((safe_add_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u((safe_sub_func_int16_t_s_s((safe_mod_func_int32_t_s_s(0xE64B6092L, l_247)), p_14)), 0x9EC0A325L)) > g_223), l_226)), l_248)), p_12)) ^ l_217) >= 0xEC40L) < g_35[4][5]) ^ g_210);
            g_225 = l_248;
        }
        for (g_151 = 0; (g_151 <= 2); g_151 += 1)
        { /* block id: 151 */
            int i, j;
            l_221 = l_17[g_151][g_6];
        }
        for (l_247 = 2; (l_247 >= 0); l_247 -= 1)
        { /* block id: 156 */
            int i, j;
            l_221 = (((safe_mul_func_uint8_t_u_u(255UL, l_17[g_6][g_6])) || 1L) != 0x93EDD8F2L);
        }
        for (p_14 = 0; (p_14 <= 2); p_14 += 1)
        { /* block id: 161 */
            uint16_t l_253[4] = {0xA0B9L,0xA0B9L,0xA0B9L,0xA0B9L};
            int32_t l_256 = 1L;
            int i;
            l_253[0] = (safe_add_func_int64_t_s_s((-6L), g_6));
            l_230[3][4] = (+0xE300602DL);
            l_256 = (+g_108);
        }
    }
    l_219 = (safe_mul_func_uint16_t_u_u((p_14 && l_227[0][6][2]), 0xFDF0L));
    return g_108;
}


/* ------------------------------------------ */
/* 
 * reads : g_60 g_135 g_108 g_182 g_111 g_75 g_191 g_118 g_151 g_210 g_126
 * writes: g_60 g_135 g_182 g_191 g_118 g_210
 */
static uint64_t  func_20(int16_t  p_21)
{ /* block id: 112 */
    int16_t l_181 = 1L;
    int32_t l_183 = 0x776E9E25L;
    for (g_60 = 25; (g_60 >= 8); --g_60)
    { /* block id: 115 */
        int32_t l_187[5];
        int i;
        for (i = 0; i < 5; i++)
            l_187[i] = 2L;
        for (g_135 = (-25); (g_135 != (-25)); g_135 = safe_add_func_uint16_t_u_u(g_135, 1))
        { /* block id: 118 */
            g_182 |= (((safe_sub_func_uint8_t_u_u((safe_unary_minus_func_int32_t_s((safe_sub_func_uint64_t_u_u(g_108, 18446744073709551615UL)))), l_181)) , 0L) , p_21);
            l_183 = (p_21 <= g_135);
        }
        if (g_135)
            goto lbl_211;
        for (g_182 = (-5); (g_182 != (-27)); --g_182)
        { /* block id: 124 */
            int32_t l_190 = 0xCEBA9940L;
            l_187[4] = (!(g_111 & g_111));
            l_183 = (safe_mul_func_int16_t_s_s(((g_75[0] || l_190) >= p_21), l_183));
            g_191--;
            if (p_21)
                break;
        }
    }
    for (g_118 = 0; (g_118 == 36); g_118 = safe_add_func_uint64_t_u_u(g_118, 8))
    { /* block id: 133 */
        int16_t l_202[1];
        int32_t l_203 = 0xB9DA4FCEL;
        int i;
        for (i = 0; i < 1; i++)
            l_202[i] = (-1L);
        l_203 ^= ((safe_lshift_func_int8_t_s_u(((safe_mod_func_int8_t_s_s(((((safe_div_func_uint16_t_u_u((l_183 != l_202[0]), p_21)) < l_183) | p_21) != p_21), 0xC3L)) <= l_181), 2)) , g_151);
        l_203 = (safe_lshift_func_uint16_t_u_s((p_21 || 0xEFL), p_21));
    }
lbl_211:
    g_210 |= ((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u(l_183, 0x8AA5L)), g_191)) > l_183);
    l_183 = (((safe_mul_func_uint16_t_u_u((safe_sub_func_int16_t_s_s((-9L), l_181)), l_183)) , (-7L)) && g_126);
    return l_183;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_6 g_60 g_75 g_84 g_70 g_108 g_111 g_118 g_121 g_126 g_135 g_112 g_151
 * writes: g_35 g_70 g_75 g_60 g_84 g_108 g_111 g_118 g_126 g_135 g_151 g_121
 */
static int32_t  func_22(uint8_t  p_23, uint32_t  p_24, const int64_t  p_25)
{ /* block id: 13 */
    int16_t l_29[1];
    int32_t l_33 = 0xB927EED0L;
    int32_t l_34[7][10][3] = {{{1L,1L,0x92A1DD6BL},{0x22781501L,(-9L),0x53483200L},{0L,0L,(-1L)},{0xEC499E98L,0x9AF2C67AL,0x8BA832A4L},{0L,0x9F41AF53L,(-1L)},{8L,(-1L),0xD6C8400BL},{0xCE5FEF40L,0L,(-1L)},{0xE864ADB5L,1L,0x8BA832A4L},{(-9L),0x94D85D5FL,(-1L)},{(-1L),0xCE5FEF40L,0x53483200L}},{{0x726F2C0EL,0x0B631114L,(-1L)},{1L,0x8BA832A4L,0xD6C8400BL},{0x9F41AF53L,1L,(-1L)},{1L,0x94D85D5FL,6L},{1L,0xD6C8400BL,1L},{0x9F41AF53L,1L,0xD57ECA51L},{1L,0xE864ADB5L,6L},{0x8BA832A4L,0x0B631114L,0x0B631114L},{0x48967C74L,(-1L),1L},{1L,(-1L),0L}},{{1L,0x5B6D4F50L,(-1L)},{(-1L),1L,1L},{0xD57ECA51L,0x5B6D4F50L,0L},{(-6L),(-1L),8L},{(-1L),(-1L),0x22781501L},{0x506946CBL,0x0B631114L,(-6L)},{(-1L),0xE864ADB5L,0x9AF2C67AL},{0xAE776296L,1L,0x92A1DD6BL},{0x0B631114L,0xD6C8400BL,0xE864ADB5L},{0xEC499E98L,0x94D85D5FL,0xE864ADB5L}},{{0x9AF2C67AL,1L,0x92A1DD6BL},{0x53483200L,0x8BA832A4L,0x9AF2C67AL},{1L,0x92A1DD6BL,(-6L)},{0x22781501L,(-1L),0x22781501L},{(-1L),(-4L),8L},{0x2B783560L,8L,0L},{6L,(-6L),1L},{(-1L),0L,(-1L)},{6L,1L,0L},{0x2B783560L,0x726F2C0EL,1L}},{{(-1L),0x506946CBL,0x0B631114L},{0x22781501L,1L,6L},{1L,0x53483200L,0xD57ECA51L},{0x53483200L,0x48967C74L,1L},{0x9AF2C67AL,0x67DBF129L,6L},{0xEC499E98L,0x67DBF129L,(-1L)},{0x0B631114L,0x48967C74L,0xD6C8400BL},{0xAE776296L,0x53483200L,(-1L)},{(-1L),1L,(-1L)},{0x506946CBL,0x506946CBL,(-3L)}},{{(-1L),0x726F2C0EL,0x94D85D5FL},{(-6L),1L,0x48967C74L},{0xD57ECA51L,0L,(-9L)},{(-1L),(-6L),0x48967C74L},{1L,8L,0x94D85D5FL},{1L,(-4L),(-3L)},{0x48967C74L,(-1L),(-1L)},{0x8BA832A4L,0x92A1DD6BL,(-1L)},{1L,0x8BA832A4L,0xD6C8400BL},{0x9F41AF53L,1L,(-1L)}},{{1L,0x94D85D5FL,6L},{1L,0xD6C8400BL,1L},{0x9F41AF53L,1L,0xD57ECA51L},{1L,0xE864ADB5L,6L},{0x8BA832A4L,0x0B631114L,0x0B631114L},{0x48967C74L,(-1L),1L},{1L,(-1L),0L},{1L,0x5B6D4F50L,(-1L)},{(-1L),1L,1L},{0xD57ECA51L,0x5B6D4F50L,0L}}};
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_29[i] = 0L;
    for (p_23 = 0; (p_23 >= 29); ++p_23)
    { /* block id: 16 */
        int32_t l_30 = 0x50887C5CL;
        int32_t l_32 = 0L;
        for (p_24 = 0; (p_24 <= 0); p_24 += 1)
        { /* block id: 19 */
            int32_t l_31[10] = {(-1L),4L,0xC7A88FF7L,4L,(-1L),(-1L),4L,0xC7A88FF7L,4L,(-1L)};
            int i;
            l_30 = 0xB35F1971L;
            if (l_29[p_24])
                continue;
            g_35[0][1]++;
            l_32 ^= (l_31[3] , 1L);
        }
        return g_6;
    }
    if (l_33)
    { /* block id: 27 */
        uint64_t l_113 = 3UL;
        int32_t l_117 = 0x47E4C77BL;
lbl_116:
        for (l_33 = 0; (l_33 <= 0); l_33 += 1)
        { /* block id: 30 */
            int32_t l_38 = 0x7F559297L;
            int i;
            l_38 = ((l_29[l_33] , l_29[0]) || p_23);
            g_111 ^= (safe_add_func_int32_t_s_s(func_41(((p_23 , l_33) , g_35[3][4]), g_6, l_38, g_6, g_6), 0L));
            l_113++;
            l_38 = 1L;
            if (p_24)
                goto lbl_122;
            if (l_113)
                goto lbl_116;
        }
        --g_118;
lbl_122:
        l_34[6][0][1] = (((8L <= p_25) && l_117) == g_121);
        l_117 = g_121;
    }
    else
    { /* block id: 83 */
        uint64_t l_123 = 18446744073709551608UL;
        l_123 |= ((0x6627L == (-1L)) || l_33);
    }
lbl_150:
    l_33 = 0xF45F4F03L;
    if ((safe_mod_func_uint8_t_u_u(0UL, 1UL)))
    { /* block id: 87 */
        --g_126;
        return p_25;
    }
    else
    { /* block id: 90 */
        int32_t l_142 = 0xEE5F14FEL;
        g_135 = ((safe_add_func_int8_t_s_s(((safe_mul_func_int8_t_s_s((safe_add_func_int8_t_s_s(g_84, l_33)), l_29[0])) || p_23), l_33)) != 0xA726563165A292D2LL);
        for (g_84 = 0; (g_84 <= 6); g_84 += 1)
        { /* block id: 94 */
            int16_t l_143 = 0L;
            l_143 = (safe_div_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_u((((safe_mul_func_int16_t_s_s(0xC59BL, 0UL)) < g_135) <= l_142), p_24)) >= 7UL), 0x48E8C813L));
            l_34[6][4][2] = (((((safe_add_func_uint64_t_u_u((((safe_sub_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_s((l_142 , l_142), 2)) | p_23), 1UL)) >= 1L) , p_23), 0UL)) | l_34[6][4][2]) || 8UL) || l_142) <= 0UL);
            if (g_111)
                continue;
        }
        if ((((((p_25 || p_24) > 0x861B4666L) ^ 0x5BL) , l_34[4][2][0]) , p_23))
        { /* block id: 99 */
            if (g_118)
                goto lbl_150;
        }
        else
        { /* block id: 101 */
            int16_t l_155 = 0xB27BL;
            g_151 &= ((l_34[6][4][2] & g_112) , p_23);
            l_155 = ((safe_unary_minus_func_int64_t_s(((safe_sub_func_int64_t_s_s(7L, p_25)) != 0xAB2CL))) && p_25);
        }
        for (g_121 = 0; (g_121 <= 6); g_121 += 1)
        { /* block id: 107 */
            int i;
            l_34[3][7][1] = (safe_mod_func_uint16_t_u_u(((((safe_lshift_func_uint8_t_u_s((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((((((safe_add_func_uint16_t_u_u(((safe_sub_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(((((-1L) == g_75[g_121]) & 0x7C1614232493EC21LL) >= l_142), g_126)), 0x6F8ADBACC00A57CCLL)) | 0UL), l_29[0])) & (-8L)) | 65535UL) > g_60) , l_29[0]), p_23)), l_34[3][1][1])), 2)), g_60)) || l_142) ^ g_75[g_121]) && g_108), g_75[g_121]));
        }
    }
    return g_75[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_6 g_60 g_75 g_84 g_70 g_108
 * writes: g_70 g_75 g_60 g_84 g_108
 */
static int32_t  func_41(const int32_t  p_42, int32_t  p_43, int8_t  p_44, int32_t  p_45, int32_t  p_46)
{ /* block id: 32 */
    int8_t l_59 = 1L;
    int8_t l_71 = 0x9CL;
    uint32_t l_74 = 4294967295UL;
    int32_t l_100 = (-1L);
    int16_t l_107 = 0x9CE9L;
    if ((safe_rshift_func_uint16_t_u_u(p_44, p_44)))
    { /* block id: 33 */
        uint32_t l_54 = 0x58B99485L;
        int32_t l_56[10] = {4L,4L,4L,4L,4L,4L,4L,4L,4L,4L};
        int i;
        if ((safe_unary_minus_func_uint32_t_u((0xCDE8L | 0x35D4L))))
        { /* block id: 34 */
            uint64_t l_55 = 0xCE2A3F7B2C8398D9LL;
            int32_t l_57 = 1L;
            int32_t l_58 = 0L;
            l_56[4] = (safe_rshift_func_int16_t_s_s(((((((((((safe_mod_func_uint32_t_u_u(((p_45 ^ g_35[5][5]) ^ 249UL), l_54)) > p_44) > p_44) <= g_6) != (-2L)) | (-1L)) <= 0UL) , 5UL) , l_55) , 0L), 7));
            l_57 = ((-2L) <= p_42);
            l_58 |= l_57;
        }
        else
        { /* block id: 38 */
            l_59 = 0x7097499CL;
            l_56[4] = ((l_54 , g_60) | 0L);
            p_45 = ((safe_unary_minus_func_int16_t_s((safe_mod_func_uint16_t_u_u(65533UL, p_43)))) , 0x1179EF6EL);
        }
        if ((((safe_mul_func_int16_t_s_s(g_35[6][5], g_60)) != g_60) | 0xCD19L))
        { /* block id: 43 */
            int16_t l_66 = 0x9702L;
            int32_t l_67[8][5][6] = {{{(-5L),(-1L),6L,(-1L),(-5L),0x794A777CL},{(-5L),0x2C0441A9L,(-1L),0x122BDA4FL,0x8DDEC24AL,0x8DDEC24AL},{0x2C0441A9L,0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL},{9L,0x8DDEC24AL,(-1L),0x794A777CL,0x122BDA4FL,0x794A777CL},{6L,0xCDDCCF37L,6L,(-1L),0x122BDA4FL,(-5L)}},{{(-1L),0x8DDEC24AL,9L,6L,6L,9L},{0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL,(-1L)},{(-1L),0x2C0441A9L,(-5L),(-1L),(-5L),0x2C0441A9L},{6L,(-1L),(-5L),0x794A777CL,0xBC366FF5L,(-1L)},{9L,0x794A777CL,0x2C0441A9L,0x2C0441A9L,0x794A777CL,9L}},{{0x2C0441A9L,0x794A777CL,9L,0x122BDA4FL,0xBC366FF5L,(-5L)},{(-5L),(-1L),6L,(-1L),(-5L),0x794A777CL},{(-5L),0x2C0441A9L,(-1L),0x122BDA4FL,0x8DDEC24AL,0x8DDEC24AL},{0x2C0441A9L,0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL},{9L,0x8DDEC24AL,(-1L),0x794A777CL,0x122BDA4FL,0x794A777CL}},{{6L,0xCDDCCF37L,6L,(-1L),0x122BDA4FL,(-5L)},{(-1L),0x8DDEC24AL,9L,6L,6L,9L},{0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL,(-1L)},{(-1L),0x2C0441A9L,(-5L),(-1L),(-5L),0x2C0441A9L},{6L,(-1L),(-5L),0x794A777CL,0xBC366FF5L,(-1L)}},{{9L,0x794A777CL,0x2C0441A9L,0x2C0441A9L,0x794A777CL,9L},{0x2C0441A9L,0x794A777CL,9L,0x122BDA4FL,0xBC366FF5L,(-5L)},{(-5L),(-1L),6L,(-1L),(-5L),0x794A777CL},{(-5L),0x2C0441A9L,(-1L),0x122BDA4FL,0x8DDEC24AL,0x8DDEC24AL},{0x2C0441A9L,0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL}},{{9L,0x8DDEC24AL,(-1L),0x794A777CL,0x122BDA4FL,0x794A777CL},{6L,0xCDDCCF37L,6L,(-1L),0x122BDA4FL,(-5L)},{(-1L),0x8DDEC24AL,9L,6L,6L,9L},{0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL,(-1L)},{(-1L),0x2C0441A9L,(-5L),(-1L),(-5L),0x2C0441A9L}},{{6L,(-1L),(-5L),0x794A777CL,(-1L),(-1L)},{6L,0x2C0441A9L,0xBC366FF5L,0xBC366FF5L,0x2C0441A9L,6L},{0xBC366FF5L,0x2C0441A9L,6L,0x8DDEC24AL,(-1L),9L},{9L,0xCDDCCF37L,0x794A777CL,0xCDDCCF37L,9L,0x2C0441A9L},{9L,0xBC366FF5L,0xCDDCCF37L,0x8DDEC24AL,(-5L),(-5L)}},{{0xBC366FF5L,(-1L),(-1L),0xBC366FF5L,0x794A777CL,(-5L)},{6L,(-5L),0xCDDCCF37L,0x2C0441A9L,0x8DDEC24AL,0x2C0441A9L},{0x794A777CL,0x122BDA4FL,0x794A777CL,(-1L),0x8DDEC24AL,9L},{0xCDDCCF37L,(-5L),6L,0x794A777CL,0x794A777CL,6L},{(-1L),(-1L),0xBC366FF5L,0x794A777CL,(-5L),(-1L)}}};
            int i, j, k;
            l_67[0][2][1] |= l_66;
            g_70 = (safe_lshift_func_uint16_t_u_u(p_45, g_35[0][1]));
            p_45 = ((l_71 < p_46) , p_43);
        }
        else
        { /* block id: 47 */
            return g_60;
        }
    }
    else
    { /* block id: 50 */
        g_75[0] = (((safe_add_func_int8_t_s_s((0xE8L | (-9L)), g_35[0][1])) , 0x97L) ^ l_74);
    }
    for (g_60 = 0; (g_60 > 55); g_60 = safe_add_func_uint16_t_u_u(g_60, 1))
    { /* block id: 55 */
        const uint32_t l_97 = 0x54074BD2L;
        for (p_46 = 6; (p_46 >= 0); p_46 -= 1)
        { /* block id: 58 */
            int i, j;
            g_84 ^= (safe_sub_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(0x5832669E62AD52EBLL, g_35[(p_46 + 1)][p_46])), (-2L))) & g_75[p_46]), l_71));
        }
        for (l_74 = 0; (l_74 > 24); l_74 = safe_add_func_int16_t_s_s(l_74, 8))
        { /* block id: 63 */
            int16_t l_87[4][5] = {{0x479CL,0x479CL,0x479CL,0x479CL,0x479CL},{9L,0xAF94L,9L,0xAF94L,9L},{0x479CL,0x479CL,0x479CL,0x479CL,0x479CL},{9L,0xAF94L,9L,0xAF94L,9L}};
            uint16_t l_96 = 65534UL;
            int i, j;
            l_87[1][2] = 0x0CF28406L;
            p_45 = (safe_div_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((((safe_mod_func_int8_t_s_s(p_46, l_74)) ^ l_96) & l_97), g_6)) , 0x6EL), g_70)), 0x97B4F3ECL));
            p_46 ^= (((((safe_mul_func_uint8_t_u_u(0x19L, 0x35L)) & 0L) >= 0x4DL) ^ p_44) , l_97);
            l_100 = ((g_6 && g_75[4]) , (-2L));
        }
        p_45 = ((((safe_lshift_func_int8_t_s_u(((safe_mod_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_u((0xAE2F6F5FL < l_71), 9)) & g_6) || 0xE4E9FC46A622BFDELL), p_43)) | g_84), p_44)) && l_107) , l_97) >= l_97);
        if (g_35[0][1])
            continue;
    }
    ++g_108;
    return g_35[8][6];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_35[i][j], "g_35[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_75[i], "g_75[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_182, "g_182", print_hash_value);
    transparent_crc(g_191, "g_191", print_hash_value);
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_222, "g_222", print_hash_value);
    transparent_crc(g_223, "g_223", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    transparent_crc(g_228, "g_228", print_hash_value);
    transparent_crc(g_229, "g_229", print_hash_value);
    transparent_crc(g_231, "g_231", print_hash_value);
    transparent_crc(g_232, "g_232", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_267[i][j][k], "g_267[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_293[i], "g_293[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_294, "g_294", print_hash_value);
    transparent_crc(g_319, "g_319", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 94
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 20
breakdown:
   depth: 1, occurrence: 127
   depth: 2, occurrence: 31
   depth: 3, occurrence: 14
   depth: 4, occurrence: 10
   depth: 5, occurrence: 5
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 4
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 2
   depth: 14, occurrence: 1
   depth: 20, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 206
XXX times a non-volatile is write: 89
XXX times a volatile is read: 26
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 104
XXX percentage of non-volatile access: 90.5

XXX forward jumps: 3
XXX backward jumps: 1

XXX stmts: 127
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 22
   depth: 1, occurrence: 37
   depth: 2, occurrence: 68

XXX percentage a fresh-made variable is used: 28.2
XXX percentage an existing variable is used: 71.8
********************* end of statistics **********************/

