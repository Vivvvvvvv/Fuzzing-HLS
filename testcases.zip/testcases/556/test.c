/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      869990151404526300
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_2[4][3][10] = {{{18446744073709551609UL,0xE713E19FL,0xE713E19FL,18446744073709551609UL,0x69AC54C9L,0UL,1UL,18446744073709551609UL,0UL,0xE713E19FL},{0x69AC54C9L,0UL,0x25BFC88EL,0xCD509978L,7UL,18446744073709551613UL,0xE713E19FL,1UL,0UL,18446744073709551613UL},{0xD732ADAAL,0x7D228D5FL,0xCD509978L,18446744073709551609UL,0xD732ADAAL,0x25BFC88EL,0x25BFC88EL,0xD732ADAAL,18446744073709551609UL,0xCD509978L}},{{0x69AC54C9L,0x69AC54C9L,0xCD509978L,0UL,18446744073709551610UL,0xD732ADAAL,0xCD509978L,1UL,0x69AC54C9L,7UL},{18446744073709551609UL,0UL,0x25BFC88EL,18446744073709551613UL,0xD732ADAAL,0x7D228D5FL,1UL,0UL,18446744073709551613UL,0xCD509978L},{0xD732ADAAL,18446744073709551610UL,0UL,0xCD509978L,0x69AC54C9L,0x69AC54C9L,0xCD509978L,0UL,18446744073709551610UL,0xD732ADAAL}},{{0xD732ADAAL,0xE713E19FL,0x548AAB56L,18446744073709551613UL,18446744073709551610UL,0xE713E19FL,0UL,0xD732ADAAL,0UL,0x548AAB56L},{0UL,0xD732ADAAL,0UL,0xE713E19FL,18446744073709551610UL,18446744073709551613UL,0x548AAB56L,0xE713E19FL,0xD732ADAAL,0xD732ADAAL},{18446744073709551610UL,0UL,0xCD509978L,0x69AC54C9L,0x69AC54C9L,0xCD509978L,0UL,18446744073709551610UL,0xD732ADAAL,0xCD509978L}},{{18446744073709551613UL,0UL,1UL,0xE713E19FL,18446744073709551613UL,7UL,0xCD509978L,0x25BFC88EL,0UL,0x69AC54C9L},{18446744073709551610UL,0x548AAB56L,1UL,18446744073709551613UL,18446744073709551609UL,0x25BFC88EL,1UL,18446744073709551610UL,18446744073709551610UL,1UL},{0UL,18446744073709551613UL,0xCD509978L,0xCD509978L,18446744073709551613UL,0UL,1UL,0xE713E19FL,18446744073709551613UL,7UL}}};
static int32_t g_3 = 1L;
static int16_t g_28 = 0L;
static volatile uint64_t g_29 = 18446744073709551607UL;/* VOLATILE GLOBAL g_29 */
static uint8_t g_40 = 251UL;
static int64_t g_51 = 8L;
static uint32_t g_56 = 1UL;
static uint64_t g_65[2][2][6] = {{{1UL,6UL,0UL,1UL,6UL,1UL},{1UL,1UL,1UL,1UL,1UL,0UL}},{{1UL,5UL,1UL,1UL,5UL,1UL},{1UL,6UL,0UL,1UL,6UL,1UL}}};
static volatile uint16_t g_70 = 65531UL;/* VOLATILE GLOBAL g_70 */
static uint32_t g_75[6][7] = {{0UL,0xD91310E3L,0xD91310E3L,0UL,0UL,0xD91310E3L,0xD91310E3L},{0x422EE889L,4294967294UL,0x422EE889L,4294967294UL,0x422EE889L,4294967294UL,0x422EE889L},{0UL,0UL,0xD91310E3L,0xD91310E3L,0UL,0UL,0xD91310E3L},{0UL,4294967294UL,0UL,4294967294UL,0UL,4294967294UL,0UL},{0UL,0xD91310E3L,0xD91310E3L,0UL,0UL,0xD91310E3L,0xD91310E3L},{0x422EE889L,4294967294UL,0x422EE889L,4294967294UL,0x422EE889L,4294967294UL,0x422EE889L}};
static int64_t g_80 = 1L;
static volatile int32_t g_84[1] = {0L};
static volatile int8_t g_96 = (-1L);/* VOLATILE GLOBAL g_96 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_9(const uint8_t  p_10);
static uint16_t  func_13(int32_t  p_14);
static uint16_t  func_46(uint64_t  p_47, int32_t  p_48, uint8_t  p_49);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_29 g_28 g_56 g_65 g_70 g_75 g_51
 * writes: g_3 g_28 g_29 g_40 g_51 g_56 g_65 g_70 g_75 g_80
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_5[7] = {3L,3L,3L,3L,3L,3L,3L};
    uint16_t l_107[5][7][1] = {{{65527UL},{0x1989L},{0x18E9L},{0x18E9L},{0x1989L},{65527UL},{0UL}},{{0x1989L},{0UL},{65527UL},{0x1989L},{0x18E9L},{0x18E9L},{0x1989L}},{{65527UL},{0UL},{0x1989L},{0UL},{65527UL},{0x1989L},{0x18E9L}},{{0x18E9L},{0x1989L},{65527UL},{0UL},{0x1989L},{0UL},{65527UL}},{{0x1989L},{0x18E9L},{0x18E9L},{0x1989L},{65527UL},{0UL},{0x1989L}}};
    int32_t l_109 = 1L;
    int32_t l_110 = 0x358E79FDL;
    int32_t l_111 = 0x01E2AC5FL;
    int32_t l_112[3][3][5] = {{{0xD96F57F4L,0xD96F57F4L,0x902CEC10L,0xD96F57F4L,0xD96F57F4L},{4L,0xD96F57F4L,4L,0x902CEC10L,4L},{4L,0x902CEC10L,0x902CEC10L,4L,0x902CEC10L}},{{4L,4L,0xD96F57F4L,4L,4L},{0x902CEC10L,4L,0x902CEC10L,0x902CEC10L,4L},{4L,0x902CEC10L,0x902CEC10L,4L,0x902CEC10L}},{{4L,4L,0xD96F57F4L,4L,4L},{0x902CEC10L,4L,0x902CEC10L,0x902CEC10L,4L},{4L,0x902CEC10L,0x902CEC10L,4L,0x902CEC10L}}};
    int32_t l_113[6] = {0x493B66AFL,0x493B66AFL,0x493B66AFL,0x493B66AFL,0x493B66AFL,0x493B66AFL};
    uint32_t l_114 = 18446744073709551615UL;
    int i, j, k;
lbl_108:
    g_3 = g_2[2][2][4];
    for (g_3 = 0; (g_3 <= 2); g_3 += 1)
    { /* block id: 4 */
        int32_t l_4 = 1L;
        int32_t l_6 = 0x0D58E7EAL;
        if (l_4)
            break;
        if (g_3)
        { /* block id: 6 */
            if (l_5[6])
                break;
            l_6 = 1L;
            return g_3;
        }
        else
        { /* block id: 10 */
            if (l_6)
                break;
        }
        l_107[0][5][0] = (safe_div_func_int32_t_s_s(func_9((((((func_13((safe_rshift_func_int16_t_s_s(((safe_div_func_uint8_t_u_u(((l_6 || l_6) <= l_5[4]), g_2[2][2][4])) || g_2[2][2][4]), 15))) >= 9L) || l_5[6]) <= 0L) | g_3) , g_56)), l_6));
        for (l_6 = 0; (l_6 <= 2); l_6 += 1)
        { /* block id: 66 */
            if (g_3)
                goto lbl_108;
        }
    }
    --l_114;
    return l_107[0][5][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_65 g_29 g_70 g_3 g_75 g_51
 * writes: g_56 g_65 g_70 g_75 g_80
 */
static int32_t  func_9(const uint8_t  p_10)
{ /* block id: 40 */
    int32_t l_69 = 0x49BFE1A8L;
    int32_t l_92 = 0x0AFEB5ABL;
    int32_t l_97 = 0xBB34BBF6L;
    int32_t l_99[5][10] = {{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L},{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L},{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L},{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L},{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L}};
    uint16_t l_103[1][3][6] = {{{0x788BL,0xDF63L,0x788BL,0x788BL,0xDF63L,0x788BL},{0x788BL,0xDF63L,0x788BL,0x788BL,0xDF63L,0x788BL},{0x788BL,0xDF63L,0x788BL,0x788BL,0xDF63L,0x788BL}}};
    uint32_t l_106 = 5UL;
    int i, j, k;
    for (g_56 = 19; (g_56 >= 19); g_56 = safe_add_func_uint16_t_u_u(g_56, 4))
    { /* block id: 43 */
        uint64_t l_64 = 1UL;
        volatile int64_t l_68 = 0x4C8AB2937F868666LL;/* VOLATILE GLOBAL l_68 */
        int32_t l_79 = (-3L);
        int32_t l_82 = 0xC01BB24DL;
        int32_t l_87 = (-9L);
        int32_t l_88 = 0xF7DC92B2L;
        int32_t l_91[6];
        int32_t l_93 = 1L;
        int32_t l_94[5][3] = {{1L,0L,1L},{8L,0L,8L},{1L,0L,1L},{8L,0L,8L},{1L,0L,1L}};
        uint32_t l_100 = 18446744073709551607UL;
        int i, j;
        for (i = 0; i < 6; i++)
            l_91[i] = 0x052AF0D9L;
        if (((l_64 ^ p_10) || p_10))
        { /* block id: 44 */
            ++g_65[0][1][3];
        }
        else
        { /* block id: 46 */
            uint32_t l_73 = 0xD57AD3C0L;
            l_68 = g_29;
            g_70++;
            if (l_73)
                break;
        }
        if (g_3)
        { /* block id: 51 */
            const int8_t l_74 = 0xA6L;
            g_75[4][2] &= (p_10 && l_74);
            l_79 = (safe_div_func_int64_t_s_s((~g_75[4][2]), l_69));
            g_80 = (0xF904L >= l_79);
        }
        else
        { /* block id: 55 */
            uint32_t l_81 = 0x035E89B0L;
            int32_t l_83 = (-1L);
            int32_t l_85 = 0xBD6D72D1L;
            int32_t l_86 = 0x9A7EFCC6L;
            int32_t l_89 = 8L;
            int32_t l_90 = 0x04081ECFL;
            int32_t l_95 = 0x0B01AA1EL;
            int32_t l_98[8][5] = {{(-1L),0x4C20F6EBL,8L,0x9A48E5C9L,0x4C20F6EBL},{(-3L),0L,0L,(-3L),0x5516B95FL},{0x1DD83CB0L,(-1L),0x77BC6277L,0x4C20F6EBL,0x4C20F6EBL},{0L,(-3L),0L,0x5516B95FL,(-3L)},{0x4C20F6EBL,8L,0x9A48E5C9L,0x4C20F6EBL,0x9A48E5C9L},{0x1BCF51ADL,0x1BCF51ADL,0L,(-3L),0x493B5762L},{(-1L),0x1DD83CB0L,0x9A48E5C9L,0x9A48E5C9L,0x1DD83CB0L},{0x493B5762L,0L,0L,0x493B5762L,0x5516B95FL}};
            int i, j;
            l_81 |= ((((0x1F98D32190EF9F67LL & 4UL) != l_64) != g_51) > g_3);
            --l_100;
            l_87 = ((0L <= p_10) || 4UL);
            --l_103[0][2][5];
        }
    }
    return l_106;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_29 g_28 g_56
 * writes: g_28 g_29 g_40 g_51 g_56
 */
static uint16_t  func_13(int32_t  p_14)
{ /* block id: 13 */
    uint32_t l_19[5][5] = {{18446744073709551614UL,18446744073709551614UL,0xE2646899L,18446744073709551614UL,18446744073709551614UL},{1UL,18446744073709551612UL,1UL,1UL,18446744073709551612UL},{18446744073709551614UL,18446744073709551610UL,18446744073709551610UL,18446744073709551614UL,18446744073709551610UL},{18446744073709551612UL,18446744073709551612UL,0x5B7518DBL,18446744073709551612UL,18446744073709551612UL},{18446744073709551610UL,18446744073709551614UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL}};
    int32_t l_26 = (-1L);
    uint32_t l_53[2];
    int i, j;
    for (i = 0; i < 2; i++)
        l_53[i] = 0UL;
    l_19[2][2]--;
    if ((safe_lshift_func_uint8_t_u_s(l_19[2][2], l_19[1][4])))
    { /* block id: 15 */
        uint32_t l_27[7][8][1] = {{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}},{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}},{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}},{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}},{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}},{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}},{{1UL},{0UL},{1UL},{0UL},{1UL},{0UL},{1UL},{0UL}}};
        int i, j, k;
        l_26 = (safe_rshift_func_uint16_t_u_s(((g_3 , g_3) || 0xDB81L), p_14));
        p_14 = (l_27[2][0][0] & 0L);
    }
    else
    { /* block id: 18 */
        g_28 = g_2[2][1][2];
    }
lbl_55:
    g_29 ^= 0x72A7181CL;
    for (g_28 = 0; (g_28 >= (-22)); g_28 = safe_sub_func_int32_t_s_s(g_28, 2))
    { /* block id: 24 */
        int64_t l_36 = 0x3C5815DA77236C34LL;
        int32_t l_54 = 1L;
        const int64_t l_61 = 0x972037C870D18411LL;
        l_26 = (safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s(((l_36 <= g_2[2][2][4]) , g_28), p_14)), g_28));
        for (l_36 = 0; (l_36 <= 7); l_36++)
        { /* block id: 28 */
            uint8_t l_39 = 0x9FL;
            uint64_t l_50 = 0UL;
            g_40 = ((((0xBCB567DFL > g_29) >= 0xD66052DBL) >= l_39) == 0x1FL);
            l_54 = (safe_add_func_uint32_t_u_u((safe_add_func_int32_t_s_s(((!(func_46(l_50, l_36, g_2[2][2][4]) & l_26)) > p_14), l_36)), l_53[1]));
            if (g_3)
                goto lbl_55;
            --g_56;
        }
        l_26 = (safe_lshift_func_int16_t_s_u((((8L != 1L) | l_61) , p_14), 6));
    }
    return g_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_51
 */
static uint16_t  func_46(uint64_t  p_47, int32_t  p_48, uint8_t  p_49)
{ /* block id: 30 */
    uint16_t l_52 = 0UL;
    g_51 = g_2[2][2][4];
    return l_52;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_65[i][j][k], "g_65[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_70, "g_70", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_75[i][j], "g_75[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_80, "g_80", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_84[i], "g_84[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_96, "g_96", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 59
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 51
   depth: 2, occurrence: 10
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 4
   depth: 8, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 60
XXX times a non-volatile is write: 27
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 78
XXX percentage of non-volatile access: 93.5

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 45
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 12
   depth: 2, occurrence: 20

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

