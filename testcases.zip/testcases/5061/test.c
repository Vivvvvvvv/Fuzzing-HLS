/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17453619197862469858
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_5[4][8][5] = {{{0x3EL,3UL,0x90L,9UL,1UL},{0x3EL,6UL,1UL,1UL,6UL},{0xD1L,3UL,1UL,4UL,0x5CL},{0x19L,1UL,0x90L,1UL,0x5CL},{0x3DL,255UL,4UL,9UL,6UL},{0x19L,255UL,0UL,0xD1L,1UL},{0xD1L,1UL,4UL,0xD1L,0x69L},{0x3EL,3UL,0x90L,9UL,1UL}},{{0x3EL,6UL,1UL,1UL,6UL},{0xD1L,0x31L,0x5CL,1UL,0xE7L},{255UL,255UL,6UL,0x5CL,0xE7L},{253UL,0x5AL,1UL,3UL,0xEFL},{255UL,0x5AL,0x69L,0UL,255UL},{255UL,255UL,1UL,0UL,1UL},{255UL,0x31L,6UL,3UL,255UL},{255UL,0xEFL,0x5CL,0x5CL,0xEFL}},{{255UL,0x31L,0x5CL,1UL,0xE7L},{255UL,255UL,6UL,0x5CL,0xE7L},{253UL,0x5AL,1UL,3UL,0xEFL},{255UL,0x5AL,0x69L,0UL,255UL},{255UL,255UL,1UL,0UL,1UL},{255UL,0x31L,6UL,3UL,255UL},{255UL,0xEFL,0x5CL,0x5CL,0xEFL},{255UL,0x31L,0x5CL,1UL,0xE7L}},{{255UL,255UL,6UL,0x5CL,0xE7L},{253UL,0x5AL,1UL,3UL,0xEFL},{255UL,0x5AL,0x69L,0UL,255UL},{255UL,255UL,1UL,0UL,1UL},{255UL,0x31L,6UL,3UL,255UL},{255UL,0xEFL,0x5CL,0x5CL,0xEFL},{255UL,0x31L,0x5CL,1UL,0xE7L},{255UL,255UL,6UL,0x5CL,0xE7L}}};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes:
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_4[7] = {0xD32FL,0xD32FL,0xD32FL,0xD32FL,0xD32FL,0xD32FL,0xD32FL};
    int32_t l_6 = (-2L);
    int i;
    l_6 = (((safe_lshift_func_uint16_t_u_u(((l_4[0] , 4294967295UL) , l_4[0]), 0)) , g_5[2][4][0]) == 1UL);
    l_6 &= g_5[2][1][0];
    return l_4[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_5[i][j][k], "g_5[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 4
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 3
XXX times a non-volatile is write: 2
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 71.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 3
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 3

XXX percentage a fresh-made variable is used: 42.9
XXX percentage an existing variable is used: 57.1
********************* end of statistics **********************/

