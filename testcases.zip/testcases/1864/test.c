/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11751008801498371676
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_5 = 0UL;
static uint16_t g_6 = 0x70CDL;
static volatile uint64_t g_10 = 18446744073709551615UL;/* VOLATILE GLOBAL g_10 */
static volatile uint32_t g_15 = 0UL;/* VOLATILE GLOBAL g_15 */
static int64_t g_31 = (-1L);


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_7(int32_t  p_8, int32_t  p_9);
static int32_t  func_18(uint32_t  p_19, int64_t  p_20, uint8_t  p_21, uint32_t  p_22, uint64_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_10 g_6 g_15 g_31
 * writes: g_6 g_10 g_15 g_31 g_5
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_4 = 0xDB22L;
    int32_t l_41 = 3L;
    int32_t l_44 = (-2L);
    g_6 = (safe_mod_func_uint16_t_u_u((l_4 == g_5), 0x39EDL));
    l_41 = func_7(l_4, g_5);
    l_44 &= (safe_mul_func_uint16_t_u_u(g_31, l_41));
    return l_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_6 g_15 g_5 g_31
 * writes: g_10 g_6 g_15 g_31 g_5
 */
static int32_t  func_7(int32_t  p_8, int32_t  p_9)
{ /* block id: 2 */
    int32_t l_24 = 0x647F1A96L;
    uint32_t l_40 = 0x3EC3E1B8L;
    g_10--;
    for (g_6 = 0; (g_6 > 48); g_6++)
    { /* block id: 6 */
        int8_t l_25 = 0xE3L;
        g_15--;
        p_9 = func_18(l_24, p_8, p_9, p_8, l_25);
        for (g_5 = 0; (g_5 != 8); g_5 = safe_add_func_uint32_t_u_u(g_5, 4))
        { /* block id: 14 */
            p_9 = ((safe_div_func_uint32_t_u_u(((safe_sub_func_uint32_t_u_u((safe_div_func_int32_t_s_s(g_6, (-8L))), (-6L))) & 0x7C0EC0DCEE05243BLL), g_5)) && l_40);
            return g_31;
        }
    }
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_31 g_15
 * writes: g_31
 */
static int32_t  func_18(uint32_t  p_19, int64_t  p_20, uint8_t  p_21, uint32_t  p_22, uint64_t  p_23)
{ /* block id: 8 */
    uint64_t l_30 = 0xAF8716B5B3847D22LL;
    g_31 ^= ((safe_div_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s((g_5 == l_30), 13)), 0x2B058EFAL)) && l_30);
    return g_15;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 8
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 11
XXX percentage of non-volatile access: 90.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 3
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 41.4
XXX percentage an existing variable is used: 58.6
********************* end of statistics **********************/

