/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10182815739140372454
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_15 = 0x0B5F0B101AAE4B9ALL;/* VOLATILE GLOBAL g_15 */
static int16_t g_16[4][3] = {{1L,1L,1L},{1L,1L,1L},{1L,1L,1L},{1L,1L,1L}};
static int64_t g_38 = 0xD0127420EA1BCA33LL;
static int64_t g_64[9][7][3] = {{{0L,(-1L),0x79822E7BB921586CLL},{(-3L),0x4AE77DDBA47A58E8LL,0x65B034E2D8D86F2FLL},{0L,0x56F60D197A07E09FLL,(-3L)},{1L,0xCEE7E287B835292FLL,0x79E4C0C5DC747387LL},{1L,(-1L),0L},{0x79822E7BB921586CLL,1L,0x0591FCF288C1B93FLL},{6L,0x5BA09F94EB44D538LL,6L}},{{0x56F60D197A07E09FLL,0x872AF4091208AFAELL,0x9AD35785F4F6E089LL},{0x18CA9A6AE6C26CF9LL,(-7L),0xC666DF6EF7D18C36LL},{0x5F0D2369E1CF7F80LL,(-10L),0x911DF381B91F40ACLL},{(-1L),0L,0x6A4AF1292777EF5ELL},{0x5F0D2369E1CF7F80LL,(-1L),0x18CA9A6AE6C26CF9LL},{0x79E4C0C5DC747387LL,(-1L),0x5BA09F94EB44D538LL},{0x6A4AF1292777EF5ELL,0xA6C5FA6071001949LL,0xE5052DE1722BB76ELL}},{{0x76A8768DD0F05760LL,0x3C6AA55A6935E7B0LL,0L},{(-1L),0L,0L},{0x3C6AA55A6935E7B0LL,0x56F60D197A07E09FLL,0x5F0D2369E1CF7F80LL},{0L,0x79E4C0C5DC747387LL,(-1L)},{(-10L),6L,0x6A5961B9AEE73119LL},{0x9AD35785F4F6E089LL,(-10L),0x6A4AF1292777EF5ELL},{0x07285EBC95BC5B36LL,0x92E0EE4D501105CALL,0x4EDB9D72FAF72239LL}},{{8L,(-6L),0x4EDB9D72FAF72239LL},{0x5063020822C3E505LL,0x6A5961B9AEE73119LL,0x6A4AF1292777EF5ELL},{0x56F60D197A07E09FLL,(-9L),0x6A5961B9AEE73119LL},{1L,(-10L),(-1L)},{0xB0C40B387E8D9F6CLL,0x4AE77DDBA47A58E8LL,0x5F0D2369E1CF7F80LL},{0xC666DF6EF7D18C36LL,0x76A8768DD0F05760LL,0L},{0L,0x0591FCF288C1B93FLL,0L}},{{0x48F9E473B9571DA8LL,0xE5052DE1722BB76ELL,0xE5052DE1722BB76ELL},{(-1L),0x48F9E473B9571DA8LL,0x5BA09F94EB44D538LL},{1L,0x79822E7BB921586CLL,0x18CA9A6AE6C26CF9LL},{(-9L),1L,(-10L)},{(-10L),(-7L),0x0591FCF288C1B93FLL},{0x1334807DA0BF3FD2LL,1L,0x4AE77DDBA47A58E8LL},{(-3L),0x79822E7BB921586CLL,0xC666DF6EF7D18C36LL}},{{1L,0x48F9E473B9571DA8LL,0x76A8768DD0F05760LL},{0xA6C5FA6071001949LL,0xE5052DE1722BB76ELL,(-7L)},{0L,0x0591FCF288C1B93FLL,0x65B034E2D8D86F2FLL},{(-7L),0x76A8768DD0F05760LL,(-1L)},{0L,0x4AE77DDBA47A58E8LL,0x9AD35785F4F6E089LL},{0x4AE77DDBA47A58E8LL,(-10L),0xF37692AFB55E8A08LL},{0L,(-9L),(-1L)}},{{(-1L),0x6A5961B9AEE73119LL,0L},{(-1L),(-6L),(-10L)},{(-1L),0x92E0EE4D501105CALL,0L},{(-1L),(-10L),0x79E4C0C5DC747387LL},{0L,6L,8L},{0x4AE77DDBA47A58E8LL,0x79E4C0C5DC747387LL,(-9L)},{0L,0x56F60D197A07E09FLL,(-1L)}},{{(-7L),0L,(-10L)},{0L,0x3C6AA55A6935E7B0LL,0xA6C5FA6071001949LL},{0xA6C5FA6071001949LL,0xA6C5FA6071001949LL,(-10L)},{1L,(-1L),(-9L)},{(-3L),(-1L),0x8B7E04BE07DECC76LL},{0x1334807DA0BF3FD2LL,1L,0x92E0EE4D501105CALL},{(-10L),(-3L),0x8B7E04BE07DECC76LL}},{{(-9L),1L,(-9L)},{1L,0xC054819E5EE4ADB8LL,(-10L)},{(-1L),(-1L),0xA6C5FA6071001949LL},{0x48F9E473B9571DA8LL,(-9L),(-10L)},{0L,0x5F0D2369E1CF7F80LL,(-1L)},{0xC666DF6EF7D18C36LL,(-1L),(-9L)},{0xB0C40B387E8D9F6CLL,0x6A4AF1292777EF5ELL,8L}}};
static uint32_t g_85[1] = {0x3715829BL};
static int16_t g_92 = 0xDE64L;
static uint32_t g_94 = 0xC049E589L;


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);
static int32_t  func_2(uint16_t  p_3, int32_t  p_4, int16_t  p_5, int32_t  p_6);
static uint16_t  func_7(uint16_t  p_8, int16_t  p_9, const int8_t  p_10, int16_t  p_11);
static uint32_t  func_20(uint32_t  p_21, int8_t  p_22, uint32_t  p_23, uint32_t  p_24);
static int32_t  func_28(uint32_t  p_29, uint32_t  p_30, uint32_t  p_31, int64_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_38 g_64 g_85 g_92 g_94
 * writes: g_38 g_64 g_85 g_92 g_94
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    const uint16_t l_14 = 1UL;
    const uint8_t l_17 = 0UL;
    int32_t l_49 = 0x4ADDBFD3L;
    int32_t l_50 = 9L;
    uint16_t l_84 = 0xDFC8L;
    int32_t l_102 = 0x5D69AD93L;
    if (func_2(((((func_7(((safe_add_func_uint32_t_u_u((((l_14 , 6L) , g_15) , l_14), g_16[3][1])) > l_14), g_16[2][1], l_17, g_16[3][1]) && 0x8000L) == g_16[2][2]) , 0UL) > g_16[3][1]), g_16[3][1], g_16[3][1], g_16[3][1]))
    { /* block id: 18 */
        int16_t l_48 = 0L;
        int32_t l_58 = 0L;
        l_50 = ((l_48 != l_49) , 0x116E8CFBL);
        for (l_48 = 0; (l_48 != 14); l_48 = safe_add_func_uint64_t_u_u(l_48, 7))
        { /* block id: 22 */
            const uint32_t l_57 = 9UL;
            l_58 &= ((((safe_add_func_uint16_t_u_u(((safe_mod_func_uint64_t_u_u(g_15, l_49)) ^ l_14), g_16[1][2])) && g_38) , l_57) <= g_38);
        }
    }
    else
    { /* block id: 25 */
        int8_t l_63 = 0x06L;
        g_64[0][1][2] &= (safe_rshift_func_uint8_t_u_u((safe_add_func_uint32_t_u_u(((0xC30F141BL && g_38) , 0x9BB2D3F5L), 1UL)), l_63));
        for (g_38 = 0; (g_38 <= 16); g_38 = safe_add_func_uint32_t_u_u(g_38, 1))
        { /* block id: 29 */
            uint32_t l_71[9] = {0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L,0xD0CFE8E9L};
            uint32_t l_72 = 18446744073709551615UL;
            int32_t l_81[10][4][4] = {{{0x64D162ABL,5L,5L,0x64D162ABL},{0xDE629050L,1L,0xB1619642L,(-1L)},{0x1E4501C6L,(-1L),(-1L),0xBD8D123FL},{(-1L),0xBD8D123FL,7L,0xBD8D123FL}},{{5L,(-1L),0x41400369L,(-1L)},{0x09DF947BL,1L,0xBD8D123FL,0x64D162ABL},{0x41400369L,5L,5L,5L},{0xBD8D123FL,0xBD8D123FL,0x1E4501C6L,1L}},{{(-1L),5L,0xBD8D123FL,(-1L)},{0x64D162ABL,0xDE629050L,0x09DF947BL,0xBD8D123FL},{0x8960E8A9L,0xDE629050L,0x8960E8A9L,(-1L)},{0xDE629050L,5L,7L,1L}},{{1L,0xBD8D123FL,0x64D162ABL,5L},{0x41400369L,0x64D162ABL,0x64D162ABL,0x41400369L},{1L,(-1L),7L,0x8960E8A9L},{0xDE629050L,0xB1619642L,0x8960E8A9L,0x1E4501C6L}},{{0x8960E8A9L,0x1E4501C6L,0x09DF947BL,0x1E4501C6L},{0x64D162ABL,0xB1619642L,0xBD8D123FL,0x8960E8A9L},{(-1L),(-1L),0x1E4501C6L,0x41400369L},{0xBD8D123FL,0x64D162ABL,5L,5L}},{{0xBD8D123FL,0xBD8D123FL,0x1E4501C6L,1L},{(-1L),5L,0xBD8D123FL,(-1L)},{0x64D162ABL,0xDE629050L,0x09DF947BL,0xBD8D123FL},{0x8960E8A9L,0xDE629050L,0x8960E8A9L,(-1L)}},{{0xDE629050L,5L,7L,1L},{1L,0xBD8D123FL,0x64D162ABL,5L},{0x41400369L,0x64D162ABL,0x64D162ABL,0x41400369L},{1L,(-1L),7L,0x8960E8A9L}},{{0xDE629050L,0xB1619642L,0x8960E8A9L,0x1E4501C6L},{0x8960E8A9L,0x1E4501C6L,0x09DF947BL,0x1E4501C6L},{0x64D162ABL,0xB1619642L,0xBD8D123FL,0x8960E8A9L},{(-1L),(-1L),0x1E4501C6L,0x41400369L}},{{0xBD8D123FL,0x64D162ABL,5L,5L},{0xBD8D123FL,0xBD8D123FL,0x1E4501C6L,1L},{(-1L),5L,0xBD8D123FL,(-1L)},{0x64D162ABL,0xDE629050L,0x09DF947BL,0xBD8D123FL}},{{0x8960E8A9L,0xDE629050L,0x8960E8A9L,(-1L)},{0xDE629050L,5L,7L,1L},{1L,0xBD8D123FL,0x64D162ABL,5L},{0x41400369L,0x64D162ABL,0x64D162ABL,0x41400369L}}};
            int i, j, k;
            l_72 = ((safe_sub_func_uint16_t_u_u((((safe_sub_func_uint32_t_u_u((g_16[1][1] && g_64[4][3][1]), l_14)) != g_16[3][1]) , l_63), g_16[3][1])) == l_71[6]);
            l_81[1][3][1] |= ((safe_div_func_uint32_t_u_u(((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_add_func_uint64_t_u_u(((0xFA8C4D3BBE6313C7LL < l_71[3]) , l_71[1]), 7UL)), 3)), l_17)) == l_71[6]), l_71[6])) && l_72);
        }
        l_84 = ((safe_mod_func_uint16_t_u_u((l_50 <= 0xEB113692L), l_14)) && g_16[3][1]);
    }
    g_85[0] = ((g_16[3][1] , 3UL) <= l_49);
    g_92 ^= ((safe_add_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(g_85[0], l_14)), g_85[0])), l_17)) <= l_14);
    if ((g_16[1][1] < g_16[3][1]))
    { /* block id: 37 */
        int8_t l_93[9][5][5] = {{{(-1L),0x04L,0x04L,(-5L),0xBEL},{1L,(-1L),5L,0xA3L,(-10L)},{0x04L,8L,0x4CL,(-1L),(-1L)},{1L,(-1L),(-9L),1L,0x0AL},{(-1L),0x7DL,0xB9L,8L,0L}},{{0x43L,4L,0x43L,0x0AL,1L},{0L,(-7L),0x14L,1L,0xBEL},{0L,0x77L,1L,(-10L),0xA3L},{0x30L,(-5L),0x14L,(-1L),(-4L)},{(-1L),1L,0x43L,0xCDL,0x60L}},{{0xCDL,0x32L,0xB9L,0x32L,0xCDL},{0x70L,0x43L,1L,0x0AL,(-1L)},{0x4CL,0x01L,0xB9L,0x04L,0x52L},{0x28L,(-1L),0L,0x43L,(-1L)},{0L,0x04L,0x23L,(-1L),0L}},{{(-1L),6L,0x0AL,0x70L,0x0AL},{1L,0xE9L,0L,(-7L),0x14L},{(-2L),0x60L,1L,0x0AL,0x60L},{6L,5L,9L,(-1L),0x84L},{1L,0x60L,0L,0x0AL,(-1L)}},{{0x23L,0xE9L,0xE2L,0xB9L,0x04L},{(-9L),6L,6L,(-9L),0xE6L},{0x14L,0x04L,(-1L),0xE9L,0x30L},{(-2L),(-1L),(-3L),0xE6L,1L},{0x30L,0x01L,7L,0xE9L,0x84L}},{{0x70L,0x43L,0x77L,(-9L),0x28L},{0L,(-1L),0x84L,0xB9L,6L},{0x60L,5L,(-1L),0x0AL,0x0AL},{0xAFL,0x0CL,(-1L),(-1L),0x4CL},{(-1L),0x70L,5L,0x0AL,0x43L}},{{0xAFL,0x01L,0x97L,(-7L),0x52L},{0x60L,(-9L),0L,0x70L,0x70L},{0L,0x94L,0L,(-1L),0xAFL},{0x70L,6L,0xE6L,0x43L,0x0AL},{0x30L,7L,0L,0x04L,0xBEL}},{{(-2L),0x0AL,0xE6L,0x0AL,0x0AL},{0x14L,5L,0L,(-1L),0x84L},{(-9L),0x28L,0L,0x28L,(-9L)},{0x23L,1L,0x97L,0xB9L,1L},{1L,6L,5L,1L,0xE6L}},{{6L,(-7L),(-1L),1L,1L},{(-2L),1L,(-1L),0xE6L,(-9L)},{1L,0x01L,0x84L,7L,0x84L},{(-1L),(-1L),0x77L,(-1L),0x0AL},{0L,(-1L),7L,0xB9L,0xBEL}}};
        int i, j, k;
        l_93[0][2][3] = (0xA52B8ED3L && g_15);
    }
    else
    { /* block id: 39 */
        uint16_t l_97 = 65535UL;
        int32_t l_103 = 4L;
        g_94 = g_92;
        l_97 = ((((safe_div_func_uint32_t_u_u(g_64[0][1][2], l_49)) || g_16[2][1]) > 0x09L) && g_85[0]);
        l_102 = (safe_mul_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u(((g_16[3][2] || 253UL) >= g_16[0][0]), 18446744073709551615UL)) < l_97), l_97));
        l_103 = ((1UL != g_92) <= 0x06C70737C935D89ALL);
    }
    return g_94;
}


/* ------------------------------------------ */
/* 
 * reads : g_15
 * writes:
 */
static int32_t  func_2(uint16_t  p_3, int32_t  p_4, int16_t  p_5, int32_t  p_6)
{ /* block id: 15 */
    int32_t l_47[2];
    int i;
    for (i = 0; i < 2; i++)
        l_47[i] = 0x76A5D0C9L;
    l_47[1] = ((safe_add_func_uint32_t_u_u((((safe_div_func_uint64_t_u_u((0UL >= 0UL), l_47[1])) <= 1UL) ^ p_6), g_15)) , p_4);
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_16
 * writes: g_38
 */
static uint16_t  func_7(uint16_t  p_8, int16_t  p_9, const int8_t  p_10, int16_t  p_11)
{ /* block id: 1 */
    uint32_t l_25[4];
    int32_t l_39 = (-6L);
    int i;
    for (i = 0; i < 4; i++)
        l_25[i] = 0x41B44ADCL;
    l_39 |= (safe_lshift_func_uint8_t_u_u((func_20(l_25[1], l_25[1], g_15, g_16[3][1]) , 0UL), 6));
    l_39 &= (((!((safe_mul_func_uint8_t_u_u(p_11, 0xCAL)) , l_25[1])) && 0UL) ^ 1UL);
    return l_25[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_16
 * writes: g_38
 */
static uint32_t  func_20(uint32_t  p_21, int8_t  p_22, uint32_t  p_23, uint32_t  p_24)
{ /* block id: 2 */
    uint8_t l_33 = 0xA6L;
    for (p_24 = (-12); (p_24 == 23); p_24 = safe_add_func_uint32_t_u_u(p_24, 3))
    { /* block id: 5 */
        uint8_t l_34 = 254UL;
        g_38 = func_28(l_33, l_34, p_24, p_21);
    }
    return g_16[3][1];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_28(uint32_t  p_29, uint32_t  p_30, uint32_t  p_31, int64_t  p_32)
{ /* block id: 6 */
    uint32_t l_35[1][10][6] = {{{4294967295UL,9UL,9UL,4294967295UL,0x4BA09A16L,0UL},{0x4BA09A16L,4294967295UL,9UL,9UL,4294967295UL,0x4BA09A16L},{0x4BA09A16L,9UL,0UL,4294967295UL,4294967295UL,0UL},{4294967295UL,4294967295UL,0UL,9UL,0x4BA09A16L,0x4BA09A16L},{4294967295UL,9UL,9UL,4294967295UL,0x4BA09A16L,0UL},{0x4BA09A16L,4294967295UL,9UL,9UL,4294967295UL,0x4BA09A16L},{0x4BA09A16L,9UL,0UL,4294967295UL,4294967295UL,0UL},{4294967295UL,4294967295UL,0UL,9UL,0x4BA09A16L,0x4BA09A16L},{4294967295UL,9UL,9UL,4294967295UL,0x4BA09A16L,0UL},{0x4BA09A16L,4294967295UL,9UL,9UL,4294967295UL,0x4BA09A16L}}};
    int i, j, k;
    l_35[0][1][5]--;
    return p_30;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_16[i][j], "g_16[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_38, "g_38", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_64[i][j][k], "g_64[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_85[i], "g_85[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 29
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 5
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 5
   depth: 6, occurrence: 1
   depth: 7, occurrence: 4
   depth: 9, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 77
XXX times a non-volatile is write: 21
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 34
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 11
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 29.9
XXX percentage an existing variable is used: 70.1
********************* end of statistics **********************/

