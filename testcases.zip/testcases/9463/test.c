/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13454515451103408958
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_4 = 251UL;
static uint32_t g_9 = 0UL;
static uint8_t g_10[5][2][5] = {{{0x3EL,253UL,0UL,1UL,0UL},{0xBBL,0xBBL,0xA8L,246UL,255UL}},{{0x3EL,0UL,0xABL,0xAAL,0xAAL},{246UL,0x1BL,246UL,254UL,0UL}},{{0xABL,0UL,0x3EL,255UL,0x74L},{0xA8L,0xBBL,0xBBL,0xA8L,246UL}},{{0UL,253UL,0x3EL,0x74L,0UL},{1UL,0x18L,246UL,0x18L,1UL}},{{253UL,255UL,0xABL,0x74L,8UL},{0x1FL,0xA8L,0xBBL,0xBBL,0xA8L}}};
static uint64_t g_16 = 0x3F30045702377D64LL;
static int32_t g_42 = (-2L);
static int32_t g_44 = (-1L);
static uint8_t g_48 = 7UL;
static volatile int16_t g_50 = 0x92C2L;/* VOLATILE GLOBAL g_50 */
static uint64_t g_71 = 0x0AE94942BEBA8472LL;
static uint32_t g_73 = 0xA51C30C3L;
static int8_t g_91 = 0x76L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_17(int32_t  p_18, uint16_t  p_19, const uint64_t  p_20, uint64_t  p_21, uint8_t  p_22);
static uint8_t  func_25(uint64_t  p_26);
static int32_t  func_32(uint32_t  p_33, int8_t  p_34, int16_t  p_35, uint64_t  p_36, uint64_t  p_37);
static int32_t  func_63(int64_t  p_64, uint8_t  p_65);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_9 g_16 g_48 g_50 g_42 g_71 g_73 g_44 g_91
 * writes: g_9 g_10 g_16 g_42 g_44 g_48 g_50 g_71 g_73 g_91
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2 = 0UL;
    int32_t l_3 = 0x473EB905L;
    uint64_t l_94[7][6] = {{18446744073709551614UL,0x135235ED9E4BB11ELL,18446744073709551615UL,0x262CCAF28F66BB0FLL,0x135235ED9E4BB11ELL,0x866F533643AD1FF0LL},{0x0316972AE3155336LL,0x866F533643AD1FF0LL,18446744073709551615UL,18446744073709551614UL,1UL,1UL},{0x8C8EF010E3964532LL,0x866F533643AD1FF0LL,0x866F533643AD1FF0LL,0x8C8EF010E3964532LL,0x135235ED9E4BB11ELL,0UL},{0x8C8EF010E3964532LL,0x135235ED9E4BB11ELL,0UL,18446744073709551614UL,0x866F533643AD1FF0LL,0UL},{0x0316972AE3155336LL,1UL,0x866F533643AD1FF0LL,0x262CCAF28F66BB0FLL,0x866F533643AD1FF0LL,1UL},{18446744073709551614UL,0x135235ED9E4BB11ELL,18446744073709551615UL,0x262CCAF28F66BB0FLL,0x135235ED9E4BB11ELL,0x866F533643AD1FF0LL},{0x0316972AE3155336LL,0x866F533643AD1FF0LL,18446744073709551615UL,18446744073709551614UL,1UL,1UL}};
    const int64_t l_103[9] = {0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL,0x82A09A2E5C1CDF14LL};
    int i, j;
    l_3 ^= (l_2 < l_2);
    if (g_4)
    { /* block id: 2 */
        g_9 = ((safe_div_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(0x44L, 6)) , l_2), g_4)) >= 248UL);
        g_10[4][0][1] &= l_2;
    }
    else
    { /* block id: 5 */
        int32_t l_12 = 2L;
        if (g_10[4][0][1])
        { /* block id: 6 */
            uint16_t l_11 = 0x2FE8L;
            l_3 = 4L;
            return l_11;
        }
        else
        { /* block id: 9 */
            uint8_t l_15 = 249UL;
            l_12 = 0x06986D6DL;
            g_16 = (safe_rshift_func_uint8_t_u_u((((0xB15D3E99L ^ l_15) ^ l_2) || g_9), l_12));
        }
        g_91 |= func_17((safe_div_func_uint8_t_u_u(func_25((l_2 ^ l_2)), 0xC8L)), g_10[4][0][1], g_16, g_10[4][0][1], l_12);
        l_3 &= (safe_add_func_uint16_t_u_u(g_48, 0x3E25L));
        return l_94[4][0];
    }
    l_3 = (safe_mul_func_uint16_t_u_u((((g_91 < 0UL) != g_4) >= 8UL), l_94[4][0]));
    l_3 = ((safe_div_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(((l_94[4][2] >= 6UL) , 0x59B5L), l_94[4][0])), l_103[1])) ^ 65531UL), g_9)) , g_4);
    return l_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_48 g_10 g_4 g_50 g_42 g_71 g_73 g_44
 * writes: g_44 g_48 g_50 g_42 g_71 g_73
 */
static int32_t  func_17(int32_t  p_18, uint16_t  p_19, const uint64_t  p_20, uint64_t  p_21, uint8_t  p_22)
{ /* block id: 23 */
    uint16_t l_43 = 0xCA54L;
    int64_t l_49[6] = {1L,1L,1L,1L,1L,1L};
    int32_t l_55 = 0x0C7F43A4L;
    int i;
    g_44 = (l_43 , l_43);
lbl_90:
    if (l_43)
    { /* block id: 25 */
        int32_t l_47[10][10] = {{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL},{0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL,0x0D8167E6L,4L,4L,0x0D8167E6L,0xD0AE446FL}};
        int i, j;
        l_47[1][4] = (safe_add_func_uint8_t_u_u((0xD2A48B7552F0C8C5LL == p_19), p_19));
        g_48 = (0UL && g_16);
        return l_49[0];
    }
    else
    { /* block id: 29 */
        uint32_t l_60 = 0xFF04C396L;
        for (p_22 = 0; (p_22 <= 5); p_22 += 1)
        { /* block id: 32 */
            int32_t l_61 = 1L;
            int i;
            g_50 = 0xF5F1E611L;
            l_55 &= (safe_mod_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u(0xB711L, 4)), 2UL));
            l_60 = ((safe_mul_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_u((l_49[p_22] <= p_20), 4)) ^ 4UL), l_55)) , g_48);
            l_61 = (p_21 > p_18);
        }
        if (((+func_25((l_49[0] && 0xAA3AL))) || g_4))
        { /* block id: 38 */
            return l_60;
        }
        else
        { /* block id: 40 */
            int32_t l_72 = 0x625F1A37L;
            l_72 &= func_63(g_4, g_50);
            ++g_73;
        }
        l_55 ^= ((safe_lshift_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((((safe_mod_func_uint32_t_u_u(g_50, 0x99CBC132L)) == g_10[4][0][1]) , 0xA1L), g_4)), 0)) ^ 18446744073709551615UL), 0xBC9EF25AL)), 0)) == g_44);
        l_55 = (safe_mul_func_uint16_t_u_u((p_22 == 65530UL), g_71));
    }
    l_55 = (((safe_add_func_uint64_t_u_u(l_49[2], g_50)) != g_42) && g_48);
    if (l_43)
        goto lbl_90;
    return g_10[2][0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_10
 * writes: g_42
 */
static uint8_t  func_25(uint64_t  p_26)
{ /* block id: 13 */
    uint32_t l_31 = 18446744073709551609UL;
    int64_t l_38 = 1L;
    int32_t l_41 = 0x3333DB96L;
    l_31 = (safe_div_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(1UL, 12)), 65535UL));
    l_41 |= func_32(g_16, l_38, g_10[4][0][1], g_10[2][1][0], p_26);
    g_42 = 0x4730E92FL;
    return g_10[4][0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_10
 * writes:
 */
static int32_t  func_32(uint32_t  p_33, int8_t  p_34, int16_t  p_35, uint64_t  p_36, uint64_t  p_37)
{ /* block id: 15 */
    int32_t l_39 = 0x461D0EE3L;
    int32_t l_40 = 0L;
    l_40 = ((l_39 < l_39) , p_37);
    l_40 = (18446744073709551615UL || p_36);
    l_40 = g_10[3][1][3];
    return g_10[2][0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_71
 * writes: g_71
 */
static int32_t  func_63(int64_t  p_64, uint8_t  p_65)
{ /* block id: 41 */
    int32_t l_68[9][1] = {{1L},{0xE333AB1AL},{0xE333AB1AL},{1L},{0xE333AB1AL},{0xE333AB1AL},{1L},{0xE333AB1AL},{0xE333AB1AL}};
    const int8_t l_69[9][10] = {{0xB0L,0L,0x14L,6L,(-2L),(-1L),(-1L),(-2L),6L,0x14L},{3L,3L,0x19L,(-2L),(-10L),0x5AL,0x0DL,3L,0x18L,0x0DL},{0L,0x3EL,0x19L,0x14L,0x3EL,7L,0x44L,7L,0x3EL,0x14L},{0x5AL,0xB6L,0x5AL,0x19L,0x44L,0x18L,0x19L,0xB0L,0L,0x5AL},{0xB0L,(-3L),(-10L),(-1L),0xB6L,0L,0xB0L,0xB0L,0L,0xB6L},{(-3L),0x5AL,0x5AL,(-3L),0L,0x3EL,0xB6L,7L,0x5AL,0xB0L},{0L,0xB0L,0x19L,0x18L,0x44L,0x19L,0x5AL,0xB6L,0x5AL,0x19L},{(-1L),(-3L),3L,(-3L),(-1L),0x0DL,0x14L,(-1L),0L,0x44L},{0xB6L,0L,0x18L,(-1L),0xC4L,0x3EL,0x44L,0L,0L,0x44L}};
    const int16_t l_70[3] = {0xC45FL,0xC45FL,0xC45FL};
    int i, j;
    g_71 &= (safe_mul_func_uint16_t_u_u((((((l_68[1][0] == g_42) && 4294967295UL) && l_69[1][9]) != l_70[2]) && 255UL), l_68[1][0]));
    return l_68[1][0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_10[i][j][k], "g_10[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_91, "g_91", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 7
   depth: 3, occurrence: 6
   depth: 4, occurrence: 2
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 74
XXX times a non-volatile is write: 29
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 96.3

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 44
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 13
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 31.7
XXX percentage an existing variable is used: 68.3
********************* end of statistics **********************/

