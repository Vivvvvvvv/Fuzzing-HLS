/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8640939742393096107
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 1L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 1L;/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = (-9L);
static volatile int32_t g_7 = (-1L);/* VOLATILE GLOBAL g_7 */
static volatile int32_t g_8 = (-10L);/* VOLATILE GLOBAL g_8 */
static int32_t g_9 = 0x260417BEL;
static volatile int32_t g_23[8][9][3] = {{{(-1L),(-1L),0x90CC4B0BL},{0x473CB3F0L,0L,0x66AA6F69L},{4L,0x68A7991AL,7L},{0x7C4BD4ACL,4L,0L},{0x58C9E433L,7L,0xC5EFF0D5L},{(-9L),0x353AE792L,0xED6FA3C4L},{0x8C043881L,0x07C168B3L,0xED6FA3C4L},{0x7F748928L,(-1L),0xC5EFF0D5L},{0x1EDC6299L,(-10L),0L}},{{0x176A90D2L,3L,7L},{0x267C8CEAL,0x61F9DA97L,0x66AA6F69L},{(-1L),0x27F4FEF5L,0x90CC4B0BL},{0L,(-5L),(-9L)},{3L,0L,5L},{1L,0x1AD04870L,0x81CA5788L},{1L,0x3BE97B5CL,0x176A90D2L},{1L,0xC5EFF0D5L,0xED6FA3C4L},{(-6L),0x68A7991AL,0xD9846C24L}},{{0xC5EFF0D5L,(-5L),1L},{9L,0x81CA5788L,0x81CA5788L},{(-5L),0xF2C41E7DL,0x71B2A125L},{(-10L),0L,0L},{0x1EDC6299L,0x2D12977BL,7L},{(-1L),5L,(-1L)},{(-1L),0x2D12977BL,0x61F9DA97L},{0L,0L,(-1L)},{(-1L),0xF2C41E7DL,0x27F4FEF5L}},{{0x633F8A1CL,0x81CA5788L,0x07C168B3L},{(-1L),(-5L),1L},{0xF97A265DL,0x68A7991AL,0x90CC4B0BL},{0xA6C6106AL,0xC5EFF0D5L,0x353AE792L},{(-10L),0x3BE97B5CL,5L},{0x176A90D2L,0xC8CEE692L,(-1L)},{0x071C3330L,3L,0x893B2529L},{3L,0xC8B43F62L,0x82856065L},{0x1AD04870L,(-1L),1L}},{{(-1L),(-5L),1L},{0xE57CEC44L,1L,4L},{0x3BE97B5CL,0x8C043881L,(-5L)},{0x416071ECL,0x152F54C4L,0x7C4BD4ACL},{0x58C9E433L,(-2L),1L},{0x58C9E433L,0L,0x3BE97B5CL},{0x416071ECL,6L,1L},{0x3BE97B5CL,0x1EDC6299L,0L},{0xE57CEC44L,0x7C4BD4ACL,0x473CB3F0L}},{{(-1L),5L,(-1L)},{0x1AD04870L,0x833E6FCBL,(-1L)},{3L,0x552B10A2L,0x071C3330L},{0x071C3330L,0xC72F7145L,(-6L)},{0x176A90D2L,0x58C9E433L,(-1L)},{(-10L),(-1L),0xCA98D253L},{0xA6C6106AL,0xCA98D253L,0x152F54C4L},{0xF97A265DL,1L,0x059E6156L},{(-1L),(-7L),(-8L)}},{{0x633F8A1CL,0x633F8A1CL,5L},{(-1L),1L,0xC8B43F62L},{0L,7L,0L},{(-1L),5L,0x833E6FCBL},{(-1L),0L,0L},{0x1EDC6299L,0x416071ECL,0xC8B43F62L},{(-10L),(-8L),5L},{(-5L),4L,(-8L)},{9L,0L,0x059E6156L}},{{0xC5EFF0D5L,(-1L),0x152F54C4L},{(-6L),1L,0xCA98D253L},{1L,8L,(-1L)},{0x07C168B3L,4L,(-6L)},{0x059E6156L,0xA08D8D3BL,0x071C3330L},{1L,0x267C8CEAL,(-1L)},{1L,(-1L),(-1L)},{0x2D12977BL,1L,0x473CB3F0L},{0x552B10A2L,0x9DE24E56L,0L}}};
static int64_t g_24 = 1L;
static volatile uint64_t g_25[6] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint8_t  func_14(int64_t  p_15, uint16_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_3 g_25 g_2
 * writes: g_4 g_9 g_8 g_25 g_7 g_2
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_28 = 0L;
    for (g_4 = 7; (g_4 < (-11)); g_4 = safe_sub_func_uint32_t_u_u(g_4, 8))
    { /* block id: 3 */
        int32_t l_17 = 5L;
        int32_t l_32 = 1L;
        for (g_9 = 14; (g_9 != 14); g_9 = safe_add_func_uint64_t_u_u(g_9, 8))
        { /* block id: 6 */
            const int32_t l_31 = 0x8C926BDCL;
            g_7 = ((safe_lshift_func_uint8_t_u_u(func_14(g_4, l_17), g_9)) && l_28);
            l_32 = (safe_sub_func_uint8_t_u_u((0UL < 1UL), l_31));
        }
        g_7 = 0x84A18462L;
        g_2 |= l_32;
    }
    return l_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_25
 * writes: g_8 g_25
 */
static uint8_t  func_14(int64_t  p_15, uint16_t  p_16)
{ /* block id: 7 */
    int8_t l_21 = 0L;
    int32_t l_22[10][9][2] = {{{0xB30498D2L,0xB1F0CFADL},{0x46C64E71L,4L},{1L,1L},{(-3L),1L},{(-9L),(-1L)},{0x870AF03FL,0xB8DB370CL},{4L,0x870AF03FL},{0xF2EF51AEL,0x7974498BL},{(-1L),(-3L)}},{{0x33D2AFDDL,(-10L)},{(-3L),0xA1EE3199L},{0L,(-1L)},{1L,0x82EA9177L},{0x82EA9177L,0x33D2AFDDL},{0xB30498D2L,(-1L)},{0xE9A5A165L,0x82EA9177L},{0x63439FCBL,(-1L)},{0L,4L}},{{(-1L),(-10L)},{(-1L),(-1L)},{(-1L),0L},{(-7L),(-3L)},{(-1L),0x550032DCL},{(-3L),4L},{0xAF19195CL,(-1L)},{0x63439FCBL,0xE9A5A165L},{0x82EA9177L,(-1L)}},{{6L,(-1L)},{0x82EA9177L,0xE9A5A165L},{0x63439FCBL,(-1L)},{0xAF19195CL,4L},{(-3L),0x550032DCL},{(-1L),(-3L)},{(-7L),0L},{(-1L),(-1L)},{(-1L),(-10L)}},{{(-1L),4L},{0L,(-1L)},{0x63439FCBL,0x82EA9177L},{0xE9A5A165L,(-1L)},{0xB30498D2L,0x33D2AFDDL},{0x82EA9177L,0x82EA9177L},{1L,(-1L)},{0L,0xA1EE3199L},{(-3L),(-10L)}},{{0x33D2AFDDL,(-3L)},{(-1L),0x7974498BL},{(-1L),(-3L)},{0x33D2AFDDL,(-10L)},{(-3L),0xA1EE3199L},{0L,(-1L)},{1L,0x82EA9177L},{0x82EA9177L,0x33D2AFDDL},{0xB30498D2L,(-1L)}},{{0xE9A5A165L,0x82EA9177L},{0x63439FCBL,(-1L)},{0L,4L},{(-1L),(-10L)},{(-1L),(-1L)},{(-1L),0L},{(-7L),(-3L)},{(-1L),0x550032DCL},{(-3L),4L}},{{0xAF19195CL,(-1L)},{0x63439FCBL,0xE9A5A165L},{0x82EA9177L,(-1L)},{6L,(-1L)},{0x82EA9177L,0xE9A5A165L},{0x63439FCBL,(-1L)},{0xAF19195CL,4L},{(-3L),0x550032DCL},{(-1L),(-3L)}},{{(-7L),0L},{(-1L),(-1L)},{(-1L),(-10L)},{(-1L),4L},{0L,(-1L)},{0x63439FCBL,0x82EA9177L},{0xE9A5A165L,(-1L)},{0xB30498D2L,0x33D2AFDDL},{0x82EA9177L,0x82EA9177L}},{{1L,(-1L)},{0L,0xA1EE3199L},{(-3L),(-10L)},{0x33D2AFDDL,(-3L)},{(-1L),0x7974498BL},{(-1L),(-3L)},{0x33D2AFDDL,(-10L)},{(-3L),0xA1EE3199L},{0L,(-1L)}}};
    int i, j, k;
    for (p_15 = 0; (p_15 == 11); p_15 = safe_add_func_uint64_t_u_u(p_15, 1))
    { /* block id: 10 */
        uint64_t l_20 = 5UL;
        l_20 &= ((p_16 < p_16) , g_3);
        g_8 = (p_16 <= g_4);
    }
    g_25[4]++;
    l_22[1][1][0] = (((0UL < p_15) ^ 0x97L) || p_16);
    return g_25[4];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_23[i][j][k], "g_23[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_24, "g_24", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 16
XXX times a non-volatile is write: 6
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 75.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 5
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 24.4
XXX percentage an existing variable is used: 75.6
********************* end of statistics **********************/

