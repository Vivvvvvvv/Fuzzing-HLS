/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3545641384041724126
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int32_t  f0;
   int32_t  f1;
   volatile uint32_t  f2;
   const uint16_t  f3;
   volatile uint16_t  f4;
   uint8_t  f5;
   volatile uint32_t  f6;
   int32_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_10[8][8][3] = {{{0x3CD4FE93L,0xAB79AE4FL,0x234AC019L},{18446744073709551611UL,0x6D20A2E7L,0UL},{0xF9E84EBFL,0x1D0EE3B0L,0xFFAF0720L},{0x2A04F777L,0xD4475678L,0x1D0EE3B0L},{0xB7228D02L,0x5680A256L,0x2ABAC89DL},{18446744073709551609UL,0x5452E2CCL,18446744073709551606UL},{0x86D6DBC1L,7UL,0UL},{1UL,18446744073709551608UL,0xB4CCC414L}},{{1UL,1UL,18446744073709551609UL},{0x86D6DBC1L,0x7504ED09L,8UL},{18446744073709551609UL,1UL,0x01213072L},{0xB7228D02L,18446744073709551615UL,18446744073709551610UL},{0x2A04F777L,18446744073709551613UL,0x8CAE2FE8L},{0xF9E84EBFL,0x4648A574L,0x7DCD66A0L},{18446744073709551611UL,0x0133ECB4L,0x3CD4FE93L},{0x3CD4FE93L,1UL,4UL}},{{18446744073709551609UL,0xCC545E21L,0x0AECAA70L},{0x7DCD66A0L,18446744073709551611UL,0xC2076ACBL},{18446744073709551609UL,18446744073709551609UL,0x67F6A191L},{0xFFAF0720L,0x91260E2EL,0x46AA1DD5L},{0x131B3B33L,1UL,1UL},{0xE8E60A2FL,0xCC545E21L,0x3DB9622CL},{18446744073709551608UL,0x131B3B33L,1UL},{1UL,18446744073709551608UL,0x46AA1DD5L}},{{0UL,0x86D6DBC1L,0x67F6A191L},{18446744073709551610UL,3UL,0xC2076ACBL},{0xC9FA8BC0L,18446744073709551615UL,0x0AECAA70L},{18446744073709551608UL,0xAB61B583L,4UL},{0x46BD29A2L,0x0133ECB4L,0x6CEDDA56L},{0UL,0x67F6A191L,0x131B3B33L},{0UL,0x1C17C774L,0x3E763161L},{0x234AC019L,0x711A53FDL,0x8CAE2FE8L}},{{0x7DCD66A0L,0x131B3B33L,4UL},{1UL,18446744073709551611UL,1UL},{0x8CAE2FE8L,18446744073709551611UL,1UL},{0x91260E2EL,0x702377D6L,0x53D8B3D3L},{0xFFAF0720L,0x702377D6L,0x01213072L},{1UL,18446744073709551611UL,1UL},{0x46BD29A2L,18446744073709551611UL,18446744073709551610UL},{0x1C3D076CL,0x131B3B33L,0x91260E2EL}},{{0xB818F8F6L,0x711A53FDL,0xB64730E9L},{0UL,0x1C17C774L,18446744073709551610UL},{8UL,0x67F6A191L,0xC2076ACBL},{1UL,0x0133ECB4L,1UL},{0x1C3D076CL,0xAB61B583L,4UL},{0xAB61B583L,18446744073709551615UL,0x5452E2CCL},{0UL,3UL,0UL},{0x0133ECB4L,0x86D6DBC1L,0x3E763161L}},{{18446744073709551609UL,18446744073709551608UL,0x6CEDDA56L},{0x8CAE2FE8L,0x131B3B33L,4UL},{0x86D6DBC1L,0xCC545E21L,18446744073709551615UL},{0x8CAE2FE8L,1UL,0x1C3D076CL},{18446744073709551609UL,0x91260E2EL,0x53D8B3D3L},{0x0133ECB4L,18446744073709551609UL,0x46AA1DD5L},{0UL,18446744073709551611UL,0x91260E2EL},{0xAB61B583L,0xCC545E21L,0UL}},{{0x1C3D076CL,1UL,0x234AC019L},{1UL,0x46AA1DD5L,0xB64730E9L},{8UL,1UL,0x67F6A191L},{0UL,0x67F6A191L,1UL},{0xB818F8F6L,18446744073709551615UL,18446744073709551615UL},{0x1C3D076CL,0xD4475678L,0x9CDE30ECL},{0x46BD29A2L,0UL,0x5452E2CCL},{1UL,0x5680A256L,0x131B3B33L}}};
static const uint8_t g_12 = 0UL;
static struct S0 g_35[7][8] = {{{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L}},{{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L}},{{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{0xC9D536C3L,0xC5B6CC60L,0x97593EB6L,65535UL,7UL,0xDFL,0UL,1L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xC9D536C3L,0xC5B6CC60L,0x97593EB6L,65535UL,7UL,0xDFL,0UL,1L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L}},{{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L}},{{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L}},{{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{0xC9D536C3L,0xC5B6CC60L,0x97593EB6L,65535UL,7UL,0xDFL,0UL,1L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{0xC7BDE7BCL,0L,0UL,3UL,2UL,9UL,0x70674D57L,7L},{1L,-3L,0xC05799F9L,0x51C3L,0xC3E4L,0UL,3UL,0x817F253AL},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L}},{{1L,0xCC26152DL,8UL,1UL,65535UL,1UL,0UL,0L},{0xCF4EDB98L,1L,0x33643AD1L,65530UL,2UL,0UL,0x10E39645L,-8L},{0xC9D536C3L,0xC5B6CC60L,0x97593EB6L,65535UL,7UL,0xDFL,0UL,1L},{1L,0xCC26152DL,8UL,1UL,65535UL,1UL,0UL,0L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L},{0xC9D536C3L,0xC5B6CC60L,0x97593EB6L,65535UL,7UL,0xDFL,0UL,1L},{0xC9D536C3L,0xC5B6CC60L,0x97593EB6L,65535UL,7UL,0xDFL,0UL,1L},{4L,0xE333AB1AL,0xF13F3F2CL,65535UL,0x6281L,0x62L,0x3DCCD505L,3L}}};
static const int32_t g_52 = (-1L);
static volatile uint64_t g_55 = 0UL;/* VOLATILE GLOBAL g_55 */
static int8_t g_67 = 0xF1L;
static int32_t g_68[10][1] = {{(-1L)},{6L},{2L},{6L},{(-1L)},{(-1L)},{6L},{2L},{6L},{(-1L)}};
static volatile int8_t g_71[9] = {0x90L,0x90L,0x90L,0x90L,0x90L,0x90L,0x90L,0x90L,0x90L};
static int64_t g_73[2][7][6] = {{{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL},{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL},{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL},{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL},{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL},{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL},{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL}},{{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL},{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL},{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL},{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL},{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL},{0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL,0xD1488185611DFC2BLL,0x8AD55D9A899DE236LL},{(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL,(-1L),0x8AD55D9A899DE236LL}}};
static int64_t g_76[8] = {0xBA2A9BA58C66C539LL,(-6L),0xBA2A9BA58C66C539LL,0xBA2A9BA58C66C539LL,(-6L),0xBA2A9BA58C66C539LL,0xBA2A9BA58C66C539LL,(-6L)};
static int8_t g_78 = 0L;
static int32_t g_79 = 1L;
static volatile int32_t g_82 = 0x759CC73FL;/* VOLATILE GLOBAL g_82 */
static uint64_t g_83[8][6] = {{0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL},{0UL,1UL,0UL,1UL,0UL,1UL},{0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL},{0UL,1UL,0UL,1UL,0UL,1UL},{0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL},{0UL,1UL,0UL,1UL,0UL,1UL},{0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL,0x5B41805AE8A67A0ELL,1UL},{0UL,1UL,0UL,1UL,0UL,1UL}};
static uint32_t g_110 = 0x97A6A314L;
static int32_t g_147[10] = {0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L,0x5ED28508L};
static int32_t g_148 = 0x3CA6D3C6L;
static int16_t g_149 = 0x997DL;
static uint32_t g_151 = 0xEBF1156FL;
static volatile uint64_t g_172 = 1UL;/* VOLATILE GLOBAL g_172 */
static uint32_t g_181 = 0x262F6884L;
static volatile int32_t g_204 = 0x83CE62D5L;/* VOLATILE GLOBAL g_204 */
static volatile int16_t g_224 = 0L;/* VOLATILE GLOBAL g_224 */
static uint16_t g_225 = 0xCA08L;
static const uint8_t g_275[7] = {0x42L,0x42L,0x42L,0x42L,0x42L,0x42L,0x42L};
static int32_t g_284[2][6][5] = {{{0xB021E3EDL,0xB021E3EDL,0xBC8BBD86L,0x958A52B3L,0xD7D04A55L},{2L,0xCE39DFC4L,0x4639052BL,(-1L),0xCE39DFC4L},{0xF58D6F8AL,1L,0x7C6E5AD4L,0xCE39DFC4L,(-1L)},{(-1L),0xCE39DFC4L,0xF928766DL,0xD7D04A55L,0x958A52B3L},{0x942EDEBCL,1L,0x6AE4ED8CL,(-1L),(-5L)},{0xD4616730L,0x6AE4ED8CL,0x6AE4ED8CL,0xD4616730L,(-5L)}},{{0xD7D04A55L,(-1L),0xF928766DL,1L,0xCE3962BDL},{2L,0x958A52B3L,0x7C6E5AD4L,(-5L),(-1L)},{0xCE3962BDL,0x6AE4ED8CL,0x4639052BL,1L,(-1L)},{(-5L),0xCE3962BDL,0x6CFC8072L,0xD4616730L,0xF58D6F8AL},{2L,0xF58D6F8AL,(-1L),(-1L),0xF58D6F8AL},{0xCE39DFC4L,1L,0x942EDEBCL,0xD7D04A55L,(-1L)}}};
static int8_t g_285 = (-1L);
static int32_t g_286 = 0x6CCAD6F9L;
static int64_t g_288[7] = {0x9B85E786ED6AA910LL,0x9B85E786ED6AA910LL,0x9B85E786ED6AA910LL,0x9B85E786ED6AA910LL,0x9B85E786ED6AA910LL,0x9B85E786ED6AA910LL,0x9B85E786ED6AA910LL};
static uint8_t g_290 = 0x54L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(uint8_t  p_3, uint64_t  p_4, uint64_t  p_5, const uint64_t  p_6, int8_t  p_7);
static int8_t  func_16(int8_t  p_17);
static int32_t  func_21(int64_t  p_22, int32_t  p_23, uint32_t  p_24, uint16_t  p_25);
static struct S0  func_29(uint64_t  p_30, uint32_t  p_31);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_35 g_52 g_55 g_83 g_67 g_76 g_110 g_71 g_151 g_79 g_73 g_172 g_68 g_181 g_82 g_148 g_78 g_149 g_147 g_225 g_204 g_275 g_290
 * writes: g_35.f7 g_55 g_83 g_35.f0 g_110 g_151 g_172 g_67 g_148 g_78 g_225 g_204 g_290
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_11 = 0x4BL;
    int32_t l_282 = 9L;
    int32_t l_283[10] = {0x13B3005CL,0xBDE1BF11L,1L,0xBDE1BF11L,0x13B3005CL,0x13B3005CL,0xBDE1BF11L,1L,0xBDE1BF11L,0x13B3005CL};
    int32_t l_287 = 1L;
    int8_t l_289[4];
    int i;
    for (i = 0; i < 4; i++)
        l_289[i] = 1L;
    g_35[6][7].f0 = ((func_2((safe_div_func_int8_t_s_s((g_10[0][4][0] || l_11), l_11)), l_11, l_11, g_12, g_12) , g_35[6][7].f7) <= (-10L));
    g_290--;
    for (g_78 = (-26); (g_78 == 15); g_78 = safe_add_func_int16_t_s_s(g_78, 1))
    { /* block id: 154 */
        int32_t l_299 = 0x0AE462C7L;
        uint64_t l_300 = 18446744073709551612UL;
        for (l_282 = 0; (l_282 <= 2); l_282 += 1)
        { /* block id: 157 */
            int32_t l_303 = (-1L);
            l_283[4] = ((((safe_add_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(l_11, l_299)), g_71[3])) && g_73[0][6][2]) != l_299) && l_300);
            l_283[2] = (safe_rshift_func_uint8_t_u_s(0UL, 3));
            l_283[4] ^= g_149;
            l_303 = g_83[2][2];
        }
        if (g_83[5][0])
        { /* block id: 163 */
            return g_68[5][0];
        }
        else
        { /* block id: 165 */
            l_283[4] ^= ((safe_sub_func_uint32_t_u_u(0x22CBC8A1L, l_289[0])) > g_83[5][2]);
            return g_147[7];
        }
    }
    return g_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_35 g_52 g_55 g_83 g_67 g_76 g_110 g_71 g_151 g_79 g_73 g_172 g_68 g_181 g_82 g_148 g_78 g_149 g_147 g_225 g_204 g_275
 * writes: g_35.f7 g_55 g_83 g_35.f0 g_110 g_151 g_172 g_67 g_148 g_78 g_225 g_204
 */
static int32_t  func_2(uint8_t  p_3, uint64_t  p_4, uint64_t  p_5, const uint64_t  p_6, int8_t  p_7)
{ /* block id: 1 */
    uint64_t l_13 = 18446744073709551615UL;
    int32_t l_202 = 0x0B1DFA8FL;
    int32_t l_205 = 0L;
    int32_t l_228 = 0x85E5775FL;
    uint8_t l_229 = 1UL;
    l_13++;
    if (((func_16(g_10[0][4][0]) & p_3) & 7UL))
    { /* block id: 102 */
        int8_t l_201 = 0x28L;
        int32_t l_203[5];
        uint64_t l_206 = 0xD8598E06BF6E393ALL;
        int i;
        for (i = 0; i < 5; i++)
            l_203[i] = 0xC50ED1BEL;
        --l_206;
        if ((g_76[6] , 1L))
        { /* block id: 104 */
            l_202 = p_7;
            g_35[6][7].f0 = (l_206 | g_110);
        }
        else
        { /* block id: 107 */
            g_35[6][7].f0 = (((safe_rshift_func_uint16_t_u_s(((((safe_mod_func_int16_t_s_s((+0x0BC355EAF38123D7LL), l_202)) <= p_6) , g_149) && (-1L)), p_7)) || 0xF3D6L) , 0x27E377B8L);
        }
        if (g_147[7])
        { /* block id: 110 */
            int8_t l_218 = 0L;
            int32_t l_219 = 0xA3309937L;
            l_219 = ((safe_mod_func_int64_t_s_s((safe_mul_func_int8_t_s_s(l_218, l_218)), g_73[1][0][1])) && 3UL);
            return g_73[1][2][3];
        }
        else
        { /* block id: 113 */
            uint32_t l_221 = 9UL;
            l_221 = (~g_52);
        }
    }
    else
    { /* block id: 116 */
        int32_t l_222 = 0xC7C0F988L;
        int32_t l_223[5][9] = {{6L,4L,(-8L),0x62B98622L,2L,0xA0D352A7L,0x1CC5E253L,0xA0D352A7L,2L},{7L,0x1CC5E253L,0x1CC5E253L,7L,(-5L),4L,(-2L),2L,(-8L)},{6L,2L,0x1CC5E253L,0x6E348D3EL,0x6E348D3EL,0x1CC5E253L,2L,6L,0x2F2A417AL},{0x47D54846L,0x6E348D3EL,(-8L),6L,(-5L),2L,2L,(-5L),6L},{0x62B98622L,0x47D54846L,0x62B98622L,4L,2L,0x6E348D3EL,(-2L),0x2F2A417AL,0x2F2A417AL}};
        int i, j;
        ++g_225;
    }
    l_229--;
    if ((safe_div_func_uint64_t_u_u((((g_83[2][1] && p_7) | g_52) ^ 0x1459DAEEL), l_202)))
    { /* block id: 120 */
        const int32_t l_236 = 1L;
        l_205 &= (safe_mul_func_int16_t_s_s(((g_151 || l_236) , (-7L)), p_5));
        if ((safe_div_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(1UL, g_52)), l_236)))
        { /* block id: 122 */
            l_202 &= 0xAB348A6AL;
        }
        else
        { /* block id: 124 */
            int64_t l_241 = 0x8D1A8308682BDF8DLL;
            int32_t l_242[6] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
            int i;
            g_204 = (g_52 & g_71[3]);
            l_242[0] = (((l_241 & g_71[7]) ^ g_12) , 0xBF35C4B0L);
            return l_236;
        }
        l_202 |= (((g_52 ^ 0x18A4L) ^ p_5) > 0L);
        g_35[6][7].f0 &= ((safe_add_func_uint32_t_u_u(((((safe_lshift_func_uint8_t_u_s(0UL, 7)) < p_5) , l_236) , 0x69B9C6CFL), l_13)) != 0xFC1D8D492CE9E550LL);
    }
    else
    { /* block id: 131 */
        int16_t l_265 = 0x2117L;
        uint64_t l_280[6] = {0x63DD09485683FCD8LL,0x63DD09485683FCD8LL,0x63DD09485683FCD8LL,0x63DD09485683FCD8LL,0x63DD09485683FCD8LL,0x63DD09485683FCD8LL};
        int32_t l_281 = 1L;
        int i;
        for (g_110 = 0; (g_110 <= 35); g_110 = safe_add_func_uint8_t_u_u(g_110, 8))
        { /* block id: 134 */
            uint32_t l_253 = 1UL;
            int32_t l_254 = 0x485EE6CBL;
            l_254 = ((safe_add_func_uint32_t_u_u((safe_div_func_int32_t_s_s(((((g_67 >= 3UL) <= l_253) , l_253) > 0x3FL), p_6)), g_78)) > p_4);
            g_35[6][7].f7 = ((safe_mod_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((safe_div_func_uint32_t_u_u(l_253, 4294967295UL)), g_71[3])), l_254)) || 0x3FL);
            if (g_204)
                continue;
            l_265 = (safe_lshift_func_int16_t_s_s((safe_sub_func_uint16_t_u_u((((l_253 , 0x627330C4L) == l_254) || 1UL), l_13)), 15));
        }
        for (g_78 = 0; (g_78 <= 23); g_78++)
        { /* block id: 142 */
            uint64_t l_272 = 18446744073709551608UL;
            l_228 = (1UL >= p_5);
            g_35[6][7].f0 = (safe_rshift_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s(((g_35[6][7].f2 ^ 1L) && l_265), l_272)), p_7));
        }
        l_228 = ((safe_rshift_func_uint16_t_u_s(((g_83[5][2] || l_228) <= l_265), g_275[3])) >= l_265);
        l_281 |= ((safe_sub_func_int16_t_s_s((((safe_rshift_func_uint8_t_u_s((((l_280[5] & 4294967295UL) <= l_202) , 4UL), 1)) >= l_228) >= 5L), g_151)) ^ g_71[3]);
    }
    return g_35[6][7].f7;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_35 g_52 g_55 g_83 g_67 g_76 g_110 g_71 g_151 g_79 g_73 g_172 g_68 g_181 g_82 g_148 g_78
 * writes: g_35.f7 g_55 g_83 g_35.f0 g_110 g_151 g_172 g_67 g_148 g_78
 */
static int8_t  func_16(int8_t  p_17)
{ /* block id: 3 */
    uint16_t l_18 = 0x552FL;
    int16_t l_200 = 6L;
    ++l_18;
    if (func_21((((g_10[0][4][0] < l_18) >= (-1L)) | 0x6007B4AD293D0AE4LL), p_17, g_12, l_18))
    { /* block id: 78 */
        uint64_t l_183[2];
        int32_t l_191 = 5L;
        int i;
        for (i = 0; i < 2; i++)
            l_183[i] = 0xDB131245ED57654CLL;
        for (g_67 = 1; (g_67 > (-26)); g_67 = safe_sub_func_uint64_t_u_u(g_67, 2))
        { /* block id: 81 */
            const uint8_t l_182[1][7][5] = {{{0UL,0UL,1UL,249UL,0x60L},{4UL,0x02L,1UL,0x02L,4UL},{0x60L,249UL,1UL,0UL,0UL},{1UL,0x02L,1UL,0xA8L,1UL},{0x60L,0UL,249UL,249UL,0UL},{4UL,0xA8L,1UL,0xA8L,4UL},{0UL,249UL,249UL,0UL,0x60L}}};
            int i, j, k;
            g_35[6][7].f0 = (safe_div_func_int32_t_s_s((((0x043A5CBA9923A281LL | g_68[2][0]) , g_181) | l_182[0][2][4]), 0x06610828L));
            l_183[0] = g_79;
            g_35[6][7].f7 |= (safe_rshift_func_uint16_t_u_s((safe_div_func_uint32_t_u_u(((((safe_div_func_int64_t_s_s((l_182[0][2][4] == g_83[2][0]), 18446744073709551608UL)) | l_182[0][0][0]) != 0x4695D468L) | g_82), l_183[0])), 10));
            l_191 = (((!p_17) ^ l_182[0][2][4]) >= 0xAF20L);
        }
        if (g_52)
            goto lbl_199;
        for (g_148 = 0; (g_148 != (-6)); --g_148)
        { /* block id: 89 */
            l_191 = g_35[6][7].f6;
        }
    }
    else
    { /* block id: 92 */
lbl_199:
        for (g_78 = 5; (g_78 > 1); g_78--)
        { /* block id: 95 */
            uint32_t l_196 = 0x63834FB5L;
            l_196--;
        }
        return l_200;
    }
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_52 g_55 g_12 g_83 g_67 g_76 g_110 g_71 g_151 g_79 g_73 g_172
 * writes: g_35.f7 g_55 g_83 g_35.f0 g_110 g_151 g_172
 */
static int32_t  func_21(int64_t  p_22, int32_t  p_23, uint32_t  p_24, uint16_t  p_25)
{ /* block id: 5 */
    const uint8_t l_26[3][10] = {{0xECL,4UL,4UL,0xECL,4UL,4UL,0xECL,4UL,4UL,0xECL},{4UL,0xECL,4UL,4UL,0xECL,4UL,4UL,0xECL,4UL,4UL},{0xECL,0xECL,3UL,0xECL,0xECL,0xECL,4UL,4UL,0xECL,4UL}};
    int32_t l_54 = 0x6842B3FCL;
    int32_t l_74 = 9L;
    int32_t l_75 = 2L;
    int32_t l_77[3][9] = {{4L,(-1L),(-1L),0x948E95C3L,(-1L),(-1L),4L,(-1L),(-1L)},{0xB7F54350L,0L,0L,0xB7F54350L,0L,0L,0xB7F54350L,0L,0L},{4L,(-1L),(-1L),0x948E95C3L,(-1L),(-1L),4L,(-1L),(-1L)}};
    uint32_t l_115 = 0x15E5C18EL;
    int32_t l_129 = 0xDC91CA63L;
    uint8_t l_156 = 0x06L;
    uint32_t l_163 = 1UL;
    int i, j;
    if ((0xA3L <= l_26[0][6]))
    { /* block id: 6 */
        volatile uint32_t l_36 = 0x84C26686L;/* VOLATILE GLOBAL l_36 */
        int32_t l_63 = 1L;
        int32_t l_64 = 0xD63D9F3AL;
        int32_t l_65 = (-1L);
        int32_t l_72 = (-7L);
        int32_t l_80 = 4L;
        int32_t l_81 = 0x9802BA47L;
        int64_t l_88 = 0x687208B660CD2BE1LL;
        for (p_22 = (-26); (p_22 != 21); ++p_22)
        { /* block id: 9 */
            int16_t l_32 = (-1L);
            int32_t l_42 = 0x653BE29DL;
            l_36 = (func_29(l_26[1][0], l_32) , g_35[6][7].f2);
            l_42 = (safe_unary_minus_func_uint64_t_u((((safe_mod_func_int64_t_s_s((((safe_sub_func_int16_t_s_s(0x53C8L, l_26[1][0])) & 1UL) <= p_25), (-9L))) , g_35[6][7].f3) , 18446744073709551609UL)));
        }
        g_35[6][7].f7 ^= (safe_add_func_int32_t_s_s(l_26[2][3], l_36));
        if ((safe_mul_func_uint16_t_u_u((g_35[6][7].f1 >= 0xCA972D9DL), 1UL)))
        { /* block id: 17 */
            int64_t l_51[9][9] = {{(-6L),0L,1L,1L,0L,(-6L),0x34A22360892C684BLL,1L,0L},{0L,1L,0xCEABDB128D63D52ELL,0xCAD7D98C00C08B14LL,0xCEABDB128D63D52ELL,1L,0L,(-4L),0L},{8L,0x34A22360892C684BLL,0L,(-6L),(-6L),0L,0x34A22360892C684BLL,8L,(-6L)},{0xD48C05A145734C79LL,(-4L),(-5L),0x918EFA3C6A65346BLL,0xB5D9575A6E9923ECLL,0x918EFA3C6A65346BLL,(-5L),(-4L),0xD48C05A145734C79LL},{0x801899B7E06FDCCDLL,(-6L),1L,0x81CD2028979A2FC8LL,0x801899B7E06FDCCDLL,0x801899B7E06FDCCDLL,0x81CD2028979A2FC8LL,1L,(-6L)},{0xCEABDB128D63D52ELL,(-1L),0L,0xCAD7D98C00C08B14LL,0x8D0DBADF69682565LL,(-4L),0x8D0DBADF69682565LL,0xCAD7D98C00C08B14LL,0L},{0x801899B7E06FDCCDLL,8L,0x81CD2028979A2FC8LL,0L,(-6L),8L,8L,(-6L),0L},{0xD48C05A145734C79LL,(-1L),0xD48C05A145734C79LL,(-4L),(-5L),0x918EFA3C6A65346BLL,0xB5D9575A6E9923ECLL,0x918EFA3C6A65346BLL,(-5L)},{8L,(-6L),0x81CD2028979A2FC8LL,0L,0L,8L,0x81CD2028979A2FC8LL,0x81CD2028979A2FC8LL,8L}};
            int32_t l_53 = (-1L);
            int i, j;
            g_35[6][7].f7 = (safe_div_func_uint8_t_u_u(((((safe_lshift_func_uint16_t_u_u((p_25 && l_51[0][3]), l_26[0][6])) <= l_51[0][3]) , 0x58A0L) && g_35[6][7].f0), g_52));
            --g_55;
            l_54 |= (((safe_rshift_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((+(l_51[8][3] | 7UL)), g_35[6][7].f7)), p_22)) == l_36) < l_26[2][8]);
        }
        else
        { /* block id: 21 */
            int16_t l_66 = 0L;
            int32_t l_69 = 8L;
            int32_t l_70[8] = {4L,4L,4L,4L,4L,4L,4L,4L};
            int i;
            l_54 = (((g_55 | g_12) ^ l_54) && l_54);
            p_23 |= l_26[0][7];
            g_83[5][2]--;
            l_72 = (0xBD436219L <= l_72);
        }
        g_35[6][7].f7 |= (((safe_sub_func_int32_t_s_s(1L, p_24)) & l_88) > p_24);
    }
    else
    { /* block id: 28 */
        int64_t l_89 = (-3L);
        int32_t l_108 = 3L;
        uint32_t l_116 = 0x4572FAC3L;
        if (p_23)
        { /* block id: 29 */
            uint32_t l_90[5] = {0UL,0UL,0UL,0UL,0UL};
            int i;
            l_89 = ((g_67 == l_26[2][6]) <= p_23);
            ++l_90[4];
            p_23 &= p_25;
        }
        else
        { /* block id: 33 */
            uint64_t l_100 = 0x65E8A440665D72AELL;
lbl_99:
            p_23 = (safe_lshift_func_int16_t_s_s(p_23, 5));
            g_35[6][7].f0 = (((safe_sub_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((p_25 , g_35[6][7].f6), p_23)), p_25)) , 1UL) , g_76[0]);
            if (g_67)
                goto lbl_99;
            l_100 = 3L;
        }
        if (((safe_div_func_uint8_t_u_u(g_35[6][7].f2, (-1L))) , l_89))
        { /* block id: 39 */
            g_35[6][7].f7 ^= (safe_mul_func_uint8_t_u_u(g_35[6][7].f4, g_52));
            return g_52;
        }
        else
        { /* block id: 42 */
            int32_t l_107[10] = {0x9785EC66L,0x7C9A4742L,0x9785EC66L,0x9785EC66L,0x7C9A4742L,0x9785EC66L,0x9785EC66L,0x7C9A4742L,0x9785EC66L,0x9785EC66L};
            int32_t l_109 = 1L;
            int i;
            l_107[2] = (safe_rshift_func_int8_t_s_u(p_22, 3));
            ++g_110;
            p_23 = (((+((!l_115) > 0xF214E0A7E5BCBC8BLL)) , 0x082FB81DL) , 0x3292AA65L);
            ++l_116;
        }
        g_35[6][7].f0 |= ((safe_mod_func_uint64_t_u_u((safe_mul_func_int8_t_s_s(l_75, g_35[6][7].f7)), l_108)) != 0x5897DADBB84CDFD8LL);
        g_35[6][7].f7 = (p_22 | 0x95546736D523453ALL);
    }
    l_75 = g_83[5][2];
    if ((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int8_t_s_s((safe_sub_func_uint16_t_u_u((p_22 , 65535UL), p_25)), l_129)), 13)))
    { /* block id: 52 */
        uint8_t l_132 = 0x15L;
        int32_t l_146[4][9][7] = {{{0xD3E714B4L,1L,2L,7L,0L,0xF24D469CL,0xAB7E2050L},{0x1FC4C820L,0x287C9091L,0L,0xAB7E2050L,0xC05C0CC7L,(-4L),1L},{(-6L),(-1L),0x4120DA18L,0L,0xB0CA4C30L,0L,0x4120DA18L},{0x78E21E83L,0x78E21E83L,0x1FA4A3DAL,0x5D323453L,1L,(-10L),0xAB7E2050L},{0xCEBFDD09L,9L,0x8998BE7CL,0x890C0586L,0L,0x9BB32C21L,0x1FC4C820L},{0x0D2B85DAL,0x68D0BCE4L,0x742DCBA3L,0xEDD9AE8CL,1L,0L,0xE424F598L},{0x17F3DB08L,(-1L),0xCD84E662L,1L,0xB0CA4C30L,0x45096FADL,0x5D323453L},{1L,0x0E4EAF2CL,0x9BB32C21L,0x8E1EF68BL,0xC05C0CC7L,0xE424F598L,9L},{2L,0xD58F199DL,0xBCD9D4EAL,0L,0x287C9091L,0x1FA4A3DAL,0xA01C24B0L}},{{0L,0x756BE5B3L,0xB0CA4C30L,0xEDD9AE8CL,0L,0x336DEEBDL,0x9BB32C21L},{(-6L),0L,0x7999FF8BL,0xC05C0CC7L,0x8D8505F0L,0xF24D469CL,2L},{(-10L),2L,0xF24D469CL,0xF5A7FC6AL,0x07620ED2L,0xF24D469CL,(-1L)},{0L,(-1L),7L,0x4120DA18L,0x0E4EAF2CL,0x336DEEBDL,0x07620ED2L},{(-1L),0xD5DCE314L,0x0978246AL,0L,1L,0x1FA4A3DAL,0xA2AEA371L},{1L,2L,2L,0xD5DCE314L,1L,0x65F44572L,0x8230FADCL},{0L,0xA2AEA371L,1L,0x07620ED2L,0x742DCBA3L,0x1FC4C820L,0x742DCBA3L},{0xC05C0CC7L,(-10L),(-10L),0xC05C0CC7L,0xF50E0B20L,8L,0L},{0x1FA4A3DAL,2L,(-1L),1L,0L,0xA01C24B0L,0x7999FF8BL}},{{(-9L),0x4120DA18L,(-1L),0x83C7EF23L,0L,(-1L),0L},{(-4L),0x296AE8CEL,0x65F44572L,0L,0L,0x549EA420L,0x742DCBA3L},{0x8230FADCL,2L,0L,0xF24D469CL,0x83C7EF23L,(-1L),0x8230FADCL},{0L,0x83C7EF23L,(-1L),0x287C9091L,0L,0xB0CA4C30L,0xA2AEA371L},{0L,0xF50E0B20L,0x45096FADL,0x0E4EAF2CL,0xBCD9D4EAL,(-10L),0x07620ED2L},{0xD5DCE314L,0xD58F199DL,0x8D8505F0L,0x296AE8CEL,0x756BE5B3L,0x8230FADCL,(-1L)},{0xF92495E0L,0L,0x557C3E86L,2L,0x742DCBA3L,0x17F3DB08L,2L},{0xF92495E0L,2L,0x65F44572L,0xD58F199DL,0x1FA4A3DAL,0L,0x9BB32C21L},{0xD5DCE314L,0x9BB32C21L,0xF50E0B20L,(-9L),0L,0x7999FF8BL,0xA01C24B0L}},{{0L,0x535910C0L,0x129FB94FL,(-9L),0x0E4EAF2CL,0x9E673365L,9L},{0L,(-6L),(-10L),0x7E705506L,0xF5A7FC6AL,(-9L),(-1L)},{0x8230FADCL,0L,0L,0L,0L,0x8230FADCL,0x65F44572L},{(-4L),0x0E4EAF2CL,0x556FD85EL,(-9L),0L,0x68D0BCE4L,1L},{(-9L),0xF24D469CL,0x0978246AL,0x742DCBA3L,0x0AF24343L,0xF5A7FC6AL,0xD58F199DL},{0x1FA4A3DAL,0x0E4EAF2CL,0x549EA420L,0x68CEC908L,0xA2AEA371L,(-1L),0xF24D469CL},{0xC05C0CC7L,0L,5L,2L,0x0D2B85DAL,7L,0x8998BE7CL},{0L,(-6L),0x7999FF8BL,(-1L),0xF24D469CL,0xCD84E662L,0xD58F199DL},{1L,0x68CEC908L,0x5D323453L,(-1L),0L,0x129FB94FL,0x78E21E83L}}};
        int i, j, k;
        if (g_35[6][7].f0)
        { /* block id: 53 */
            g_35[6][7].f7 |= (((((((safe_rshift_func_uint8_t_u_u(((l_132 | l_77[2][1]) | l_74), l_132)) , (-9L)) , 0xC30EB271F3292925LL) <= g_71[1]) >= 0x867C341A536D6C3FLL) >= p_23) != 0x2A5CAD6F74C4BF40LL);
        }
        else
        { /* block id: 55 */
            int16_t l_139 = 8L;
            uint8_t l_143 = 0xD5L;
            int32_t l_144 = (-1L);
            int32_t l_145 = 0x6C7403DBL;
            int32_t l_150[3][7][3] = {{{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L}},{{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)}},{{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L},{(-1L),(-1L),(-1L)},{6L,6L,0xD901D547L}}};
            int i, j, k;
            l_139 = ((safe_mul_func_uint16_t_u_u(((safe_mod_func_int64_t_s_s((safe_rshift_func_int16_t_s_u((9L ^ 0L), 12)), 18446744073709551615UL)) != 0x298D51729B53F0AELL), 0L)) ^ 1UL);
            g_35[6][7].f7 ^= (safe_mul_func_int16_t_s_s(((!l_143) | g_71[3]), l_129));
            g_151--;
            l_145 = ((safe_mul_func_uint8_t_u_u((0x61L < p_22), (-1L))) | 0x27FBL);
        }
        p_23 = ((l_74 > p_23) & l_156);
    }
    else
    { /* block id: 62 */
        int32_t l_157 = 0L;
        return l_157;
    }
    if ((safe_div_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_s((+((0xEDL < 0x21L) || g_151)), 2)) > l_163), 1UL)))
    { /* block id: 65 */
        return g_35[6][7].f7;
    }
    else
    { /* block id: 67 */
        if (((safe_add_func_int8_t_s_s(0x9FL, g_79)) >= 8UL))
        { /* block id: 68 */
            g_35[6][7].f7 = g_73[1][0][1];
        }
        else
        { /* block id: 70 */
            uint16_t l_170[4];
            int8_t l_171 = 0L;
            int i;
            for (i = 0; i < 4; i++)
                l_170[i] = 0UL;
            p_23 = l_74;
            g_35[6][7].f7 ^= ((safe_add_func_int8_t_s_s((((((safe_div_func_uint8_t_u_u(1UL, l_170[2])) <= 1UL) && p_22) , g_35[6][7].f4) , 0xBFL), 0xA9L)) | 6L);
            g_172--;
            l_75 = ((safe_mul_func_int8_t_s_s((1L > g_52), p_22)) && g_83[6][4]);
        }
    }
    return l_77[0][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_35
 * writes:
 */
static struct S0  func_29(uint64_t  p_30, uint32_t  p_31)
{ /* block id: 10 */
    uint16_t l_33 = 0xA1C1L;
    int32_t l_34[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
    int i;
    l_34[7] ^= l_33;
    return g_35[6][7];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_10[i][j][k], "g_10[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_35[i][j].f0, "g_35[i][j].f0", print_hash_value);
            transparent_crc(g_35[i][j].f1, "g_35[i][j].f1", print_hash_value);
            transparent_crc(g_35[i][j].f2, "g_35[i][j].f2", print_hash_value);
            transparent_crc(g_35[i][j].f3, "g_35[i][j].f3", print_hash_value);
            transparent_crc(g_35[i][j].f4, "g_35[i][j].f4", print_hash_value);
            transparent_crc(g_35[i][j].f5, "g_35[i][j].f5", print_hash_value);
            transparent_crc(g_35[i][j].f6, "g_35[i][j].f6", print_hash_value);
            transparent_crc(g_35[i][j].f7, "g_35[i][j].f7", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_68[i][j], "g_68[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_71[i], "g_71[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_73[i][j][k], "g_73[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_76[i], "g_76[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_83[i][j], "g_83[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_110, "g_110", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_147[i], "g_147[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    transparent_crc(g_181, "g_181", print_hash_value);
    transparent_crc(g_204, "g_204", print_hash_value);
    transparent_crc(g_224, "g_224", print_hash_value);
    transparent_crc(g_225, "g_225", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_275[i], "g_275[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_284[i][j][k], "g_284[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_285, "g_285", print_hash_value);
    transparent_crc(g_286, "g_286", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_288[i], "g_288[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_290, "g_290", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 108
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 121
   depth: 2, occurrence: 20
   depth: 3, occurrence: 9
   depth: 4, occurrence: 12
   depth: 5, occurrence: 6
   depth: 6, occurrence: 5
   depth: 7, occurrence: 4
   depth: 8, occurrence: 5
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 175
XXX times a non-volatile is write: 69
XXX times a volatile is read: 25
XXX    times read thru a pointer: 0
XXX times a volatile is write: 12
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 138
XXX percentage of non-volatile access: 86.8

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 112
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 32
   depth: 2, occurrence: 61

XXX percentage a fresh-made variable is used: 30.1
XXX percentage an existing variable is used: 69.9
********************* end of statistics **********************/

