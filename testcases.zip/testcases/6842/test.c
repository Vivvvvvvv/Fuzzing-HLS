/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15624924082654958243
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static int32_t g_3[7][1] = {{1L},{(-1L)},{1L},{(-1L)},{1L},{(-1L)},{1L}};
static uint8_t g_30[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static uint32_t g_36[2] = {0x3B040F4EL,0x3B040F4EL};


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static const int32_t  func_6(uint32_t  p_7, const int16_t  p_8, uint16_t  p_9);
static int32_t  func_11(uint32_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_30 g_36
 * writes: g_3 g_2 g_30 g_36
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_37 = 0UL;
    for (g_3[5][0] = 0; (g_3[5][0] < (-16)); --g_3[5][0])
    { /* block id: 3 */
        const uint16_t l_10 = 1UL;
        g_2 = 0xECCCE1E2L;
        g_30[2] &= func_6(g_3[5][0], l_10, l_10);
        if (g_2)
        { /* block id: 21 */
            return l_10;
        }
        else
        { /* block id: 23 */
            const uint32_t l_35 = 2UL;
            g_2 = ((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(g_3[3][0], 2)), g_30[2])) <= g_30[2]);
            g_36[1] &= ((func_6(g_30[3], l_35, g_3[1][0]) > g_3[6][0]) , 0L);
        }
    }
    return l_37;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static const int32_t  func_6(uint32_t  p_7, const int16_t  p_8, uint16_t  p_9)
{ /* block id: 5 */
    uint8_t l_15 = 0x20L;
    int32_t l_20[7];
    int i;
    for (i = 0; i < 7; i++)
        l_20[i] = 0L;
    if (func_11(((safe_mul_func_uint8_t_u_u((3UL <= p_7), 0xB3L)) < l_15)))
    { /* block id: 9 */
        int64_t l_28[3][8][3] = {{{0x278A4911CCFE983DLL,0x16D21B1857497F3CLL,(-1L)},{0xB656D4C01E07AD46LL,0xB656D4C01E07AD46LL,1L},{0x04FC4B664FB7D476LL,0x16D21B1857497F3CLL,0x23205E60D1F28301LL},{1L,0x286A4ABFF1EB7E59LL,4L},{0x04FC4B664FB7D476LL,1L,(-1L)},{0xB656D4C01E07AD46LL,1L,4L},{0x278A4911CCFE983DLL,0x278A4911CCFE983DLL,0x23205E60D1F28301LL},{3L,1L,1L}},{{0x16D21B1857497F3CLL,1L,(-1L)},{3L,0x286A4ABFF1EB7E59LL,0xC34F1D4B082B0002LL},{1L,(-1L),1L},{0x9A67B9C5C935CB51LL,0x9A67B9C5C935CB51LL,3L},{(-10L),(-1L),0x04FC4B664FB7D476LL},{0xC36C1D66BD5D5181LL,(-7L),0x286A4ABFF1EB7E59LL},{(-10L),0x872A60D4E023024ALL,0x48718302CCA7A22FLL},{0x9A67B9C5C935CB51LL,0xC36C1D66BD5D5181LL,0x286A4ABFF1EB7E59LL}},{{1L,1L,0x04FC4B664FB7D476LL},{(-1L),0xC36C1D66BD5D5181LL,3L},{(-1L),0x872A60D4E023024ALL,1L},{(-1L),(-7L),(-9L)},{1L,(-1L),1L},{0x9A67B9C5C935CB51LL,0x9A67B9C5C935CB51LL,3L},{(-10L),(-1L),0x04FC4B664FB7D476LL},{0xC36C1D66BD5D5181LL,(-7L),0x286A4ABFF1EB7E59LL}}};
        int i, j, k;
        for (p_7 = 0; (p_7 < 21); p_7 = safe_add_func_uint64_t_u_u(p_7, 4))
        { /* block id: 12 */
            uint16_t l_21[1];
            int i;
            for (i = 0; i < 1; i++)
                l_21[i] = 1UL;
            ++l_21[0];
            g_2 ^= ((safe_add_func_uint64_t_u_u((((safe_mul_func_uint16_t_u_u(((0x6B7A7BC6C8951BB3LL != 0x0547507AF9CA3EAALL) || p_8), l_28[0][1][0])) , 0xEA65D3384F7A324CLL) , 18446744073709551609UL), 0x129E5E26C5F514FCLL)) , p_7);
        }
    }
    else
    { /* block id: 16 */
        const uint32_t l_29[4] = {0UL,0UL,0UL,0UL};
        int i;
        return l_29[1];
    }
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_11(uint32_t  p_12)
{ /* block id: 6 */
    uint64_t l_16 = 0xA2B441A62A96950ALL;
    int32_t l_17 = 0xC694A61BL;
    l_17 |= (l_16 , (-1L));
    return p_12;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_30[i], "g_30[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_36[i], "g_36[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 6
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 13
XXX percentage of non-volatile access: 87.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 5
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 38.7
XXX percentage an existing variable is used: 61.3
********************* end of statistics **********************/

