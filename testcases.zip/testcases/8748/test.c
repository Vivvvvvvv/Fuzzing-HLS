/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1432601905306855196
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_10 = 0x64276038591B68DELL;
static uint16_t g_21 = 0x0EBFL;
static volatile int32_t g_29 = 0xF7D59448L;/* VOLATILE GLOBAL g_29 */
static volatile int32_t g_41 = (-2L);/* VOLATILE GLOBAL g_41 */
static volatile uint32_t g_42 = 0x8CDE333BL;/* VOLATILE GLOBAL g_42 */
static uint32_t g_48[8] = {0x181CA8FDL,0x181CA8FDL,0x181CA8FDL,0x181CA8FDL,0x181CA8FDL,0x181CA8FDL,0x181CA8FDL,0x181CA8FDL};
static uint64_t g_52 = 0x5DA77236C342871ELL;
static volatile int16_t g_74 = 0x70F1L;/* VOLATILE GLOBAL g_74 */
static uint8_t g_75 = 0x21L;
static uint16_t g_80[5] = {65535UL,65535UL,65535UL,65535UL,65535UL};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_2(int32_t  p_3);
static int32_t  func_4(const int16_t  p_5, uint32_t  p_6, int32_t  p_7, uint8_t  p_8);
static uint8_t  func_13(int32_t  p_14);
static uint8_t  func_15(uint32_t  p_16, int64_t  p_17, int32_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_42 g_48 g_52 g_29 g_75 g_80 g_41
 * writes: g_10 g_21 g_29 g_42 g_48 g_75 g_80 g_52
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    const uint64_t l_9[7][1][3] = {{{9UL,0UL,9UL}},{{0xF3C34EEA2A3B3F36LL,0xB8114768C0AA39EDLL,0xB8114768C0AA39EDLL}},{{0UL,0UL,0UL}},{{0xF3C34EEA2A3B3F36LL,0xF3C34EEA2A3B3F36LL,0xB8114768C0AA39EDLL}},{{9UL,0UL,9UL}},{{0xF3C34EEA2A3B3F36LL,0xB8114768C0AA39EDLL,0xB8114768C0AA39EDLL}},{{0UL,0UL,0UL}}};
    int32_t l_143 = 1L;
    uint16_t l_150 = 9UL;
    int i, j, k;
    l_143 = func_2(func_4(l_9[4][0][2], l_9[6][0][0], g_10, l_9[1][0][2]));
    for (g_52 = 0; (g_52 <= 4); g_52 += 1)
    { /* block id: 95 */
        uint8_t l_144 = 248UL;
        int i;
        if ((((((0xD3L == g_48[(g_52 + 2)]) != 0xB170L) <= l_9[4][0][2]) , g_48[(g_52 + 2)]) , g_48[(g_52 + 2)]))
        { /* block id: 96 */
            ++l_144;
        }
        else
        { /* block id: 98 */
            uint32_t l_147 = 1UL;
            l_147 = g_21;
        }
        g_29 |= ((safe_div_func_uint32_t_u_u((3UL > 18446744073709551608UL), l_150)) , g_75);
        return l_9[6][0][0];
    }
    return g_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_48 g_10
 * writes:
 */
static int32_t  func_2(int32_t  p_3)
{ /* block id: 86 */
    int16_t l_131[10] = {(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L),(-1L),5L,(-1L)};
    const uint32_t l_141 = 0x9B1B028DL;
    int32_t l_142 = 2L;
    int i;
    p_3 ^= (safe_lshift_func_uint8_t_u_u(((0x8C401198L && 4294967287UL) , g_21), 1));
    p_3 = 0x431493BBL;
    p_3 = (safe_add_func_uint16_t_u_u(l_131[0], p_3));
    l_142 = (safe_add_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(((((!((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(0UL, 15)), l_141)) != p_3)) || g_48[1]) < 0x39L) >= l_131[0]), g_21)), g_10));
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_42 g_48 g_52 g_29 g_75 g_80 g_41
 * writes: g_10 g_21 g_29 g_42 g_48 g_75 g_80
 */
static int32_t  func_4(const int16_t  p_5, uint32_t  p_6, int32_t  p_7, uint8_t  p_8)
{ /* block id: 1 */
    const int32_t l_61 = 0x52A103ABL;
    uint8_t l_62 = 255UL;
    int32_t l_71 = 2L;
    volatile uint32_t l_84 = 1UL;/* VOLATILE GLOBAL l_84 */
    int32_t l_99[2];
    int i;
    for (i = 0; i < 2; i++)
        l_99[i] = 0x9042C8ACL;
    for (g_10 = (-25); (g_10 != 12); g_10++)
    { /* block id: 4 */
        int8_t l_56 = 0x75L;
        p_7 &= ((func_13(g_10) && l_56) , l_56);
        return p_8;
    }
    if (((((safe_sub_func_uint64_t_u_u((((((safe_lshift_func_uint8_t_u_u((p_5 && p_6), p_7)) > l_61) , l_62) > p_8) == g_48[2]), 0x9F15FC87C03C79A3LL)) > g_29) && g_42) != l_61))
    { /* block id: 39 */
        const int64_t l_68 = 0x1160C006E742402BLL;
        int32_t l_72 = 0xD205C6C2L;
        p_7 = p_6;
        if (((1UL && 0xCBL) > 1UL))
        { /* block id: 41 */
            g_29 = 1L;
            if (g_10)
                goto lbl_63;
        }
        else
        { /* block id: 43 */
lbl_63:
            g_29 = g_10;
            p_7 |= ((safe_mul_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((g_48[5] >= g_29), l_68)), l_68)) ^ l_61);
        }
        for (g_21 = (-30); (g_21 <= 30); g_21 = safe_add_func_uint16_t_u_u(g_21, 6))
        { /* block id: 50 */
            int64_t l_73 = 0xA3B757A549BDA14ELL;
            g_75++;
            g_29 = (-1L);
            l_72 = (((safe_div_func_uint8_t_u_u(g_48[0], 0x46L)) < p_5) || l_71);
            p_7 = l_73;
        }
    }
    else
    { /* block id: 56 */
        uint32_t l_83 = 0xD3C07AF8L;
        ++g_80[1];
        l_83 = l_62;
    }
    l_84 = g_42;
    if (((((safe_rshift_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((p_8 <= g_52), l_99[1])), p_6)) > 18446744073709551610UL) < p_5), p_6)), g_41)), 4)), 7UL)), p_7)) || p_5) ^ g_80[1]) == p_8))
    { /* block id: 61 */
        int16_t l_103[3];
        int i;
        for (i = 0; i < 3; i++)
            l_103[i] = 0xC41FL;
        l_71 = (safe_mod_func_uint16_t_u_u(((+((((0x45A0D0093E2C01BBLL >= 0xD4651924C026D396LL) < 0x626D9AC2FE1997BDLL) , g_48[1]) == p_6)) != l_103[0]), l_103[2]));
        for (g_75 = 0; (g_75 <= 16); g_75++)
        { /* block id: 65 */
            return g_10;
        }
        p_7 = 0xD808B432L;
    }
    else
    { /* block id: 69 */
        const uint32_t l_107[6] = {0x1BEEAF45L,0x1BEEAF45L,0x1BEEAF45L,0x1BEEAF45L,0x1BEEAF45L,0x1BEEAF45L};
        int32_t l_119 = 1L;
        int i;
        if ((+(0x90AFEB5AB84A4DC8LL == l_107[0])))
        { /* block id: 70 */
            uint32_t l_118 = 2UL;
            l_119 = (((((safe_mul_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u(((safe_div_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u(p_6, l_99[1])), 0x6B95FC1DL)) ^ 255UL), 0)), l_107[4])), 0x1ADCL)) , 1L) , l_107[0]) < l_118) >= g_80[4]);
        }
        else
        { /* block id: 72 */
            l_71 = g_80[1];
            l_119 &= ((safe_div_func_uint8_t_u_u(g_75, 0x0AL)) >= p_6);
            g_29 = p_7;
            g_29 = ((0UL == 4294967291UL) == 0x8A72L);
        }
        for (g_75 = 0; (g_75 > 26); g_75 = safe_add_func_uint8_t_u_u(g_75, 5))
        { /* block id: 80 */
            int8_t l_126 = 1L;
            l_126 = ((safe_sub_func_uint16_t_u_u((g_10 <= g_42), p_8)) , (-1L));
            g_29 = g_21;
        }
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_42 g_48 g_52
 * writes: g_21 g_29 g_42 g_48
 */
static uint8_t  func_13(int32_t  p_14)
{ /* block id: 5 */
    uint8_t l_53 = 0xECL;
    int32_t l_55 = 0x2A25C95EL;
    l_53 = (func_15(g_10, p_14, p_14) , g_52);
    l_55 = (+(p_14 != 0x9934L));
    return g_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_10 g_42 g_48
 * writes: g_21 g_29 g_42 g_48
 */
static uint8_t  func_15(uint32_t  p_16, int64_t  p_17, int32_t  p_18)
{ /* block id: 6 */
    int64_t l_24 = 0xEF9953E80C6548AALL;
    uint32_t l_32 = 1UL;
    int32_t l_39 = 0xA498A597L;
    int32_t l_40[4] = {0x09E13A3AL,0x09E13A3AL,0x09E13A3AL,0x09E13A3AL};
    int i;
    for (p_18 = 4; (p_18 < (-9)); p_18 = safe_sub_func_uint16_t_u_u(p_18, 8))
    { /* block id: 9 */
        uint32_t l_28 = 0xDB956746L;
        int32_t l_30[5][5];
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 5; j++)
                l_30[i][j] = 0x63CFEBDAL;
        }
        ++g_21;
        if ((((((g_10 <= l_24) >= 0x11D7FEAE215169FFLL) == 0xD732ADAAL) != p_16) , g_10))
        { /* block id: 11 */
            uint16_t l_27 = 65535UL;
            int32_t l_31 = 0x4BD1A6F3L;
            l_27 = ((safe_add_func_uint8_t_u_u((0xEC0DCEE05243B9C3LL > g_10), g_21)) == g_21);
            g_29 = ((((g_21 , p_17) <= p_17) , l_28) , 0x4E785C2FL);
            ++l_32;
        }
        else
        { /* block id: 15 */
            uint64_t l_35[9] = {0xDF2FFA36FE54384FLL,0xAC16B405B7518DB0LL,0xDF2FFA36FE54384FLL,0xDF2FFA36FE54384FLL,0xAC16B405B7518DB0LL,0xDF2FFA36FE54384FLL,0xDF2FFA36FE54384FLL,0xAC16B405B7518DB0LL,0xDF2FFA36FE54384FLL};
            int32_t l_38 = (-9L);
            int i;
            l_35[6] = g_10;
            g_29 = (safe_add_func_uint16_t_u_u(((p_16 <= 255UL) != 0UL), p_16));
            l_38 = l_32;
            g_42++;
        }
    }
    for (p_18 = 9; (p_18 != (-28)); --p_18)
    { /* block id: 24 */
        uint16_t l_51 = 0x4F4DL;
        if (l_24)
        { /* block id: 25 */
            uint8_t l_47 = 0xA6L;
            l_47 = (g_10 || g_42);
        }
        else
        { /* block id: 27 */
            g_48[2]++;
        }
        l_51 = l_40[0];
    }
    return g_48[7];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_48[i], "g_48[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_80[i], "g_80[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 75
   depth: 2, occurrence: 11
   depth: 3, occurrence: 3
   depth: 4, occurrence: 7
   depth: 5, occurrence: 3
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 2
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 106
XXX times a non-volatile is write: 38
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 11
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 63
XXX percentage of non-volatile access: 87.8

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 65
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 19
   depth: 2, occurrence: 27

XXX percentage a fresh-made variable is used: 28.3
XXX percentage an existing variable is used: 71.7
********************* end of statistics **********************/

