/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11091507985310969771
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int16_t  f0;
   const int32_t  f1;
   int8_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static volatile struct S0 g_4 = {1L,0x60417BE1L,0x79L};/* VOLATILE GLOBAL g_4 */
static int8_t g_6 = 1L;
static int64_t g_14[7] = {(-9L),0xCE4B0AD8EA5F34BDLL,(-9L),(-9L),0xCE4B0AD8EA5F34BDLL,(-9L),(-9L)};
static int16_t g_24 = 0L;
static uint32_t g_27[8] = {0x0D790F95L,0x2AFDDF34L,0x0D790F95L,0x2AFDDF34L,0x0D790F95L,0x2AFDDF34L,0x0D790F95L,0x2AFDDF34L};
static uint8_t g_42 = 247UL;
static struct S0 g_43 = {0L,0x82EA9177L,0L};/* VOLATILE GLOBAL g_43 */
static volatile struct S0 g_44[2] = {{4L,-1L,0x95L},{4L,-1L,0x95L}};
static uint64_t g_47[8][7] = {{0xBDD0C5DF97F74892LL,0x156CF859E2267C8CLL,18446744073709551606UL,5UL,5UL,18446744073709551606UL,0x156CF859E2267C8CLL},{0xF2865603B64E3176LL,0xCEC448071C3330F6LL,0xD7F484382FD97811LL,5UL,5UL,0xD7F484382FD97811LL,0xCEC448071C3330F6LL},{0xBDD0C5DF97F74892LL,0x156CF859E2267C8CLL,18446744073709551606UL,5UL,5UL,18446744073709551606UL,0x156CF859E2267C8CLL},{0xF2865603B64E3176LL,0xCEC448071C3330F6LL,0xD7F484382FD97811LL,5UL,5UL,0xD7F484382FD97811LL,0xCEC448071C3330F6LL},{0xBDD0C5DF97F74892LL,0x020A50D0CE47CEE5LL,5UL,0xBDD0C5DF97F74892LL,0xBDD0C5DF97F74892LL,5UL,0x020A50D0CE47CEE5LL},{0x8EC3DF54D9846C24LL,4UL,5UL,0xF2865603B64E3176LL,0xF2865603B64E3176LL,5UL,4UL},{0x2C41E7D42A80B09DLL,0x020A50D0CE47CEE5LL,5UL,0xBDD0C5DF97F74892LL,0xBDD0C5DF97F74892LL,5UL,0x020A50D0CE47CEE5LL},{0x8EC3DF54D9846C24LL,4UL,5UL,0xF2865603B64E3176LL,0xF2865603B64E3176LL,5UL,4UL}};
static volatile uint16_t g_48 = 0x62B7L;/* VOLATILE GLOBAL g_48 */
static volatile uint32_t g_51 = 4294967295UL;/* VOLATILE GLOBAL g_51 */
static volatile int8_t g_54[4] = {0L,0L,0L,0L};
static uint32_t g_55[9] = {0x3CB3F04BL,0xA7991AD4L,0xA7991AD4L,0x3CB3F04BL,0xA7991AD4L,0xA7991AD4L,0x3CB3F04BL,0xA7991AD4L,0xA7991AD4L};
static volatile uint16_t g_93[8][9][3] = {{{0x2174L,0x7131L,65535UL},{65529UL,0xA908L,3UL},{6UL,1UL,65533UL},{0x13BAL,0xA908L,65535UL},{0UL,0x7131L,3UL},{0xDEB7L,65530UL,65533UL},{4UL,0x3C14L,0xD3EAL},{0UL,3UL,65530UL},{0UL,3UL,0x1BE0L}},{{0x13BAL,0x3C14L,1UL},{0UL,65530UL,3UL},{0xA374L,0x7131L,0xE232L},{0x2174L,0xA908L,0xD3EAL},{0UL,1UL,0x0C15L},{0x39C0L,0xA908L,65533UL},{0x570CL,0x7131L,65535UL},{0UL,65530UL,0x0C15L},{5UL,0x3C14L,0x4306L}},{{0UL,3UL,65535UL},{0UL,3UL,3UL},{0x39C0L,0x3C14L,0x2356L},{0x41CDL,65530UL,0UL},{65529UL,0x7131L,65530UL},{0xA374L,0xA908L,0x4306L},{0x41CDL,1UL,0x4B44L},{1UL,0xA908L,3UL},{0UL,0x7131L,65533UL}},{{0UL,65530UL,0x4B44L},{65535UL,0x3C14L,3UL},{0xDEB7L,3UL,0xE232L},{0x570CL,3UL,0UL},{1UL,0x3C14L,0x3C14L},{6UL,65530UL,0x1BE0L},{0x2174L,0x7131L,65535UL},{65529UL,0xA908L,3UL},{6UL,1UL,65533UL}},{{0x13BAL,0xA908L,65535UL},{0UL,0x7131L,3UL},{0xDEB7L,65530UL,65533UL},{4UL,0x3C14L,0xD3EAL},{0UL,3UL,65530UL},{0UL,3UL,0x1BE0L},{0x13BAL,0x3C14L,1UL},{0UL,65530UL,3UL},{0xA374L,0x7131L,0xE232L}},{{0x2174L,0xA908L,0xD3EAL},{0UL,1UL,0x0C15L},{0x39C0L,0xA908L,65533UL},{0x570CL,0x7131L,65535UL},{0UL,65530UL,0x0C15L},{5UL,1UL,0x8547L},{65533UL,1UL,1UL},{1UL,1UL,5UL},{1UL,1UL,0xFB06L}},{{1UL,0UL,0xA75EL},{0x0C15L,0UL,0UL},{0x4B44L,0x5749L,0x8547L},{1UL,0UL,1UL},{0x3C14L,0x5749L,0xD3F9L},{5UL,0UL,0xE7F8L},{65533UL,0UL,1UL},{65526UL,1UL,1UL},{65535UL,1UL,65535UL}},{{0UL,1UL,0xA75EL},{0x3C14L,1UL,1UL},{65535UL,0UL,65532UL},{65533UL,0UL,1UL},{0x0C15L,0x5749L,1UL},{65535UL,0UL,0UL},{0x2356L,0x5749L,0x3468L},{1UL,0UL,0xD3F9L},{65535UL,0UL,0UL}}};
static volatile int32_t g_94 = 0xC0EDBB19L;/* VOLATILE GLOBAL g_94 */
static volatile uint8_t g_113 = 0x7DL;/* VOLATILE GLOBAL g_113 */
static uint32_t g_136 = 18446744073709551615UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int16_t  func_8(int32_t  p_9, int16_t  p_10, int16_t  p_11, int32_t  p_12, uint8_t  p_13);
static int32_t  func_29(const int32_t  p_30, int32_t  p_31, uint16_t  p_32, int64_t  p_33, int32_t  p_34);
static const int32_t  func_35(uint32_t  p_36);
static const int16_t  func_62(uint16_t  p_63, uint8_t  p_64, uint16_t  p_65, uint32_t  p_66);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_14 g_24 g_27 g_43 g_44 g_48 g_51 g_55 g_47 g_42 g_113 g_93
 * writes: g_24 g_27 g_6 g_42 g_47 g_48 g_51 g_55 g_93 g_94 g_113 g_136
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_5 = 0xD6C3F0BC5021C3A2LL;
    int32_t l_7 = 0L;
    l_7 = (safe_lshift_func_int8_t_s_u((g_4 , l_5), g_6));
    g_136 = ((func_8(l_7, l_5, g_4.f0, g_6, g_6) != 65535UL) ^ g_43.f1);
    return l_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_24 g_27 g_6 g_4.f2 g_4.f1 g_43 g_44 g_48 g_51 g_55 g_47 g_42 g_113 g_4.f0 g_93
 * writes: g_24 g_27 g_6 g_42 g_47 g_48 g_51 g_55 g_93 g_94 g_113
 */
static int16_t  func_8(int32_t  p_9, int16_t  p_10, int16_t  p_11, int32_t  p_12, uint8_t  p_13)
{ /* block id: 2 */
    int64_t l_15 = 0xC5D177CCE45D764CLL;
    int32_t l_98 = 0x73433C16L;
    for (p_10 = 0; (p_10 <= 6); p_10 += 1)
    { /* block id: 5 */
        volatile uint32_t l_28 = 0x804524BEL;/* VOLATILE GLOBAL l_28 */
        for (p_13 = 0; (p_13 <= 6); p_13 += 1)
        { /* block id: 8 */
            int i;
            l_15 = 0x6D8FF8CDL;
            return g_14[p_13];
        }
        for (p_11 = (-7); (p_11 <= 8); p_11 = safe_add_func_uint64_t_u_u(p_11, 8))
        { /* block id: 14 */
            uint16_t l_25 = 65526UL;
            const uint32_t l_26 = 0UL;
            g_24 |= (safe_lshift_func_int8_t_s_u((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(g_14[3], p_13)), l_15)), p_11));
            if (l_25)
                continue;
            g_27[0] |= (l_26 >= 4294967295UL);
            if (g_6)
                continue;
        }
        p_9 ^= (6L == 0x99L);
        l_28 = g_4.f2;
    }
    if (func_29(func_35((safe_rshift_func_uint8_t_u_s((0xFCL <= 255UL), g_4.f1))), p_9, g_27[0], l_15, p_12))
    { /* block id: 41 */
        int16_t l_97[7][4] = {{1L,0x38A0L,0x38A0L,1L},{0xC110L,0x38A0L,0xECE2L,0x38A0L},{0x38A0L,0xAC45L,0xECE2L,0xECE2L},{0xC110L,0xC110L,0x38A0L,0xECE2L},{1L,0xAC45L,1L,0x38A0L},{1L,0x38A0L,0x38A0L,1L},{0xC110L,0x38A0L,0xECE2L,0x38A0L}};
        uint16_t l_119 = 0xEFA7L;
        int i, j;
        if (g_24)
        { /* block id: 42 */
            int8_t l_73 = 0L;
            g_55[3]++;
            l_98 ^= func_29((((safe_mod_func_uint32_t_u_u((safe_add_func_int16_t_s_s(func_62((safe_add_func_int16_t_s_s((((safe_rshift_func_uint8_t_u_s((((safe_add_func_uint16_t_u_u(g_44[1].f2, 0x90CCL)) && g_4.f1) & 0x43F6L), 0)) ^ l_73) >= 0x1EDCL), p_9)), g_55[3], p_13, g_47[6][0]), l_15)), (-7L))) > 1UL) ^ l_97[3][3]), g_43.f2, g_27[3], g_27[0], l_97[3][1]);
            g_94 = (((safe_div_func_int32_t_s_s((safe_rshift_func_uint8_t_u_s((((safe_lshift_func_int8_t_s_s((((safe_mod_func_int64_t_s_s(p_13, l_73)) && 0UL) ^ l_73), 0)) , g_55[3]) , 0xF8L), 5)), l_97[2][3])) , l_15) || l_98);
        }
        else
        { /* block id: 60 */
            p_9 = ((g_43.f2 >= 0xF6L) || p_10);
            p_9 = ((((safe_sub_func_int32_t_s_s(((0x4B777FD1935D6DE2LL <= 0L) <= p_13), 0xCE24E6ACL)) > 0x1E50D5DEC9E90796LL) , 0x2AB80D10L) & l_15);
        }
        for (p_12 = 0; (p_12 <= 16); ++p_12)
        { /* block id: 66 */
            g_113--;
            if (p_9)
                break;
            p_9 &= (~(safe_sub_func_int8_t_s_s(((p_13 ^ p_12) , 0x19L), g_4.f0)));
            l_119 |= ((l_97[3][3] < 0x0B6653C3L) & p_13);
        }
        l_98 = (((!(((safe_unary_minus_func_int16_t_s(l_97[3][3])) != l_119) & l_98)) , 5UL) != 1UL);
    }
    else
    { /* block id: 73 */
        int32_t l_126[7] = {0x3DDF55D2L,(-4L),0x3DDF55D2L,0x3DDF55D2L,(-4L),0x3DDF55D2L,0x3DDF55D2L};
        int i;
        for (g_42 = 0; (g_42 != 30); g_42++)
        { /* block id: 76 */
            uint64_t l_127 = 0x7924F713FB69F9E0LL;
            p_9 = (safe_div_func_uint8_t_u_u((l_126[0] || p_13), l_127));
            g_94 = (((l_127 , p_13) <= g_93[7][7][0]) < 0x359DL);
        }
        for (g_42 = 0; (g_42 <= 38); ++g_42)
        { /* block id: 82 */
            return g_93[4][1][0];
        }
        l_126[0] &= (safe_lshift_func_int8_t_s_u(g_4.f2, 4));
        l_126[0] |= g_27[0];
    }
    l_98 = (((safe_lshift_func_int8_t_s_s(((!(~7UL)) > l_98), 3)) && 3L) >= g_24);
    p_9 = 0xF47EB60EL;
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_14 g_43 g_44 g_48 g_51
 * writes: g_6 g_42 g_47 g_48 g_51
 */
static int32_t  func_29(const int32_t  p_30, int32_t  p_31, uint16_t  p_32, int64_t  p_33, int32_t  p_34)
{ /* block id: 25 */
    for (g_6 = 0; (g_6 <= 6); g_6 += 1)
    { /* block id: 28 */
        int32_t l_45 = 0x870E7C4BL;
        int i;
        g_42 = (safe_rshift_func_uint8_t_u_u(247UL, 0));
        if (g_14[g_6])
            break;
        l_45 = ((g_43 , g_44[1]) , g_14[g_6]);
        if (g_14[g_6])
        { /* block id: 32 */
            int32_t l_46 = 0x5D6F9C23L;
            p_31 = (p_34 ^ g_14[g_6]);
            g_47[6][6] = (p_34 , l_46);
        }
        else
        { /* block id: 35 */
            ++g_48;
        }
    }
    --g_51;
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int32_t  func_35(uint32_t  p_36)
{ /* block id: 23 */
    const uint32_t l_39 = 0xDBD8D46CL;
    return l_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_44.f1 g_24 g_55 g_4.f1 g_42 g_48
 * writes: g_93 g_94
 */
static const int16_t  func_62(uint16_t  p_63, uint8_t  p_64, uint16_t  p_65, uint32_t  p_66)
{ /* block id: 44 */
    uint32_t l_91 = 0x05A4DEA9L;
    int16_t l_95 = (-5L);
    int32_t l_96[9][7][3] = {{{0L,0x41A25E91L,0x77C3F9E4L},{(-1L),0x2EA94D18L,0x6A3224D4L},{0x41A25E91L,0x41A25E91L,0x18F96B43L},{0x933D78BCL,(-1L),1L},{0x933D78BCL,0x56077E59L,0x74F060B1L},{0x41A25E91L,(-5L),5L},{(-1L),0x933D78BCL,0x74F060B1L}},{{0L,0xD0EF1DBDL,1L},{0x16D73FB0L,0xD0EF1DBDL,0x18F96B43L},{(-5L),0x933D78BCL,0x6A3224D4L},{5L,(-5L),0x77C3F9E4L},{(-5L),0x56077E59L,8L},{0x16D73FB0L,(-1L),8L},{0L,0x41A25E91L,0x77C3F9E4L}},{{(-1L),0x2EA94D18L,0x6A3224D4L},{0x41A25E91L,0x41A25E91L,0x18F96B43L},{0x933D78BCL,(-1L),1L},{0x933D78BCL,0x56077E59L,0x74F060B1L},{0x41A25E91L,(-5L),5L},{(-1L),0x933D78BCL,0x74F060B1L},{0L,0xD0EF1DBDL,1L}},{{0x16D73FB0L,0xD0EF1DBDL,0x18F96B43L},{(-5L),0x933D78BCL,0x6A3224D4L},{5L,(-5L),0x77C3F9E4L},{(-5L),0x56077E59L,8L},{0x16D73FB0L,(-1L),8L},{0L,0x41A25E91L,0x77C3F9E4L},{(-1L),0x2EA94D18L,0x6A3224D4L}},{{0x41A25E91L,0x41A25E91L,0x18F96B43L},{0x933D78BCL,(-1L),1L},{0x7A3E983FL,0x43B5DB32L,(-1L)},{0xE4FDE8E7L,0L,(-5L)},{0xFAEFD05EL,0x7A3E983FL,(-1L)},{1L,0x7EC92911L,0x2FB1C122L},{0x09ED79FFL,0x7EC92911L,0x933D78BCL}},{{0L,0x7A3E983FL,0x16D73FB0L},{0x61410948L,0L,5L},{0L,0x43B5DB32L,0x2EA94D18L},{0x09ED79FFL,0xE64750ADL,0x2EA94D18L},{1L,0xE4FDE8E7L,5L},{0xFAEFD05EL,0x2AC3FE91L,0x16D73FB0L},{0xE4FDE8E7L,0xE4FDE8E7L,0x933D78BCL}},{{0x7A3E983FL,0xE64750ADL,0x2FB1C122L},{0x7A3E983FL,0x43B5DB32L,(-1L)},{0xE4FDE8E7L,0L,(-5L)},{0xFAEFD05EL,0x7A3E983FL,(-1L)},{1L,0x7EC92911L,0x2FB1C122L},{0x09ED79FFL,0x7EC92911L,0x933D78BCL},{0L,0x7A3E983FL,0x16D73FB0L}},{{0x61410948L,0L,5L},{0L,0x43B5DB32L,0x2EA94D18L},{0x09ED79FFL,0xE64750ADL,0x2EA94D18L},{1L,0xE4FDE8E7L,5L},{0xFAEFD05EL,0x2AC3FE91L,0x16D73FB0L},{0xE4FDE8E7L,0xE4FDE8E7L,0x933D78BCL},{0x7A3E983FL,0xE64750ADL,0x2FB1C122L}},{{0x7A3E983FL,0x43B5DB32L,(-1L)},{0xE4FDE8E7L,0L,(-5L)},{0xFAEFD05EL,0x7A3E983FL,(-1L)},{1L,0x7EC92911L,0x2FB1C122L},{0x09ED79FFL,0x7EC92911L,0x933D78BCL},{0L,0x7A3E983FL,0x16D73FB0L},{0x61410948L,0L,5L}}};
    int i, j, k;
    for (p_63 = 0; (p_63 <= 13); p_63 = safe_add_func_uint64_t_u_u(p_63, 1))
    { /* block id: 47 */
        uint8_t l_92 = 253UL;
        if ((~((safe_mul_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u((((((safe_mod_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((((safe_mod_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(((safe_lshift_func_uint16_t_u_u(((g_44[1].f1 & 0xDAL) >= l_91), 5)) , g_24), 8)), l_91)) >= p_64) || 0x0B464957343453D9LL), g_55[3])), l_91)) == p_63) <= l_91) == 4UL) > p_63), 10)) , l_92), l_91)) < l_91)))
        { /* block id: 48 */
            g_93[4][1][0] = 0xF42CBA37L;
        }
        else
        { /* block id: 50 */
            return p_66;
        }
        g_94 = g_4.f1;
    }
    l_95 = g_42;
    l_96[5][0][2] &= p_63;
    return g_48;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4.f0, "g_4.f0", print_hash_value);
    transparent_crc(g_4.f1, "g_4.f1", print_hash_value);
    transparent_crc(g_4.f2, "g_4.f2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_24, "g_24", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_27[i], "g_27[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43.f0, "g_43.f0", print_hash_value);
    transparent_crc(g_43.f1, "g_43.f1", print_hash_value);
    transparent_crc(g_43.f2, "g_43.f2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_44[i].f0, "g_44[i].f0", print_hash_value);
        transparent_crc(g_44[i].f1, "g_44[i].f1", print_hash_value);
        transparent_crc(g_44[i].f2, "g_44[i].f2", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_47[i][j], "g_47[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_54[i], "g_54[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_55[i], "g_55[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_93[i][j][k], "g_93[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 21
breakdown:
   depth: 1, occurrence: 58
   depth: 2, occurrence: 14
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 19, occurrence: 1
   depth: 21, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 93
XXX times a non-volatile is write: 32
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 8
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 50
XXX percentage of non-volatile access: 85

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 56
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 17
   depth: 2, occurrence: 23

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
********************* end of statistics **********************/

