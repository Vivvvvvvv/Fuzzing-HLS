/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14988627412940147958
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_2 = (-2L);
static uint16_t g_3 = 1UL;
static int64_t g_4 = 0xA654FDDD3F467215LL;
static int32_t g_6[2][7][3] = {{{(-7L),3L,1L},{0x1DF82D83L,(-7L),(-7L)},{(-7L),0L,0x4E703026L},{0xA012E1DFL,0L,0x4E703026L},{0x989226C3L,0x4E703026L,(-7L)},{(-1L),6L,1L},{0x4E703026L,0x4E703026L,6L}},{{3L,0L,0L},{3L,0L,(-1L)},{0x4E703026L,(-7L),0L},{(-1L),3L,(-1L)},{0x989226C3L,0x83303773L,0L},{0xA012E1DFL,0x83303773L,6L},{(-7L),3L,1L}}};
static int8_t g_18 = 8L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_18
 * writes: g_3 g_4 g_6
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_5 = 0UL;
    int32_t l_7 = 0xFA32FD2DL;
    int32_t l_8 = 0x5969A22DL;
    int32_t l_9 = 0xEC326874L;
    int32_t l_10 = 0x6AEBA4D3L;
    int32_t l_11 = 0x25429297L;
    int32_t l_12 = (-6L);
    int32_t l_13 = 4L;
    int32_t l_14 = (-2L);
    int32_t l_15 = (-1L);
    int32_t l_16[2][10] = {{0x67684593L,2L,0x67684593L,0x67684593L,0x67684593L,0x6C0B333EL,0x6C0B333EL,0x67684593L,0x6C0B333EL,0x6C0B333EL},{0x67684593L,0x67684593L,2L,0x67684593L,0x67684593L,2L,0x67684593L,0x67684593L,2L,0x67684593L}};
    int32_t l_17 = (-1L);
    uint32_t l_19 = 0x49CE5708L;
    int i, j;
    g_3 = g_2;
    g_4 = 0x3DF603FAL;
    g_6[0][1][0] = (g_3 == l_5);
    l_19++;
    return g_18;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_18, "g_18", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 4
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 5
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 5

XXX percentage a fresh-made variable is used: 30
XXX percentage an existing variable is used: 70
********************* end of statistics **********************/

