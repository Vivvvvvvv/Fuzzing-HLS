/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17672791250432926625
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-1L);
static int32_t g_8 = 0xCCB03629L;
static int32_t g_39[8][1][10] = {{{3L,(-1L),1L,1L,(-1L),3L,(-1L),1L,1L,(-1L)}},{{3L,(-1L),1L,1L,(-1L),3L,(-1L),1L,1L,(-1L)}},{{3L,(-1L),1L,1L,(-1L),3L,(-1L),1L,1L,(-1L)}},{{3L,(-1L),1L,1L,(-1L),3L,(-1L),1L,1L,(-1L)}},{{3L,(-1L),1L,1L,(-1L),3L,1L,(-1L),(-1L),1L}},{{0x36511F0BL,1L,(-1L),(-1L),1L,0x36511F0BL,1L,(-1L),(-1L),1L}},{{0x36511F0BL,1L,(-1L),(-1L),1L,0x36511F0BL,1L,(-1L),(-1L),1L}},{{0x36511F0BL,1L,(-1L),(-1L),1L,0x36511F0BL,1L,(-1L),(-1L),1L}}};
static int32_t g_86 = 0x25CAFD93L;
static uint64_t g_99 = 0x165012FDBCC2C37ALL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const int32_t  func_9(uint32_t  p_10, uint64_t  p_11, uint64_t  p_12);
static uint16_t  func_15(int16_t  p_16, int64_t  p_17);
static uint8_t  func_25(uint16_t  p_26, int32_t  p_27, uint8_t  p_28, uint16_t  p_29, int8_t  p_30);
static int32_t  func_43(int16_t  p_44, uint32_t  p_45);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_39 g_8 g_86 g_99
 * writes: g_2 g_8 g_39
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_13[10] = {(-1L),0L,0L,(-1L),0L,0L,(-1L),0L,0L,(-1L)};
    int32_t l_105 = (-8L);
    uint8_t l_111 = 0x6CL;
    uint64_t l_128[9][4][1] = {{{0x9C1318B2E7E373B7LL},{18446744073709551615UL},{18446744073709551615UL},{0x9C1318B2E7E373B7LL}},{{18446744073709551615UL},{18446744073709551615UL},{0x9C1318B2E7E373B7LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x9C1318B2E7E373B7LL},{18446744073709551615UL},{18446744073709551615UL}},{{0x9C1318B2E7E373B7LL},{18446744073709551615UL},{18446744073709551615UL},{0x9C1318B2E7E373B7LL}},{{18446744073709551615UL},{18446744073709551615UL},{0x9C1318B2E7E373B7LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x9C1318B2E7E373B7LL},{18446744073709551615UL},{18446744073709551615UL}},{{0x9C1318B2E7E373B7LL},{18446744073709551615UL},{18446744073709551615UL},{0x9C1318B2E7E373B7LL}},{{18446744073709551615UL},{18446744073709551615UL},{0x9C1318B2E7E373B7LL},{18446744073709551615UL}},{{18446744073709551615UL},{0x9C1318B2E7E373B7LL},{18446744073709551615UL},{18446744073709551615UL}}};
    int i, j, k;
    for (g_2 = 0; (g_2 == 16); g_2 = safe_add_func_uint8_t_u_u(g_2, 6))
    { /* block id: 3 */
        uint32_t l_5 = 3UL;
        int32_t l_110 = 6L;
        if (l_5)
        { /* block id: 4 */
            int32_t l_14[10][2][6] = {{{0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL,0xAFC1DA7BL},{0xFDB69689L,1L,1L,0xFDB69689L,1L,0xFDB69689L}},{{0xFDB69689L,1L,0xFDB69689L,1L,1L,0xFDB69689L},{0xAFC1DA7BL,0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL}},{{1L,1L,0L,0L,1L,1L},{0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL,0xAFC1DA7BL}},{{0xFDB69689L,1L,1L,0xFDB69689L,1L,0xFDB69689L},{0xFDB69689L,1L,0xFDB69689L,1L,1L,0xFDB69689L}},{{0xAFC1DA7BL,0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL},{1L,1L,0L,0L,1L,1L}},{{0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL,0xAFC1DA7BL},{0xFDB69689L,1L,1L,0xFDB69689L,1L,0xFDB69689L}},{{0xFDB69689L,1L,0xFDB69689L,1L,1L,0xFDB69689L},{0xAFC1DA7BL,0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL}},{{1L,1L,0L,0L,1L,1L},{0xAFC1DA7BL,1L,0L,1L,0xAFC1DA7BL,0xAFC1DA7BL}},{{0xFDB69689L,1L,1L,0xFDB69689L,1L,0xFDB69689L},{0xFDB69689L,1L,0xFDB69689L,1L,1L,0xFDB69689L}},{{0xAFC1DA7BL,0xAFC1DA7BL,1L,1L,0xFDB69689L,1L},{0xFDB69689L,0xAFC1DA7BL,1L,1L,0xAFC1DA7BL,0xFDB69689L}}};
            int i, j, k;
            g_8 = (safe_div_func_uint64_t_u_u(g_2, 4UL));
            l_105 = func_9((((l_13[7] , 255UL) != l_13[5]) || l_14[2][1][0]), l_13[7], g_2);
        }
        else
        { /* block id: 59 */
            g_39[0][0][9] = ((safe_sub_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u((((g_39[4][0][3] <= 0x00L) ^ l_105) >= l_105), 65535UL)) , 0x18E1L), 0x3D26L)) <= 1UL);
        }
        g_39[0][0][9] = l_13[1];
        --l_111;
    }
    l_105 = (safe_div_func_uint64_t_u_u((g_39[5][0][4] < l_13[4]), g_86));
    g_2 ^= (safe_mul_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u(((safe_mod_func_uint32_t_u_u((safe_add_func_uint16_t_u_u(g_86, 65526UL)), g_86)) != g_39[0][0][9]), l_128[5][2][0])) >= l_13[7]), 0x1454L)), 3)), l_128[4][0][0]));
    g_2 = (safe_div_func_uint16_t_u_u(65530UL, g_86));
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_39 g_8 g_86 g_99
 * writes: g_39
 */
static const int32_t  func_9(uint32_t  p_10, uint64_t  p_11, uint64_t  p_12)
{ /* block id: 6 */
    const int8_t l_104 = (-1L);
    g_39[3][0][3] = (func_15(g_2, p_11) && 0x924AL);
    return l_104;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_39 g_8 g_86 g_99
 * writes: g_39
 */
static uint16_t  func_15(int16_t  p_16, int64_t  p_17)
{ /* block id: 7 */
    uint64_t l_20 = 0UL;
    int16_t l_35 = 0L;
lbl_100:
    l_20 |= (safe_rshift_func_uint16_t_u_u(0x9974L, 8));
    for (p_16 = 0; (p_16 >= 21); p_16++)
    { /* block id: 11 */
        int32_t l_103 = 3L;
        if ((safe_rshift_func_uint8_t_u_u(func_25((safe_div_func_uint32_t_u_u(((safe_sub_func_uint8_t_u_u(255UL, 0UL)) || l_35), l_35)), p_17, l_20, g_2, p_16), 1)))
        { /* block id: 45 */
            return g_99;
        }
        else
        { /* block id: 47 */
            if (g_2)
                goto lbl_100;
            g_39[4][0][1] = (safe_mod_func_uint32_t_u_u(g_2, 0x3183DA37L));
        }
        l_103 = l_103;
        l_103 = p_16;
        g_39[2][0][1] ^= g_2;
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_39 g_8 g_86
 * writes: g_39
 */
static uint8_t  func_25(uint16_t  p_26, int32_t  p_27, uint8_t  p_28, uint16_t  p_29, int8_t  p_30)
{ /* block id: 12 */
    int16_t l_36 = 7L;
    int32_t l_55 = 0x9B64A474L;
    uint16_t l_67[6] = {0x1266L,3UL,0x1266L,0x1266L,3UL,0x1266L};
    int32_t l_71 = (-9L);
    int32_t l_73 = (-1L);
    int32_t l_75 = 1L;
    int32_t l_76 = 0xEB866B6FL;
    int32_t l_77 = 0xA4BDFCF0L;
    int32_t l_89 = 8L;
    int32_t l_90 = 1L;
    int32_t l_91 = 0x264F7316L;
    int32_t l_92[10][10] = {{0x850C049AL,1L,(-1L),0x4C0ED61DL,0x43C15C23L,0x84A95BEAL,8L,0x84A95BEAL,0x43C15C23L,0x4C0ED61DL},{2L,(-8L),2L,0xC8A69409L,0x219E070DL,0x292A33AFL,4L,1L,0x1ECF65DDL,0L},{4L,1L,0x43C15C23L,1L,1L,0L,0x9BC801A5L,1L,1L,(-1L)},{1L,(-10L),2L,0xB654FA89L,0x1ECF65DDL,1L,1L,0x84A95BEAL,0L,0x292A33AFL},{7L,1L,(-1L),0L,0xD86C0845L,(-1L),(-9L),(-1L),0x4C0ED61DL,2L},{(-8L),0xD86C0845L,4L,(-1L),1L,1L,(-1L),4L,0xD86C0845L,(-8L)},{0x1BD54BCFL,0x84A95BEAL,0x70BFA85FL,0x053E2D80L,(-9L),0L,0x309CA0AEL,0x1ECF65DDL,0xEE10C307L,1L},{(-8L),1L,1L,0x84A95BEAL,(-9L),0L,1L,9L,1L,(-8L)},{(-9L),0x309CA0AEL,1L,1L,1L,0x1ECF65DDL,1L,(-1L),(-1L),2L},{9L,0L,0xC8A69409L,0x1BD54BCFL,0xD86C0845L,0xB654FA89L,1L,0x292A33AFL,0x9BC801A5L,0x292A33AFL}};
    int32_t l_93 = 0x7FF7C82FL;
    int32_t l_94 = 0x173883CAL;
    uint16_t l_96[8] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
    int i, j;
    l_36 = g_2;
    if (p_28)
    { /* block id: 14 */
        uint16_t l_38 = 0x2404L;
        int32_t l_42 = 0xCE33A902L;
        l_38 = (+(p_29 > 65527UL));
        g_39[0][0][9] ^= g_2;
        l_42 = ((safe_mul_func_uint8_t_u_u(l_36, 0x30L)) == l_38);
        if (func_43(p_29, p_30))
        { /* block id: 21 */
            l_42 ^= g_8;
        }
        else
        { /* block id: 23 */
            uint32_t l_48[7];
            int i;
            for (i = 0; i < 7; i++)
                l_48[i] = 4294967295UL;
            l_48[0] = g_2;
            g_39[0][0][9] = p_26;
            l_55 = (safe_div_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u(((safe_mod_func_uint64_t_u_u(((((65532UL < 9UL) >= 0x1AC6L) , l_36) , p_26), 1UL)) > p_30), 0xC2B13F3B720FAE23LL)) >= 9UL), l_36));
            return g_8;
        }
    }
    else
    { /* block id: 29 */
        int32_t l_63 = 0xF870A655L;
        int32_t l_66 = 0xC089A473L;
        int32_t l_74[6][10][4] = {{{0L,2L,0L,1L},{0xFF3B7F0DL,7L,1L,0xFC01934DL},{7L,0x3E57ECD0L,0x3E57ECD0L,7L},{0L,(-10L),1L,0x8812E5E4L},{0xAC2FF03EL,2L,1L,0xFF3B7F0DL},{0xC17BCF7AL,0xED3529ACL,0L,0xFF3B7F0DL},{0L,2L,1L,0x8812E5E4L},{0xFC01934DL,(-10L),0x4AF4489FL,7L},{0x287B7884L,0x3E57ECD0L,0x8812E5E4L,0xFC01934DL},{0L,7L,0L,1L}},{{2L,2L,1L,0x287B7884L},{2L,0x3E57ECD0L,0xED3529ACL,2L},{0L,0xFC01934DL,0xED3529ACL,0x8812E5E4L},{2L,0xFF3B7F0DL,1L,2L},{2L,0xED3529ACL,0L,0xC17BCF7AL},{0L,0xC17BCF7AL,0x8812E5E4L,0x8812E5E4L},{0x287B7884L,0x287B7884L,0x4AF4489FL,0x3E57ECD0L},{0L,0xD301F6F3L,2L,0L},{0xE47109BDL,0x3E57ECD0L,0x35ACB962L,2L},{0xA774B632L,0x3E57ECD0L,(-10L),0L}},{{0x3E57ECD0L,0xD301F6F3L,0x4AF4489FL,0x3E57ECD0L},{0xC0142974L,0L,0xD301F6F3L,0x0066BE38L},{1L,0xA774B632L,(-10L),0xA774B632L},{0x8812E5E4L,1L,0xC0142974L,1L},{0xE47109BDL,0x8812E5E4L,0x6454C9BFL,0x0066BE38L},{0L,0L,0xFC01934DL,0xED3529ACL},{0L,0xD301F6F3L,0x6454C9BFL,0L},{0xE47109BDL,0xED3529ACL,0xC0142974L,2L},{0x8812E5E4L,1L,(-10L),0L},{1L,0xD301F6F3L,0xD301F6F3L,1L}},{{0xC0142974L,0L,0x4AF4489FL,0x0066BE38L},{0x3E57ECD0L,1L,(-10L),0x8812E5E4L},{0xA774B632L,1L,0x35ACB962L,0x8812E5E4L},{0xE47109BDL,1L,2L,0x0066BE38L},{0L,0L,0xFC01934DL,1L},{0L,0xD301F6F3L,0x0066BE38L,0L},{0xE47109BDL,1L,0xE47109BDL,2L},{1L,0xED3529ACL,(-10L),0L},{0xED3529ACL,0xD301F6F3L,1L,0xED3529ACL},{0xC0142974L,0L,1L,0x0066BE38L}},{{0xED3529ACL,0x8812E5E4L,(-10L),1L},{1L,1L,0xE47109BDL,0xA774B632L},{0xE47109BDL,0xA774B632L,0x0066BE38L,0x0066BE38L},{0L,0L,0xFC01934DL,0x3E57ECD0L},{0L,0xD301F6F3L,2L,0L},{0xE47109BDL,0x3E57ECD0L,0x35ACB962L,2L},{0xA774B632L,0x3E57ECD0L,(-10L),0L},{0x3E57ECD0L,0xD301F6F3L,0x4AF4489FL,0x3E57ECD0L},{0xC0142974L,0L,0xD301F6F3L,0x0066BE38L},{1L,0xA774B632L,(-10L),0xA774B632L}},{{0x8812E5E4L,1L,0xC0142974L,1L},{0xE47109BDL,0x8812E5E4L,0x6454C9BFL,0x0066BE38L},{0L,0L,0xFC01934DL,0xED3529ACL},{0L,0xD301F6F3L,0x6454C9BFL,0L},{0xE47109BDL,0xED3529ACL,0xC0142974L,2L},{0x8812E5E4L,1L,(-10L),0L},{1L,0xD301F6F3L,0xD301F6F3L,1L},{0xC0142974L,0L,0x4AF4489FL,0x0066BE38L},{0x3E57ECD0L,1L,(-10L),0x8812E5E4L},{0xA774B632L,1L,0x35ACB962L,0x8812E5E4L}}};
        uint64_t l_78 = 0xDDC8DEE7960B978FLL;
        int32_t l_95[6][10][4] = {{{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L}},{{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L}},{{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L}},{{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L}},{{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L}},{{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L},{0x2F5D31D5L,(-1L),0xF665F5ADL,0x76EE3E29L},{0xF91A75F8L,1L,(-1L),0x76EE3E29L},{0x7B5E8C0CL,(-1L),0xC8505D4FL,0x76EE3E29L},{0x76EE3E29L,1L,1L,0x76EE3E29L}}};
        int i, j, k;
        if ((safe_add_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(0x54L, l_55)), 0)), 253UL)))
        { /* block id: 30 */
            g_39[0][0][9] = (((+l_63) , p_26) || 0x52D4L);
            l_66 ^= (((((safe_add_func_uint8_t_u_u(g_8, g_39[0][0][9])) ^ 18446744073709551612UL) <= g_2) == g_39[2][0][8]) <= 0xB6EA11B98B5DB27CLL);
            g_39[5][0][3] |= l_55;
            l_66 = ((((l_67[3] != 9UL) , g_2) == p_28) , (-1L));
        }
        else
        { /* block id: 35 */
            int64_t l_68 = 0x00147550418440ACLL;
            int32_t l_69 = (-6L);
            int32_t l_70 = 0x7A8F3E70L;
            int32_t l_72 = 0xB9F09720L;
            ++l_78;
            l_77 = (((safe_rshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((+0UL), 1)), p_30)) , g_86) <= 1UL);
            l_72 = (safe_lshift_func_uint8_t_u_u(((0x6FL < g_8) == g_39[6][0][2]), p_30));
        }
        l_96[1]++;
        l_71 = l_36;
        l_77 = (l_96[1] < 0xEF75D212L);
    }
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_43(int16_t  p_44, uint32_t  p_45)
{ /* block id: 18 */
    uint8_t l_46[8][4] = {{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL},{1UL,0xE5L,0xE5L,1UL}};
    int32_t l_47 = (-5L);
    int i, j;
    l_47 = ((l_46[0][2] >= 0x75E6L) == l_46[7][1]);
    return l_46[7][0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_39[i][j][k], "g_39[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_99, "g_99", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 44
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 57
   depth: 2, occurrence: 8
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 77
XXX times a non-volatile is write: 35
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 48
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 15
   depth: 2, occurrence: 18

XXX percentage a fresh-made variable is used: 18
XXX percentage an existing variable is used: 82
********************* end of statistics **********************/

