/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1004197464335003906
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int8_t  f0;
   volatile uint32_t  f1;
   volatile uint32_t  f2;
   volatile int8_t  f3;
   uint32_t  f4;
   int32_t  f5;
   volatile int32_t  f6;
   uint32_t  f7;
   int16_t  f8;
   uint32_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-2L);/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0xD11D962EL;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6[6] = {0x058A835AL,0x058A835AL,0x058A835AL,0x058A835AL,0x058A835AL,0x058A835AL};
static volatile int32_t g_7 = 0L;/* VOLATILE GLOBAL g_7 */
static int32_t g_8[9][7][4] = {{{6L,1L,0x06C0F1A0L,0x05B8B78AL},{1L,(-7L),7L,5L},{(-1L),0L,0x6EF6F0C3L,0xEA964A90L},{4L,0x1CD43096L,1L,(-1L)},{(-1L),0x79A20B28L,0x0EF874ACL,5L},{0x3631E19EL,1L,0x05B8B78AL,(-1L)},{(-9L),0xC4B7C700L,(-5L),0L}},{{0L,(-4L),0L,0x6D402DA3L},{0x4D1B40E1L,(-5L),0xF7CF8FB6L,(-1L)},{0x334ADC6FL,6L,0x79A20B28L,0xADF62858L},{0L,(-1L),(-4L),(-7L)},{0L,(-4L),0L,0x0284818AL},{0xC4B7C700L,0x05B8B78AL,0xC4B7C700L,7L},{0xE11914CCL,0x540EE1D4L,(-1L),0x10CBEDFAL}},{{(-1L),0x1CD43096L,0x4D1B40E1L,0x540EE1D4L},{0xBD697E78L,0xC4B7C700L,0x4D1B40E1L,0x60D743CCL},{(-1L),5L,(-1L),0L},{0xE11914CCL,(-1L),0xC4B7C700L,5L},{0xC4B7C700L,5L,0L,0L},{0L,8L,(-4L),0xE11914CCL},{0L,0x0EF874ACL,(-1L),0x06C0F1A0L}},{{0x47D17017L,0x79A20B28L,0x06C0F1A0L,8L},{0x6D402DA3L,0xBACDE9E8L,0x68FAB8D2L,0x3D21462CL},{0x4D1B40E1L,0L,(-1L),1L},{0x12C51978L,0x4D1B40E1L,0xB15E314AL,2L},{(-5L),0x0284818AL,0x6EF6F0C3L,0x47D17017L},{0xF7CF8FB6L,0x10CBEDFAL,0L,1L},{7L,4L,4L,7L}},{{0x05B8B78AL,0xB15E314AL,0x2E40C18AL,0L},{0L,(-5L),(-7L),0L},{0x5A8DF044L,1L,0xF7CF8FB6L,0L},{0x540EE1D4L,(-5L),0xBACDE9E8L,0L},{0x06C0F1A0L,0xB15E314AL,0xE11914CCL,7L},{0x53FFD03BL,4L,0x1CD43096L,1L},{(-1L),0x10CBEDFAL,7L,0x47D17017L}},{{0L,0x0284818AL,6L,2L},{(-1L),0x4D1B40E1L,0L,1L},{6L,0L,(-1L),0x3D21462CL},{5L,0xBACDE9E8L,0x0EF874ACL,8L},{8L,0x79A20B28L,0x3631E19EL,0x06C0F1A0L},{0L,0x0EF874ACL,0x60D743CCL,0xE11914CCL},{(-1L),8L,0L,0L}},{{1L,5L,8L,5L},{0x6EF6F0C3L,(-1L),7L,0L},{0x79A20B28L,5L,0x53FFD03BL,0x60D743CCL},{2L,0xC4B7C700L,0L,0x540EE1D4L},{2L,0x1CD43096L,0x53FFD03BL,0x10CBEDFAL},{0x79A20B28L,0x540EE1D4L,7L,7L},{0x6EF6F0C3L,0x05B8B78AL,8L,0x0284818AL}},{{1L,(-4L),0L,(-7L)},{(-1L),(-1L),0x60D743CCL,0xC4B7C700L},{0L,0x5A8DF044L,0x3631E19EL,0x334ADC6FL},{8L,0xADF62858L,0x0EF874ACL,0L},{5L,0x19C9214AL,(-1L),0x53FFD03BL},{6L,0xEA964A90L,0L,0x0EF874ACL},{(-1L),0x60D743CCL,6L,(-1L)}},{{0L,(-1L),7L,0x05B8B78AL},{(-1L),0L,0x1CD43096L,0L},{0xE11914CCL,0xE11914CCL,5L,0x12C51978L},{(-7L),0xBD697E78L,0L,7L},{1L,0x68FAB8D2L,0x06C0F1A0L,0L},{8L,0x68FAB8D2L,0L,7L},{0x68FAB8D2L,0xBD697E78L,0x79A20B28L,0x12C51978L}}};
static struct S0 g_35 = {-7L,2UL,2UL,0x75L,0x6E024B17L,-6L,0x0DD081FBL,0x192EEDB0L,0x1D9DL,0x0CD947E9L};/* VOLATILE GLOBAL g_35 */
static int16_t g_36 = 0L;
static int32_t g_67 = 0x363BB6A5L;
static volatile int16_t g_93 = 4L;/* VOLATILE GLOBAL g_93 */
static uint16_t g_142 = 2UL;
static volatile int16_t g_151 = 8L;/* VOLATILE GLOBAL g_151 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint16_t  func_11(const int16_t  p_12, const uint32_t  p_13, uint32_t  p_14, int8_t  p_15);
static struct S0  func_28(int16_t  p_29, uint32_t  p_30, uint8_t  p_31, int64_t  p_32);
static struct S0  func_42(int32_t  p_43, int8_t  p_44, int8_t  p_45, const uint32_t  p_46);
static int32_t  func_54(int32_t  p_55, int8_t  p_56, uint32_t  p_57, const int32_t  p_58, int8_t  p_59);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_6 g_7 g_5 g_35 g_36 g_3 g_151
 * writes: g_8 g_35 g_5 g_4 g_36 g_67 g_142 g_7
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[5] = {0L,0L,0L,0L,0L};
    uint32_t l_38[6][6][7] = {{{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL},{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL},{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL}},{{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL},{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL},{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL}},{{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL},{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL}},{{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL},{0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL,1UL,0xEF177DAEL},{1UL,1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL},{1UL,1UL,1UL,1UL,1UL,1UL,1UL},{1UL,0x85D54DBCL,0x85D54DBCL,1UL,1UL,0x85D54DBCL,0x85D54DBCL}}};
    int64_t l_92 = 5L;
    uint16_t l_109 = 0xF6DFL;
    uint64_t l_163 = 6UL;
    int i, j, k;
    for (g_8[1][6][1] = 1; (g_8[1][6][1] <= 4); g_8[1][6][1] += 1)
    { /* block id: 3 */
        int i;
        l_2[g_8[1][6][1]] = (((safe_lshift_func_uint16_t_u_s(func_11(l_2[g_8[1][6][1]], g_6[2], g_8[7][0][3], g_8[1][6][1]), 13)) && g_7) & l_2[g_8[1][6][1]]);
    }
    if (((0UL || l_2[2]) ^ g_6[2]))
    { /* block id: 9 */
        const uint32_t l_22 = 0x3D0097E4L;
        int32_t l_23 = 1L;
        int32_t l_24 = 0xEDC29BFBL;
        if (func_11(((((safe_add_func_uint16_t_u_u((g_5 ^ l_2[1]), g_8[1][6][1])) , l_2[4]) , 0xA2DD3184L) , l_22), l_22, g_8[3][3][1], g_8[5][6][0]))
        { /* block id: 10 */
            uint64_t l_25 = 0x2B81468F30040642LL;
            int32_t l_37 = 0x519F073EL;
            l_25++;
            g_35 = func_28((!(l_25 != 1UL)), g_7, g_8[1][6][1], g_8[2][0][0]);
            --l_38[4][2][2];
        }
        else
        { /* block id: 17 */
            const int8_t l_49[1] = {(-10L)};
            int i;
            g_4 = (!(func_42((safe_mul_func_int8_t_s_s((func_11(g_35.f1, g_8[8][5][2], g_35.f0, g_8[5][3][3]) & (-1L)), 0xEBL)), g_35.f8, l_24, l_49[0]) , 1L));
            if (l_24)
                goto lbl_76;
        }
lbl_76:
        l_23 = ((!((g_35.f1 ^ l_2[0]) < 0xF415013FL)) <= 0xC67737D68548FAEALL);
        g_4 = (safe_sub_func_uint16_t_u_u(1UL, (-1L)));
    }
    else
    { /* block id: 40 */
        int32_t l_85 = 6L;
        int32_t l_86 = 0x3139573EL;
        int32_t l_91 = 7L;
        int32_t l_94 = 9L;
        int32_t l_96 = 0x4CB8E999L;
        int32_t l_100[9] = {2L,2L,2L,2L,2L,2L,2L,2L,2L};
        uint64_t l_101 = 0xE2533209CDE0C07DLL;
        int32_t l_118[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int16_t l_120[7][4][8] = {{{4L,(-1L),(-1L),(-7L),3L,0x3248L,1L,(-1L)},{(-6L),2L,0x645DL,0x55A9L,(-7L),0x3248L,0x55A9L,0x4C82L},{(-1L),(-1L),0xE321L,0x6BD4L,(-6L),0x780BL,(-6L),0x6BD4L},{0x4C82L,0x6BD4L,0x4C82L,0L,1L,(-1L),1L,1L}},{{0L,1L,2L,0L,0L,0x645DL,1L,0x4C82L},{0L,0x55A9L,0x780BL,0x8576L,1L,0xE321L,3L,3L},{0x4C82L,(-6L),(-7L),(-7L),(-6L),0x4C82L,2L,0x8576L},{(-1L),1L,0L,(-1L),(-7L),2L,(-1L),4L}},{{(-6L),1L,0x780BL,(-1L),3L,0x780BL,0L,0x8576L},{4L,3L,1L,(-7L),(-1L),(-7L),1L,3L},{0x55A9L,2L,4L,0x8576L,8L,0xF227L,0L,0x5D3AL},{0x4C82L,4L,(-1L),2L,(-7L),(-1L),0L,1L}},{{0x5D3AL,2L,(-2L),0xF227L,(-1L),0xCFB5L,0xCFB5L,(-1L)},{(-1L),0xCFB5L,0xCFB5L,(-1L),0xF227L,(-2L),2L,0x5D3AL},{1L,0L,(-1L),(-7L),2L,(-1L),4L,0x4C82L},{0x5D3AL,0L,0xF227L,8L,0L,(-2L),0x780BL,(-7L)}},{{0x645DL,0xCFB5L,8L,4L,8L,0xCFB5L,0x645DL,(-2L)},{0L,2L,(-1L),0x645DL,0x4C82L,(-1L),1L,0x3248L},{(-2L),4L,0x780BL,8L,0x4C82L,0xF227L,0xCFB5L,4L},{0L,0x780BL,0x5D3AL,0x3248L,8L,8L,0x3248L,0x5D3AL}},{{0x645DL,0x645DL,(-1L),1L,0L,(-1L),(-7L),2L},{0x5D3AL,1L,0xAC0BL,0xF227L,2L,0x780BL,0xCFB5L,2L},{1L,0xCFB5L,0xE321L,1L,0xF227L,0x5D3AL,(-1L),0x5D3AL},{(-1L),0x3248L,(-1L),0x3248L,(-1L),(-1L),0x4C82L,4L}},{{0x5D3AL,(-7L),0x76BFL,8L,(-7L),0xAC0BL,0x780BL,0x3248L},{0x4C82L,0xCFB5L,0x76BFL,0x645DL,8L,0xE321L,0x4C82L,(-2L)},{(-7L),(-1L),(-1L),4L,4L,(-1L),(-1L),(-7L)},{(-2L),0x4C82L,0xE321L,8L,0x645DL,0x76BFL,0xCFB5L,0x4C82L}}};
        uint64_t l_122 = 1UL;
        uint32_t l_131 = 0xF3A0D9A2L;
        int i, j, k;
        for (g_35.f4 = (-6); (g_35.f4 <= 49); g_35.f4++)
        { /* block id: 43 */
            int32_t l_81 = (-1L);
            int32_t l_82 = 0xC1F71C78L;
            int32_t l_83 = (-9L);
            int16_t l_84 = (-3L);
            int32_t l_87 = 0xC39CF3F9L;
            int32_t l_88 = (-6L);
            int8_t l_89 = (-6L);
            int32_t l_90 = 5L;
            int16_t l_95 = 0xCA6AL;
            int32_t l_97 = 0x48A18BD6L;
            int32_t l_98 = (-4L);
            int32_t l_99[7];
            int i;
            for (i = 0; i < 7; i++)
                l_99[i] = 7L;
            l_101--;
            l_96 = (safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u(g_8[7][6][3], 2)) | l_85), l_100[8]));
        }
        l_109 ^= ((safe_unary_minus_func_int64_t_s(((((l_92 | l_2[1]) != 0xC9762EA7L) < l_94) & g_35.f5))) == g_7);
        if ((((safe_sub_func_int8_t_s_s((safe_mod_func_int64_t_s_s(0xB50DB93F61EF617CLL, l_38[0][3][3])), l_100[7])) && l_109) , 0L))
        { /* block id: 48 */
            int8_t l_114[5][9][4] = {{{0L,0xECL,0x5EL,0x23L},{0xA0L,0xF2L,0L,0xFBL},{1L,0x6BL,1L,8L},{0x6EL,2L,0xDAL,7L},{2L,7L,0x41L,1L},{1L,0x6AL,1L,1L},{0xF2L,0x84L,(-6L),(-7L)},{0L,0x37L,0x1CL,7L},{0x82L,1L,(-9L),(-2L)}},{{(-6L),1L,1L,(-10L)},{0L,(-7L),0x60L,2L},{0x5EL,0x8FL,(-2L),0x2AL},{0xBDL,0xDAL,0xF8L,0xBDL},{0xFBL,0x32L,0x37L,2L},{0x6AL,5L,0x33L,7L},{0x6EL,0x8DL,8L,1L},{0x6EL,0x33L,0x33L,(-10L)},{0x6AL,1L,0x37L,0xC3L}},{{0xFBL,1L,0x8DL,0x8DL},{0x33L,0xCAL,0x07L,1L},{(-9L),1L,1L,0x00L},{0x5EL,1L,0x2AL,0x33L},{0x00L,1L,1L,0xCAL},{1L,0x5EL,0x8DL,(-2L)},{0x3AL,0xECL,0x00L,0xF2L},{1L,7L,0xC3L,1L},{0L,8L,0L,0x32L}},{{(-7L),0x8DL,0xBDL,0L},{0L,1L,2L,0x84L},{(-10L),0x23L,1L,1L},{8L,0xF8L,(-9L),0x8FL},{1L,(-6L),0xCEL,1L},{0L,7L,0L,0xF8L},{1L,(-5L),(-5L),1L},{1L,0x6BL,0L,0x8DL},{0x37L,0xDDL,0x7BL,0xCEL}},{{0xECL,0L,(-2L),0xCEL},{2L,0xDDL,0x5EL,0x8DL},{1L,0x6BL,0x1DL,1L},{0xA0L,(-5L),(-5L),0xF8L},{1L,7L,0xECL,1L},{1L,(-6L),1L,0x8FL},{7L,0xF8L,1L,1L},{0x41L,0x23L,0x8FL,0x84L},{7L,1L,7L,0L}}};
            int i, j, k;
            l_2[0] = l_114[4][7][3];
        }
        else
        { /* block id: 50 */
            int16_t l_115 = 0x19DEL;
            int32_t l_117 = 1L;
            int32_t l_119 = 0x4FF77B4AL;
            int32_t l_121 = 1L;
            int32_t l_125 = 1L;
            int32_t l_126 = 0xB5F68378L;
            int32_t l_127 = 1L;
            int32_t l_128 = (-1L);
            int32_t l_129 = 0L;
            int32_t l_130[7][8] = {{0L,7L,7L,0L,0x6F4D311DL,0x5F7C6F1CL,7L,(-9L)},{(-7L),0L,0x5B11B79EL,7L,0x5B11B79EL,0L,(-7L),7L},{0x5B11B79EL,0L,(-7L),7L,0x5F7C6F1CL,0x5F7C6F1CL,7L,(-7L)},{7L,7L,0L,0x6F4D311DL,0x5F7C6F1CL,7L,(-9L),7L},{0x5B11B79EL,(-7L),0x6F4D311DL,(-7L),0x5B11B79EL,7L,7L,7L},{(-7L),0x5F7C6F1CL,(-9L),0x6F4D311DL,0x6F4D311DL,(-9L),0x5F7C6F1CL,(-7L)},{0L,7L,(-9L),7L,7L,0x5B11B79EL,7L,7L}};
            int i, j;
            l_2[0] &= 8L;
            if (l_109)
                goto lbl_116;
lbl_116:
            l_115 = 0xE15430F9L;
            l_122--;
            l_131++;
        }
        g_5 = (safe_mul_func_uint8_t_u_u(((g_35.f3 != g_35.f9) , g_35.f5), g_35.f0));
    }
    for (g_35.f7 = 0; (g_35.f7 <= 5); g_35.f7 += 1)
    { /* block id: 61 */
        uint32_t l_136 = 0UL;
        for (g_35.f5 = 5; (g_35.f5 >= 1); g_35.f5 -= 1)
        { /* block id: 64 */
            g_5 = l_2[2];
            if (l_136)
                break;
            l_2[3] &= ((safe_mul_func_int8_t_s_s((0x242EEF4D9A01408CLL && g_3), l_92)) && l_38[1][2][2]);
        }
        for (g_36 = 5; (g_36 >= 0); g_36 -= 1)
        { /* block id: 71 */
            g_67 = g_6[2];
            return g_35.f5;
        }
        for (g_35.f0 = 5; (g_35.f0 >= 0); g_35.f0 -= 1)
        { /* block id: 77 */
            l_2[1] = l_136;
            if (g_5)
                break;
            g_8[3][1][3] = (safe_mod_func_uint16_t_u_u((g_5 < l_38[4][2][2]), l_136));
        }
    }
    if ((g_6[2] , g_35.f6))
    { /* block id: 83 */
        uint64_t l_141 = 0x6437F609D877C5E7LL;
        g_142 = ((0x2E5B4F79F911611CLL != l_141) >= g_7);
    }
    else
    { /* block id: 85 */
        int64_t l_143 = 0x0961C7848F6BBE48LL;
        int32_t l_144 = 0x4CEE256FL;
        int32_t l_173 = 5L;
        int64_t l_177 = 9L;
        uint8_t l_179 = 248UL;
        for (g_35.f4 = 0; (g_35.f4 <= 5); g_35.f4 += 1)
        { /* block id: 88 */
            l_144 |= (g_5 || l_143);
            g_4 = 1L;
            g_8[1][6][1] = ((safe_rshift_func_int8_t_s_s(((safe_add_func_int64_t_s_s((safe_rshift_func_int8_t_s_u(l_38[1][0][3], l_109)), g_151)) | l_143), g_35.f7)) && l_38[4][3][4]);
        }
        if (l_143)
        { /* block id: 93 */
            uint16_t l_156[1];
            int i;
            for (i = 0; i < 1; i++)
                l_156[i] = 1UL;
            l_156[0] = (safe_div_func_uint64_t_u_u((safe_div_func_int8_t_s_s(0x76L, l_143)), 0x6AF810B9F66EA20ALL));
            g_4 = (((safe_div_func_int32_t_s_s(((((((safe_rshift_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((g_35.f2 , l_163), g_35.f7)), 5)) >= 0x7177L) > g_35.f8) , l_143) >= g_35.f0) , g_3), g_8[3][0][2])) <= 0x64E080E16A57D192LL) < 0UL);
        }
        else
        { /* block id: 96 */
            uint16_t l_168 = 0x3146L;
            int32_t l_171 = 0L;
            int32_t l_172 = 1L;
            int32_t l_174 = 0xCDADA2B9L;
            int32_t l_175 = 0xAF432EDFL;
            int32_t l_176 = 0xE7D68A63L;
            int32_t l_178 = (-8L);
            g_7 = (safe_rshift_func_int16_t_s_s((safe_sub_func_int8_t_s_s(((g_151 != l_2[0]) ^ g_35.f5), l_168)), l_143));
            l_171 ^= (safe_rshift_func_int8_t_s_u(g_8[2][6][2], l_168));
            ++l_179;
        }
    }
    return l_109;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_11(const int16_t  p_12, const uint32_t  p_13, uint32_t  p_14, int8_t  p_15)
{ /* block id: 4 */
    int32_t l_17 = 3L;
    uint32_t l_18 = 1UL;
    int32_t l_19[3][1];
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_19[i][j] = (-1L);
    }
    l_19[0][0] ^= ((!(((l_17 && l_18) & l_18) , p_14)) <= 0xE0512ED4033E270BLL);
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_8 g_35
 * writes:
 */
static struct S0  func_28(int16_t  p_29, uint32_t  p_30, uint8_t  p_31, int64_t  p_32)
{ /* block id: 12 */
    int32_t l_34 = (-10L);
    l_34 |= (g_6[4] != g_8[2][6][1]);
    return g_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_35.f7 g_35.f8 g_35.f4 g_35.f0 g_36 g_5 g_35
 * writes: g_35.f7 g_35.f8 g_5
 */
static struct S0  func_42(int32_t  p_43, int8_t  p_44, int8_t  p_45, const uint32_t  p_46)
{ /* block id: 18 */
    int32_t l_60 = (-2L);
    int32_t l_62 = 0x5E7C9E84L;
    int32_t l_65 = 0L;
    int32_t l_66 = 0xF81C7DC7L;
    int32_t l_68 = 0x584F164EL;
    int32_t l_69[8];
    int i;
    for (i = 0; i < 8; i++)
        l_69[i] = 0xF5B2801FL;
    for (g_35.f7 = 0; (g_35.f7 == 13); ++g_35.f7)
    { /* block id: 21 */
        uint32_t l_61[9] = {0x35E3094FL,0x35E3094FL,8UL,0x35E3094FL,0x35E3094FL,8UL,4294967295UL,4294967295UL,0x35E3094FL};
        int32_t l_63 = 0xC381FEC7L;
        int32_t l_64 = (-4L);
        int32_t l_70[6];
        int64_t l_71 = (-2L);
        uint32_t l_72 = 0x07CA36F2L;
        int i;
        for (i = 0; i < 6; i++)
            l_70[i] = 0x6A81A3A0L;
        for (g_35.f8 = 0; (g_35.f8 > 18); g_35.f8++)
        { /* block id: 24 */
            g_5 &= func_54(g_35.f4, l_60, l_61[1], p_43, p_46);
            return g_35;
        }
        l_62 = (l_60 , (-8L));
        --l_72;
    }
    return g_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_35.f0 g_36
 * writes:
 */
static int32_t  func_54(int32_t  p_55, int8_t  p_56, uint32_t  p_57, const int32_t  p_58, int8_t  p_59)
{ /* block id: 25 */
    p_55 = g_35.f0;
    return g_36;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_8[i][j][k], "g_8[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_35.f0, "g_35.f0", print_hash_value);
    transparent_crc(g_35.f1, "g_35.f1", print_hash_value);
    transparent_crc(g_35.f2, "g_35.f2", print_hash_value);
    transparent_crc(g_35.f3, "g_35.f3", print_hash_value);
    transparent_crc(g_35.f4, "g_35.f4", print_hash_value);
    transparent_crc(g_35.f5, "g_35.f5", print_hash_value);
    transparent_crc(g_35.f6, "g_35.f6", print_hash_value);
    transparent_crc(g_35.f7, "g_35.f7", print_hash_value);
    transparent_crc(g_35.f8, "g_35.f8", print_hash_value);
    transparent_crc(g_35.f9, "g_35.f9", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 80
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 63
   depth: 2, occurrence: 15
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 4
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 92
XXX times a non-volatile is write: 37
XXX times a volatile is read: 22
XXX    times read thru a pointer: 0
XXX times a volatile is write: 8
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 181
XXX percentage of non-volatile access: 81.1

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 61
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 17
   depth: 2, occurrence: 31

XXX percentage a fresh-made variable is used: 21.7
XXX percentage an existing variable is used: 78.3
********************* end of statistics **********************/

