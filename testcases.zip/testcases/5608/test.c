/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      351572470914285294
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_8 = 0UL;
static int64_t g_15 = 0xE94F934F545EE28FLL;
static uint32_t g_23 = 0x389A9B8FL;
static int16_t g_43 = 0xC70EL;
static int64_t g_51 = 0L;
static int32_t g_57 = (-2L);
static volatile uint64_t g_60[10][4][6] = {{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}},{{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL},{0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL,0xCF2842C5ACC8E11FLL}}};
static uint32_t g_66 = 0x6264A05AL;
static volatile uint16_t g_79 = 0xA0C9L;/* VOLATILE GLOBAL g_79 */
static int32_t g_80 = 0L;
static uint8_t g_85[1][6][1] = {{{1UL},{1UL},{1UL},{1UL},{1UL},{1UL}}};
static volatile int64_t g_99 = 5L;/* VOLATILE GLOBAL g_99 */
static uint8_t g_101 = 0x2BL;
static uint32_t g_106 = 18446744073709551606UL;
static uint8_t g_117 = 1UL;
static int8_t g_120 = 0x03L;
static uint16_t g_128 = 9UL;
static uint16_t g_131 = 4UL;
static uint32_t g_140 = 18446744073709551615UL;
static volatile int16_t g_143 = 0xA815L;/* VOLATILE GLOBAL g_143 */
static volatile uint8_t g_144[2][1][9] = {{{1UL,248UL,1UL,1UL,248UL,1UL,1UL,248UL,1UL}},{{1UL,248UL,1UL,1UL,248UL,1UL,1UL,248UL,1UL}}};
static uint32_t g_154 = 1UL;
static uint32_t g_156 = 0x6B522420L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static const int32_t  func_2(int8_t  p_3, uint16_t  p_4, int8_t  p_5, int16_t  p_6);
static uint8_t  func_29(int32_t  p_30, int16_t  p_31, int8_t  p_32, int16_t  p_33);
static uint32_t  func_39(const uint64_t  p_40);
static uint64_t  func_44(int8_t  p_45, uint32_t  p_46, int32_t  p_47, int32_t  p_48, int32_t  p_49);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_15 g_23 g_51 g_43 g_79 g_66 g_80 g_85 g_57 g_101 g_106 g_128 g_120 g_131 g_117 g_140 g_144
 * writes: g_15 g_23 g_43 g_51 g_8 g_57 g_60 g_66 g_79 g_80 g_85 g_101 g_106 g_117 g_120 g_128 g_131 g_140 g_144 g_154 g_156
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_7 = 5L;
    int32_t l_26 = 6L;
    l_26 = func_2(l_7, g_8, g_8, l_7);
    g_156 = ((safe_mul_func_uint8_t_u_u(func_29(g_23, g_23, l_26, l_7), 254UL)) && 4294967295UL);
    return g_117;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_15 g_23
 * writes: g_15 g_23
 */
static const int32_t  func_2(int8_t  p_3, uint16_t  p_4, int8_t  p_5, int16_t  p_6)
{ /* block id: 1 */
    uint8_t l_14[5];
    int32_t l_18 = 0x24307A32L;
    int32_t l_21 = 0x4891023FL;
    int32_t l_22 = 0L;
    int i;
    for (i = 0; i < 5; i++)
        l_14[i] = 254UL;
    g_15 |= (safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((+g_8), l_14[2])), p_3));
    l_18 = ((safe_add_func_uint32_t_u_u((0x33F23E93D0B5486BLL > l_14[1]), 0x73417203L)) ^ g_15);
    l_18 = (safe_mul_func_uint8_t_u_u(1UL, l_14[3]));
    ++g_23;
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_8 g_23 g_51 g_43 g_79 g_66 g_80 g_85 g_57 g_101 g_106 g_128 g_120 g_131 g_117 g_140 g_144
 * writes: g_43 g_51 g_8 g_57 g_60 g_66 g_79 g_80 g_85 g_101 g_106 g_117 g_120 g_128 g_131 g_140 g_144 g_154
 */
static uint8_t  func_29(int32_t  p_30, int16_t  p_31, int8_t  p_32, int16_t  p_33)
{ /* block id: 8 */
    int16_t l_34 = (-1L);
    int32_t l_90 = 0L;
    int32_t l_100 = (-1L);
    int8_t l_139 = 2L;
    uint32_t l_155 = 0x6E2EDB36L;
    if (l_34)
    { /* block id: 9 */
        uint64_t l_88 = 0xD6318E2BB11FE8BELL;
        for (l_34 = 0; (l_34 == (-30)); --l_34)
        { /* block id: 12 */
            p_30 |= ((safe_div_func_uint32_t_u_u(g_15, 0x46552DEDL)) > g_8);
            p_30 = ((func_39(g_8) >= 0x45BD2804L) > 0xB4D62422L);
            return p_30;
        }
        p_30 &= (safe_mod_func_uint32_t_u_u(l_88, g_79));
    }
    else
    { /* block id: 39 */
        int8_t l_89 = 0xFEL;
        int8_t l_97 = 0x7CL;
        const uint64_t l_98 = 1UL;
        l_89 ^= g_85[0][2][0];
        l_90 |= (g_80 != g_57);
        if (((safe_mod_func_uint32_t_u_u((safe_div_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u(((((p_32 < l_97) > p_33) , (-2L)) , g_79), g_15)) >= 0x9B51ECC885CB6E38LL), g_85[0][0][0])), l_89)) <= g_85[0][5][0]))
        { /* block id: 42 */
            int64_t l_109 = 0x0EDEAE2A06A03D0BLL;
            p_30 = (l_98 , l_34);
            g_101++;
            g_106 &= (safe_lshift_func_uint16_t_u_u((254UL <= p_33), 9));
            p_30 = (safe_mul_func_uint16_t_u_u(((g_106 <= g_85[0][4][0]) , l_109), g_85[0][2][0]));
        }
        else
        { /* block id: 47 */
            int8_t l_116 = 0x1CL;
            g_117 = (safe_mod_func_uint8_t_u_u((safe_add_func_uint32_t_u_u((((safe_lshift_func_uint8_t_u_u((((l_34 >= 7UL) || p_31) , 253UL), l_116)) ^ p_30) >= g_8), 0x8BCDAFCEL)), p_31));
        }
        return g_57;
    }
    g_120 = ((safe_add_func_uint64_t_u_u(p_32, 0x205A567ADB25B5FELL)) != 255UL);
    for (p_32 = 11; (p_32 > 20); p_32 = safe_add_func_uint64_t_u_u(p_32, 6))
    { /* block id: 55 */
        return g_85[0][2][0];
    }
    for (g_80 = 0; (g_80 == (-26)); g_80--)
    { /* block id: 60 */
        int8_t l_127 = 0xB9L;
        g_128 &= (((safe_lshift_func_uint8_t_u_u((0xDAL < l_127), l_100)) != 0x02L) >= g_106);
        g_131 &= (safe_mod_func_uint32_t_u_u(((p_33 <= p_32) , g_120), 0xD60F7E9AL));
        if ((((+((p_31 != p_33) ^ p_30)) , g_101) == 0x5289450AL))
        { /* block id: 63 */
            p_30 = (safe_div_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u(0x75L, g_117)) <= l_139), 10)), 0x624DL));
            g_140 &= l_127;
        }
        else
        { /* block id: 66 */
            int64_t l_141 = 0L;
            int32_t l_142 = 0xD8BF8503L;
            g_144[0][0][5]++;
        }
        g_154 = ((safe_mod_func_uint64_t_u_u((!(safe_mul_func_uint8_t_u_u(((safe_add_func_uint16_t_u_u(g_51, l_90)) >= p_30), p_32))), 18446744073709551615UL)) < l_127);
    }
    return l_155;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_23 g_15 g_51 g_43 g_79 g_66 g_80 g_85
 * writes: g_43 g_51 g_8 g_57 g_60 g_66 g_79 g_80 g_85
 */
static uint32_t  func_39(const uint64_t  p_40)
{ /* block id: 14 */
    uint32_t l_42 = 0UL;
    if ((+l_42))
    { /* block id: 15 */
        int32_t l_50 = 0xB643C8F4L;
        g_43 = l_42;
        g_66 = (func_44(g_8, l_42, l_50, g_23, g_15) || g_23);
    }
    else
    { /* block id: 29 */
        g_79 ^= (((safe_rshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((safe_div_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u(4294967286UL, l_42)), p_40)), p_40)), p_40)), 9)), p_40)) <= p_40) , (-1L));
        g_80 = g_66;
    }
    g_85[0][2][0] ^= ((safe_mod_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u(0xB24D3E44E821FD1BLL, l_42)) >= g_79), g_80)) >= g_80);
    return l_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_51 g_8 g_43 g_23
 * writes: g_51 g_8 g_57 g_60
 */
static uint64_t  func_44(int8_t  p_45, uint32_t  p_46, int32_t  p_47, int32_t  p_48, int32_t  p_49)
{ /* block id: 17 */
    int16_t l_65[4] = {6L,6L,6L,6L};
    int i;
    g_51 &= p_46;
    for (g_8 = 0; (g_8 == 7); g_8++)
    { /* block id: 21 */
        uint16_t l_56 = 1UL;
        g_57 = (safe_lshift_func_uint8_t_u_u((p_48 < g_43), l_56));
        p_49 ^= (safe_rshift_func_uint8_t_u_u((p_47 , l_56), 2));
        g_60[1][0][4] = 5L;
        l_65[3] = ((safe_lshift_func_uint16_t_u_u((((safe_sub_func_uint64_t_u_u(0xB358509EF6E88F3CLL, 18446744073709551608UL)) == 0x1C9EEB3BL) > p_47), 15)) == g_23);
    }
    return l_65[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_60[i][j][k], "g_60[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_85[i][j][k], "g_85[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_99, "g_99", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_144[i][j][k], "g_144[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 8
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 5
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 99
XXX times a non-volatile is write: 34
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 38
XXX percentage of non-volatile access: 95.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 49
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 19
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 32.6
XXX percentage an existing variable is used: 67.4
********************* end of statistics **********************/

