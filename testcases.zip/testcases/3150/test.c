/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7524841462453875447
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   int32_t  f1;
   const uint64_t  f2;
   volatile int16_t  f3;
   volatile int32_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_11[7] = {0xCBL,0xCBL,0xCBL,0xCBL,0xCBL,0xCBL,0xCBL};
static int32_t g_12[5] = {(-2L),(-2L),(-2L),(-2L),(-2L)};
static volatile int32_t g_46 = 0x99C24175L;/* VOLATILE GLOBAL g_46 */
static uint8_t g_81 = 0xE2L;
static uint16_t g_101 = 0xEA8FL;
static struct S0 g_103 = {0xD576224DL,2L,18446744073709551606UL,0x8A5EL,0xB2B9DCA8L};/* VOLATILE GLOBAL g_103 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_2(int64_t  p_3, uint8_t  p_4);
static uint8_t  func_23(uint8_t  p_24, int32_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_12 g_46 g_81 g_101 g_103
 * writes: g_12 g_81 g_46 g_101 g_103.f4 g_103.f1
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    const uint32_t l_13 = 4294967289UL;
    const int64_t l_14 = 1L;
    int32_t l_86[2];
    int32_t l_87 = 1L;
    int64_t l_112 = 0L;
    int i;
    for (i = 0; i < 2; i++)
        l_86[i] = (-4L);
    if (func_2((safe_mod_func_int32_t_s_s((((((safe_div_func_uint16_t_u_u(((safe_rshift_func_uint8_t_u_s(g_11[1], g_12[3])) | l_13), 0x9393L)) | g_12[0]) , l_13) , l_14) ^ l_13), 0xED45B0E8L)), g_12[1]))
    { /* block id: 27 */
        int32_t l_80 = 0x4639A721L;
        g_81 ^= (safe_div_func_int16_t_s_s(((((((((safe_lshift_func_uint16_t_u_s((l_13 >= g_12[3]), 13)) < l_14) , 0x1D39A42CL) ^ 0xAB084DB6L) <= l_80) | g_11[4]) , l_14) & g_12[3]), 0xAFA1L));
        g_46 = (safe_mod_func_int16_t_s_s(((((safe_mul_func_int16_t_s_s((g_12[1] != 4294967295UL), l_86[0])) >= l_80) >= l_87) == 0xD3L), l_14));
        return g_12[3];
    }
    else
    { /* block id: 31 */
        int8_t l_113 = (-7L);
lbl_94:
        g_12[3] = (safe_mod_func_int64_t_s_s((safe_sub_func_uint64_t_u_u(18446744073709551615UL, g_12[3])), 6L));
        for (g_81 = 0; (g_81 != 15); g_81 = safe_add_func_int16_t_s_s(g_81, 5))
        { /* block id: 35 */
            uint32_t l_102 = 0x45A0FBD7L;
            if (l_14)
                goto lbl_94;
            l_102 &= ((safe_mod_func_int8_t_s_s((((safe_add_func_int8_t_s_s(((safe_add_func_int8_t_s_s((-1L), g_101)) | g_101), l_14)) > 1UL) <= g_46), (-1L))) != 0x0955L);
            if (l_102)
                continue;
            if (g_11[1])
                break;
        }
        for (g_101 = 0; (g_101 <= 6); g_101 += 1)
        { /* block id: 43 */
            int i;
            if (g_11[g_101])
                break;
            g_12[1] = (((g_103 , g_81) & g_81) , g_103.f1);
            g_103.f4 = ((safe_sub_func_uint8_t_u_u(g_81, 0L)) >= g_46);
        }
        for (g_103.f1 = 4; (g_103.f1 >= 0); g_103.f1 -= 1)
        { /* block id: 50 */
            int i;
            g_12[g_103.f1] &= (safe_add_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_rshift_func_int8_t_s_u((((0x74284727L || l_112) | (-1L)) >= l_113), g_11[1])), g_101)), 8UL));
            return g_12[3];
        }
    }
    return l_112;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_12 g_46
 * writes: g_12
 */
static int32_t  func_2(int64_t  p_3, uint8_t  p_4)
{ /* block id: 1 */
    int64_t l_15 = 0L;
    uint8_t l_20 = 247UL;
    int32_t l_75 = 0x69A4A7B5L;
    l_15 &= 1L;
    l_20 = ((safe_add_func_int64_t_s_s((((safe_add_func_int32_t_s_s(((-1L) && 0L), 0x33FD52A4L)) || 0x4AA41A80L) <= p_4), l_15)) <= p_4);
    l_75 = (safe_rshift_func_uint8_t_u_s(func_23(((safe_mul_func_uint16_t_u_u(((((safe_mul_func_int16_t_s_s((((safe_div_func_int16_t_s_s(((g_11[2] > g_12[3]) , l_20), p_4)) & 0x69L) != g_12[2]), 0L)) >= g_12[3]) & p_4) && 0xB0A9L), p_4)) || g_12[3]), l_20), 7));
    return g_11[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_46 g_12
 * writes: g_12
 */
static uint8_t  func_23(uint8_t  p_24, int32_t  p_25)
{ /* block id: 4 */
    uint8_t l_38 = 0x49L;
    uint16_t l_41[10] = {0UL,1UL,1UL,0UL,0x5E09L,0UL,1UL,1UL,0UL,0x5E09L};
    int32_t l_57 = 1L;
    int32_t l_63 = (-1L);
    int32_t l_67[1];
    int i;
    for (i = 0; i < 1; i++)
        l_67[i] = 0x83B01F68L;
    for (p_24 = 1; (p_24 <= 6); p_24 += 1)
    { /* block id: 7 */
        int32_t l_56 = 5L;
        int32_t l_58 = (-1L);
        int32_t l_60 = 0x47D9BA74L;
        int32_t l_61 = 0x5E33AB57L;
        int32_t l_64 = (-1L);
        int32_t l_65 = 0L;
        int32_t l_66[5] = {0xB34BCD01L,0xB34BCD01L,0xB34BCD01L,0xB34BCD01L,0xB34BCD01L};
        int8_t l_70 = 1L;
        int i;
        if (g_11[p_24])
        { /* block id: 8 */
            int i;
            p_25 = ((safe_mod_func_int8_t_s_s((safe_mul_func_int8_t_s_s((safe_add_func_int16_t_s_s((1L > g_11[p_24]), 0xBB38L)), l_38)), 0x90L)) , g_11[p_24]);
            g_12[3] = ((safe_add_func_uint16_t_u_u((((((-1L) >= 65531UL) & 0x80L) , l_41[6]) != 4UL), 0x57B0L)) || g_11[4]);
        }
        else
        { /* block id: 11 */
            g_12[3] = (safe_sub_func_uint64_t_u_u((((((safe_mul_func_uint16_t_u_u((((l_41[6] < 0x4BB8686BL) | 0x4BBCL) > g_11[p_24]), p_25)) , g_46) || 0x30C1ABDDA6A1E05BLL) <= l_41[6]) ^ l_41[6]), p_24));
            p_25 = (p_24 < p_24);
        }
        p_25 = (((safe_rshift_func_int16_t_s_s((((safe_add_func_int16_t_s_s(p_25, l_38)) != l_41[6]) < g_11[p_24]), 11)) & p_24) , g_46);
        if ((safe_rshift_func_uint16_t_u_s((((safe_div_func_uint16_t_u_u(0UL, 1UL)) || g_12[3]) < p_25), p_24)))
        { /* block id: 16 */
            int8_t l_55 = 0x32L;
            int32_t l_59 = (-9L);
            int32_t l_62[9];
            int16_t l_68 = 1L;
            int64_t l_69[3];
            int8_t l_71 = 4L;
            uint64_t l_72 = 18446744073709551615UL;
            int i;
            for (i = 0; i < 9; i++)
                l_62[i] = 0xEA6296EFL;
            for (i = 0; i < 3; i++)
                l_69[i] = 0x203F87D51EEA2DBBLL;
            g_12[3] &= (((65533UL >= l_41[6]) == l_55) >= p_24);
            ++l_72;
            return g_12[3];
        }
        else
        { /* block id: 20 */
            return l_66[2];
        }
    }
    return g_11[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_11[i], "g_11[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_103.f0, "g_103.f0", print_hash_value);
    transparent_crc(g_103.f1, "g_103.f1", print_hash_value);
    transparent_crc(g_103.f2, "g_103.f2", print_hash_value);
    transparent_crc(g_103.f3, "g_103.f3", print_hash_value);
    transparent_crc(g_103.f4, "g_103.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 36
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 31
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 5
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 71
XXX times a non-volatile is write: 19
XXX times a volatile is read: 18
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 65
XXX percentage of non-volatile access: 81.8

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 35
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 10
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 23.9
XXX percentage an existing variable is used: 76.1
********************* end of statistics **********************/

