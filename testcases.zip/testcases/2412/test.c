/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13421904771935834613
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const int8_t g_13 = 0L;
static volatile int16_t g_14 = 1L;/* VOLATILE GLOBAL g_14 */
static uint32_t g_26 = 0x08700D35L;
static int64_t g_32 = 0xCC19583E3585CA25LL;
static int32_t g_34[3] = {0x4067BC62L,0x4067BC62L,0x4067BC62L};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_2(const int8_t  p_3, int16_t  p_4, uint16_t  p_5, int16_t  p_6);
static uint8_t  func_9(uint8_t  p_10, const int16_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_14 g_26 g_34
 * writes: g_26 g_32 g_34
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_12[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int32_t l_24 = 0x20F746E3L;
    uint8_t l_29[8];
    int32_t l_46 = 0xC17F7268L;
    int i;
    for (i = 0; i < 8; i++)
        l_29[i] = 0x98L;
    g_26 = ((func_2((safe_lshift_func_uint8_t_u_s(func_9(((l_12[2] & l_12[2]) || l_12[2]), g_13), 7)), l_12[2], l_12[0], l_24) < g_13) < (-9L));
    if ((safe_mul_func_uint16_t_u_u(l_29[3], g_13)))
    { /* block id: 10 */
        int16_t l_33[4];
        int64_t l_35 = 0x14B71808ADC705BELL;
        int32_t l_36[4];
        uint32_t l_37 = 18446744073709551608UL;
        int i;
        for (i = 0; i < 4; i++)
            l_33[i] = (-2L);
        for (i = 0; i < 4; i++)
            l_36[i] = 0x49F0DC4BL;
        g_32 = (safe_sub_func_int8_t_s_s((g_14 ^ l_12[3]), g_26));
        g_34[1] = (l_33[0] == g_26);
        l_37++;
        g_34[1] = ((safe_rshift_func_int8_t_s_u(((g_14 < l_12[2]) & l_33[0]), 2)) , l_33[0]);
    }
    else
    { /* block id: 15 */
        int16_t l_42 = 0L;
        int32_t l_43 = 7L;
        l_43 &= (l_42 != 0x2E46A6F4L);
        l_43 = ((safe_rshift_func_uint16_t_u_u(l_12[2], g_34[2])) > g_34[0]);
    }
    return l_46;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_14
 * writes:
 */
static int64_t  func_2(const int8_t  p_3, int16_t  p_4, uint16_t  p_5, int16_t  p_6)
{ /* block id: 6 */
    int64_t l_25 = 0x7A140552487223B1LL;
    l_25 = (g_13 >= g_14);
    return l_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes:
 */
static uint8_t  func_9(uint8_t  p_10, const int16_t  p_11)
{ /* block id: 1 */
    uint16_t l_15 = 4UL;
    int32_t l_22 = 0x979CD329L;
lbl_23:
    --l_15;
    l_22 = (safe_lshift_func_int8_t_s_u(((safe_div_func_uint8_t_u_u(0UL, g_14)) , g_14), 3));
    if (l_15)
        goto lbl_23;
    return l_15;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 10
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 87.5

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 6

XXX percentage a fresh-made variable is used: 36
XXX percentage an existing variable is used: 64
********************* end of statistics **********************/

