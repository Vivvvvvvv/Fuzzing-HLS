/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4697275414867130735
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_11 = 5UL;
static uint64_t g_18 = 0x70012AF0488F4F36LL;
static uint64_t g_45[2] = {0xB5A7DD9AE65C3421LL,0xB5A7DD9AE65C3421LL};
static uint64_t g_51[3][1][8] = {{{0UL,8UL,8UL,0UL,18446744073709551614UL,0UL,8UL,8UL}},{{8UL,18446744073709551614UL,1UL,1UL,18446744073709551614UL,8UL,18446744073709551614UL,1UL}},{{0UL,18446744073709551614UL,0UL,8UL,8UL,0UL,18446744073709551614UL,0UL}}};
static int32_t g_69[2][2] = {{0L,0L},{0L,0L}};
static int16_t g_70 = 0x92ADL;
static uint32_t g_72[6][9][4] = {{{0x44077424L,0x9428F8A5L,0UL,0UL},{0x8E0D3184L,0x8E0D3184L,0x44077424L,0UL},{0x789B64D4L,0x9428F8A5L,0x789B64D4L,0x44077424L},{0x789B64D4L,0x44077424L,0x44077424L,0x789B64D4L},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL}},{{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L}},{{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L}},{{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L}},{{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L}},{{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x9428F8A5L},{0UL,0x8E0D3184L,0UL,0x789B64D4L},{0UL,0x789B64D4L,0x789B64D4L,0UL},{0x44077424L,0x789B64D4L,0x9428F8A5L,0x789B64D4L},{0x789B64D4L,0x8E0D3184L,0x9428F8A5L,0x9428F8A5L},{0x44077424L,0x44077424L,0x789B64D4L,0x8E0D3184L},{0x9428F8A5L,0x44077424L,0x9428F8A5L,0UL},{0x9428F8A5L,0UL,0UL,0x9428F8A5L}}};
static int64_t g_92 = 0x66A56D104A74307FLL;
static int8_t g_100 = 0xA6L;


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);
static uint8_t  func_4(int32_t  p_5, uint32_t  p_6, int32_t  p_7, uint8_t  p_8);
static uint32_t  func_21(const int16_t  p_22, uint8_t  p_23, int32_t  p_24, int8_t  p_25, int64_t  p_26);
static uint32_t  func_29(uint32_t  p_30, int64_t  p_31, uint32_t  p_32, int32_t  p_33, const uint64_t  p_34);
static uint8_t  func_39(uint64_t  p_40);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_45 g_18 g_51 g_69 g_70 g_92 g_72
 * writes: g_18 g_45 g_51 g_69 g_70 g_72 g_92 g_100
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_12 = (-6L);
    int32_t l_93 = 0xB9FEC4F7L;
    l_93 = ((safe_div_func_uint8_t_u_u(func_4((safe_mul_func_uint16_t_u_u(g_11, g_11)), l_12, l_12, g_11), l_12)) && l_12);
    l_93 = (safe_sub_func_uint16_t_u_u(g_51[2][0][0], g_72[3][4][3]));
    for (l_12 = 0; (l_12 >= (-5)); l_12 = safe_sub_func_uint8_t_u_u(l_12, 7))
    { /* block id: 38 */
        int32_t l_103 = 0L;
        g_100 = (safe_rshift_func_uint8_t_u_u(g_11, 3));
        l_103 &= (safe_add_func_uint8_t_u_u(0xD1L, g_11));
        return l_12;
    }
    return l_93;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_45 g_18 g_51 g_69 g_70 g_92
 * writes: g_18 g_45 g_51 g_69 g_70 g_72 g_92
 */
static uint8_t  func_4(int32_t  p_5, uint32_t  p_6, int32_t  p_7, uint8_t  p_8)
{ /* block id: 1 */
    int16_t l_17 = 6L;
    int32_t l_75 = 0x68620657L;
    g_18 = (safe_add_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_u(255UL, g_11)) != l_17) == l_17), g_11));
    for (p_8 = 7; (p_8 == 44); p_8 = safe_add_func_uint64_t_u_u(p_8, 6))
    { /* block id: 5 */
        int16_t l_73 = 4L;
        uint16_t l_85 = 0xA5EAL;
        uint16_t l_86 = 0x9839L;
        int32_t l_87 = 9L;
        l_75 = (func_21((safe_sub_func_uint32_t_u_u(func_29((safe_rshift_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((func_39(p_6) >= l_17), g_11)), 2)), g_11, g_18, p_6, p_8), g_11)), p_7, g_11, l_73, p_7) < l_73);
        l_87 &= (((safe_add_func_uint64_t_u_u((!(safe_lshift_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((((((((safe_rshift_func_uint8_t_u_u((g_69[0][1] || l_85), 1)) <= g_45[1]) && l_86) != l_86) < g_45[0]) < g_51[2][0][0]) , 18446744073709551615UL), 18446744073709551615UL)), l_17))), 0x83B7C1F666C839C7LL)) , g_69[0][1]) , l_73);
        g_92 &= (safe_mod_func_uint32_t_u_u(((safe_sub_func_uint16_t_u_u(0x4365L, p_7)) >= g_70), 0x97B3892EL));
    }
    return l_17;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_21(const int16_t  p_22, uint8_t  p_23, int32_t  p_24, int8_t  p_25, int64_t  p_26)
{ /* block id: 26 */
    int32_t l_74 = 3L;
    l_74 = 0L;
    return l_74;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_45 g_51 g_69
 * writes: g_18 g_51 g_69 g_70 g_72
 */
static uint32_t  func_29(uint32_t  p_30, int64_t  p_31, uint32_t  p_32, int32_t  p_33, const uint64_t  p_34)
{ /* block id: 10 */
    const int8_t l_60 = 0xF9L;
    int32_t l_71 = (-1L);
    for (g_18 = (-7); (g_18 != 9); g_18 = safe_add_func_uint32_t_u_u(g_18, 8))
    { /* block id: 13 */
        int64_t l_59 = 0x7721CA7BC41BBBBFLL;
        int32_t l_63[1];
        int i;
        for (i = 0; i < 1; i++)
            l_63[i] = 0x2614F5C6L;
        g_51[2][0][0] = (!g_45[1]);
        if ((+((safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((safe_add_func_uint8_t_u_u((l_59 <= 0xA2L), g_51[2][0][5])), p_34)), l_60)) , 0xF2FE868EL)))
        { /* block id: 15 */
            l_63[0] = ((safe_lshift_func_uint8_t_u_u(g_51[2][0][0], 3)) ^ p_32);
        }
        else
        { /* block id: 17 */
            int16_t l_64[9] = {0x3251L,0x3251L,0x3251L,0x3251L,0x3251L,0x3251L,0x3251L,0x3251L,0x3251L};
            int i;
            l_64[6] ^= p_33;
            g_69[0][1] |= ((safe_sub_func_uint16_t_u_u((((safe_rshift_func_uint8_t_u_u(g_18, l_60)) == p_34) < 0x73C098B3L), 0x7C2BL)) == p_33);
            g_70 = (0x5FECL == l_63[0]);
        }
    }
    l_71 ^= p_30;
    g_72[3][4][3] = g_45[0];
    return l_60;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_45
 * writes: g_45
 */
static uint8_t  func_39(uint64_t  p_40)
{ /* block id: 6 */
    uint32_t l_44 = 0xC7E318B4L;
    l_44 = ((!(safe_add_func_uint16_t_u_u(g_11, p_40))) , (-8L));
    g_45[1]--;
    return g_45[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_45[i], "g_45[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_51[i][j][k], "g_51[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_69[i][j], "g_69[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_70, "g_70", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_72[i][j][k], "g_72[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 25
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 17
breakdown:
   depth: 1, occurrence: 30
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 14, occurrence: 1
   depth: 17, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 66
XXX times a non-volatile is write: 21
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 8
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 30.9
XXX percentage an existing variable is used: 69.1
********************* end of statistics **********************/

