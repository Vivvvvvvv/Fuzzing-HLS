/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11390658918912420916
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_11 = 9UL;
static int64_t g_36 = 0xDD253D975123020FLL;
static int64_t g_43 = 0x1D497C242EA6AE20LL;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint8_t  func_4(int8_t  p_5);
static uint16_t  func_16(uint8_t  p_17, uint64_t  p_18);
static uint8_t  func_19(const uint16_t  p_20, int32_t  p_21, int32_t  p_22);
static uint16_t  func_23(const int32_t  p_24, const int64_t  p_25, int32_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_36
 * writes: g_36 g_43
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_12 = 0UL;
    int32_t l_42 = 0x1F32AFCBL;
    l_42 |= (safe_sub_func_uint8_t_u_u(func_4(((safe_sub_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u((((+g_11) || g_11) < g_11), l_12)) != g_11), l_12)) ^ g_11)), g_11));
    g_43 = (1UL && 0UL);
    return g_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_36
 * writes: g_36
 */
static uint8_t  func_4(int8_t  p_5)
{ /* block id: 1 */
    int32_t l_13 = (-1L);
    l_13 = (((p_5 , 18446744073709551615UL) , g_11) ^ g_11);
    l_13 = (((safe_div_func_uint16_t_u_u(func_16(func_19(func_23(g_11, g_11, l_13), l_13, p_5), l_13), g_11)) || 0xBFEEL) < 0UL);
    return l_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_36
 * writes: g_36
 */
static uint16_t  func_16(uint8_t  p_17, uint64_t  p_18)
{ /* block id: 10 */
    uint32_t l_28 = 1UL;
    int32_t l_41 = 7L;
    l_28 = 0x6193FE69L;
    for (p_18 = 20; (p_18 >= 9); p_18 = safe_sub_func_uint16_t_u_u(p_18, 5))
    { /* block id: 14 */
        int32_t l_33 = 0xFA72D50FL;
        int32_t l_34 = 0x7494DFD9L;
        l_34 |= ((safe_add_func_uint32_t_u_u(l_28, 4294967295UL)) , l_33);
        if ((g_11 , (-1L)))
        { /* block id: 16 */
            uint8_t l_35 = 255UL;
            l_34 &= (-10L);
            if (l_35)
                break;
        }
        else
        { /* block id: 19 */
            g_36 = l_28;
            return p_17;
        }
    }
    l_41 = (safe_sub_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((l_28 >= g_36), 7)), p_17));
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes:
 */
static uint8_t  func_19(const uint16_t  p_20, int32_t  p_21, int32_t  p_22)
{ /* block id: 6 */
    int8_t l_27 = 4L;
    p_21 = g_11;
    l_27 = (0x04L != 0UL);
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_23(const int32_t  p_24, const int64_t  p_25, int32_t  p_26)
{ /* block id: 3 */
    p_26 = (p_24 < p_25);
    return p_25;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 23
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 25.5
XXX percentage an existing variable is used: 74.5
********************* end of statistics **********************/

