/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10071503149487573021
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_7 = (-1L);
static int32_t g_26[2] = {0x7AB6CE1AL,0x7AB6CE1AL};
static const volatile int32_t g_39 = 3L;/* VOLATILE GLOBAL g_39 */
static uint16_t g_120 = 65535UL;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_2(int16_t  p_3, int64_t  p_4, uint16_t  p_5);
static int32_t  func_8(uint8_t  p_9, int32_t  p_10, int16_t  p_11, int8_t  p_12);
static const uint16_t  func_15(uint64_t  p_16, int8_t  p_17, int32_t  p_18);
static uint64_t  func_19(uint32_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_26 g_39 g_120
 * writes: g_26 g_7 g_120
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_6 = 0x286E871DL;
    int32_t l_108[7][9][4] = {{{4L,(-4L),0xA2FD1301L,0x12E90868L},{0xD7298C4FL,0xBB21A5A1L,0L,0L},{1L,1L,0L,0L},{0xA3F67225L,0xA3F67225L,(-4L),(-6L)},{0xA5162D90L,0L,(-8L),0xA3DBB834L},{0x78B5E36AL,1L,0x87175307L,(-8L)},{0xBB3B6D22L,1L,0xD55268D4L,0xA3DBB834L},{1L,0L,(-1L),(-6L)},{(-1L),0xA3F67225L,0x9D7C2881L,0L}},{{0L,1L,(-1L),0L},{0xAAE426BEL,0xBB21A5A1L,1L,0x12E90868L},{0x261DBC53L,0x88910D5BL,(-9L),(-8L)},{0xA5162D90L,0xA3F67225L,1L,(-10L)},{0x4C9C871BL,0xBB21A5A1L,0xA5162D90L,(-1L)},{(-6L),0x2E68823EL,(-4L),(-7L)},{0L,0xEC2F7F93L,0xFAE34B66L,0L},{0xBB21A5A1L,(-8L),8L,0xAAE426BEL},{0x88910D5BL,(-8L),(-4L),(-10L)}},{{0x6A9ED742L,0x87175307L,0L,(-9L)},{0L,(-1L),0L,0L},{0x2F8029A7L,4L,0xAAE426BEL,0xD55268D4L},{0xA2FD1301L,(-1L),0x2090DF5CL,0L},{0xFAE34B66L,0xBB3B6D22L,(-4L),0xE2B1DE1DL},{0x344571AEL,0x9D7C2881L,0xF10FDB64L,0xD849AB60L},{(-1L),0xD7298C4FL,0x24C1B6DCL,0xF10FDB64L},{0L,1L,0x78B5E36AL,(-1L)},{1L,0x12E90868L,(-10L),0x12E90868L}},{{(-7L),0xBB3B6D22L,1L,0x2090DF5CL},{(-4L),0L,4L,1L},{(-1L),1L,(-6L),0L},{(-1L),0x88910D5BL,4L,0xA080896FL},{(-4L),0L,1L,0xA5162D90L},{(-7L),(-8L),(-10L),(-1L)},{1L,0xE464C473L,0x78B5E36AL,0xC7B1BD9BL},{0L,0x32A4309CL,0x24C1B6DCL,(-7L)},{(-1L),(-8L),0xF10FDB64L,0L}},{{0x344571AEL,(-1L),(-4L),0xA5162D90L},{0xFAE34B66L,0xA3F67225L,0x2090DF5CL,(-9L)},{0xA2FD1301L,0x344571AEL,0xAAE426BEL,1L},{0x2F8029A7L,1L,0L,0xEC2F7F93L},{0L,(-1L),0L,(-1L)},{0x6A9ED742L,0xFAE34B66L,(-4L),0x12E90868L},{0x88910D5BL,1L,8L,0xD849AB60L},{0xBB21A5A1L,1L,0xFAE34B66L,8L},{0L,0xD7298C4FL,(-4L),(-1L)}},{{(-6L),0x12E90868L,0xA5162D90L,0x2F8029A7L},{0x4C9C871BL,0xFAE34B66L,1L,0L},{0xA5162D90L,5L,(-9L),1L},{0x261DBC53L,1L,1L,1L},{(-1L),(-1L),2L,(-8L)},{(-1L),0L,0L,(-1L)},{0x4C9C871BL,(-1L),(-10L),0xAAE426BEL},{1L,0x2E68823EL,0xF4719CE8L,0xC7B1BD9BL},{1L,0x28269CF3L,0xFAE34B66L,0xC7B1BD9BL}},{{(-1L),0x2E68823EL,(-4L),0xAAE426BEL},{0x0EE195F7L,(-1L),0x88910D5BL,(-1L)},{0x6A9ED742L,0L,0x2090DF5CL,(-8L)},{(-7L),(-1L),(-1L),1L},{0x9D7C2881L,1L,0xAAE426BEL,1L},{(-1L),0x28269CF3L,(-10L),(-1L)},{0xBE207B94L,0L,0xEAA03808L,1L},{(-7L),0L,0xD7298C4FL,2L},{2L,0x9D7C2881L,0xBB32BA0DL,0xD7298C4FL}}};
    int8_t l_119[6][8] = {{0x11L,7L,9L,0x28L,1L,(-7L),(-7L),1L},{0L,0x11L,0x11L,0L,0L,6L,0L,0x69L},{0x28L,9L,7L,0x11L,6L,1L,6L,0x84L},{0x84L,9L,0xE3L,(-7L),7L,6L,7L,(-7L)},{0xFFL,0x11L,0xFFL,0L,3L,(-7L),0L,7L},{0L,7L,0x28L,0x09L,0x11L,0xFBL,3L,9L}};
    int i, j, k;
    l_108[0][4][2] = func_2((l_6 , (-4L)), l_6, g_7);
    for (l_6 = (-19); (l_6 < 3); l_6++)
    { /* block id: 64 */
        uint16_t l_111 = 0x7B99L;
        int32_t l_114 = (-2L);
        int32_t l_115 = 0x089050E9L;
        int32_t l_116 = 3L;
        int32_t l_117 = 6L;
        int32_t l_118[10] = {0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL,0x443474DDL};
        int i;
        --l_111;
        g_120++;
    }
    return g_26[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_26 g_39
 * writes: g_26 g_7
 */
static int32_t  func_2(int16_t  p_3, int64_t  p_4, uint16_t  p_5)
{ /* block id: 1 */
    uint32_t l_13[2][3][6] = {{{1UL,18446744073709551613UL,0x0D2F38D9L,0x0D2F38D9L,18446744073709551613UL,1UL},{1UL,0x1860EC01L,1UL,0x0D2F38D9L,0x1860EC01L,0x0D2F38D9L},{1UL,6UL,1UL,0x0D2F38D9L,6UL,1UL}},{{1UL,18446744073709551613UL,0x0D2F38D9L,0x0D2F38D9L,18446744073709551613UL,1UL},{1UL,0x1860EC01L,1UL,0x0D2F38D9L,0x1860EC01L,0x0D2F38D9L},{1UL,6UL,1UL,0x0D2F38D9L,6UL,1UL}}};
    int64_t l_101[4] = {5L,5L,5L,5L};
    int32_t l_104[3];
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_104[i] = 0L;
    l_101[1] = func_8((247UL >= 0x51L), p_5, l_13[1][2][2], p_5);
    for (p_3 = 0; (p_3 <= (-3)); p_3 = safe_sub_func_uint8_t_u_u(p_3, 1))
    { /* block id: 55 */
        l_104[2] = g_26[1];
        return p_3;
    }
    l_104[1] = (!(safe_rshift_func_uint8_t_u_u(((((p_5 < l_13[1][2][2]) <= 0xC438L) > l_101[3]) && l_101[0]), g_7)));
    return g_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_26 g_39
 * writes: g_26 g_7
 */
static int32_t  func_8(uint8_t  p_9, int32_t  p_10, int16_t  p_11, int8_t  p_12)
{ /* block id: 2 */
    const uint32_t l_14 = 4294967295UL;
    int32_t l_49 = 1L;
    const uint32_t l_61 = 0xAFE108D8L;
    int32_t l_92 = 0L;
    int32_t l_93 = 2L;
    int32_t l_94 = 3L;
    int32_t l_95[10] = {6L,6L,6L,6L,6L,6L,6L,6L,6L,6L};
    uint16_t l_96 = 6UL;
    int i;
    if (l_14)
    { /* block id: 3 */
        int16_t l_21 = 0xEE0CL;
        int32_t l_44[7][7] = {{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{0x49EDE151L,0x0D90C37CL,0x49EDE151L,0x0D90C37CL,0x49EDE151L,0x0D90C37CL,0x49EDE151L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{0x49EDE151L,0x0D90C37CL,0x49EDE151L,0x0D90C37CL,0x49EDE151L,0x0D90C37CL,0x49EDE151L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{0x49EDE151L,0x0D90C37CL,0x49EDE151L,0x0D90C37CL,0x49EDE151L,0x0D90C37CL,0x49EDE151L},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)}};
        int i, j;
        g_26[0] = (func_15((((((func_19(l_21) > 0x7279C90E69CD17CDLL) , l_21) ^ 0x55F1BB13L) ^ l_14) >= 0x7AA29676L), g_7, l_14) != l_14);
        if ((+(((g_39 && g_7) == l_14) == 3UL)))
        { /* block id: 14 */
            l_44[1][5] = ((g_26[1] > l_21) > l_21);
            l_49 |= (safe_add_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u(p_12, g_39)), p_10));
        }
        else
        { /* block id: 17 */
            int8_t l_56 = 0x2EL;
            int32_t l_57 = 0xDDAF140BL;
            l_57 = (safe_add_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((l_14 >= g_7), g_26[1])) < l_49), 0x4D35L)) ^ l_56), 252UL));
        }
        for (p_9 = 0; (p_9 == 8); p_9 = safe_add_func_uint64_t_u_u(p_9, 3))
        { /* block id: 22 */
            const int32_t l_60 = 7L;
            p_10 = (((g_39 && 255UL) , p_12) , 0xB380B773L);
            if (l_60)
                break;
            p_10 &= (p_12 >= g_39);
            l_49 = (1UL && l_61);
        }
    }
    else
    { /* block id: 28 */
        uint16_t l_75[2][7][7] = {{{0UL,0x5111L,0x6FF1L,0x1B20L,0x7EEBL,0UL,0UL},{0x5E9CL,65535UL,0xB3E3L,0x2F3DL,0x90E5L,0x6FF1L,0x7EEBL},{0x9FD6L,0x6FF1L,9UL,4UL,65531UL,0UL,0x08C6L},{0x2FD9L,65535UL,0x5E6AL,0x90E5L,1UL,0UL,0UL},{7UL,5UL,0xF1AAL,0x90E5L,0x1239L,0xB120L,0UL},{0UL,0UL,0x56ECL,4UL,0x56ECL,0UL,0UL},{0x1239L,0x2B60L,0x90E5L,0UL,0UL,9UL,65535UL}},{{0x5E9CL,0UL,0x7EEBL,7UL,0x2F3DL,0UL,65535UL},{0x5111L,65531UL,0x90E5L,0x755EL,0x08C6L,65535UL,1UL},{4UL,0x4B93L,0x56ECL,7UL,7UL,0x2B60L,65531UL},{65535UL,0UL,0xF1AAL,0x08C6L,0UL,0x6FF1L,0x5E6AL},{0x1B20L,0UL,0x5E6AL,0xB3E3L,1UL,0x56ECL,0x56ECL},{3UL,0x4B93L,9UL,0x4B93L,3UL,0x1B20L,65535UL},{0x4B93L,65531UL,0UL,0x2B60L,0UL,5UL,65535UL}}};
        int32_t l_76 = 0L;
        int32_t l_77 = 7L;
        int32_t l_78 = 0x6E8DA2FBL;
        int32_t l_79[10];
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_79[i] = 3L;
        for (g_7 = (-15); (g_7 != (-3)); g_7 = safe_add_func_uint32_t_u_u(g_7, 4))
        { /* block id: 31 */
            int64_t l_66[8] = {0x449D4C0F60069ABCLL,0xC70A1111CD9E91B6LL,0xC70A1111CD9E91B6LL,0x449D4C0F60069ABCLL,0xC70A1111CD9E91B6LL,0xC70A1111CD9E91B6LL,0x449D4C0F60069ABCLL,0xC70A1111CD9E91B6LL};
            int i;
            l_66[1] &= (safe_mul_func_uint8_t_u_u(0x9DL, g_26[0]));
            g_26[0] = ((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(((l_49 < 1UL) != 0x5732E7CEL), p_12)), g_26[0])), 5)), p_11)) < l_75[0][6][3]);
        }
        if ((p_10 && p_12))
        { /* block id: 35 */
            uint8_t l_80[8] = {0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L,0xD6L};
            int i;
            l_80[5]--;
            g_26[0] = (safe_mod_func_uint16_t_u_u(l_80[3], p_10));
        }
        else
        { /* block id: 38 */
            uint16_t l_89 = 0xE9E6L;
            g_26[0] = ((safe_rshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((65529UL || 65530UL), l_89)), l_61)) , l_14);
            g_26[0] = ((safe_add_func_uint64_t_u_u(3UL, g_7)) != 0x3B973E414CEA6EDCLL);
        }
    }
    l_96++;
    p_10 = p_10;
    for (l_93 = 0; (l_93 < (-28)); --l_93)
    { /* block id: 47 */
        p_10 = (p_12 ^ l_93);
        l_92 = (p_10 != l_92);
    }
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_26 g_7 g_39
 * writes: g_26
 */
static const uint16_t  func_15(uint64_t  p_16, int8_t  p_17, int32_t  p_18)
{ /* block id: 8 */
    uint32_t l_27[3][2] = {{0xC4CE10B4L,0xC4CE10B4L},{0xC4CE10B4L,0xC4CE10B4L},{0xC4CE10B4L,0xC4CE10B4L}};
    uint32_t l_38 = 1UL;
    int32_t l_40 = (-6L);
    int i, j;
    g_26[0] = (l_27[2][1] ^ p_17);
    l_40 = ((((safe_rshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(((safe_add_func_uint8_t_u_u((((safe_sub_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((p_18 >= 18446744073709551607UL), g_26[0])), l_27[2][1])) || g_26[0]) , g_7), l_27[0][0])) >= g_26[1]), g_26[0])), g_7)) , 0xA419L) ^ l_38) || g_39);
    l_40 &= (safe_div_func_uint32_t_u_u(l_27[2][1], g_39));
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_26
 */
static uint64_t  func_19(uint32_t  p_20)
{ /* block id: 4 */
    int32_t l_22 = 0x785734CBL;
    uint32_t l_23 = 0UL;
    l_23--;
    g_26[0] = (((251UL && 0xC8L) <= p_20) >= l_22);
    return p_20;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_26[i], "g_26[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 42
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 14
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 79
XXX times a non-volatile is write: 33
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 16
XXX percentage of non-volatile access: 94.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 43
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 11
   depth: 2, occurrence: 13

XXX percentage a fresh-made variable is used: 22.1
XXX percentage an existing variable is used: 77.9
********************* end of statistics **********************/

