/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12513952237212004329
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2 = 9UL;
static uint8_t g_20 = 247UL;
static int16_t g_43[8] = {0xB783L,0x0E84L,0xB783L,0xB783L,0x0E84L,0xB783L,0xB783L,0x0E84L};
static int32_t g_47[7][9][4] = {{{4L,1L,0L,5L},{5L,0x2B85AE34L,0x3A04BB84L,0x694A98A1L},{0xCB15B75DL,0x3A04BB84L,0x3A04BB84L,0xCB15B75DL},{5L,6L,0L,(-9L)},{4L,0x862B336FL,(-1L),(-1L)},{(-9L),0x73452C79L,1L,(-1L)},{1L,0x862B336FL,0x2B85AE34L,(-9L)},{0x87F7F2BFL,6L,0x73452C79L,0xCB15B75DL},{0x575434BBL,0x3A04BB84L,1L,0x694A98A1L}},{{0x575434BBL,0x2B85AE34L,0x74B4FBF6L,1L},{(-9L),0x3A04BB84L,0x73452C79L,0L},{0xCB15B75DL,0x05405EA3L,(-3L),(-1L)},{0x694A98A1L,0x05405EA3L,1L,0L},{5L,0x3A04BB84L,1L,1L},{1L,0x73452C79L,7L,1L},{0x575434BBL,7L,7L,0x575434BBL},{1L,0x862B336FL,1L,0x694A98A1L},{5L,0L,1L,4L}},{{0x694A98A1L,0x74B4FBF6L,(-3L),4L},{0xCB15B75DL,0L,0x73452C79L,0x694A98A1L},{(-9L),0x862B336FL,0x74B4FBF6L,0x575434BBL},{(-1L),7L,0x3A04BB84L,1L},{(-1L),0x73452C79L,0x74B4FBF6L,1L},{(-9L),0x3A04BB84L,0x73452C79L,0L},{0xCB15B75DL,0x05405EA3L,(-3L),(-1L)},{0x694A98A1L,0x05405EA3L,1L,0L},{5L,0x3A04BB84L,1L,1L}},{{1L,0x73452C79L,7L,1L},{0x575434BBL,7L,7L,0x575434BBL},{1L,0x862B336FL,1L,0x694A98A1L},{5L,0L,1L,4L},{0x694A98A1L,0x74B4FBF6L,(-3L),4L},{0xCB15B75DL,0L,0x73452C79L,0x694A98A1L},{(-9L),0x862B336FL,0x74B4FBF6L,0x575434BBL},{(-1L),7L,0x3A04BB84L,1L},{(-1L),0x73452C79L,0x74B4FBF6L,1L}},{{(-9L),0x3A04BB84L,0x73452C79L,0L},{0xCB15B75DL,0x05405EA3L,(-3L),(-1L)},{0x694A98A1L,0x05405EA3L,1L,0L},{5L,0x3A04BB84L,1L,1L},{1L,0x73452C79L,7L,1L},{0x575434BBL,7L,7L,0x575434BBL},{1L,0x862B336FL,1L,0x694A98A1L},{5L,0L,1L,4L},{0x694A98A1L,0x74B4FBF6L,(-3L),4L}},{{0xCB15B75DL,0L,0x73452C79L,0x694A98A1L},{(-9L),0x862B336FL,0x74B4FBF6L,0x575434BBL},{(-1L),7L,0x3A04BB84L,1L},{(-1L),0x73452C79L,0x74B4FBF6L,1L},{(-9L),0x3A04BB84L,0x73452C79L,0L},{0xCB15B75DL,0x05405EA3L,(-3L),(-1L)},{0x694A98A1L,0x05405EA3L,1L,0L},{5L,0x3A04BB84L,1L,1L},{1L,0x73452C79L,7L,1L}},{{0x575434BBL,7L,7L,0x575434BBL},{1L,0x862B336FL,1L,0x694A98A1L},{5L,0L,1L,4L},{0x694A98A1L,0x05405EA3L,(-1L),5L},{0x575434BBL,1L,0x74B4FBF6L,1L},{0x694A98A1L,0L,0x05405EA3L,(-1L)},{4L,0x2B85AE34L,7L,0xCB15B75DL},{4L,0x74B4FBF6L,0x05405EA3L,0L},{0x694A98A1L,7L,0x74B4FBF6L,0xF634C5D1L}}};
static uint16_t g_73[3] = {0x3F9EL,0x3F9EL,0x3F9EL};


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint64_t  func_10(uint8_t  p_11, int16_t  p_12);
static int32_t  func_13(uint8_t  p_14, uint64_t  p_15, uint8_t  p_16);
static const uint16_t  func_30(int16_t  p_31, int8_t  p_32, uint8_t  p_33, uint32_t  p_34, uint32_t  p_35);
static int32_t  func_75(int8_t  p_76, int32_t  p_77, uint64_t  p_78, uint64_t  p_79);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_20 g_43 g_47 g_73
 * writes: g_2 g_20 g_43 g_47 g_73
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int64_t l_3 = (-1L);
    int32_t l_44 = 0xF41AF53CL;
    int32_t l_46 = 0xADB5D230L;
    int32_t l_49 = 0xCB379706L;
    int16_t l_50 = (-7L);
    int32_t l_55 = 1L;
    int32_t l_56 = 0xB18E49B9L;
    int32_t l_60 = 0L;
    uint64_t l_81 = 0UL;
    uint32_t l_115 = 18446744073709551614UL;
    l_3 = g_2;
    for (l_3 = (-24); (l_3 != (-21)); ++l_3)
    { /* block id: 4 */
        int32_t l_45 = 0L;
        int32_t l_48[10][6][4] = {{{0xAFAA48CCL,(-1L),0L,(-7L)},{3L,0x6FF5FBB4L,3L,0L},{0x868C9304L,(-7L),0x4AAF27CEL,0x353696E0L},{(-9L),0x1F8E388CL,0x06334729L,(-7L)},{0x8980DF3AL,0x79C5DFBCL,0x06334729L,(-1L)},{(-9L),0x29281337L,0x4AAF27CEL,0x1796DE0DL}},{{0x868C9304L,1L,3L,0x79C5DFBCL},{3L,0x79C5DFBCL,0L,0x60774821L},{0xAFAA48CCL,0x6FF5FBB4L,1L,0x353696E0L},{0x868C9304L,0x60774821L,0xCF3742C0L,0x353696E0L},{0L,0x6FF5FBB4L,0x06334729L,0x60774821L},{(-1L),0x79C5DFBCL,0x03F40BDEL,0x79C5DFBCL}},{{(-9L),1L,0xCF3742C0L,0x1796DE0DL},{0x60F42E90L,0x29281337L,3L,(-1L)},{0xAFAA48CCL,0x79C5DFBCL,(-1L),(-7L)},{0xAFAA48CCL,0x1F8E388CL,3L,0x353696E0L},{0x60F42E90L,(-7L),0xCF3742C0L,0L},{(-9L),0x6FF5FBB4L,0x03F40BDEL,(-7L)}},{{(-1L),(-1L),0x06334729L,0x79C5DFBCL},{0L,0x29281337L,0xCF3742C0L,0x5B30FD8BL},{0x868C9304L,0x29281337L,1L,0x79C5DFBCL},{0xAFAA48CCL,(-1L),0L,(-7L)},{3L,0x6FF5FBB4L,3L,0L},{0x868C9304L,(-7L),0x4AAF27CEL,0x353696E0L}},{{(-9L),0x1F8E388CL,0x06334729L,(-7L)},{0x8980DF3AL,0x79C5DFBCL,0x06334729L,(-1L)},{(-9L),0x29281337L,0x4AAF27CEL,0x1796DE0DL},{0x868C9304L,1L,3L,0x79C5DFBCL},{3L,0x79C5DFBCL,0L,0x60774821L},{0xAFAA48CCL,0x6FF5FBB4L,1L,0x353696E0L}},{{0x868C9304L,0x60774821L,0xCF3742C0L,0x353696E0L},{0L,0x6FF5FBB4L,0x06334729L,0x60774821L},{(-1L),0x79C5DFBCL,0x03F40BDEL,0x79C5DFBCL},{(-9L),1L,0xCF3742C0L,0x1796DE0DL},{0x60F42E90L,0x29281337L,3L,(-1L)},{0xAFAA48CCL,0x79C5DFBCL,(-1L),(-7L)}},{{0xAFAA48CCL,0x1F8E388CL,3L,0x353696E0L},{0x60F42E90L,(-7L),0xCF3742C0L,0L},{(-9L),0x6FF5FBB4L,0x03F40BDEL,(-7L)},{(-1L),(-1L),0x06334729L,0x79C5DFBCL},{0L,0x29281337L,0xCF3742C0L,0x5B30FD8BL},{3L,0x60774821L,(-1L),1L}},{{0x8980DF3AL,0x9D29CCA1L,1L,0L},{(-1L),6L,(-1L),0x66D8DA35L},{3L,0L,(-1L),0x5B30FD8BL},{0x1928B54DL,(-1L),(-1L),0L},{0x4AAF27CEL,1L,(-1L),0x9D29CCA1L},{0x1928B54DL,0x60774821L,(-1L),0x1F8E388CL}},{{3L,7L,(-1L),1L},{(-1L),1L,1L,0L},{0x8980DF3AL,6L,(-1L),0x5B30FD8BL},{3L,0L,0x03F40BDEL,0x5B30FD8BL},{1L,6L,(-1L),0L},{0xCF3742C0L,1L,(-9L),1L}},{{0x1928B54DL,7L,0x03F40BDEL,0x1F8E388CL},{1L,0x60774821L,(-1L),0x9D29CCA1L},{0x8980DF3AL,1L,0xDDEC24A8L,0L},{0x8980DF3AL,(-1L),(-1L),0x5B30FD8BL},{1L,0L,0x03F40BDEL,0x66D8DA35L},{0x1928B54DL,6L,(-9L),0L}}};
        uint32_t l_61 = 0x587EAAD8L;
        int i, j, k;
        for (g_2 = 25; (g_2 > 34); g_2 = safe_add_func_uint8_t_u_u(g_2, 7))
        { /* block id: 7 */
            int64_t l_42 = (-1L);
            int32_t l_51 = 0x5DC65F55L;
            int32_t l_52 = 0L;
            int32_t l_53 = 0x29EA9C73L;
            int32_t l_54[6][4] = {{0xEE6A4CB4L,(-1L),0xEE6A4CB4L,(-1L)},{0xEE6A4CB4L,(-1L),0xEE6A4CB4L,(-1L)},{0xEE6A4CB4L,(-1L),0xEE6A4CB4L,(-1L)},{0xEE6A4CB4L,(-1L),0xEE6A4CB4L,(-1L)},{0xEE6A4CB4L,(-1L),0xEE6A4CB4L,(-1L)},{0xEE6A4CB4L,(-1L),0xEE6A4CB4L,(-1L)}};
            uint32_t l_57 = 3UL;
            uint64_t l_64 = 0x3DF0C45E9BC94048LL;
            int i, j;
            g_43[5] ^= (safe_rshift_func_uint8_t_u_u(((((func_10(g_2, g_2) <= l_42) <= g_2) && g_20) , 0x4AL), g_2));
            l_57++;
            l_61--;
            --l_64;
        }
        l_49 = (safe_div_func_uint16_t_u_u(l_44, g_2));
    }
    if (func_10(g_43[5], g_20))
    { /* block id: 26 */
        uint64_t l_72 = 0xECFAE2F6F5F90F01LL;
        g_47[1][8][3] = ((!((safe_mul_func_uint8_t_u_u(l_72, g_20)) , g_47[2][7][0])) , 0xFEE4E9FCL);
        g_73[1] |= g_47[4][0][3];
    }
    else
    { /* block id: 29 */
        int64_t l_74[5] = {(-10L),(-10L),(-10L),(-10L),(-10L)};
        int i;
        g_47[0][6][1] = 0xEEE36A70L;
        g_47[2][7][0] = (func_13(l_74[4], l_74[4], l_50) <= g_2);
        g_47[2][7][0] = func_75(((!((((((l_81 < 0xB16F84042AD97937LL) ^ 2UL) > l_81) && 1UL) || l_74[4]) >= g_43[2])) < l_49), g_47[1][6][0], g_47[2][7][0], g_43[0]);
        return g_43[5];
    }
    for (l_3 = 0; (l_3 == 18); l_3 = safe_add_func_uint32_t_u_u(l_3, 4))
    { /* block id: 55 */
        uint8_t l_112[2];
        uint32_t l_113 = 0x7732ECB4L;
        int32_t l_114 = 0x08352772L;
        int16_t l_118 = 0L;
        int i;
        for (i = 0; i < 2; i++)
            l_112[i] = 0x32L;
        l_114 = (safe_rshift_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u((!l_112[0]), l_113)) < l_114), g_43[5]));
        l_115++;
        if (l_118)
            break;
        l_55 = l_49;
    }
    return g_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_20
 * writes: g_20
 */
static uint64_t  func_10(uint8_t  p_11, int16_t  p_12)
{ /* block id: 8 */
    const uint8_t l_23 = 0x81L;
    int32_t l_24 = 0L;
    int16_t l_41[1][2];
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_41[i][j] = (-10L);
    }
    g_20 ^= func_13(g_2, g_2, g_2);
    l_24 ^= (safe_add_func_uint16_t_u_u((func_13((((0x9EL || 0UL) <= l_23) , 0x62L), g_20, g_2) || 0x4DDB84C6A37D7C86LL), 0x7D6BL));
    l_24 = ((safe_add_func_uint8_t_u_u(((!((safe_lshift_func_uint16_t_u_u(func_30(((func_13(l_24, l_24, l_23) > 0x87C5C6A81D68C2AFLL) >= 0UL), g_2, g_2, p_11, p_12), 15)) >= l_23)) != g_20), g_20)) , l_24);
    l_41[0][1] = (safe_sub_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(p_12, 0x293CL)), 18446744073709551606UL));
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int32_t  func_13(uint8_t  p_14, uint64_t  p_15, uint8_t  p_16)
{ /* block id: 9 */
    uint32_t l_19 = 0xDD9CD443L;
    l_19 = (safe_rshift_func_uint16_t_u_u(65535UL, g_2));
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const uint16_t  func_30(int16_t  p_31, int8_t  p_32, uint8_t  p_33, uint32_t  p_34, uint32_t  p_35)
{ /* block id: 14 */
    const uint8_t l_36 = 0xE1L;
    return l_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_47 g_2 g_20
 * writes: g_47
 */
static int32_t  func_75(int8_t  p_76, int32_t  p_77, uint64_t  p_78, uint64_t  p_79)
{ /* block id: 32 */
    uint16_t l_82[5][2][3] = {{{0x3D5EL,0x5F4FL,0x5F4FL},{0x5F4FL,0UL,0x1673L}},{{0x3D5EL,0UL,0x3D5EL},{1UL,0x5F4FL,0x1673L}},{{1UL,1UL,0x5F4FL},{0x3D5EL,0x5F4FL,0x5F4FL}},{{0x5F4FL,0UL,0x1673L},{0x3D5EL,0UL,0x3D5EL}},{{1UL,0x5F4FL,0x1673L},{1UL,1UL,0x5F4FL}}};
    int32_t l_83[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
    uint64_t l_103 = 0x4DF38324C0507638LL;
    int32_t l_104 = 0L;
    int i, j, k;
    l_83[8] |= (((g_47[1][3][3] ^ 4294967295UL) && l_82[2][1][2]) && p_76);
    if ((safe_add_func_uint16_t_u_u(((p_77 != 0x0405A668L) ^ g_2), l_82[0][1][0])))
    { /* block id: 34 */
        int64_t l_86[8] = {0x5633C59A757E7574LL,0x5633C59A757E7574LL,0x45631F00607BE1BDLL,0x5633C59A757E7574LL,0x5633C59A757E7574LL,0x45631F00607BE1BDLL,0x5633C59A757E7574LL,0x5633C59A757E7574LL};
        int i;
        l_86[2] = ((255UL != p_78) > p_77);
    }
    else
    { /* block id: 36 */
        int32_t l_91[2];
        int32_t l_92[5];
        uint32_t l_93 = 0UL;
        int i;
        for (i = 0; i < 2; i++)
            l_91[i] = 1L;
        for (i = 0; i < 5; i++)
            l_92[i] = 8L;
        if ((safe_rshift_func_uint16_t_u_u((((safe_lshift_func_uint16_t_u_u(l_91[0], 5)) > g_47[2][7][0]) && g_47[4][8][1]), l_82[2][1][0])))
        { /* block id: 37 */
            g_47[2][7][0] = g_20;
            g_47[2][6][2] = 0x5A70E1A0L;
        }
        else
        { /* block id: 40 */
            g_47[1][2][3] = (4UL && l_91[0]);
            return p_77;
        }
        l_93--;
        l_92[1] &= (!(safe_rshift_func_uint8_t_u_u(g_47[2][7][0], 2)));
    }
    l_83[8] &= g_2;
    l_104 &= (safe_rshift_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((((g_47[2][7][0] , l_83[8]) < p_78) != l_82[2][1][2]), 8UL)), l_103));
    return p_78;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_43[i], "g_43[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_47[i][j][k], "g_47[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_73[i], "g_73[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 44
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 83
XXX times a non-volatile is write: 31
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 42
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 16
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 22.2
XXX percentage an existing variable is used: 77.8
********************* end of statistics **********************/

