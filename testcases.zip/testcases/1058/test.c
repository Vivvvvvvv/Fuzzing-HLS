/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7343364333976291026
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
   uint64_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_2 = 253UL;/* VOLATILE GLOBAL g_2 */
static int32_t g_6 = 0x72A72759L;
static int8_t g_13 = 0xD3L;
static const struct S0 g_38 = {1UL,0UL};
static int8_t g_48[7][6][6] = {{{0xF7L,0xEFL,1L,(-2L),0L,6L},{(-1L),0x7DL,5L,5L,0x7DL,(-1L)},{(-3L),6L,4L,(-2L),0L,0xCAL},{0L,0xA4L,0x96L,0x7DL,(-2L),0xA0L},{0L,1L,0x7DL,(-2L),0xF7L,7L},{(-3L),0L,0x28L,5L,0x96L,0xA4L}},{{(-1L),0xA0L,1L,(-2L),0x0EL,(-3L)},{0xF7L,(-6L),0xA0L,1L,6L,0x28L},{4L,0xDFL,9L,1L,0xEFL,0x7DL},{0L,(-2L),7L,(-1L),0L,0x96L},{0xF7L,(-2L),1L,0x0EL,0xEFL,4L},{1L,0xDFL,(-1L),1L,6L,5L}},{{7L,0x28L,0xF7L,0xA0L,0x96L,1L},{(-2L),6L,(-1L),1L,1L,(-1L)},{(-1L),(-1L),(-3L),0L,9L,0x96L},{0xA0L,0xCAL,0L,0x49L,1L,(-3L)},{(-2L),0xA0L,0L,7L,(-1L),0x96L},{0xFBL,7L,(-3L),0xEFL,0xA4L,(-1L)}},{{0xEFL,0xA4L,(-1L),(-1L),0x96L,1L},{0xDFL,(-3L),0xF7L,5L,(-1L),5L},{(-1L),(-6L),(-1L),0x7DL,0xFBL,4L},{0x49L,0x7BL,1L,0xF7L,4L,0x96L},{0xCAL,0L,7L,0xF7L,(-2L),0x7DL},{0x49L,(-1L),9L,0x7DL,7L,0x28L}},{{(-1L),1L,6L,5L,0xE1L,1L},{0xDFL,0xFBL,0xCAL,(-1L),0xA0L,0xA0L},{0xEFL,0L,0L,0xEFL,(-1L),0xF7L},{0xFBL,0x0EL,0xA4L,7L,(-6L),6L},{(-2L),0xEFL,(-4L),0x49L,(-6L),(-2L)},{0xA0L,0x0EL,0xE1L,0L,(-1L),(-1L)}},{{(-1L),0L,0xDFL,1L,0xA0L,7L},{(-2L),0xFBL,5L,0xA0L,0xE1L,0L},{7L,1L,(-1L),1L,7L,0xEFL},{1L,(-1L),1L,0x0EL,(-2L),1L},{0xF7L,0L,1L,(-1L),4L,1L},{0L,0x7BL,1L,1L,0xFBL,0xEFL}},{{4L,(-6L),(-1L),0L,(-1L),0L},{9L,(-3L),5L,1L,0x96L,7L},{(-1L),0xA4L,0xDFL,0xDFL,0xA4L,(-1L)},{1L,7L,0xE1L,0x28L,(-1L),1L},{0x7DL,6L,(-2L),0xA0L,0L,7L},{0x7DL,(-2L),0xA0L,0x28L,1L,9L}}};
static volatile int16_t g_50 = 0x7A78L;/* VOLATILE GLOBAL g_50 */
static volatile int16_t g_53 = 0L;/* VOLATILE GLOBAL g_53 */
static volatile uint16_t g_57 = 0xF1EAL;/* VOLATILE GLOBAL g_57 */
static uint64_t g_70 = 0x77434CA839EF24C4LL;
static int8_t g_72 = (-1L);
static int32_t g_82[9][4] = {{0xDA103C12L,0xDA103C12L,1L,(-1L)},{0xED53B0E2L,0x30B1440DL,0xDA103C12L,(-6L)},{0x6C942108L,5L,1L,0xDA103C12L},{0x17125C8CL,5L,0x17125C8CL,(-6L)},{5L,0x30B1440DL,0x5F4D78F3L,(-1L)},{(-1L),0xDA103C12L,0x6C942108L,0x30B1440DL},{1L,0x6C942108L,0x6C942108L,1L},{(-1L),(-6L),0x5F4D78F3L,0x17125C8CL},{5L,0xC58EAAB9L,0x17125C8CL,1L}};
static uint8_t g_93[6][9][4] = {{{0xA3L,0x78L,0x3CL,255UL},{0x26L,0x7AL,0x26L,0x81L},{0x81L,0x18L,0x44L,0xF0L},{3UL,0x12L,0x23L,0x18L},{0x0EL,254UL,0x23L,248UL},{3UL,0x1AL,0x44L,1UL},{0x81L,3UL,0x26L,0xB9L},{0x26L,0xB9L,0x3CL,0x0EL},{0xA3L,6UL,1UL,0x0EL}},{{0x7AL,1UL,0xABL,0xFBL},{255UL,8UL,1UL,1UL},{0xA4L,0x3EL,0xA3L,0xA3L},{248UL,248UL,0xFBL,0xA5L},{0xFFL,255UL,254UL,0x64L},{6UL,0x3CL,0x3EL,254UL},{8UL,0x3CL,0xA4L,0x64L},{0x3CL,255UL,0xFFL,0xA5L},{0xB2L,248UL,0x0EL,0xA3L}},{{0x6AL,0x3EL,0x76L,1UL},{0x78L,8UL,0xB9L,0xFBL},{0x76L,1UL,255UL,0x0EL},{255UL,6UL,0x64L,0x0EL},{1UL,0xB9L,3UL,0xB9L},{255UL,3UL,254UL,1UL},{0x0EL,0x1AL,255UL,248UL},{0xA5L,254UL,8UL,0x18L},{0xA5L,0x12L,255UL,0xF0L}},{{0x0EL,0x18L,254UL,0x81L},{255UL,0x7AL,3UL,255UL},{1UL,0x78L,0x64L,255UL},{255UL,0xB2L,255UL,0x44L},{0x76L,0xF9L,0xB9L,0xFFL},{0x78L,0x49L,0x76L,0xFFL},{0x6AL,0x0EL,0x0EL,0x6AL},{0xB2L,0x64L,0xFFL,0x1AL},{6UL,0x81L,0x44L,255UL}},{{253UL,0x23L,0x48L,255UL},{0x0EL,0x81L,0xA4L,0x1AL},{0xBEL,254UL,255UL,1UL},{0x49L,0UL,0x3CL,0xF9L},{0x44L,0x1AL,3UL,0xBEL},{8UL,0xB9L,0xFBL,0x81L},{0x6AL,254UL,0xF0L,0xA3L},{0x3CL,0x26L,6UL,0xFFL},{0x64L,0x6AL,0x64L,0x23L}},{{0x23L,0x76L,0x81L,248UL},{0x0EL,255UL,1UL,0x76L},{0x18L,0xFFL,1UL,0x49L},{0x0EL,0x12L,0x81L,3UL},{0x23L,0x0EL,0x64L,0x3EL},{0x64L,0x3EL,6UL,0UL},{0x3CL,0x0EL,0xF0L,0x18L},{0x6AL,3UL,0xFBL,255UL},{8UL,253UL,3UL,0xF0L}}};
static int16_t g_95 = 1L;
static volatile uint64_t g_117 = 18446744073709551608UL;/* VOLATILE GLOBAL g_117 */
static int32_t g_118 = 0xD66935DDL;
static int8_t g_123 = (-1L);
static int32_t g_124 = 0x31F8782DL;
static volatile uint32_t g_125 = 18446744073709551608UL;/* VOLATILE GLOBAL g_125 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint8_t  func_7(uint32_t  p_8, int32_t  p_9, uint16_t  p_10, int16_t  p_11);
static uint8_t  func_21(uint8_t  p_22, int16_t  p_23, uint8_t  p_24, int16_t  p_25);
static int16_t  func_26(int32_t  p_27, struct S0  p_28, const int8_t  p_29);
static int32_t  func_32(struct S0  p_33, int16_t  p_34, const struct S0  p_35, uint32_t  p_36);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_13 g_38 g_57 g_50 g_48 g_70 g_53 g_72 g_82 g_93 g_118 g_95 g_125
 * writes: g_2 g_6 g_48 g_57 g_70 g_72 g_82 g_93 g_95 g_117 g_118 g_125
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5[4][3][6] = {{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}},{{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L},{0L,0L,0L,0L,0L,0L}}};
    uint16_t l_92 = 0xBF5EL;
    int32_t l_106 = 0x7036DBD5L;
    int32_t l_119 = (-1L);
    int i, j, k;
    ++g_2;
    for (g_6 = 2; (g_6 >= 0); g_6 -= 1)
    { /* block id: 4 */
        int64_t l_12 = 0x60CBEB969161D594LL;
        int32_t l_87 = 0x63695F89L;
        if ((func_7((l_5[0][2][5] <= g_6), g_2, l_12, l_12) , l_12))
        { /* block id: 49 */
            const int32_t l_80 = 0xD506DC73L;
            uint8_t l_81 = 254UL;
            int32_t l_94 = 0xDF4C6C2CL;
            g_82[8][1] = ((((safe_mod_func_int16_t_s_s(((!(g_70 | 0L)) < l_12), 0x6ADEL)) ^ g_48[4][5][5]) , l_80) , l_81);
            l_87 = (safe_mod_func_int32_t_s_s((safe_mul_func_int16_t_s_s(0xF44AL, l_5[1][1][3])), 0xBB7457E6L));
            g_93[2][6][0] = (safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_u((((g_72 , 0x059363F8L) , l_87) == l_5[3][1][5]), 0)) > l_92), g_70));
            l_94 = ((0x87184D558848F550LL && g_53) < 0x8C8944EAL);
        }
        else
        { /* block id: 54 */
            uint8_t l_102 = 0x3CL;
            int32_t l_103[1][4][9] = {{{(-10L),0x7D4F9838L,(-10L),(-10L),0x7D4F9838L,(-10L),(-10L),0x7D4F9838L,(-10L)},{0x60C9FB33L,0L,0x60C9FB33L,0x60C9FB33L,0L,0x60C9FB33L,0x60C9FB33L,0L,0x60C9FB33L},{(-10L),0x7D4F9838L,(-10L),(-10L),0x7D4F9838L,(-10L),(-10L),0x7D4F9838L,(-10L)},{0x60C9FB33L,0L,0x60C9FB33L,0x60C9FB33L,0L,0x60C9FB33L,0x60C9FB33L,0L,0x60C9FB33L}}};
            int i, j, k;
            g_95 = (g_82[8][1] <= l_87);
            l_103[0][2][5] = (((safe_rshift_func_int16_t_s_u(((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s((g_93[2][6][0] != l_12), 2)), l_102)) && 0xF5L), 4)) && g_48[2][0][2]) , g_93[2][6][0]);
            l_106 = (safe_add_func_int8_t_s_s(((l_102 , l_92) != l_103[0][0][8]), g_53));
            l_87 = 8L;
        }
        l_87 = (safe_mod_func_int64_t_s_s((((safe_add_func_int64_t_s_s((((safe_sub_func_int32_t_s_s((safe_div_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u(l_87, l_87)), g_53)), 0L)) & g_48[6][1][1]) || l_92), 1UL)) || (-1L)) & g_48[4][5][5]), g_93[2][6][0]));
        g_117 = 0x022BCE0AL;
        for (l_106 = 0; (l_106 <= 2); l_106 += 1)
        { /* block id: 64 */
            g_118 &= g_82[1][3];
        }
    }
    l_119 ^= l_106;
    for (g_95 = 0; (g_95 >= (-24)); --g_95)
    { /* block id: 71 */
        int8_t l_122[1][10] = {{0x25L,0xF6L,0xF6L,0x25L,0xFAL,0x25L,0x25L,0x25L,0x96L,0L}};
        int i, j;
        ++g_125;
    }
    return g_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_38 g_6 g_57 g_50 g_48 g_70 g_53
 * writes: g_48 g_57 g_70 g_72
 */
static uint8_t  func_7(uint32_t  p_8, int32_t  p_9, uint16_t  p_10, int16_t  p_11)
{ /* block id: 5 */
    uint16_t l_14 = 0UL;
    struct S0 l_30 = {0UL,18446744073709551615UL};
    const uint16_t l_31 = 65535UL;
    int32_t l_74 = (-5L);
    --l_14;
    p_9 = (~(((safe_sub_func_uint32_t_u_u((+0x14L), g_2)) == 5L) >= (-4L)));
    l_74 = (func_21((func_26(g_13, l_30, l_31) <= 9UL), g_6, g_38.f1, p_10) >= l_30.f0);
    for (p_11 = (-26); (p_11 > 10); ++p_11)
    { /* block id: 45 */
        return g_53;
    }
    return l_30.f1;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_72
 */
static uint8_t  func_21(uint8_t  p_22, int16_t  p_23, uint8_t  p_24, int16_t  p_25)
{ /* block id: 39 */
    uint64_t l_73 = 0x72C46366C4368EC6LL;
    g_72 = (-10L);
    return l_73;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_6 g_13 g_57 g_50 g_48 g_70
 * writes: g_48 g_57 g_70
 */
static int16_t  func_26(int32_t  p_27, struct S0  p_28, const int8_t  p_29)
{ /* block id: 8 */
    struct S0 l_37 = {2UL,0x3E70D28E48792891LL};
    int32_t l_71 = (-4L);
    l_71 = func_32(l_37, p_28.f0, g_38, g_6);
    return l_37.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_57 g_50 g_48 g_70
 * writes: g_48 g_57 g_70
 */
static int32_t  func_32(struct S0  p_33, int16_t  p_34, const struct S0  p_35, uint32_t  p_36)
{ /* block id: 9 */
    uint64_t l_39[7][9][4] = {{{0xC46221EB1ED30906LL,0xC987F9BD85DD727ALL,18446744073709551611UL,0UL},{0x3DEE6EE3E4F6F484LL,0UL,18446744073709551611UL,18446744073709551611UL},{0xC987F9BD85DD727ALL,0UL,0xE9426CEFC6E20B39LL,0x16037280DDA259C4LL},{0x0CB933DF47B5881FLL,0x6A96DAD8BE776E9FLL,1UL,18446744073709551607UL},{1UL,18446744073709551613UL,1UL,0xA56CF6D70783DB47LL},{0UL,0xA718BA309CE07B88LL,0xA56CF6D70783DB47LL,18446744073709551609UL},{0x3DEE6EE3E4F6F484LL,1UL,0xD57D38C46158E9D2LL,0xA718BA309CE07B88LL},{0xA718BA309CE07B88LL,0UL,0xD57D38C46158E9D2LL,0x16037280DDA259C4LL},{0x3DEE6EE3E4F6F484LL,0x0CB933DF47B5881FLL,0xA56CF6D70783DB47LL,0xD57D38C46158E9D2LL}},{{0UL,0UL,1UL,0xC987F9BD85DD727ALL},{1UL,0xC987F9BD85DD727ALL,1UL,0xC46221EB1ED30906LL},{0x0CB933DF47B5881FLL,1UL,0xE9426CEFC6E20B39LL,0xA56CF6D70783DB47LL},{0xC987F9BD85DD727ALL,0x85B5F732BC12A55BLL,18446744073709551611UL,18446744073709551611UL},{0x3DEE6EE3E4F6F484LL,0x3DEE6EE3E4F6F484LL,18446744073709551611UL,18446744073709551607UL},{0xC46221EB1ED30906LL,0UL,0UL,0xC987F9BD85DD727ALL},{1UL,0UL,0xA56CF6D70783DB47LL,0UL},{0x6A96DAD8BE776E9FLL,0UL,0xE9426CEFC6E20B39LL,0xC987F9BD85DD727ALL},{0UL,0UL,4UL,18446744073709551607UL}},{{0x0CB933DF47B5881FLL,0x3DEE6EE3E4F6F484LL,0UL,18446744073709551611UL},{0UL,0x85B5F732BC12A55BLL,18446744073709551609UL,0xA56CF6D70783DB47LL},{1UL,1UL,18446744073709551611UL,0xC46221EB1ED30906LL},{8UL,0xC987F9BD85DD727ALL,0xD57D38C46158E9D2LL,0xC987F9BD85DD727ALL},{1UL,0UL,18446744073709551611UL,0xD57D38C46158E9D2LL},{0x6A96DAD8BE776E9FLL,0x0CB933DF47B5881FLL,0UL,0x16037280DDA259C4LL},{1UL,0UL,1UL,0xA718BA309CE07B88LL},{1UL,1UL,0UL,18446744073709551609UL},{0x6A96DAD8BE776E9FLL,0xA718BA309CE07B88LL,18446744073709551611UL,0xA56CF6D70783DB47LL}},{{1UL,18446744073709551613UL,0xD57D38C46158E9D2LL,18446744073709551607UL},{8UL,0x6A96DAD8BE776E9FLL,18446744073709551611UL,0x16037280DDA259C4LL},{1UL,0UL,18446744073709551609UL,18446744073709551611UL},{0UL,0UL,0UL,0UL},{0x0CB933DF47B5881FLL,0xC987F9BD85DD727ALL,4UL,0xA718BA309CE07B88LL},{0UL,18446744073709551613UL,0xE9426CEFC6E20B39LL,18446744073709551611UL},{0x6A96DAD8BE776E9FLL,8UL,0xA56CF6D70783DB47LL,18446744073709551611UL},{1UL,18446744073709551613UL,0UL,0xA718BA309CE07B88LL},{0xC46221EB1ED30906LL,0xC987F9BD85DD727ALL,18446744073709551611UL,0UL}},{{0x3DEE6EE3E4F6F484LL,0UL,18446744073709551611UL,18446744073709551611UL},{0xC987F9BD85DD727ALL,0UL,0xE9426CEFC6E20B39LL,0x16037280DDA259C4LL},{0x0CB933DF47B5881FLL,0x6A96DAD8BE776E9FLL,1UL,18446744073709551607UL},{1UL,18446744073709551613UL,1UL,0xA56CF6D70783DB47LL},{0UL,0xA718BA309CE07B88LL,0xA56CF6D70783DB47LL,18446744073709551609UL},{0x3DEE6EE3E4F6F484LL,1UL,0xD57D38C46158E9D2LL,0xA718BA309CE07B88LL},{0xA718BA309CE07B88LL,0UL,0xD57D38C46158E9D2LL,0x16037280DDA259C4LL},{0x3DEE6EE3E4F6F484LL,0x0CB933DF47B5881FLL,0xA56CF6D70783DB47LL,0xD57D38C46158E9D2LL},{0UL,0UL,1UL,0xC987F9BD85DD727ALL}},{{1UL,0xC987F9BD85DD727ALL,1UL,0xC46221EB1ED30906LL},{0x0CB933DF47B5881FLL,1UL,0xE9426CEFC6E20B39LL,0UL},{1UL,0x6545545654A13735LL,0x89BE308DDD7AD251LL,0x89BE308DDD7AD251LL},{0x1A770AACC702B5BDLL,0x1A770AACC702B5BDLL,1UL,0xBC130268D9A65C8BLL},{18446744073709551611UL,0x0CB933DF47B5881FLL,4UL,1UL},{0x656E2E31B5465392LL,0xC46221EB1ED30906LL,0UL,4UL},{0UL,0xC46221EB1ED30906LL,0x85B5F732BC12A55BLL,1UL},{0xC46221EB1ED30906LL,0x0CB933DF47B5881FLL,18446744073709551608UL,0xBC130268D9A65C8BLL},{0xA718BA309CE07B88LL,0x1A770AACC702B5BDLL,0xC46221EB1ED30906LL,0x89BE308DDD7AD251LL}},{{0xE9426CEFC6E20B39LL,0x6545545654A13735LL,0xD57D38C46158E9D2LL,0UL},{0x656E2E31B5465392LL,0x81002A9564FCBDFALL,1UL,18446744073709551611UL},{0xA56CF6D70783DB47LL,1UL,18446744073709551613UL,1UL},{0x81002A9564FCBDFALL,8UL,0x89BE308DDD7AD251LL,18446744073709551613UL},{0UL,0xA718BA309CE07B88LL,0xC46221EB1ED30906LL,0UL},{18446744073709551607UL,0x0CB933DF47B5881FLL,0x656E2E31B5465392LL,18446744073709551609UL},{18446744073709551607UL,0x81002A9564FCBDFALL,0xC46221EB1ED30906LL,0xD57D38C46158E9D2LL},{0UL,18446744073709551609UL,0x89BE308DDD7AD251LL,0UL},{0x81002A9564FCBDFALL,0x5F74462D17F4926ALL,18446744073709551613UL,0xBC130268D9A65C8BLL}}};
    int32_t l_44 = 2L;
    int32_t l_52 = 0xF52682FBL;
    int32_t l_55[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
    int8_t l_66 = 0x25L;
    int i, j, k;
    for (p_33.f0 = 0; (p_33.f0 <= 3); p_33.f0 += 1)
    { /* block id: 12 */
        int32_t l_51 = 0L;
        int32_t l_54 = 0x7B57B06EL;
        if (g_13)
            break;
        l_44 = ((safe_lshift_func_int16_t_s_u(((((safe_div_func_uint8_t_u_u(1UL, p_36)) ^ 0xF00D13BCL) == 0x1E226996L) ^ g_13), p_33.f1)) != 0x4363L);
        for (p_33.f1 = 0; (p_33.f1 <= 3); p_33.f1 += 1)
        { /* block id: 17 */
            int8_t l_47[7];
            int i;
            for (i = 0; i < 7; i++)
                l_47[i] = (-1L);
            g_48[4][5][5] = (safe_rshift_func_int16_t_s_u(((-1L) || p_36), l_47[6]));
        }
        for (l_44 = 3; (l_44 >= 0); l_44 -= 1)
        { /* block id: 22 */
            int64_t l_49[3];
            int32_t l_56 = (-1L);
            int i;
            for (i = 0; i < 3; i++)
                l_49[i] = (-7L);
            l_49[1] |= (l_44 < p_35.f1);
            ++g_57;
        }
    }
    if (l_44)
        goto lbl_67;
lbl_67:
    for (p_33.f0 = 0; (p_33.f0 >= 5); p_33.f0 = safe_add_func_uint64_t_u_u(p_33.f0, 9))
    { /* block id: 29 */
        uint8_t l_63[6];
        int i;
        for (i = 0; i < 6; i++)
            l_63[i] = 0x3BL;
        l_63[5] = (!(p_33.f1 && g_50));
        l_55[1] = (((safe_add_func_uint64_t_u_u((g_57 <= p_35.f1), p_36)) & l_66) && g_48[4][5][5]);
        if (p_33.f0)
            continue;
    }
    g_70 ^= (safe_sub_func_uint32_t_u_u(0xEB3E5EB5L, p_33.f1));
    return p_36;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_38.f0, "g_38.f0", print_hash_value);
    transparent_crc(g_38.f1, "g_38.f1", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_48[i][j][k], "g_48[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_82[i][j], "g_82[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_93[i][j][k], "g_93[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 42
   depth: 1, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 44
   depth: 2, occurrence: 12
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 7, occurrence: 4
   depth: 8, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 72
XXX times a non-volatile is write: 30
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 51
XXX percentage of non-volatile access: 88.7

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 44
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 13
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 39.5
XXX percentage an existing variable is used: 60.5
********************* end of statistics **********************/

