/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12622763725173266152
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3 = 0x72D4EA68L;
static uint32_t g_19 = 18446744073709551611UL;
static int8_t g_28 = 1L;
static volatile uint32_t g_29 = 1UL;/* VOLATILE GLOBAL g_29 */
static volatile int8_t g_38 = 0xFCL;/* VOLATILE GLOBAL g_38 */
static volatile int32_t g_39 = 0x3763964EL;/* VOLATILE GLOBAL g_39 */
static uint16_t g_40 = 0x4A4EL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_4(uint32_t  p_5, int16_t  p_6, const uint64_t  p_7, uint8_t  p_8, const uint32_t  p_9);
static int64_t  func_13(uint8_t  p_14, uint32_t  p_15, int64_t  p_16, int64_t  p_17, uint32_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_19 g_40 g_38
 * writes: g_3 g_19 g_29 g_40
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[5];
    int32_t l_43 = (-5L);
    int i;
    for (i = 0; i < 5; i++)
        l_2[i] = 0xF4A8B108L;
    g_3 = l_2[2];
    l_43 |= func_4((safe_sub_func_uint8_t_u_u(l_2[1], g_3)), g_3, g_3, l_2[2], g_3);
    return g_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_19 g_40
 * writes: g_19 g_29 g_40
 */
static int32_t  func_4(uint32_t  p_5, int16_t  p_6, const uint64_t  p_7, uint8_t  p_8, const uint32_t  p_9)
{ /* block id: 2 */
    uint64_t l_12 = 18446744073709551606UL;
    int32_t l_35[2];
    int64_t l_36[5] = {0L,0L,0L,0L,0L};
    int64_t l_37 = 0x395CC9E520C3D8D5LL;
    int i;
    for (i = 0; i < 2; i++)
        l_35[i] = 5L;
    l_12 &= 0x5C285CE9L;
    l_35[0] = (func_13(p_7, l_12, g_3, p_5, l_12) & p_5);
    ++g_40;
    return g_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_19
 * writes: g_19 g_29
 */
static int64_t  func_13(uint8_t  p_14, uint32_t  p_15, int64_t  p_16, int64_t  p_17, uint32_t  p_18)
{ /* block id: 4 */
    uint16_t l_24 = 65531UL;
    int32_t l_25 = 0xFC0336AEL;
    int32_t l_26 = 0x2C4EB0A1L;
    int32_t l_27[1];
    int i;
    for (i = 0; i < 1; i++)
        l_27[i] = 0x09E149CFL;
    g_19 = (((((7UL == 65531UL) <= g_3) ^ g_3) > 1UL) > 65535UL);
    l_25 = (((safe_rshift_func_int16_t_s_u((safe_mul_func_int8_t_s_s(0x52L, g_3)), l_24)) | p_15) , g_3);
    g_29--;
    for (p_16 = 0; (p_16 < 1); p_16 = safe_add_func_uint64_t_u_u(p_16, 4))
    { /* block id: 10 */
        uint64_t l_34[9] = {0x6C5533F2A6ADD33DLL,3UL,0x6C5533F2A6ADD33DLL,3UL,0x6C5533F2A6ADD33DLL,3UL,0x6C5533F2A6ADD33DLL,3UL,0x6C5533F2A6ADD33DLL};
        int i;
        l_34[7] ^= 0xD7C8A36AL;
        return g_19;
    }
    return p_17;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 9
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 91.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 38.3
XXX percentage an existing variable is used: 61.7
********************* end of statistics **********************/

