/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16325719139713491655
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_7[8][4] = {{0x4215E1ABL,0xB8BC588EL,3L,3L},{0xC2A82A10L,0xC2A82A10L,0xA43B2B74L,1L},{0x8F21009DL,(-1L),(-2L),0x62751C76L},{(-2L),0x62751C76L,0x4215E1ABL,(-2L)},{0xC2A82A10L,0x62751C76L,6L,0x62751C76L},{0x62751C76L,(-1L),3L,1L},{0x1B552BF3L,0xC2A82A10L,0x4215E1ABL,3L},{0x8F21009DL,0xB8BC588EL,1L,0x62751C76L}};
static int32_t g_8 = (-5L);
static uint8_t g_9 = 0xD3L;
static volatile int32_t g_15 = 0xB75DA2CAL;/* VOLATILE GLOBAL g_15 */


/* --- FORWARD DECLARATIONS --- */
static const int16_t  func_1(void);
static int32_t  func_21(int32_t  p_22, int64_t  p_23, int16_t  p_24);
static int32_t  func_30(int32_t  p_31, int16_t  p_32, int32_t  p_33, int32_t  p_34);
static int32_t  func_37(uint16_t  p_38, int64_t  p_39, uint64_t  p_40, int16_t  p_41, int32_t  p_42);
static int32_t  func_66(uint32_t  p_67, int8_t  p_68, int8_t  p_69, const int32_t  p_70, int16_t  p_71);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_8 g_9 g_15
 * writes: g_9 g_7
 */
static const int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_10 = 0x1A93826AL;
    int32_t l_11 = 0L;
    int32_t l_12 = 0xB504DBF0L;
    int32_t l_13 = 0x62F63069L;
    int32_t l_14 = 1L;
    uint8_t l_16 = 1UL;
    g_9 |= ((!(safe_sub_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_u(g_7[3][0], 0)) & 0x3C22L), g_8))) == 0x23CCDE6BC044B0BFLL);
    l_16++;
    if (l_14)
    { /* block id: 3 */
        uint32_t l_19 = 18446744073709551611UL;
        g_7[4][0] = (l_19 , 0x9F21C9B6L);
    }
    else
    { /* block id: 5 */
        volatile uint8_t l_20 = 0x47L;/* VOLATILE GLOBAL l_20 */
        int32_t l_26 = (-7L);
        l_20 = g_7[1][0];
        g_7[3][0] = func_21((!((g_9 , g_7[1][3]) != l_26)), l_26, g_9);
    }
    return g_7[2][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_15 g_9 g_8
 * writes: g_7
 */
static int32_t  func_21(int32_t  p_22, int64_t  p_23, int16_t  p_24)
{ /* block id: 7 */
    const int16_t l_35 = 8L;
    int32_t l_126 = 0x8E6FE173L;
    g_7[3][0] = (-10L);
    for (p_22 = 3; (p_22 >= 0); p_22 -= 1)
    { /* block id: 11 */
        int64_t l_36[4][2][8] = {{{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL},{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL}},{{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL},{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL}},{{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL},{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL}},{{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL},{0x1947684A5798870BLL,0xEBB36E903ADFE1DBLL,0x813F8C547FCE3BADLL,0x5C66B31915E3087CLL,0x5C66B31915E3087CLL,0x813F8C547FCE3BADLL,0xEBB36E903ADFE1DBLL,0x1947684A5798870BLL}}};
        int i, j, k;
        for (p_23 = 0; (p_23 <= 3); p_23 += 1)
        { /* block id: 14 */
            uint16_t l_29 = 0x944CL;
            int32_t l_99 = 0x099D399BL;
            int i, j;
            g_7[p_23][p_23] = (safe_sub_func_int8_t_s_s((((g_7[p_22][p_22] , 0x9425A33ED863780DLL) , g_7[p_22][p_22]) | l_29), p_24));
            if (g_7[3][0])
                break;
            l_99 &= func_30(((l_35 | g_15) && p_22), l_36[3][0][2], g_9, p_22);
            if (p_22)
                continue;
        }
        for (p_24 = 3; (p_24 >= 0); p_24 -= 1)
        { /* block id: 81 */
            int32_t l_100[6] = {0xA684D056L,(-1L),0xA684D056L,0xA684D056L,(-1L),0xA684D056L};
            int i, j;
            g_7[(p_22 + 3)][p_24] = g_7[(p_22 + 1)][p_22];
            if (p_22)
                break;
            l_100[2] ^= g_15;
        }
    }
    if ((0xD0F49ACE371FA290LL < (-1L)))
    { /* block id: 87 */
        const int32_t l_123 = (-1L);
        uint64_t l_124 = 18446744073709551615UL;
        uint32_t l_125 = 4294967290UL;
        int32_t l_138[7];
        int i;
        for (i = 0; i < 7; i++)
            l_138[i] = 0x64D10B9EL;
        if (((~(safe_add_func_uint64_t_u_u((safe_mod_func_int8_t_s_s(((((safe_add_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((((safe_sub_func_int64_t_s_s(((~(safe_add_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_s(((safe_mod_func_uint64_t_u_u(((safe_sub_func_int64_t_s_s(((((safe_div_func_uint64_t_u_u(0xF5B4EFAD5DA70D91LL, g_8)) && g_9) <= l_123) || l_123), p_24)) && g_15), 0xA53D9216BE7DE8CFLL)) < l_35), l_124)) >= g_9), l_123))) || l_35), l_125)) ^ g_8) <= l_35) , p_22), l_125)), 6L)) , 3UL) < p_22) & 65529UL), 0x91L)), p_24))) , g_9))
        { /* block id: 88 */
            uint8_t l_135 = 0x06L;
            l_126 = 0x02351AC1L;
            g_7[1][3] &= p_23;
            l_126 = (safe_mod_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_s(((safe_rshift_func_int8_t_s_s((((safe_lshift_func_int8_t_s_u((-1L), 5)) ^ p_23) && 0xC256L), 2)) != g_8), p_23)), l_135));
            l_138[6] = (safe_add_func_int32_t_s_s((-10L), p_23));
        }
        else
        { /* block id: 93 */
            uint8_t l_139 = 0UL;
            int16_t l_140 = 0x9A63L;
            int32_t l_141[1];
            int i;
            for (i = 0; i < 1; i++)
                l_141[i] = 0x4DC35AD3L;
            l_141[0] &= ((l_139 || l_140) || g_9);
            g_7[2][1] ^= 0x45175A4CL;
        }
        l_126 = (0x54A37D6F5CED9F99LL < g_8);
    }
    else
    { /* block id: 98 */
        g_7[3][0] = (((safe_div_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(((-1L) || 0x4BL), g_7[0][2])), 0xB9AAL)) , l_35) != 0x0381DB17C0C13F38LL);
    }
    g_7[3][0] ^= 0x26CC1D1BL;
    return l_126;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_7 g_9 g_15
 * writes: g_7
 */
static int32_t  func_30(int32_t  p_31, int16_t  p_32, int32_t  p_33, int32_t  p_34)
{ /* block id: 17 */
    int32_t l_43 = (-1L);
    uint32_t l_44 = 0xD37D67F3L;
    const int8_t l_91 = 0xA9L;
    int32_t l_93 = (-1L);
    g_7[6][3] = (func_37(l_43, l_43, p_32, l_44, l_43) == 0L);
    for (l_43 = 0; (l_43 <= 3); l_43 += 1)
    { /* block id: 62 */
        int16_t l_85 = 0x81E9L;
        int32_t l_92[9] = {0xC3DE63DFL,5L,0xC3DE63DFL,0xC3DE63DFL,5L,0xC3DE63DFL,0xC3DE63DFL,5L,0xC3DE63DFL};
        int i;
        if (l_85)
            break;
        l_92[8] &= (safe_sub_func_uint16_t_u_u((safe_unary_minus_func_int16_t_s(((safe_sub_func_uint64_t_u_u((g_8 && 0x2412L), 0x08F3773156C3613BLL)) & g_7[3][0]))), l_91));
        if ((((0UL == l_91) ^ g_9) < p_33))
        { /* block id: 65 */
            uint64_t l_94[5] = {0UL,0UL,0UL,0UL,0UL};
            int32_t l_95[4][6] = {{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)},{(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)}};
            int i, j;
            l_93 = ((0xD2C52FFFL > p_32) || (-1L));
            l_95[3][2] = (l_94[3] != 0x7AL);
            return g_7[0][1];
        }
        else
        { /* block id: 69 */
            p_34 ^= ((safe_lshift_func_uint8_t_u_s((!g_8), 7)) & 0x94615860L);
            return l_44;
        }
    }
    g_7[1][2] = l_93;
    return l_91;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_7 g_9 g_15
 * writes: g_7
 */
static int32_t  func_37(uint16_t  p_38, int64_t  p_39, uint64_t  p_40, int16_t  p_41, int32_t  p_42)
{ /* block id: 18 */
    uint8_t l_47 = 255UL;
    int32_t l_49 = (-4L);
    uint32_t l_50 = 0x39845F05L;
    int32_t l_77[8][9] = {{0x943CDA06L,(-3L),(-3L),0xCA4FAC92L,0x0D081C37L,0x95679D65L,0x0D081C37L,0xCA4FAC92L,(-3L)},{0x53E4AB27L,0x53E4AB27L,4L,(-4L),(-10L),(-1L),0xB48F0B38L,0x1A39BFC1L,0xE2C0A09EL},{0x8A1895B1L,0xA37F4EAFL,1L,0x95679D65L,0x1A39BFC1L,(-7L),(-3L),0x8A1895B1L,0x943CDA06L},{(-1L),0x943CDA06L,4L,(-7L),0x2EEAF0C9L,0xEB12FA99L,0x17F0EF7CL,0x95679D65L,(-7L)},{0xA8B8E484L,0x1A39BFC1L,(-3L),0x17F0EF7CL,0xB48F0B38L,0xB48F0B38L,0x17F0EF7CL,(-3L),0x1A39BFC1L},{0x1A39BFC1L,(-3L),1L,(-1L),0x55DDCF39L,0x17F0EF7CL,(-3L),0xE2C0A09EL,(-3L)},{1L,(-1L),0x17F0EF7CL,1L,0x95679D65L,1L,0xB48F0B38L,0x943CDA06L,(-4L)},{(-7L),(-3L),0x8A1895B1L,0x943CDA06L,0x1A39BFC1L,(-1L),0x0D081C37L,(-7L),(-1L)}};
    uint16_t l_84 = 0x0D02L;
    int i, j;
    g_7[4][2] = (-10L);
    if ((((safe_rshift_func_uint16_t_u_s(l_47, 2)) ^ 1L) > g_8))
    { /* block id: 20 */
        for (l_47 = 0; (l_47 <= 3); l_47 += 1)
        { /* block id: 23 */
            int32_t l_48 = 0L;
            g_7[3][0] |= (l_48 && p_41);
        }
        for (p_40 = 0; (p_40 <= 3); p_40 += 1)
        { /* block id: 28 */
            if (g_9)
                break;
        }
        for (p_39 = 3; (p_39 >= 0); p_39 -= 1)
        { /* block id: 33 */
            return p_40;
        }
        l_50++;
    }
    else
    { /* block id: 37 */
        uint32_t l_56 = 0x4247EC8AL;
        const uint32_t l_61[10][2] = {{6UL,0x1E67E28FL},{0x30B13CFFL,0UL},{0xB23DF491L,0x30B13CFFL},{0UL,0x1E67E28FL},{0UL,0x30B13CFFL},{0xB23DF491L,0UL},{0x30B13CFFL,0x1E67E28FL},{6UL,6UL},{0xB23DF491L,6UL},{6UL,0x1E67E28FL}};
        int16_t l_81 = 0x61FAL;
        int32_t l_83[6][3][9] = {{{0x2328EFC3L,0x2328EFC3L,0x062075E4L,2L,7L,0x851EC277L,(-7L),0x69D43CEDL,2L},{0x69D43CEDL,(-7L),7L,0x7CDF6140L,0x6EBA2134L,7L,0xA5590F52L,4L,0xF80B5AD6L},{0xCA50A4B5L,0x6E9E1E60L,0xFEAAC53AL,0x854AF0FFL,0x32788347L,0xC5F39321L,0x34787714L,0x33A1BBB5L,(-7L)}},{{0xDF41299DL,1L,0x6EBA2134L,(-1L),0x851EC277L,0x135E92A0L,1L,0x3A54A151L,6L},{(-7L),0x851EC277L,(-3L),0xCA50A4B5L,0x744102D6L,0x2328EFC3L,9L,1L,5L},{1L,5L,7L,0xF01ADD9DL,0x744102D6L,0xA5590F52L,0x0CFAF67AL,0xC4CBDEF9L,9L}},{{5L,0x0CFAF67AL,0xF80B5AD6L,0x5B464587L,0x851EC277L,1L,1L,1L,1L},{0x062075E4L,0x32788347L,0x43F0C890L,0x43F0C890L,0x32788347L,0x062075E4L,(-3L),0x988215CFL,0x181DD90CL},{(-3L),9L,0L,1L,0x6EBA2134L,0xF80B5AD6L,(-7L),0x7363D2F6L,0x851EC277L}},{{1L,1L,(-1L),0xA5590F52L,1L,0xDF41299DL,(-3L),0L,0L},{0L,0x7363D2F6L,0xC5B6348AL,0x5F8E08A2L,1L,0x43F0C890L,1L,0x0CFAF67AL,0L},{0xC5B6348AL,(-3L),1L,1L,(-3L),0xB645C325L,0x0CFAF67AL,0x854AF0FFL,0L}},{{1L,7L,6L,1L,9L,0L,9L,1L,0L},{(-7L),4L,0x33A1BBB5L,0x062075E4L,(-1L),(-3L),1L,0x851EC277L,0L},{0x5F8E08A2L,0L,1L,0x34787714L,(-8L),(-8L),0x34787714L,1L,0L}},{{0x6EBA2134L,0x854AF0FFL,0x5B464587L,(-3L),1L,0x32788347L,0xA5590F52L,0xB645C325L,0x851EC277L},{0xC5F39321L,0L,9L,0x85DA9DFCL,0xA5590F52L,1L,(-7L),0x062075E4L,0x181DD90CL},{0xB645C325L,0x854AF0FFL,0L,0x7363D2F6L,0xC5B6348AL,0x5F8E08A2L,1L,0x43F0C890L,1L}}};
        int i, j, k;
        if ((safe_div_func_uint64_t_u_u((!1UL), g_8)))
        { /* block id: 38 */
            --l_56;
        }
        else
        { /* block id: 40 */
            uint32_t l_62 = 8UL;
            l_62 = (safe_sub_func_uint32_t_u_u(0x4F583EF4L, l_61[9][0]));
            p_42 = ((((safe_lshift_func_int8_t_s_s(((+(func_66(((safe_add_func_uint16_t_u_u(l_61[6][1], l_62)) ^ l_56), l_62, p_38, g_15, g_9) != 0x227BBAC6L)) | p_38), 3)) || p_38) != l_77[1][1]) == l_77[1][1]);
            return g_9;
        }
        if (((((g_9 > l_77[1][1]) , p_38) & g_7[3][0]) ^ g_9))
        { /* block id: 48 */
            uint64_t l_80 = 0UL;
            p_42 |= ((((safe_lshift_func_int8_t_s_s(p_39, 7)) >= p_39) , p_40) >= l_80);
            g_7[3][0] &= (((l_81 > l_80) | g_8) , (-1L));
        }
        else
        { /* block id: 51 */
            uint8_t l_82 = 1UL;
            p_42 = g_8;
            l_83[3][1][1] = l_82;
        }
    }
    l_77[4][8] |= (0UL & (-1L));
    g_7[7][2] = (p_41 <= g_15);
    return l_84;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_66(uint32_t  p_67, int8_t  p_68, int8_t  p_69, const int32_t  p_70, int16_t  p_71)
{ /* block id: 42 */
    int32_t l_76 = 0xD36899A9L;
    l_76 = (safe_mul_func_uint16_t_u_u(0x23EDL, 0xC6E3L));
    return p_70;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_7[i][j], "g_7[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 49
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 25
breakdown:
   depth: 1, occurrence: 68
   depth: 2, occurrence: 18
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
   depth: 5, occurrence: 5
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 14, occurrence: 1
   depth: 25, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 105
XXX times a non-volatile is write: 29
XXX times a volatile is read: 17
XXX    times read thru a pointer: 0
XXX times a volatile is write: 16
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 56
XXX percentage of non-volatile access: 80.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 66
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 17
   depth: 2, occurrence: 29

XXX percentage a fresh-made variable is used: 30.4
XXX percentage an existing variable is used: 69.6
********************* end of statistics **********************/

