/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5773458829563686757
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static int32_t g_3[7] = {0x6847DFA8L,0x6847DFA8L,0x6847DFA8L,0x6847DFA8L,0x6847DFA8L,0x6847DFA8L,0x6847DFA8L};
static uint8_t g_21 = 0xA8L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static const int32_t  func_13(int8_t  p_14);
static const int32_t  func_24(int8_t  p_25, int32_t  p_26, int8_t  p_27, int32_t  p_28);
static int32_t  func_36(uint64_t  p_37);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_21 g_2
 * writes: g_3 g_2 g_21
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_8 = 0x6DA5L;
    int32_t l_9 = 0xBF90EDCAL;
    int32_t l_20 = 0x512A30A4L;
    int8_t l_35 = 0xFDL;
    for (g_3[6] = (-7); (g_3[6] < (-3)); g_3[6] = safe_add_func_uint16_t_u_u(g_3[6], 7))
    { /* block id: 3 */
        l_9 = (safe_div_func_uint64_t_u_u(l_8, 18446744073709551615UL));
        if (g_3[6])
        { /* block id: 5 */
            int32_t l_10 = 1L;
            l_10 &= 0x5C9E53E5L;
            g_2 = (safe_div_func_uint64_t_u_u(g_3[6], 0xB72B21A35CA42045LL));
            return g_3[6];
        }
        else
        { /* block id: 9 */
            int8_t l_15 = 0x7CL;
            g_2 = func_13(l_15);
            g_21++;
            g_2 = (0xEF90L || 0xBC0DL);
            return g_3[6];
        }
    }
    l_9 &= func_24((safe_sub_func_uint16_t_u_u((((safe_sub_func_uint64_t_u_u(((safe_sub_func_uint16_t_u_u(func_13(g_21), l_20)) , l_35), l_20)) < g_3[5]) == 0x4491L), 4UL)), g_21, g_3[6], g_2);
    return g_3[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static const int32_t  func_13(int8_t  p_14)
{ /* block id: 10 */
    uint32_t l_16 = 4294967295UL;
    int32_t l_19 = (-8L);
    ++l_16;
    l_19 &= g_3[6];
    return g_3[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_2
 */
static const int32_t  func_24(int8_t  p_25, int32_t  p_26, int8_t  p_27, int32_t  p_28)
{ /* block id: 20 */
    uint64_t l_38 = 0UL;
    g_2 = func_36(l_38);
    return g_3[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int32_t  func_36(uint64_t  p_37)
{ /* block id: 21 */
    int64_t l_41 = 0x17854C3EBE1552B9LL;
    l_41 &= ((safe_mod_func_uint32_t_u_u((p_37 != 0x02L), p_37)) || g_3[6]);
    return p_37;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 6
   depth: 4, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 8
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 22
XXX percentage of non-volatile access: 86.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 19
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 2
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 28.9
XXX percentage an existing variable is used: 71.1
********************* end of statistics **********************/

