/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14726349968113817697
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile int32_t g_2 = 0xDF251D69L;/* VOLATILE GLOBAL g_2 */
static uint16_t g_5 = 8UL;
static uint32_t g_13[1][5] = {{4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL}};
static uint32_t g_21 = 0x54981C58L;
static volatile uint8_t g_30[1][1][3] = {{{3UL,3UL,3UL}}};
static uint64_t g_44 = 18446744073709551615UL;
static uint32_t g_48 = 6UL;
static uint32_t g_49 = 4294967287UL;
static uint64_t g_67 = 18446744073709551613UL;
static int8_t g_70 = 1L;
static uint8_t g_73 = 0x12L;
static uint32_t g_74[7] = {0xC0C90B22L,0UL,0UL,0xC0C90B22L,0UL,0UL,0xC0C90B22L};
static uint8_t g_77 = 1UL;
static int16_t g_85 = 0xDE17L;
static uint32_t g_89 = 4294967287UL;
static volatile uint32_t g_94 = 0x7109BDD5L;/* VOLATILE GLOBAL g_94 */
static volatile int16_t g_108 = 0L;/* VOLATILE GLOBAL g_108 */
static volatile uint64_t g_109[10][1] = {{18446744073709551613UL},{0x0300625CAFD932BCLL},{18446744073709551613UL},{0x0300625CAFD932BCLL},{18446744073709551613UL},{0x0300625CAFD932BCLL},{18446744073709551613UL},{0x0300625CAFD932BCLL},{18446744073709551613UL},{0x0300625CAFD932BCLL}};
static volatile uint16_t g_113[2][10][9] = {{{0x9FC9L,1UL,0x8625L,0x956DL,0xA159L,0x714EL,65535UL,0UL,65535UL},{0xD4A0L,0UL,0xF66FL,0xA159L,0x75DFL,65535UL,0x5038L,0x0644L,0x3C07L},{2UL,0x77C7L,0xFE22L,0xFE22L,65535UL,0xFF19L,0xD4A0L,0x7067L,0UL},{0xBE40L,0UL,65535UL,0x1EF1L,0xFEA2L,0xA159L,0xD4A0L,1UL,65535UL},{0x7597L,8UL,0x5038L,65535UL,0UL,0x1603L,0xFE22L,65535UL,65535UL},{0x7067L,65535UL,0xFEA2L,0x607FL,0x81D6L,0x81D6L,0x607FL,0xFEA2L,65535UL},{0x7F35L,0xFF19L,0x81D6L,8UL,65535UL,0x75DFL,0xABA3L,65535UL,0x1603L},{0xFE22L,0xE5A6L,0x691EL,0UL,0x429FL,0UL,0UL,0UL,1UL},{9UL,0xFF19L,0UL,0xEF9BL,0x0D0DL,0x5038L,65535UL,65528UL,0UL},{65535UL,65535UL,65535UL,0x83FDL,8UL,0x607FL,0xECFDL,65535UL,65535UL}},{{0x81D6L,8UL,8UL,0x9FC9L,0UL,0xE5A6L,65530UL,65535UL,0xFF19L},{0x1EF1L,0UL,9UL,0xF66FL,65535UL,0xE5A6L,65535UL,0x956DL,65535UL},{1UL,0x9FC9L,0xABA3L,0x7067L,0x28BFL,0x607FL,0x7F35L,0xE5A6L,0x0644L},{8UL,0x8B10L,0x5B4FL,0x5038L,0x75DFL,0x5038L,0x5B4FL,0x8B10L,8UL},{0x5038L,65535UL,0xF66FL,0x429FL,65535UL,0UL,1UL,0xC284L,0UL},{65535UL,0xF66FL,0xEF9BL,65535UL,0x607FL,0x75DFL,65535UL,1UL,65535UL},{0x5038L,65535UL,1UL,65535UL,0xD4A0L,0x81D6L,0x8B10L,1UL,0x5B4FL},{8UL,0x0D0DL,0x1EF1L,0xA159L,0UL,0x1603L,0xF66FL,0UL,0xEF9BL},{1UL,1UL,0UL,0xECFDL,0x8625L,0xA159L,0x637DL,0x77C7L,0x7F35L},{0x1EF1L,0x607FL,65535UL,0x3C07L,0x8625L,0xFF19L,0x7597L,65535UL,0xABA3L}}};
static volatile uint16_t g_117[10] = {2UL,0x10C3L,2UL,0x10C3L,2UL,0x10C3L,2UL,0x10C3L,2UL,0x10C3L};
static int8_t g_123 = 0xF6L;
static volatile uint32_t g_140 = 0x459814C7L;/* VOLATILE GLOBAL g_140 */
static uint16_t g_155 = 65535UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_6(uint64_t  p_7);
static int32_t  func_8(int64_t  p_9, int32_t  p_10, uint64_t  p_11);
static int64_t  func_50(uint8_t  p_51, uint16_t  p_52, int8_t  p_53);
static int32_t  func_78(const int64_t  p_79, uint8_t  p_80, int32_t  p_81, uint64_t  p_82);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_21 g_13 g_48 g_49 g_67 g_74 g_77 g_44 g_30 g_85 g_94 g_109 g_113 g_140 g_155 g_117
 * writes: g_5 g_13 g_21 g_30 g_44 g_49 g_67 g_70 g_73 g_74 g_77 g_85 g_89 g_94 g_109 g_113 g_117 g_123 g_140 g_155
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_3[8] = {0x6CL,0x82L,0x6CL,0x82L,0x6CL,0x82L,0x6CL,0x82L};
    uint8_t l_4 = 255UL;
    uint32_t l_83 = 0UL;
    const int8_t l_122 = 0x22L;
    int32_t l_152[4][4] = {{0x28D446D2L,3L,0x28D446D2L,3L},{0x28D446D2L,3L,0x28D446D2L,3L},{0x28D446D2L,3L,0x28D446D2L,3L},{0x28D446D2L,3L,0x28D446D2L,3L}};
    uint32_t l_157 = 1UL;
    int i, j;
    g_5 |= ((g_2 ^ l_3[4]) != l_4);
    g_77 ^= func_6(g_2);
lbl_156:
    if (func_78(((l_3[4] , l_4) , 0x0CFC2012663943E1LL), l_4, l_83, l_3[4]))
    { /* block id: 71 */
        const uint64_t l_138 = 0xCA8B6AEB2B1B5CBCLL;
        uint32_t l_139 = 0x42DAAAAFL;
        g_123 = l_122;
        l_139 = (safe_add_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((l_83 , 0xD21247B8CF327FF7LL) , l_4), l_138)), 65528UL)), l_138)), 0xA5L)) , 255UL), g_113[1][3][4])), l_3[4])), 0x4449FB5AL));
        g_140--;
    }
    else
    { /* block id: 75 */
        uint16_t l_151[4][2];
        int i, j;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 2; j++)
                l_151[i][j] = 1UL;
        }
        l_152[3][2] = (safe_div_func_uint16_t_u_u((((((safe_sub_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u(l_151[2][0], 0x61D6DE73C7943488LL)), l_4)) <= l_151[1][0]), g_109[2][0])) <= l_151[2][0]) < l_122) < l_4) == l_151[3][1]), g_77));
    }
    if ((4294967290UL <= 0xF8719566L))
    { /* block id: 78 */
        g_155 |= (safe_mod_func_uint64_t_u_u(l_152[2][2], 0x5B22E30894340C13LL));
    }
    else
    { /* block id: 80 */
        if (l_83)
            goto lbl_156;
        l_157 = 0L;
    }
    return g_117[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_21 g_13 g_48 g_49 g_67 g_74
 * writes: g_13 g_21 g_30 g_44 g_49 g_67 g_70 g_73 g_74
 */
static int32_t  func_6(uint64_t  p_7)
{ /* block id: 2 */
    int32_t l_12 = 0x28A062B0L;
    int32_t l_27 = 0L;
    int32_t l_37 = 0L;
    uint16_t l_42 = 0x2547L;
    int32_t l_43 = 0x69719EFCL;
    if (func_8((l_12 , g_5), p_7, g_5))
    { /* block id: 8 */
        uint32_t l_26 = 0x3D2AE456L;
        int32_t l_31 = 0L;
        l_27 = (safe_lshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(l_26, 1)) == 0x38L), g_13[0][1]));
        for (l_12 = 0; (l_12 == 11); l_12++)
        { /* block id: 12 */
            return g_13[0][1];
        }
        g_30[0][0][1] = 0x9DFEEE83L;
        l_31 ^= (253UL <= p_7);
    }
    else
    { /* block id: 17 */
        int16_t l_36[3];
        int i;
        for (i = 0; i < 3; i++)
            l_36[i] = 0x156BL;
        l_37 ^= (safe_mod_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u(l_27, p_7)) > l_36[2]), g_5));
        g_44 = func_8(func_8(((safe_mod_func_uint64_t_u_u(((safe_lshift_func_uint8_t_u_u(g_13[0][1], 4)) < g_2), l_37)) == l_36[2]), l_42, g_13[0][1]), l_43, l_36[1]);
    }
    for (l_42 = 17; (l_42 > 13); --l_42)
    { /* block id: 23 */
        int8_t l_47 = (-10L);
        int32_t l_69 = (-10L);
        if ((l_47 , g_48))
        { /* block id: 24 */
            g_49 |= l_37;
        }
        else
        { /* block id: 26 */
            uint32_t l_56 = 0x295D0C5FL;
            l_69 = (((((func_8(func_50((safe_sub_func_uint64_t_u_u(l_56, p_7)), l_47, p_7), p_7, l_56) > g_5) <= l_12) != p_7) , 4294967293UL) == 0x4C19FD8DL);
            g_70 = g_13[0][3];
            if (p_7)
                break;
            g_73 = (safe_sub_func_uint16_t_u_u(0x02D5L, p_7));
        }
        ++g_74[0];
    }
    return l_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_21 g_13
 * writes: g_13 g_21
 */
static int32_t  func_8(int64_t  p_9, int32_t  p_10, uint64_t  p_11)
{ /* block id: 3 */
    int16_t l_15 = 0xCBE9L;
    int32_t l_16 = 1L;
    g_13[0][1] = (((g_2 == g_5) , g_5) < p_9);
    l_16 = (+(((l_15 > g_5) && g_2) >= 1UL));
    g_21 &= (safe_mul_func_uint16_t_u_u(((safe_mod_func_uint32_t_u_u(4294967295UL, 0xE4ED383DL)) && 65535UL), p_9));
    return g_13[0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_67
 * writes: g_67
 */
static int64_t  func_50(uint8_t  p_51, uint16_t  p_52, int8_t  p_53)
{ /* block id: 27 */
    uint8_t l_66 = 255UL;
    int16_t l_68 = (-10L);
    g_67 ^= (safe_sub_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u((!(0x7D7E7D1C2B13F3B7LL == l_66)), l_66)), p_52)), g_13[0][1])), 0x9B64L));
    return l_68;
}


/* ------------------------------------------ */
/* 
 * reads : g_44 g_74 g_30 g_85 g_94 g_67 g_109 g_21 g_113 g_13
 * writes: g_44 g_85 g_89 g_94 g_109 g_21 g_113 g_117
 */
static int32_t  func_78(const int64_t  p_79, uint8_t  p_80, int32_t  p_81, uint64_t  p_82)
{ /* block id: 39 */
    int32_t l_91 = 0x7832F570L;
    int32_t l_97 = 0xD35AB2A6L;
    uint16_t l_107 = 65535UL;
    int32_t l_112 = 0L;
    for (g_44 = 1; (g_44 <= 6); g_44 += 1)
    { /* block id: 42 */
        int8_t l_84 = 0L;
        int32_t l_88[8][4] = {{(-2L),0xA682D83EL,0xA682D83EL,(-2L)},{0xA682D83EL,(-2L),0xA682D83EL,0xA682D83EL},{(-2L),(-2L),0x34C6454CL,(-2L)},{(-2L),0xA682D83EL,0xA682D83EL,(-2L)},{0xA682D83EL,(-2L),0xA682D83EL,0xA682D83EL},{(-2L),(-2L),0x34C6454CL,(-2L)},{(-2L),0xA682D83EL,0xA682D83EL,(-2L)},{0xA682D83EL,(-2L),0xA682D83EL,0xA682D83EL}};
        uint64_t l_106 = 0x978F22BB1B770899LL;
        int i, j;
        g_85 &= (((g_74[g_44] , l_84) != p_79) , g_30[0][0][1]);
        l_88[1][3] = ((safe_mul_func_uint16_t_u_u(((1UL == g_30[0][0][2]) <= 8UL), 0xB37EL)) ^ g_74[g_44]);
        if (((0x7A535ACB962FAD32LL != p_79) >= 0x301F6F3BL))
        { /* block id: 45 */
            int8_t l_90 = (-5L);
            int32_t l_92 = (-4L);
            int32_t l_93 = 0xE4DFF3B7L;
            g_89 = l_88[2][0];
            l_90 &= (p_81 < p_80);
            g_94--;
            l_97 = l_88[1][3];
        }
        else
        { /* block id: 50 */
            uint64_t l_98 = 0xD34E1B6EB866B6F1LL;
            --l_98;
            l_107 = (safe_rshift_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u((((+((g_67 , l_106) <= p_79)) , p_80) , p_80), g_74[g_44])) , 1UL), 1));
            g_109[6][0]--;
        }
        for (g_21 = 0; (g_21 <= 0); g_21 += 1)
        { /* block id: 57 */
            int32_t l_116 = 1L;
            int i, j;
            --g_113[0][4][7];
            l_116 = (-1L);
            if (g_13[g_21][(g_21 + 1)])
                break;
        }
        for (l_112 = 0; (l_112 >= 0); l_112 -= 1)
        { /* block id: 64 */
            g_117[4] = 0x309CA0AEL;
            l_88[1][3] |= (safe_rshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(((l_84 >= g_30[0][0][1]) ^ l_91), p_81)), 15));
            l_88[1][3] = 0x35CAECAFL;
        }
    }
    return l_107;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_13[i][j], "g_13[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_21, "g_21", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_30[i][j][k], "g_30[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_74[i], "g_74[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_109[i][j], "g_109[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_113[i][j][k], "g_113[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_117[i], "g_117[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 59
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 61
   depth: 2, occurrence: 12
   depth: 3, occurrence: 2
   depth: 4, occurrence: 6
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 94
XXX times a non-volatile is write: 35
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 38
XXX percentage of non-volatile access: 88.4

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 55
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 20
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 41.5
XXX percentage an existing variable is used: 58.5
********************* end of statistics **********************/

