/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9072405050794471097
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_20 = 0x345FE46C2E7CCC89LL;
static int32_t g_27 = 1L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_6(int16_t  p_7, uint64_t  p_8);
static uint8_t  func_13(uint32_t  p_14, int8_t  p_15, int8_t  p_16, uint32_t  p_17, int16_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_20 g_27
 * writes: g_27
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 1L;
    uint16_t l_3 = 0x19D2L;
    int16_t l_58 = (-1L);
    uint64_t l_62 = 0x9D8E7DFBF73ECB6ALL;
    ++l_3;
    if (func_6((safe_lshift_func_int16_t_s_u(l_2, 7)), l_2))
    { /* block id: 26 */
        l_2 |= 0x5AB883EBL;
    }
    else
    { /* block id: 28 */
        uint16_t l_53 = 0xBC0BL;
        l_53 ^= ((safe_sub_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u(g_20, l_3)), 0UL)) & (-1L));
    }
    l_2 = (safe_lshift_func_int16_t_s_u(((((safe_lshift_func_int16_t_s_s(g_20, g_27)) , l_58) || 6L) == l_2), l_2));
    l_62 = (safe_add_func_uint64_t_u_u((+(l_58 , 0xC007L)), l_58));
    return l_58;
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_27
 * writes: g_27
 */
static int32_t  func_6(int16_t  p_7, uint64_t  p_8)
{ /* block id: 2 */
    uint64_t l_19 = 18446744073709551606UL;
    int16_t l_21 = 0x662DL;
    int32_t l_44[2];
    int i;
    for (i = 0; i < 2; i++)
        l_44[i] = 1L;
    l_44[1] = (safe_sub_func_uint8_t_u_u(func_13((l_19 > g_20), l_21, g_20, l_19, l_21), l_21));
    g_27 = ((safe_add_func_int8_t_s_s(((g_27 || 0L) <= 1UL), l_44[1])) , l_19);
    return l_44[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_27
 * writes: g_27
 */
static uint8_t  func_13(uint32_t  p_14, int8_t  p_15, int8_t  p_16, uint32_t  p_17, int16_t  p_18)
{ /* block id: 3 */
    uint32_t l_24 = 18446744073709551608UL;
    uint32_t l_33 = 18446744073709551614UL;
    uint64_t l_35 = 0x52BF390F3BD791F9LL;
    int32_t l_40 = 8L;
    if ((p_15 > g_20))
    { /* block id: 4 */
lbl_28:
        l_24 = (safe_lshift_func_uint8_t_u_u((g_20 != 1UL), 5));
        for (p_17 = 0; (p_17 != 22); p_17++)
        { /* block id: 8 */
            g_27 &= g_20;
            if (g_20)
                goto lbl_28;
            g_27 &= p_16;
        }
    }
    else
    { /* block id: 13 */
        int8_t l_29 = (-4L);
        uint32_t l_30 = 9UL;
        int32_t l_34 = (-10L);
        l_30--;
        l_34 = ((p_18 , p_18) , l_33);
        l_34 = (((l_24 == l_29) , p_17) , 0xC78EF8A6L);
        ++l_35;
    }
    l_40 = (safe_mod_func_int8_t_s_s(0xE2L, g_27));
    l_40 = ((safe_mod_func_int64_t_s_s(0xEFB659BAAA4F69A7LL, l_35)) > 5L);
    l_40 = (~((((-8L) == 0UL) , g_20) <= 0x4415E40C88307B36LL));
    return l_40;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 27
   depth: 2, occurrence: 3
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 39
XXX times a non-volatile is write: 18
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 24
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 8
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 28.8
XXX percentage an existing variable is used: 71.2
********************* end of statistics **********************/

