/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5511314847150658171
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_15 = 0x2FL;/* VOLATILE GLOBAL g_15 */
static int32_t g_17 = 0x357F451DL;
static uint32_t g_26 = 0x7E3BC4AEL;
static uint32_t g_27 = 4294967290UL;
static int32_t g_35 = 0L;
static uint32_t g_42 = 0x71D0C0B8L;
static int32_t g_47[2] = {(-9L),(-9L)};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int32_t  p_4, int8_t  p_5);
static int32_t  func_8(uint32_t  p_9, int8_t  p_10, int8_t  p_11, int32_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_17 g_27 g_26 g_47
 * writes: g_26 g_27 g_42 g_47
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_16 = 0x459EEDA5L;
    int32_t l_28 = 0x031C36B5L;
    g_47[1] &= func_2((safe_add_func_int32_t_s_s((func_8(((safe_div_func_uint32_t_u_u((18446744073709551611UL <= 0x5E4B7834D8A94B2ALL), g_15)) ^ l_16), g_17, g_17, l_16) , (-1L)), g_17)), l_28, l_16);
    return g_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_15 g_26
 * writes: g_27 g_42
 */
static int32_t  func_2(int32_t  p_3, int32_t  p_4, int8_t  p_5)
{ /* block id: 5 */
    uint8_t l_29 = 0x41L;
    int32_t l_46 = 0x06DFE535L;
    ++l_29;
    if ((safe_mul_func_int16_t_s_s(g_27, 0x3BF8L)))
    { /* block id: 7 */
        uint16_t l_34 = 5UL;
        l_34 = (-1L);
    }
    else
    { /* block id: 9 */
        uint32_t l_36 = 0UL;
        ++l_36;
    }
    for (g_27 = 0; (g_27 < 50); g_27 = safe_add_func_int16_t_s_s(g_27, 7))
    { /* block id: 14 */
        uint64_t l_43 = 0x32F82966B9117A54LL;
        g_42 = (!g_15);
        if (g_26)
            break;
        return l_43;
    }
    l_46 = (((safe_add_func_int64_t_s_s((((g_27 && l_29) ^ p_4) , 0x3D4FCE88636EEBCBLL), p_4)) ^ p_3) <= g_15);
    return l_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_17
 * writes: g_26 g_27
 */
static int32_t  func_8(uint32_t  p_9, int8_t  p_10, int8_t  p_11, int32_t  p_12)
{ /* block id: 1 */
    g_26 = (safe_div_func_uint16_t_u_u(((((safe_lshift_func_int8_t_s_s((safe_div_func_int32_t_s_s((safe_sub_func_int16_t_s_s((-5L), (-1L))), g_17)), 7)) && g_17) , p_11) > p_11), 0x8C10L));
    g_27 = (((-2L) != 0UL) == 0xEC46BC22L);
    return g_17;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_47[i], "g_47[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 9
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 14
XXX percentage of non-volatile access: 91.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 41.2
XXX percentage an existing variable is used: 58.8
********************* end of statistics **********************/

