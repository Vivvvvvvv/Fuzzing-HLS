/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7348582248972230815
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0xD7D490C4L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int8_t  func_4(int32_t  p_5, uint32_t  p_6, int32_t  p_7);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_3
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2[1];
    int32_t l_22 = 0L;
    int i;
    for (i = 0; i < 1; i++)
        l_2[i] = 18446744073709551615UL;
    for (g_3 = 0; g_3 < 1; g_3 += 1)
    {
        l_2[g_3] = 0xE5CCC90AL;
    }
    g_3 = l_2[0];
    l_22 = (func_4(g_3, g_3, g_3) , (-1L));
    return l_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_3
 */
static int8_t  func_4(int32_t  p_5, uint32_t  p_6, int32_t  p_7)
{ /* block id: 3 */
    uint32_t l_8 = 4294967294UL;
    int32_t l_21[7][8][4] = {{{0xE7550730L,(-1L),1L,1L},{(-2L),(-2L),0xE7550730L,1L},{(-10L),(-1L),(-10L),0xE7550730L},{(-10L),0xE7550730L,0xE7550730L,(-10L)},{(-2L),0xE7550730L,1L,0xE7550730L},{0xE7550730L,(-1L),1L,1L},{(-2L),(-2L),0xE7550730L,1L},{(-10L),(-1L),(-10L),0xE7550730L}},{{(-10L),0xE7550730L,0xE7550730L,(-10L)},{(-2L),0xE7550730L,1L,0xE7550730L},{0xE7550730L,(-1L),1L,1L},{(-2L),(-2L),(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)}},{{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L}},{{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)}},{{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)}},{{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)}},{{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)},{0xE7550730L,0xE7550730L,(-10L),(-1L)},{1L,(-2L),1L,(-10L)},{1L,(-10L),(-10L),1L},{0xE7550730L,(-10L),(-1L),(-10L)},{(-10L),(-2L),(-1L),(-1L)}}};
    int i, j, k;
    l_8 &= p_5;
    g_3 = (safe_add_func_uint8_t_u_u((((1UL < g_3) <= p_6) < 0xE1D11023DCDF5EF8LL), g_3));
    l_21[0][2][1] = (safe_mod_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(g_3, g_3)), 7)), 0xBC8B421DD2EB2FC2LL)), l_8)), l_8));
    return p_5;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 10
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 14
XXX times a non-volatile is write: 5
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 8

XXX percentage a fresh-made variable is used: 15
XXX percentage an existing variable is used: 85
********************* end of statistics **********************/

