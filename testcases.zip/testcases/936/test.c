/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8523685717872611542
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_5 = 7L;
static volatile uint32_t g_8 = 0xB37B0480L;/* VOLATILE GLOBAL g_8 */
static int32_t g_66 = (-3L);
static uint64_t g_72 = 1UL;
static int64_t g_73 = 0xE20FE055878DFE85LL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_17(uint32_t  p_18, uint16_t  p_19, uint8_t  p_20);
static int32_t  func_22(uint8_t  p_23);
static uint8_t  func_28(int16_t  p_29, int32_t  p_30, int8_t  p_31, uint32_t  p_32, uint16_t  p_33);
static int32_t  func_35(uint16_t  p_36, int32_t  p_37, uint32_t  p_38);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_8 g_66 g_73
 * writes: g_5 g_8 g_66 g_72 g_73
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_21 = 0L;
    int32_t l_65[8][9][3] = {{{4L,0x6C484D54L,0xF52837B7L},{0x8D42F466L,0x0517E40DL,0x9ED226F8L},{4L,0L,(-7L)},{(-1L),0x2882C653L,0x8D42F466L},{9L,8L,0x8E05992EL},{(-1L),0x3A5B7DFFL,0x3F1199D3L},{4L,0x8D46D8DAL,4L},{0x8D42F466L,(-10L),8L},{4L,0x707ECB51L,(-1L)}},{{(-1L),0x14E4A47BL,1L},{9L,0x6A0F30BDL,(-5L)},{(-1L),1L,8L},{4L,6L,9L},{0x8D42F466L,0xAE7BE98BL,0x6697289FL},{4L,0L,1L},{(-1L),8L,(-1L)},{0x866C5D89L,4L,0xEB8A80AAL},{(-1L),0x3F1199D3L,0x9C93506FL}},{{0x686B7DE7L,0x8E05992EL,1L},{0x4E384C83L,0x8D42F466L,(-1L)},{0x686B7DE7L,(-7L),0xE1A273DDL},{(-1L),0x9ED226F8L,0x4E384C83L},{0x866C5D89L,0xF52837B7L,0x72472F85L},{(-1L),0x727FAAB1L,0L},{0x686B7DE7L,0L,0x686B7DE7L},{0x4E384C83L,(-1L),0x1A75C26FL},{0x686B7DE7L,1L,1L}},{{(-1L),0x6697289FL,(-10L)},{0x866C5D89L,9L,0x1D2A6A8EL},{(-1L),8L,(-1L)},{0x686B7DE7L,(-5L),0x866C5D89L},{0x4E384C83L,1L,0xD44351D5L},{0x686B7DE7L,(-1L),0x50C43CAEL},{(-1L),8L,(-1L)},{0x866C5D89L,4L,0xEB8A80AAL},{(-1L),0x3F1199D3L,0x9C93506FL}},{{0x686B7DE7L,0x8E05992EL,1L},{0x4E384C83L,0x8D42F466L,(-1L)},{0x686B7DE7L,(-7L),0xE1A273DDL},{(-1L),0x9ED226F8L,0x4E384C83L},{0x866C5D89L,0xF52837B7L,0x72472F85L},{(-1L),0x727FAAB1L,0L},{0x686B7DE7L,0L,0x686B7DE7L},{0x4E384C83L,(-1L),0x1A75C26FL},{0x686B7DE7L,1L,1L}},{{(-1L),0x6697289FL,(-10L)},{0x866C5D89L,9L,0x1D2A6A8EL},{(-1L),8L,(-1L)},{0x686B7DE7L,(-5L),0x866C5D89L},{0x4E384C83L,1L,0xD44351D5L},{0x686B7DE7L,(-1L),0x50C43CAEL},{(-1L),8L,(-1L)},{0x866C5D89L,4L,0xEB8A80AAL},{(-1L),0x3F1199D3L,0x9C93506FL}},{{0x686B7DE7L,0x8E05992EL,1L},{0x4E384C83L,0x8D42F466L,(-1L)},{0x686B7DE7L,(-7L),0xE1A273DDL},{(-1L),0x9ED226F8L,0x4E384C83L},{0x866C5D89L,0xF52837B7L,0x72472F85L},{(-1L),0x727FAAB1L,0L},{0x686B7DE7L,0L,0x686B7DE7L},{0x4E384C83L,(-1L),0x1A75C26FL},{0x686B7DE7L,1L,1L}},{{(-1L),0x6697289FL,(-10L)},{0x866C5D89L,9L,0x1D2A6A8EL},{(-1L),8L,(-1L)},{0x686B7DE7L,(-5L),0x866C5D89L},{0x4E384C83L,1L,0xD44351D5L},{0x686B7DE7L,(-1L),0x50C43CAEL},{(-1L),8L,(-1L)},{0x866C5D89L,4L,0xEB8A80AAL},{(-1L),0x3F1199D3L,0x9C93506FL}}};
    int i, j, k;
    g_5 = ((safe_unary_minus_func_int8_t_s((safe_lshift_func_uint16_t_u_u(1UL, 0)))) > (-1L));
    for (g_5 = (-15); (g_5 != 0); ++g_5)
    { /* block id: 4 */
        int8_t l_15 = (-7L);
        g_8++;
        if ((safe_lshift_func_int16_t_s_s((safe_mul_func_int16_t_s_s(g_5, l_15)), g_5)))
        { /* block id: 6 */
            uint16_t l_16[9] = {0xD8D3L,0UL,0xD8D3L,0xD8D3L,0UL,0xD8D3L,0xD8D3L,0UL,0xD8D3L};
            int i;
            l_16[2] = l_15;
            l_65[2][7][1] ^= func_17(l_21, g_5, l_16[2]);
            if (l_16[2])
                continue;
        }
        else
        { /* block id: 47 */
            g_66 &= 0xA6F331A9L;
            g_66 = (safe_mod_func_uint64_t_u_u((((((~0x1CL) != 0x957B0931L) & 3L) >= 0xAD0BC0716CFB31DFLL) , g_8), 18446744073709551615UL));
        }
    }
    for (g_5 = 0; (g_5 <= 2); g_5 += 1)
    { /* block id: 54 */
        int8_t l_74 = 0x7FL;
        int32_t l_75 = 8L;
        uint16_t l_77 = 0x1E93L;
        for (g_66 = 2; (g_66 >= 0); g_66 -= 1)
        { /* block id: 57 */
            g_72 = (((((safe_div_func_int16_t_s_s((0xFC8FL | l_65[4][0][1]), g_5)) <= g_66) == 0x4931B730L) , g_66) <= g_5);
            g_73 = g_66;
        }
        for (l_21 = 0; (l_21 <= 2); l_21 += 1)
        { /* block id: 63 */
            int8_t l_76 = 1L;
            l_77++;
            if (l_65[1][4][0])
                break;
        }
    }
    l_65[2][7][1] = (safe_mul_func_uint8_t_u_u(((g_8 , l_21) , l_65[2][7][1]), g_73));
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_8
 * writes:
 */
static int32_t  func_17(uint32_t  p_18, uint16_t  p_19, uint8_t  p_20)
{ /* block id: 8 */
    uint32_t l_34[4];
    int32_t l_49 = 0x00312349L;
    int i;
    for (i = 0; i < 4; i++)
        l_34[i] = 0x6A0B3493L;
lbl_52:
    l_49 = func_22((safe_mod_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(func_28(l_34[2], g_5, p_18, p_18, l_34[2]), 246UL)), l_34[0])));
lbl_54:
    for (p_18 = 0; (p_18 == 53); p_18++)
    { /* block id: 22 */
        uint64_t l_53 = 2UL;
        if (p_20)
        { /* block id: 23 */
            if (p_18)
                goto lbl_52;
            return g_5;
        }
        else
        { /* block id: 26 */
            l_53 = 9L;
            if (p_20)
                goto lbl_54;
            return g_5;
        }
    }
    if (g_5)
    { /* block id: 32 */
        uint16_t l_55 = 0xDA4AL;
        l_55 = g_5;
    }
    else
    { /* block id: 34 */
        return p_20;
    }
    for (p_20 = (-19); (p_20 < 22); p_20 = safe_add_func_uint32_t_u_u(p_20, 2))
    { /* block id: 39 */
        uint64_t l_60 = 0xE6047311EBC84814LL;
        int32_t l_61 = 5L;
        const int32_t l_64[4][7] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)}};
        int i, j;
        l_61 = ((safe_lshift_func_uint8_t_u_s(251UL, l_60)) || p_18);
        l_61 = (safe_mod_func_int16_t_s_s((l_64[0][4] || 0x23A2CC37069E5F9CLL), 0x002BL));
        l_61 = (-1L);
    }
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_8
 * writes:
 */
static int32_t  func_22(uint8_t  p_23)
{ /* block id: 16 */
    uint16_t l_48 = 0xC387L;
    l_48 |= g_8;
    return l_48;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_5
 * writes:
 */
static uint8_t  func_28(int16_t  p_29, int32_t  p_30, int8_t  p_31, uint32_t  p_32, uint16_t  p_33)
{ /* block id: 9 */
    uint64_t l_39 = 0UL;
    int32_t l_45 = 0x2B8FFD02L;
    l_45 = func_35(g_8, l_39, p_33);
    l_45 &= (safe_mod_func_uint16_t_u_u(p_31, 1UL));
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_5
 * writes:
 */
static int32_t  func_35(uint16_t  p_36, int32_t  p_37, uint32_t  p_38)
{ /* block id: 10 */
    uint16_t l_44 = 65528UL;
    l_44 = (((safe_mul_func_int16_t_s_s(((((((safe_div_func_uint16_t_u_u(((0xD88101AEL <= p_36) < p_38), g_8)) & p_36) | g_5) & g_5) , g_8) || g_8), 0xABA4L)) , 0xDF89L) != g_5);
    return l_44;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 24
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 7
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 53
XXX times a non-volatile is write: 25
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 31
XXX percentage of non-volatile access: 90.7

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 10
   depth: 2, occurrence: 14

XXX percentage a fresh-made variable is used: 31.2
XXX percentage an existing variable is used: 68.8
********************* end of statistics **********************/

