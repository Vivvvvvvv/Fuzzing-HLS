/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13326636835250373775
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_4 = 0xC8L;/* VOLATILE GLOBAL g_4 */
static int32_t g_6 = (-9L);
static int8_t g_19 = (-9L);
static volatile uint32_t g_21 = 0xC7E318B4L;/* VOLATILE GLOBAL g_21 */
static int32_t g_64 = 0x06571F67L;
static int16_t g_68 = 4L;
static uint16_t g_69 = 0x0B49L;
static uint8_t g_81 = 0xB0L;
static uint16_t g_87 = 0x391DL;
static uint32_t g_89 = 0x7C350235L;
static int32_t g_91 = 0x715E5E7DL;
static uint32_t g_92 = 0xE622E340L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint8_t  func_10(uint16_t  p_11, uint32_t  p_12, const uint8_t  p_13, int8_t  p_14);
static int32_t  func_43(uint16_t  p_44, uint64_t  p_45, uint32_t  p_46, int16_t  p_47);
static uint32_t  func_51(int32_t  p_52, uint64_t  p_53, uint64_t  p_54, uint32_t  p_55, uint16_t  p_56);
static int32_t  func_82(uint8_t  p_83, uint64_t  p_84, uint8_t  p_85);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_21 g_19 g_69 g_64 g_81 g_87 g_92 g_68 g_89
 * writes: g_6 g_21 g_64 g_68 g_69 g_81 g_87 g_89 g_92
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_5[4][8] = {{0x8ABCL,(-1L),0x6544L,0x06ECL,0x6544L,(-1L),0x8ABCL,0x09CCL},{(-1L),0x5FA5L,0x2994L,0L,0xD786L,0x06ECL,0x06ECL,0xD786L},{1L,0x8ABCL,0x8ABCL,1L,0xD786L,0xEE87L,0x09CCL,0x06ECL},{(-1L),0xEF2CL,0L,0xD786L,0x6544L,0xD786L,0L,0xEF2CL}};
    int32_t l_7 = 0x06695998L;
    uint64_t l_24 = 0xAD7BA966896E60BELL;
    int16_t l_31[5] = {0x22E7L,0x22E7L,0x22E7L,0x22E7L,0x22E7L};
    int i, j;
    l_7 = (((safe_mul_func_uint8_t_u_u((g_4 > l_5[3][6]), l_5[3][4])) ^ g_6) >= g_6);
    if ((g_6 , l_5[3][6]))
    { /* block id: 2 */
        int64_t l_15 = (-7L);
        int32_t l_18 = 0x11B9C6FEL;
        if (((safe_div_func_uint8_t_u_u(func_10(g_6, l_15, l_15, g_4), 0xFBL)) == 248UL))
        { /* block id: 6 */
            l_18 |= (g_6 != g_4);
        }
        else
        { /* block id: 8 */
            int32_t l_20 = 0L;
            --g_21;
        }
        l_24 = 0xB5A7DD9AL;
        l_18 = ((safe_sub_func_uint16_t_u_u((g_4 && 1UL), g_6)) , l_15);
        l_31[2] = (safe_div_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(4294967295UL, 0x3B947E29L)), g_6));
    }
    else
    { /* block id: 14 */
        uint8_t l_34 = 246UL;
        int32_t l_41 = 0x0D602FF7L;
        uint64_t l_42 = 18446744073709551615UL;
        for (l_7 = 0; (l_7 < 18); l_7 = safe_add_func_uint64_t_u_u(l_7, 7))
        { /* block id: 17 */
            return g_19;
        }
        g_6 &= (l_34 >= l_34);
        g_6 &= (safe_mul_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u(g_19, l_34)), 0xDA1FL));
        for (g_6 = 0; (g_6 <= (-18)); g_6--)
        { /* block id: 24 */
            const uint8_t l_75 = 249UL;
            l_41 = l_34;
            l_42 = g_6;
            l_7 = func_43((safe_sub_func_uint8_t_u_u((+((func_51((!g_19), g_21, g_6, g_19, l_41) && g_64) , g_19)), l_75)), g_19, g_19, l_7);
        }
    }
    g_6 = (-2L);
    return g_68;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_6
 * writes: g_6
 */
static uint8_t  func_10(uint16_t  p_11, uint32_t  p_12, const uint8_t  p_13, int8_t  p_14)
{ /* block id: 3 */
    g_6 = ((safe_div_func_uint16_t_u_u(0UL, g_4)) == g_6);
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_6 g_19 g_69 g_4 g_81 g_87 g_92 g_68 g_89
 * writes: g_64 g_68 g_69 g_81 g_87 g_89 g_92
 */
static int32_t  func_43(uint16_t  p_44, uint64_t  p_45, uint32_t  p_46, int16_t  p_47)
{ /* block id: 46 */
    int64_t l_76 = 0x643983B7C1F666C8LL;
    uint8_t l_77 = 0UL;
    int32_t l_90[4] = {1L,1L,1L,1L};
    uint16_t l_125 = 8UL;
    int i;
    if (func_51(l_76, l_77, l_77, g_64, g_64))
    { /* block id: 47 */
        uint64_t l_80 = 7UL;
        int32_t l_103 = 1L;
        if (((safe_add_func_uint32_t_u_u((((((p_46 , l_80) , 0x97B3892EL) , g_4) || g_64) == 0UL), p_44)) || 4294967295UL))
        { /* block id: 48 */
            uint32_t l_86 = 0x4F437236L;
            g_81 &= p_45;
            g_89 = (func_51(func_82(g_4, g_81, l_86), p_46, g_64, l_86, l_76) && 0UL);
            g_92--;
            l_90[3] = ((safe_mul_func_uint16_t_u_u(p_46, 65535UL)) , (-1L));
        }
        else
        { /* block id: 56 */
            int8_t l_106[9] = {0x05L,0x3AL,0x3AL,0x05L,0x3AL,(-4L),0x3AL,(-4L),(-4L)};
            int i;
            l_103 = (safe_rshift_func_uint16_t_u_u(((safe_sub_func_uint16_t_u_u(((safe_mul_func_uint8_t_u_u((l_90[3] < p_47), 0UL)) > p_47), 0xF8D1L)) , p_44), g_68));
            l_106[0] = (safe_sub_func_uint64_t_u_u(g_64, 0xBD8287126A377049LL));
        }
        l_90[1] = 0x67B55C79L;
        for (g_68 = (-2); (g_68 < 29); g_68++)
        { /* block id: 63 */
            int16_t l_114 = (-1L);
            l_114 = (safe_sub_func_uint32_t_u_u((((!((safe_mod_func_uint64_t_u_u((p_47 >= g_81), p_47)) ^ l_103)) < p_45) , g_69), g_81));
            return l_114;
        }
        l_103 = (((safe_mod_func_uint8_t_u_u(p_46, 247UL)) ^ p_44) , p_46);
    }
    else
    { /* block id: 68 */
        const int32_t l_121 = 3L;
        int32_t l_127 = 0xF7338A2FL;
        for (l_76 = (-22); (l_76 > 29); l_76 = safe_add_func_uint16_t_u_u(l_76, 4))
        { /* block id: 71 */
            return l_90[3];
        }
        for (g_89 = 0; (g_89 == 39); g_89++)
        { /* block id: 76 */
            uint64_t l_122 = 0x132EE097E4B88546LL;
            int32_t l_126 = 0xD0DCC659L;
            l_122 = ((((((l_90[3] >= 0x79L) < l_121) , g_69) && 0xD252A4F93C24CE62LL) == g_89) || 0UL);
            l_126 = (safe_mod_func_uint8_t_u_u(((((0x856DD1CDL == g_6) < 6UL) && l_125) , 0x07L), p_45));
            l_127 = (l_76 > 1UL);
        }
    }
    return g_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_19 g_69
 * writes: g_64 g_68 g_69
 */
static uint32_t  func_51(int32_t  p_52, uint64_t  p_53, uint64_t  p_54, uint32_t  p_55, uint16_t  p_56)
{ /* block id: 27 */
    int32_t l_58[7][6] = {{0L,0L,9L,0L,9L,0L},{0x24270207L,0L,0xAD5889E5L,0x24270207L,9L,9L},{0x72FEE613L,0L,0L,0x72FEE613L,9L,0xAD5889E5L},{0L,0L,9L,0L,9L,0L},{0x24270207L,0L,0xAD5889E5L,0x24270207L,9L,9L},{0x72FEE613L,0L,0L,0x72FEE613L,9L,0xAD5889E5L},{0L,0L,9L,0L,9L,0L}};
    uint16_t l_67 = 0xAB70L;
    int i, j;
lbl_74:
    l_58[6][4] = p_56;
    for (p_52 = (-18); (p_52 == (-1)); p_52 = safe_add_func_uint64_t_u_u(p_52, 5))
    { /* block id: 31 */
        g_64 = ((+(safe_add_func_uint32_t_u_u(((0x861E80F96066EAA9LL || 18446744073709551611UL) ^ g_6), 7UL))) && g_19);
    }
    for (p_55 = 0; (p_55 == 35); p_55 = safe_add_func_uint64_t_u_u(p_55, 8))
    { /* block id: 36 */
        g_68 = ((p_55 ^ p_52) , l_67);
        g_69++;
    }
    for (p_52 = 0; (p_52 > 16); ++p_52)
    { /* block id: 42 */
        if (p_52)
            goto lbl_74;
    }
    return g_69;
}


/* ------------------------------------------ */
/* 
 * reads : g_87
 * writes: g_87
 */
static int32_t  func_82(uint8_t  p_83, uint64_t  p_84, uint8_t  p_85)
{ /* block id: 50 */
    int32_t l_88[8][9][1] = {{{7L},{0xF06E9126L},{(-1L)},{0x817ACDDEL},{(-6L)},{7L},{7L},{(-6L)},{0x817ACDDEL}},{{(-1L)},{0xF06E9126L},{7L},{(-1L)},{(-1L)},{(-1L)},{7L},{0xF06E9126L},{(-1L)}},{{0x817ACDDEL},{(-6L)},{7L},{7L},{(-6L)},{0x817ACDDEL},{(-1L)},{0xF06E9126L},{7L}},{{(-1L)},{(-1L)},{(-1L)},{7L},{0xF06E9126L},{(-1L)},{0x817ACDDEL},{(-6L)},{7L}},{{7L},{(-6L)},{0x817ACDDEL},{(-1L)},{0xF06E9126L},{7L},{(-1L)},{(-1L)},{(-1L)}},{{7L},{0xF06E9126L},{(-1L)},{0x817ACDDEL},{(-6L)},{7L},{7L},{(-6L)},{0x817ACDDEL}},{{(-1L)},{0xF06E9126L},{7L},{(-1L)},{(-1L)},{(-1L)},{7L},{0xF06E9126L},{(-1L)}},{{0x817ACDDEL},{(-6L)},{7L},{7L},{(-6L)},{0x817ACDDEL},{(-1L)},{0xF06E9126L},{7L}}};
    int i, j, k;
    g_87 ^= 0xC6B8A9B0L;
    return l_88[0][2][0];
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_92, "g_92", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 39
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 50
   depth: 2, occurrence: 13
   depth: 3, occurrence: 5
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 4
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 93
XXX times a non-volatile is write: 37
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 57
XXX percentage of non-volatile access: 93.5

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 51
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 18
   depth: 2, occurrence: 18

XXX percentage a fresh-made variable is used: 29.5
XXX percentage an existing variable is used: 70.5
********************* end of statistics **********************/

