/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11007513180714021731
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x571177E8L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[5][2] = {{0x1FEBAEEFL,7L},{(-3L),0x1FEBAEEFL},{0xECCCE1E2L,0xECCCE1E2L},{0xECCCE1E2L,0x1FEBAEEFL},{(-3L),7L}};
static volatile int32_t g_4 = 7L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 1L;/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = 0x363F9E92L;
static int16_t g_13 = 2L;
static int32_t g_59 = 0xDD1EB108L;
static int32_t g_60 = 7L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_17(uint16_t  p_18, uint32_t  p_19, int64_t  p_20);
static uint64_t  func_23(int16_t  p_24, const int64_t  p_25, int16_t  p_26, uint16_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_2 g_3 g_13 g_5 g_4 g_59 g_60
 * writes: g_6 g_13 g_2 g_4 g_3 g_60
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_43 = (-3L);
    uint32_t l_58 = 0xC4E24635L;
    int32_t l_61 = 0x3B0BAB1DL;
    for (g_6 = 0; (g_6 > (-16)); --g_6)
    { /* block id: 3 */
        const int16_t l_11[7][7] = {{0x468AL,(-3L),0x468AL,1L,0L,0x96C7L,0x41A6L},{0x21E9L,1L,1L,(-3L),0L,0x0837L,0xA969L},{(-3L),1L,1L,0x21E9L,0x7C69L,0x96C7L,0x96C7L},{1L,0x468AL,(-3L),0x468AL,1L,0L,0x96C7L},{(-9L),0x6EE4L,1L,0x4D63L,0x96C7L,1L,0xA969L},{1L,0x0837L,0x96C7L,0x9A2BL,0x41A6L,1L,0xA969L},{1L,(-3L),0xB2C5L,0xA969L,0xB2C5L,(-3L),1L}};
        int32_t l_12 = 0x40EB4495L;
        int32_t l_16[1];
        int i, j;
        for (i = 0; i < 1; i++)
            l_16[i] = 0x9CA3EAA3L;
        l_12 |= (safe_sub_func_int8_t_s_s(g_2, l_11[2][3]));
        for (l_12 = 1; (l_12 >= 0); l_12 -= 1)
        { /* block id: 7 */
            int i, j;
            g_13 ^= g_3[(l_12 + 2)][l_12];
            g_2 = (safe_sub_func_int64_t_s_s(((g_6 || 255UL) , 0x3388A0193208AF06LL), 0x7A7BC6C8951BB35BLL));
            l_16[0] = 0L;
            return g_6;
        }
        g_4 = func_17(l_11[2][3], l_16[0], g_3[4][1]);
        for (l_12 = (-20); (l_12 <= 23); l_12++)
        { /* block id: 28 */
            uint32_t l_44 = 0xF4EB9534L;
            l_44++;
            g_3[2][0] = (((func_17((l_16[0] || 0x77L), g_4, l_44) , g_3[4][1]) , 0x19L) <= l_12);
            g_60 ^= (((safe_mul_func_int8_t_s_s((((safe_mul_func_uint16_t_u_u(((safe_mod_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u((safe_unary_minus_func_uint16_t_u(l_43)), 0x35L)) < g_13), l_58)), l_12)) < g_5), g_6)) , l_16[0]) , 2L), g_59)) < (-1L)) && l_43);
            l_61 = ((((-7L) >= 4UL) && 0xC0F44DC8L) ^ g_60);
        }
    }
    return g_3[0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_3 g_6 g_2 g_5
 * writes: g_2
 */
static int32_t  func_17(uint16_t  p_18, uint32_t  p_19, int64_t  p_20)
{ /* block id: 13 */
    int32_t l_31[4][7] = {{(-8L),0x718302CCL,0x718302CCL,(-8L),0x718302CCL,0x718302CCL,(-8L)},{0x718302CCL,(-8L),0x718302CCL,0x718302CCL,(-8L),0x718302CCL,0x718302CCL},{(-8L),(-8L),0x66BD5D51L,(-8L),(-8L),0x66BD5D51L,(-8L)},{(-8L),0x718302CCL,0x718302CCL,(-8L),0x718302CCL,0x718302CCL,(-8L)}};
    int32_t l_40[1][7][10] = {{{0x8B536E21L,0x3D96456CL,(-3L),0x3D96456CL,0x8B536E21L,0x3D96456CL,(-3L),0x3D96456CL,0x8B536E21L,0x3D96456CL},{0x44FFA2B8L,0x3D96456CL,0x44FFA2B8L,0x06852DB5L,0x44FFA2B8L,0x3D96456CL,0x44FFA2B8L,0x06852DB5L,0x44FFA2B8L,0x3D96456CL},{0x8B536E21L,0x06852DB5L,(-3L),0x06852DB5L,0x8B536E21L,0x06852DB5L,(-3L),0x06852DB5L,0x8B536E21L,0x06852DB5L},{0x44FFA2B8L,0x06852DB5L,0x44FFA2B8L,0x3D96456CL,0x44FFA2B8L,0x06852DB5L,0x44FFA2B8L,0x3D96456CL,0x44FFA2B8L,0x06852DB5L},{0x8B536E21L,0x3D96456CL,(-3L),0x3D96456CL,0x8B536E21L,0x3D96456CL,(-3L),0x3D96456CL,0x8B536E21L,0x3D96456CL},{0x44FFA2B8L,0x3D96456CL,0x44FFA2B8L,0x06852DB5L,0x44FFA2B8L,0x3D96456CL,0x44FFA2B8L,0x06852DB5L,0x44FFA2B8L,0x3D96456CL},{0x8B536E21L,0x06852DB5L,(-3L),0x06852DB5L,0x8B536E21L,0x06852DB5L,(-3L),0x06852DB5L,0x8B536E21L,0x06852DB5L}}};
    int i, j, k;
    l_40[0][1][8] &= (((safe_mod_func_uint64_t_u_u(func_23((safe_rshift_func_uint16_t_u_u(((((g_13 <= g_3[3][0]) >= 0xB656L) , p_19) != g_6), 14)), g_13, p_18, l_31[2][4], g_13), p_19)) , p_19) || g_3[1][1]);
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_2
 * writes: g_2
 */
static uint64_t  func_23(int16_t  p_24, const int64_t  p_25, int16_t  p_26, uint16_t  p_27, uint32_t  p_28)
{ /* block id: 14 */
    uint32_t l_32 = 0UL;
    l_32 = (-6L);
    for (p_28 = (-27); (p_28 > 10); ++p_28)
    { /* block id: 18 */
        int16_t l_39 = 0L;
        l_39 ^= ((safe_mul_func_int16_t_s_s((((safe_div_func_int8_t_s_s(g_6, l_32)) <= 0xB57606ABL) < l_32), 0xD338L)) <= 0x4C99L);
        g_2 ^= g_6;
    }
    return p_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 5
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 35
XXX times a non-volatile is write: 13
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 30
XXX percentage of non-volatile access: 77.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 6
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 25.5
XXX percentage an existing variable is used: 74.5
********************* end of statistics **********************/

