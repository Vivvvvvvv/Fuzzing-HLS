/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15512875842030729230
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_4[9][3] = {{0L,(-9L),8L},{1L,0xFB6318D5816210B9LL,1L},{0x9FB023ED15DE05DALL,0L,8L},{(-1L),(-1L),0x5A60D00585B7F37CLL},{0x4CCB63E8E1B88146LL,0L,0L},{0x5A60D00585B7F37CLL,0xFB6318D5816210B9LL,0xDEAD9BACC5D9B4E9LL},{0x4CCB63E8E1B88146LL,(-9L),0x4CCB63E8E1B88146LL},{(-1L),0x5A60D00585B7F37CLL,0xDEAD9BACC5D9B4E9LL},{0x9FB023ED15DE05DALL,0x9FB023ED15DE05DALL,0L}};
static int32_t g_7[4] = {(-1L),(-1L),(-1L),(-1L)};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint16_t  func_13(int64_t  p_14, int64_t  p_15, uint32_t  p_16);
static int32_t  func_23(uint64_t  p_24, int8_t  p_25, const int16_t  p_26, const uint64_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_7
 * writes: g_7
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5 = 0L;
    int32_t l_6[10][10] = {{0x609FA85FL,7L,0x7E294B58L,7L,0x609FA85FL,0xFE24307AL,1L,0xB5EA28C7L,1L,0x15FB26C4L},{0xFFAA2324L,0L,0L,0L,1L,0L,0x81630907L,9L,0x0E5E5349L,0L},{0x15FB26C4L,0xB5EA28C7L,0L,(-7L),1L,0x486B6FEBL,0L,0x2DB756FDL,1L,0x0E5E5349L},{1L,0x1920B245L,0L,0x7E294B58L,1L,0L,0L,0x29EF4A04L,0x29EF4A04L,0L},{0x7E294B58L,0xFFAA2324L,0x43260389L,0x43260389L,0xFFAA2324L,0x7E294B58L,1L,0x5256EE97L,(-7L),1L},{0L,0x81630907L,0xFFAA2324L,1L,(-1L),0xF8ABFF5EL,9L,0xB5EA28C7L,0x609FA85FL,(-9L)},{0L,(-3L),1L,1L,0L,0x7E294B58L,(-9L),0x5B611FB8L,0xE9D60A22L,(-1L)},{0x7E294B58L,(-9L),0x5B611FB8L,0xE9D60A22L,(-1L),0L,0x1920B245L,0L,(-1L),0L},{1L,0x486B6FEBL,0x0E5E5349L,0L,0x0E5E5349L,0x486B6FEBL,1L,0xE9D60A22L,0x23F126C7L,0x1920B245L},{0x15FB26C4L,0x5B611FB8L,0x32B7B88CL,0x81630907L,0xABC24891L,0L,0L,0L,0x1920B245L,0xE9D60A22L}};
    uint8_t l_8 = 0x55L;
    int32_t l_33 = (-9L);
    uint8_t l_35 = 0x00L;
    int i, j;
    l_5 = (safe_div_func_uint32_t_u_u(g_4[1][0], 1UL));
    --l_8;
    for (l_5 = 6; (l_5 >= 3); l_5 -= 1)
    { /* block id: 5 */
        int16_t l_34[6][4] = {{0x3A3CL,1L,0xFA4EL,0x3A3CL},{4L,0x0576L,4L,0xFA4EL},{0x9E62L,0x0576L,0xA871L,0x3A3CL},{0x0576L,1L,1L,0x0576L},{4L,0x3A3CL,1L,0xFA4EL},{0x0576L,0x9E62L,0xA871L,0x9E62L}};
        int i, j;
        l_33 |= ((safe_add_func_uint16_t_u_u(func_13((safe_sub_func_uint64_t_u_u((l_6[4][9] || l_8), 0xE082ADE89B93B3BBLL)), g_4[1][0], g_7[2]), g_4[6][2])) < l_6[9][6]);
        return l_34[2][0];
    }
    ++l_35;
    return l_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_7
 * writes: g_7
 */
static uint16_t  func_13(int64_t  p_14, int64_t  p_15, uint32_t  p_16)
{ /* block id: 6 */
    int64_t l_21 = 0xE197B2C3CC8C9F13LL;
    int32_t l_22 = 0x12DB22C0L;
    int32_t l_32 = 1L;
    l_22 = (safe_mul_func_uint16_t_u_u((l_21 == l_21), g_4[1][0]));
    l_32 &= func_23(l_22, p_15, p_14, p_14, g_7[2]);
    g_7[2] |= l_32;
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes: g_7
 */
static int32_t  func_23(uint64_t  p_24, int8_t  p_25, const int16_t  p_26, const uint64_t  p_27, uint32_t  p_28)
{ /* block id: 8 */
    int64_t l_31 = (-8L);
    g_7[2] = ((safe_lshift_func_uint8_t_u_u(1UL, g_7[2])) > l_31);
    return l_31;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_4[i][j], "g_4[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 21.8
XXX percentage an existing variable is used: 78.2
********************* end of statistics **********************/

