/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6754364859982777473
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_6 = 0x37B1891FL;
static int32_t g_8 = 0xEE327439L;
static uint8_t g_12 = 0x4CL;
static int32_t g_15 = 8L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_12 g_15
 * writes: g_6 g_8 g_12 g_15
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_4 = 0x12L;
    int16_t l_5 = 0L;
    uint64_t l_7 = 0x9AA810D21DFE4B28LL;
    int32_t l_9 = 0x85613717L;
    int64_t l_16 = 0xFAEB382E58099740LL;
    g_6 &= (safe_rshift_func_uint8_t_u_u(l_4, l_5));
    g_8 = l_7;
    l_9 |= g_6;
    if (l_9)
    { /* block id: 4 */
        int64_t l_10 = 0x32AA61FC2DA8AFC1LL;
        int32_t l_11[6];
        int i;
        for (i = 0; i < 6; i++)
            l_11[i] = 0x39F5FA31L;
        if (((l_9 && l_10) ^ 0x9589L))
        { /* block id: 5 */
            return l_11[5];
        }
        else
        { /* block id: 7 */
            l_11[0] &= l_9;
        }
        g_12++;
    }
    else
    { /* block id: 11 */
        g_15 &= (l_7 && 0UL);
    }
    return l_16;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 3
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 11
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 3
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 64.7
XXX percentage an existing variable is used: 35.3
********************* end of statistics **********************/

