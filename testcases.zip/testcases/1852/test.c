/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14394911872910505800
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_19 = 0x1311E2DBL;
static uint16_t g_20 = 65535UL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_2(uint16_t  p_3, uint32_t  p_4);
static int32_t  func_10(int8_t  p_11, uint64_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_19 g_20
 * writes: g_20
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_5[1];
    int i;
    for (i = 0; i < 1; i++)
        l_5[i] = 0xEEE2FDE2BBEF7D65LL;
    g_20 = func_2(l_5[0], l_5[0]);
    return g_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes:
 */
static int32_t  func_2(uint16_t  p_3, uint32_t  p_4)
{ /* block id: 1 */
    uint8_t l_6 = 5UL;
    int32_t l_7[4] = {(-6L),(-6L),(-6L),(-6L)};
    int i;
    l_7[2] = l_6;
    for (p_3 = 12; (p_3 < 38); ++p_3)
    { /* block id: 5 */
        l_7[2] = func_10(p_3, p_3);
    }
    return l_7[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes:
 */
static int32_t  func_10(int8_t  p_11, uint64_t  p_12)
{ /* block id: 6 */
    int16_t l_13[8] = {0xED4AL,0xED4AL,0xED4AL,0xED4AL,0xED4AL,0xED4AL,0xED4AL,0xED4AL};
    int i;
    for (p_11 = 0; (p_11 <= 7); p_11 += 1)
    { /* block id: 9 */
        int32_t l_18 = (-1L);
        int i;
        l_18 = (safe_div_func_int64_t_s_s((safe_lshift_func_uint8_t_u_s(l_13[p_11], l_13[p_11])), l_13[p_11]));
        return l_13[p_11];
    }
    return g_19;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 6
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 3
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 2
   depth: 3, occurrence: 3

XXX total number of pointers: 0

XXX times a non-volatile is read: 14
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

