/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6043108082818447142
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile int32_t g_10 = 0x68819570L;/* VOLATILE GLOBAL g_10 */
static uint64_t g_17[7][1][10] = {{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}},{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}},{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}},{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}},{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}},{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}},{{0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL,0x7104272BA75A592CLL}}};
static int32_t g_20 = 0xB641B44AL;
static int16_t g_46 = 3L;
static int32_t g_67 = (-8L);
static int32_t g_69 = 0x6E0E3F56L;
static volatile int64_t g_71 = 0x72FAF72239D13348LL;/* VOLATILE GLOBAL g_71 */
static int8_t g_72 = 0xF3L;
static volatile uint32_t g_73 = 0x030FACFAL;/* VOLATILE GLOBAL g_73 */
static int8_t g_95[2][10] = {{0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L},{0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L,0x97L}};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int16_t  func_4(int64_t  p_5);
static int32_t  func_23(const int64_t  p_24, int32_t  p_25, int32_t  p_26);
static const int64_t  func_27(uint16_t  p_28, int64_t  p_29, int32_t  p_30, int64_t  p_31, int64_t  p_32);
static const int32_t  func_34(uint16_t  p_35, int64_t  p_36, int32_t  p_37, uint32_t  p_38, int8_t  p_39);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_17 g_20 g_46 g_73 g_72 g_71 g_67 g_95 g_69
 * writes: g_17 g_20 g_46 g_67 g_73 g_69 g_72
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_6 = 0x4914D2EDL;
    int32_t l_113 = 1L;
    int32_t l_124 = 0xB8F5B537L;
    if ((safe_mod_func_int16_t_s_s(func_4((l_6 || 0x5B7CEFA9L)), g_95[1][9])))
    { /* block id: 74 */
lbl_112:
        for (l_6 = 10; (l_6 != 23); ++l_6)
        { /* block id: 77 */
            int64_t l_98 = 0xC2345427DA897626LL;
            l_98 = (0xA397L <= g_71);
        }
    }
    else
    { /* block id: 80 */
        int8_t l_106 = 0x24L;
        for (l_6 = 0; (l_6 <= 60); l_6++)
        { /* block id: 83 */
            int32_t l_105 = (-1L);
            int32_t l_111 = 8L;
            g_20 = (safe_mod_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_s(((l_105 > 0x563CFC51L) == g_69), l_106)) >= g_67), g_17[1][0][6]));
            l_111 = (safe_sub_func_int64_t_s_s(((safe_mul_func_int16_t_s_s(l_105, g_17[1][0][6])) <= 0L), g_72));
            if (g_20)
                goto lbl_112;
        }
        g_69 = (g_95[1][9] ^ 6L);
        l_113 = ((0x96L == g_72) | 18446744073709551615UL);
        for (g_69 = 0; (g_69 > 20); g_69++)
        { /* block id: 92 */
            if (g_67)
                break;
        }
    }
    l_124 |= ((safe_add_func_int8_t_s_s((safe_sub_func_int32_t_s_s((safe_mod_func_uint16_t_u_u((((safe_lshift_func_int8_t_s_s(1L, 0)) , (-5L)) | 0UL), g_69)), l_113)), g_10)) && g_95[1][7]);
    return l_124;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_17 g_20 g_46 g_73 g_72 g_71 g_67
 * writes: g_17 g_20 g_46 g_67 g_73 g_69 g_72
 */
static int16_t  func_4(int64_t  p_5)
{ /* block id: 1 */
    int64_t l_11[7];
    int32_t l_90 = 1L;
    int i;
    for (i = 0; i < 7; i++)
        l_11[i] = (-2L);
    if (((safe_unary_minus_func_uint16_t_u((safe_div_func_int8_t_s_s(p_5, g_10)))) >= l_11[1]))
    { /* block id: 2 */
        int8_t l_16 = (-7L);
        g_17[1][0][6] ^= (safe_rshift_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(l_16, l_16)), 7));
    }
    else
    { /* block id: 4 */
        g_20 = (safe_mod_func_uint8_t_u_u((g_17[1][0][6] >= g_17[1][0][6]), 0xE2L));
        for (g_20 = (-29); (g_20 <= (-24)); g_20 = safe_add_func_uint8_t_u_u(g_20, 1))
        { /* block id: 8 */
            uint32_t l_33 = 7UL;
            g_69 = func_23(func_27(((((((1L != p_5) > 0x5D5EC7E0L) ^ l_33) | 0x948214D2L) <= 0x5C3C3AE50714BA09LL) & 0x64L), g_17[1][0][6], g_10, g_17[5][0][5], g_17[1][0][6]), p_5, l_11[1]);
        }
        if (((g_72 ^ 1UL) >= g_10))
        { /* block id: 50 */
            g_20 &= (p_5 >= 0x4EB44D5381D84798LL);
            return g_71;
        }
        else
        { /* block id: 53 */
            g_20 = ((safe_mod_func_uint64_t_u_u((p_5 || 0x7360B9F0A6C5FA60LL), 0x225D623911DF381BLL)) && 0xF40AC15CL);
            return g_72;
        }
    }
    if (((~((((l_11[1] , 0xD35785F4L) , (-10L)) ^ p_5) || l_11[3])) , (-7L)))
    { /* block id: 58 */
        int32_t l_84[3];
        int i;
        for (i = 0; i < 3; i++)
            l_84[i] = 0xDD3DE950L;
        return l_84[2];
    }
    else
    { /* block id: 60 */
        uint64_t l_85 = 0x97EF0591FCF288C1LL;
        l_85 = p_5;
        if (l_85)
        { /* block id: 62 */
            return g_46;
        }
        else
        { /* block id: 64 */
            l_90 = ((((((safe_sub_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((p_5 ^ p_5), l_85)), 9UL)) & l_85) || 0L) <= g_71) <= 4294967295UL) <= p_5);
        }
        for (g_72 = 0; (g_72 <= 6); g_72 += 1)
        { /* block id: 69 */
            int i;
            g_20 ^= ((safe_mod_func_int32_t_s_s((safe_rshift_func_int16_t_s_s(((3L != l_11[g_72]) ^ 0L), p_5)), 6UL)) , g_67);
        }
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_73
 * writes: g_67 g_73
 */
static int32_t  func_23(const int64_t  p_24, int32_t  p_25, int32_t  p_26)
{ /* block id: 33 */
    int32_t l_66[4];
    int i;
    for (i = 0; i < 4; i++)
        l_66[i] = 0x0B387E8DL;
    for (p_26 = 0; (p_26 >= 3); ++p_26)
    { /* block id: 36 */
        uint32_t l_63 = 0x8D11A6C9L;
        if (l_63)
            break;
    }
    for (p_26 = 0; (p_26 == 24); ++p_26)
    { /* block id: 41 */
        int32_t l_68 = (-9L);
        int32_t l_70 = 0xE09FA00AL;
        g_67 = l_66[0];
        g_73++;
    }
    l_66[2] = (!(safe_mod_func_uint8_t_u_u(p_24, 0x38L)));
    l_66[0] ^= (safe_lshift_func_int16_t_s_s(p_25, 7));
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_10 g_20 g_46
 * writes: g_46
 */
static const int64_t  func_27(uint16_t  p_28, int64_t  p_29, int32_t  p_30, int64_t  p_31, int64_t  p_32)
{ /* block id: 9 */
    int32_t l_40[5][1];
    int32_t l_55 = (-1L);
    int i, j;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
            l_40[i][j] = 2L;
    }
lbl_56:
    l_55 &= func_34(l_40[4][0], g_17[2][0][3], g_10, l_40[4][0], g_17[1][0][6]);
    for (p_31 = 0; (p_31 >= 0); p_31 -= 1)
    { /* block id: 17 */
        uint16_t l_59[1][2];
        const uint16_t l_60 = 0UL;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_59[i][j] = 0UL;
        }
        for (l_55 = 0; (l_55 >= 0); l_55 -= 1)
        { /* block id: 20 */
            l_40[4][0] = (p_28 < l_40[4][0]);
            if (l_55)
                goto lbl_56;
            l_40[4][0] |= (((safe_div_func_int16_t_s_s(p_31, 1L)) || g_46) && l_59[0][1]);
        }
        for (p_32 = 0; (p_32 <= 0); p_32 += 1)
        { /* block id: 27 */
            return l_60;
        }
    }
    l_40[1][0] &= g_17[1][0][9];
    return l_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_20
 * writes: g_46
 */
static const int32_t  func_34(uint16_t  p_35, int64_t  p_36, int32_t  p_37, uint32_t  p_38, int8_t  p_39)
{ /* block id: 10 */
    int32_t l_45 = 1L;
    uint16_t l_53 = 1UL;
    uint16_t l_54 = 0x1688L;
    g_46 = (((safe_rshift_func_uint16_t_u_s(((safe_mod_func_int32_t_s_s(((g_17[1][0][6] >= 1L) & p_36), p_36)) <= l_45), l_45)) , p_39) ^ p_37);
    l_54 = ((safe_sub_func_int16_t_s_s(((safe_div_func_int64_t_s_s(((((safe_mul_func_uint8_t_u_u((247UL < l_45), 0xF8L)) >= 65531UL) , g_17[1][0][3]) & g_20), p_39)) , g_17[5][0][8]), l_53)) >= g_20);
    return g_17[1][0][6];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_17[i][j][k], "g_17[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_95[i][j], "g_95[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 34
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 16
   depth: 3, occurrence: 5
   depth: 4, occurrence: 4
   depth: 6, occurrence: 4
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 92
XXX times a non-volatile is write: 33
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 46
XXX percentage of non-volatile access: 93.3

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 53
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 18
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 28.1
XXX percentage an existing variable is used: 71.9
********************* end of statistics **********************/

