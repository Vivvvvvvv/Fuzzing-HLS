/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11962693544582168368
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S1 {
   uint8_t  f0;
   int16_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_2 = 0x2263126FL;
static volatile uint32_t g_11 = 0UL;/* VOLATILE GLOBAL g_11 */
static uint64_t g_16[10] = {0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL,0x587C7AB89BDD7770LL};
static uint16_t g_22 = 0xB831L;
static uint64_t g_25 = 0x511EC1FCC8AF9534LL;
static struct S1 g_45 = {2UL,0xF6EDL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const int32_t  func_17(int64_t  p_18);
static const uint64_t  func_33(uint64_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_11 g_22 g_25 g_16 g_45
 * writes: g_2 g_11 g_16 g_22 g_25
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_5 = (-4L);
    uint32_t l_8 = 1UL;
    int32_t l_10 = (-10L);
    ++g_2;
    if (g_2)
        goto lbl_9;
lbl_15:
    if ((((l_5 , l_5) <= l_5) && 0x16A205B2L))
    { /* block id: 2 */
lbl_9:
        for (g_2 = 15; (g_2 > 37); g_2 = safe_add_func_int64_t_s_s(g_2, 1))
        { /* block id: 5 */
            if (l_8)
                break;
            if (l_5)
                goto lbl_15;
        }
        --g_11;
    }
    else
    { /* block id: 10 */
        uint16_t l_14 = 0x66B1L;
        return l_14;
    }
    if (l_10)
    { /* block id: 14 */
        g_16[9] = 1L;
    }
    else
    { /* block id: 16 */
        int8_t l_31 = 1L;
        if (func_17(g_2))
        { /* block id: 25 */
            g_25++;
        }
        else
        { /* block id: 27 */
            int8_t l_30 = 0x65L;
            int32_t l_47 = 0x88B1495DL;
            l_30 = (safe_mul_func_int16_t_s_s(0x9628L, g_16[6]));
            l_31 = g_22;
            l_47 &= (~((func_33((l_31 , g_25)) , g_16[9]) > g_45.f1));
        }
        if (l_8)
            goto lbl_15;
        for (g_22 = 0; (g_22 == 54); g_22++)
        { /* block id: 38 */
            int64_t l_52[1];
            int i;
            for (i = 0; i < 1; i++)
                l_52[i] = 0x1DB06D673C042909LL;
            l_10 = l_31;
            if (l_31)
                break;
            l_52[0] = ((safe_div_func_uint16_t_u_u((((((g_45.f1 > g_16[8]) > l_8) && 1UL) || g_22) | 9L), 65526UL)) != 9UL);
            l_10 ^= l_5;
        }
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_22
 * writes: g_2 g_22
 */
static const int32_t  func_17(int64_t  p_18)
{ /* block id: 17 */
    int32_t l_21 = 0xF8E3BF11L;
    for (g_2 = 11; (g_2 != 11); g_2 = safe_add_func_int64_t_s_s(g_2, 7))
    { /* block id: 20 */
        return p_18;
    }
    g_22++;
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_11 g_22
 * writes:
 */
static const uint64_t  func_33(uint64_t  p_34)
{ /* block id: 30 */
    int32_t l_46 = 2L;
    l_46 = (safe_add_func_uint32_t_u_u(((((safe_add_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((((safe_lshift_func_uint8_t_u_u(((g_45 , g_45.f1) < (-5L)), 5)) <= g_11) < 0x4071C19CD890F6DALL), 0L)), g_22)), l_46)) ^ p_34) , 0xF54C3DC4L) , l_46), p_34));
    return l_46;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_16[i], "g_16[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_45.f0, "g_45.f0", print_hash_value);
    transparent_crc(g_45.f1, "g_45.f1", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 31
   depth: 2, occurrence: 5
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 8, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 34
XXX times a non-volatile is write: 14
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 96

XXX forward jumps: 2
XXX backward jumps: 1

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 8
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 34.8
XXX percentage an existing variable is used: 65.2
********************* end of statistics **********************/

