/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3930814869352294448
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_10 = 0x8F576C5165352F76LL;/* VOLATILE GLOBAL g_10 */
static int64_t g_11 = 0x205B2906C902DAFBLL;
static uint32_t g_15 = 0xB17B722BL;
static uint8_t g_29 = 248UL;
static uint32_t g_31 = 9UL;
static uint64_t g_34 = 0x8E548E01AFEC1E18LL;
static uint64_t g_40 = 6UL;
static int8_t g_42 = 0x9DL;
static uint16_t g_44 = 65532UL;
static uint32_t g_49 = 0xDB06D673L;
static uint32_t g_67 = 0x8679DD5AL;
static int32_t g_75[4][10] = {{0L,(-5L),0L,0L,(-5L),0L,(-5L),0L,0L,(-5L)},{0L,(-5L),0L,0L,(-5L),0L,(-5L),0L,0L,(-5L)},{0L,(-5L),0L,0L,(-5L),0L,(-5L),0L,0L,(-5L)},{0L,(-5L),0L,0L,(-5L),0L,(-5L),0L,0L,(-5L)}};
static int16_t g_85[7] = {1L,1L,1L,1L,1L,1L,1L};
static uint8_t g_107 = 251UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_5(uint32_t  p_6, uint8_t  p_7);
static int32_t  func_12(int8_t  p_13);
static uint8_t  func_20(uint8_t  p_21, uint16_t  p_22, uint32_t  p_23, const uint32_t  p_24);
static int32_t  func_50(int16_t  p_51);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_11 g_15 g_29 g_31 g_34 g_40 g_44 g_42 g_75 g_85 g_49
 * writes: g_15 g_29 g_31 g_40 g_44 g_49 g_67 g_75 g_85 g_107
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2[9] = {4294967293UL,4294967293UL,4294967293UL,4294967293UL,4294967293UL,4294967293UL,4294967293UL,4294967293UL,4294967293UL};
    int32_t l_110 = 0x0419DFFBL;
    int i;
    l_2[5]++;
    g_107 = (func_5((safe_rshift_func_uint16_t_u_u((0UL <= g_10), 12)), g_11) && g_85[1]);
    l_110 = (((((safe_rshift_func_uint16_t_u_u(l_2[5], 14)) > g_44) >= 0x7496171667F30D37LL) > l_2[5]) <= l_2[5]);
    return l_2[8];
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_15 g_10 g_29 g_31 g_34 g_40 g_44 g_42 g_75 g_85 g_49
 * writes: g_15 g_29 g_31 g_40 g_44 g_49 g_67 g_75 g_85
 */
static uint16_t  func_5(uint32_t  p_6, uint8_t  p_7)
{ /* block id: 2 */
    int32_t l_16 = 0x8F985589L;
    int32_t l_30 = 0xB4D258D0L;
    l_16 = func_12(g_11);
    l_30 = (+(safe_div_func_uint16_t_u_u((func_20(g_10, l_16, g_11, l_16) == 0x2FL), g_15)));
lbl_41:
    g_31 = p_7;
    if (((3UL < 1UL) , g_31))
    { /* block id: 13 */
        int64_t l_35 = 0x81F6ED734895C4B7LL;
        int32_t l_36 = 0x0D296407L;
        int16_t l_39 = 8L;
        int32_t l_43 = 0xF0A86225L;
        l_35 = ((func_20((safe_div_func_uint16_t_u_u(g_34, g_10)), p_7, g_29, g_15) , 5UL) < 0x4EL);
        l_36 = (p_6 > g_29);
        if (p_7)
        { /* block id: 16 */
            g_40 ^= (((safe_add_func_uint32_t_u_u((((((g_11 != 0x1495DD68L) >= l_35) != l_39) > 0x463AL) || l_30), 4UL)) != p_7) > p_7);
        }
        else
        { /* block id: 18 */
            if (l_30)
                goto lbl_41;
            g_44++;
            g_49 = (((safe_add_func_uint32_t_u_u(1UL, g_15)) , p_6) || 18446744073709551606UL);
        }
    }
    else
    { /* block id: 23 */
        int16_t l_63 = 0xB35EL;
        int8_t l_64 = 0x51L;
        int32_t l_106 = 0L;
        if (func_50((+(safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((((((safe_mul_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(l_16, l_63)), 0x76L)) >= p_6), l_64)) , g_42) && l_63) && 18446744073709551613UL) == p_7), p_7)), l_30)))))
        { /* block id: 46 */
            l_30 &= (safe_sub_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(((((safe_rshift_func_uint16_t_u_u(g_85[0], p_7)) == 5UL) && p_6) , g_49), p_7)), 1UL));
            l_30 |= (safe_add_func_uint32_t_u_u((l_16 == 0x65L), 0x56D1B7A1L));
        }
        else
        { /* block id: 49 */
            int64_t l_102[3][8][4] = {{{1L,0L,1L,(-6L)},{0xE3948B2FD71B997ELL,(-5L),(-2L),0xC33281310918DDDCLL},{(-4L),0x3401CF63C109E68FLL,0xC33281310918DDDCLL,(-5L)},{1L,0x660C9299130DA5F0LL,0xC33281310918DDDCLL,0x0CEA35DC67607BBCLL},{(-4L),1L,(-2L),7L},{0xE3948B2FD71B997ELL,0xB52C7FF4120E7427LL,1L,1L},{1L,1L,0xB52C7FF4120E7427LL,0xE3948B2FD71B997ELL},{7L,(-2L),1L,(-4L)}},{{0x0CEA35DC67607BBCLL,0xC33281310918DDDCLL,0x660C9299130DA5F0LL,1L},{(-5L),0xC33281310918DDDCLL,0x3401CF63C109E68FLL,(-4L)},{0xC33281310918DDDCLL,(-2L),(-5L),0xE3948B2FD71B997ELL},{(-6L),1L,0L,1L},{0x87538C74B559E040LL,0xB52C7FF4120E7427LL,(-4L),7L},{1L,1L,0L,0x0CEA35DC67607BBCLL},{0L,0x660C9299130DA5F0LL,(-7L),(-5L)},{0L,0x3401CF63C109E68FLL,0L,0xC33281310918DDDCLL}},{{1L,(-5L),(-4L),(-6L)},{0x87538C74B559E040LL,0L,0L,0x87538C74B559E040LL},{(-6L),(-4L),(-5L),1L},{0xC33281310918DDDCLL,0L,0x3401CF63C109E68FLL,0L},{(-5L),(-7L),0x660C9299130DA5F0LL,0L},{0x0CEA35DC67607BBCLL,0L,1L,1L},{7L,(-4L),0xB52C7FF4120E7427LL,0x87538C74B559E040LL},{1L,0L,1L,(-6L)}}};
            int i, j, k;
            l_102[0][2][3] = ((safe_add_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u(g_10, g_42)), p_7)) , l_64);
            l_106 &= ((!(safe_rshift_func_uint8_t_u_u(((g_11 , p_7) ^ l_102[1][3][1]), 0))) , p_6);
        }
    }
    return g_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_15
 * writes: g_15
 */
static int32_t  func_12(int8_t  p_13)
{ /* block id: 3 */
    int32_t l_14 = 0xE9934B0BL;
    g_15 &= (p_13 && l_14);
    return g_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_15
 * writes: g_29
 */
static uint8_t  func_20(uint8_t  p_21, uint16_t  p_22, uint32_t  p_23, const uint32_t  p_24)
{ /* block id: 7 */
    uint64_t l_25 = 1UL;
    int16_t l_28 = 1L;
    l_25 = 0x209C3997L;
    g_29 &= (((safe_mod_func_uint16_t_u_u(0xC477L, l_25)) >= l_28) || l_25);
    return g_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_29 g_34 g_31 g_15 g_75
 * writes: g_29 g_67 g_75 g_85
 */
static int32_t  func_50(int16_t  p_51)
{ /* block id: 24 */
    uint16_t l_68 = 0x6B31L;
    int32_t l_88 = 0x685AC0FEL;
    for (g_29 = 0; (g_29 <= 24); g_29 = safe_add_func_uint16_t_u_u(g_29, 5))
    { /* block id: 27 */
        uint64_t l_71 = 8UL;
        g_67 = ((((g_34 < 255UL) < g_29) == 4294967290UL) || 0x2BB7L);
        --l_68;
        if ((g_31 < g_15))
        { /* block id: 30 */
            l_71 = (p_51 != g_15);
        }
        else
        { /* block id: 32 */
            uint8_t l_76 = 1UL;
            g_75[2][1] = ((safe_add_func_uint32_t_u_u((((!(p_51 , g_31)) , 0x87B6L) || 5UL), l_71)) > 1UL);
            l_76 &= 0x30262A88L;
        }
    }
    g_85[0] = (safe_lshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(((safe_div_func_uint32_t_u_u(g_75[2][1], 4294967295UL)) >= 18446744073709551607UL), p_51)), 2)) != 6UL), l_68));
    for (l_68 = 2; (l_68 != 50); l_68 = safe_add_func_uint32_t_u_u(l_68, 2))
    { /* block id: 40 */
        l_88 = p_51;
        l_88 = (!3UL);
    }
    l_88 = 1L;
    return p_51;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_75[i][j], "g_75[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_85[i], "g_85[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_107, "g_107", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 75
XXX times a non-volatile is write: 29
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 37
XXX percentage of non-volatile access: 96.3

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 39
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 9
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 30.6
XXX percentage an existing variable is used: 69.4
********************* end of statistics **********************/

