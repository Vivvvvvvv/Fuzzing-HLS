/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2177630518686777508
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3[9] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static const int32_t g_12[7] = {4L,4L,4L,4L,4L,4L,4L};
static int32_t g_21 = 0L;
static uint64_t g_23 = 0UL;
static uint64_t g_46 = 0x2987C837E05AF849LL;
static int16_t g_53 = 0L;
static int32_t g_71[10] = {0xBEBD5D22L,0L,0x97E54B53L,0L,0xBEBD5D22L,0xBEBD5D22L,0L,0x97E54B53L,0L,0xBEBD5D22L};
static uint32_t g_78[6] = {0xF34F21D6L,0xF34F21D6L,0xF34F21D6L,0xF34F21D6L,0xF34F21D6L,0xF34F21D6L};
static int16_t g_83 = 0xCAAAL;
static uint64_t g_84 = 0xEC3E4F79C1191D71LL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_8(uint32_t  p_9, int16_t  p_10, const int32_t  p_11);
static const uint64_t  func_28(int8_t  p_29, const uint32_t  p_30, uint32_t  p_31, int16_t  p_32, int32_t  p_33);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_12 g_23 g_53 g_46 g_71 g_83
 * writes: g_3 g_23 g_46 g_53 g_71 g_78 g_83 g_84
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = (-3L);
    uint64_t l_4 = 9UL;
    g_3[4] = (l_2 && l_2);
    if (l_2)
        goto lbl_5;
lbl_5:
    l_4 ^= ((l_2 ^ g_3[6]) , 5L);
    g_84 = (safe_lshift_func_uint8_t_u_u((func_8(g_3[6], g_3[3], g_12[3]) >= 1L), g_12[4]));
    return l_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_12 g_23 g_53 g_46 g_71 g_83
 * writes: g_23 g_46 g_53 g_71 g_78 g_83
 */
static int32_t  func_8(uint32_t  p_9, int16_t  p_10, const int32_t  p_11)
{ /* block id: 4 */
    uint8_t l_13 = 0UL;
    int32_t l_14 = (-1L);
    int8_t l_17 = 1L;
    int32_t l_22 = 1L;
    l_14 = (((l_13 > p_10) , l_13) | p_10);
lbl_80:
    if (((g_3[4] && 0x5AF9F7C8B166C193LL) | 8L))
    { /* block id: 6 */
        int8_t l_18 = 0x33L;
        int32_t l_19 = 0xE1EE67B3L;
        int32_t l_20[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int i;
        l_18 = (safe_mul_func_int16_t_s_s((l_17 & 65535UL), g_12[2]));
        if (l_13)
            goto lbl_80;
        g_23++;
        return p_11;
    }
    else
    { /* block id: 10 */
        int8_t l_39 = (-6L);
        uint32_t l_40 = 0x59A7032FL;
        int32_t l_79 = (-1L);
        g_78[0] = (safe_sub_func_uint64_t_u_u(func_28(((safe_add_func_int32_t_s_s((safe_rshift_func_int16_t_s_u((safe_unary_minus_func_int32_t_s(l_39)), 8)), 0xA82BC906L)) & p_9), p_11, l_39, l_40, p_9), l_17));
        l_79 ^= (0xBCA32D9FL & 1L);
        if (g_23)
            goto lbl_80;
    }
    l_14 = (p_11 & g_71[7]);
    g_83 &= ((safe_rshift_func_uint16_t_u_s(1UL, 8)) & 1L);
    return g_83;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_3 g_12 g_53 g_46 g_71
 * writes: g_46 g_23 g_53 g_71
 */
static const uint64_t  func_28(int8_t  p_29, const uint32_t  p_30, uint32_t  p_31, int16_t  p_32, int32_t  p_33)
{ /* block id: 11 */
    int64_t l_45 = 9L;
    int32_t l_54 = (-8L);
    int32_t l_56[6];
    uint16_t l_58 = 0x562EL;
    int8_t l_76[6] = {1L,6L,1L,1L,1L,0x5CL};
    int32_t l_77 = 0L;
    int i;
    for (i = 0; i < 6; i++)
        l_56[i] = 0xA07874D2L;
    g_46 = (safe_add_func_uint8_t_u_u((safe_div_func_int64_t_s_s(0x6593C394A737B78FLL, l_45)), 0x36L));
    for (p_31 = 0; (p_31 <= 8); p_31 += 1)
    { /* block id: 15 */
        int16_t l_49 = 0x18E8L;
        int32_t l_55 = (-10L);
        int32_t l_57[2];
        uint8_t l_63 = 0x86L;
        int i;
        for (i = 0; i < 2; i++)
            l_57[i] = (-4L);
        for (g_23 = 2; (g_23 <= 8); g_23 += 1)
        { /* block id: 18 */
            int32_t l_50 = (-1L);
            int i;
            l_50 = (((safe_rshift_func_uint8_t_u_s(((0x828E972CE3C48971LL ^ g_3[p_31]) , l_49), p_30)) != 0xFA3CE724L) <= 1UL);
            g_53 ^= (safe_mod_func_int8_t_s_s(((g_3[4] & 1L) && g_12[3]), g_12[2]));
            if (p_32)
                continue;
        }
        --l_58;
        if (((((safe_lshift_func_uint16_t_u_u(((g_3[4] ^ l_55) , l_63), 11)) , g_46) || l_56[0]) >= 0xC7BEL))
        { /* block id: 24 */
            if (p_32)
                break;
        }
        else
        { /* block id: 26 */
            uint32_t l_70 = 0UL;
            g_71[0] = (safe_rshift_func_int16_t_s_u((((((safe_mul_func_uint16_t_u_u((((((safe_sub_func_uint8_t_u_u((((g_3[0] , l_54) == 4294967295UL) >= 0x14680EDEL), g_3[4])) | 0x3BL) > l_45) , 0x8196E547EF217EDELL) & l_58), l_54)) ^ g_12[3]) > l_70) , g_23) || p_30), g_46));
            if (l_63)
                break;
        }
        for (p_29 = 0; (p_29 <= 8); p_29 += 1)
        { /* block id: 32 */
            uint8_t l_72[4] = {0x01L,0x01L,0x01L,0x01L};
            int i;
            l_72[0] ^= (p_29 ^ g_71[0]);
        }
    }
    l_77 = ((!(safe_add_func_uint16_t_u_u(l_76[0], g_12[3]))) ^ g_12[5]);
    return g_12[3];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_71[i], "g_71[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_78[i], "g_78[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 35
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 29
   depth: 2, occurrence: 7
   depth: 3, occurrence: 6
   depth: 4, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 62
XXX times a non-volatile is write: 20
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 3
XXX backward jumps: 0

XXX stmts: 32
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 11
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 41.2
XXX percentage an existing variable is used: 58.8
********************* end of statistics **********************/

