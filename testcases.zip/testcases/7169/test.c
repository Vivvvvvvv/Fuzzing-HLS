/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      623338995137106720
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_24 = 1L;
static volatile int8_t g_31 = 0x13L;/* VOLATILE GLOBAL g_31 */
static uint64_t g_33 = 1UL;
static volatile uint8_t g_38 = 0xEAL;/* VOLATILE GLOBAL g_38 */
static int32_t g_44 = 1L;
static int64_t g_57 = 0x1E7FF51885A1EC8FLL;
static uint8_t g_59 = 247UL;
static int64_t g_65 = 0x30B545435D7D231DLL;
static int64_t g_70 = 3L;
static uint32_t g_71 = 0xBEC8B24CL;
static volatile uint16_t g_107 = 0UL;/* VOLATILE GLOBAL g_107 */
static volatile uint16_t g_112 = 0x21C9L;/* VOLATILE GLOBAL g_112 */
static volatile uint16_t g_115 = 0x1DFFL;/* VOLATILE GLOBAL g_115 */
static int32_t g_117 = (-10L);
static volatile int8_t g_120 = 0xA2L;/* VOLATILE GLOBAL g_120 */
static volatile uint32_t g_122 = 0x469BA6CEL;/* VOLATILE GLOBAL g_122 */
static int32_t g_126[7][5][7] = {{{0x34EEA40FL,(-1L),0x86FCAFA2L,(-1L),0x34EEA40FL,0xD4BBA09BL,0xDA4F77C9L},{1L,0xB60A5FB0L,0x86FCAFA2L,0x219839B2L,(-1L),0x41A119B8L,0x81905554L},{0x219839B2L,8L,(-1L),0x41A119B8L,0x41A119B8L,(-1L),8L},{1L,0x219839B2L,0xB60A5FB0L,0xDA4F77C9L,2L,(-1L),0xD4BBA09BL},{0x34EEA40FL,0xC871CFEEL,(-2L),0x86FCAFA2L,0L,0x41A119B8L,0L}},{{0xDA4F77C9L,0L,0L,0xDA4F77C9L,0xD54EFE8FL,0xD4BBA09BL,0x86FCAFA2L},{0xD4BBA09BL,0L,0x34EEA40FL,0x41A119B8L,(-1L),0xB60A5FB0L,0xD4BBA09BL},{0x219839B2L,0xD54EFE8FL,0x86FCAFA2L,0xDA4F77C9L,0x86FCAFA2L,0xD54EFE8FL,0x219839B2L},{0L,0xDA4F77C9L,0xD54EFE8FL,0xD4BBA09BL,0x86FCAFA2L,0x81905554L,(-2L)},{(-1L),0x81905554L,0x34EEA40FL,0x86FCAFA2L,(-1L),(-1L),0x86FCAFA2L}},{{0xD54EFE8FL,8L,0xD54EFE8FL,2L,0xB60A5FB0L,(-1L),0x81905554L},{0xD54EFE8FL,0xD4BBA09BL,0x86FCAFA2L,0x81905554L,(-2L),8L,(-1L)},{(-1L),0L,0xC871CFEEL,0xC871CFEEL,0L,(-1L),1L},{0L,0x86FCAFA2L,(-2L),0xC871CFEEL,0x34EEA40FL,(-1L),0xB60A5FB0L},{0x219839B2L,(-1L),0x41A119B8L,0x81905554L,0xD4BBA09BL,0x81905554L,0x41A119B8L}},{{0x86FCAFA2L,0x86FCAFA2L,8L,2L,0xC871CFEEL,0xD54EFE8FL,0x41A119B8L},{1L,0L,2L,0x86FCAFA2L,0x41A119B8L,0xB60A5FB0L,0xB60A5FB0L},{0xC871CFEEL,0xD4BBA09BL,0x219839B2L,0xD4BBA09BL,0xC871CFEEL,0x86FCAFA2L,1L},{(-1L),8L,0x219839B2L,0xDA4F77C9L,0xD4BBA09BL,0x34EEA40FL,(-1L)},{0xDA4F77C9L,0x81905554L,2L,0x34EEA40FL,0x34EEA40FL,2L,0x81905554L}},{{(-1L),0xDA4F77C9L,8L,1L,0L,2L,0x86FCAFA2L},{0xC871CFEEL,0xD54EFE8FL,0x41A119B8L,0x219839B2L,(-2L),0x34EEA40FL,(-2L)},{1L,(-2L),(-2L),1L,0xB60A5FB0L,0x86FCAFA2L,0x219839B2L},{0x86FCAFA2L,(-2L),0xC871CFEEL,0x34EEA40FL,(-1L),0xB60A5FB0L,0xD4BBA09BL},{0x219839B2L,0xD54EFE8FL,0x86FCAFA2L,0xDA4F77C9L,0x86FCAFA2L,0xD54EFE8FL,0x219839B2L}},{{0L,0xDA4F77C9L,0xD54EFE8FL,0xD4BBA09BL,0x86FCAFA2L,0x81905554L,(-2L)},{(-1L),0x81905554L,0x34EEA40FL,0x86FCAFA2L,(-1L),(-1L),0x86FCAFA2L},{0xD54EFE8FL,8L,0xD54EFE8FL,2L,0xB60A5FB0L,(-1L),0x81905554L},{0xD54EFE8FL,0xD4BBA09BL,0x86FCAFA2L,0x81905554L,(-2L),8L,(-1L)},{(-1L),0L,0xC871CFEEL,0xC871CFEEL,0L,(-1L),1L}},{{0L,0x86FCAFA2L,(-2L),0xC871CFEEL,0x34EEA40FL,(-1L),0xB60A5FB0L},{0x219839B2L,(-1L),0x41A119B8L,0x81905554L,0xD4BBA09BL,0x81905554L,0x41A119B8L},{0x86FCAFA2L,0x86FCAFA2L,8L,2L,0xC871CFEEL,0xD54EFE8FL,0x41A119B8L},{1L,0L,2L,0x86FCAFA2L,0x41A119B8L,0xB60A5FB0L,8L},{0xD54EFE8FL,0x86FCAFA2L,0xDA4F77C9L,0x86FCAFA2L,0xD54EFE8FL,0x219839B2L,(-1L)}}};
static int32_t g_127[6] = {(-3L),0xB4EC1833L,0xB4EC1833L,(-3L),0xB4EC1833L,0xB4EC1833L};
static volatile int32_t g_128 = 0x66B1C03AL;/* VOLATILE GLOBAL g_128 */
static uint32_t g_130 = 0xD4FE02E2L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static uint64_t  func_2(int64_t  p_3, int32_t  p_4, uint32_t  p_5);
static uint64_t  func_10(uint8_t  p_11, uint64_t  p_12, uint64_t  p_13, int32_t  p_14);
static uint8_t  func_15(uint64_t  p_16, uint64_t  p_17, uint8_t  p_18);
static uint16_t  func_94(int32_t  p_95, int32_t  p_96);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_24 g_33 g_38 g_31 g_44 g_71 g_59 g_70 g_65 g_107 g_57 g_112 g_122 g_130
 * writes: g_33 g_38 g_44 g_57 g_59 g_65 g_71 g_107 g_70 g_112 g_115 g_122 g_130 g_24 g_117 g_128
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    const int32_t l_23 = 0x0977A124L;
    int32_t l_41 = 0x30B91EE4L;
    uint32_t l_45 = 0x71B36C93L;
    uint8_t l_135 = 0x35L;
    g_128 = (func_2((safe_lshift_func_uint16_t_u_u(((safe_mod_func_uint64_t_u_u(func_10((((func_15((safe_lshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(65535UL, l_23)), 4)), g_24, l_23) == l_41) && 65535UL) , g_24), l_41, g_24, g_24), g_24)) ^ l_41), 2)), l_45, g_24) != l_41);
    return l_135;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_33 g_44 g_24 g_38 g_71 g_59 g_70 g_65 g_107 g_57 g_112 g_122 g_130
 * writes: g_33 g_57 g_59 g_38 g_44 g_65 g_71 g_107 g_70 g_112 g_115 g_122 g_130 g_24 g_117
 */
static uint64_t  func_2(int64_t  p_3, int32_t  p_4, uint32_t  p_5)
{ /* block id: 10 */
    uint16_t l_48 = 0x8927L;
    int16_t l_60 = 0x65D6L;
    int32_t l_67 = (-1L);
    int32_t l_68 = 0x0D5DD215L;
    int32_t l_69[6][5][6] = {{{0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L,0xC6833686L},{0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L,0x23037D9CL,0xE9347A64L},{0xE9347A64L,0x23037D9CL,0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L},{0xC6833686L,0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L},{0x36C21779L,0x23037D9CL,0xCA181885L,0xCA181885L,0x23037D9CL,0x36C21779L}},{{0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L,0xC6833686L},{0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L,0x23037D9CL,0xE9347A64L},{0xE9347A64L,0x23037D9CL,0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L},{0xC6833686L,0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L},{0x36C21779L,0x23037D9CL,0xCA181885L,0xCA181885L,0x23037D9CL,0x36C21779L}},{{0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L,0xC6833686L},{0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L,0x23037D9CL,0xE9347A64L},{0xE9347A64L,0x23037D9CL,0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L},{0xC6833686L,0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L},{0x36C21779L,0x23037D9CL,0xCA181885L,0xCA181885L,0x23037D9CL,0x36C21779L}},{{0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L,0xC6833686L},{0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L,0x23037D9CL,0xE9347A64L},{0xE9347A64L,0x23037D9CL,0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L},{0xC6833686L,0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L},{0x36C21779L,0x23037D9CL,0xCA181885L,0xCA181885L,0x23037D9CL,0x36C21779L}},{{0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L,0xC6833686L},{0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L,0x23037D9CL,0xE9347A64L},{0xE9347A64L,0x23037D9CL,0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L},{0xC6833686L,0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L},{0x36C21779L,0x23037D9CL,0xCA181885L,0xCA181885L,0x23037D9CL,0x36C21779L}},{{0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L,0xC6833686L},{0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L,0x23037D9CL,0xE9347A64L},{0xE9347A64L,0x23037D9CL,0xE9347A64L,0x36C21779L,0x36C21779L,0xE9347A64L},{0xC6833686L,0xC6833686L,0x36C21779L,0xCA181885L,0x36C21779L,0xC6833686L},{0x36C21779L,0x23037D9CL,0x23037D9CL,0x23037D9CL,0xC6833686L,0xE9347A64L}}};
    int i, j, k;
    l_48 = (safe_mod_func_uint64_t_u_u(g_31, 4UL));
lbl_66:
    for (p_4 = 0; (p_4 <= (-24)); --p_4)
    { /* block id: 14 */
        uint32_t l_61 = 0x5E0ECF58L;
        int32_t l_62 = (-1L);
        for (g_33 = 15; (g_33 >= 34); ++g_33)
        { /* block id: 17 */
            uint8_t l_58 = 253UL;
            g_57 = (safe_add_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(g_44, 0xF205L)), l_48));
            g_59 = l_58;
        }
        l_62 = (func_10(func_15(l_48, l_48, l_48), g_44, l_48, l_60) || l_61);
        if (l_60)
            goto lbl_66;
        g_65 = (safe_lshift_func_uint8_t_u_u(l_48, l_61));
    }
    g_71--;
    if ((safe_add_func_uint64_t_u_u(0xAD942A26B13122E3LL, g_59)))
    { /* block id: 26 */
        uint32_t l_78 = 0xDF81F9D3L;
        int32_t l_80[6] = {0x172C66C3L,0x172C66C3L,0x172C66C3L,0x172C66C3L,0x172C66C3L,0x172C66C3L};
        int i;
        for (p_4 = 3; (p_4 < (-22)); p_4 = safe_sub_func_uint32_t_u_u(p_4, 7))
        { /* block id: 29 */
            uint64_t l_79[2];
            int i;
            for (i = 0; i < 2; i++)
                l_79[i] = 0UL;
            l_78 = (2UL >= p_3);
            l_79[0] = 0xADBE56F6L;
            l_80[4] = 0L;
            l_69[1][1][3] = (safe_rshift_func_uint16_t_u_u(p_5, p_4));
        }
        l_80[4] = (safe_mod_func_uint8_t_u_u(func_10((safe_rshift_func_uint8_t_u_u(p_3, 5)), l_60, p_3, g_70), g_71));
    }
    else
    { /* block id: 36 */
        uint32_t l_91[6][2] = {{0UL,0xEC44CB18L},{0x40CFCE32L,0x40CFCE32L},{0x40CFCE32L,0xEC44CB18L},{0UL,0UL},{0xEC44CB18L,0UL},{0UL,0xEC44CB18L}};
        int32_t l_116 = 0L;
        int32_t l_119 = 0x9B9B769EL;
        int i, j;
        l_67 = (safe_add_func_uint64_t_u_u(g_65, 0x7DCB2139E6D59493LL));
        if ((safe_mod_func_uint32_t_u_u(((g_38 != p_5) < 1UL), l_91[3][1])))
        { /* block id: 38 */
            l_67 = (safe_div_func_uint16_t_u_u(func_94(((safe_rshift_func_uint16_t_u_u((255UL || g_65), 5)) || p_5), l_69[1][1][3]), g_44));
            l_69[1][1][3] = (safe_add_func_uint8_t_u_u(p_5, p_5));
        }
        else
        { /* block id: 51 */
            int64_t l_118 = 1L;
            int16_t l_121[2];
            int32_t l_125 = 0xB85C5578L;
            int32_t l_129 = 0L;
            int i;
            for (i = 0; i < 2; i++)
                l_121[i] = 1L;
            g_115 = g_112;
            g_122--;
            g_130++;
        }
        for (g_24 = (-13); (g_24 > (-23)); --g_24)
        { /* block id: 58 */
            if (g_59)
                break;
        }
        g_117 = g_112;
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_38
 * writes: g_44
 */
static uint64_t  func_10(uint8_t  p_11, uint64_t  p_12, uint64_t  p_13, int32_t  p_14)
{ /* block id: 6 */
    int16_t l_42 = 4L;
    int32_t l_43 = 0x3ED23C5AL;
    l_43 ^= ((l_42 >= g_38) , (-4L));
    g_44 = (l_43 || p_14);
    return l_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_33 g_38
 * writes: g_33 g_38
 */
static uint8_t  func_15(uint64_t  p_16, uint64_t  p_17, uint8_t  p_18)
{ /* block id: 1 */
    int16_t l_29 = 0L;
    int32_t l_30 = 0L;
    int32_t l_32 = (-1L);
    int32_t l_36 = 0xFF5452FAL;
    int32_t l_37 = 0xF3813BF5L;
    l_29 = (safe_mul_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(p_18, p_18)), g_24));
    ++g_33;
    g_38--;
    return l_37;
}


/* ------------------------------------------ */
/* 
 * reads : g_59 g_24 g_107 g_70 g_57
 * writes: g_107 g_70 g_112
 */
static uint16_t  func_94(int32_t  p_95, int32_t  p_96)
{ /* block id: 39 */
    uint32_t l_105 = 0xFB2EF76CL;
    int32_t l_106 = 8L;
    l_106 = (safe_sub_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(((((((safe_lshift_func_uint16_t_u_u(l_105, 15)) && 4294967295UL) == g_59) > g_24) ^ 0x70D6L) , p_95), p_95)), l_105));
    --g_107;
    for (g_70 = 20; (g_70 >= (-23)); g_70 = safe_sub_func_uint16_t_u_u(g_70, 2))
    { /* block id: 44 */
        g_112 = 0xFF1065C7L;
        p_96 = g_57;
    }
    return l_106;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_126[i][j][k], "g_126[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_127[i], "g_127[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 51
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 20
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 13
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 7, occurrence: 2
   depth: 9, occurrence: 2
   depth: 20, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 67
XXX times a non-volatile is write: 27
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 42
XXX percentage of non-volatile access: 89.5

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 42
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 12
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 38.9
XXX percentage an existing variable is used: 61.1
********************* end of statistics **********************/

