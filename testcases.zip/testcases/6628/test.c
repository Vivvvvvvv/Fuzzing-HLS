/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5808793223575418957
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 1L;
static uint64_t g_32 = 0xF23E469209A488D5LL;
static uint32_t g_34 = 0xB8842B4CL;
static int32_t g_39 = (-10L);
static int32_t g_40 = 0x72F25996L;
static int16_t g_47 = 0x7530L;
static volatile int8_t g_48 = (-1L);/* VOLATILE GLOBAL g_48 */
static int8_t g_49 = 0L;
static volatile uint8_t g_50 = 0x62L;/* VOLATILE GLOBAL g_50 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int16_t  func_11(int8_t  p_12, uint16_t  p_13, uint8_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_32 g_34 g_50 g_48
 * writes: g_2 g_32 g_34 g_50
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_19 = 1L;
    int32_t l_35 = 0x23782ECCL;
    uint32_t l_53 = 18446744073709551615UL;
    for (g_2 = (-2); (g_2 < 0); g_2 = safe_add_func_uint8_t_u_u(g_2, 2))
    { /* block id: 3 */
        int16_t l_5 = 0xDA0EL;
        int32_t l_6 = 0xE77DD688L;
        int32_t l_36 = 0x4A219909L;
        int32_t l_37 = (-1L);
        int32_t l_38[2];
        int i;
        for (i = 0; i < 2; i++)
            l_38[i] = (-4L);
        l_6 = l_5;
        for (l_5 = 0; (l_5 > 26); l_5 = safe_add_func_uint8_t_u_u(l_5, 9))
        { /* block id: 7 */
            uint16_t l_33 = 0xA1DDL;
            uint8_t l_41 = 0x30L;
            g_34 = (safe_mod_func_uint8_t_u_u((func_11((safe_lshift_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(l_19, 0xE790L)), g_2)), g_2, g_2) , l_19), l_33));
            l_35 &= g_32;
            l_41--;
        }
        for (g_34 = 0; (g_34 < 38); g_34 = safe_add_func_uint16_t_u_u(g_34, 8))
        { /* block id: 22 */
            int64_t l_46 = 0x81F51B4373C94681LL;
            g_50--;
        }
        l_35 = ((g_50 > g_34) , l_6);
    }
    l_53 = g_34;
    return g_48;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_32
 * writes: g_32
 */
static int16_t  func_11(int8_t  p_12, uint16_t  p_13, uint8_t  p_14)
{ /* block id: 8 */
    uint64_t l_24[4];
    int i;
    for (i = 0; i < 4; i++)
        l_24[i] = 0UL;
    if ((safe_mul_func_uint8_t_u_u((((safe_add_func_uint64_t_u_u(l_24[1], g_2)) , l_24[1]) <= l_24[1]), 1UL)))
    { /* block id: 9 */
        uint32_t l_27 = 0UL;
        l_27 = (((safe_rshift_func_uint8_t_u_u(p_14, p_12)) != 18446744073709551607UL) , g_2);
    }
    else
    { /* block id: 11 */
        int8_t l_30[5][7] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0xD9L,0xE1L,0xD9L,0xE1L,0xD9L,0xE1L,0xD9L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0xD9L,0xE1L,0xD9L,0xE1L,0xD9L,0xE1L,0xD9L},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
        int32_t l_31 = 0xC39C9D94L;
        int i, j;
        l_31 ^= ((safe_rshift_func_uint8_t_u_u(255UL, l_30[3][4])) < l_30[3][6]);
        g_32 |= (-5L);
    }
    return l_24[1];
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 24
XXX times a non-volatile is write: 12
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 92.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 7
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 47.9
XXX percentage an existing variable is used: 52.1
********************* end of statistics **********************/

