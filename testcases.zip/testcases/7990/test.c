/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18178443135362261729
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x824A8C6AL;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 0x06CE125DL;
static int32_t g_71[2][5] = {{0x322AC55BL,0x322AC55BL,0x322AC55BL,0x322AC55BL,0x322AC55BL},{0x322AC55BL,0x322AC55BL,0x322AC55BL,0x322AC55BL,0x322AC55BL}};
static uint64_t g_73 = 0UL;
static volatile int8_t g_80 = 0x83L;/* VOLATILE GLOBAL g_80 */
static int16_t g_81 = 0x35B4L;
static volatile int32_t g_82[9][7][1] = {{{(-6L)},{(-1L)},{0xB654FA89L},{(-8L)},{(-6L)},{0L},{(-6L)}},{{(-8L)},{0xB654FA89L},{(-1L)},{(-6L)},{0x8AE84C8BL},{(-6L)},{(-1L)}},{{0xB654FA89L},{(-8L)},{(-6L)},{0L},{(-6L)},{(-8L)},{0xB654FA89L}},{{(-1L)},{(-6L)},{0x8AE84C8BL},{(-6L)},{(-1L)},{0xB654FA89L},{(-8L)}},{{(-6L)},{0L},{(-6L)},{(-8L)},{0xB654FA89L},{(-1L)},{(-6L)}},{{0x8AE84C8BL},{0xB654FA89L},{0L},{0xE691EA77L},{0x8AE84C8BL},{0xB654FA89L},{0x2FC28BF8L}},{{0xB654FA89L},{0x8AE84C8BL},{0xE691EA77L},{0L},{0xB654FA89L},{0x219E070DL},{0xB654FA89L}},{{0L},{0xE691EA77L},{0x8AE84C8BL},{0xB654FA89L},{0x2FC28BF8L},{0xB654FA89L},{0x8AE84C8BL}},{{0xE691EA77L},{0L},{0xB654FA89L},{0x219E070DL},{0xB654FA89L},{0L},{0xE691EA77L}}};
static volatile int8_t g_91 = 0xB3L;/* VOLATILE GLOBAL g_91 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint8_t  func_8(uint32_t  p_9, int16_t  p_10, int32_t  p_11, uint32_t  p_12);
static uint32_t  func_13(const uint32_t  p_14, uint64_t  p_15, int32_t  p_16, int32_t  p_17, uint64_t  p_18);
static uint32_t  func_19(uint8_t  p_20, int64_t  p_21);
static uint32_t  func_24(uint8_t  p_25, uint64_t  p_26, const uint16_t  p_27, int32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_73
 * writes: g_3 g_2 g_73
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_30 = 0xCBE92E3FL;
    uint8_t l_48 = 0x19L;
    int32_t l_63[8] = {9L,9L,9L,9L,9L,9L,9L,9L};
    int16_t l_79 = 0xEF9BL;
    int32_t l_83[3][3][6] = {{{7L,(-8L),1L,1L,(-8L),(-1L)},{7L,0x62EE7B9AL,1L,3L,0x62EE7B9AL,0xB35B4449L},{0xB35B4449L,(-1L),(-1L),3L,0xB5A3AA3BL,3L}},{{7L,0L,7L,1L,(-8L),0xDAAAAF26L},{7L,6L,1L,3L,6L,1L},{0xB35B4449L,0xB5A3AA3BL,(-1L),3L,0L,1L}},{{7L,(-8L),0xB35B4449L,1L,0L,(-1L)},{7L,0x83CA8B6AL,3L,3L,0x83CA8B6AL,7L},{0xB35B4449L,0L,0xDAAAAF26L,3L,(-1L),1L}}};
    int32_t l_84 = 1L;
    int8_t l_85 = 0x2EL;
    uint64_t l_86[10] = {3UL,2UL,3UL,2UL,3UL,2UL,3UL,2UL,3UL,2UL};
    int8_t l_89 = 1L;
    int32_t l_90[8] = {0xA8B3183DL,0x404BF6FAL,0xA8B3183DL,0x404BF6FAL,0xA8B3183DL,0x404BF6FAL,0xA8B3183DL,0x404BF6FAL};
    uint64_t l_92[7];
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_92[i] = 7UL;
    for (g_3 = (-8); (g_3 >= (-5)); ++g_3)
    { /* block id: 3 */
        int16_t l_29 = 0x8AA2L;
        uint8_t l_47 = 4UL;
        if ((((((safe_rshift_func_uint8_t_u_u(func_8(func_13((((((func_19((safe_sub_func_uint8_t_u_u((func_24((l_29 , l_29), g_2, g_3, l_30) > l_30), 247UL)), l_29) ^ g_3) > 0UL) != 0x9DL) , 253UL) == g_3), g_3, l_29, l_29, g_3), l_47, l_48, l_47), 6)) || g_3) == g_3) , 0UL) >= 65535UL))
        { /* block id: 28 */
            int32_t l_53 = 0xC3B36352L;
            l_53 = (+(g_3 != l_48));
        }
        else
        { /* block id: 30 */
            uint32_t l_54 = 0x45464CD0L;
            return l_54;
        }
    }
    if ((safe_rshift_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(((safe_div_func_uint16_t_u_u((0x1EC3L <= g_2), g_3)) > l_30), g_3)), g_3)))
    { /* block id: 34 */
        uint32_t l_62 = 0x77D7E7D1L;
        uint16_t l_64[9][9][3] = {{{1UL,1UL,9UL},{8UL,6UL,8UL},{65535UL,0x9155L,65535UL},{0xD49AL,0xB632L,0x6639L},{0x87D1L,0xC715L,0xED35L},{0UL,65535UL,0UL},{65531UL,65535UL,65535UL},{0UL,65535UL,0xAA68L},{0x87D1L,1UL,1UL}},{{0xD49AL,1UL,0xB5DBL},{65535UL,2UL,0x8BBDL},{8UL,0UL,65526UL},{1UL,0xD8A5L,9UL},{0xAF0CL,0xCBDCL,1UL},{0x95FFL,0xD49AL,0UL},{0UL,0x8BBDL,1UL},{7UL,0x4F54L,0UL},{0x27F9L,0x8DD9L,0xB37EL}},{{0xCBDCL,2UL,65535UL},{0xB5DBL,0xF84FL,0x32FBL},{0xAA68L,65530UL,0xA102L},{6UL,8UL,0x5618L},{6UL,0UL,5UL},{0x0A02L,65535UL,65530UL},{0UL,1UL,0UL},{0xB632L,1UL,65535UL},{0x2EC3L,65535UL,0xC715L}},{{0x8BBDL,0UL,0x319FL},{0xC715L,0x8AE6L,65535UL},{8UL,0xC715L,0x2EC3L},{0xA33BL,1UL,0x3E70L},{0x27F9L,65535UL,0xD49AL},{65535UL,65535UL,8UL},{6UL,65530UL,0UL},{2UL,0x83C5L,65535UL},{1UL,0x8351L,0xF84FL}},{{3UL,65535UL,1UL},{0UL,0x6C0CL,65535UL},{0x8DD9L,0x7108L,0x6C0CL},{0x717FL,3UL,0xA102L},{9UL,9UL,7UL},{65535UL,4UL,0xB001L},{0UL,0xDF81L,65535UL},{0x8095L,0x0646L,65530UL},{1UL,0UL,65535UL}},{{65531UL,0x32FBL,0xB001L},{0x6A77L,0xAA68L,7UL},{1UL,65535UL,0xA102L},{1UL,0x319FL,0x6C0CL},{0x8BBDL,0x9708L,65535UL},{0x0646L,0x3C5CL,1UL},{0UL,0x2F22L,0xF84FL},{6UL,65531UL,65535UL},{0UL,0x0418L,0UL}},{{0xC201L,0x9652L,8UL},{1UL,8UL,0xD49AL},{0xC93EL,0x6639L,0x3E70L},{0x0A02L,6UL,0x2EC3L},{65535UL,65535UL,65535UL},{0x3C5CL,0x717FL,0x27F9L},{0x9652L,65535UL,0x32FBL},{0x5DE1L,0xAF0CL,0x0646L},{0xD42CL,0UL,65531UL}},{{0xD42CL,0x7201L,0x9652L},{0x5DE1L,0x63FEL,0UL},{0x9652L,0UL,0UL},{0x3C5CL,7UL,0xD8A5L},{65535UL,9UL,0x8BBDL},{0x0A02L,0xC1A6L,65531UL},{0xC93EL,5UL,1UL},{1UL,2UL,0x7108L},{0xC201L,65526UL,0x4F54L}},{{0UL,0UL,0xB37EL},{6UL,0UL,9UL},{0UL,65526UL,0x5DE1L},{0x0646L,8UL,0UL},{0x8BBDL,1UL,0x83C5L},{1UL,0x87D1L,0x87D1L},{1UL,65533UL,0x2F08L},{0x6A77L,0xC201L,0xCBDCL},{65531UL,0x8BBDL,0UL}}};
        uint8_t l_65[5][7] = {{0UL,0xC5L,255UL,250UL,255UL,0xC5L,0UL},{0xE5L,5UL,1UL,255UL,1UL,5UL,0xE5L},{0UL,0xC5L,255UL,250UL,255UL,0xC5L,0UL},{0xE5L,5UL,1UL,255UL,1UL,5UL,0xE5L},{0UL,0xC5L,255UL,255UL,0xE5L,0UL,250UL}};
        int i, j, k;
        l_63[0] = (!(l_62 < 0xFAL));
        l_64[1][6][0] &= 0xEFD7F9B6L;
        l_65[1][6] ^= g_2;
        g_2 = (+(+1UL));
    }
    else
    { /* block id: 39 */
        int16_t l_70[8][9][3] = {{{(-10L),0x04EDL,0x52ACL},{0xCB94L,0xCB94L,0xB6EBL},{1L,0xAFD9L,0L},{0x0899L,8L,0xB1B1L},{0xB1B7L,0xFD6BL,(-1L)},{0xB1B1L,0x0899L,0xB1B1L},{0x3884L,0x8BF3L,0L},{0x0625L,0xCF0FL,0xB6EBL},{(-1L),(-4L),0x52ACL}},{{1L,0x6F13L,0x6F13L},{(-1L),0x09BDL,0xB1B7L},{0x0625L,0x5886L,0xCB94L},{0x3884L,3L,(-1L)},{0xB1B1L,0xB6EBL,0L},{0xB1B7L,3L,0x819BL},{0x0899L,0x5886L,0x2A6AL},{1L,0x09BDL,(-10L)},{0xCB94L,0x6F13L,0x5886L}},{{(-10L),(-4L),(-10L)},{0xB7F0L,0xCF0FL,0x2A6AL},{0xD659L,0x8BF3L,0x819BL},{0x6F13L,0x0899L,0L},{0xD34EL,0xFD6BL,(-1L)},{0x6F13L,8L,0xCB94L},{0xD659L,0xAFD9L,0xB1B7L},{0xB7F0L,0xCB94L,0x6F13L},{(-10L),0x04EDL,0x52ACL}},{{0xCB94L,0xCB94L,0xB6EBL},{1L,0xAFD9L,0L},{0x0899L,8L,0xB1B1L},{0xB1B7L,0xFD6BL,(-1L)},{0xB1B1L,0x0899L,0xB1B1L},{0x3884L,0x8BF3L,0L},{0x0625L,0xCF0FL,0xB6EBL},{(-1L),(-4L),0x52ACL},{1L,0x6F13L,0x6F13L}},{{(-1L),0x09BDL,0xB1B7L},{0x0625L,0x5886L,0xCB94L},{0x3884L,3L,(-1L)},{0xB1B1L,0xB6EBL,0L},{0xB1B7L,3L,0x819BL},{0x0899L,0x5886L,0x2A6AL},{1L,0x09BDL,(-10L)},{0xCB94L,0x6F13L,0x5886L},{(-10L),(-4L),(-10L)}},{{0xB7F0L,0xCF0FL,0x2A6AL},{0xD659L,0x8BF3L,0x819BL},{0x6F13L,0x0899L,0L},{0xD34EL,0xFD6BL,(-1L)},{0x6F13L,8L,0xCB94L},{0xD659L,0xAFD9L,0xB1B7L},{0xB7F0L,0xCB94L,0x6F13L},{(-10L),0x04EDL,0x52ACL},{0xCB94L,0xCB94L,0xB6EBL}},{{1L,0xAFD9L,0L},{0x0899L,8L,0xB1B1L},{0xB1B7L,0xFD6BL,(-1L)},{0xB1B1L,0x0899L,0xB1B1L},{0x3884L,0x8BF3L,0L},{0x0625L,0xCF0FL,0xB6EBL},{(-1L),(-4L),0x52ACL},{1L,0x6F13L,0x6F13L},{(-1L),(-1L),0x819BL}},{{0xB1B1L,0x6F13L,0xB6EBL},{(-1L),0x04EDL,0xD34EL},{0x5886L,0x0899L,0x0625L},{0x819BL,0x04EDL,1L},{0xB7F0L,0x6F13L,0L},{0x3884L,(-1L),(-1L)},{0xB6EBL,1L,0x6F13L},{(-1L),0x66B6L,(-1L)},{0xCF0FL,8L,0L}}};
        int32_t l_72 = 0x064424CFL;
        int8_t l_78[1];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_78[i] = (-2L);
        l_70[7][7][0] = (safe_add_func_uint64_t_u_u(g_2, l_48));
        g_73++;
        l_72 = (((safe_rshift_func_uint16_t_u_u(0xD86AL, 6)) || 0x38L) >= l_78[0]);
        return l_78[0];
    }
    ++l_86[5];
    l_92[3]--;
    return l_90[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_2
 */
static uint8_t  func_8(uint32_t  p_9, int16_t  p_10, int32_t  p_11, uint32_t  p_12)
{ /* block id: 24 */
    uint64_t l_49 = 7UL;
    --l_49;
    g_2 = ((l_49 != l_49) , l_49);
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2
 * writes: g_2
 */
static uint32_t  func_13(const uint32_t  p_14, uint64_t  p_15, int32_t  p_16, int32_t  p_17, uint64_t  p_18)
{ /* block id: 18 */
    int8_t l_42[6][1] = {{0L},{(-8L)},{0L},{(-8L)},{0L},{(-8L)}};
    int16_t l_45 = 0x25B0L;
    int32_t l_46 = 2L;
    int i, j;
    g_2 = (+(+(p_17 , p_16)));
    p_17 = (((safe_rshift_func_uint8_t_u_u(g_3, 0)) , p_17) && g_3);
    l_42[5][0] |= 0L;
    l_46 = ((safe_mul_func_uint8_t_u_u(l_42[3][0], g_2)) , l_45);
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static uint32_t  func_19(uint8_t  p_20, int64_t  p_21)
{ /* block id: 8 */
    uint8_t l_33 = 255UL;
    int32_t l_34 = 0xB6B7BE2DL;
    uint32_t l_35 = 0xD53D2AE4L;
    l_34 |= l_33;
    l_34 = (255UL > l_33);
    l_34 = ((l_35 ^ p_20) ^ g_2);
    for (p_21 = 0; (p_21 != (-24)); p_21 = safe_sub_func_uint32_t_u_u(p_21, 8))
    { /* block id: 14 */
        g_2 = g_2;
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static uint32_t  func_24(uint8_t  p_25, uint64_t  p_26, const uint16_t  p_27, int32_t  p_28)
{ /* block id: 4 */
    int64_t l_31 = 0x99740826F3938425LL;
    l_31 = p_28;
    p_28 = (!3UL);
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_71[i][j], "g_71[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_82[i][j][k], "g_82[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_91, "g_91", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 35
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 29
breakdown:
   depth: 1, occurrence: 41
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 29, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 48
XXX times a non-volatile is write: 20
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 84
XXX percentage of non-volatile access: 84

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 33
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 10
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 17.1
XXX percentage an existing variable is used: 82.9
********************* end of statistics **********************/

