/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4991998013914423614
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_2[3] = {0x3556834504CD4536LL,0x3556834504CD4536LL,0x3556834504CD4536LL};
static int32_t g_12 = 0L;
static int32_t g_13[3][6][9] = {{{0xE71CC545L,0x8B36CEDDL,0xE71CC545L,0x711A53FDL,0x7722ABACL,(-1L),0x6A191A83L,(-1L),0x7722ABACL},{(-5L),0x81720D70L,0x81720D70L,(-5L),0x8F8F6A1CL,(-1L),0x81720D70L,0x702377D6L,(-5L)},{0xBA3F3004L,0x711A53FDL,6L,0x711A53FDL,0xBA3F3004L,(-8L),0x9CDE30ECL,4L,0x9CDE30ECL},{0x702377D6L,0x8F8F6A1CL,(-5L),(-5L),0x8F8F6A1CL,0x702377D6L,0L,(-5L),1L},{0x91260E2EL,(-8L),0x7722ABACL,4L,0x7722ABACL,(-8L),0x91260E2EL,(-1L),0x6A191A83L},{1L,(-1L),(-5L),(-5L),(-5L),(-5L),(-1L),1L,(-5L)}},{{6L,(-1L),1L,4L,0xBA3F3004L,4L,1L,(-1L),6L},{0x702377D6L,(-5L),0L,(-1L),0x702377D6L,0x702377D6L,(-1L),0L,(-5L)},{0xE71CC545L,(-8L),0x6A191A83L,0x8B36CEDDL,0x91260E2EL,(-1L),0x91260E2EL,0x8B36CEDDL,0x6A191A83L},{0x702377D6L,0x81720D70L,(-1L),0x8F8F6A1CL,(-5L),0x81720D70L,0x81720D70L,(-5L),0x8F8F6A1CL},{6L,(-8L),6L,(-1L),1L,4L,0xBA3F3004L,4L,1L},{1L,(-5L),(-1L),(-5L),(-7L),1L,(-1L),(-1L),1L}},{{0x7722ABACL,(-1L),0x6A191A83L,(-1L),0x7722ABACL,0x711A53FDL,0xE71CC545L,0x8B36CEDDL,0xE71CC545L},{(-5L),(-1L),0L,0x8F8F6A1CL,(-7L),(-1L),(-1L),0x8F8F6A1CL,0x8F8F6A1CL},{0x9CDE30ECL,0x711A53FDL,1L,0x8B36CEDDL,1L,0x711A53FDL,0x9CDE30ECL,(-1L),3L},{1L,(-7L),(-5L),(-1L),(-5L),1L,(-1L),(-5L),(-5L)},{(-1L),(-1L),0xE71CC545L,4L,0x91260E2EL,4L,0xE71CC545L,(-1L),(-1L)},{0x702377D6L,(-1L),0L,(-5L),0x702377D6L,0x81720D70L,(-1L),0x8F8F6A1CL,(-5L)}}};


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2 g_12 g_13
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_11 = 0x182B4746L;
    --g_2[2];
    g_12 = ((((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_div_func_uint32_t_u_u(((0x4D513C61C71BC7DCLL < 0UL) < l_11), 1UL)), l_11)), 7)) < 0x7AB6L) ^ g_2[2]) > g_2[2]);
    g_13[1][4][1] = ((l_11 < 0x8F2BA167L) >= g_2[2]);
    g_13[1][4][1] = ((l_11 == 0UL) > g_2[2]);
    return g_2[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_13[i][j][k], "g_13[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 6
   depth: 3, occurrence: 2
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 5
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 5

XXX percentage a fresh-made variable is used: 30.8
XXX percentage an existing variable is used: 69.2
********************* end of statistics **********************/

