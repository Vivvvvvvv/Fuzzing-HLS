/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10963511998564308558
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = (-1L);
static volatile int8_t g_74 = 0xD7L;/* VOLATILE GLOBAL g_74 */
static uint32_t g_76 = 0xAC155EA0L;
static volatile int32_t g_86 = 0x6D6BBB23L;/* VOLATILE GLOBAL g_86 */
static uint32_t g_87 = 18446744073709551615UL;
static uint8_t g_114[1] = {247UL};
static int32_t g_140 = 0x3136B179L;
static int16_t g_141 = (-9L);
static volatile int32_t g_142 = 0xF833B27FL;/* VOLATILE GLOBAL g_142 */
static volatile uint16_t g_143 = 0x7B2BL;/* VOLATILE GLOBAL g_143 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static const int32_t  func_6(uint64_t  p_7, int64_t  p_8, uint32_t  p_9, uint8_t  p_10, int32_t  p_11);
static uint64_t  func_25(uint64_t  p_26);
static uint64_t  func_30(uint64_t  p_31, uint8_t  p_32, uint64_t  p_33);
static int32_t  func_35(uint64_t  p_36, uint32_t  p_37, uint8_t  p_38);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_76 g_87 g_74 g_86 g_114 g_143 g_142 g_141 g_140
 * writes: g_3 g_2 g_76 g_87 g_114 g_143
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int64_t l_119 = 0x858447AD0ED6609ALL;
    uint8_t l_131[3];
    int32_t l_136 = 0L;
    uint32_t l_156 = 0UL;
    int16_t l_164 = 0x10CFL;
    uint16_t l_178 = 0UL;
    int i;
    for (i = 0; i < 3; i++)
        l_131[i] = 0UL;
    for (g_3 = 0; (g_3 <= (-30)); g_3 = safe_sub_func_uint64_t_u_u(g_3, 1))
    { /* block id: 3 */
        int8_t l_12 = 2L;
        int32_t l_113[6][7] = {{(-5L),1L,(-5L),0x87E9A703L,(-5L),1L,(-5L)},{0x60F7E9ACL,0x996C8B9EL,9L,0x0817FF2AL,0x0817FF2AL,9L,0x996C8B9EL},{1L,1L,1L,1L,1L,1L,1L},{0x0817FF2AL,0x0817FF2AL,9L,0x996C8B9EL,0x60F7E9ACL,0x60F7E9ACL,0x996C8B9EL},{(-5L),0x87E9A703L,(-5L),1L,(-5L),0x87E9A703L,(-5L)},{0x0817FF2AL,0x996C8B9EL,0x996C8B9EL,0x0817FF2AL,0x60F7E9ACL,9L,9L}};
        int i, j;
        if (func_6(g_2, l_12, g_3, g_3, l_12))
        { /* block id: 62 */
            uint64_t l_112[4];
            int i;
            for (i = 0; i < 4; i++)
                l_112[i] = 0x785040678986B1ECLL;
            g_2 = l_112[2];
            l_113[5][2] &= (-9L);
        }
        else
        { /* block id: 65 */
            g_2 = ((4294967295UL ^ l_113[5][2]) < 65535UL);
            g_2 = (65528UL >= g_76);
        }
        --g_114[0];
        for (l_12 = (-27); (l_12 <= 3); l_12 = safe_add_func_uint16_t_u_u(l_12, 6))
        { /* block id: 72 */
            return l_119;
        }
    }
lbl_155:
    if ((7UL >= 0x66L))
    { /* block id: 76 */
        uint16_t l_120 = 0x12A6L;
        int32_t l_125 = 0xAEE0EB6CL;
        uint16_t l_135 = 2UL;
        l_120++;
        for (g_87 = 0; (g_87 < 5); g_87 = safe_add_func_uint32_t_u_u(g_87, 3))
        { /* block id: 80 */
            l_125 ^= g_3;
            g_3 = (safe_rshift_func_uint8_t_u_u(((((!g_76) && g_2) , 248UL) == g_87), 4));
            g_3 |= l_119;
            if (l_125)
                goto lbl_155;
            return g_76;
        }
        g_3 |= l_119;
        if ((l_119 && 0xA2485703L))
        { /* block id: 87 */
            uint32_t l_129[3][3][9] = {{{0xF5104884L,7UL,7UL,7UL,0xF5104884L,0x954279E9L,7UL,0x954279E9L,0xF5104884L},{1UL,1UL,1UL,1UL,0x7F8654D6L,0x81A46AFDL,18446744073709551608UL,18446744073709551609UL,0x61E54E03L},{18446744073709551608UL,0x954279E9L,18446744073709551608UL,0xCC89D979L,5UL,0x954279E9L,5UL,0xCC89D979L,18446744073709551608UL}},{{0x61E54E03L,0x61E54E03L,0x81A46AFDL,1UL,0x7F8654D6L,18446744073709551609UL,1UL,18446744073709551608UL,1UL},{0xF5104884L,0x21FA5157L,0x12D82128L,0xCC89D979L,0xF5104884L,0xCC89D979L,0x12D82128L,0x21FA5157L,0xF5104884L},{0x7F8654D6L,1UL,0x81A46AFDL,1UL,0x61E54E03L,18446744073709551608UL,1UL,18446744073709551609UL,18446744073709551609UL}},{{5UL,0x21FA5157L,18446744073709551608UL,7UL,18446744073709551608UL,0x21FA5157L,5UL,7UL,5UL},{0x7F8654D6L,0x61E54E03L,1UL,1UL,1UL,18446744073709551609UL,0x81A46AFDL,0x81A46AFDL,18446744073709551609UL},{0xF5104884L,0x954279E9L,7UL,0x954279E9L,0xF5104884L,7UL,7UL,7UL,0xF5104884L}}};
            int i, j, k;
lbl_130:
            l_129[1][0][7] &= 0L;
            g_3 = (((((l_120 > l_125) > l_129[1][0][0]) == 65535UL) ^ g_74) , g_114[0]);
            if (l_125)
                goto lbl_130;
        }
        else
        { /* block id: 91 */
            uint16_t l_132 = 1UL;
            g_2 &= (((0xCD93L && l_131[0]) ^ g_114[0]) && l_132);
            l_136 = (safe_div_func_uint8_t_u_u((l_135 > l_125), 6UL));
            l_136 |= 0L;
        }
    }
    else
    { /* block id: 96 */
        uint32_t l_154 = 4294967295UL;
        for (g_3 = 0; (g_3 <= (-7)); g_3--)
        { /* block id: 99 */
            int32_t l_139 = 0x539A05EBL;
            g_2 = g_3;
            g_2 = l_139;
            g_143++;
            l_154 = (safe_div_func_uint64_t_u_u(((((safe_sub_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(g_114[0], 0x1F22L)), 7)), g_114[0])) , 3UL) && 250UL) < g_142), l_139));
        }
    }
    if (((l_131[2] < l_156) > g_114[0]))
    { /* block id: 107 */
        int64_t l_161 = 2L;
        int32_t l_165 = 0xFE107053L;
        int64_t l_174 = 0x39280DD1ACC9075FLL;
        if (((safe_mod_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u((g_114[0] ^ l_161), 0UL)) && g_141), g_2)) <= 0xE665L))
        { /* block id: 108 */
            l_165 &= ((safe_sub_func_uint16_t_u_u(((((((g_86 >= 255UL) != g_114[0]) == l_131[0]) == 65531UL) , 0x62AE5279L) == 0UL), 65533UL)) != l_164);
            g_2 = g_3;
            return g_141;
        }
        else
        { /* block id: 112 */
            int32_t l_177 = 0x605C4976L;
            g_2 = (safe_rshift_func_uint8_t_u_u((((((safe_div_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(((((((g_140 != g_142) || g_140) , g_74) < g_76) || l_119) && 255UL), 14)), 255UL)) != g_114[0]), 1UL)) < 0x913F7DCBD80DBD02LL) == l_174) <= 65528UL) , 253UL), 5));
            l_178 = ((safe_lshift_func_uint8_t_u_u(g_141, 4)) , l_177);
        }
        return g_86;
    }
    else
    { /* block id: 117 */
        uint8_t l_179 = 0x11L;
        --l_179;
        g_2 |= l_164;
        g_2 = g_76;
    }
    return l_164;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_76 g_87 g_74 g_86
 * writes: g_2 g_76 g_87
 */
static const int32_t  func_6(uint64_t  p_7, int64_t  p_8, uint32_t  p_9, uint8_t  p_10, int32_t  p_11)
{ /* block id: 4 */
    uint64_t l_66 = 0xD083830386B9BDD1LL;
    int32_t l_75 = (-3L);
    int32_t l_83[9][5] = {{0x318E2BB1L,(-1L),(-1L),0x318E2BB1L,(-3L)},{0L,0xE2253E45L,0L,1L,0xB8B7CB4DL},{0L,4L,(-3L),4L,0L},{0xE2253E45L,8L,0x54743E03L,1L,8L},{0xB26CBFC7L,0L,0x318E2BB1L,0x318E2BB1L,0L},{(-10L),0L,0L,8L,8L},{4L,0x318E2BB1L,0L,0x24228194L,0L},{8L,8L,0xE2253E45L,(-10L),0xB8B7CB4DL},{4L,0x667D1577L,0xB26CBFC7L,(-3L),(-3L)}};
    int32_t l_105 = 0x98C5D292L;
    int i, j;
    for (p_10 = 0; (p_10 > 21); p_10 = safe_add_func_uint64_t_u_u(p_10, 7))
    { /* block id: 7 */
        for (p_9 = (-4); (p_9 != 41); p_9++)
        { /* block id: 10 */
            uint8_t l_29 = 0x34L;
            int32_t l_67[7] = {6L,6L,0xB358509EL,6L,6L,0xB358509EL,6L};
            int i;
            l_67[1] &= (safe_sub_func_uint8_t_u_u((!(safe_lshift_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u((!(func_25((safe_rshift_func_uint16_t_u_u(l_29, 7))) , l_66)), p_8)) , 0x3176A17913DA513ELL) >= p_11), 6))), g_3));
            g_2 = (safe_lshift_func_uint16_t_u_u(0x0BF0L, 11));
        }
    }
    g_2 = g_2;
    if ((g_3 , l_66))
    { /* block id: 46 */
        int32_t l_70 = 1L;
        int32_t l_71 = 0xB4074358L;
        int32_t l_72 = (-1L);
        int32_t l_73 = (-1L);
        ++g_76;
    }
    else
    { /* block id: 48 */
        const uint8_t l_82 = 0x12L;
        int32_t l_84 = (-1L);
        int32_t l_85[2][6][6] = {{{8L,0xF88197C5L,(-2L),0xF88197C5L,8L,8L},{1L,0xF88197C5L,0xF88197C5L,1L,0x62BFFD65L,1L},{1L,0x62BFFD65L,1L,0xF88197C5L,0xF88197C5L,1L},{8L,8L,0xF88197C5L,(-2L),0xF88197C5L,8L},{0xF88197C5L,0x62BFFD65L,(-2L),(-2L),0x62BFFD65L,0xF88197C5L},{8L,0xF88197C5L,(-2L),0xF88197C5L,8L,8L}},{{1L,0xF88197C5L,0xF88197C5L,1L,0x62BFFD65L,1L},{1L,0x62BFFD65L,1L,0xF88197C5L,0xF88197C5L,1L},{8L,8L,0xF88197C5L,(-2L),0xF88197C5L,8L},{0xF88197C5L,0x62BFFD65L,(-2L),(-2L),0x62BFFD65L,0xF88197C5L},{8L,1L,0x62BFFD65L,1L,0xF88197C5L,0xF88197C5L},{(-2L),1L,1L,(-2L),8L,(-2L)}}};
        int i, j, k;
        l_83[0][1] ^= (((!((safe_mul_func_uint8_t_u_u(((0xC6L < l_82) && p_7), l_66)) <= 0x9A3A415DBE4B24D3LL)) , l_75) >= g_76);
        --g_87;
        if ((safe_add_func_uint8_t_u_u(((safe_div_func_uint32_t_u_u(l_85[0][3][3], 0x7C5FD538L)) <= g_2), g_3)))
        { /* block id: 51 */
            l_85[1][2][0] = (safe_div_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u((!(((l_82 , 0UL) >= g_87) > 0x82L)), 0x36L)), 1UL)), 6)), 65535UL));
        }
        else
        { /* block id: 53 */
            g_2 = (safe_sub_func_uint16_t_u_u(((((g_76 <= g_3) && 0xF2L) > 65535UL) , 0xEAE2L), p_8));
            g_2 = ((l_105 , 0UL) >= g_76);
            l_85[1][5][0] = (safe_mod_func_uint8_t_u_u(0x34L, g_3));
            g_2 = (((((((((safe_lshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(0xE21EL, l_84)), g_74)) != 0x3EL) , l_82) || p_11) <= 0UL) ^ 0xFE41CD94L) ^ g_76) , g_87) == 0xE0B6AD74L);
        }
    }
    g_2 = g_86;
    return l_66;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3
 * writes: g_2
 */
static uint64_t  func_25(uint64_t  p_26)
{ /* block id: 11 */
    int8_t l_34 = 0x34L;
    int32_t l_65 = 0x7C316764L;
    g_2 = p_26;
    l_65 = (func_30(l_34, l_34, g_2) <= g_3);
    g_2 = (7UL ^ l_34);
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2
 * writes: g_2
 */
static uint64_t  func_30(uint64_t  p_31, uint8_t  p_32, uint64_t  p_33)
{ /* block id: 13 */
    int32_t l_52[1];
    int i;
    for (i = 0; i < 1; i++)
        l_52[i] = (-2L);
    l_52[0] |= func_35(g_3, g_3, p_31);
    for (p_33 = 0; (p_33 >= 31); p_33 = safe_add_func_uint32_t_u_u(p_33, 3))
    { /* block id: 33 */
        int32_t l_61 = 9L;
        int32_t l_64[4];
        int i;
        for (i = 0; i < 4; i++)
            l_64[i] = 0xDCBDED69L;
        g_2 = (safe_add_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(((g_3 <= l_61) != l_61), 0x05L)), 14)), g_2));
        l_64[1] = ((safe_mul_func_uint8_t_u_u((0x0C63704BAE9140DELL || g_2), 251UL)) >= 65528UL);
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2
 * writes: g_2
 */
static int32_t  func_35(uint64_t  p_36, uint32_t  p_37, uint8_t  p_38)
{ /* block id: 14 */
    uint16_t l_47 = 0x4DB5L;
    for (p_38 = (-12); (p_38 > 35); p_38 = safe_add_func_uint16_t_u_u(p_38, 3))
    { /* block id: 17 */
        uint32_t l_41 = 6UL;
        int32_t l_42 = 0x0B2455F9L;
        l_41 |= ((g_3 , g_2) != 0xC4L);
        l_42 = (g_2 != p_37);
        l_42 = (safe_lshift_func_uint16_t_u_u(g_2, 0));
        g_2 = (((safe_sub_func_uint64_t_u_u((l_41 && g_2), 0UL)) < g_3) , p_37);
    }
    l_47++;
    for (l_47 = 0; (l_47 > 38); l_47++)
    { /* block id: 26 */
        if (p_36)
            break;
    }
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_114[i], "g_114[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 51
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 83
   depth: 2, occurrence: 18
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 5
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 2
   depth: 11, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 107
XXX times a non-volatile is write: 37
XXX times a volatile is read: 21
XXX    times read thru a pointer: 0
XXX times a volatile is write: 21
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 108
XXX percentage of non-volatile access: 77.4

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 77
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 25
   depth: 2, occurrence: 32

XXX percentage a fresh-made variable is used: 27
XXX percentage an existing variable is used: 73
********************* end of statistics **********************/

