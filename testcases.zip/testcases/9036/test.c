/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      935534662901982546
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_3[10][6] = {{0xBE13L,0xA66EL,5L,0x5BA7L,0x2170L,0xBE13L},{0L,2L,0L,0xBE13L,0x7B56L,0x7B56L},{0x4D07L,0x3B9DL,0x3B9DL,0x4D07L,1L,0xA727L},{0L,0x2304L,0x4D07L,0xC027L,0xBD2AL,0xE1F6L},{0x8D02L,0x7B56L,2L,5L,0xBD2AL,0x9141L},{0xBE13L,0x2304L,0x9951L,0L,1L,0xBE13L},{0x7B56L,0x3B9DL,0x704FL,0x3B9DL,0x7B56L,1L},{0xA727L,2L,0xBD2AL,0x4D07L,0x9141L,0x704FL},{0L,0x8D02L,5L,0L,0xE1F6L,0x704FL},{2L,0xBE13L,(-10L),0xA66EL,0xA727L,0xC027L}};
static volatile int64_t g_5[4][3][4] = {{{0x21EC2184E5A945CBLL,0x21EC2184E5A945CBLL,(-3L),0xEA0D018D303F0244LL},{1L,(-9L),0xD4E2B79DC86695CDLL,0xEC5EC62BB2C593C8LL},{6L,0xD4E2B79DC86695CDLL,0xEA0D018D303F0244LL,0xD4E2B79DC86695CDLL}},{{0xEA0D018D303F0244LL,0xD4E2B79DC86695CDLL,6L,0xEC5EC62BB2C593C8LL},{0xD4E2B79DC86695CDLL,(-9L),1L,0xEA0D018D303F0244LL},{(-3L),0x21EC2184E5A945CBLL,0x21EC2184E5A945CBLL,(-3L)}},{{(-3L),0xEC5EC62BB2C593C8LL,1L,7L},{0xD4E2B79DC86695CDLL,(-3L),6L,1L},{0xEA0D018D303F0244LL,0L,0xEA0D018D303F0244LL,1L}},{{6L,(-3L),0xD4E2B79DC86695CDLL,7L},{1L,0xEC5EC62BB2C593C8LL,(-3L),(-3L)},{0x21EC2184E5A945CBLL,0x21EC2184E5A945CBLL,(-3L),0xEA0D018D303F0244LL}}};
static int32_t g_7 = 0x607F4707L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_7 g_5
 * writes: g_7
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2 = 1UL;
    int32_t l_6[2][10] = {{0xE7F13BCFL,0x2305ABA9L,0xE7F13BCFL,0x36572186L,0x36572186L,0xE7F13BCFL,0x2305ABA9L,0xE7F13BCFL,0x36572186L,0x36572186L},{0xE7F13BCFL,0x2305ABA9L,0xE7F13BCFL,0x36572186L,0x36572186L,0xE7F13BCFL,0x2305ABA9L,0xE7F13BCFL,0x36572186L,0x36572186L}};
    int i, j;
    if (l_2)
    { /* block id: 1 */
        int8_t l_4 = 0xCBL;
        l_4 = (g_3[6][5] , g_3[6][5]);
    }
    else
    { /* block id: 3 */
        uint16_t l_8 = 0xE487L;
        l_8++;
        g_7 &= (0x09020024L > 0UL);
        l_6[0][6] &= ((safe_mod_func_uint64_t_u_u(l_8, g_5[1][2][3])) < 0x0165L);
    }
    g_7 = (((0xE4F6F484L != g_3[6][5]) < 0x6A96DAD8BE776E9FLL) < g_7);
    return l_6[0][0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_5[i][j][k], "g_5[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_7, "g_7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 7
XXX times a non-volatile is write: 5
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 92.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 43.8
XXX percentage an existing variable is used: 56.2
********************* end of statistics **********************/

