/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob2.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14180411140122455386
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_6 = 0x9C1464F1L;/* VOLATILE GLOBAL g_6 */
static uint8_t g_7 = 0x9AL;
static uint8_t g_8 = 0x92L;
static volatile uint32_t g_33 = 4294967286UL;/* VOLATILE GLOBAL g_33 */
static uint16_t g_44 = 0UL;
static const uint32_t g_62[6] = {0x911B6BEFL,0x911B6BEFL,0x911B6BEFL,0x911B6BEFL,0x911B6BEFL,0x911B6BEFL};
static int64_t g_107 = (-3L);
static volatile int16_t g_108[5][1][10] = {{{0L,3L,0L,0L,3L,0L,0L,3L,0L,0L}},{{3L,3L,0x12EAL,3L,3L,0x12EAL,3L,3L,0x12EAL,3L}},{{3L,0L,0L,3L,0L,0L,3L,0L,0L,3L}},{{0L,3L,0L,0L,3L,0L,0L,3L,0L,0L}},{{0L,0L,3L,0L,0L,3L,0L,0L,3L,0L}}};
static uint32_t g_109 = 1UL;
static int32_t g_120 = 5L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint8_t  func_17(uint16_t  p_18, int32_t  p_19);
static uint16_t  func_20(uint16_t  p_21, const uint32_t  p_22, int16_t  p_23);
static uint32_t  func_50(uint32_t  p_51, const int32_t  p_52, int64_t  p_53, uint32_t  p_54, uint32_t  p_55);
static uint16_t  func_67(int32_t  p_68, uint64_t  p_69, int8_t  p_70);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_7 g_8 g_33 g_44 g_62 g_109 g_107 g_120 g_108
 * writes: g_8 g_7 g_33 g_6 g_109 g_120
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_4 = 0x69L;
    uint8_t l_5 = 1UL;
    uint32_t l_133 = 1UL;
    g_8 |= (safe_add_func_uint64_t_u_u((((l_4 <= l_5) != 0x3843046B6EB6B9DDLL) > g_6), g_7));
    for (g_7 = 0; (g_7 > 40); g_7++)
    { /* block id: 4 */
        const uint16_t l_24[5] = {65532UL,65532UL,65532UL,65532UL,65532UL};
        int i;
        g_120 ^= ((safe_mod_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((func_17(func_20(l_5, l_24[4], l_4), g_8) , g_62[5]), g_7)), l_24[0])), 0xA73C59DB3CA632B0LL)) >= g_107);
    }
    g_6 = ((safe_mul_func_uint16_t_u_u((safe_mod_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u((((safe_div_func_uint32_t_u_u(0x885CFE2AL, g_109)) < g_108[1][0][4]) || 0x78L), l_5)), g_7)) || g_62[5]), l_133)), l_4)), g_7)) || 0xD33E78EDL);
    return g_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_8 g_44 g_7 g_33 g_62 g_109 g_107
 * writes: g_33 g_6 g_8 g_109
 */
static uint8_t  func_17(uint16_t  p_18, int32_t  p_19)
{ /* block id: 14 */
    int32_t l_39 = (-2L);
    int32_t l_43 = (-1L);
    int32_t l_48 = 0xE1CF2BBAL;
    uint8_t l_71[5] = {254UL,254UL,254UL,254UL,254UL};
    int32_t l_94 = 0x8780EC7DL;
    int i;
    if ((safe_sub_func_uint16_t_u_u(((l_39 , l_39) == g_6), l_39)))
    { /* block id: 15 */
        uint32_t l_40[3];
        int i;
        for (i = 0; i < 3; i++)
            l_40[i] = 0xA4B38B4BL;
        return l_40[2];
    }
    else
    { /* block id: 17 */
        uint64_t l_49 = 0xEE00B46F9F111191LL;
        int32_t l_102 = 6L;
        int32_t l_103 = (-8L);
        int32_t l_104 = (-1L);
        int32_t l_105 = 4L;
        if (((safe_lshift_func_uint8_t_u_u(l_43, p_19)) ^ g_8))
        { /* block id: 18 */
            int32_t l_45 = 3L;
            const int32_t l_64 = 8L;
            l_39 = ((func_20(g_44, l_43, l_45) >= l_45) , p_18);
            l_39 |= g_44;
            l_49 |= (safe_mul_func_uint16_t_u_u(l_48, p_19));
            l_39 = (func_20(((func_50(((safe_div_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u(0UL, l_43)), p_19)) == 0xA0L), p_18, g_33, g_8, l_49) <= 0xE57B790EL) , g_44), l_64, p_18) > p_18);
        }
        else
        { /* block id: 27 */
            uint64_t l_100 = 0x8A7AA087AC20A80BLL;
            int32_t l_101 = 0xBF61A385L;
            int16_t l_106 = 0x3983L;
            l_94 &= (safe_lshift_func_uint16_t_u_u((func_67(p_18, l_71[4], p_19) == g_44), p_19));
            l_39 = (safe_sub_func_uint16_t_u_u((!((safe_lshift_func_uint8_t_u_u(0UL, 2)) || g_33)), p_19));
            l_100 = l_71[1];
            g_109--;
        }
        if ((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((0x9381L || 0x4F58L), p_18)), g_109)))
        { /* block id: 56 */
            l_94 = 0xD8654C91L;
            g_6 = ((safe_mul_func_uint8_t_u_u(l_104, l_94)) >= l_105);
            l_43 |= (safe_div_func_uint64_t_u_u(g_107, 0xA2CB73A7AD93CD92LL));
        }
        else
        { /* block id: 60 */
            l_39 = (p_18 < p_19);
        }
    }
    return g_62[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_33 g_6
 * writes: g_33 g_6
 */
static uint16_t  func_20(uint16_t  p_21, const uint32_t  p_22, int16_t  p_23)
{ /* block id: 5 */
    uint64_t l_27 = 18446744073709551608UL;
    int32_t l_29 = 4L;
    int32_t l_30 = 1L;
    int32_t l_32 = 0xD5D08818L;
    if (g_7)
    { /* block id: 6 */
        uint64_t l_28 = 0xADD635290CE96F8FLL;
        int32_t l_31 = 0L;
        l_28 = (safe_mod_func_uint8_t_u_u(l_27, p_23));
        g_33++;
    }
    else
    { /* block id: 9 */
        uint8_t l_36[6];
        int i;
        for (i = 0; i < 6; i++)
            l_36[i] = 255UL;
        g_6 ^= l_36[4];
        g_6 = l_27;
    }
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_62 g_33 g_6
 * writes: g_33 g_6
 */
static uint32_t  func_50(uint32_t  p_51, const int32_t  p_52, int64_t  p_53, uint32_t  p_54, uint32_t  p_55)
{ /* block id: 22 */
    int32_t l_63 = 1L;
    l_63 = (safe_sub_func_uint32_t_u_u((func_20((g_7 >= 0x0FD77138BF9CC53ALL), g_62[5], p_54) == l_63), 4294967291UL));
    l_63 ^= g_62[5];
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_8 g_33 g_6
 * writes: g_6 g_8
 */
static uint16_t  func_67(int32_t  p_68, uint64_t  p_69, int8_t  p_70)
{ /* block id: 28 */
    const int64_t l_72 = (-7L);
    int32_t l_75 = 4L;
    int32_t l_83 = 0x24C01D5BL;
    g_6 = (l_72 <= 1UL);
    l_75 ^= ((((safe_add_func_uint16_t_u_u((p_70 ^ p_70), 0xC4DBL)) ^ g_7) == 0xCAL) >= l_72);
    if ((247UL > p_70))
    { /* block id: 31 */
        int32_t l_82 = 0x266DE40CL;
        l_83 &= (safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(((((safe_sub_func_uint8_t_u_u(1UL, p_68)) != l_82) > l_82) < l_82), 0x36L)), l_75));
        for (l_82 = (-29); (l_82 != 11); l_82 = safe_add_func_uint64_t_u_u(l_82, 8))
        { /* block id: 35 */
            l_83 = l_82;
        }
        g_6 = (p_69 ^ 1UL);
    }
    else
    { /* block id: 39 */
        int64_t l_90 = (-10L);
        int32_t l_91 = 0x47A7A01CL;
        for (g_8 = 14; (g_8 >= 1); --g_8)
        { /* block id: 42 */
            g_6 = (safe_mod_func_uint64_t_u_u((p_68 == l_90), g_8));
            g_6 = g_8;
        }
        l_91 = (p_68 > g_33);
        g_6 = (p_69 || 0x83L);
    }
    g_6 |= ((safe_lshift_func_uint16_t_u_u(((g_7 < 0x5BD1L) , 0UL), p_68)) == 0xA932E4B48400EC86LL);
    return l_83;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_62[i], "g_62[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_107, "g_107", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_108[i][j][k], "g_108[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_109, "g_109", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 44
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 12
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 11, occurrence: 2
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 96
XXX times a non-volatile is write: 23
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 11
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 42
XXX percentage of non-volatile access: 87.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 45
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 14
   depth: 2, occurrence: 15

XXX percentage a fresh-made variable is used: 30.1
XXX percentage an existing variable is used: 69.9
********************* end of statistics **********************/

