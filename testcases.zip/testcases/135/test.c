/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13739291668385111488
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_2[9][2][9] = {{{4UL,1UL,1UL,4UL,65533UL,0x2A8DL,65533UL,4UL,1UL},{5UL,0x9EDBL,0x1DEDL,0x4455L,0x5273L,0x4455L,0x1DEDL,0x9EDBL,5UL}},{{1UL,4UL,65533UL,0x2A8DL,65533UL,4UL,1UL,1UL,4UL},{0xEB06L,0x4B4EL,0x1DEDL,0x4B4EL,0xEB06L,6UL,0x4FD9L,0x4455L,0x707DL}},{{1UL,65533UL,1UL,0UL,0xE90AL,0xE90AL,0UL,1UL,65533UL},{5UL,0x4455L,0x1DEDL,0x9EDBL,5UL,65528UL,0xEB06L,0x9AE7L,0xEB06L}},{{1UL,0UL,0xE90AL,0xE90AL,0UL,1UL,65533UL,1UL,0UL},{0UL,0x4455L,0xEB06L,0UL,0x5273L,6UL,0x5273L,0UL,0xEB06L}},{{65534UL,65534UL,65533UL,0UL,4UL,0UL,65533UL,65534UL,65534UL},{0xEB06L,0UL,0x5273L,6UL,0x5273L,0UL,0xEB06L,0x4455L,0UL}},{{0UL,1UL,65533UL,1UL,0UL,0xE90AL,0xE90AL,0UL,1UL},{0xEB06L,0x9AE7L,0xEB06L,65528UL,5UL,0x9EDBL,0x1DEDL,0x4455L,0x5273L}},{{65534UL,0x2A8DL,0xE90AL,65533UL,65533UL,0xE90AL,0x2A8DL,65534UL,0x2A8DL},{0UL,6UL,0x1DEDL,65528UL,0x4FD9L,0UL,5UL,0UL,0x4FD9L}},{{1UL,0x2A8DL,0x2A8DL,1UL,65534UL,0UL,65534UL,1UL,0x2A8DL},{0x5273L,0x9AE7L,5UL,6UL,0x707DL,6UL,5UL,0x9AE7L,0x5273L}},{{0x2A8DL,1UL,65534UL,0UL,65534UL,1UL,0x2A8DL,0x2A8DL,1UL},{0x4FD9L,0UL,5UL,0UL,0x4FD9L,65528UL,0x1DEDL,6UL,0UL}}};
static uint64_t g_15 = 1UL;
static int16_t g_19[5][8] = {{0xEA06L,0x23C5L,0xEA06L,0xEA06L,0x23C5L,0xEA06L,0xEA06L,0x23C5L},{0x23C5L,0xEA06L,0xEA06L,0x23C5L,0xEA06L,0xEA06L,0x23C5L,0xEA06L},{0x23C5L,0x23C5L,4L,0x23C5L,0x23C5L,4L,0x23C5L,0x23C5L},{0xEA06L,0x23C5L,0xEA06L,0xEA06L,0x23C5L,0xEA06L,0xEA06L,0x23C5L},{0x23C5L,0xEA06L,0xEA06L,0x23C5L,0xEA06L,0xEA06L,0x23C5L,0xEA06L}};
static volatile uint16_t g_21 = 0xBDB6L;/* VOLATILE GLOBAL g_21 */
static uint16_t g_29 = 0xE65FL;
static uint8_t g_44 = 0xD7L;
static volatile uint8_t g_51 = 0UL;/* VOLATILE GLOBAL g_51 */
static uint64_t g_61 = 0xB7C80BFD7802F47DLL;
static int8_t g_65 = 0L;
static int16_t g_70 = 0xFF1CL;
static int32_t g_72 = 0x495AE89EL;
static volatile int16_t g_75[5] = {(-4L),(-4L),(-4L),(-4L),(-4L)};
static int8_t g_81[2][9][2] = {{{(-1L),(-7L)},{0x94L,(-7L)},{(-1L),0xE4L},{0x94L,0xE4L},{(-1L),(-7L)},{0x94L,(-7L)},{(-1L),0xE4L},{0x94L,0xE4L},{(-1L),(-7L)}},{{0x94L,(-7L)},{(-1L),0xE4L},{0x94L,0xE4L},{(-1L),(-7L)},{0x94L,(-7L)},{(-1L),0xE4L},{0x94L,0xE4L},{(-1L),(-7L)},{0x94L,(-7L)}}};
static uint32_t g_82[7] = {0UL,1UL,0UL,0UL,1UL,0UL,0UL};
static int32_t g_85 = 0x29C5D079L;
static volatile int32_t g_86 = 0x0D248760L;/* VOLATILE GLOBAL g_86 */
static volatile uint16_t g_87 = 0x5112L;/* VOLATILE GLOBAL g_87 */
static uint64_t g_93 = 0xB285EFCBABA1048DLL;
static uint16_t g_96 = 0x3F4CL;
static int64_t g_97 = 0xB769E501E45A2DC9LL;
static uint32_t g_105 = 18446744073709551615UL;
static uint64_t g_112 = 0x72BDA1E5BAC90574LL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_3(int32_t  p_4, uint16_t  p_5, uint64_t  p_6, int8_t  p_7);
static int32_t  func_30(int32_t  p_31, uint64_t  p_32, int64_t  p_33, uint16_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_15 g_21 g_29 g_19 g_44 g_51 g_61 g_82 g_87 g_93 g_86 g_70 g_75 g_85 g_96 g_112 g_72 g_81
 * writes: g_15 g_21 g_29 g_44 g_51 g_61 g_65 g_70 g_82 g_87 g_93 g_96 g_97 g_105 g_85 g_112
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_9 = 0xF3L;
    uint32_t l_24 = 18446744073709551612UL;
    int32_t l_100[7] = {(-1L),(-1L),(-7L),(-1L),(-1L),(-7L),(-1L)};
    int i;
    if (g_2[2][1][6])
    { /* block id: 1 */
        int32_t l_8 = 0L;
        int32_t l_18 = 0x99649744L;
        int32_t l_20 = 0x7F4A1D2DL;
        if (func_3(g_2[1][1][1], l_8, g_2[6][1][2], l_9))
        { /* block id: 16 */
            uint32_t l_35 = 0x954EB856L;
            ++g_21;
            ++l_24;
            g_29 = ((safe_div_func_int16_t_s_s(func_3((g_2[2][0][7] , g_15), g_2[6][1][2], g_15, g_2[2][1][6]), g_2[5][1][2])) | 1UL);
            g_96 = func_30(l_8, l_18, l_8, l_35);
        }
        else
        { /* block id: 55 */
            g_97 = (18446744073709551615UL | g_82[5]);
            return g_86;
        }
        for (g_70 = 0; (g_70 > (-29)); g_70 = safe_sub_func_int64_t_s_s(g_70, 9))
        { /* block id: 61 */
            l_100[3] |= 0L;
        }
        g_105 = (safe_lshift_func_uint8_t_u_s((func_30((safe_div_func_int16_t_s_s(g_19[3][5], g_29)), l_24, l_8, g_82[6]) || g_87), 6));
    }
    else
    { /* block id: 65 */
        int32_t l_113 = 3L;
        uint64_t l_114 = 0xEA799ADA34CB066DLL;
        int32_t l_117 = 1L;
        l_100[1] &= (safe_add_func_int64_t_s_s(g_75[4], 0x334EEA40FDB04FC3LL));
        for (g_85 = (-12); (g_85 >= 26); g_85++)
        { /* block id: 69 */
            g_112 = (safe_lshift_func_int8_t_s_s(((g_70 != l_24) >= 0xD4FE02E2238E951FLL), g_15));
            l_114 &= ((g_96 | l_113) , 2L);
        }
        l_117 = (safe_sub_func_int64_t_s_s(((((func_30((l_114 , (-1L)), g_15, g_112, l_113) <= g_72) < g_19[4][1]) && g_81[1][2][0]) > g_2[8][1][7]), l_100[5]));
    }
    return g_81[0][8][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_15
 * writes: g_15
 */
static int32_t  func_3(int32_t  p_4, uint16_t  p_5, uint64_t  p_6, int8_t  p_7)
{ /* block id: 2 */
    for (p_6 = 28; (p_6 >= 36); p_6 = safe_add_func_uint16_t_u_u(p_6, 1))
    { /* block id: 5 */
        int64_t l_14 = 0x839E071A05132D7ALL;
        if ((safe_rshift_func_int16_t_s_u((l_14 & p_4), g_2[2][1][6])))
        { /* block id: 6 */
            return p_5;
        }
        else
        { /* block id: 8 */
            return p_7;
        }
    }
    p_4 = g_2[1][0][0];
    p_4 = ((250UL | g_2[4][1][4]) | g_2[2][1][6]);
    ++g_15;
    return g_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_29 g_2 g_19 g_15 g_44 g_51 g_61 g_82 g_87 g_93
 * writes: g_44 g_15 g_51 g_61 g_65 g_70 g_82 g_87 g_93
 */
static int32_t  func_30(int32_t  p_31, uint64_t  p_32, int64_t  p_33, uint16_t  p_34)
{ /* block id: 20 */
    int32_t l_43 = 1L;
    int32_t l_45 = (-1L);
    const int8_t l_59 = 0xF5L;
    uint32_t l_68 = 0xA33FE8F1L;
    uint32_t l_71 = 0x49333086L;
    int32_t l_76[8] = {0xC3B14A51L,0xC3B14A51L,0xC3B14A51L,0xC3B14A51L,0xC3B14A51L,0xC3B14A51L,0xC3B14A51L,0xC3B14A51L};
    int i;
    g_44 = (safe_mul_func_int8_t_s_s(((safe_lshift_func_uint16_t_u_u((~(safe_lshift_func_int8_t_s_s(g_21, g_29))), 12)) || g_2[2][1][6]), l_43));
    l_45 = 0xFECEB2CFL;
    if (func_3(g_21, l_45, g_19[4][5], l_43))
    { /* block id: 23 */
        uint16_t l_48 = 0UL;
        int32_t l_49 = 0L;
        int32_t l_50[3][5];
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 5; j++)
                l_50[i][j] = 0xB047C147L;
        }
        for (g_44 = 0; (g_44 <= 1); g_44 += 1)
        { /* block id: 26 */
            p_31 &= (safe_sub_func_uint8_t_u_u(((4294967290UL != g_2[2][1][6]) <= l_48), g_15));
            g_51--;
        }
        for (p_31 = 0; (p_31 <= 2); p_31 += 1)
        { /* block id: 32 */
            uint32_t l_60 = 0x35D6DF81L;
            int32_t l_62 = (-1L);
            g_61 &= (safe_div_func_int16_t_s_s((+((safe_sub_func_int32_t_s_s((((l_59 , g_2[2][1][6]) & g_44) , p_32), l_60)) & g_51)), g_19[3][5]));
            l_62 = g_29;
        }
        g_65 = (safe_sub_func_uint8_t_u_u(g_21, g_15));
    }
    else
    { /* block id: 37 */
        const uint32_t l_69 = 0xA1EA5693L;
        int32_t l_73 = (-10L);
        int32_t l_74 = 0x1BDB030FL;
        for (g_44 = 0; (g_44 < 45); g_44 = safe_add_func_uint8_t_u_u(g_44, 5))
        { /* block id: 40 */
            return l_68;
        }
        g_70 = (p_31 < l_69);
        if (func_3(g_2[2][1][4], p_31, g_51, l_71))
        { /* block id: 44 */
            uint64_t l_77 = 0xEA20016C6A45D312LL;
            int32_t l_80 = 0x354C0A20L;
            l_77++;
            ++g_82[5];
            g_87--;
        }
        else
        { /* block id: 48 */
            const uint8_t l_92 = 253UL;
            p_31 = ((((safe_sub_func_uint16_t_u_u(0x5C77L, l_92)) > 0UL) <= p_34) < 5UL);
        }
        --g_93;
    }
    return g_82[5];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_15, "g_15", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_19[i][j], "g_19[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_75[i], "g_75[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_81[i][j][k], "g_81[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_82[i], "g_82[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 50
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 47
   depth: 2, occurrence: 10
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 6
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 77
XXX times a non-volatile is write: 30
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 56
XXX percentage of non-volatile access: 90.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 45
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 14
   depth: 2, occurrence: 20

XXX percentage a fresh-made variable is used: 38.2
XXX percentage an existing variable is used: 61.8
********************* end of statistics **********************/

