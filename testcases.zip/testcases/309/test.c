/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6665023169463446559
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xFD3DF75DL;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 0x3D7D490CL;
static int16_t g_28 = 1L;
static volatile uint32_t g_31 = 0x88CE324EL;/* VOLATILE GLOBAL g_31 */
static volatile uint16_t g_53 = 0x5671L;/* VOLATILE GLOBAL g_53 */
static uint64_t g_88 = 5UL;
static uint16_t g_132 = 0x3AD1L;
static volatile int8_t g_139 = 0x2FL;/* VOLATILE GLOBAL g_139 */
static int16_t g_141 = 0x073AL;
static volatile int64_t g_144 = 0xEBBB35188A0E647CLL;/* VOLATILE GLOBAL g_144 */
static volatile uint8_t g_145[9] = {4UL,247UL,4UL,4UL,247UL,4UL,4UL,247UL,4UL};
static uint32_t g_148 = 4294967290UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_15(int16_t  p_16, uint16_t  p_17);
static int16_t  func_39(int16_t  p_40, uint8_t  p_41);
static int32_t  func_60(int16_t  p_61, uint64_t  p_62, uint64_t  p_63, uint16_t  p_64, uint32_t  p_65);
static int8_t  func_73(uint8_t  p_74, int16_t  p_75);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_31 g_28 g_53 g_88 g_132 g_145 g_148
 * writes: g_3 g_2 g_31 g_28 g_53 g_88 g_132 g_145 g_148
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_6 = 1L;
    uint32_t l_10[3][2];
    int32_t l_13 = (-5L);
    int32_t l_138 = 0x9BC035BBL;
    int32_t l_142 = 0x0B0106A9L;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
            l_10[i][j] = 4294967295UL;
    }
    for (g_3 = (-1); (g_3 < 18); g_3 = safe_add_func_uint16_t_u_u(g_3, 6))
    { /* block id: 3 */
        uint8_t l_7[2];
        int i;
        for (i = 0; i < 2; i++)
            l_7[i] = 0UL;
        --l_7[0];
        return g_2;
    }
    g_2 = (g_2 >= g_3);
    for (g_3 = 1; (g_3 >= 0); g_3 -= 1)
    { /* block id: 10 */
        int64_t l_14 = 6L;
        int64_t l_18[5][3] = {{0xC257A10DD664087ALL,0xC257A10DD664087ALL,1L},{4L,1L,1L},{1L,0x097BC8B421DD2EB2LL,0x7B09F5954E3F1571LL},{4L,0x097BC8B421DD2EB2LL,4L},{0xC257A10DD664087ALL,1L,0x7B09F5954E3F1571LL}};
        int32_t l_143 = (-7L);
        int i, j;
        for (l_6 = 0; (l_6 <= 1); l_6 += 1)
        { /* block id: 13 */
            l_13 = (safe_mul_func_int8_t_s_s(g_2, 0xD1L));
            return l_14;
        }
        g_132 ^= func_15(g_2, l_18[4][0]);
        for (l_13 = 0; (l_13 <= 1); l_13 += 1)
        { /* block id: 93 */
            if (g_132)
                break;
            if (g_3)
                break;
            g_2 = g_31;
        }
        for (g_28 = 1; (g_28 >= 0); g_28 -= 1)
        { /* block id: 100 */
            uint32_t l_135 = 0xC4BF33FDL;
            int16_t l_136 = 3L;
            int32_t l_137 = 1L;
            int32_t l_140[2];
            int i;
            for (i = 0; i < 2; i++)
                l_140[i] = 0L;
            l_136 = (safe_mul_func_int8_t_s_s(((4294967295UL & l_135) >= 255UL), (-1L)));
            g_145[0]++;
            g_148 &= ((l_140[0] , g_31) , g_2);
        }
    }
    return l_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_28 g_2 g_3 g_53 g_88
 * writes: g_2 g_31 g_28 g_53 g_88
 */
static int32_t  func_15(int16_t  p_16, uint16_t  p_17)
{ /* block id: 17 */
    uint8_t l_19[9] = {246UL,246UL,246UL,246UL,246UL,246UL,246UL,246UL,246UL};
    int32_t l_26 = 0x9C3CBAA6L;
    int64_t l_29 = 6L;
    int32_t l_56 = 0x26771399L;
    int i;
    for (g_2 = 0; g_2 < 9; g_2 += 1)
    {
        l_19[g_2] = 0xEEL;
    }
    for (p_16 = 22; (p_16 <= (-14)); p_16--)
    { /* block id: 21 */
        int32_t l_24 = (-1L);
        int32_t l_27 = 0x2CB818EBL;
        int32_t l_30[6][3] = {{0L,0x7672A6DFL,0L},{0L,0x7672A6DFL,0L},{0L,0x7672A6DFL,0L},{0L,0x7672A6DFL,0L},{0L,0L,1L},{1L,0L,1L}};
        int64_t l_45 = 8L;
        int64_t l_52 = (-1L);
        uint8_t l_57 = 0UL;
        int i, j;
        for (p_17 = 0; (p_17 != 34); p_17++)
        { /* block id: 24 */
            int64_t l_25[4][8] = {{0x2625AA9C4AD1532DLL,1L,1L,1L,0x6E836EA0E402095DLL,0x2625AA9C4AD1532DLL,1L,1L},{0x6E836EA0E402095DLL,0x2625AA9C4AD1532DLL,1L,1L,1L,0x2625AA9C4AD1532DLL,0x6E836EA0E402095DLL,1L},{0L,1L,0xC1543F36FC75DFCCLL,0L,1L,(-1L),1L,1L},{1L,1L,1L,1L,1L,1L,(-9L),1L}};
            int i, j;
            g_31--;
            if (p_17)
                break;
            l_26 = (-2L);
        }
        for (g_28 = 0; (g_28 != (-3)); g_28--)
        { /* block id: 31 */
            int8_t l_36 = 5L;
            l_36 ^= p_16;
            l_30[2][0] |= (safe_mul_func_int16_t_s_s(func_39(p_17, g_31), l_36));
        }
        if (((safe_div_func_uint8_t_u_u(((5L != l_24) ^ l_45), 0xC7L)) && p_16))
        { /* block id: 38 */
            l_30[3][0] = (safe_rshift_func_int8_t_s_u(l_29, p_16));
            return g_3;
        }
        else
        { /* block id: 41 */
            uint16_t l_48 = 6UL;
            int32_t l_49 = 0x3923BFA4L;
            int32_t l_50 = 0L;
            int32_t l_51 = 0x1E8EE622L;
            l_48 &= ((g_3 , 0xCC8FFCACL) ^ p_16);
            --g_53;
            l_57++;
        }
        for (l_26 = 8; (l_26 >= 2); l_26 -= 1)
        { /* block id: 48 */
            int i;
            if (l_19[l_26])
                break;
            l_27 = func_39((func_60(g_3, p_16, l_19[l_26], p_17, g_3) , g_28), p_16);
            l_56 = (safe_div_func_uint16_t_u_u(7UL, p_17));
        }
    }
    l_26 = (safe_unary_minus_func_int8_t_s((safe_rshift_func_uint16_t_u_u(((((func_39((func_73(((safe_mod_func_uint8_t_u_u((safe_add_func_int64_t_s_s((safe_mod_func_uint16_t_u_u(p_17, (-7L))), 0xFF331764C7F453ACLL)), p_17)) ^ l_19[0]), g_53) , g_2), g_3) , 65531UL) , 0x8991D75CL) < l_56) <= 0xA52CL), 8))));
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static int16_t  func_39(int16_t  p_40, uint8_t  p_41)
{ /* block id: 33 */
    int16_t l_42 = (-5L);
    g_2 = (((-1L) & p_40) , g_2);
    return l_42;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_60(int16_t  p_61, uint64_t  p_62, uint64_t  p_63, uint16_t  p_64, uint32_t  p_65)
{ /* block id: 50 */
    int16_t l_66 = 1L;
    int32_t l_67 = 3L;
    l_66 = 3L;
    l_67 = (l_66 ^ p_63);
    return l_66;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_31 g_88 g_3 g_2 g_53
 * writes: g_88 g_2
 */
static int8_t  func_73(uint8_t  p_74, int16_t  p_75)
{ /* block id: 58 */
    int8_t l_86[2];
    uint32_t l_87 = 4294967295UL;
    int32_t l_91 = 0xF6474A04L;
    uint16_t l_99 = 0x3F48L;
    int16_t l_105 = 3L;
    uint8_t l_110 = 0xFDL;
    int32_t l_124 = (-1L);
    int i;
    for (i = 0; i < 2; i++)
        l_86[i] = 0x82L;
lbl_113:
    g_88 |= ((safe_sub_func_int64_t_s_s(((((((((safe_rshift_func_int8_t_s_s(g_28, 3)) , 0UL) >= l_86[0]) & 0L) & 0x37768238A52A621CLL) && 0L) || l_87) || 0UL), g_31)) > 0x27L);
    l_91 = (safe_rshift_func_int16_t_s_s((g_31 & p_74), 10));
    for (p_75 = 0; (p_75 < (-19)); p_75--)
    { /* block id: 63 */
        uint8_t l_104 = 7UL;
        int32_t l_109[2][6][4] = {{{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)}},{{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)},{(-5L),(-1L),(-5L),(-1L)}}};
        int i, j, k;
        if (((((((safe_div_func_int32_t_s_s((+(safe_lshift_func_uint8_t_u_s(1UL, 7))), g_28)) > g_3) == 1L) || g_28) != 65535UL) > g_88))
        { /* block id: 64 */
            uint16_t l_106[8] = {0xF7B6L,0xF7B6L,0xF7B6L,0xF7B6L,0xF7B6L,0xF7B6L,0xF7B6L,0xF7B6L};
            int i;
            ++l_99;
            g_2 |= (((safe_mod_func_int16_t_s_s((((1L | 6UL) > l_104) , g_88), 65526UL)) <= p_75) > p_74);
            ++l_106[1];
            --l_110;
        }
        else
        { /* block id: 69 */
            if (l_99)
                goto lbl_113;
        }
        l_109[1][0][0] = (safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((g_53 , 18446744073709551615UL) , (-1L)), g_3)), 0x0E8CD9E3L));
        l_109[0][0][3] = (safe_lshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u((((p_74 ^ l_109[0][0][3]) && 0xD4D995C8L) <= 0x76D89E43L), p_74)), 7));
    }
    for (g_88 = 0; (g_88 <= 1); g_88 += 1)
    { /* block id: 77 */
        int32_t l_130 = 0xEFBA41DAL;
        for (l_91 = 0; (l_91 <= 1); l_91 += 1)
        { /* block id: 80 */
            int32_t l_131 = 0xAC7FE344L;
            int i;
            l_124 = (safe_lshift_func_int8_t_s_s(l_86[l_91], l_87));
            l_124 = (safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint32_t_u_u(1UL, 1UL)) >= p_74), 8));
            if (p_74)
                continue;
            l_131 = (((((+(((((((((1L && 0x59B86C8BL) != l_87) < l_86[l_91]) < 0x11L) && g_53) && g_53) < l_86[l_91]) < l_91) , l_130)) || g_53) <= l_86[l_91]) ^ p_75) < 2L);
        }
    }
    return g_88;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    transparent_crc(g_144, "g_144", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_145[i], "g_145[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_148, "g_148", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 52
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 60
   depth: 2, occurrence: 18
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 80
XXX times a non-volatile is write: 38
XXX times a volatile is read: 17
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 66
XXX percentage of non-volatile access: 83.1

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 62
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 14
   depth: 2, occurrence: 30

XXX percentage a fresh-made variable is used: 33.1
XXX percentage an existing variable is used: 66.9
********************* end of statistics **********************/

