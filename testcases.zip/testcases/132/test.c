/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7307641862695417199
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0xA6B950BAL;
static uint16_t g_11 = 0UL;
static int16_t g_53 = 0x2AD5L;
static int32_t g_57 = 7L;
static int32_t g_58[10] = {(-3L),(-1L),(-3L),(-3L),(-1L),(-3L),(-3L),(-1L),(-3L),(-3L)};
static int16_t g_59 = (-5L);
static volatile int8_t g_61 = (-3L);/* VOLATILE GLOBAL g_61 */
static volatile int32_t g_63[7] = {0xF7F3414CL,0xF7F3414CL,0xF7F3414CL,0xF7F3414CL,0xF7F3414CL,0xF7F3414CL,0xF7F3414CL};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_4(int64_t  p_5, int32_t  p_6, uint32_t  p_7, int32_t  p_8);
static const int32_t  func_12(uint16_t  p_13, uint16_t  p_14, int16_t  p_15, int32_t  p_16, int16_t  p_17);
static const uint8_t  func_29(int64_t  p_30, uint32_t  p_31, const uint32_t  p_32);
static int16_t  func_35(int8_t  p_36);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_11 g_53 g_58 g_63 g_57 g_59 g_61
 * writes: g_3 g_11 g_53 g_57 g_63 g_59
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2[10] = {0xC184C506L,0x57FD5464L,0x57FD5464L,0xC184C506L,3UL,0xC184C506L,0x57FD5464L,0x57FD5464L,0xC184C506L,3UL};
    int32_t l_111[9] = {0xDACD49A5L,0x8C7CB7DFL,0xDACD49A5L,0x8C7CB7DFL,0xDACD49A5L,0x8C7CB7DFL,0xDACD49A5L,0x8C7CB7DFL,0xDACD49A5L};
    const int32_t l_119 = 0x152D3AD3L;
    int i;
lbl_122:
    for (g_3 = 2; (g_3 <= 9); g_3 += 1)
    { /* block id: 3 */
        uint8_t l_112 = 0UL;
        if (g_3)
            break;
        if (func_4(g_3, l_2[1], l_2[6], l_2[0]))
        { /* block id: 107 */
            --l_112;
        }
        else
        { /* block id: 109 */
            g_57 = (!0xD303A7F8L);
            if (g_57)
                goto lbl_122;
            l_111[3] = l_112;
        }
        l_111[3] = ((safe_lshift_func_int16_t_s_s((((~l_119) < 0x9EL) < 1L), 3)) < l_111[6]);
        g_57 = (safe_sub_func_uint8_t_u_u((l_2[6] || g_11), g_63[2]));
    }
    if (((safe_add_func_int32_t_s_s(((safe_lshift_func_int16_t_s_u((-1L), g_58[5])) < 0UL), g_63[2])) ^ g_11))
    { /* block id: 117 */
        int64_t l_131 = (-2L);
        int32_t l_134[4] = {(-8L),(-8L),(-8L),(-8L)};
        int i;
        g_57 ^= (safe_lshift_func_int8_t_s_u((((safe_lshift_func_int16_t_s_u(0xF09AL, 11)) <= g_63[5]) , l_131), 2));
        g_63[2] = (safe_rshift_func_uint16_t_u_u(l_134[0], 1));
    }
    else
    { /* block id: 120 */
        uint32_t l_141 = 0UL;
        int64_t l_151 = 0xB5CB29808C030507LL;
        g_3 = ((safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((((safe_sub_func_uint16_t_u_u(1UL, l_119)) || l_141) != l_2[8]), 1UL)), 0x71L)) > 0xEBL);
        for (g_53 = 0; (g_53 == 15); g_53++)
        { /* block id: 124 */
            g_63[6] = (safe_mul_func_uint8_t_u_u(1UL, g_11));
        }
        if ((((safe_mod_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((!l_151), 0xF9L)), l_141)) > g_61) & l_119))
        { /* block id: 127 */
            g_57 &= g_63[2];
        }
        else
        { /* block id: 129 */
            g_63[2] = l_151;
            return l_111[3];
        }
    }
    l_111[4] = 0L;
    return l_111[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_11 g_53 g_58 g_63 g_57 g_59
 * writes: g_11 g_53 g_57 g_63 g_59
 */
static int32_t  func_4(int64_t  p_5, int32_t  p_6, uint32_t  p_7, int32_t  p_8)
{ /* block id: 5 */
    int32_t l_9[3][6][7] = {{{0x55A63A74L,0x7C6AE49AL,0x0488F4F3L,0xCC424770L,0x87F6FB80L,0x1F3403CAL,0x998AB545L},{1L,0x1F3403CAL,0xD670012AL,0x1DC6B79DL,0xD670012AL,0x1F3403CAL,1L},{0xE86524F2L,1L,0x7C6AE49AL,0x1DC6B79DL,0x87F6FB80L,0x998AB545L,(-4L)},{(-1L),0x55A63A74L,(-1L),(-4L),0xE86524F2L,0x8A9017CAL,0x8A9017CAL},{(-1L),0xCC424770L,0x7C6AE49AL,0xCC424770L,(-1L),0x0488F4F3L,0x25F5F996L},{0x25F5F996L,0xCC424770L,0xD670012AL,1L,0x1DC6B79DL,(-1L),0xE86524F2L}},{{0xCC424770L,0x55A63A74L,0x1DC6B79DL,1L,0x7C6AE49AL,0x7C6AE49AL,1L},{0x25F5F996L,1L,0x25F5F996L,0x7C6AE49AL,0x998AB545L,0x55A63A74L,1L},{(-1L),0x1F3403CAL,(-1L),0x0488F4F3L,1L,0x25F5F996L,0xE86524F2L},{(-1L),0x25F5F996L,0x55A63A74L,0x1F3403CAL,0x1F3403CAL,0x55A63A74L,0x25F5F996L},{0xE86524F2L,0x87F6FB80L,(-4L),(-1L),0x1F3403CAL,0x7C6AE49AL,0x8A9017CAL},{1L,(-1L),0x87F6FB80L,0xD670012AL,1L,(-1L),(-4L)}},{{0x0488F4F3L,0x998AB545L,(-1L),(-1L),0x998AB545L,0x0488F4F3L,1L},{0x87F6FB80L,(-4L),(-1L),0x1F3403CAL,0x7C6AE49AL,0x8A9017CAL,0x998AB545L},{0x8A9017CAL,1L,0x87F6FB80L,0x0488F4F3L,0x1DC6B79DL,0x998AB545L,0x1DC6B79DL},{0x7C6AE49AL,(-4L),(-4L),0x7C6AE49AL,(-1L),0x1F3403CAL,(-1L)},{0x7C6AE49AL,0x998AB545L,0x55A63A74L,1L,0xE86524F2L,0xD670012AL,(-1L)},{0x8A9017CAL,(-1L),(-1L),1L,0x87F6FB80L,1L,(-1L)}}};
    int i, j, k;
    for (p_8 = 0; (p_8 <= 2); p_8 += 1)
    { /* block id: 8 */
        int8_t l_18 = 1L;
        int32_t l_99 = (-5L);
        int32_t l_100 = 0x81418936L;
        int32_t l_101[6][10] = {{(-1L),(-1L),0x88D6F10EL,0x47F44F2EL,(-1L),0xA325B7F8L,0x47F44F2EL,0x47F44F2EL,0xA325B7F8L,(-1L)},{(-1L),1L,1L,(-1L),(-5L),1L,0x47F44F2EL,(-5L),(-5L),0x47F44F2EL},{(-5L),(-1L),1L,1L,(-1L),(-5L),1L,0x47F44F2EL,(-5L),(-5L)},{(-1L),0x47F44F2EL,0x88D6F10EL,(-1L),(-1L),0x88D6F10EL,0x47F44F2EL,(-1L),0xA325B7F8L,0x47F44F2EL},{(-1L),(-5L),1L,0x47F44F2EL,(-5L),(-5L),0x47F44F2EL,1L,(-5L),(-1L)},{(-5L),0x47F44F2EL,1L,(-5L),(-1L),1L,1L,(-1L),(-5L),1L}};
        uint16_t l_104 = 0xBF25L;
        int i, j;
        if ((g_3 && g_3))
        { /* block id: 9 */
            uint16_t l_10 = 0xD8D9L;
            int64_t l_19[10];
            int i;
            for (i = 0; i < 10; i++)
                l_19[i] = (-1L);
            l_10 ^= p_7;
            g_11 = l_9[0][3][4];
            l_9[1][5][0] = ((g_11 && 0x6D54EC7E318B4743LL) , (-1L));
            l_9[2][2][0] = func_12(l_18, g_11, l_19[1], l_19[1], l_9[0][5][3]);
        }
        else
        { /* block id: 92 */
            int8_t l_102 = 0xB0L;
            int32_t l_103[8];
            int64_t l_109 = 1L;
            int32_t l_110 = 0x156C71AAL;
            int i;
            for (i = 0; i < 8; i++)
                l_103[i] = 1L;
            l_104++;
            l_100 = (((g_57 < l_101[2][1]) < g_53) >= p_7);
            l_109 ^= (safe_sub_func_uint32_t_u_u(((p_8 || 0xD4C4AE1A5ED94E99LL) && (-4L)), (-4L)));
            l_110 &= ((l_101[0][9] <= l_18) , l_103[3]);
        }
        l_100 = (((l_9[0][3][6] != p_6) && 0xAFCDE767DA599C36LL) >= l_101[0][6]);
        for (l_100 = 2; (l_100 >= 0); l_100 -= 1)
        { /* block id: 101 */
            l_101[2][1] &= (-1L);
            return p_8;
        }
    }
    return g_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_3 g_53 g_58 g_63 g_57 g_59
 * writes: g_11 g_53 g_57 g_63 g_59
 */
static const int32_t  func_12(uint16_t  p_13, uint16_t  p_14, int16_t  p_15, int32_t  p_16, int16_t  p_17)
{ /* block id: 13 */
    uint8_t l_20 = 0x21L;
    int32_t l_95 = 0L;
    l_20 = g_11;
lbl_98:
    for (p_16 = 0; (p_16 >= (-17)); p_16--)
    { /* block id: 17 */
        for (p_13 = 1; (p_13 >= 60); ++p_13)
        { /* block id: 20 */
            if (p_17)
                break;
            g_63[2] = (safe_add_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(func_29((((safe_add_func_int32_t_s_s((func_35(p_13) || p_15), 4294967295UL)) | 0x0544DDA6L) , p_15), l_20, p_17), g_58[5])), 0x5DL));
        }
    }
    if (p_13)
    { /* block id: 64 */
        volatile uint16_t l_87 = 0x68E9L;/* VOLATILE GLOBAL l_87 */
        l_87 = g_63[2];
        for (g_59 = 5; (g_59 >= 0); g_59 -= 1)
        { /* block id: 68 */
            int i;
            return g_63[g_59];
        }
    }
    else
    { /* block id: 71 */
        uint32_t l_90 = 0x6241912EL;
        for (l_20 = 0; (l_20 <= 9); l_20 += 1)
        { /* block id: 74 */
            int i;
            l_90 |= ((safe_div_func_uint8_t_u_u(g_58[l_20], g_58[l_20])) & g_58[l_20]);
            l_95 = (safe_rshift_func_int16_t_s_u(((((((safe_mod_func_int16_t_s_s((0xB8C7L & g_53), g_11)) , g_11) && g_58[3]) | (-8L)) < p_13) >= l_90), g_58[l_20]));
        }
        for (g_11 = (-5); (g_11 <= 22); g_11 = safe_add_func_uint8_t_u_u(g_11, 5))
        { /* block id: 80 */
            if (g_3)
                goto lbl_98;
        }
        for (p_15 = 0; (p_15 <= 6); p_15 += 1)
        { /* block id: 85 */
            int i;
            return g_63[p_15];
        }
        l_95 = (-5L);
    }
    return l_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_58 g_53 g_63 g_57 g_11
 * writes: g_53 g_57 g_63
 */
static const uint8_t  func_29(int64_t  p_30, uint32_t  p_31, const uint32_t  p_32)
{ /* block id: 46 */
    uint64_t l_77 = 0x8C06C6856C279493LL;
    int32_t l_78 = 0xED47904AL;
    int32_t l_81 = (-4L);
    uint16_t l_84 = 65533UL;
    l_78 = ((((l_77 , 0xD154C37BL) , l_77) >= g_58[5]) || p_32);
    for (l_78 = 19; (l_78 >= (-23)); --l_78)
    { /* block id: 50 */
        l_81 = 4L;
        for (g_53 = (-11); (g_53 <= 24); ++g_53)
        { /* block id: 54 */
            g_57 ^= ((g_63[1] || l_81) <= 0UL);
        }
    }
    g_57 = ((p_31 != 0x4F1AD9D6L) | l_84);
    g_63[6] = (((((safe_lshift_func_uint8_t_u_s((((((((((g_63[2] | g_53) | g_11) >= l_78) , 0x23B59FD8L) , 1L) & 0x9F8FL) , p_30) >= g_58[0]) || l_78), 5)) | g_11) ^ p_30) ^ (-1L)) , 0L);
    return l_78;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_3 g_53
 * writes: g_11
 */
static int16_t  func_35(int8_t  p_36)
{ /* block id: 22 */
    int16_t l_37[1];
    int32_t l_46 = 0L;
    int32_t l_62[5];
    int64_t l_65 = (-1L);
    uint32_t l_73 = 0x1A6A6FFDL;
    int i;
    for (i = 0; i < 1; i++)
        l_37[i] = (-9L);
    for (i = 0; i < 5; i++)
        l_62[i] = (-1L);
    for (g_11 = 0; (g_11 <= 0); g_11 += 1)
    { /* block id: 25 */
        int i;
        if ((l_37[g_11] ^ 65535UL))
        { /* block id: 26 */
            int i;
            return l_37[g_11];
        }
        else
        { /* block id: 28 */
            int16_t l_45 = 0x9274L;
            l_46 ^= (safe_lshift_func_uint8_t_u_s((safe_add_func_int64_t_s_s((safe_mul_func_int16_t_s_s(((((~(1UL != l_45)) , 0xFCL) == g_3) ^ 3L), g_3)), p_36)), 2));
        }
    }
    for (g_11 = 8; (g_11 <= 40); g_11 = safe_add_func_uint32_t_u_u(g_11, 9))
    { /* block id: 34 */
        uint32_t l_54 = 1UL;
        int32_t l_60[8][6][5] = {{{(-10L),0xD2985DA4L,0x6A56D104L,8L,0x6DAC17B1L},{0x459084C0L,0xEF6BE7A0L,0x800BCFD7L,0xD2985DA4L,0x55039576L},{1L,(-7L),0x11162BCAL,(-7L),0x6B90ED9AL},{0L,0xADAB70C6L,0x11162BCAL,0x21EB82DDL,0x4405C6DFL},{1L,7L,6L,(-3L),0x983B7C1FL},{1L,0xD1A96CE5L,0L,0xA9B06ECFL,1L}},{{0xCF92AC6BL,7L,3L,0xF30550D7L,0x1B334FE9L},{8L,0xADAB70C6L,0x8D59A436L,0xADAB70C6L,8L},{8L,(-7L),0x6206571FL,0x43214E45L,0L},{0xCF92AC6BL,(-1L),1L,(-5L),0x0B496A2AL},{1L,0x05DEF9EEL,0x6AF6502FL,(-7L),0L},{1L,(-5L),1L,0x1E4A2643L,8L}},{{0L,0xA9B06ECFL,0xD1FAEF75L,0x1E4A2643L,0x1B334FE9L},{0xA62E52ABL,0L,(-1L),(-7L),1L},{0x0B496A2AL,(-9L),0xD4E1BE66L,(-5L),0x983B7C1FL},{0xA73003F8L,0L,(-1L),0x43214E45L,0x4405C6DFL},{0x6B01FE44L,0xE5592ED9L,0xD1FAEF75L,0xADAB70C6L,0x6B90ED9AL},{0x983B7C1FL,0xE5592ED9L,1L,0xF30550D7L,(-1L)}},{{0L,0L,0x6AF6502FL,0xA9B06ECFL,(-2L)},{0L,(-9L),1L,(-3L),0xA2EA94A5L},{0L,0L,0x6206571FL,0x21EB82DDL,0xCF92AC6BL},{0x983B7C1FL,0xA9B06ECFL,0x8D59A436L,(-7L),0xCF92AC6BL},{0x6B01FE44L,(-5L),3L,0x05DEF9EEL,0xA2EA94A5L},{0xA73003F8L,0x05DEF9EEL,0L,7L,(-2L)}},{{0x0B496A2AL,(-1L),6L,0x05DEF9EEL,(-1L)},{0xA62E52ABL,(-7L),0x11162BCAL,(-7L),0x6B90ED9AL},{0L,0xADAB70C6L,0x11162BCAL,0x21EB82DDL,0x4405C6DFL},{1L,7L,6L,(-3L),0x983B7C1FL},{1L,0xD1A96CE5L,0L,0xA9B06ECFL,1L},{0xCF92AC6BL,7L,3L,0xF30550D7L,0x1B334FE9L}},{{8L,0xADAB70C6L,0x8D59A436L,0xADAB70C6L,8L},{8L,(-7L),0x6206571FL,0x43214E45L,0L},{0xCF92AC6BL,(-1L),1L,(-5L),0x0B496A2AL},{1L,0x05DEF9EEL,0x6AF6502FL,(-7L),0L},{1L,(-5L),1L,0x1E4A2643L,8L},{0L,0xA9B06ECFL,0xD1FAEF75L,0x1E4A2643L,0x1B334FE9L}},{{0xA62E52ABL,0L,(-1L),(-7L),1L},{0x0B496A2AL,(-9L),0xD4E1BE66L,(-5L),0x983B7C1FL},{0xA73003F8L,0L,(-1L),0x43214E45L,0x4405C6DFL},{0x6B01FE44L,0xE5592ED9L,0xD1FAEF75L,0xADAB70C6L,0x6B90ED9AL},{0x983B7C1FL,0L,0x82E32560L,0xAE622E34L,0xEF091AFFL},{0x43214E45L,0xA74F5703L,0xEF8C34F7L,0x4391DAA6L,(-7L)}},{{0L,0x2817ACDDL,0xCFC28C89L,(-1L),(-7L)},{0x43214E45L,(-1L),0x7B260EC6L,0L,0xA9B06ECFL},{0x66C839C7L,0x4391DAA6L,1L,(-3L),0xA9B06ECFL},{0xADAB70C6L,0x113E7BE8L,0x037DE7B4L,4L,(-7L)},{0L,4L,0x07F0789CL,0x6A56D104L,(-7L)},{0xEA8900E2L,1L,(-1L),4L,0xEF091AFFL}}};
        int i, j, k;
        if (p_36)
            break;
        if ((safe_mul_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(p_36, l_37[0])) != g_53), 0x9E59L)))
        { /* block id: 36 */
            int16_t l_64[9] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
            uint32_t l_66[2][9][10] = {{{0xC2307931L,0x9F9BF173L,1UL,0xA2D252A4L,4294967290UL,0x0A5080F1L,0xBD0DCC65L,4294967295UL,4294967295UL,0x298C9807L},{4294967295UL,0xABC3D1A6L,0x9282FEEDL,0x7F3E9DA8L,0x0A5080F1L,0xA2D252A4L,0x9B496B13L,0xA2D252A4L,0x0A5080F1L,0x7F3E9DA8L},{7UL,0xB885461AL,7UL,0xBD0DCC65L,4294967290UL,4294967295UL,0xD1409FA7L,0xABC3D1A6L,4UL,0x4516B2CFL},{0x8E595DB7L,0x4516B2CFL,4294967295UL,4294967295UL,6UL,0x9282FEEDL,0x0A5080F1L,0xABC3D1A6L,4294967290UL,0x03213856L},{0xE657869FL,0x9B496B13L,7UL,0x8E595DB7L,4UL,0x298C9807L,0xA2D252A4L,0xA2D252A4L,0x298C9807L,4UL},{1UL,0x9282FEEDL,0x9282FEEDL,1UL,0x4516B2CFL,0x3EA2BDD4L,4294967295UL,4294967295UL,0xC2307931L,0x9076915CL},{0x9B496B13L,4294967295UL,1UL,6UL,0x8E595DB7L,4294967290UL,0x9282FEEDL,4294967295UL,0xC2307931L,0xB885461AL},{0xB885461AL,4UL,0xC2307931L,1UL,0x03213856L,0x9F9BF173L,0x298C9807L,4294967295UL,0x298C9807L,0x9F9BF173L},{0x9282FEEDL,0x8E595DB7L,0xE657869FL,0x8E595DB7L,0x9282FEEDL,7UL,0x3EA2BDD4L,0x9F9BF173L,4294967290UL,6UL}},{{0x099C3224L,0x8F5DBB77L,0x0A5080F1L,4294967295UL,0x3EA2BDD4L,0xE657869FL,4294967290UL,4294967290UL,4UL,6UL},{4294967290UL,4294967295UL,0x298C9807L,0xBD0DCC65L,0x9282FEEDL,0x9076915CL,0x9F9BF173L,0x0A5080F1L,0x0A5080F1L,0x9F9BF173L},{4294967295UL,0x03213856L,0x7F3E9DA8L,0x7F3E9DA8L,0x03213856L,4294967295UL,7UL,4294967290UL,4294967295UL,0xB885461AL},{4294967295UL,0xD1409FA7L,0x4516B2CFL,0xA2D252A4L,0x8E595DB7L,0xC2307931L,0xE657869FL,6UL,0x099C3224L,0x9076915CL},{4294967295UL,0xBD0DCC65L,0x03213856L,0x9B496B13L,0x4516B2CFL,4294967295UL,0x9076915CL,4UL,0x9F9BF173L,4UL},{4294967295UL,0x9076915CL,4UL,0x0A5080F1L,4294967295UL,4294967295UL,0x8E595DB7L,0xB885461AL,4294967290UL,0x7F3E9DA8L},{0xC2307931L,0xA2D252A4L,4294967295UL,4294967290UL,0x3EA2BDD4L,0x9076915CL,0xABC3D1A6L,0x03213856L,6UL,0xB885461AL},{4294967290UL,0xA2D252A4L,1UL,0x9F9BF173L,0xC2307931L,0x099C3224L,0x8E595DB7L,0x7F3E9DA8L,4UL,4UL},{0xD1409FA7L,4294967295UL,0x0A5080F1L,4294967295UL,4294967295UL,0x0A5080F1L,4294967295UL,0xD1409FA7L,0x4516B2CFL,0xA2D252A4L}}};
            int32_t l_69 = 0x5792D6E4L;
            int32_t l_70 = (-2L);
            int32_t l_71 = 0L;
            int32_t l_72 = 9L;
            int i, j, k;
            ++l_54;
            l_46 ^= p_36;
            ++l_66[0][1][8];
            ++l_73;
        }
        else
        { /* block id: 41 */
            int32_t l_76 = 0x8E84D414L;
            l_46 = (l_60[2][3][1] < l_76);
        }
    }
    return g_11;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_58[i], "g_58[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_63[i], "g_63[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 73
   depth: 2, occurrence: 19
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 6
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 111
XXX times a non-volatile is write: 47
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 86
XXX percentage of non-volatile access: 90.8

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 75
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 24
   depth: 2, occurrence: 33

XXX percentage a fresh-made variable is used: 17.9
XXX percentage an existing variable is used: 82.1
********************* end of statistics **********************/

