/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17154570935581418686
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_7 = 0UL;
static const uint16_t g_9[8] = {1UL,0x66A0L,1UL,1UL,0x66A0L,1UL,1UL,0x66A0L};
static int16_t g_14 = (-1L);
static int64_t g_25[5] = {0x818F8F6A1C3D076CLL,0x818F8F6A1C3D076CLL,0x818F8F6A1C3D076CLL,0x818F8F6A1C3D076CLL,0x818F8F6A1C3D076CLL};
static volatile uint16_t g_28 = 0x054FL;/* VOLATILE GLOBAL g_28 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint8_t  func_17(int8_t  p_18, uint64_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_9 g_14 g_25 g_28
 * writes: g_14 g_25 g_28
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_8 = 0xCE4562513244D513LL;
    int32_t l_10 = 2L;
    uint32_t l_11[9] = {18446744073709551614UL,0x1B583DC0L,18446744073709551614UL,0x1B583DC0L,18446744073709551614UL,0x1B583DC0L,18446744073709551614UL,0x1B583DC0L,18446744073709551614UL};
    uint64_t l_31 = 0x648A57461D0EE3B0LL;
    int i;
    l_10 ^= (safe_mod_func_uint16_t_u_u(((((safe_unary_minus_func_int16_t_s(((safe_lshift_func_uint16_t_u_s(65535UL, g_7)) & g_7))) >= g_7) == 9UL) < l_8), g_9[7]));
    for (l_8 = 0; (l_8 <= 8); l_8 += 1)
    { /* block id: 4 */
        uint64_t l_24 = 0UL;
        for (l_10 = 8; (l_10 >= 3); l_10 -= 1)
        { /* block id: 7 */
            int i;
            if (l_11[l_10])
                break;
        }
        g_14 = ((safe_rshift_func_int8_t_s_s(l_11[6], 0)) , g_7);
        g_25[4] = (safe_mod_func_uint8_t_u_u((func_17(g_9[7], g_14) != l_24), 0x50L));
        return l_11[6];
    }
    l_10 = (((safe_mul_func_uint8_t_u_u((l_8 , l_8), g_25[4])) || g_14) || g_7);
    --g_28;
    return l_31;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_17(int8_t  p_18, uint64_t  p_19)
{ /* block id: 11 */
    uint32_t l_20[10] = {0x22ABAC89L,0x22ABAC89L,1UL,0x22ABAC89L,0x22ABAC89L,1UL,0x22ABAC89L,0x22ABAC89L,1UL,0x22ABAC89L};
    int32_t l_23 = 0xD6446BD2L;
    int i;
    l_20[8]++;
    l_23 ^= l_20[8];
    return p_18;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_14, "g_14", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 96.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 4
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 42.3
XXX percentage an existing variable is used: 57.7
********************* end of statistics **********************/

