/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1308494626489908249
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_14[6] = {0x45F5B1B6FD43DDCALL,0x45F5B1B6FD43DDCALL,0x45F5B1B6FD43DDCALL,0x45F5B1B6FD43DDCALL,0x45F5B1B6FD43DDCALL,0x45F5B1B6FD43DDCALL};
static uint16_t g_21 = 0x42C7L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_4(uint32_t  p_5);
static uint32_t  func_6(uint64_t  p_7, uint32_t  p_8, int32_t  p_9);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_21
 * writes: g_21
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_10 = 0x2DF3D37A5B7D8CF4LL;
    uint32_t l_25 = 1UL;
    l_25 = ((((safe_mod_func_int32_t_s_s((func_4(func_6(l_10, l_10, l_10)) != 0L), g_14[0])) ^ g_14[5]) ^ l_10) < g_14[0]);
    return l_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_21
 * writes: g_21
 */
static int64_t  func_4(uint32_t  p_5)
{ /* block id: 5 */
    uint16_t l_16 = 1UL;
    int32_t l_20[7];
    int i;
    for (i = 0; i < 7; i++)
        l_20[i] = 0x37AE9F90L;
    for (p_5 = 0; (p_5 <= 5); p_5 += 1)
    { /* block id: 8 */
        int8_t l_19 = 3L;
        if (p_5)
            break;
        l_16 = (-1L);
        if (p_5)
            goto lbl_24;
        l_19 = ((safe_mod_func_int16_t_s_s((l_16 < g_14[5]), g_14[1])) <= g_14[3]);
    }
    --g_21;
lbl_24:
    l_20[1] = p_5;
    l_20[5] = (p_5 ^ g_14[4]);
    return g_14[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes:
 */
static uint32_t  func_6(uint64_t  p_7, uint32_t  p_8, int32_t  p_9)
{ /* block id: 1 */
    int32_t l_11 = 0x59310C13L;
    int32_t l_15 = 0x4A11600DL;
    p_9 = l_11;
    l_15 = ((safe_mod_func_uint16_t_u_u(0x3785L, p_8)) , g_14[3]);
    return l_15;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 30
XXX percentage an existing variable is used: 70
********************* end of statistics **********************/

