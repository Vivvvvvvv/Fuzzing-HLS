/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3013387595343107147
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 1L;
static volatile int32_t g_6 = 4L;/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7 = 1L;/* VOLATILE GLOBAL g_7 */
static volatile int32_t g_8 = 0x88CB5C74L;/* VOLATILE GLOBAL g_8 */
static int32_t g_9 = (-3L);


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_9 g_8 g_6
 * writes: g_2 g_9 g_8
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_5[7][9][4] = {{{65534UL,65535UL,1UL,0x0BDBL},{0xDDCDL,0xEF33L,65535UL,1UL},{65533UL,65529UL,0xBE18L,0x8483L},{0xBE18L,0x8483L,0x3049L,5UL},{1UL,1UL,1UL,0UL},{0x2FB2L,1UL,0xD0E7L,0xD564L},{0x6EDAL,65532UL,0x753FL,1UL},{65535UL,0xACD4L,0UL,0xCCE4L},{0UL,0x9B8DL,65532UL,5UL}},{{0xEF33L,0UL,0x4CE3L,0xB24AL},{1UL,0x7B7FL,1UL,0x99F2L},{65532UL,0xEF33L,2UL,0x0D79L},{0xFF79L,1UL,0x9501L,5UL},{65531UL,65535UL,65534UL,1UL},{0xB24AL,65527UL,0xACD4L,65527UL},{1UL,0UL,65535UL,0xCE4BL},{65530UL,65532UL,65535UL,0xC842L},{0x0BDBL,0x34CCL,0UL,65533UL}},{{0x7528L,1UL,65527UL,0UL},{0x03FAL,0x0CD9L,0x0002L,6UL},{65535UL,65535UL,0x885EL,0x3AC4L},{0x6D8FL,65532UL,0xBE18L,65535UL},{0UL,65532UL,0xD564L,1UL},{0x99F2L,5UL,7UL,1UL},{0xF34FL,1UL,65529UL,0xAC9DL},{0xA7ECL,65529UL,0x5A16L,0xEE72L},{65529UL,65534UL,0x6F44L,0x885EL}},{{1UL,1UL,0xD564L,0UL},{0x9501L,1UL,1UL,0x9501L},{65533UL,65534UL,0x21A0L,65534UL},{65535UL,0x88D9L,0xEE72L,0x5A16L},{65535UL,1UL,5UL,0x5A16L},{0x6944L,0x88D9L,0UL,65534UL},{0xBFD0L,65534UL,0xA7ECL,0x9501L},{65532UL,1UL,0xBE18L,0UL},{1UL,1UL,0x3AC4L,0x885EL}},{{0x8483L,65534UL,65533UL,0xEE72L},{65532UL,65529UL,0x9501L,0xAC9DL},{1UL,1UL,0UL,1UL},{1UL,5UL,1UL,1UL},{1UL,65532UL,0xCE4BL,65535UL},{1UL,65532UL,1UL,0x3AC4L},{0x3DF2L,65535UL,0UL,6UL},{1UL,0x0CD9L,0UL,0UL},{0UL,1UL,65535UL,65533UL}},{{65535UL,0x34CCL,2UL,0xC842L},{1UL,65532UL,0UL,0xCE4BL},{1UL,0UL,0xD564L,65527UL},{6UL,65527UL,1UL,1UL},{0x6652L,65535UL,0x7B7FL,5UL},{0xA7ECL,1UL,4UL,0x0D79L},{0x4498L,65534UL,65534UL,2UL},{0x3BEDL,0x34C2L,0xD564L,5UL},{0UL,0UL,5UL,0x9501L}},{{0x9B8DL,65533UL,65535UL,0x6F44L},{65535UL,0x2AFDL,0xF51AL,65535UL},{0x18F4L,1UL,0xAC9DL,4UL},{0x0452L,65534UL,0UL,1UL},{0xD0E7L,6UL,65527UL,0x9501L},{0x2FB2L,0xD564L,1UL,0xD564L},{0xFF79L,0x6D8FL,0xDDCDL,0UL},{0UL,0xA7ECL,0x3BEDL,0x34CCL},{0x3AC4L,0UL,0x7B7FL,1UL}}};
    int32_t l_11 = 0x4E719BA7L;
    int i, j, k;
    for (g_2 = 0; (g_2 <= (-27)); g_2 = safe_sub_func_int16_t_s_s(g_2, 9))
    { /* block id: 3 */
        int32_t l_10 = 9L;
        int32_t l_12 = (-2L);
        int16_t l_13 = 0x0EB1L;
        uint32_t l_14 = 0UL;
        for (g_9 = 3; (g_9 >= 0); g_9 -= 1)
        { /* block id: 6 */
            l_14++;
        }
        g_9 &= (safe_mod_func_int16_t_s_s((((safe_rshift_func_int8_t_s_u(g_8, 0)) != 0UL) , g_6), 5UL));
        g_8 = (safe_rshift_func_int16_t_s_u(g_6, g_2));
        return g_2;
    }
    return g_8;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 5
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 6
   depth: 2, occurrence: 3
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 4
XXX times a non-volatile is write: 4
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 12
XXX percentage of non-volatile access: 61.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 4
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 31.2
XXX percentage an existing variable is used: 68.8
********************* end of statistics **********************/

