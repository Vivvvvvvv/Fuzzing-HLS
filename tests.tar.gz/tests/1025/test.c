/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3017715005678444933
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_11[6][7] = {{0x21A35CA4L,0L,0x15362DAAL,0L,0x15362DAAL,0L,0x21A35CA4L},{0L,0x6F3F17E2L,(-6L),8L,0L,1L,0x21A35CA4L},{0L,0x21A35CA4L,1L,1L,0x21A35CA4L,0L,0L},{0L,1L,(-6L),0L,5L,0L,0L},{8L,5L,0x15362DAAL,5L,8L,1L,0L},{0x53E58BFCL,1L,0L,0x6F3F17E2L,8L,0L,8L}};
static int16_t g_17 = 1L;
static uint32_t g_33 = 4294967294UL;
static volatile uint32_t g_36 = 4294967289UL;/* VOLATILE GLOBAL g_36 */
static int64_t g_47 = 0L;
static int32_t g_49 = (-8L);
static int32_t g_128 = 1L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, int32_t  p_4, uint32_t  p_5, int8_t  p_6);
static uint64_t  func_7(int32_t  p_8, uint32_t  p_9);
static int32_t  func_18(int64_t  p_19, uint64_t  p_20, uint32_t  p_21, uint64_t  p_22, const int32_t  p_23);
static int32_t  func_51(uint8_t  p_52, int64_t  p_53, const int64_t  p_54);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_17 g_33 g_36 g_47 g_49
 * writes: g_33 g_36 g_47 g_49 g_128
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_10 = 0xA5043C4AB274BF90LL;
    int32_t l_50 = 0x0F1B6398L;
    l_50 ^= func_2(func_7((7L && l_10), g_11[1][2]), l_10, l_10, g_17);
    g_128 = func_51(g_33, g_11[2][0], g_11[2][2]);
    return g_49;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_17 g_33 g_36 g_47
 * writes: g_33 g_36 g_47 g_49
 */
static int32_t  func_2(uint64_t  p_3, int32_t  p_4, uint32_t  p_5, int8_t  p_6)
{ /* block id: 13 */
    int64_t l_28 = 0xF738F585950CFDFELL;
    int16_t l_29 = 0x9935L;
    if (func_18((safe_mod_func_int8_t_s_s((safe_mul_func_uint8_t_u_u(((func_7(l_28, p_6) > p_4) && l_28), l_28)), g_17)), g_17, l_29, p_3, l_28))
    { /* block id: 17 */
        uint8_t l_46 = 1UL;
        for (g_33 = 27; (g_33 > 40); ++g_33)
        { /* block id: 20 */
            uint16_t l_39 = 65534UL;
            --g_36;
            l_39 |= 0L;
        }
        if (((safe_mul_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_u((func_18(((safe_sub_func_uint64_t_u_u(((g_33 || l_29) < g_11[4][5]), 0x9AEA1DC7E9069002LL)) == l_28), p_6, p_5, g_33, p_5) && l_28), 4)) | 65528UL), l_29)) == l_46))
        { /* block id: 24 */
            return p_4;
        }
        else
        { /* block id: 26 */
            return g_11[2][4];
        }
    }
    else
    { /* block id: 29 */
        uint64_t l_48 = 18446744073709551615UL;
        g_47 ^= (p_5 <= 1L);
        g_49 = (((((l_29 , l_48) && 0x8D212595L) <= 0x43L) < 3UL) , p_6);
        return g_47;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes:
 */
static uint64_t  func_7(int32_t  p_8, uint32_t  p_9)
{ /* block id: 1 */
    uint64_t l_12 = 0x1F145BA13B288586LL;
    l_12 ^= (1L < 0UL);
    for (p_9 = 0; (p_9 < 24); p_9 = safe_add_func_int8_t_s_s(p_9, 9))
    { /* block id: 5 */
        for (p_8 = 0; (p_8 == (-30)); p_8--)
        { /* block id: 8 */
            return g_11[4][0];
        }
    }
    return g_11[1][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes: g_33
 */
static int32_t  func_18(int64_t  p_19, uint64_t  p_20, uint32_t  p_21, uint64_t  p_22, const int32_t  p_23)
{ /* block id: 14 */
    int64_t l_32[8];
    int i;
    for (i = 0; i < 8; i++)
        l_32[i] = 0x06ED55C59C3F9080LL;
    g_33 = (safe_mul_func_uint8_t_u_u((g_11[1][2] , g_11[0][1]), l_32[7]));
    return l_32[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_47 g_33 g_17 g_36 g_49
 * writes: g_49 g_47
 */
static int32_t  func_51(uint8_t  p_52, int64_t  p_53, const int64_t  p_54)
{ /* block id: 35 */
    uint8_t l_55[8][2][10] = {{{0x3BL,0x3DL,0xFFL,255UL,1UL,9UL,246UL,0UL,0x99L,253UL},{0x7BL,0x49L,255UL,0x3BL,255UL,0x66L,1UL,255UL,3UL,0UL}},{{255UL,0x49L,3UL,1UL,5UL,1UL,246UL,253UL,0x11L,255UL},{0UL,9UL,0x3BL,0xFFL,0x9DL,255UL,0x63L,0x63L,255UL,0x9DL}},{{1UL,5UL,5UL,1UL,0x99L,0x3BL,1UL,0x86L,0x04L,1UL},{0x49L,0xFFL,1UL,0xB9L,255UL,1UL,5UL,1UL,0x04L,0x63L}},{{5UL,0UL,253UL,1UL,0xB9L,0xC5L,0x99L,0x66L,255UL,0x7BL},{0xBFL,5UL,0x11L,0xFFL,0x20L,5UL,0x20L,0xFFL,0x11L,5UL}},{{255UL,0x8AL,246UL,1UL,1UL,0UL,9UL,0x9DL,3UL,0x86L},{0UL,4UL,0UL,0x3BL,0x63L,0UL,1UL,255UL,0x99L,0x49L}},{{255UL,0x3DL,0x86L,255UL,247UL,5UL,255UL,246UL,0xBFL,0xBFL},{0xBFL,1UL,0xC5L,3UL,3UL,0xC5L,1UL,0xBFL,0x49L,0x99L}},{{5UL,1UL,0xB9L,0UL,0x3DL,1UL,0x49L,0x3BL,0x86L,3UL},{0x49L,0UL,0xB9L,0x3DL,246UL,0x3BL,0x66L,0xBFL,5UL,0x11L}},{{1UL,0xB9L,0xC5L,0x99L,0x66L,255UL,0x7BL,246UL,0x7BL,255UL},{0UL,255UL,0x86L,255UL,0UL,1UL,0x11L,255UL,0x63L,0x04L}}};
    int32_t l_65[3];
    uint16_t l_85 = 0UL;
    const uint16_t l_90 = 65528UL;
    uint8_t l_97 = 1UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_65[i] = 0x47F9ABEFL;
lbl_69:
    l_55[7][0][1] ^= p_52;
    if ((((((0x19L && g_11[2][3]) >= 4L) , l_55[5][0][5]) != g_47) | 0x15L))
    { /* block id: 37 */
        int32_t l_58 = 0xF2CFEAA3L;
        int64_t l_75 = (-3L);
        int32_t l_86 = 0L;
        l_58 |= ((safe_sub_func_uint8_t_u_u(g_11[1][2], 0x8CL)) , 7L);
        for (p_53 = 0; (p_53 >= 19); p_53 = safe_add_func_uint64_t_u_u(p_53, 5))
        { /* block id: 41 */
            if (p_53)
                break;
            return g_33;
        }
lbl_87:
        if ((((safe_rshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(((g_17 >= 0x5676L) | l_58), g_11[1][2])), g_36)) || p_53) < p_54))
        { /* block id: 45 */
            uint16_t l_66 = 1UL;
            ++l_66;
            if (p_54)
                goto lbl_69;
        }
        else
        { /* block id: 48 */
            int16_t l_72 = 0xCFE4L;
            int32_t l_76 = 0L;
            l_72 = (safe_div_func_uint64_t_u_u(2UL, p_54));
            l_76 = (safe_sub_func_uint16_t_u_u(((((p_54 < l_75) | 0x7CB4E35EE06F66B5LL) && l_72) < 0x631DL), l_58));
        }
        if ((((safe_div_func_int64_t_s_s(((safe_lshift_func_uint8_t_u_s((!(safe_mul_func_int8_t_s_s(((((!((l_55[5][0][9] , 0x0EF9L) & 0xD11AL)) != g_36) ^ l_65[1]) , l_85), l_75))), 1)) == 0xC0L), g_11[1][2])) == g_11[4][1]) >= g_11[3][4]))
        { /* block id: 52 */
            l_86 = (l_58 , 0x5A3FFCEDL);
        }
        else
        { /* block id: 54 */
            uint16_t l_91 = 0xA8E5L;
            if (p_53)
                goto lbl_87;
            g_49 &= 0xE07F6A70L;
            l_91 = (safe_div_func_int16_t_s_s(((g_36 , 4294967295UL) && 0x2AF0730FL), l_90));
            g_49 = (!p_52);
        }
    }
    else
    { /* block id: 60 */
        int16_t l_104 = 1L;
        int32_t l_113 = 0xC4BB8212L;
        if ((safe_add_func_uint64_t_u_u((((safe_mul_func_uint8_t_u_u(0x86L, 7L)) >= l_55[7][1][9]) ^ l_97), l_85)))
        { /* block id: 61 */
            uint8_t l_105 = 255UL;
            int32_t l_107[5];
            int i;
            for (i = 0; i < 5; i++)
                l_107[i] = 0x383E184CL;
            g_49 &= (safe_add_func_int32_t_s_s((0xB9L || 0xF0L), p_54));
            if (g_47)
                goto lbl_106;
lbl_106:
            l_65[0] = (safe_mod_func_int8_t_s_s(((safe_div_func_int8_t_s_s((0x7B9E3EC41181933ALL == l_104), p_52)) < l_105), l_105));
            l_107[2] ^= (g_47 != l_104);
        }
        else
        { /* block id: 66 */
            l_65[2] = (safe_unary_minus_func_uint64_t_u((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_s((l_97 , 1L), g_17)) ^ l_85), 5))));
        }
        l_113 = ((g_36 && p_53) != 0x9B320AFAL);
        for (l_104 = 5; (l_104 >= 0); l_104 -= 1)
        { /* block id: 72 */
            int32_t l_114 = 0xCD5419F2L;
            g_49 = (l_104 <= 0x9E1B5AB6L);
            g_49 ^= (((255UL == l_114) , g_47) , 1L);
        }
        g_49 = (l_113 == 0x1FA81E3AF264BFD8LL);
    }
    if ((safe_mod_func_int16_t_s_s(((((p_53 ^ 0xABL) , g_33) || 6L) ^ l_65[2]), (-2L))))
    { /* block id: 78 */
        uint32_t l_117 = 0xA63C46DEL;
        l_117 = p_52;
    }
    else
    { /* block id: 80 */
        int8_t l_124 = 0xE5L;
        g_49 = ((safe_add_func_uint32_t_u_u(((safe_lshift_func_int16_t_s_s((safe_mod_func_uint16_t_u_u(((g_36 != l_65[0]) == l_90), l_124)), p_54)) | p_54), 0xD4CACFD2L)) <= p_54);
        for (g_47 = (-15); (g_47 < 19); g_47 = safe_add_func_uint8_t_u_u(g_47, 4))
        { /* block id: 84 */
            int32_t l_127[8] = {0x17292063L,0x17292063L,0x17292063L,0x17292063L,0x17292063L,0x17292063L,0x17292063L,0x17292063L};
            int i;
            g_49 ^= ((l_124 <= l_127[4]) || g_11[4][0]);
        }
        return g_11[1][2];
    }
    return g_11[1][2];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_11[i][j], "g_11[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 36
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 13
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 12, occurrence: 2
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 109
XXX times a non-volatile is write: 33
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 42
XXX percentage of non-volatile access: 95.9

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 55
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 18
   depth: 2, occurrence: 24

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
********************* end of statistics **********************/

