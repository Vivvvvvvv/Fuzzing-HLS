/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8255023437829051745
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_5[8] = {(-8L),1L,(-8L),(-8L),1L,(-8L),(-8L),1L};
static const int32_t g_6 = 1L;
static uint32_t g_15 = 18446744073709551608UL;
static volatile uint32_t g_25 = 0x50FAEB38L;/* VOLATILE GLOBAL g_25 */
static uint32_t g_31[6] = {0xB000E2E4L,0x467B47E0L,0x467B47E0L,0xB000E2E4L,0x467B47E0L,0x467B47E0L};
static const int8_t g_33 = 0x38L;
static uint8_t g_39 = 5UL;
static int16_t g_40[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
static int32_t g_43 = 0x2FDDD0C6L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint8_t  func_12(int16_t  p_13);
static const int64_t  func_22(int32_t  p_23, int32_t  p_24);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_25 g_33 g_31 g_39 g_40 g_43
 * writes: g_15 g_25 g_31 g_39 g_40 g_43
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2[2];
    int32_t l_7 = 0x0DB85613L;
    int8_t l_44 = (-7L);
    int i;
    for (i = 0; i < 2; i++)
        l_2[i] = 0UL;
    ++l_2[0];
    l_7 |= (((l_2[0] <= g_5[6]) == g_6) , g_6);
    for (l_7 = 0; (l_7 != (-15)); --l_7)
    { /* block id: 5 */
        g_40[7] = ((safe_rshift_func_uint8_t_u_s(func_12(l_7), 1)) && 1L);
    }
    g_43 &= (((((safe_rshift_func_int8_t_s_s(l_7, g_39)) & g_5[6]) && g_40[7]) == (-4L)) , l_2[1]);
    return l_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_25 g_33 g_5 g_31 g_39
 * writes: g_15 g_25 g_31 g_39
 */
static uint8_t  func_12(int16_t  p_13)
{ /* block id: 6 */
    uint16_t l_14 = 0x6968L;
    int32_t l_38[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
    int i;
    g_15 = (g_6 & l_14);
    g_39 &= (safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_u(((safe_add_func_int16_t_s_s((func_22(p_13, l_14) , (-6L)), l_38[2])) <= p_13), 7)), 2));
    return g_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_6 g_33 g_5 g_31
 * writes: g_25 g_31
 */
static const int64_t  func_22(int32_t  p_23, int32_t  p_24)
{ /* block id: 8 */
    int32_t l_30 = (-1L);
    int16_t l_32 = 0x41B6L;
    g_25++;
    g_31[5] = (safe_mod_func_uint32_t_u_u(4294967295UL, l_30));
    p_23 = (((((p_24 >= l_32) >= g_6) | g_25) , g_6) > g_33);
    l_30 |= (((safe_sub_func_int32_t_s_s((((safe_lshift_func_int16_t_s_s(p_23, 14)) , g_5[6]) == 2UL), g_31[5])) <= 0UL) , 0xB017290BL);
    return g_31[3];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_31[i], "g_31[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_40[i], "g_40[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_43, "g_43", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 3
   depth: 4, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 10
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 15
XXX percentage of non-volatile access: 87.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 41
XXX percentage an existing variable is used: 59
********************* end of statistics **********************/

