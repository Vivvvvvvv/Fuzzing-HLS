/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9661271387805916058
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_2[8][4] = {{0x48F6L,0UL,0UL,0xF7FDL},{65528UL,0UL,65528UL,0UL},{0UL,0xA32BL,65535UL,65535UL},{65535UL,0xF7FDL,0x48F6L,0xA32BL},{0xCECBL,0x48F6L,0x48F6L,0xCECBL},{65535UL,0UL,65535UL,65528UL},{0UL,65535UL,65528UL,1UL},{65528UL,1UL,0UL,1UL}};
static int32_t g_3[9] = {0x3843046BL,0x3843046BL,0x3843046BL,0x3843046BL,0x3843046BL,0x3843046BL,0x3843046BL,0x3843046BL,0x3843046BL};
static volatile int32_t g_4 = 0xBBF9ACF2L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = (-1L);/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = 0x4C865B49L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_2 g_5
 * writes: g_3 g_6 g_4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_14 = 0L;
    for (g_3[2] = 3; (g_3[2] >= 0); g_3[2] -= 1)
    { /* block id: 3 */
        for (g_6 = 0; (g_6 <= 3); g_6 += 1)
        { /* block id: 6 */
            int i, j;
            return g_2[(g_6 + 3)][g_3[2]];
        }
        for (g_6 = 3; (g_6 >= 0); g_6 -= 1)
        { /* block id: 11 */
            uint16_t l_11 = 0x1AFDL;
            g_4 = (((safe_rshift_func_uint8_t_u_u((l_11 == 0L), g_5)) , 0xD8L) , l_11);
        }
    }
    for (g_6 = 0; (g_6 == 3); ++g_6)
    { /* block id: 17 */
        l_14 = g_6;
    }
    return l_14;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 5
   depth: 2, occurrence: 4
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 5
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 87.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 3
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 28.6
XXX percentage an existing variable is used: 71.4
********************* end of statistics **********************/

