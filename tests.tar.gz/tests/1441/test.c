/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12056020222074691042
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_2[9] = {0xB546158D32FFAB8CLL,0xC85F70AD6F2EE76FLL,0xB546158D32FFAB8CLL,0xB546158D32FFAB8CLL,0xC85F70AD6F2EE76FLL,0xB546158D32FFAB8CLL,0xB546158D32FFAB8CLL,0xC85F70AD6F2EE76FLL,0xB546158D32FFAB8CLL};
static volatile int32_t g_3 = 0x152C58FBL;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 5L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0x748AFA2FL;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = (-1L);/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7 = 0L;/* VOLATILE GLOBAL g_7 */
static volatile int32_t g_8 = 0x058A835AL;/* VOLATILE GLOBAL g_8 */
static volatile int32_t g_9 = 0x86F8C7B5L;/* VOLATILE GLOBAL g_9 */
static volatile int32_t g_10 = 0xFF3DE036L;/* VOLATILE GLOBAL g_10 */
static int32_t g_11 = 0x697E780CL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_2 g_8 g_5
 * writes: g_11
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_16 = (-4L);
    for (g_11 = 0; (g_11 <= 8); g_11 += 1)
    { /* block id: 3 */
        int i;
        l_16 = (((safe_rshift_func_uint16_t_u_s(((safe_mul_func_uint16_t_u_u(65530UL, 0UL)) == g_2[g_11]), 0)) , g_2[g_11]) <= 0x6D21CD4309642E40LL);
    }
    l_16 = ((safe_add_func_int32_t_s_s(1L, g_8)) < g_2[8]);
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 3
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 4
XXX times a non-volatile is write: 3
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 77.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 4
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
********************* end of statistics **********************/

