/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2684382406797196472
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const uint16_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 1L;
static int32_t g_4 = 7L;
static volatile int64_t g_7 = 0x49F6D4A0D461E3FFLL;/* VOLATILE GLOBAL g_7 */
static volatile int64_t g_9 = 7L;/* VOLATILE GLOBAL g_9 */
static volatile uint16_t g_10 = 65534UL;/* VOLATILE GLOBAL g_10 */
static int32_t g_27 = 0x64548797L;
static uint8_t g_29 = 0UL;
static volatile int32_t g_38 = (-1L);/* VOLATILE GLOBAL g_38 */
static volatile uint32_t g_39 = 0xEB6BA8A7L;/* VOLATILE GLOBAL g_39 */
static struct S0 g_50 = {0UL};


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static uint64_t  func_15(int8_t  p_16, int8_t  p_17, int64_t  p_18, uint32_t  p_19, uint32_t  p_20);
static int32_t  func_22(const uint8_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_10 g_9 g_7 g_27 g_29 g_39 g_38 g_50
 * writes: g_3 g_4 g_10 g_27 g_29 g_39 g_38
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int32_t l_2[1];
    int i;
    for (i = 0; i < 1; i++)
        l_2[i] = 0x67FA5C62L;
    for (g_3 = 0; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        int16_t l_8 = (-1L);
        int16_t l_21 = 0xC0DEL;
        int32_t l_34 = (-1L);
        int32_t l_37 = (-1L);
        for (g_4 = 0; (g_4 <= 0); g_4 += 1)
        { /* block id: 6 */
            int32_t l_5 = (-1L);
            int32_t l_6 = (-2L);
            int i;
            g_10--;
            l_2[0] = l_2[g_4];
        }
        l_34 = (safe_div_func_uint64_t_u_u(func_15((0xF11BBB4F5AC3D6C1LL & g_9), l_8, l_21, l_8, g_4), l_8));
        for (g_4 = 29; (g_4 < 1); g_4 = safe_sub_func_uint8_t_u_u(g_4, 5))
        { /* block id: 24 */
            const uint16_t l_47 = 0xA5F0L;
            ++g_39;
            l_37 = (((safe_lshift_func_int16_t_s_s((~((safe_div_func_uint8_t_u_u(((((0xB4954824L & g_38) != l_47) && g_39) , l_47), g_27)) != g_4)), l_47)) == g_29) < 0xA1AB7048L);
            g_38 = ((safe_rshift_func_uint8_t_u_u(l_8, l_2[0])) || l_2[0]);
            if (g_27)
                break;
        }
        g_27 |= l_34;
    }
    return g_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_7 g_3 g_27 g_29 g_10
 * writes: g_27 g_29
 */
static uint64_t  func_15(int8_t  p_16, int8_t  p_17, int64_t  p_18, uint32_t  p_19, uint32_t  p_20)
{ /* block id: 10 */
    const int32_t l_24 = 0xA60813C2L;
    int32_t l_32 = 1L;
    l_32 = func_22(l_24);
    l_32 = (((safe_unary_minus_func_uint8_t_u(0xD4L)) <= p_17) ^ g_3);
    l_32 = 0x40C2C6F7L;
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_7 g_3 g_27 g_29 g_10
 * writes: g_27 g_29
 */
static int32_t  func_22(const uint8_t  p_23)
{ /* block id: 11 */
    int32_t l_28[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
    int i;
    g_27 &= (((((safe_rshift_func_uint8_t_u_u(((((g_4 , g_7) == p_23) != p_23) > g_3), 0)) != 0xC147L) ^ g_4) > g_4) & g_4);
    g_29++;
    l_28[7] = (((0x5BB5FB49L > 0xB09C821FL) ^ g_10) , 8L);
    g_27 = p_23;
    return p_23;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_50.f0, "g_50.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 34
XXX times a non-volatile is write: 14
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 28.1
XXX percentage an existing variable is used: 71.9
********************* end of statistics **********************/

