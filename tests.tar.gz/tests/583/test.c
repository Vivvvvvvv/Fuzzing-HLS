/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1330530165798060396
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_8[7][4][9] = {{{0L,1L,(-1L),1L,(-1L),1L,0L,0x5D811F07L,(-10L)},{0x662A2B3BL,(-10L),0L,0L,0x5D811F07L,0L,0L,(-10L),0x662A2B3BL},{1L,0L,0x662A2B3BL,0x5D811F07L,1L,(-1L),1L,0x5D811F07L,0x662A2B3BL},{1L,1L,1L,(-1L),(-10L),1L,0x662A2B3BL,1L,(-10L)}},{{1L,1L,1L,1L,(-1L),(-10L),1L,0x662A2B3BL,1L},{0x662A2B3BL,1L,1L,1L,1L,(-1L),(-10L),1L,0x662A2B3BL},{(-1L),(-1L),(-1L),0L,0L,(-1L),(-1L),(-1L),1L},{0x662A2B3BL,1L,(-1L),(-10L),(-1L),(-1L),(-10L),(-1L),1L}},{{0L,(-1L),0x662A2B3BL,1L,1L,0L,0L,1L,1L},{0L,0x5D811F07L,0L,0L,(-10L),0x662A2B3BL,(-1L),(-1L),0x662A2B3BL},{0x662A2B3BL,(-1L),0L,(-1L),0x662A2B3BL,1L,1L,0L,0L},{(-1L),1L,0x662A2B3BL,0L,0x662A2B3BL,1L,(-1L),(-10L),(-1L)}},{{(-1L),(-1L),(-1L),1L,(-10L),1L,(-1L),(-1L),(-1L)},{1L,1L,(-1L),(-10L),1L,0x662A2B3BL,1L,(-10L),(-1L)},{1L,1L,1L,0L,(-1L),0L,(-1L),0L,(-1L)},{1L,1L,1L,1L,0L,(-1L),0L,(-1L),0L}},{{(-1L),1L,1L,1L,1L,(-1L),(-10L),1L,0x662A2B3BL},{(-1L),(-1L),(-1L),0L,0L,(-1L),(-1L),(-1L),1L},{0x662A2B3BL,1L,(-1L),(-10L),(-1L),(-1L),(-10L),(-1L),1L},{0L,(-1L),0x662A2B3BL,1L,1L,0L,0L,1L,1L}},{{0L,0x5D811F07L,0L,0L,(-10L),0x662A2B3BL,(-1L),(-1L),0x662A2B3BL},{0x662A2B3BL,(-1L),0L,(-1L),0x662A2B3BL,1L,1L,0L,0L},{(-1L),1L,0x662A2B3BL,0L,0x662A2B3BL,1L,(-1L),(-10L),(-1L)},{(-1L),(-1L),(-1L),1L,(-10L),1L,(-1L),(-1L),(-1L)}},{{1L,1L,(-1L),(-10L),1L,0x662A2B3BL,1L,(-10L),(-1L)},{1L,1L,1L,0L,(-1L),0L,(-1L),0L,(-1L)},{1L,1L,1L,1L,1L,0x662A2B3BL,(-1L),0L,(-1L)},{0L,1L,1L,1L,1L,0L,(-1L),0L,(-1L)}}};
static uint8_t g_53 = 0x5DL;
static uint32_t g_58 = 0x56EB3E19L;
static uint32_t g_63 = 0UL;
static int32_t g_69 = 0x5D7B1ECBL;
static int16_t g_78[4] = {0xFBBAL,0xFBBAL,0xFBBAL,0xFBBAL};
static uint16_t g_79[6] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static int32_t g_94 = 0x0D08F1B1L;
static uint32_t g_111 = 0x715C7436L;
static uint32_t g_120 = 18446744073709551612UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, int16_t  p_5, int32_t  p_6, int8_t  p_7);
static int8_t  func_12(uint32_t  p_13, uint32_t  p_14, const int8_t  p_15);
static int32_t  func_22(int32_t  p_23, uint16_t  p_24, int8_t  p_25, int32_t  p_26);
static int8_t  func_40(uint64_t  p_41, int32_t  p_42, int32_t  p_43, uint32_t  p_44);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_53 g_63 g_69 g_79 g_94 g_78 g_111 g_120
 * writes: g_53 g_58 g_63 g_69 g_79 g_94 g_111 g_120
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9 = 6L;
    if ((func_2(g_8[4][1][3], l_9, g_8[4][1][3], l_9, l_9) != 1L))
    { /* block id: 77 */
        uint8_t l_118 = 0xCEL;
        int32_t l_119[10][3] = {{0x76911F35L,0xED91AC48L,(-1L)},{0xED91AC48L,0xD213B74EL,9L},{0x76911F35L,0xD213B74EL,(-9L)},{6L,0xED91AC48L,9L},{6L,6L,(-1L)},{0x76911F35L,0xED91AC48L,(-1L)},{0xED91AC48L,0xD213B74EL,9L},{0x76911F35L,0xD213B74EL,(-9L)},{6L,0xED91AC48L,9L},{6L,6L,(-1L)}};
        int i, j;
        l_118 ^= (~(safe_mul_func_int16_t_s_s(1L, l_9)));
        g_120++;
        g_69 = (g_111 , 0x9B7196FBL);
    }
    else
    { /* block id: 81 */
        g_94 = ((g_111 || 0UL) && 1L);
    }
    for (g_63 = 0; (g_63 >= 19); g_63 = safe_add_func_uint8_t_u_u(g_63, 1))
    { /* block id: 86 */
        uint16_t l_125 = 0x3662L;
        if (l_125)
            break;
    }
    g_69 |= g_63;
    return g_111;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_53 g_63 g_69 g_79 g_94 g_78 g_111
 * writes: g_53 g_58 g_63 g_69 g_79 g_94 g_111
 */
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, int16_t  p_5, int32_t  p_6, int8_t  p_7)
{ /* block id: 1 */
    int64_t l_27 = 0L;
    int32_t l_109 = (-1L);
    for (p_4 = 0; (p_4 <= 3); p_4 += 1)
    { /* block id: 4 */
        uint8_t l_28 = 0x18L;
        const uint32_t l_102 = 0x8796DE13L;
        int64_t l_104 = 1L;
        int32_t l_107 = 0x63F3D54CL;
        int32_t l_108 = (-10L);
        int8_t l_114[2];
        int i;
        for (i = 0; i < 2; i++)
            l_114[i] = 0x9BL;
        if (g_8[4][1][3])
        { /* block id: 5 */
            const uint16_t l_92 = 0x825FL;
            int32_t l_95[10] = {(-7L),5L,5L,(-7L),0x941AE2D2L,(-7L),5L,5L,(-7L),0x941AE2D2L};
            int i;
            g_94 = (safe_lshift_func_int8_t_s_u(func_12(((safe_mul_func_int8_t_s_s((safe_div_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(func_22(p_3, l_27, p_3, l_28), g_8[4][1][3])), 0x71L)), 9UL)) , g_63), l_27, l_92), 0));
            l_95[6] = l_28;
            g_69 = g_79[3];
        }
        else
        { /* block id: 59 */
            uint32_t l_103 = 4294967293UL;
            l_104 = ((((((safe_mul_func_int8_t_s_s((((((safe_add_func_int8_t_s_s((((safe_lshift_func_uint16_t_u_u(l_102, 10)) == l_27) >= l_27), 0xA2L)) | 0xC2L) , l_103) > (-1L)) , l_27), g_53)) ^ p_7) && 1UL) , p_5) , p_7) != 0x3769207283BD055DLL);
        }
        g_94 ^= ((safe_mod_func_int32_t_s_s(g_53, p_5)) , g_8[1][3][3]);
        if (g_78[1])
        { /* block id: 63 */
            if (l_104)
                break;
            return p_4;
        }
        else
        { /* block id: 66 */
            int64_t l_110 = 1L;
            ++g_111;
            l_114[1] &= (((g_63 > g_53) && 3UL) <= 8L);
        }
        for (p_3 = 3; (p_3 >= 0); p_3 -= 1)
        { /* block id: 72 */
            if (g_63)
                break;
        }
    }
    return l_27;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_12(uint32_t  p_13, uint32_t  p_14, const int8_t  p_15)
{ /* block id: 54 */
    int64_t l_93[5] = {(-2L),(-2L),(-2L),(-2L),(-2L)};
    int i;
    return l_93[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_53 g_63 g_69 g_79
 * writes: g_53 g_58 g_63 g_69 g_79
 */
static int32_t  func_22(int32_t  p_23, uint16_t  p_24, int8_t  p_25, int32_t  p_26)
{ /* block id: 6 */
    uint8_t l_34 = 255UL;
    int32_t l_35 = 1L;
    int32_t l_72 = 0x2C2642A2L;
    int32_t l_73[10];
    int i;
    for (i = 0; i < 10; i++)
        l_73[i] = 1L;
lbl_59:
    l_35 ^= ((((safe_rshift_func_uint8_t_u_s((~((safe_sub_func_uint64_t_u_u(18446744073709551615UL, 18446744073709551608UL)) , p_24)), 5)) | l_34) < 0L) < g_8[4][1][3]);
lbl_82:
    for (p_24 = 0; (p_24 == 49); p_24 = safe_add_func_uint64_t_u_u(p_24, 3))
    { /* block id: 10 */
        if (p_24)
            break;
        for (p_25 = 0; (p_25 <= (-5)); p_25 = safe_sub_func_uint64_t_u_u(p_25, 1))
        { /* block id: 14 */
            uint32_t l_49 = 18446744073709551615UL;
            g_58 = (func_40(((safe_add_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(l_49, 1)), 0x07C1L)) , g_8[4][1][3]), g_8[4][1][3], p_25, l_35) & 250UL);
            if (l_35)
                goto lbl_59;
            g_63 = (~(safe_lshift_func_uint8_t_u_s(p_24, 5)));
        }
    }
    for (l_35 = 0; (l_35 < 4); ++l_35)
    { /* block id: 34 */
        int32_t l_70 = 0x2FA57A88L;
        uint64_t l_71 = 18446744073709551606UL;
        for (p_26 = 0; (p_26 <= 3); p_26 += 1)
        { /* block id: 37 */
            uint32_t l_68 = 0xB2BD68E4L;
            p_23 &= ((((safe_div_func_uint64_t_u_u(l_68, g_63)) && 8L) != 0x44A95A47L) , 0xE4BCB816L);
            g_69 ^= l_35;
        }
        g_69 = (l_70 >= (-10L));
        l_73[0] ^= ((l_71 || l_71) && l_72);
        if ((safe_lshift_func_int8_t_s_s((safe_rshift_func_int16_t_s_u((-1L), p_24)), 6)))
        { /* block id: 43 */
            --g_79[1];
        }
        else
        { /* block id: 45 */
            uint64_t l_89 = 0UL;
            if (g_69)
                goto lbl_82;
            if (l_34)
                break;
            l_73[0] = (safe_mul_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s(p_25, 65534UL)), 1)), p_25));
            l_89 |= (((l_72 | p_24) & p_25) != p_26);
        }
    }
    g_69 = (safe_sub_func_int8_t_s_s(0x48L, 247UL));
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_53
 * writes: g_53
 */
static int8_t  func_40(uint64_t  p_41, int32_t  p_42, int32_t  p_43, uint32_t  p_44)
{ /* block id: 15 */
    int64_t l_52 = 0L;
    for (p_42 = 0; (p_42 <= (-5)); p_42--)
    { /* block id: 18 */
        g_53 = l_52;
    }
    for (g_53 = 0; (g_53 > 57); ++g_53)
    { /* block id: 23 */
        uint64_t l_57[10] = {0x7B249E3C8D3FD905LL,0x2657A772BE76DCB0LL,0x2657A772BE76DCB0LL,0x7B249E3C8D3FD905LL,9UL,0x7B249E3C8D3FD905LL,0x2657A772BE76DCB0LL,0x2657A772BE76DCB0LL,0x7B249E3C8D3FD905LL,9UL};
        int i;
        p_42 &= ((~((l_57[2] < 4294967292UL) >= p_43)) > (-5L));
    }
    return p_43;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_8[i][j][k], "g_8[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_78[i], "g_78[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_79[i], "g_79[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 38
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 14
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 81
XXX times a non-volatile is write: 34
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 51
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 17
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 34.2
XXX percentage an existing variable is used: 65.8
********************* end of statistics **********************/

