/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1651295081307197934
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int8_t  f0;
   volatile int64_t  f1;
   volatile uint16_t  f2;
   const int16_t  f3;
};

struct S1 {
   uint32_t  f0;
   const struct S0  f1;
   volatile uint8_t  f2;
   volatile uint16_t  f3;
   const int32_t  f4;
   volatile uint32_t  f5;
   int32_t  f6;
   uint32_t  f7;
   int32_t  f8;
   volatile uint32_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3[5] = {0x7A329EF4L,0x7A329EF4L,0x7A329EF4L,0x7A329EF4L,0x7A329EF4L};
static int32_t g_10 = (-4L);
static struct S1 g_18[8] = {{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L},{0x0698B42DL,{-1L,0xD69B12DB22C08F49LL,9UL,0x6764L},0UL,65530UL,3L,1UL,0xE11F3177L,0x55A2C03FL,0xDA78404DL,0x83830386L}};


/* --- FORWARD DECLARATIONS --- */
static struct S1  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_18
 * writes:
 */
static struct S1  func_1(void)
{ /* block id: 0 */
    int64_t l_2 = 0x6EE97341720348F4LL;
    int32_t l_4 = 0L;
    int32_t l_5 = (-1L);
    int32_t l_6 = 6L;
    int32_t l_7 = 0L;
    int32_t l_8 = 0xD5B611FBL;
    int32_t l_9 = 0x8C7FFFAAL;
    int32_t l_11 = 0xB7B88CDFL;
    int8_t l_12[5] = {0xA2L,0xA2L,0xA2L,0xA2L,0xA2L};
    int32_t l_13 = (-1L);
    int32_t l_14[7] = {0xDB756FD8L,0xDB756FD8L,0xDB756FD8L,0xDB756FD8L,0xDB756FD8L,0xDB756FD8L,0xDB756FD8L};
    uint16_t l_15 = 65526UL;
    int i;
    l_2 = 0xEB9E9D60L;
    l_15++;
    return g_18[3];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_10, "g_10", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_18[i].f0, "g_18[i].f0", print_hash_value);
        transparent_crc(g_18[i].f1.f0, "g_18[i].f1.f0", print_hash_value);
        transparent_crc(g_18[i].f1.f1, "g_18[i].f1.f1", print_hash_value);
        transparent_crc(g_18[i].f1.f2, "g_18[i].f1.f2", print_hash_value);
        transparent_crc(g_18[i].f1.f3, "g_18[i].f1.f3", print_hash_value);
        transparent_crc(g_18[i].f2, "g_18[i].f2", print_hash_value);
        transparent_crc(g_18[i].f3, "g_18[i].f3", print_hash_value);
        transparent_crc(g_18[i].f4, "g_18[i].f4", print_hash_value);
        transparent_crc(g_18[i].f5, "g_18[i].f5", print_hash_value);
        transparent_crc(g_18[i].f6, "g_18[i].f6", print_hash_value);
        transparent_crc(g_18[i].f7, "g_18[i].f7", print_hash_value);
        transparent_crc(g_18[i].f8, "g_18[i].f8", print_hash_value);
        transparent_crc(g_18[i].f9, "g_18[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 0
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 1
breakdown:
   depth: 1, occurrence: 5

XXX total number of pointers: 0

XXX times a non-volatile is read: 1
XXX times a non-volatile is write: 2
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 3
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 3

XXX percentage a fresh-made variable is used: 34.1
XXX percentage an existing variable is used: 65.9
********************* end of statistics **********************/

