/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8700000667101753765
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_5 = 18446744073709551609UL;
static int64_t g_14 = 0x84085EFBE72F236BLL;
static volatile int32_t g_25 = (-9L);/* VOLATILE GLOBAL g_25 */
static int32_t g_27 = 0L;
static int8_t g_35 = 0x59L;
static int32_t g_63 = 0x29592AE1L;
static volatile uint32_t g_67 = 4294967295UL;/* VOLATILE GLOBAL g_67 */
static uint32_t g_70 = 0x2B9925C1L;
static volatile uint8_t g_81 = 253UL;/* VOLATILE GLOBAL g_81 */
static uint32_t g_90[1][5] = {{0x621383E1L,0x621383E1L,0x621383E1L,0x621383E1L,0x621383E1L}};
static volatile uint8_t g_94[3] = {1UL,1UL,1UL};
static int32_t g_97[8] = {0x378B10DFL,0xB9B320AFL,0xB9B320AFL,0x378B10DFL,0xB9B320AFL,0xB9B320AFL,0x378B10DFL,0xB9B320AFL};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint32_t  func_9(int64_t  p_10, uint8_t  p_11);
static int64_t  func_36(const uint32_t  p_37, int64_t  p_38, uint8_t  p_39);
static int32_t  func_52(int32_t  p_53);
static int8_t  func_86(const uint32_t  p_87);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_25 g_27 g_35 g_67 g_81 g_63 g_70 g_94 g_14 g_90 g_97
 * writes: g_5 g_14 g_27 g_35 g_67 g_70 g_81 g_63 g_90 g_94 g_97
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_2 = 5UL;
    int64_t l_6[8][7][4] = {{{6L,0x3250E6DA5043C4ABLL,(-8L),0L},{0L,0L,0L,0L},{1L,0x3250E6DA5043C4ABLL,0xF9D44C039ECF4A41LL,0L},{0L,0x3250E6DA5043C4ABLL,1L,0L},{6L,0L,0xF9D44C039ECF4A41LL,0L},{0L,0x3250E6DA5043C4ABLL,0L,0L},{6L,0x3250E6DA5043C4ABLL,(-8L),0L}},{{0L,0L,1L,0L},{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L},{1L,0L,1L,1L},{1L,0L,0L,0L},{0L,1L,1L,0L}},{{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L},{1L,0L,1L,1L},{1L,0L,0L,0L},{0L,1L,1L,0L},{(-1L),0L,(-8L),1L}},{{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L},{1L,0L,1L,1L},{1L,0L,0L,0L},{0L,1L,1L,0L},{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L}},{{1L,1L,(-8L),0L},{1L,0L,1L,1L},{1L,0L,0L,0L},{0L,1L,1L,0L},{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L}},{{1L,0L,1L,1L},{1L,0L,0L,0L},{0L,1L,1L,0L},{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L},{1L,0L,1L,1L}},{{1L,0L,0L,0L},{0L,1L,1L,0L},{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L},{1L,0L,1L,1L},{1L,0L,0L,0L}},{{0L,1L,1L,0L},{(-1L),0L,(-8L),1L},{0L,0L,0x3250E6DA5043C4ABLL,0L},{1L,1L,(-8L),0L},{1L,0L,1L,1L},{1L,0L,0L,0L},{0L,0x3250E6DA5043C4ABLL,0x3250E6DA5043C4ABLL,1L}}};
    int32_t l_150[5][6][1] = {{{0x56938820L},{0x3E1308BAL},{(-1L)},{0x293BDCD7L},{0x22127DE2L},{0xB2766196L}},{{0x22127DE2L},{0x293BDCD7L},{(-1L)},{0x3E1308BAL},{0x56938820L},{0x3E1308BAL}},{{(-1L)},{0x293BDCD7L},{0x22127DE2L},{0xB2766196L},{0x22127DE2L},{0x293BDCD7L}},{{(-1L)},{0x3E1308BAL},{0x56938820L},{0x3E1308BAL},{(-1L)},{0x293BDCD7L}},{{0x22127DE2L},{0xB2766196L},{0x22127DE2L},{0x293BDCD7L},{(-1L)},{0x3E1308BAL}}};
    int8_t l_154 = (-1L);
    int32_t l_181 = 0xDCCD7B2CL;
    uint64_t l_184 = 9UL;
    int32_t l_195[7][4] = {{(-7L),8L,0x6D7A7CCCL,(-1L)},{(-7L),0x6D7A7CCCL,(-7L),0x44A9CEF0L},{8L,(-1L),0x44A9CEF0L,0x44A9CEF0L},{0x6D7A7CCCL,0x6D7A7CCCL,(-1L),(-1L)},{(-1L),8L,(-1L),8L},{0x6D7A7CCCL,(-7L),0x44A9CEF0L,(-1L)},{8L,(-7L),(-7L),8L}};
    int i, j, k;
lbl_168:
    if (l_2)
    { /* block id: 1 */
        uint16_t l_12[7][10][3] = {{{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL}},{{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL}},{{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL}},{{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL}},{{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL}},{{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL}},{{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL},{0xCE85L,0xA6CEL,0xA6CEL},{65527UL,8UL,65527UL},{0xCE85L,0xCE85L,0xA6CEL},{7UL,8UL,7UL}}};
        int i, j, k;
        g_5 &= (safe_mul_func_int8_t_s_s(l_2, (-10L)));
        for (l_2 = 0; (l_2 <= 3); l_2 += 1)
        { /* block id: 5 */
            uint64_t l_13 = 18446744073709551615UL;
            uint32_t l_28 = 0x9E48991CL;
            if (g_5)
                break;
            g_27 = (safe_mod_func_uint32_t_u_u(func_9(l_12[0][9][2], l_13), g_5));
            l_28 = g_27;
            g_35 = (safe_mod_func_uint64_t_u_u(func_9((((((safe_add_func_uint16_t_u_u((safe_div_func_uint64_t_u_u(func_9(func_9(l_28, g_27), g_5), l_28)), 0L)) & 1UL) & 0xABL) > g_5) > (-1L)), l_28), g_27));
        }
    }
    else
    { /* block id: 22 */
        const int16_t l_54 = 0x6AC6L;
        int32_t l_139 = 0x114AE42EL;
        uint32_t l_148 = 1UL;
        int32_t l_151 = 0xCBD2EE51L;
        int32_t l_155 = 0x858BC3E6L;
        int32_t l_156 = 0xF9D2C0AAL;
        int32_t l_157 = (-9L);
        int32_t l_158 = 6L;
        int32_t l_159 = (-9L);
        int32_t l_161 = 3L;
        int32_t l_162 = 0x8ECFB4A1L;
        int32_t l_163 = (-2L);
        int32_t l_164 = (-3L);
        uint32_t l_165 = 0xCC302F64L;
        if ((func_9(func_36(g_35, g_25, g_27), g_35) >= g_35))
        { /* block id: 31 */
            int16_t l_140[7] = {0x57F2L,0x57F2L,0x57F2L,0x57F2L,0x57F2L,0x57F2L,0x57F2L};
            int i;
            l_139 &= func_52(func_36(l_54, l_2, g_25));
            l_139 = (g_25 > g_97[2]);
            return l_140[6];
        }
        else
        { /* block id: 105 */
            uint8_t l_141 = 0x98L;
            int32_t l_149 = 0L;
            int32_t l_152 = (-1L);
            int32_t l_153[6];
            int8_t l_160[9][4] = {{(-5L),0xCCL,0xF7L,(-5L)},{0xF7L,(-5L),0x0AL,0x0AL},{(-7L),(-7L),0xC8L,(-1L)},{(-7L),0xCCL,0x0AL,(-7L)},{0xF7L,(-1L),0xF7L,0x0AL},{(-5L),(-1L),0xC8L,(-7L)},{(-1L),0xCCL,0xCCL,(-1L)},{0xF7L,(-7L),0xCCL,0x0AL},{(-1L),(-5L),0xC8L,(-5L)}};
            int i, j;
            for (i = 0; i < 6; i++)
                l_153[i] = 0x6704F707L;
            l_141++;
            l_149 |= (safe_sub_func_uint32_t_u_u(((safe_mul_func_int16_t_s_s(l_54, g_27)) , l_148), 1UL));
            l_165++;
        }
    }
    if ((((0x02L > g_94[2]) , 0x73B9E9AAL) >= (-1L)))
    { /* block id: 111 */
        int16_t l_171 = (-1L);
        if (g_27)
            goto lbl_168;
        l_150[3][4][0] = (((safe_rshift_func_uint8_t_u_s(((g_25 & l_171) & l_150[3][2][0]), 5)) && l_171) , l_150[3][4][0]);
        g_97[6] = ((g_81 == g_14) < l_150[3][4][0]);
    }
    else
    { /* block id: 115 */
        uint8_t l_180 = 0x71L;
        uint8_t l_187 = 0xE4L;
        int16_t l_197 = 0L;
        int32_t l_208[2];
        int16_t l_209 = 0x1E91L;
        uint8_t l_210 = 1UL;
        int16_t l_215 = (-1L);
        int32_t l_216[9];
        uint64_t l_217 = 9UL;
        int i;
        for (i = 0; i < 2; i++)
            l_208[i] = 0xFA78DD74L;
        for (i = 0; i < 9; i++)
            l_216[i] = (-1L);
        if ((safe_sub_func_int64_t_s_s(((safe_rshift_func_uint16_t_u_s(((safe_mod_func_int8_t_s_s(((safe_div_func_int64_t_s_s(((g_70 <= 4294967295UL) ^ 1L), l_180)) != 1UL), l_180)) & l_180), l_180)) < l_6[4][4][0]), 0L)))
        { /* block id: 116 */
            int64_t l_182[7][3] = {{0x8F9857E4DE94C89DLL,0x9A66F5DFC3470E8CLL,0x57AB89A725E6F1A9LL},{(-1L),(-1L),0xCEE3CB9E092BE84DLL},{4L,0x9A66F5DFC3470E8CLL,0x9A66F5DFC3470E8CLL},{0xCEE3CB9E092BE84DLL,0x540248992C6C6D99LL,4L},{4L,0L,4L},{(-1L),0xCEE3CB9E092BE84DLL,4L},{0x8F9857E4DE94C89DLL,0x8F9857E4DE94C89DLL,0x9A66F5DFC3470E8CLL}};
            int32_t l_183[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i, j;
            g_97[2] ^= l_181;
            l_184--;
            l_187 = l_154;
            g_97[2] = g_90[0][0];
        }
        else
        { /* block id: 121 */
            g_97[2] = ((g_14 == l_6[7][3][2]) == 4294967286UL);
        }
        if (((safe_lshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u((0UL > 0x78E65A7A0E92DA2FLL), l_150[3][4][0])), g_94[2])) && 65535UL))
        { /* block id: 124 */
            uint32_t l_194 = 0UL;
            l_150[3][4][0] = ((safe_sub_func_uint32_t_u_u((l_194 > 0xBDL), 0xFD1AC27FL)) > l_195[6][2]);
            g_97[6] = g_81;
        }
        else
        { /* block id: 127 */
            uint64_t l_196 = 0x1A939D389A2BFAC5LL;
            g_97[2] &= l_196;
            g_97[2] ^= l_197;
        }
        if (g_94[2])
        { /* block id: 131 */
            uint32_t l_204 = 18446744073709551615UL;
            g_97[1] &= ((((safe_add_func_uint16_t_u_u((safe_mod_func_int16_t_s_s((((safe_add_func_uint32_t_u_u(6UL, 0x7C6442FDL)) < 0x0F7F480F0B603982LL) == l_204), g_63)), 0xF14BL)) > g_90[0][0]) <= 65535UL) != 6L);
            if (g_35)
                goto lbl_207;
        }
        else
        { /* block id: 133 */
lbl_207:
            g_97[2] = (((safe_sub_func_int8_t_s_s(l_187, 0x3CL)) & 0xF457C9E6L) != 4UL);
            ++l_210;
            l_150[2][2][0] &= (safe_lshift_func_int8_t_s_u((0x6898C7DA12D69996LL ^ g_27), 7));
            l_217--;
        }
    }
    return g_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_25
 * writes: g_14
 */
static uint32_t  func_9(int64_t  p_10, uint8_t  p_11)
{ /* block id: 7 */
    uint16_t l_15[2];
    int i;
    for (i = 0; i < 2; i++)
        l_15[i] = 65530UL;
lbl_16:
    g_14 = (g_5 & 0x149F7FAE0CD5C0F4LL);
    for (p_11 = 0; (p_11 <= 1); p_11 += 1)
    { /* block id: 11 */
        int32_t l_26[1];
        int i;
        for (i = 0; i < 1; i++)
            l_26[i] = 0x79F1A7DFL;
        if (p_11)
            goto lbl_16;
        if (l_15[p_11])
            break;
        l_26[0] = (safe_lshift_func_int16_t_s_u(((safe_sub_func_uint64_t_u_u((safe_add_func_int16_t_s_s((safe_sub_func_int32_t_s_s(l_15[p_11], p_10)), g_25)), (-1L))) < p_10), g_5));
        if (p_11)
            continue;
    }
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_25
 * writes: g_5 g_14
 */
static int64_t  func_36(const uint32_t  p_37, int64_t  p_38, uint8_t  p_39)
{ /* block id: 23 */
    uint64_t l_46 = 18446744073709551615UL;
    int32_t l_47 = (-1L);
    for (g_5 = 0; (g_5 > 28); ++g_5)
    { /* block id: 26 */
        uint8_t l_50 = 0x80L;
        int32_t l_51 = (-1L);
        l_47 ^= (safe_div_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(1UL, l_46)), 8UL));
        l_51 = ((safe_rshift_func_int8_t_s_u(((((func_9(l_47, l_50) | g_5) , 0xFAL) , 1UL) , p_38), p_38)) && p_38);
    }
    return g_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_67 g_5 g_27 g_81 g_63 g_70 g_25 g_94 g_14 g_90 g_97
 * writes: g_35 g_67 g_70 g_27 g_81 g_63 g_90 g_5 g_94 g_97
 */
static int32_t  func_52(int32_t  p_53)
{ /* block id: 32 */
    int32_t l_55[5] = {0x9AB98CFEL,0x9AB98CFEL,0x9AB98CFEL,0x9AB98CFEL,0x9AB98CFEL};
    int32_t l_61 = 0xED05CE63L;
    int32_t l_62 = 0xF5FC6D38L;
    int8_t l_79 = 0xCEL;
    int16_t l_111 = (-5L);
    uint16_t l_122 = 0xAB66L;
    uint16_t l_129 = 1UL;
    int i;
    for (g_35 = 3; (g_35 >= 0); g_35 -= 1)
    { /* block id: 35 */
        int32_t l_60 = 0x35EE06F6L;
        int32_t l_64 = 0x7106FA44L;
        int32_t l_65 = 9L;
        int32_t l_66 = 8L;
        int i;
        l_60 |= (safe_mul_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(l_55[(g_35 + 1)], 0x14C0ACF2L)), (-1L)));
        g_67--;
        if (g_5)
            break;
        g_70 = l_65;
    }
lbl_138:
    for (g_27 = 0; (g_27 > 6); ++g_27)
    { /* block id: 43 */
        return g_67;
    }
    for (p_53 = 0; (p_53 >= 19); p_53 = safe_add_func_uint64_t_u_u(p_53, 9))
    { /* block id: 48 */
        uint64_t l_80[9][1] = {{3UL},{3UL},{1UL},{3UL},{3UL},{1UL},{3UL},{3UL},{1UL}};
        int64_t l_84 = (-7L);
        int32_t l_131[5][8][6] = {{{1L,(-8L),0x8C4E8C28L,0xE3320B12L,0x96BFC592L,0x46A68022L},{0x2E75A53AL,0xD22BE5E2L,0x0C63ED81L,0x9A001620L,9L,(-1L)},{0x2307A3C1L,0xF9BFDDA3L,0x03B609C6L,3L,0x46A68022L,0x8C4E8C28L},{0xD3C435FAL,(-3L),0x2E75A53AL,(-8L),0L,(-9L)},{0xE61D7D12L,0xA51F0974L,(-9L),0x0C63ED81L,0x1DF02EAEL,0xD22BE5E2L},{0x4CD4942DL,0x8C4E8C28L,3L,0x979EA24BL,0x9A001620L,0x2ED989C8L},{(-9L),(-1L),0x80768EFDL,0xED40CDEBL,0x94C2ECEAL,0x76BBF86DL},{0x76BBF86DL,0x9A001620L,1L,0x3E8D0C3CL,1L,0x03B609C6L}},{{0L,0x2ED989C8L,(-1L),0x2ED989C8L,0L,0xA4938770L},{(-1L),(-4L),0x979EA24BL,0x54065CC1L,(-10L),0x96BFC592L},{0x2307A3C1L,(-1L),0xA84A55BAL,(-4L),0xED40CDEBL,0x96BFC592L},{9L,0x74B49123L,0x979EA24BL,0x6AEA00BFL,0xA38B5D02L,0xA4938770L},{0xED40CDEBL,0x2E75A53AL,(-1L),4L,9L,0x03B609C6L},{0x1DF02EAEL,(-1L),1L,0x0D9698A8L,0xF769B8DEL,0x76BBF86DL},{0x8C4E8C28L,0xD22BE5E2L,0x80768EFDL,0L,0x8D3DCD3DL,0x2ED989C8L},{0x740FBDBEL,0L,3L,1L,(-3L),0xD22BE5E2L}},{{0xA38B5D02L,(-8L),(-9L),0xE61D7D12L,0x74B49123L,0x8C4E8C28L},{0xF4511BC6L,0x0C8DDAE6L,(-1L),0xF9BFDDA3L,0xA4938770L,0x6FFCA76EL},{(-3L),4L,0x2ED989C8L,(-9L),0xF4511BC6L,(-4L)},{0x46A68022L,0x9807974FL,9L,0xF4511BC6L,(-8L),0x74D08404L},{0xA84A55BAL,9L,0x6FFCA76EL,9L,0x80768EFDL,0xE61D7D12L},{(-10L),0L,(-8L),0xFE41880DL,4L,4L},{3L,0x94C2ECEAL,0x94C2ECEAL,3L,0x54065CC1L,0xF4511BC6L},{0x0C63ED81L,(-3L),0x8C4E8C28L,0xB3F44D47L,(-1L),0x74B49123L}},{{(-8L),0xD3C435FAL,0xCED94F1BL,0xFD37754CL,(-1L),0xE3320B12L},{0x8D3DCD3DL,(-3L),(-4L),0x9A001620L,0x54065CC1L,0x2E75A53AL},{(-3L),0x94C2ECEAL,0x3B1CCB90L,9L,4L,0x0C63ED81L},{0xA4938770L,0L,0xFD37754CL,0x74D08404L,0x80768EFDL,0x4CD4942DL},{3L,9L,2L,0xF769B8DEL,(-8L),0xC86662D1L},{0x54065CC1L,0x9807974FL,0xF9BFDDA3L,0xF1DF6FF7L,0xF4511BC6L,1L},{(-9L),4L,0xB3F44D47L,0L,0xA4938770L,(-1L)},{0xD3C435FAL,0x0C8DDAE6L,0x8878B811L,0L,0x74B49123L,0x4334ECE7L}},{{0x96BFC592L,(-8L),(-3L),0xC86662D1L,(-3L),0x1DF02EAEL},{(-4L),0L,0xF769B8DEL,0x96BFC592L,0x8D3DCD3DL,3L},{(-8L),0xD22BE5E2L,0L,(-9L),0xF769B8DEL,0x25E9BBC1L},{0x6FFCA76EL,(-1L),0x96BFC592L,0xCED94F1BL,9L,0xCED94F1BL},{(-1L),(-1L),0x8878B811L,0xFD37754CL,0x4334ECE7L,0xF1DF6FF7L},{0x0C8DDAE6L,0xD22BE5E2L,0L,(-8L),0xF4511BC6L,0x0C63ED81L},{4L,0x4CD4942DL,0x74D08404L,(-8L),0x6AEA00BFL,0xFD37754CL},{0x0C8DDAE6L,0xFE41880DL,3L,0xFD37754CL,1L,3L}}};
        int16_t l_132 = (-4L);
        int i, j, k;
        if ((safe_add_func_uint32_t_u_u(((((((safe_div_func_int8_t_s_s(l_61, p_53)) <= l_79) & 4L) < l_80[7][0]) == 0xDBL) ^ l_62), 1L)))
        { /* block id: 49 */
            uint8_t l_85[8][10] = {{0x39L,0x5FL,9UL,9UL,9UL,9UL,0x5FL,0x39L,9UL,0x39L},{9UL,0x5FL,0x92L,9UL,0x92L,0x5FL,9UL,0UL,0UL,9UL},{0UL,0x39L,0x92L,0x92L,0x39L,0UL,0x5FL,0x39L,0x5FL,0UL},{0x5FL,0x39L,9UL,0x39L,0x5FL,9UL,9UL,9UL,9UL,0x5FL},{0x5FL,0x5FL,0x5FL,0x5FL,0x92L,0UL,0x5FL,0UL,0x92L,0x5FL},{0UL,0x5FL,0UL,0x92L,0x5FL,0x5FL,0x5FL,0x5FL,0x92L,0UL},{9UL,9UL,9UL,0x5FL,0x39L,9UL,0x39L,0x5FL,9UL,9UL},{0x39L,0x5FL,0UL,0x39L,0x92L,0x92L,0x39L,0UL,0x5FL,0x39L}};
            int i, j;
            --g_81;
            l_85[5][5] = l_84;
        }
        else
        { /* block id: 52 */
            g_97[2] = ((func_86(((p_53 != l_84) , g_63)) <= 0x55L) | 1L);
            return p_53;
        }
        if (((p_53 > l_111) , 0L))
        { /* block id: 76 */
            uint8_t l_114 = 4UL;
            g_97[6] = (((safe_mul_func_uint8_t_u_u(l_114, g_35)) , 0UL) != 0xA6927BAF6ACB5B97LL);
            g_97[2] = (safe_div_func_uint16_t_u_u(g_14, g_90[0][3]));
        }
        else
        { /* block id: 79 */
            int32_t l_119 = 0x22C8C089L;
            g_97[2] |= ((safe_lshift_func_int16_t_s_u((p_53 > l_119), 11)) <= (-1L));
            l_62 = (((safe_rshift_func_uint8_t_u_u(0x41L, 0)) , l_122) == l_61);
        }
        for (l_84 = (-23); (l_84 != 19); l_84++)
        { /* block id: 85 */
            int32_t l_130 = 0L;
            int32_t l_133 = (-10L);
            int32_t l_134 = (-1L);
            uint32_t l_135 = 0x23D7B41EL;
            l_129 &= (safe_mul_func_int8_t_s_s(((((safe_add_func_uint16_t_u_u(g_70, p_53)) & p_53) ^ (-10L)) != p_53), p_53));
            ++l_135;
            if (g_70)
                goto lbl_138;
        }
    }
    for (l_111 = 0; (l_111 >= 0); l_111 -= 1)
    { /* block id: 93 */
        if (g_63)
            break;
        for (g_35 = 0; (g_35 <= 0); g_35 += 1)
        { /* block id: 97 */
            return g_25;
        }
    }
    return g_81;
}


/* ------------------------------------------ */
/* 
 * reads : g_70 g_63 g_25 g_5 g_94 g_27
 * writes: g_70 g_63 g_90 g_5 g_94
 */
static int8_t  func_86(const uint32_t  p_87)
{ /* block id: 53 */
    int64_t l_88[7][5] = {{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L},{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L},{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L},{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L},{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L},{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L},{0x827A0C98A99528C7LL,0xA11D7DECAE08EB45LL,0xA11D7DECAE08EB45LL,0x827A0C98A99528C7LL,5L}};
    int8_t l_89 = 0xCFL;
    int8_t l_92 = 0xCAL;
    int8_t l_93 = 0xA4L;
    uint16_t l_98[2];
    int32_t l_101 = 0x1C087C3AL;
    int32_t l_102 = 0x5847AAFFL;
    int32_t l_103 = 1L;
    int32_t l_104 = 0xEEA078BFL;
    int32_t l_105 = 0xE869CBCCL;
    int32_t l_106 = 0x226F5125L;
    int32_t l_107 = 0x1FA81E3AL;
    uint32_t l_108 = 0xC34014C2L;
    int i, j;
    for (i = 0; i < 2; i++)
        l_98[i] = 65534UL;
    for (g_70 = 1; (g_70 <= 4); g_70 += 1)
    { /* block id: 56 */
        int32_t l_91 = 0xECA5129FL;
        for (g_63 = 3; (g_63 >= 1); g_63 -= 1)
        { /* block id: 59 */
            int i, j;
            l_89 = (l_88[(g_70 + 2)][(g_63 + 1)] >= g_25);
            g_90[0][0] = l_89;
        }
        for (g_5 = 1; (g_5 <= 4); g_5 += 1)
        { /* block id: 65 */
            return l_91;
        }
    }
    --g_94[2];
    --l_98[1];
    l_108++;
    return g_27;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_90[i][j], "g_90[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_94[i], "g_94[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_97[i], "g_97[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 95
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 88
   depth: 2, occurrence: 17
   depth: 3, occurrence: 6
   depth: 4, occurrence: 8
   depth: 5, occurrence: 2
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 113
XXX times a non-volatile is write: 55
XXX times a volatile is read: 15
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 137
XXX percentage of non-volatile access: 90.3

XXX forward jumps: 1
XXX backward jumps: 3

XXX stmts: 85
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 27
   depth: 2, occurrence: 40

XXX percentage a fresh-made variable is used: 31.5
XXX percentage an existing variable is used: 68.5
********************* end of statistics **********************/

