/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11033669281314466484
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3 = 6UL;
static int32_t g_28 = 0x4667120DL;
static volatile int32_t g_33 = 0xAC1E0F75L;/* VOLATILE GLOBAL g_33 */
static volatile int8_t g_34 = 0xFAL;/* VOLATILE GLOBAL g_34 */
static volatile int64_t g_35 = 0xA8FAD7494DFD9964LL;/* VOLATILE GLOBAL g_35 */
static int32_t g_36 = 2L;
static volatile uint8_t g_38 = 0xC8L;/* VOLATILE GLOBAL g_38 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int8_t  func_6(int32_t  p_7, uint64_t  p_8, uint16_t  p_9, int8_t  p_10);
static int32_t  func_22(uint64_t  p_23, int8_t  p_24);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_28 g_38
 * writes: g_3 g_28 g_38
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = (-7L);
    uint8_t l_11 = 0x1FL;
    int32_t l_29 = 0x6193FE69L;
    int16_t l_30 = 0xA413L;
    int32_t l_31 = (-1L);
    int32_t l_32 = (-7L);
    int32_t l_37[6] = {2L,0x04549C4BL,2L,2L,0x04549C4BL,2L};
    int i;
    g_3 &= (l_2 && l_2);
    l_29 = (safe_mod_func_int32_t_s_s((func_6(l_11, l_11, l_11, l_2) ^ l_11), 4294967295UL));
    g_38++;
    return g_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_28
 * writes: g_28
 */
static int8_t  func_6(int32_t  p_7, uint64_t  p_8, uint16_t  p_9, int8_t  p_10)
{ /* block id: 2 */
    int8_t l_20 = 1L;
    int32_t l_21 = (-1L);
    for (p_7 = 0; (p_7 >= (-28)); p_7--)
    { /* block id: 5 */
        l_21 &= (safe_add_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(0xC6FEL, l_20)), 0)), g_3));
        if (p_8)
            continue;
        return p_8;
    }
    g_28 ^= (func_22(((safe_div_func_int16_t_s_s(p_8, l_20)) < g_3), p_8) < g_3);
    return g_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int32_t  func_22(uint64_t  p_23, int8_t  p_24)
{ /* block id: 10 */
    int16_t l_27 = 0xDAB5L;
    l_27 = ((g_3 , 0x491BA6B42BE197E7LL) || p_23);
    return p_24;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 12
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 96.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 45.9
XXX percentage an existing variable is used: 54.1
********************* end of statistics **********************/

