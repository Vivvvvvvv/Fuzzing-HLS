/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11746289620300684161
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0L;
static volatile int32_t g_6 = 0x782A1836L;/* VOLATILE GLOBAL g_6 */
static int32_t g_7 = 0L;
static volatile int32_t g_33[9] = {(-1L),0x18264D92L,(-1L),(-1L),0x18264D92L,(-1L),(-1L),0x18264D92L,(-1L)};
static volatile uint16_t g_34 = 65535UL;/* VOLATILE GLOBAL g_34 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static const int16_t  func_11(int32_t  p_12);
static int32_t  func_13(int32_t  p_14, const int16_t  p_15, const int32_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_7 g_6 g_34 g_33
 * writes: g_2 g_7 g_34 g_6
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    const int8_t l_21[6] = {0x87L,0x93L,0x87L,0x87L,0x93L,0x87L};
    int32_t l_46 = 0L;
    int i;
    for (g_2 = 0; (g_2 >= (-13)); --g_2)
    { /* block id: 3 */
        int8_t l_5[7] = {0L,1L,0L,0L,1L,0L,0L};
        uint32_t l_8 = 0xC93EE327L;
        int i;
        for (g_7 = 6; (g_7 >= 1); g_7 -= 1)
        { /* block id: 6 */
            int i;
            l_8--;
            g_6 = (((func_11(func_13(((safe_sub_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u(l_5[g_7], l_5[g_7])) == 4294967295UL), g_6)) , (-7L)), l_21[1], g_7)) , 1L) , 0x19EFL) == 0xDDD0L);
        }
        g_6 ^= (l_21[2] > 0UL);
    }
    for (g_2 = (-10); (g_2 != (-5)); g_2++)
    { /* block id: 36 */
        int8_t l_43 = 0L;
        if (l_43)
            break;
        for (g_7 = 8; (g_7 >= 0); g_7 -= 1)
        { /* block id: 40 */
            int i;
            g_6 = ((g_33[g_7] , 6UL) <= 5UL);
        }
    }
    l_46 = (safe_lshift_func_int16_t_s_s((l_21[1] || 4294967295UL), g_2));
    g_2 |= g_34;
    return l_46;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_2
 * writes:
 */
static const int16_t  func_11(int32_t  p_12)
{ /* block id: 20 */
    int8_t l_39 = 0x40L;
    int32_t l_40 = (-2L);
    l_39 = 0xC2502870L;
    l_40 = p_12;
    l_40 = 0x0AE734F1L;
    for (p_12 = 0; (p_12 <= 8); p_12 += 1)
    { /* block id: 26 */
        int i;
        return g_33[p_12];
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_7 g_34 g_33 g_2
 * writes: g_34
 */
static int32_t  func_13(int32_t  p_14, const int16_t  p_15, const int32_t  p_16)
{ /* block id: 8 */
    int8_t l_26[10] = {0x26L,0x26L,0x26L,0x26L,0x26L,0x26L,0x26L,0x26L,0x26L,0x26L};
    int32_t l_29[10] = {0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL,0x47E0FA1AL};
    int i;
    p_14 |= ((((safe_mul_func_int8_t_s_s((safe_add_func_uint16_t_u_u(65533UL, 0x67F8L)), 0xE9L)) <= 0L) , 0xAEB382E5L) , l_26[1]);
    l_29[5] = (safe_sub_func_uint8_t_u_u(l_26[2], 3UL));
    for (p_14 = 0; (p_14 != 26); p_14++)
    { /* block id: 13 */
        uint32_t l_32[5];
        int i;
        for (i = 0; i < 5; i++)
            l_32[i] = 0x37F1BD53L;
        l_32[1] = (g_6 == g_7);
        --g_34;
        if (g_34)
            break;
    }
    l_29[5] = ((safe_mod_func_int32_t_s_s(((((g_7 >= p_15) > g_33[2]) >= 4294967294UL) != p_15), 0x7A832397L)) & g_2);
    return l_26[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_33[i], "g_33[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_34, "g_34", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 26
   depth: 2, occurrence: 9
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 16
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 78.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 8
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 28.9
XXX percentage an existing variable is used: 71.1
********************* end of statistics **********************/

