/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12704344388547026009
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int16_t  f0;
   uint32_t  f1;
   const volatile int16_t  f2;
   volatile uint8_t  f3;
   uint64_t  f4;
   const int32_t  f5;
   uint8_t  f6;
   uint32_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xDF37D45DL;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0xE6D4F288L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0x2E5664DCL;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = (-3L);
static uint16_t g_55 = 0x31A2L;
static const struct S0 g_76[8][6] = {{{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL}},{{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{0x045BL,9UL,7L,0xCCL,0x27AF4644DEA1A09BLL,-1L,0xBCL,0x1A03DC57L},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL}},{{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL}},{{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL},{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL}},{{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL},{0x045BL,9UL,7L,0xCCL,0x27AF4644DEA1A09BLL,-1L,0xBCL,0x1A03DC57L},{0x045BL,9UL,7L,0xCCL,0x27AF4644DEA1A09BLL,-1L,0xBCL,0x1A03DC57L},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL}},{{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{0x045BL,9UL,7L,0xCCL,0x27AF4644DEA1A09BLL,-1L,0xBCL,0x1A03DC57L},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL},{0x61F1L,1UL,-4L,0x69L,0UL,0x73440B9FL,9UL,0xBF7FA13AL},{-6L,18446744073709551615UL,0x0AD7L,0xA7L,0x2272BDBE1E68A7D7LL,0x4B927459L,0x60L,0x9B8BCB0FL}},{{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{0x5471L,0UL,0L,1UL,18446744073709551606UL,0x5603FBD5L,255UL,18446744073709551606UL},{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL},{0x045BL,9UL,7L,0xCCL,0x27AF4644DEA1A09BLL,-1L,0xBCL,0x1A03DC57L},{0x045BL,9UL,7L,0xCCL,0x27AF4644DEA1A09BLL,-1L,0xBCL,0x1A03DC57L}},{{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{0L,0xE90E87CAL,0L,0UL,0x8798E375BC53ECDFLL,0xDC4946A2L,1UL,18446744073709551610UL},{0xBFCAL,0x8CC9215AL,1L,255UL,8UL,0xFF440556L,0xACL,0x0F127D3BL},{0x61F1L,1UL,-4L,0x69L,0UL,0x73440B9FL,9UL,0xBF7FA13AL},{-1L,0UL,-6L,255UL,8UL,9L,0x7EL,18446744073709551615UL}}};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_11(uint32_t  p_12, uint32_t  p_13, int32_t  p_14);
static uint32_t  func_15(uint16_t  p_16, uint64_t  p_17, int64_t  p_18);
static uint16_t  func_33(int8_t  p_34);
static int16_t  func_39(uint16_t  p_40, int16_t  p_41, int64_t  p_42);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_2 g_3 g_55 g_76
 * writes: g_5 g_4 g_55 g_2 g_3
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_8 = 0UL;
    int32_t l_21 = (-3L);
    for (g_5 = 22; (g_5 > (-11)); g_5 = safe_sub_func_uint32_t_u_u(g_5, 5))
    { /* block id: 3 */
        int32_t l_77 = 0xF1F8E40AL;
        g_4 = l_8;
        for (l_8 = 0; (l_8 != 56); l_8++)
        { /* block id: 7 */
            int16_t l_22 = 0x64A1L;
            if (l_8)
                break;
            g_2 = func_11(func_15(((((((safe_rshift_func_uint8_t_u_u(l_21, 1)) , 0L) != g_4) > l_22) , g_2) < g_5), g_5, l_22), g_5, l_8);
            g_3 = (l_22 | 0xDC6CL);
            if (l_22)
                break;
        }
        for (l_8 = 0; (l_8 != 7); l_8++)
        { /* block id: 45 */
            uint32_t l_80 = 0xBABBD54EL;
            l_77 = (((g_76[4][2] , (-1L)) ^ g_76[4][2].f1) != g_55);
            g_3 = l_77;
            if (l_77)
                continue;
            g_4 |= (safe_mul_func_uint16_t_u_u(0x5129L, l_80));
        }
    }
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_4 g_3 g_55
 * writes: g_55
 */
static int32_t  func_11(uint32_t  p_12, uint32_t  p_13, int32_t  p_14)
{ /* block id: 12 */
    uint8_t l_35 = 255UL;
    int32_t l_53[5][1][8] = {{{0x0EC253D5L,0x3EB999C8L,1L,0x3EB999C8L,0x0EC253D5L,1L,1L,0x0EC253D5L}},{{0x3EB999C8L,6L,6L,0x3EB999C8L,0xEA1E1734L,0x0EC253D5L,0xEA1E1734L,0x3EB999C8L}},{{6L,0xEA1E1734L,6L,1L,1L,1L,1L,6L}},{{0xEA1E1734L,0xEA1E1734L,1L,0x0EC253D5L,1L,0x0EC253D5L,1L,0xEA1E1734L}},{{0xEA1E1734L,6L,1L,1L,1L,1L,6L,0xEA1E1734L}}};
    uint32_t l_61[6];
    uint32_t l_64 = 0x1B934971L;
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_61[i] = 4294967292UL;
    l_35 = (safe_lshift_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u((((safe_rshift_func_uint16_t_u_u(func_33(g_5), 7)) , g_2) >= 249UL), g_5)) != 4294967291UL), g_5));
    for (l_35 = 27; (l_35 > 53); ++l_35)
    { /* block id: 18 */
        int32_t l_46 = (-1L);
        int32_t l_49 = 0xCE43C7D7L;
        int32_t l_50 = 0x256FAE7AL;
        int32_t l_52 = (-1L);
        uint32_t l_71 = 0x6FF7DD1AL;
        if ((safe_unary_minus_func_int32_t_s(((p_14 >= l_35) <= p_13))))
        { /* block id: 19 */
            uint32_t l_47 = 4294967295UL;
            l_47 ^= (func_39((safe_rshift_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u(l_46)), 7)), l_46, g_4) , g_2);
            return g_3;
        }
        else
        { /* block id: 24 */
            int32_t l_48 = (-1L);
            int32_t l_51[2];
            int32_t l_54 = 0x1C50D5D7L;
            int i;
            for (i = 0; i < 2; i++)
                l_51[i] = 0xF4FC6A3FL;
            p_14 = l_48;
            --g_55;
            l_50 |= (!(((safe_rshift_func_uint8_t_u_u(0x67L, 2)) , l_51[1]) >= g_5));
        }
        --l_61[3];
        if (l_64)
        { /* block id: 30 */
            l_50 = (safe_rshift_func_int8_t_s_s(((l_46 && 0xC5DEL) , 0xA3L), 3));
        }
        else
        { /* block id: 32 */
            int8_t l_67 = (-6L);
            int32_t l_68 = 0x73ECB6AEL;
            int32_t l_69 = 1L;
            int32_t l_70[9][9] = {{(-1L),0xB28C330CL,0L,9L,0L,0xB28C330CL,(-1L),(-1L),0xB28C330CL},{9L,0xB28C330CL,(-1L),0xB28C330CL,9L,0L,0L,9L,0xB28C330CL},{(-1L),0L,(-1L),0L,(-1L),(-1L),0L,(-1L),0L},{0L,(-1L),0L,(-1L),(-1L),0L,(-1L),0L,(-1L)},{0xB28C330CL,9L,0L,0L,9L,0xB28C330CL,(-1L),0xB28C330CL,9L},{0xB28C330CL,(-1L),(-1L),0xB28C330CL,0L,9L,0L,0xB28C330CL,(-1L)},{0L,0L,(-1L),9L,0x02EAB385L,9L,(-1L),0L,0L},{(-1L),0xB28C330CL,0L,9L,0L,0xB28C330CL,(-1L),(-1L),0xB28C330CL},{9L,0xB28C330CL,(-1L),0xB28C330CL,9L,0L,0L,9L,0xB28C330CL}};
            int i, j;
            --l_71;
        }
        if (l_46)
            break;
    }
    p_14 &= ((p_12 == l_35) >= l_61[3]);
    return l_53[1][0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4
 * writes:
 */
static uint32_t  func_15(uint16_t  p_16, uint64_t  p_17, int64_t  p_18)
{ /* block id: 9 */
    uint32_t l_25 = 0xE2BF5F40L;
    int32_t l_26[6];
    int i;
    for (i = 0; i < 6; i++)
        l_26[i] = (-7L);
    l_26[4] = (safe_mul_func_uint8_t_u_u(g_3, l_25));
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static uint16_t  func_33(int8_t  p_34)
{ /* block id: 13 */
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int16_t  func_39(uint16_t  p_40, int16_t  p_41, int64_t  p_42)
{ /* block id: 20 */
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_76[i][j].f0, "g_76[i][j].f0", print_hash_value);
            transparent_crc(g_76[i][j].f1, "g_76[i][j].f1", print_hash_value);
            transparent_crc(g_76[i][j].f2, "g_76[i][j].f2", print_hash_value);
            transparent_crc(g_76[i][j].f3, "g_76[i][j].f3", print_hash_value);
            transparent_crc(g_76[i][j].f4, "g_76[i][j].f4", print_hash_value);
            transparent_crc(g_76[i][j].f5, "g_76[i][j].f5", print_hash_value);
            transparent_crc(g_76[i][j].f6, "g_76[i][j].f6", print_hash_value);
            transparent_crc(g_76[i][j].f7, "g_76[i][j].f7", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 33
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 41
XXX times a non-volatile is write: 15
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 36
XXX percentage of non-volatile access: 78.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 32
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 7
   depth: 2, occurrence: 15

XXX percentage a fresh-made variable is used: 28.3
XXX percentage an existing variable is used: 71.7
********************* end of statistics **********************/

