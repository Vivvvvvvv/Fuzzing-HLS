/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11904236482995610798
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
   const uint8_t  f1;
   volatile uint32_t  f2;
   uint32_t  f3;
   uint8_t  f4;
   volatile uint16_t  f5;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_8 = 5L;
static int8_t g_21[9] = {0L,(-1L),0L,0L,(-1L),0L,0L,(-1L),0L};
static volatile int32_t g_22 = 0x9B8FA48AL;/* VOLATILE GLOBAL g_22 */
static volatile int32_t g_23 = 0xEA2C39D5L;/* VOLATILE GLOBAL g_23 */
static int32_t g_24 = 0x1FB8EB5EL;
static uint32_t g_48 = 0x8C4B1E4FL;
static volatile uint8_t g_51 = 0x09L;/* VOLATILE GLOBAL g_51 */
static volatile struct S0 g_94 = {4UL,0x65L,0x89450AD3L,0xF8EFC5DFL,0xA5L,6UL};/* VOLATILE GLOBAL g_94 */
static struct S0 g_127 = {18446744073709551615UL,0xB2L,0x2917DE5EL,4294967291UL,1UL,0UL};/* VOLATILE GLOBAL g_127 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static const int32_t  func_5(int32_t  p_6, const int16_t  p_7);
static uint32_t  func_11(uint64_t  p_12);
static uint64_t  func_13(int32_t  p_14, uint32_t  p_15, int16_t  p_16);
static int32_t  func_17(int8_t  p_18, const uint16_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_24 g_22 g_21 g_23 g_48 g_51 g_94 g_127
 * writes: g_8 g_24 g_22 g_48 g_51 g_23 g_127.f4
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2 = 0x18D5816210B999FBLL;
    int32_t l_151 = 0x7B70EE5EL;
    l_2++;
    l_151 ^= func_5(g_8, l_2);
    return g_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_24 g_22 g_21 g_23 g_48 g_51 g_94 g_127
 * writes: g_8 g_24 g_22 g_48 g_51 g_23 g_127.f4
 */
static const int32_t  func_5(int32_t  p_6, const int16_t  p_7)
{ /* block id: 2 */
    int32_t l_20[7] = {0xA7609FA8L,0xA8FE2430L,0xA7609FA8L,0xA7609FA8L,0xA8FE2430L,0xA7609FA8L,0xA7609FA8L};
    int32_t l_143 = 0x4BF07F47L;
    uint32_t l_145 = 0x58245BBFL;
    int i;
    for (g_8 = (-6); (g_8 > 9); g_8 = safe_add_func_int16_t_s_s(g_8, 2))
    { /* block id: 5 */
        int16_t l_144[5][10] = {{8L,0x0CF3L,0L,0x0CF3L,8L,8L,0x0CF3L,0L,0x0CF3L,8L},{8L,0x0CF3L,0L,0x0CF3L,8L,8L,0x0CF3L,0L,0x0CF3L,8L},{8L,0x0CF3L,0L,0x0CF3L,8L,8L,0x0CF3L,0L,0x0CF3L,8L},{0x0CF3L,3L,0x1156L,3L,0x0CF3L,0x0CF3L,3L,0x1156L,3L,0x0CF3L},{0x0CF3L,3L,0x1156L,3L,0x0CF3L,0x0CF3L,3L,0x1156L,3L,0x0CF3L}};
        int i, j;
        if ((func_11((((func_13(func_17((((p_6 <= 0L) && g_8) , l_20[5]), p_6), g_8, g_8) < (-1L)) , 1UL) && l_20[2])) == 8UL))
        { /* block id: 114 */
            p_6 = (safe_add_func_int8_t_s_s(((p_7 > g_127.f0) || p_7), g_94.f1));
            ++l_145;
        }
        else
        { /* block id: 117 */
            int64_t l_150[5];
            int i;
            for (i = 0; i < 5; i++)
                l_150[i] = 0x2132D04EE4DB16BELL;
            p_6 |= ((((safe_lshift_func_int8_t_s_u((-1L), g_21[0])) > l_20[3]) , l_150[2]) ^ 0xB8F3L);
        }
    }
    return g_94.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_24 g_22 g_94.f5 g_94.f1 g_21 g_94.f2 g_127
 * writes: g_24 g_23 g_127.f4 g_22
 */
static uint32_t  func_11(uint64_t  p_12)
{ /* block id: 73 */
    uint16_t l_100 = 0UL;
    int32_t l_107[4] = {0x8039CC89L,0x8039CC89L,0x8039CC89L,0x8039CC89L};
    int32_t l_131 = 0xE0746DC9L;
    int i;
lbl_117:
    l_100 = (safe_sub_func_uint16_t_u_u(0x4202L, 0x1DB4L));
    for (p_12 = 24; (p_12 >= 34); p_12 = safe_add_func_uint16_t_u_u(p_12, 5))
    { /* block id: 77 */
        int32_t l_105[3];
        int16_t l_106 = 0x425FL;
        int i;
        for (i = 0; i < 3; i++)
            l_105[i] = 0x4279E96FL;
        l_107[3] |= (((safe_sub_func_uint32_t_u_u(p_12, l_105[1])) < g_23) , l_106);
        for (l_106 = 11; (l_106 < 3); l_106--)
        { /* block id: 81 */
            g_24 ^= 0x53257E1EL;
        }
        l_105[0] = ((l_105[2] || g_22) <= p_12);
        return g_24;
    }
    for (p_12 = (-19); (p_12 < 17); p_12 = safe_add_func_int32_t_s_s(p_12, 3))
    { /* block id: 89 */
        const int16_t l_116 = 0x56EDL;
        if ((safe_lshift_func_int16_t_s_s((((safe_lshift_func_uint16_t_u_u((0L == p_12), l_116)) , g_94.f5) || p_12), 7)))
        { /* block id: 90 */
            if (p_12)
                goto lbl_117;
        }
        else
        { /* block id: 92 */
            int64_t l_118 = 0xF68E754454C8FCCFLL;
            l_118 |= (((g_94.f1 != p_12) != g_21[5]) , 0x11AB6490L);
            return l_116;
        }
        g_23 = (safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s(((((g_94.f2 || (-1L)) != l_107[2]) , 0xD046L) <= l_116), g_24)) < 0x64L), 2UL)), 1)), p_12));
        if (g_24)
            break;
        g_24 = ((g_127 , l_107[3]) >= 0xDCL);
    }
    for (g_24 = 0; (g_24 < 13); g_24 = safe_add_func_uint16_t_u_u(g_24, 6))
    { /* block id: 102 */
        int32_t l_130 = 6L;
        l_131 = l_130;
        for (g_127.f4 = (-23); (g_127.f4 != 37); g_127.f4 = safe_add_func_uint64_t_u_u(g_127.f4, 3))
        { /* block id: 106 */
            uint8_t l_134 = 4UL;
            g_22 = g_127.f1;
            l_134++;
            g_23 = (((safe_add_func_uint16_t_u_u(g_127.f3, (-2L))) <= l_130) & 0xDD9846AC962BC758LL);
            l_131 = (((safe_sub_func_int64_t_s_s((p_12 , g_127.f4), 0L)) ^ l_134) ^ p_12);
        }
    }
    return l_107[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_48 g_22 g_51 g_8 g_24 g_23 g_94
 * writes: g_23 g_24
 */
static uint64_t  func_13(int32_t  p_14, uint32_t  p_15, int16_t  p_16)
{ /* block id: 53 */
    int32_t l_81 = (-8L);
    int16_t l_84 = 8L;
    if (((safe_add_func_uint32_t_u_u((+((safe_mul_func_int16_t_s_s((p_15 && 7L), l_81)) || l_81)), g_48)) | g_22))
    { /* block id: 54 */
        uint32_t l_88 = 0xD6516C33L;
        if ((g_51 == l_81))
        { /* block id: 55 */
            int32_t l_85 = 0x6AD74ACFL;
            p_14 &= (safe_mod_func_uint16_t_u_u((((((p_15 && l_84) <= g_8) <= g_24) == l_85) , g_48), 4UL));
        }
        else
        { /* block id: 57 */
            int32_t l_91 = 0x3387E9A7L;
            g_23 = (safe_add_func_uint32_t_u_u(g_51, l_88));
            l_81 ^= (((safe_lshift_func_uint8_t_u_u((((g_24 ^ l_91) == g_23) || 0x9DL), l_88)) , p_14) == 0x2B08325BL);
            g_23 = (safe_sub_func_uint16_t_u_u((g_94 , l_84), l_91));
            return p_16;
        }
    }
    else
    { /* block id: 63 */
        for (g_24 = 8; (g_24 >= 0); g_24 -= 1)
        { /* block id: 66 */
            int64_t l_95 = 0x13D8BF8503667010LL;
            l_95 &= 0x47AD0ED6L;
        }
        l_81 |= p_15;
    }
    p_14 = (safe_add_func_uint16_t_u_u((((((0xC92F557AL & g_22) , 1L) < g_8) <= l_84) < 0xA8FCL), l_84));
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_22 g_8 g_21 g_23 g_48 g_51
 * writes: g_24 g_22 g_48 g_51 g_23
 */
static int32_t  func_17(int8_t  p_18, const uint16_t  p_19)
{ /* block id: 6 */
    int8_t l_28 = (-3L);
    int32_t l_32 = 0x8A13C444L;
    const int64_t l_36 = (-4L);
    int32_t l_39 = 6L;
    int32_t l_44[8];
    int i;
    for (i = 0; i < 8; i++)
        l_44[i] = (-1L);
    for (p_18 = 0; (p_18 <= 8); p_18 += 1)
    { /* block id: 9 */
        int8_t l_27[2];
        int32_t l_29[1][7][5] = {{{0x4DB503B5L,0x4DB503B5L,(-1L),0x4DB503B5L,0x4DB503B5L},{1L,0x4DB503B5L,1L,1L,0x4DB503B5L},{0x4DB503B5L,1L,1L,0x4DB503B5L,1L},{0x4DB503B5L,0x4DB503B5L,(-1L),0x4DB503B5L,0x4DB503B5L},{1L,0x4DB503B5L,1L,1L,0x4DB503B5L},{0x4DB503B5L,1L,1L,0x4DB503B5L,1L},{0x4DB503B5L,0x4DB503B5L,(-1L),0x4DB503B5L,0x4DB503B5L}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_27[i] = 0x07L;
        if (p_18)
            break;
        for (g_24 = 8; (g_24 >= 0); g_24 -= 1)
        { /* block id: 13 */
            l_28 = ((safe_sub_func_int8_t_s_s(((((g_22 != 0x0B2455F9L) > 0x756FL) && l_27[0]) , g_24), g_8)) != g_24);
            if (g_21[7])
                break;
            l_29[0][0][4] ^= (l_27[0] >= p_19);
        }
    }
    if (g_21[0])
    { /* block id: 19 */
        for (p_18 = 0; (p_18 > (-19)); p_18--)
        { /* block id: 22 */
            if (g_23)
                break;
        }
    }
    else
    { /* block id: 25 */
        uint64_t l_35 = 6UL;
        int32_t l_40 = 0x167647CFL;
        int32_t l_41 = (-2L);
        int32_t l_43 = 0x83830386L;
        int32_t l_46 = 0x4B24D3E4L;
        int32_t l_47 = 0xB63E3B66L;
        l_32 = ((p_19 , g_23) == 0x83L);
        if (((safe_add_func_uint8_t_u_u(l_35, l_36)) > (-8L)))
        { /* block id: 27 */
            uint32_t l_37 = 0xBBB531EAL;
            g_22 &= l_37;
            if (g_8)
                goto lbl_38;
lbl_38:
            g_24 = 0L;
            g_22 = (7UL < g_8);
        }
        else
        { /* block id: 32 */
            int64_t l_42 = 0x177355A2C03FDDA7LL;
            int32_t l_45[4][9][3] = {{{0xCA00AF40L,0xCA00AF40L,0x3A0C94A7L},{0xD0A06037L,0x2B3A3C3AL,0x29496125L},{8L,0x739BB5F3L,0xCA00AF40L},{0x4F7CB2C1L,0xD796E990L,0xA4ED9E62L},{0xCAF6DDF9L,8L,0xCA00AF40L},{0x17913DA5L,0x29496125L,0x29496125L},{0xAD6E3F99L,0xD830BF04L,0x3A0C94A7L},{0x71C9EEB3L,0x1BA05761L,0x2B46DFF6L},{0x743585F1L,(-10L),0x66FFBA24L}},{{0x2B46DFF6L,0x4F7CB2C1L,(-8L)},{7L,(-10L),1L},{1L,0x1BA05761L,1L},{(-10L),0xD830BF04L,8L},{0x2B3A3C3AL,0x29496125L,7L},{1L,8L,0x4AC155EAL},{4L,0xD796E990L,0L},{1L,0x739BB5F3L,0xCAF6DDF9L},{0x2B3A3C3AL,0x2B3A3C3AL,0x1BA05761L}},{{(-10L),0xCA00AF40L,0x4A05A9EEL},{1L,1L,0x2B3A3C3AL},{7L,0x358509EFL,0x66072949L},{0x2B46DFF6L,1L,0x2B3A3C3AL},{0x743585F1L,0x4A05A9EEL,0x4A05A9EEL},{0x71C9EEB3L,4L,0x1BA05761L},{0xAD6E3F99L,0x3A0C94A7L,0xCAF6DDF9L},{0x17913DA5L,0xD0A06037L,0L},{0xCAF6DDF9L,7L,0x4AC155EAL}},{{0x4F7CB2C1L,0xD0A06037L,7L},{8L,0x3A0C94A7L,8L},{0xD0A06037L,4L,1L},{0xCA00AF40L,0x4A05A9EEL,1L},{7L,1L,(-8L)},{0xD830BF04L,0x358509EFL,0x66FFBA24L},{7L,1L,0x2B46DFF6L},{0xCA00AF40L,0xCA00AF40L,0x3A0C94A7L},{0xD0A06037L,0x2B3A3C3AL,0x29496125L}}};
            int i, j, k;
            ++g_48;
        }
        ++g_51;
        for (g_48 = 0; (g_48 <= 7); g_48 += 1)
        { /* block id: 38 */
            int32_t l_59[9][3] = {{0x6D6BBB23L,0x384E0590L,0x5137C5FDL},{0x6D6BBB23L,0x4B5445D8L,0x6D6BBB23L},{0x6D6BBB23L,0x2579B7B7L,0x34EA093EL},{0x6D6BBB23L,0x384E0590L,0x5137C5FDL},{0x6D6BBB23L,0x4B5445D8L,0x6D6BBB23L},{0x6D6BBB23L,0x2579B7B7L,0x34EA093EL},{0x6D6BBB23L,0x384E0590L,0x5137C5FDL},{0x6D6BBB23L,0x4B5445D8L,0x6D6BBB23L},{0x2B236EDAL,0x6D6BBB23L,1L}};
            int i, j;
            l_44[g_48] = (safe_add_func_uint64_t_u_u((((((safe_unary_minus_func_uint8_t_u((safe_mod_func_int32_t_s_s(l_44[g_48], g_23)))) == l_44[g_48]) > 5UL) ^ g_8) , 2UL), p_18));
            l_59[6][0] |= l_44[g_48];
        }
    }
    for (l_32 = 15; (l_32 == 28); l_32++)
    { /* block id: 45 */
        uint32_t l_74 = 0x3036CC05L;
        if ((safe_mod_func_int32_t_s_s(((safe_add_func_int16_t_s_s((safe_div_func_int16_t_s_s(g_22, 0xF612L)), 0L)) > p_18), g_8)))
        { /* block id: 46 */
            int16_t l_75 = 0x248FL;
            g_24 ^= (safe_sub_func_int32_t_s_s((safe_rshift_func_int8_t_s_u((safe_lshift_func_int16_t_s_s((((l_74 < l_75) | l_74) <= p_18), l_74)), 0)), l_74));
        }
        else
        { /* block id: 48 */
            g_23 = g_51;
        }
    }
    return g_21[5];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_21[i], "g_21[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_94.f0, "g_94.f0", print_hash_value);
    transparent_crc(g_94.f1, "g_94.f1", print_hash_value);
    transparent_crc(g_94.f2, "g_94.f2", print_hash_value);
    transparent_crc(g_94.f3, "g_94.f3", print_hash_value);
    transparent_crc(g_94.f4, "g_94.f4", print_hash_value);
    transparent_crc(g_94.f5, "g_94.f5", print_hash_value);
    transparent_crc(g_127.f0, "g_127.f0", print_hash_value);
    transparent_crc(g_127.f1, "g_127.f1", print_hash_value);
    transparent_crc(g_127.f2, "g_127.f2", print_hash_value);
    transparent_crc(g_127.f3, "g_127.f3", print_hash_value);
    transparent_crc(g_127.f4, "g_127.f4", print_hash_value);
    transparent_crc(g_127.f5, "g_127.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 44
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 65
   depth: 2, occurrence: 17
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 6
   depth: 10, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 107
XXX times a non-volatile is write: 39
XXX times a volatile is read: 20
XXX    times read thru a pointer: 0
XXX times a volatile is write: 9
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 84
XXX percentage of non-volatile access: 83.4

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 69
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 22
   depth: 2, occurrence: 30

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
********************* end of statistics **********************/

