/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7069219838515409451
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[3][7] = {{0xF2000252L,0x5B9B55BBL,0x5B9B55BBL,0xF2000252L,0xF2000252L,0x5B9B55BBL,0x5B9B55BBL},{0x18795010L,1L,0x18795010L,1L,0x18795010L,1L,0x18795010L},{0xF2000252L,0xF2000252L,0x5B9B55BBL,0x5B9B55BBL,0xF2000252L,0xF2000252L,0x5B9B55BBL}};
static volatile int32_t g_3 = 0xD2D672A8L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4[6] = {0xBD4DFBD6L,0xBD4DFBD6L,0xBD4DFBD6L,0xBD4DFBD6L,0xBD4DFBD6L,0xBD4DFBD6L};
static int32_t g_5 = 0x021C3A23L;
static volatile int32_t g_8 = 7L;/* VOLATILE GLOBAL g_8 */
static int32_t g_9 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_12(uint32_t  p_13, int16_t  p_14, uint64_t  p_15, int16_t  p_16, uint32_t  p_17);
static int32_t  func_32(uint16_t  p_33, const int32_t  p_34);
static int32_t  func_42(const uint64_t  p_43, int8_t  p_44, uint8_t  p_45);
static uint32_t  func_51(int64_t  p_52, uint8_t  p_53);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_9 g_2 g_4 g_8 g_3
 * writes: g_5 g_9 g_2 g_8 g_4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_18 = 0UL;
    for (g_5 = (-28); (g_5 > (-1)); g_5 = safe_add_func_int8_t_s_s(g_5, 7))
    { /* block id: 3 */
        int32_t l_19 = 0L;
        for (g_9 = 0; (g_9 > (-17)); g_9 = safe_sub_func_uint16_t_u_u(g_9, 8))
        { /* block id: 6 */
            int32_t l_20 = (-10L);
            g_2[1][3] = (func_12(l_18, l_19, g_2[1][1], l_20, g_9) != g_5);
            l_19 = func_32((safe_mul_func_uint16_t_u_u((!((safe_lshift_func_uint8_t_u_s(g_2[1][3], 0)) | 0x4C6F444694486CAELL)), l_19)), g_5);
            return g_5;
        }
    }
    return g_2[0][2];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_12(uint32_t  p_13, int16_t  p_14, uint64_t  p_15, int16_t  p_16, uint32_t  p_17)
{ /* block id: 7 */
    uint16_t l_21 = 1UL;
    int32_t l_28 = 8L;
    uint64_t l_29 = 0xF0A0CD95FF79FACDLL;
    l_21--;
    for (l_21 = (-17); (l_21 < 43); l_21++)
    { /* block id: 11 */
        l_28 = (safe_div_func_uint8_t_u_u(l_21, p_13));
    }
    ++l_29;
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_8 g_5 g_9 g_3 g_2
 * writes: g_8 g_4 g_2
 */
static int32_t  func_32(uint16_t  p_33, const int32_t  p_34)
{ /* block id: 17 */
    int64_t l_46 = (-1L);
    int32_t l_119 = 1L;
    int8_t l_123 = (-9L);
    for (p_33 = 0; (p_33 <= 10); p_33++)
    { /* block id: 20 */
        uint32_t l_120 = 0x79527C19L;
        int32_t l_124 = 0L;
        for (g_8 = 0; g_8 < 6; g_8 += 1)
        {
            g_4[g_8] = 0xFDEABFD0L;
        }
        if (func_42(g_4[5], p_33, l_46))
        { /* block id: 62 */
            uint32_t l_116 = 4294967286UL;
            l_116 |= (0x0777L ^ g_2[0][0]);
            l_119 = ((((safe_div_func_uint32_t_u_u(l_46, p_33)) < 0UL) , p_34) < g_4[2]);
            g_2[1][3] ^= 0xD215C821L;
            l_120 |= p_33;
        }
        else
        { /* block id: 67 */
            int32_t l_127 = 0x5CA99100L;
            l_124 = (safe_unary_minus_func_int64_t_s((!(0x86F9L > l_123))));
            g_4[2] = (((((safe_sub_func_uint64_t_u_u((p_34 >= (-5L)), l_127)) , g_2[1][3]) == 0xE44AL) > l_127) > 0xF0BFBC33L);
            l_119 = (safe_add_func_uint32_t_u_u((~(((g_4[5] != g_9) | l_120) | l_127)), g_9));
            g_2[1][3] = (p_34 != l_127);
        }
        return l_124;
    }
    for (l_46 = (-16); (l_46 == (-14)); ++l_46)
    { /* block id: 77 */
        uint32_t l_133 = 0UL;
        l_133--;
        if (l_133)
            continue;
        g_4[2] = (((~((safe_div_func_uint64_t_u_u(((1L && g_3) && 0xE95AL), p_33)) < g_5)) | 0x3EB4EFABF27EFC0ALL) , g_3);
        if (l_46)
            continue;
    }
    for (p_33 = 0; (p_33 > 1); p_33 = safe_add_func_uint64_t_u_u(p_33, 1))
    { /* block id: 85 */
        return g_5;
    }
    return g_2[1][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_5 g_9 g_4 g_3 g_2
 * writes: g_4 g_2 g_8
 */
static int32_t  func_42(const uint64_t  p_43, int8_t  p_44, uint8_t  p_45)
{ /* block id: 22 */
    uint16_t l_54 = 65534UL;
    int32_t l_87 = (-2L);
    int32_t l_91[5] = {0xFA3C451EL,0xFA3C451EL,0xFA3C451EL,0xFA3C451EL,0xFA3C451EL};
    int32_t l_92[10][6] = {{0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL,3L},{0x68B3AD7DL,0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL},{0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL,3L},{0x68B3AD7DL,0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL},{0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL,3L},{0x68B3AD7DL,0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL},{0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL,3L},{0x68B3AD7DL,0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL},{0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL,3L},{0x68B3AD7DL,0x68B3AD7DL,3L,3L,0x68B3AD7DL,0x68B3AD7DL}};
    uint32_t l_97[5];
    int16_t l_110[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int i, j;
    for (i = 0; i < 5; i++)
        l_97[i] = 0x926A3224L;
lbl_90:
    l_87 |= ((safe_div_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(((func_51((((g_8 <= p_44) < l_54) && g_5), g_9) , p_44) ^ g_9), l_54)), p_45)) >= 7UL);
    if ((safe_lshift_func_uint16_t_u_s((g_4[0] ^ g_5), 8)))
    { /* block id: 47 */
        l_87 &= (8L > (-2L));
        if (p_45)
            goto lbl_90;
    }
    else
    { /* block id: 50 */
        int32_t l_93 = 0xECC2D129L;
        int32_t l_94 = 0xCF5D4612L;
        int32_t l_95 = 0x907242BEL;
        int32_t l_96[10][3][8] = {{{1L,0xCBE7429DL,1L,0xDBB19D54L,(-1L),1L,0x2A0B0D0EL,7L},{0xCBE7429DL,0xDDD92722L,(-1L),0xEF54216EL,0x3DA97B9BL,0L,0xC2CD367FL,0xBE0E570CL},{0x135D3F9AL,0x2579A822L,0xDDD92722L,0x41D5C681L,0xABF7BAE7L,0xCBE7429DL,(-1L),0x2A0B0D0EL}},{{0L,(-4L),0xA7A6E092L,1L,0x5FF039C0L,0x2A0B0D0EL,0L,0L},{7L,0x53D9EB36L,0xA49BCD99L,0x42CBA375L,0L,1L,0x8DD06FEDL,0x5B6CEA37L},{(-1L),(-6L),(-4L),(-1L),(-4L),(-6L),(-1L),0x2579A822L}},{{(-1L),0L,0xEF54216EL,(-7L),0x2A0B0D0EL,(-4L),0x5B6CEA37L,(-8L)},{2L,(-7L),6L,0xCBE7429DL,0x2A0B0D0EL,(-1L),0x42CBA375L,(-1L)},{(-1L),0x82B3C324L,0xE00DC0F6L,(-8L),(-4L),0x3605A4DEL,(-6L),0xA7A6E092L}},{{(-1L),1L,2L,0x2A0B0D0EL,0L,0xF8135449L,0xDDD92722L,0x3605A4DEL},{7L,0x135D3F9AL,(-8L),0x8DD06FEDL,0x5FF039C0L,0xC2CD367FL,0x82B3C324L,0L},{0L,2L,(-6L),(-7L),0xABF7BAE7L,0x135D3F9AL,0x135D3F9AL,0xABF7BAE7L}},{{0x135D3F9AL,0x2A0B0D0EL,0x2A0B0D0EL,0x135D3F9AL,0x3DA97B9BL,0L,7L,0L},{0xCBE7429DL,0L,2L,0x53D9EB36L,(-1L),0L,0xA49BCD99L,(-6L)},{1L,0L,0xDBB19D54L,2L,(-1L),0L,0xCBE7429DL,1L}},{{0xBE0E570CL,0x2A0B0D0EL,0x5B6CEA37L,2L,0x8DD06FEDL,0x135D3F9AL,(-1L),0xF8135449L},{0xA7A6E092L,2L,0xD9CFB06AL,1L,0x736DE7CAL,0xC2CD367FL,(-1L),0L},{0xA49BCD99L,(-1L),6L,(-1L),0xD9CFB06AL,1L,0L,(-8L)}},{{0L,0x8DD06FEDL,7L,(-1L),0xE00DC0F6L,(-1L),7L,0x8DD06FEDL},{0x2579A822L,0x41D5C681L,0L,1L,0L,0xCD86053CL,1L,2L},{0xBE0E570CL,0x42CBA375L,0xCD86053CL,(-4L),0x2579A822L,(-1L),1L,0L}},{{1L,(-4L),0L,0xCD86053CL,6L,1L,7L,0xA49BCD99L},{6L,1L,7L,0xA49BCD99L,0x41D5C681L,0x53D9EB36L,0L,0x2579A822L},{0x3DA97B9BL,(-8L),6L,0xDBB19D54L,(-7L),0L,2L,(-6L)}},{{0x135D3F9AL,(-1L),0L,0x8DD06FEDL,(-1L),0xF8135449L,0x5FF039C0L,0x5FF039C0L},{1L,0xDBB19D54L,0xC2CD367FL,0xC2CD367FL,0xDBB19D54L,1L,0xF8135449L,2L},{0x41D5C681L,0xBE0E570CL,0xEF54216EL,0xA7A6E092L,0x135D3F9AL,(-6L),1L,(-7L)}},{{0xC2CD367FL,0xF8135449L,(-1L),0xA7A6E092L,(-1L),0L,0xDDD92722L,2L},{(-1L),(-1L),0L,0xC2CD367FL,(-1L),0xABF7BAE7L,(-1L),0x5FF039C0L},{1L,0xE00DC0F6L,1L,0x8DD06FEDL,0x3DA97B9BL,0L,0x41D5C681L,(-6L)}}};
        int i, j, k;
        l_97[0]--;
        if (l_96[3][2][4])
        { /* block id: 52 */
            uint32_t l_104[9];
            int32_t l_105 = 1L;
            int i;
            for (i = 0; i < 9; i++)
                l_104[i] = 1UL;
            l_105 = (safe_add_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(p_43, g_2[0][2])), l_104[8]));
            return l_87;
        }
        else
        { /* block id: 55 */
            uint64_t l_111 = 0x3B5DB32916D73FB0LL;
            l_92[0][5] = (safe_div_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(l_110[3], g_5)), l_111));
            l_92[0][2] = (((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s((g_4[5] , g_9), 0)), g_5)) || 0x2FL) ^ g_5);
            return g_9;
        }
    }
    return p_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_5 g_9 g_8 g_2
 * writes: g_4 g_2 g_8
 */
static uint32_t  func_51(int64_t  p_52, uint8_t  p_53)
{ /* block id: 23 */
    uint8_t l_59 = 0x77L;
    int32_t l_60 = 0xF0AB59A6L;
    int32_t l_61[2];
    int i;
    for (i = 0; i < 2; i++)
        l_61[i] = 0L;
    for (p_53 = 0; (p_53 <= 5); p_53 += 1)
    { /* block id: 26 */
        int32_t l_66 = (-1L);
        int32_t l_67 = 0x9C2329B6L;
        int32_t l_69 = 0L;
        uint32_t l_70 = 0xFC4B74E4L;
        int i;
        g_4[p_53] = (safe_mod_func_uint64_t_u_u((safe_add_func_uint16_t_u_u(((0x550032DCL <= 0x837DEF5FL) | (-1L)), g_4[p_53])), l_59));
        for (l_59 = 0; (l_59 <= 2); l_59 += 1)
        { /* block id: 30 */
            int32_t l_62 = 0x61826471L;
            int32_t l_63 = (-1L);
            int32_t l_64 = (-1L);
            int32_t l_65 = 0xE433C58DL;
            int32_t l_68[8] = {0xFD97811DL,(-1L),0xFD97811DL,(-1L),0xFD97811DL,(-1L),0xFD97811DL,(-1L)};
            int i, j;
            ++l_70;
        }
        for (l_59 = 0; (l_59 != 42); l_59 = safe_add_func_int8_t_s_s(l_59, 7))
        { /* block id: 35 */
            uint16_t l_83 = 0x6FE6L;
            g_2[1][6] = (safe_lshift_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(((l_61[1] | g_3) < 1UL), 3)), 6)) > g_5), g_5)), l_83));
        }
        for (l_59 = 0; (l_59 <= 50); l_59 = safe_add_func_uint32_t_u_u(l_59, 5))
        { /* block id: 40 */
            g_8 ^= (((+p_52) , p_53) , g_9);
            g_4[p_53] = p_52;
        }
    }
    return g_2[1][3];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 40
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 15
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 73
XXX times a non-volatile is write: 27
XXX times a volatile is read: 18
XXX    times read thru a pointer: 0
XXX times a volatile is write: 9
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 82
XXX percentage of non-volatile access: 78.7

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 53
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 18
   depth: 2, occurrence: 20

XXX percentage a fresh-made variable is used: 24.7
XXX percentage an existing variable is used: 75.3
********************* end of statistics **********************/

