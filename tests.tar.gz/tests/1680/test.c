/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15748212108578342838
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_3 = (-1L);
static uint8_t g_39[9] = {0UL,253UL,0UL,0UL,253UL,0UL,0UL,253UL,0UL};
static uint32_t g_52 = 0xBB799E60L;


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);
static int32_t  func_5(uint32_t  p_6, int32_t  p_7, uint32_t  p_8);
static int16_t  func_13(int32_t  p_14, int32_t  p_15, uint64_t  p_16, int16_t  p_17, int8_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_39
 * writes: g_3 g_39 g_52
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = 0xF01CL;
    int32_t l_4 = 0L;
    g_3 |= l_2;
    l_4 = ((l_2 , g_3) < g_3);
    l_4 ^= (l_2 || g_3);
    g_52 = func_5(l_4, g_3, l_4);
    return l_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_39
 * writes: g_39
 */
static int32_t  func_5(uint32_t  p_6, int32_t  p_7, uint32_t  p_8)
{ /* block id: 4 */
    int32_t l_21[1];
    int32_t l_22 = 0x38E486AEL;
    int32_t l_43 = (-1L);
    int i;
    for (i = 0; i < 1; i++)
        l_21[i] = (-1L);
    l_22 = ((safe_sub_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s(func_13((safe_sub_func_uint8_t_u_u(247UL, l_21[0])), g_3, p_7, l_22, l_21[0]), l_21[0])) | g_3), 0L)) , p_7);
    --g_39[6];
    l_21[0] = ((((((((safe_unary_minus_func_uint32_t_u(((-9L) & l_43))) != p_8) | p_7) >= l_21[0]) || l_21[0]) <= g_3) < l_22) || g_3);
    for (l_22 = (-24); (l_22 <= 14); l_22 = safe_add_func_int64_t_s_s(l_22, 5))
    { /* block id: 15 */
        uint32_t l_46[7] = {5UL,5UL,5UL,5UL,5UL,5UL,5UL};
        int32_t l_47 = 0xD584125DL;
        int i;
        l_47 = l_46[3];
        l_21[0] |= (safe_mul_func_int8_t_s_s(((((safe_mul_func_uint8_t_u_u(0x21L, g_3)) , p_6) ^ l_46[3]) >= l_43), p_6));
    }
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int16_t  func_13(int32_t  p_14, int32_t  p_15, uint64_t  p_16, int16_t  p_17, int8_t  p_18)
{ /* block id: 5 */
    int8_t l_23 = 0x78L;
    int32_t l_26 = 0x493876A4L;
    uint8_t l_37 = 0xECL;
    int32_t l_38[3];
    int i;
    for (i = 0; i < 3; i++)
        l_38[i] = 3L;
    l_23 = g_3;
    l_26 = (safe_rshift_func_int8_t_s_u(l_26, 4));
    l_38[0] &= ((safe_rshift_func_uint8_t_u_u((safe_div_func_int16_t_s_s((((safe_sub_func_uint64_t_u_u(((safe_sub_func_int8_t_s_s((safe_add_func_uint64_t_u_u(g_3, 9L)), 2UL)) >= (-9L)), 0x6E623B26D5D64F68LL)) && 0L) , 0x31C0L), l_26)), l_37)) , g_3);
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 41
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 26.9
XXX percentage an existing variable is used: 73.1
********************* end of statistics **********************/

