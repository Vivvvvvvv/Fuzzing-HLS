/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5855629602494789478
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_17[5][1] = {{(-6L)},{(-6L)},{(-6L)},{(-6L)},{(-6L)}};
static int32_t g_26 = 0L;
static int64_t g_36 = 0x9A9D0127420EA1BCLL;
static volatile int16_t g_55 = 0x1C5AL;/* VOLATILE GLOBAL g_55 */
static volatile uint32_t g_57 = 0xAA7F794FL;/* VOLATILE GLOBAL g_57 */
static volatile uint16_t g_97[9] = {8UL,1UL,1UL,8UL,1UL,1UL,8UL,1UL,1UL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_11(uint16_t  p_12, int16_t  p_13, const uint32_t  p_14, const uint16_t  p_15, uint64_t  p_16);
static int32_t  func_27(int16_t  p_28, int32_t  p_29, uint32_t  p_30, uint64_t  p_31, int8_t  p_32);
static int32_t  func_39(int32_t  p_40);
static uint64_t  func_41(int64_t  p_42, const uint64_t  p_43, int32_t  p_44, uint64_t  p_45);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_17 g_26 g_57 g_55 g_36 g_97
 * writes: g_26 g_36 g_57 g_97
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_18 = 1UL;
    int32_t l_103 = 4L;
    l_103 = (safe_sub_func_int32_t_s_s((safe_unary_minus_func_uint8_t_u(((safe_sub_func_uint64_t_u_u(((safe_sub_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_s((func_11(((((g_17[4][0] , g_17[4][0]) | g_17[4][0]) , l_18) , g_17[4][0]), g_17[4][0], l_18, l_18, g_17[4][0]) <= 0x27L), 10)) < g_17[1][0]) | 0x8FF5528475ADB6E2LL), 0x9977ACE7L)) , l_18), 0xD3BBE6313C76A600LL)) && l_18))), g_17[4][0]));
    l_103 &= (((safe_mod_func_uint32_t_u_u(((safe_div_func_uint16_t_u_u(((g_97[8] | g_17[4][0]) | l_18), g_26)) & g_17[4][0]), (-6L))) != g_17[4][0]) ^ g_17[3][0]);
    for (l_18 = 3; (l_18 <= 8); l_18 += 1)
    { /* block id: 82 */
        int8_t l_113 = 1L;
        int i;
        if ((safe_mod_func_uint16_t_u_u(65528UL, g_97[l_18])))
        { /* block id: 83 */
            uint16_t l_110 = 2UL;
            g_26 ^= l_110;
            l_103 = ((safe_div_func_int64_t_s_s(g_17[4][0], g_26)) && g_17[4][0]);
        }
        else
        { /* block id: 86 */
            return g_57;
        }
        for (g_26 = 7; (g_26 >= 1); g_26 -= 1)
        { /* block id: 91 */
            uint8_t l_116 = 0xF5L;
            if (g_55)
                break;
            if (l_113)
                continue;
            l_103 = ((safe_div_func_uint16_t_u_u(((-8L) & g_55), l_116)) > l_103);
        }
    }
    for (l_103 = 0; (l_103 < 0); ++l_103)
    { /* block id: 99 */
        return g_55;
    }
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_26 g_57 g_55 g_36 g_97
 * writes: g_26 g_36 g_57 g_97
 */
static int8_t  func_11(uint16_t  p_12, int16_t  p_13, const uint32_t  p_14, const uint16_t  p_15, uint64_t  p_16)
{ /* block id: 1 */
    uint64_t l_21 = 0x641B44ADCA1A1F05LL;
    const int32_t l_22 = 0L;
    int32_t l_23 = 0x74B6046EL;
    uint8_t l_33 = 0x5EL;
    l_23 = ((safe_mod_func_int64_t_s_s((((p_16 ^ l_21) > g_17[4][0]) || g_17[0][0]), l_22)) , l_21);
    for (p_16 = 0; (p_16 == 59); p_16++)
    { /* block id: 5 */
        int32_t l_102[7][7] = {{0xA5961B9AL,0xDAB18E11L,(-9L),0x50866D82L,0x50866D82L,(-9L),0xDAB18E11L},{(-1L),0xA5961B9AL,3L,(-1L),0x48E3606EL,(-9L),0xE731193FL},{(-2L),0L,0xF0ABFABCL,0x47896B8AL,0x68EE181CL,0x50866D82L,0x68EE181CL},{(-1L),0x68EE181CL,0x68EE181CL,(-1L),0L,0xE731193FL,0x47896B8AL},{0xE731193FL,0x68EE181CL,(-2L),0x50866D82L,(-9L),3L,0xE731193FL},{0xA5961B9AL,0L,0x47896B8AL,(-1L),0x47896B8AL,0L,0xA5961B9AL},{0x68EE181CL,(-1L),0L,0xE731193FL,0x47896B8AL,7L,0xF0ABFABCL}};
        int i, j;
        if (g_17[4][0])
            break;
        g_26 = 1L;
        l_102[3][2] = func_27(l_23, l_33, l_22, g_26, p_12);
        l_23 ^= (((((g_17[4][0] , g_97[8]) & g_36) > l_33) < 0L) == l_102[1][5]);
    }
    return g_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_26 g_17 g_57 g_55 g_36 g_97
 * writes: g_26 g_36 g_57 g_97
 */
static int32_t  func_27(int16_t  p_28, int32_t  p_29, uint32_t  p_30, uint64_t  p_31, int8_t  p_32)
{ /* block id: 8 */
    const uint16_t l_37 = 6UL;
    int32_t l_38 = 0x30971CF7L;
    int32_t l_96 = 0L;
    for (g_26 = 0; (g_26 < 27); g_26 = safe_add_func_int16_t_s_s(g_26, 1))
    { /* block id: 11 */
        g_36 = ((g_17[4][0] <= 4UL) | 4294967289UL);
    }
    l_38 = l_37;
    if (((func_39((func_41(g_17[0][0], l_38, g_17[2][0], g_17[0][0]) , 1L)) >= p_32) | 0xEF5EL))
    { /* block id: 52 */
        int32_t l_85 = 0xA6071001L;
        l_85 = 2L;
        g_26 = (safe_rshift_func_int16_t_s_u(p_28, 3));
    }
    else
    { /* block id: 55 */
        int8_t l_90[7][2] = {{(-7L),1L},{1L,(-7L)},{1L,1L},{(-7L),1L},{1L,(-7L)},{1L,1L},{(-7L),1L}};
        int32_t l_95 = 6L;
        int i, j;
        for (p_28 = 0; (p_28 >= 0); p_28 -= 1)
        { /* block id: 58 */
            l_38 ^= (safe_sub_func_uint16_t_u_u(((l_90[4][0] , g_55) || 0xCAL), p_28));
            l_38 = 1L;
            return g_17[3][0];
        }
        l_95 = ((safe_sub_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(65526UL, g_36)), l_90[5][0])) || g_55);
        ++g_97[8];
        for (p_32 = 0; (p_32 > (-4)); --p_32)
        { /* block id: 67 */
            l_95 = p_32;
            l_96 &= 0xB81C666DL;
        }
    }
    l_96 = g_97[0];
    return g_17[1][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_26 g_55 g_17
 * writes:
 */
static int32_t  func_39(int32_t  p_40)
{ /* block id: 32 */
    int32_t l_70 = 0x87E8D9F6L;
    l_70 = (safe_mod_func_uint64_t_u_u(0x692AFB55E8A086CCLL, p_40));
    for (p_40 = 0; (p_40 != 24); p_40 = safe_add_func_uint32_t_u_u(p_40, 1))
    { /* block id: 36 */
        int16_t l_79 = 0xA47AL;
        int32_t l_84 = (-1L);
        if (l_70)
        { /* block id: 37 */
            uint16_t l_73 = 65535UL;
            uint8_t l_74 = 255UL;
            uint8_t l_75 = 0xE4L;
            l_73 = (p_40 & 0UL);
            l_75 &= ((((0xFD26F361030FACFALL == l_74) , l_70) | l_74) <= l_70);
        }
        else
        { /* block id: 40 */
            uint32_t l_76 = 0xCEE7E287L;
            l_76++;
            l_79 = 1L;
        }
        if ((p_40 == 0L))
        { /* block id: 44 */
            return l_70;
        }
        else
        { /* block id: 46 */
            l_84 &= (safe_rshift_func_uint16_t_u_s((safe_div_func_int64_t_s_s(g_26, l_70)), l_79));
            return g_55;
        }
    }
    return g_17[1][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_26 g_17 g_57
 * writes: g_26 g_57
 */
static uint64_t  func_41(int64_t  p_42, const uint64_t  p_43, int32_t  p_44, uint64_t  p_45)
{ /* block id: 15 */
    int64_t l_51 = 0xC82F3C076A5D0C9ALL;
    int32_t l_53[6];
    int i;
    for (i = 0; i < 6; i++)
        l_53[i] = 0x45EB447FL;
    for (p_44 = 0; (p_44 >= 0); p_44 -= 1)
    { /* block id: 18 */
        int32_t l_46 = 0xD89188B9L;
        int32_t l_52 = 0L;
        int32_t l_54 = 0x6B299B5FL;
        int32_t l_56 = 7L;
        l_46 &= p_42;
        l_52 = ((((safe_rshift_func_int8_t_s_s(l_51, l_51)) > 0xF607DBC1552C2547LL) ^ 4L) >= 0UL);
        for (g_26 = 0; (g_26 <= 0); g_26 += 1)
        { /* block id: 23 */
            int i, j;
            l_53[4] = ((g_17[g_26][g_26] & g_17[0][0]) ^ 0xF427L);
            --g_57;
            if (l_54)
                break;
        }
        l_52 = (safe_rshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_u(0UL, l_53[2])), l_54));
    }
    p_44 = (safe_div_func_int32_t_s_s((safe_lshift_func_uint16_t_u_s(l_53[1], 11)), 0x2A55CCBDL));
    return p_44;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_17[i][j], "g_17[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_97[i], "g_97[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 35
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 60
   depth: 2, occurrence: 15
   depth: 3, occurrence: 6
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 91
XXX times a non-volatile is write: 40
XXX times a volatile is read: 12
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 35
XXX percentage of non-volatile access: 90.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 60
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 20
   depth: 2, occurrence: 21

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
********************* end of statistics **********************/

