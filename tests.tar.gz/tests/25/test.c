/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14101886347337798543
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_12[8] = {0xCFL,0xCFL,0xCFL,0xCFL,0xCFL,0xCFL,0xCFL,0xCFL};
static int8_t g_35[5][1] = {{(-4L)},{(-9L)},{(-4L)},{(-9L)},{(-4L)}};
static int64_t g_56 = 0xAF75D59274CB070FLL;
static int32_t g_64 = 0x7789B64DL;
static int32_t g_72[8][3][1] = {{{1L},{(-3L)},{(-1L)}},{{(-3L)},{1L},{(-3L)}},{{(-1L)},{(-3L)},{1L}},{{(-3L)},{(-1L)},{(-3L)}},{{1L},{(-3L)},{(-1L)}},{{(-3L)},{1L},{(-3L)}},{{(-1L)},{(-3L)},{1L}},{{(-3L)},{(-1L)},{(-3L)}}};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_7(int8_t  p_8, uint8_t  p_9, uint32_t  p_10, int8_t  p_11);
static const int64_t  func_16(uint32_t  p_17, int32_t  p_18, uint16_t  p_19);
static const uint64_t  func_28(int32_t  p_29);
static const uint8_t  func_39(int16_t  p_40, int32_t  p_41, const uint8_t  p_42, uint64_t  p_43, int8_t  p_44);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_35 g_56 g_64 g_72
 * writes: g_35 g_56 g_64 g_72
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_13 = 0x65L;
    int32_t l_160 = 0xCA303420L;
    l_160 = ((safe_lshift_func_uint8_t_u_u((safe_unary_minus_func_int16_t_s(((safe_add_func_int64_t_s_s(func_7(g_12[4], g_12[5], l_13, g_12[7]), g_12[4])) & l_13))), 7)) , g_56);
    for (g_56 = 4; (g_56 >= (-6)); g_56 = safe_sub_func_int32_t_s_s(g_56, 3))
    { /* block id: 82 */
        uint64_t l_163 = 0xCD21EB8B61DA0039LL;
        for (g_64 = 7; (g_64 >= 1); g_64 -= 1)
        { /* block id: 85 */
            --l_163;
            return g_35[2][0];
        }
    }
    g_72[6][2][0] ^= ((((-1L) || 0L) >= g_12[2]) & g_35[1][0]);
    return g_12[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_35 g_56 g_64 g_72
 * writes: g_35 g_56 g_64 g_72
 */
static int64_t  func_7(int8_t  p_8, uint8_t  p_9, uint32_t  p_10, int8_t  p_11)
{ /* block id: 1 */
    int32_t l_32 = (-1L);
    uint64_t l_124 = 0UL;
    int32_t l_130 = 0xF47762CDL;
    int32_t l_131 = 0x5837069AL;
    int32_t l_132 = 0L;
    int32_t l_133 = 1L;
    int32_t l_134 = 0x57A72AD4L;
    int32_t l_135 = 0x3F732892L;
    int32_t l_136 = 0L;
    int32_t l_137 = 0x4BA8154FL;
    int32_t l_138 = (-6L);
    int32_t l_139 = 0xEFB63463L;
    int32_t l_140 = 0xF6A3D26EL;
    int32_t l_141 = 0xF62E4942L;
    int32_t l_142 = 0x6F81079EL;
    int32_t l_143 = 1L;
    int32_t l_144 = 0L;
    int32_t l_145 = 0xA39021D3L;
    int32_t l_146 = 0x1B8DD48DL;
    int32_t l_147[8] = {1L,0x0F172A51L,1L,0x0F172A51L,1L,0x0F172A51L,1L,0x0F172A51L};
    int32_t l_148 = 0x5F605A33L;
    int8_t l_149 = 1L;
    int32_t l_150[9] = {0x252A57B0L,0x252A57B0L,0xB5325306L,0xB5325306L,0x252A57B0L,0xB5325306L,0xB5325306L,0x252A57B0L,0xB5325306L};
    uint64_t l_151 = 0x2FE86CE72152D3ADLL;
    int i;
    for (p_11 = (-1); (p_11 < 18); p_11 = safe_add_func_int16_t_s_s(p_11, 7))
    { /* block id: 4 */
        int32_t l_82[3];
        int32_t l_128 = 8L;
        int i;
        for (i = 0; i < 3; i++)
            l_82[i] = 1L;
        if (((func_16(((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s((safe_add_func_uint64_t_u_u(func_28((safe_mul_func_uint8_t_u_u((((g_12[1] || 0xDF9481F3L) > (-8L)) , l_32), l_32))), 0UL)), p_8)), 0xCEL)), 7)) | g_12[3]), p_11, l_82[1]) & g_12[4]) , p_8))
        { /* block id: 69 */
            uint64_t l_127[10][6][4] = {{{0xFB0DACC5E6FE971DLL,18446744073709551608UL,0xADBC88E9F24F76BCLL,0xBAD84171F4BA9CC6LL},{0x4DEBD41BC699B59DLL,1UL,0UL,0xEA04750EE913E1DELL},{0x4DEBD41BC699B59DLL,18446744073709551606UL,0xADBC88E9F24F76BCLL,1UL},{0xFB0DACC5E6FE971DLL,1UL,0xBAD84171F4BA9CC6LL,0xADBC88E9F24F76BCLL},{1UL,1UL,18446744073709551615UL,1UL},{18446744073709551608UL,0xFB0DACC5E6FE971DLL,0xADBC88E9F24F76BCLL,1UL}},{{0xF1AD9D65D8E46664LL,1UL,0UL,0xADBC88E9F24F76BCLL},{0x4DEBD41BC699B59DLL,1UL,1UL,1UL},{18446744073709551608UL,18446744073709551606UL,0xBAD84171F4BA9CC6LL,0xEA04750EE913E1DELL},{18446744073709551606UL,1UL,0xBAD84171F4BA9CC6LL,0xBAD84171F4BA9CC6LL},{18446744073709551608UL,18446744073709551608UL,1UL,1UL},{0x4DEBD41BC699B59DLL,0x4E8F9E78BCBB5882LL,0UL,0xEA04750EE913E1DELL}},{{0xF1AD9D65D8E46664LL,1UL,0xADBC88E9F24F76BCLL,0UL},{18446744073709551608UL,1UL,18446744073709551615UL,0xEA04750EE913E1DELL},{1UL,0x4E8F9E78BCBB5882LL,0xBAD84171F4BA9CC6LL,1UL},{0xFB0DACC5E6FE971DLL,18446744073709551608UL,0xADBC88E9F24F76BCLL,0xBAD84171F4BA9CC6LL},{0x4DEBD41BC699B59DLL,1UL,0UL,0xEA04750EE913E1DELL},{0x4DEBD41BC699B59DLL,18446744073709551606UL,0xADBC88E9F24F76BCLL,1UL}},{{0xFB0DACC5E6FE971DLL,1UL,0xBAD84171F4BA9CC6LL,0xADBC88E9F24F76BCLL},{1UL,1UL,18446744073709551615UL,1UL},{18446744073709551608UL,0xFB0DACC5E6FE971DLL,0xADBC88E9F24F76BCLL,1UL},{0xF1AD9D65D8E46664LL,1UL,0UL,0xADBC88E9F24F76BCLL},{0x4DEBD41BC699B59DLL,1UL,1UL,1UL},{18446744073709551608UL,18446744073709551606UL,0xBAD84171F4BA9CC6LL,0xEA04750EE913E1DELL}},{{18446744073709551606UL,1UL,0xBAD84171F4BA9CC6LL,0xBAD84171F4BA9CC6LL},{18446744073709551608UL,18446744073709551608UL,1UL,1UL},{0x4DEBD41BC699B59DLL,0x4E8F9E78BCBB5882LL,0UL,0xEA04750EE913E1DELL},{0xF1AD9D65D8E46664LL,1UL,0xADBC88E9F24F76BCLL,0UL},{18446744073709551608UL,1UL,18446744073709551615UL,0xEA04750EE913E1DELL},{1UL,0x4E8F9E78BCBB5882LL,0xBAD84171F4BA9CC6LL,1UL}},{{0xFB0DACC5E6FE971DLL,18446744073709551608UL,0xADBC88E9F24F76BCLL,0xBAD84171F4BA9CC6LL},{0x4DEBD41BC699B59DLL,1UL,0UL,0xEA04750EE913E1DELL},{0x4DEBD41BC699B59DLL,18446744073709551606UL,0xADBC88E9F24F76BCLL,1UL},{0xFB0DACC5E6FE971DLL,1UL,0xBAD84171F4BA9CC6LL,0xADBC88E9F24F76BCLL},{1UL,1UL,18446744073709551615UL,1UL},{18446744073709551608UL,0xFB0DACC5E6FE971DLL,0xADBC88E9F24F76BCLL,1UL}},{{0xF1AD9D65D8E46664LL,1UL,0UL,0xADBC88E9F24F76BCLL},{0x4DEBD41BC699B59DLL,1UL,1UL,1UL},{18446744073709551608UL,18446744073709551606UL,0xBAD84171F4BA9CC6LL,0xEA04750EE913E1DELL},{18446744073709551606UL,1UL,0xBAD84171F4BA9CC6LL,0xBAD84171F4BA9CC6LL},{18446744073709551608UL,18446744073709551608UL,1UL,1UL},{0x4DEBD41BC699B59DLL,0x4E8F9E78BCBB5882LL,0UL,0xEA04750EE913E1DELL}},{{0xF1AD9D65D8E46664LL,1UL,0xADBC88E9F24F76BCLL,0UL},{18446744073709551608UL,1UL,18446744073709551615UL,0xEA04750EE913E1DELL},{1UL,0x4E8F9E78BCBB5882LL,0xBAD84171F4BA9CC6LL,1UL},{0xFB0DACC5E6FE971DLL,18446744073709551608UL,0xADBC88E9F24F76BCLL,0x12DA420BE38E84D4LL},{18446744073709551615UL,0xFB0DACC5E6FE971DLL,1UL,0UL},{18446744073709551615UL,0x8C36732C95206BB7LL,0UL,0xBAD84171F4BA9CC6LL}},{{0xF4CFC3FE24BE3DF8LL,0xF1AD9D65D8E46664LL,0x12DA420BE38E84D4LL,0UL},{0xF1AD9D65D8E46664LL,0xFB0DACC5E6FE971DLL,0xF82581418936BB2FLL,4UL},{18446744073709551606UL,0xF4CFC3FE24BE3DF8LL,0UL,4UL},{1UL,0xFB0DACC5E6FE971DLL,18446744073709551615UL,0UL},{18446744073709551615UL,0xF1AD9D65D8E46664LL,1UL,0xBAD84171F4BA9CC6LL},{18446744073709551606UL,0x8C36732C95206BB7LL,0x12DA420BE38E84D4LL,0UL}},{{0x8C36732C95206BB7LL,0xFB0DACC5E6FE971DLL,0x12DA420BE38E84D4LL,0x12DA420BE38E84D4LL},{18446744073709551606UL,18446744073709551606UL,1UL,4UL},{18446744073709551615UL,1UL,18446744073709551615UL,0UL},{1UL,0xF1AD9D65D8E46664LL,0UL,18446744073709551615UL},{18446744073709551606UL,0xF1AD9D65D8E46664LL,0xF82581418936BB2FLL,0UL},{0xF1AD9D65D8E46664LL,1UL,0x12DA420BE38E84D4LL,4UL}}};
            int i, j, k;
            g_72[5][1][0] = ((((((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((l_124 > 0L), l_82[1])), l_82[1])) < g_72[4][0][0]) | 0UL) >= (-5L)) ^ g_12[4]) > g_72[6][0][0]);
            l_128 = (((safe_sub_func_int64_t_s_s((g_56 >= 0x07931957L), g_12[5])) ^ l_127[2][1][3]) > g_12[4]);
        }
        else
        { /* block id: 72 */
            uint64_t l_129 = 18446744073709551608UL;
            return l_129;
        }
    }
    l_151++;
    g_72[4][0][0] = ((safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u((((((safe_lshift_func_uint16_t_u_u(p_9, p_10)) | g_35[1][0]) <= l_132) < 65535UL) <= p_9), g_72[0][0][0])) || p_9), 8)) < g_72[7][2][0]);
    return l_150[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_56 g_64 g_12 g_35
 * writes: g_64 g_72
 */
static const int64_t  func_16(uint32_t  p_17, int32_t  p_18, uint16_t  p_19)
{ /* block id: 45 */
    int32_t l_83[1][9] = {{(-9L),0x52AB26C3L,(-9L),(-9L),0x52AB26C3L,(-9L),(-9L),0x52AB26C3L,(-9L)}};
    int32_t l_103 = 0xF8C34F7CL;
    uint32_t l_113 = 4294967295UL;
    int8_t l_114 = (-1L);
    uint32_t l_115 = 4294967293UL;
    int i, j;
    if (l_83[0][8])
    { /* block id: 46 */
        uint32_t l_92 = 0x43BC77BBL;
        int32_t l_93[3];
        int i;
        for (i = 0; i < 3; i++)
            l_93[i] = 0xDAA6E977L;
        l_83[0][0] = (safe_lshift_func_int8_t_s_u((safe_div_func_int32_t_s_s((safe_mod_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(l_83[0][8], l_83[0][8])), p_18)), l_92)), g_56));
        l_93[2] ^= (((p_17 >= 8L) && l_83[0][8]) <= l_92);
        return l_92;
    }
    else
    { /* block id: 50 */
        for (g_64 = 0; (g_64 == 17); ++g_64)
        { /* block id: 53 */
            uint8_t l_104 = 0x40L;
            l_83[0][8] = (((!(safe_mod_func_int64_t_s_s((((safe_rshift_func_int16_t_s_s((((((safe_div_func_int32_t_s_s(l_103, g_64)) || l_83[0][4]) || 0x5E7B382EL) , 18446744073709551615UL) != p_17), g_12[5])) , l_104) < p_19), 7L))) || p_18) , g_56);
            if (g_35[4][0])
                break;
            g_72[6][0][0] = (safe_mod_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((safe_sub_func_int16_t_s_s((-5L), 0x60E8L)), 0x0D67L)), p_19));
        }
        for (p_18 = 0; (p_18 <= 7); p_18 += 1)
        { /* block id: 60 */
            g_72[4][0][0] = (p_19 > p_17);
            return p_17;
        }
    }
    l_83[0][8] = ((safe_lshift_func_int16_t_s_u((-5L), 2)) >= l_83[0][2]);
    l_83[0][0] = ((l_113 <= g_35[2][0]) | g_12[7]);
    ++l_115;
    return l_83[0][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_35 g_56 g_64
 * writes: g_35 g_56 g_64 g_72
 */
static const uint64_t  func_28(int32_t  p_29)
{ /* block id: 5 */
    int32_t l_36 = (-1L);
    int32_t l_80 = (-9L);
    const int32_t l_81 = 0x92B64398L;
    for (p_29 = 27; (p_29 > 8); p_29 = safe_sub_func_uint32_t_u_u(p_29, 1))
    { /* block id: 8 */
        int64_t l_71 = 0L;
        g_35[1][0] = (g_12[5] >= p_29);
        if (l_36)
            continue;
        for (l_36 = 0; (l_36 <= 0); l_36 += 1)
        { /* block id: 13 */
            uint8_t l_79[2];
            int i, j;
            for (i = 0; i < 2; i++)
                l_79[i] = 1UL;
            g_72[6][0][0] = (safe_div_func_uint8_t_u_u(func_39((safe_rshift_func_int16_t_s_u(g_12[(l_36 + 6)], 11)), g_35[(l_36 + 3)][l_36], g_35[(l_36 + 3)][l_36], p_29, p_29), l_71));
            l_80 = ((safe_add_func_int32_t_s_s((safe_add_func_uint64_t_u_u((((safe_div_func_int8_t_s_s(0x01L, l_36)) == (-10L)) , 1UL), g_56)), 0x3969C113L)) >= l_79[0]);
        }
        l_36 &= p_29;
    }
    return l_81;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_12 g_56 g_64
 * writes: g_56 g_64
 */
static const uint8_t  func_39(int16_t  p_40, int32_t  p_41, const uint8_t  p_42, uint64_t  p_43, int8_t  p_44)
{ /* block id: 14 */
    int32_t l_51 = (-1L);
    for (p_40 = 0; (p_40 >= 15); p_40 = safe_add_func_int8_t_s_s(p_40, 1))
    { /* block id: 17 */
        uint8_t l_55 = 5UL;
        for (p_41 = 0; (p_41 <= 0); p_41 += 1)
        { /* block id: 20 */
            int32_t l_52 = (-1L);
            int i, j;
            l_52 = (((((((((((safe_add_func_int64_t_s_s(g_35[(p_41 + 3)][p_41], 0UL)) != g_35[p_41][p_41]) && l_51) <= g_35[1][0]) > 1UL) , l_51) ^ g_35[(p_41 + 3)][p_41]) && 0x4F5CL) < l_51) < g_35[0][0]) || g_35[p_41][p_41]);
            g_56 = (safe_mul_func_int16_t_s_s(l_55, g_12[4]));
        }
        p_41 &= l_51;
    }
    for (l_51 = 0; (l_51 > (-13)); l_51--)
    { /* block id: 28 */
        int32_t l_63 = 0xC392AD58L;
        g_64 = (safe_lshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((((g_12[4] != l_63) ^ p_44) | 3UL) && p_43), 0x6139L)), g_12[4]));
        for (g_56 = 18; (g_56 >= (-19)); g_56--)
        { /* block id: 32 */
            const uint32_t l_67 = 4UL;
            if (g_12[4])
                break;
            if (l_67)
                continue;
            p_41 = (safe_sub_func_int16_t_s_s((~(((g_64 != g_64) == g_64) == p_43)), p_40));
        }
    }
    return p_40;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_35[i][j], "g_35[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_72[i][j][k], "g_72[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 54
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 14
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 119
XXX times a non-volatile is write: 35
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 50
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 15
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 19.5
XXX percentage an existing variable is used: 80.5
********************* end of statistics **********************/

