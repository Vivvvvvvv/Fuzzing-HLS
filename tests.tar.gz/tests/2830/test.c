/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7531748406786050940
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int8_t  f0;
   const uint16_t  f1;
   volatile uint32_t  f2;
   int64_t  f3;
   int32_t  f4;
   int16_t  f5;
   int32_t  f6;
   int8_t  f7;
   int32_t  f8;
};

/* --- GLOBAL VARIABLES --- */
static int64_t g_7 = 0xC975158018D9DCEELL;
static uint16_t g_11 = 0xD228L;
static struct S0 g_12 = {0xEAL,0x86F2L,1UL,-6L,0x8EFA97F5L,1L,1L,0xE8L,-8L};/* VOLATILE GLOBAL g_12 */


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_12
 * writes: g_11
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int64_t l_6[5];
    int32_t l_8[3];
    int i;
    for (i = 0; i < 5; i++)
        l_6[i] = 0xAFA9B64FDA7EF5D8LL;
    for (i = 0; i < 3; i++)
        l_8[i] = 0x3E19F23EL;
    l_8[2] = (((safe_div_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(l_6[4], l_6[4])), l_6[4])) == g_7) <= g_7);
    g_11 = ((safe_rshift_func_int16_t_s_s(l_6[0], 10)) >= l_8[2]);
    return g_12;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12.f0, "g_12.f0", print_hash_value);
    transparent_crc(g_12.f1, "g_12.f1", print_hash_value);
    transparent_crc(g_12.f2, "g_12.f2", print_hash_value);
    transparent_crc(g_12.f3, "g_12.f3", print_hash_value);
    transparent_crc(g_12.f4, "g_12.f4", print_hash_value);
    transparent_crc(g_12.f5, "g_12.f5", print_hash_value);
    transparent_crc(g_12.f6, "g_12.f6", print_hash_value);
    transparent_crc(g_12.f7, "g_12.f7", print_hash_value);
    transparent_crc(g_12.f8, "g_12.f8", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 3
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 8
XXX times a non-volatile is write: 2
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 3
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 3

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

