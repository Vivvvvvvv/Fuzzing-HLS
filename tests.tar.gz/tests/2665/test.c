/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2596864684358948404
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_3 = 1UL;/* VOLATILE GLOBAL g_3 */
static int32_t g_11 = 1L;
static volatile int32_t g_14 = 0x52568108L;/* VOLATILE GLOBAL g_14 */
static int16_t g_25 = 0x6C50L;
static volatile uint32_t g_30 = 0UL;/* VOLATILE GLOBAL g_30 */
static int16_t g_38 = 0x54ABL;
static uint32_t g_39 = 0xFEED1B4BL;
static int32_t g_50[10] = {0L,(-1L),0L,0L,(-1L),0L,0L,(-1L),0L,0L};


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static const int8_t  func_8(const uint8_t  p_9, uint32_t  p_10);
static uint8_t  func_15(uint8_t  p_16, int32_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_14 g_11 g_30 g_39 g_25 g_38 g_50
 * writes: g_3 g_11 g_25 g_30 g_39 g_50
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = (-6L);
    const uint32_t l_65 = 0UL;
    int32_t l_69 = 0x9780CE5FL;
    int32_t l_78[7];
    uint16_t l_79 = 0xC8CCL;
    int i;
    for (i = 0; i < 7; i++)
        l_78[i] = 1L;
    ++g_3;
    if (((safe_lshift_func_int8_t_s_s(func_8((0xF8F0AA6E6F7FBF21LL || l_2), g_3), 0)) >= l_2))
    { /* block id: 4 */
        int64_t l_19 = 0xD7F1912530A9BCA7LL;
        int32_t l_53 = 0L;
        g_11 = (-1L);
        for (l_2 = (-26); (l_2 <= 25); l_2 = safe_add_func_int8_t_s_s(l_2, 5))
        { /* block id: 8 */
            int8_t l_18 = 0xFAL;
            g_11 = (g_14 <= g_11);
            g_50[1] &= (func_15(l_18, l_19) , g_25);
            l_53 = (((safe_add_func_int16_t_s_s((g_3 , l_2), 0x66C0L)) == g_39) | g_39);
        }
        for (g_25 = 9; (g_25 >= 0); g_25 -= 1)
        { /* block id: 40 */
            int32_t l_58[6] = {0L,0L,0L,0L,0L,0L};
            int i;
            l_58[4] |= (safe_lshift_func_uint8_t_u_s((safe_sub_func_int32_t_s_s((g_50[g_25] & 0x0FC5A51FL), l_53)), 5));
            if (g_38)
                continue;
            g_50[g_25] = (safe_mod_func_uint32_t_u_u((((safe_sub_func_uint64_t_u_u((safe_sub_func_int16_t_s_s(l_65, 0x8F0EL)), 0xDC6606A86E60E451LL)) | 65530UL) >= 2UL), l_65));
            l_69 = (safe_lshift_func_int8_t_s_u(((((((+g_39) & (-1L)) , g_50[1]) , l_53) || l_53) == g_25), 1));
        }
    }
    else
    { /* block id: 46 */
        uint32_t l_74 = 1UL;
        int32_t l_75 = (-1L);
        int32_t l_77 = 0x75996E24L;
        l_74 = ((((safe_sub_func_uint8_t_u_u((l_2 <= 0UL), 0x56L)) & (-1L)) ^ 0x81B7FFC8L) && l_69);
        g_50[1] = (g_30 , 0L);
        for (g_39 = 0; (g_39 <= 9); g_39 += 1)
        { /* block id: 51 */
            int32_t l_76[5];
            int i;
            for (i = 0; i < 5; i++)
                l_76[i] = 0x30A87563L;
            l_79++;
        }
    }
    return l_78[2];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int8_t  func_8(const uint8_t  p_9, uint32_t  p_10)
{ /* block id: 2 */
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_11 g_14 g_30 g_39 g_25 g_38
 * writes: g_11 g_25 g_30 g_39
 */
static uint8_t  func_15(uint8_t  p_16, int32_t  p_17)
{ /* block id: 10 */
    int64_t l_20 = 0xE7C14AB653B1DAB5LL;
    int32_t l_36 = 5L;
lbl_48:
    l_20 &= (0xD2717F4039EE491BLL == g_3);
    for (g_11 = (-16); (g_11 > 2); g_11 = safe_add_func_uint16_t_u_u(g_11, 8))
    { /* block id: 14 */
        uint8_t l_35 = 0x41L;
        int32_t l_37 = 0x8BA79672L;
        for (p_17 = 24; (p_17 >= (-28)); --p_17)
        { /* block id: 17 */
            int32_t l_26 = 1L;
            int32_t l_27 = 0xCA8C98AAL;
            int32_t l_28 = 0x58FC5674L;
            int32_t l_29 = (-3L);
            g_25 = (g_14 != p_16);
            --g_30;
            l_36 = ((((safe_mod_func_uint64_t_u_u((l_20 > g_14), p_17)) || l_35) | 0x0BADL) < p_17);
        }
        g_39++;
        if ((safe_div_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((safe_mod_func_int64_t_s_s((l_35 , (-3L)), g_14)), 0x270CL)), g_39)))
        { /* block id: 23 */
            return p_17;
        }
        else
        { /* block id: 25 */
            if (p_17)
                goto lbl_48;
            l_37 = g_25;
            l_37 = g_38;
            if (g_39)
                continue;
        }
    }
    l_36 |= (~p_16);
    g_11 = g_38;
    return l_20;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_50[i], "g_50[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 29
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 36
   depth: 2, occurrence: 9
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 42
XXX times a non-volatile is write: 23
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 42
XXX percentage of non-volatile access: 86.7

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 34
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 9
   depth: 2, occurrence: 16

XXX percentage a fresh-made variable is used: 31.5
XXX percentage an existing variable is used: 68.5
********************* end of statistics **********************/

