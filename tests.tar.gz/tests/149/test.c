/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11238414615503791033
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint64_t  f0;
   uint64_t  f1;
   int64_t  f2;
   uint32_t  f3;
   int64_t  f4;
   uint16_t  f5;
};

struct S1 {
   uint64_t  f0;
   uint32_t  f1;
   uint32_t  f2;
   struct S0  f3;
   const uint32_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static int16_t g_9[2] = {(-9L),(-9L)};
static int32_t g_13[8] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
static volatile struct S1 g_30 = {0x69A75015E0C0A103LL,4294967293UL,0xAF6658D8L,{18446744073709551609UL,5UL,6L,0xD8169B41L,-6L,65535UL},0x67C8FA1BL};/* VOLATILE GLOBAL g_30 */
static int32_t g_125 = 0x10C7F523L;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, struct S0  p_4);
static uint32_t  func_5(int32_t  p_6);
static uint64_t  func_16(int32_t  p_17, int32_t  p_18, uint16_t  p_19, uint32_t  p_20, uint32_t  p_21);
static int32_t  func_22(uint64_t  p_23, int16_t  p_24, uint32_t  p_25, uint8_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_13 g_30 g_125
 * writes: g_13 g_125
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    struct S0 l_75 = {18446744073709551612UL,18446744073709551615UL,0x9AA352C7534BEE77LL,18446744073709551615UL,-6L,0x5447L};
    int32_t l_89 = 0x80B1A2B5L;
    int32_t l_102 = 0x8D07ABCEL;
    int32_t l_103 = (-1L);
    int32_t l_104 = 0x8BF1FB4DL;
    int8_t l_105 = 0x5BL;
    int32_t l_106[4] = {(-1L),(-1L),(-1L),(-1L)};
    uint32_t l_110 = 4294967295UL;
    int32_t l_134 = 3L;
    uint16_t l_149 = 65535UL;
    uint16_t l_152 = 4UL;
    int i;
lbl_94:
    l_89 |= func_2(((func_5((safe_rshift_func_uint16_t_u_s(1UL, g_9[0]))) ^ g_9[0]) && 65529UL), l_75);
    for (l_75.f4 = (-30); (l_75.f4 < (-29)); l_75.f4 = safe_add_func_uint16_t_u_u(l_75.f4, 3))
    { /* block id: 80 */
        int64_t l_99 = 0x6BE2F814610154D0LL;
        int32_t l_100[8][4][3] = {{{(-8L),0x6CCD6F84L,0xF6C4FF35L},{(-8L),3L,(-1L)},{1L,0L,1L},{(-1L),(-1L),(-10L)}},{{0xFD917EEAL,(-1L),(-1L)},{(-1L),0x5382869BL,(-8L)},{(-1L),0x73F93019L,1L},{0L,3L,0xA251F1BFL}},{{0xA251F1BFL,(-1L),0xE2076EB1L},{1L,3L,0xF044E681L},{0x2542557BL,0x73F93019L,1L},{1L,0xF044E681L,0x5382869BL}},{{1L,0x4440822FL,3L},{0xF044E681L,0L,0xAE2E0842L},{0x43A8C46FL,(-1L),0L},{0x4440822FL,(-8L),0L}},{{0x0C72D929L,(-2L),0L},{0xAE2E0842L,0xDDDF175EL,0L},{(-1L),0x6CCD6F84L,0xAE2E0842L},{0x373520E6L,0L,3L}},{{0x5382869BL,(-1L),0x5382869BL},{3L,5L,1L},{(-7L),1L,0x239E70C8L},{(-8L),3L,0xDDDF175EL}},{{(-10L),5L,(-1L)},{(-8L),0x373520E6L,5L},{(-7L),0xFD917EEAL,0L},{3L,1L,0x4440822FL}},{{0x5382869BL,0L,0x73F93019L},{0x373520E6L,(-1L),0xF6C4FF35L},{(-1L),(-1L),0x6D0C9214L},{0xAE2E0842L,0x490029EFL,(-8L)}}};
        int32_t l_107[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
        int64_t l_108 = 6L;
        int i, j, k;
        if ((safe_unary_minus_func_uint8_t_u((!(((-1L) | 18446744073709551613UL) >= 0x3748BFE3BB384EBALL)))))
        { /* block id: 81 */
            if (l_75.f0)
                goto lbl_94;
            g_13[7] = 2L;
        }
        else
        { /* block id: 84 */
            return g_30.f3.f1;
        }
        for (l_75.f3 = (-5); (l_75.f3 <= 48); l_75.f3 = safe_add_func_int64_t_s_s(l_75.f3, 4))
        { /* block id: 89 */
            int8_t l_97 = 0x7FL;
            int32_t l_98 = 0x716F66F7L;
            int32_t l_101[6] = {0xF7CD7C78L,0xF7CD7C78L,0xF7CD7C78L,0xF7CD7C78L,0xF7CD7C78L,0xF7CD7C78L};
            int8_t l_109[1][4] = {{(-1L),(-1L),(-1L),(-1L)}};
            int i, j;
            --l_110;
            return g_30.f1;
        }
        l_106[3] |= (0x011CL < l_104);
    }
    for (l_105 = 1; (l_105 >= 0); l_105 -= 1)
    { /* block id: 97 */
        int32_t l_137 = 0xD3F7DA16L;
        int32_t l_141 = 0xD3A6AC58L;
        int32_t l_147[10];
        int64_t l_148[9][7][2] = {{{5L,(-1L)},{1L,(-1L)},{5L,0xF50AE7412AEBC10CLL},{(-7L),0x33C25D2CA8022D0BLL},{0xB5EBD3B7CBDB2518LL,0L},{(-1L),(-7L)},{0xC422D24AC7B0F379LL,0x266CD422BFBABA67LL}},{{(-6L),0xEE32586A3694979DLL},{0xA42D7DE4DC80609CLL,0x001A1CCD3B4F5F1FLL},{0x464F727E752563AELL,0x0985F9BD9F5654A6LL},{0x8D21F102E53A4A4FLL,(-4L)},{0x266CD422BFBABA67LL,4L},{1L,1L},{0x661D303672CF074FLL,(-7L)}},{{0x001A1CCD3B4F5F1FLL,0L},{(-7L),0L},{0x813D76F3A889DD30LL,0xB5EBD3B7CBDB2518LL},{(-9L),(-9L)},{(-4L),(-1L)},{0xD2C106F47B0E098BLL,0xC422D24AC7B0F379LL},{0x8523E7098F6E7954LL,(-1L)}},{{0x0985F9BD9F5654A6LL,0x8523E7098F6E7954LL},{(-7L),(-1L)},{(-7L),0x8523E7098F6E7954LL},{0x0985F9BD9F5654A6LL,(-1L)},{0x8523E7098F6E7954LL,0xC422D24AC7B0F379LL},{0xD2C106F47B0E098BLL,(-1L)},{(-4L),(-9L)}},{{(-9L),0xB5EBD3B7CBDB2518LL},{0x813D76F3A889DD30LL,0L},{(-7L),0L},{0x001A1CCD3B4F5F1FLL,(-7L)},{0x661D303672CF074FLL,1L},{1L,4L},{0x266CD422BFBABA67LL,(-4L)}},{{0x8D21F102E53A4A4FLL,0x0985F9BD9F5654A6LL},{0x464F727E752563AELL,0x001A1CCD3B4F5F1FLL},{0xA42D7DE4DC80609CLL,0xEE32586A3694979DLL},{(-6L),0x266CD422BFBABA67LL},{0xC422D24AC7B0F379LL,(-7L)},{(-1L),0L},{0xB5EBD3B7CBDB2518LL,0x33C25D2CA8022D0BLL}},{{(-7L),0xF50AE7412AEBC10CLL},{5L,(-1L)},{1L,(-1L)},{5L,0xF50AE7412AEBC10CLL},{(-7L),0x33C25D2CA8022D0BLL},{0xB5EBD3B7CBDB2518LL,0L},{(-1L),(-7L)}},{{0xC422D24AC7B0F379LL,0x266CD422BFBABA67LL},{(-6L),0xEE32586A3694979DLL},{0xA42D7DE4DC80609CLL,0x001A1CCD3B4F5F1FLL},{0x464F727E752563AELL,0x0985F9BD9F5654A6LL},{0x8D21F102E53A4A4FLL,(-1L)},{0x813D76F3A889DD30LL,(-7L)},{(-4L),0xEE32586A3694979DLL}},{{(-7L),0xC28E36C2DCE2F2AALL},{(-6L),0x33C25D2CA8022D0BLL},{(-1L),(-3L)},{0xA42D7DE4DC80609CLL,0xB9DF822DF4C28BF4LL},{0L,0L},{(-1L),0x3397D4F8AA34D098LL},{(-1L),0x464F727E752563AELL}}};
        int i, j, k;
        for (i = 0; i < 10; i++)
            l_147[i] = 0xF463211CL;
        g_125 ^= ((safe_div_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((((((safe_rshift_func_uint16_t_u_s(((safe_rshift_func_int8_t_s_s((safe_mod_func_int32_t_s_s((safe_rshift_func_uint8_t_u_s(g_9[l_105], g_9[l_105])), g_9[l_105])), 3)) , l_103), g_9[l_105])) ^ g_9[0]) < g_9[l_105]) < g_30.f0) > g_9[1]), g_13[7])), 0xA5L)) , 6L);
        for (l_75.f4 = 1; (l_75.f4 >= 0); l_75.f4 -= 1)
        { /* block id: 101 */
            uint16_t l_133 = 0x6F18L;
            l_134 &= ((~(((((safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s((safe_add_func_int8_t_s_s(g_9[l_105], l_133)), l_133)), 0xC9L)) ^ g_30.f3.f3) <= 0x63L) >= l_105) || 1UL)) < g_9[l_105]);
            l_106[3] = (l_133 <= l_105);
        }
        for (l_104 = 1; (l_104 >= 0); l_104 -= 1)
        { /* block id: 107 */
            int32_t l_136 = 1L;
            int32_t l_138 = 8L;
            int32_t l_139 = 1L;
            int32_t l_140 = 0xCFB8BCE6L;
            int32_t l_142 = 0x79B7C538L;
            int32_t l_143 = 0x98E24242L;
            uint8_t l_144 = 246UL;
            l_137 = (!(((((g_30.f4 > g_9[1]) & l_104) < l_75.f3) > l_136) & l_103));
            l_144++;
            --l_149;
            --l_152;
        }
        g_13[7] ^= (1L & g_9[0]);
    }
    return g_13[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_30.f3.f0 g_30.f0
 * writes: g_13
 */
static int32_t  func_2(uint64_t  p_3, struct S0  p_4)
{ /* block id: 60 */
    int16_t l_77[5];
    int32_t l_78 = 1L;
    int32_t l_79 = 0L;
    int32_t l_80 = 0xF6D150EBL;
    int32_t l_81 = 0x319BF676L;
    int32_t l_82 = (-1L);
    int32_t l_83 = (-4L);
    int32_t l_84 = 0xA0C8E20BL;
    int32_t l_85[8][1][2] = {{{0xC997210BL,3L}},{{0xA6EED5ACL,3L}},{{0xC997210BL,0L}},{{0L,0xC997210BL}},{{3L,0xA6EED5ACL}},{{3L,0xC997210BL}},{{0L,0L}},{{0xC997210BL,3L}}};
    uint32_t l_86 = 0x0EEEE7CDL;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_77[i] = 0xDAD0L;
    for (p_4.f2 = 0; (p_4.f2 <= 7); p_4.f2 += 1)
    { /* block id: 63 */
        int64_t l_76[8][6][4] = {{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL},{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL}},{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL},{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL}},{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL},{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL}},{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL},{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL}},{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL},{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL}},{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL},{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0x6214FB9B3D0AF170LL}},{{0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL},{0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL,0xD2512995B858EE3BLL},{0x6214FB9B3D0AF170LL,0x6214FB9B3D0AF170LL,1L,0xD2512995B858EE3BLL},{0xD2512995B858EE3BLL,1L,1L,0xD2512995B858EE3BLL},{1L,0xD2512995B858EE3BLL,1L,1L},{0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL}},{{0xD2512995B858EE3BLL,1L,1L,0xD2512995B858EE3BLL},{1L,0xD2512995B858EE3BLL,1L,1L},{0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL},{0xD2512995B858EE3BLL,1L,1L,0xD2512995B858EE3BLL},{1L,0xD2512995B858EE3BLL,1L,1L},{0xD2512995B858EE3BLL,0xD2512995B858EE3BLL,0x6214FB9B3D0AF170LL,0xD2512995B858EE3BLL}}};
        int i, j, k;
        for (p_4.f4 = 0; (p_4.f4 <= 1); p_4.f4 += 1)
        { /* block id: 66 */
            int i;
            g_13[(p_4.f4 + 4)] = g_9[p_4.f4];
        }
        for (p_4.f1 = 0; (p_4.f1 <= 1); p_4.f1 += 1)
        { /* block id: 71 */
            l_76[6][4][0] = (((g_30.f3.f0 & 0x0E5BE992D143BF1FLL) & g_9[1]) && 0x3BL);
        }
    }
    l_86--;
    return g_30.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_13 g_30
 * writes: g_13
 */
static uint32_t  func_5(int32_t  p_6)
{ /* block id: 1 */
    int16_t l_12 = 0xFF12L;
    uint8_t l_27 = 6UL;
    int32_t l_50 = 0L;
    int32_t l_53[6][4] = {{2L,2L,2L,2L},{2L,2L,2L,2L},{2L,2L,2L,2L},{2L,2L,2L,2L},{2L,2L,2L,2L},{2L,2L,2L,2L}};
    uint64_t l_66[6] = {0x33072FE88D378B36LL,18446744073709551608UL,18446744073709551608UL,0x33072FE88D378B36LL,18446744073709551608UL,18446744073709551608UL};
    int i, j;
    g_13[7] &= ((safe_mod_func_uint16_t_u_u(l_12, g_9[0])) >= 0xF086L);
    if (((safe_lshift_func_int8_t_s_s(((((func_16(func_22(l_27, l_27, g_9[0], l_12), g_9[1], p_6, l_12, l_12) && 0x28C330C202EAB385LL) ^ 0UL) && l_12) , 3L), p_6)) | l_27))
    { /* block id: 41 */
        int64_t l_51 = 1L;
        int32_t l_55 = 0L;
        int32_t l_57 = 4L;
        int32_t l_58 = 0x53C4A2FBL;
        int32_t l_59 = 2L;
        int32_t l_61 = 0x7A374779L;
        int32_t l_62 = (-7L);
        int32_t l_63 = 0L;
        int32_t l_64 = 0xEB7CCD03L;
        int32_t l_65[7];
        int16_t l_69[9][6] = {{0xBBCFL,0xBBCFL,0x0E53L,0L,0xF097L,0xF097L},{0xBBCFL,0L,0L,0xBBCFL,0xF097L,0x0E53L},{0xF097L,0xBBCFL,0L,0L,0xBBCFL,0xF097L},{0xF097L,0L,0x0E53L,0xBBCFL,0xBBCFL,0x0E53L},{0xBBCFL,0xBBCFL,0x0E53L,0L,0xF097L,0xF097L},{0xBBCFL,0L,0L,0xBBCFL,0xF097L,0x0E53L},{0xF097L,0xBBCFL,0L,0L,0xBBCFL,0xF097L},{0xF097L,0L,0x0E53L,0xBBCFL,0xBBCFL,0x0E53L},{0xBBCFL,0xBBCFL,0x0E53L,0L,0xF097L,0xF097L}};
        int i, j;
        for (i = 0; i < 7; i++)
            l_65[i] = 0x64BFA3C5L;
        for (p_6 = 0; (p_6 >= (-23)); p_6--)
        { /* block id: 44 */
            int8_t l_49 = 3L;
            int32_t l_52 = 0xCE91E412L;
            int32_t l_54 = 5L;
            int32_t l_56 = 0x4618C456L;
            int32_t l_60[5];
            int i;
            for (i = 0; i < 5; i++)
                l_60[i] = 0x6BC8B8ECL;
            --l_66[5];
            if (l_69[4][0])
                break;
        }
        if ((safe_lshift_func_int8_t_s_s(l_53[3][2], p_6)))
        { /* block id: 48 */
lbl_74:
            g_13[7] = (safe_lshift_func_int16_t_s_s(g_9[0], 8));
        }
        else
        { /* block id: 50 */
            if (l_27)
                goto lbl_74;
            return g_30.f2;
        }
        l_55 = (l_63 != g_30.f3.f0);
        l_63 = l_69[4][0];
    }
    else
    { /* block id: 56 */
        return g_13[7];
    }
    return g_30.f1;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_13 g_30.f4 g_30.f3.f2 g_30.f3.f3
 * writes: g_13
 */
static uint64_t  func_16(int32_t  p_17, int32_t  p_18, uint16_t  p_19, uint32_t  p_20, uint32_t  p_21)
{ /* block id: 20 */
    uint16_t l_35 = 0x376AL;
    ++l_35;
    p_18 = p_21;
    for (p_21 = (-2); (p_21 < 52); ++p_21)
    { /* block id: 25 */
        g_13[1] &= (g_9[0] != 0xE1C2L);
    }
    for (l_35 = 0; (l_35 > 7); l_35 = safe_add_func_int8_t_s_s(l_35, 1))
    { /* block id: 30 */
        int8_t l_44[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int i;
        if (g_30.f4)
            break;
        g_13[7] |= ((safe_mod_func_uint64_t_u_u((p_19 ^ 0L), l_44[2])) | l_35);
        for (p_21 = (-12); (p_21 != 36); ++p_21)
        { /* block id: 35 */
            return g_30.f3.f2;
        }
        if (g_9[0])
            continue;
    }
    return g_30.f3.f3;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_9 g_30
 * writes: g_13
 */
static int32_t  func_22(uint64_t  p_23, int16_t  p_24, uint32_t  p_25, uint8_t  p_26)
{ /* block id: 3 */
    int32_t l_34 = 1L;
    for (p_25 = 0; (p_25 <= 1); p_25 += 1)
    { /* block id: 6 */
        int i;
        g_13[(p_25 + 5)] = g_13[(p_25 + 4)];
        g_13[p_25] |= (safe_lshift_func_uint16_t_u_s((g_9[p_25] , p_24), p_23));
        for (p_26 = 0; (p_26 <= 7); p_26 += 1)
        { /* block id: 11 */
            uint32_t l_31 = 0x60EC253DL;
            int i;
            if (p_26)
                break;
            g_13[p_26] &= (g_30 , l_31);
            if (g_13[p_26])
                break;
            l_34 = ((safe_lshift_func_uint8_t_u_u(((0x5D74L || p_24) < p_24), g_30.f3.f3)) && 6UL);
        }
        if (g_30.f3.f0)
            continue;
    }
    return l_34;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30.f0, "g_30.f0", print_hash_value);
    transparent_crc(g_30.f1, "g_30.f1", print_hash_value);
    transparent_crc(g_30.f2, "g_30.f2", print_hash_value);
    transparent_crc(g_30.f3.f0, "g_30.f3.f0", print_hash_value);
    transparent_crc(g_30.f3.f1, "g_30.f3.f1", print_hash_value);
    transparent_crc(g_30.f3.f2, "g_30.f3.f2", print_hash_value);
    transparent_crc(g_30.f3.f3, "g_30.f3.f3", print_hash_value);
    transparent_crc(g_30.f3.f4, "g_30.f3.f4", print_hash_value);
    transparent_crc(g_30.f3.f5, "g_30.f3.f5", print_hash_value);
    transparent_crc(g_30.f4, "g_30.f4", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 69
   depth: 1, occurrence: 1
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 58
   depth: 2, occurrence: 22
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 13, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 79
XXX times a non-volatile is write: 42
XXX times a volatile is read: 16
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 169
XXX percentage of non-volatile access: 88.3

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 63
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 23
   depth: 2, occurrence: 23

XXX percentage a fresh-made variable is used: 19.9
XXX percentage an existing variable is used: 80.1
********************* end of statistics **********************/

