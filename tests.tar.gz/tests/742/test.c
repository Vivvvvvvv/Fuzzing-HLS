/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6578068383695295678
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int64_t  f0;
   volatile uint16_t  f1;
   int16_t  f2;
   uint64_t  f3;
   int32_t  f4;
   volatile uint16_t  f5;
   uint16_t  f6;
   volatile uint8_t  f7;
   uint32_t  f8;
   uint32_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_4 = 0x9CL;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 2L;
static int16_t g_39 = (-7L);
static volatile uint32_t g_42 = 0xE2BF2DCFL;/* VOLATILE GLOBAL g_42 */
static uint64_t g_98 = 1UL;
static volatile uint8_t g_105 = 2UL;/* VOLATILE GLOBAL g_105 */
static volatile struct S0 g_120 = {0x346B7FD6875ADD04LL,0xE245L,1L,0x9575A6E9923EC180LL,0x899B7E06L,65526UL,0xDC40L,0x44L,4294967295UL,0x6C6A7DDBL};/* VOLATILE GLOBAL g_120 */
static volatile uint32_t g_127 = 0x690A631AL;/* VOLATILE GLOBAL g_127 */
static uint32_t g_131 = 3UL;
static int8_t g_136[4] = {0xD7L,0xD7L,0xD7L,0xD7L};
static uint16_t g_147 = 0x6FC2L;
static volatile uint32_t g_170 = 0x0E726625L;/* VOLATILE GLOBAL g_170 */
static int32_t g_180 = 0xADD7577FL;
static volatile int32_t g_182 = (-3L);/* VOLATILE GLOBAL g_182 */
static int8_t g_183 = 1L;
static volatile int64_t g_184 = 1L;/* VOLATILE GLOBAL g_184 */
static volatile int32_t g_185[5][5][8] = {{{0x7CF25E2EL,0x7CF25E2EL,0x5BB409F4L,1L,0x5BB409F4L,0x7CF25E2EL,0x7CF25E2EL,0x5BB409F4L},{0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L},{0x5BB409F4L,0x3C7D3EE5L,1L,1L,0x3C7D3EE5L,0x5BB409F4L,0x3C7D3EE5L,1L},{0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL},{0x7CF25E2EL,0x5BB409F4L,1L,0x5BB409F4L,0x7CF25E2EL,0x7CF25E2EL,0x5BB409F4L,1L}},{{0x7CF25E2EL,0x7CF25E2EL,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL},{1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL},{0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L,0x3C7D3EE5L,0x7CF25E2EL,0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L},{1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L},{0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L}},{{0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL},{1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL},{0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L,0x3C7D3EE5L,0x7CF25E2EL,0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L},{1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L},{0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L}},{{0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL},{1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL},{0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L,0x3C7D3EE5L,0x7CF25E2EL,0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L},{1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L},{0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L}},{{0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL},{1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL},{0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L,0x3C7D3EE5L,0x7CF25E2EL,0x1322C40BL,0x7CF25E2EL,0x3C7D3EE5L},{1L,0x7CF25E2EL,1L,0x1322C40BL,0x1322C40BL,1L,0x7CF25E2EL,1L},{0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L,0x1322C40BL,0x5BB409F4L,0x5BB409F4L,0x1322C40BL,0x3C7D3EE5L}}};
static uint16_t g_186 = 0UL;
static uint32_t g_193 = 0x5B5CE67DL;
static volatile uint16_t g_199[5][5] = {{0x7403L,0x8BBCL,0x7403L,0xCE54L,0x1544L},{0xC666L,65535UL,0x1544L,65535UL,0xC666L},{0x7403L,65535UL,0x8BBCL,0xC666L,0x8BBCL},{0x8BBCL,0x8BBCL,0x1544L,0xC666L,0x8E50L},{65535UL,0x7403L,0x7403L,65535UL,0x8BBCL}};
static volatile struct S0 g_202[3][8] = {{{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{-2L,65526UL,-3L,0UL,7L,0x42DCL,0xA3D8L,1UL,4294967295UL,0xC1FA4A3DL},{0xB32C21BFEE4DCC29LL,0xD850L,0xF07DL,0xD848F50E0B201384LL,-10L,0x5096L,65535UL,0xA2L,8UL,0x714A4212L},{-2L,65526UL,-3L,0UL,7L,0x42DCL,0xA3D8L,1UL,4294967295UL,0xC1FA4A3DL},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{-2L,65526UL,-3L,0UL,7L,0x42DCL,0xA3D8L,1UL,4294967295UL,0xC1FA4A3DL}},{{0xB32C21BFEE4DCC29LL,0xD850L,0xF07DL,0xD848F50E0B201384LL,-10L,0x5096L,65535UL,0xA2L,8UL,0x714A4212L},{0xAC6DAB7E20503888LL,65532UL,0xF598L,1UL,2L,6UL,0x890CL,0x58L,0xA296AE8CL,18446744073709551615UL},{0xAC6DAB7E20503888LL,65532UL,0xF598L,1UL,2L,6UL,0x890CL,0x58L,0xA296AE8CL,18446744073709551615UL},{0xB32C21BFEE4DCC29LL,0xD850L,0xF07DL,0xD848F50E0B201384LL,-10L,0x5096L,65535UL,0xA2L,8UL,0x714A4212L},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{0xB32C21BFEE4DCC29LL,0xD850L,0xF07DL,0xD848F50E0B201384LL,-10L,0x5096L,65535UL,0xA2L,8UL,0x714A4212L},{0xAC6DAB7E20503888LL,65532UL,0xF598L,1UL,2L,6UL,0x890CL,0x58L,0xA296AE8CL,18446744073709551615UL},{0xAC6DAB7E20503888LL,65532UL,0xF598L,1UL,2L,6UL,0x890CL,0x58L,0xA296AE8CL,18446744073709551615UL}},{{0xAC6DAB7E20503888LL,65532UL,0xF598L,1UL,2L,6UL,0x890CL,0x58L,0xA296AE8CL,18446744073709551615UL},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{7L,0x129FL,0L,0xD68CEC908283C7EFLL,0L,0xEBFDL,0x095FL,255UL,0UL,2UL},{7L,0x129FL,0L,0xD68CEC908283C7EFLL,0L,0xEBFDL,0x095FL,255UL,0UL,2UL},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{0xAC6DAB7E20503888LL,65532UL,0xF598L,1UL,2L,6UL,0x890CL,0x58L,0xA296AE8CL,18446744073709551615UL},{1L,0x62B0L,0x0017L,0UL,0L,0xDA18L,0x3DD0L,0x6EL,0xD9AE8C75L,0UL},{7L,0x129FL,0L,0xD68CEC908283C7EFLL,0L,0xEBFDL,0x095FL,255UL,0UL,2UL}}};
static volatile int32_t g_226 = 0xBD75E75CL;/* VOLATILE GLOBAL g_226 */
static volatile uint32_t g_227 = 4294967295UL;/* VOLATILE GLOBAL g_227 */
static volatile struct S0 g_237 = {6L,65528UL,0xBAF7L,0x3C2C657CE6F80BECLL,-6L,0x9975L,0x34F0L,0x3AL,1UL,18446744073709551611UL};/* VOLATILE GLOBAL g_237 */
static struct S0 g_238[8] = {{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL},{0L,0x0F23L,0x0746L,0x26BA7BF06610828ALL,1L,1UL,0xA56FL,250UL,0x3EDB1312L,18446744073709551615UL}};
static struct S0 g_276 = {0xA2EB4F23B0FC7D02LL,0x4134L,0xB348L,0x6A7DB87A818BF5C9LL,0L,0x986BL,65535UL,255UL,0xDCD8C62FL,0x7C6C2859L};/* VOLATILE GLOBAL g_276 */
static struct S0 g_277 = {0xD7710EA519D7A940LL,65535UL,0x56ADL,0xE3053518A418F75BLL,0xE399F6EBL,65532UL,5UL,0x49L,0x76400BEAL,0x4FAEEF8CL};/* VOLATILE GLOBAL g_277 */
static struct S0 g_278 = {0x825A526491130A6FLL,0x1D8DL,0x92CEL,0xE5505F3FDA1CE3F2LL,-9L,1UL,0xFC1EL,0x0CL,0UL,0x3C200E4AL};/* VOLATILE GLOBAL g_278 */
static uint32_t g_281[5][2] = {{0x2B693B70L,0UL},{0x2B693B70L,0UL},{0x2B693B70L,0UL},{0x2B693B70L,0UL},{0x2B693B70L,0UL}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static struct S0  func_9(int8_t  p_10, uint8_t  p_11);
static int8_t  func_28(uint32_t  p_29, int16_t  p_30, uint64_t  p_31, int16_t  p_32);
static uint8_t  func_46(int16_t  p_47, int64_t  p_48, int32_t  p_49, int8_t  p_50);
static int32_t  func_83(int16_t  p_84, int32_t  p_85, int8_t  p_86);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_42 g_39 g_98 g_105 g_120 g_127 g_131 g_147 g_136 g_170 g_186 g_193 g_199 g_183 g_202 g_180 g_182 g_227 g_238 g_237.f9 g_237.f1 g_276 g_277 g_281
 * writes: g_5 g_42 g_39 g_98 g_105 g_120.f4 g_127 g_131 g_136 g_147 g_170 g_186 g_193 g_227 g_202.f4 g_237 g_226 g_278 g_281 g_276.f4 g_277.f4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_12 = 0xE4F78D7CL;
    int32_t l_14 = 0x62A04F77L;
    if ((((safe_mod_func_int16_t_s_s(0xD2E8L, 0xF7BFL)) != g_4) , 0xD513C61CL))
    { /* block id: 1 */
        const int64_t l_13 = 0xC02A3062A4B15D3ELL;
        int8_t l_279[1];
        int32_t l_280 = 0xDF71C488L;
        int i;
        for (i = 0; i < 1; i++)
            l_279[i] = 9L;
        for (g_5 = 12; (g_5 < 20); ++g_5)
        { /* block id: 4 */
            int32_t l_8 = 0x746A1C17L;
            return l_8;
        }
        g_278 = func_9((l_12 <= l_13), l_14);
        ++g_281[2][1];
        g_276.f4 = 0x8E590C06L;
    }
    else
    { /* block id: 183 */
        int32_t l_290[10][4][4] = {{{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L},{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL},{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL},{2L,0L,2L,0x9AF34848L}},{{2L,0x9AF34848L,0x9AF34848L,2L},{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L},{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL},{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL}},{{2L,0L,2L,0x9AF34848L},{2L,0x9AF34848L,0x9AF34848L,2L},{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L},{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL}},{{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL},{2L,0L,2L,0x9AF34848L},{2L,0x9AF34848L,0x9AF34848L,2L},{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L}},{{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL},{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL},{2L,0L,2L,0x9AF34848L},{2L,0x9AF34848L,0x9AF34848L,2L}},{{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L},{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL},{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL},{2L,0L,2L,0x9AF34848L}},{{2L,0x9AF34848L,0x9AF34848L,2L},{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L},{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL},{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL}},{{2L,0L,2L,0x9AF34848L},{2L,0x9AF34848L,0x9AF34848L,2L},{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L},{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL}},{{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL},{2L,0L,2L,0x9AF34848L},{2L,0x9AF34848L,0x9AF34848L,2L},{0x5C6D67A0L,0x9AF34848L,0x91E3C11EL,0x9AF34848L}},{{0x9AF34848L,0L,0x91E3C11EL,0x91E3C11EL},{0x5C6D67A0L,0x5C6D67A0L,0x9AF34848L,0x91E3C11EL},{2L,0L,2L,0x9AF34848L},{0x91E3C11EL,2L,2L,0x91E3C11EL}}};
        int i, j, k;
        for (l_12 = 0; (l_12 <= 4); l_12 += 1)
        { /* block id: 186 */
            int32_t l_284 = (-9L);
            if (g_120.f2)
                break;
            l_284 = ((g_4 >= 0xD211L) , g_276.f3);
            g_226 = (safe_sub_func_uint8_t_u_u((!(((safe_mod_func_uint8_t_u_u(l_290[4][3][0], 0xADL)) , l_284) & 1UL)), 0xF2L));
            g_277.f4 = 0xA60A501BL;
        }
        g_237.f4 = g_227;
    }
    return g_180;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_42 g_39 g_98 g_105 g_120 g_127 g_131 g_147 g_136 g_170 g_186 g_193 g_199 g_183 g_202 g_180 g_182 g_227 g_238 g_237.f9 g_237.f1 g_276 g_277
 * writes: g_5 g_42 g_39 g_98 g_105 g_120.f4 g_127 g_131 g_136 g_147 g_170 g_186 g_193 g_227 g_202.f4 g_237 g_226
 */
static struct S0  func_9(int8_t  p_10, uint8_t  p_11)
{ /* block id: 7 */
    const uint64_t l_17[10][8][1] = {{{18446744073709551606UL},{0x9E84EBF8C32619C8LL},{0UL},{1UL},{0xB00B7228D029B4CCLL},{1UL},{0UL},{0x9E84EBF8C32619C8LL}},{{18446744073709551606UL},{0x8E60A2FC53D8B3D3LL},{0x9E84EBF8C32619C8LL},{0x41425452E2CC7BC5LL},{0xC0AECAA7054F86FCLL},{0xB00B7228D029B4CCLL},{1UL},{6UL}},{{0x9E84EBF8C32619C8LL},{0x407CB0BE945D4475LL},{0x407CB0BE945D4475LL},{0x9E84EBF8C32619C8LL},{6UL},{1UL},{0xB00B7228D029B4CCLL},{0xC0AECAA7054F86FCLL}},{{0x41425452E2CC7BC5LL},{0x9E84EBF8C32619C8LL},{0x8E60A2FC53D8B3D3LL},{18446744073709551606UL},{0x9E84EBF8C32619C8LL},{0UL},{1UL},{0xB00B7228D029B4CCLL}},{{1UL},{0UL},{0x9E84EBF8C32619C8LL},{18446744073709551606UL},{0x8E60A2FC53D8B3D3LL},{0x9E84EBF8C32619C8LL},{0x41425452E2CC7BC5LL},{0xC0AECAA7054F86FCLL}},{{0xB00B7228D029B4CCLL},{1UL},{6UL},{0x9E84EBF8C32619C8LL},{0x407CB0BE945D4475LL},{0x407CB0BE945D4475LL},{0x9E84EBF8C32619C8LL},{6UL}},{{1UL},{0xB00B7228D029B4CCLL},{0xC0AECAA7054F86FCLL},{0x41425452E2CC7BC5LL},{0x9E84EBF8C32619C8LL},{0x8E60A2FC53D8B3D3LL},{18446744073709551606UL},{0x9E84EBF8C32619C8LL}},{{0UL},{1UL},{0xB00B7228D029B4CCLL},{1UL},{0UL},{0x9E84EBF8C32619C8LL},{18446744073709551606UL},{0x8E60A2FC53D8B3D3LL}},{{0x9E84EBF8C32619C8LL},{0x41425452E2CC7BC5LL},{0xC0AECAA7054F86FCLL},{0xB00B7228D029B4CCLL},{1UL},{6UL},{0x9E84EBF8C32619C8LL},{0x407CB0BE945D4475LL}},{{0x407CB0BE945D4475LL},{0x9E84EBF8C32619C8LL},{6UL},{1UL},{0xB00B7228D029B4CCLL},{0xC0AECAA7054F86FCLL},{0x41425452E2CC7BC5LL},{0x9E84EBF8C32619C8LL}}};
    int32_t l_18 = 0xF4B9EFECL;
    uint16_t l_248[9] = {0x81CEL,0x81CEL,65529UL,0x81CEL,0x81CEL,65529UL,0x81CEL,0x81CEL,65529UL};
    uint8_t l_260 = 0x4AL;
    int32_t l_270[9][6] = {{0x622186B2L,(-1L),0L,0L,(-1L),0x622186B2L},{(-7L),0x622186B2L,0L,0x622186B2L,(-7L),(-7L)},{(-5L),0x622186B2L,0x622186B2L,(-5L),(-1L),(-5L)},{(-5L),(-1L),(-5L),0x622186B2L,0x622186B2L,(-5L)},{(-7L),(-7L),0x622186B2L,0L,0x622186B2L,(-7L)},{0x622186B2L,(-1L),0L,0L,(-1L),0x622186B2L},{(-7L),0x622186B2L,0L,0x622186B2L,(-7L),(-7L)},{(-5L),0x622186B2L,0x622186B2L,(-5L),(-1L),(-5L)},{(-5L),(-1L),(-5L),0x622186B2L,0x622186B2L,(-5L)}};
    int i, j, k;
    if (((safe_rshift_func_int8_t_s_s(p_11, 0)) != l_17[5][6][0]))
    { /* block id: 8 */
        g_5 = ((0x78L == p_11) , p_11);
        l_18 = 0x139A53AAL;
    }
    else
    { /* block id: 11 */
        uint64_t l_22 = 0UL;
        int32_t l_25 = 0x7E6007B4L;
        for (p_10 = 0; (p_10 == 14); ++p_10)
        { /* block id: 14 */
            int16_t l_21 = 2L;
            l_22 = (l_21 || p_10);
            g_5 = (safe_div_func_int32_t_s_s((g_5 , (-1L)), l_25));
            g_193 &= ((((safe_div_func_int8_t_s_s(func_28((0xAEC2L != (-7L)), l_17[5][6][0], g_4, p_11), p_10)) , 0x5CL) , p_10) <= 9L);
            if (p_11)
                continue;
        }
        g_5 |= p_10;
        g_120.f4 ^= (!((safe_div_func_int8_t_s_s(l_25, 0x51L)) , 0x9BL));
        g_5 = (((safe_mul_func_int8_t_s_s((((0UL < g_199[3][0]) , g_131) >= 0x5DD5L), 0x86L)) <= l_22) != g_131);
    }
    l_18 = (((((((safe_add_func_uint64_t_u_u(((g_120.f4 || l_17[9][0][0]) & p_11), g_136[2])) <= g_183) , g_202[1][5]) , g_42) != g_131) , g_186) | p_11);
    if ((0xF1258D5DL >= l_18))
    { /* block id: 131 */
        if ((safe_sub_func_uint64_t_u_u(0x9E67336551C80D2BLL, l_18)))
        { /* block id: 132 */
            int32_t l_205 = 0x0839589BL;
            int32_t l_206 = 0xD3C6D8B2L;
            l_206 &= ((p_11 , 0xEAL) == l_205);
        }
        else
        { /* block id: 134 */
            uint16_t l_209 = 0x5472L;
            l_209 ^= (safe_mul_func_uint16_t_u_u((g_120.f8 < g_180), p_10));
        }
    }
    else
    { /* block id: 137 */
        uint8_t l_215 = 0x27L;
        int32_t l_249 = 0L;
        l_18 = ((safe_add_func_uint8_t_u_u((((((+((safe_mod_func_uint32_t_u_u(((l_215 ^ p_11) | p_10), l_17[4][0][0])) >= 3L)) ^ p_11) != l_18) | l_215) , g_182), 255UL)) && p_11);
        if ((((safe_mod_func_int16_t_s_s(g_39, g_202[1][5].f5)) & 0x6318L) , 0xED8B2150L))
        { /* block id: 139 */
            int16_t l_224 = 0xEA00L;
            int32_t l_225 = (-1L);
            l_18 = ((safe_sub_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(p_11, p_10)), 0L)) | 0x27L);
            l_18 = (safe_rshift_func_int8_t_s_s(l_215, l_224));
            --g_227;
        }
        else
        { /* block id: 143 */
            g_202[1][5].f4 = (safe_add_func_int16_t_s_s(((safe_sub_func_int64_t_s_s(((~(safe_div_func_uint16_t_u_u(0xEA91L, g_42))) & 0UL), p_11)) == l_18), g_5));
            g_237 = g_202[0][4];
        }
        g_5 = (g_238[7] , 0xC42DD104L);
        for (l_215 = 11; (l_215 >= 59); l_215 = safe_add_func_uint64_t_u_u(l_215, 9))
        { /* block id: 150 */
            int8_t l_241 = (-1L);
            int32_t l_253[7];
            int i;
            for (i = 0; i < 7; i++)
                l_253[i] = 0x2E53EB80L;
            l_241 = (-2L);
            g_226 = (-3L);
            l_249 = ((safe_mod_func_int64_t_s_s((((safe_rshift_func_uint8_t_u_s((safe_rshift_func_int16_t_s_u(l_248[6], 4)), 0)) == p_11) , l_241), 0x315EEC50ED1BE1ECLL)) ^ 18446744073709551612UL);
            l_253[3] = (!((safe_mod_func_int32_t_s_s(l_249, g_238[7].f0)) > l_241));
        }
    }
    for (g_186 = 0; (g_186 <= 3); g_186 += 1)
    { /* block id: 159 */
        uint32_t l_261 = 18446744073709551615UL;
        int32_t l_262 = 0x37F9A2B0L;
        int32_t l_271 = 0x72235DFEL;
        uint16_t l_273 = 0xC569L;
        for (g_193 = 0; (g_193 <= 8); g_193 += 1)
        { /* block id: 162 */
            int i;
            l_261 |= (safe_add_func_int32_t_s_s((safe_add_func_int64_t_s_s((safe_div_func_uint32_t_u_u(((((((7L | 0x802AL) & g_136[g_186]) ^ g_237.f9) && 1UL) || p_11) > g_183), l_260)), g_136[g_186])), p_10));
            if (g_237.f1)
                break;
            if (g_227)
                continue;
            l_18 = ((l_261 , g_202[1][5].f2) | 0xA3A9BFCDL);
        }
        l_18 = (p_11 , p_11);
        l_262 = (0x98L | g_120.f8);
        if ((safe_unary_minus_func_int8_t_s((safe_mod_func_uint64_t_u_u(l_17[8][1][0], g_180)))))
        { /* block id: 170 */
            uint16_t l_266 = 1UL;
            int32_t l_269 = (-2L);
            int32_t l_272 = (-7L);
            l_266++;
            l_269 |= (-8L);
            g_5 &= p_11;
            ++l_273;
        }
        else
        { /* block id: 175 */
            return g_276;
        }
    }
    return g_277;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_42 g_39 g_98 g_105 g_120 g_127 g_131 g_147 g_136 g_170 g_186
 * writes: g_42 g_5 g_39 g_98 g_105 g_120.f4 g_127 g_131 g_136 g_147 g_170 g_186
 */
static int8_t  func_28(uint32_t  p_29, int16_t  p_30, uint64_t  p_31, int16_t  p_32)
{ /* block id: 17 */
    int32_t l_37[8] = {0x0C7F43A4L,0x0C7F43A4L,0x0C7F43A4L,0x0C7F43A4L,0x0C7F43A4L,0x0C7F43A4L,0x0C7F43A4L,0x0C7F43A4L};
    int32_t l_69 = 0x9915A3DCL;
    uint32_t l_165 = 0x446BF52AL;
    volatile uint64_t l_167 = 0x1D5C9785EC66A7C9LL;/* VOLATILE GLOBAL l_167 */
    int32_t l_169[9][2] = {{1L,0x197A97A6L},{0x268E8976L,0x268E8976L},{0x268E8976L,0x197A97A6L},{1L,(-3L)},{0x197A97A6L,(-3L)},{1L,0x197A97A6L},{0x268E8976L,0x268E8976L},{0x268E8976L,0x197A97A6L},{1L,(-3L)}};
    int i, j;
    if ((safe_div_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u((g_4 == (-1L)), 1UL)), g_5)))
    { /* block id: 18 */
        return p_30;
    }
    else
    { /* block id: 20 */
        int32_t l_38 = 1L;
        int32_t l_58[6][1][4];
        int i, j, k;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 1; j++)
            {
                for (k = 0; k < 4; k++)
                    l_58[i][j][k] = 0x7E9A86F2L;
            }
        }
        l_38 ^= l_37[2];
        if (((g_4 == 0UL) < p_32))
        { /* block id: 22 */
            int32_t l_40 = (-1L);
            int32_t l_41 = 8L;
            g_42--;
            l_41 = (!(((func_46((+p_30), l_38, g_39, l_37[2]) != p_30) & 0xC5L) , g_39));
            g_5 = (safe_lshift_func_int16_t_s_u(((((safe_lshift_func_uint16_t_u_u(g_42, l_40)) , 0UL) == 0x1BL) || g_4), 13));
        }
        else
        { /* block id: 28 */
            int8_t l_57 = 8L;
            l_58[4][0][1] ^= func_46(((((0x04B5L == l_37[2]) , g_5) | l_38) > 0x46B6L), p_30, l_57, g_42);
            l_58[1][0][0] = (l_37[6] < 4UL);
        }
    }
    if (p_32)
        goto lbl_168;
lbl_168:
    if ((safe_div_func_int16_t_s_s((l_37[5] || l_37[2]), 0x53ABL)))
    { /* block id: 33 */
        int8_t l_61[5][5][9] = {{{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)},{(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L)},{(-2L),(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L)},{0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L},{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)}},{{(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L)},{(-2L),(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L)},{0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L},{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)},{(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L)}},{{(-2L),(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L)},{0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L},{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)},{(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L)},{(-2L),(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L)}},{{0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L},{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)},{(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L)},{(-2L),(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L)},{0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L}},{{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)},{(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L),0xC3L,(-4L)},{(-2L),(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L)},{0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L,0xC3L,0x26L},{(-2L),1L,1L,(-2L),(-2L),1L,1L,(-2L),(-2L)}}};
        int i, j, k;
        l_61[3][4][7] = (-10L);
    }
    else
    { /* block id: 35 */
        uint8_t l_66[3][7][9] = {{{248UL,0x32L,1UL,0x32L,248UL,0x76L,0xD4L,0xFCL,1UL},{0x2AL,246UL,0x64L,0xE2L,0x23L,0x23L,0xE2L,0x64L,246UL},{1UL,0x64L,248UL,1UL,0x68L,0x76L,255UL,0xA6L,255UL},{247UL,0x53L,0xE2L,0x03L,251UL,254UL,0xD3L,247UL,251UL},{1UL,0x64L,0x1CL,0x32L,0UL,0xFCL,0UL,0x32L,0x1CL},{246UL,246UL,0xD3L,0x53L,0x8CL,251UL,0xD3L,5UL,246UL},{255UL,0x32L,1UL,0xFCL,1UL,0x32L,255UL,0x64L,0UL}},{{251UL,254UL,0xD3L,247UL,251UL,0xE2L,0xE2L,251UL,247UL},{0x1CL,0xA6L,0x1CL,0x76L,1UL,1UL,0xD4L,0x64L,0UL},{246UL,0x2AL,0xE2L,0xD3L,0x23L,0x03L,0x64L,5UL,0x2AL},{0UL,0xFCL,248UL,0x76L,249UL,0x32L,0x68L,0x32L,249UL},{247UL,0x64L,0x64L,247UL,246UL,0x53L,5UL,247UL,0x2AL},{0UL,0xA6L,1UL,0xFCL,255UL,0xFCL,1UL,0xA6L,0UL},{0x2AL,247UL,5UL,0x53L,246UL,247UL,0x64L,0x64L,247UL}},{{249UL,0x32L,0x68L,0x32L,249UL,0x76L,248UL,0xFCL,0UL},{0x2AL,5UL,0x64L,0x03L,0x23L,0xD3L,0xE2L,0x2AL,246UL},{0UL,0x64L,0xD4L,1UL,1UL,0x76L,0x1CL,0xA6L,0x1CL},{247UL,251UL,0xE2L,0xE2L,251UL,247UL,0xD3L,254UL,251UL},{0UL,0x64L,255UL,0x32L,1UL,0xFCL,1UL,0x32L,255UL},{246UL,5UL,0xD3L,251UL,247UL,0xE2L,5UL,0x8CL,0x8CL},{248UL,0x64L,255UL,0x76L,255UL,0x64L,248UL,0xFCL,0x1CL}}};
        int32_t l_79 = 0xE4102AFEL;
        int i, j, k;
        for (g_39 = 0; (g_39 <= 7); g_39 += 1)
        { /* block id: 38 */
            int i;
            l_66[1][6][4] = (safe_add_func_int32_t_s_s((safe_mul_func_int16_t_s_s((((l_37[g_39] > 0L) <= l_37[2]) >= 0xB3L), l_37[5])), (-1L)));
            g_5 = (g_39 == l_37[g_39]);
            if (g_5)
                goto lbl_80;
        }
lbl_80:
        if ((safe_div_func_int32_t_s_s(0xCCAF28F6L, 0xB0F612F8L)))
        { /* block id: 42 */
            int16_t l_70[3];
            int32_t l_73 = 1L;
            int i;
            for (i = 0; i < 3; i++)
                l_70[i] = (-4L);
            l_69 &= (func_46(g_39, l_66[1][6][4], p_29, g_39) != p_29);
            l_70[2] = p_32;
            l_73 = ((safe_lshift_func_int8_t_s_u(1L, g_4)) || 0L);
            l_73 = p_31;
        }
        else
        { /* block id: 47 */
            int32_t l_78 = 1L;
            l_79 = (safe_rshift_func_int16_t_s_s((safe_rshift_func_int16_t_s_s(g_5, l_78)), l_37[1]));
            return g_4;
        }
        for (g_39 = 8; (g_39 > (-28)); g_39 = safe_sub_func_int16_t_s_s(g_39, 1))
        { /* block id: 54 */
            uint8_t l_89[2];
            uint8_t l_90[3];
            int32_t l_166 = 0xACAF346CL;
            int i;
            for (i = 0; i < 2; i++)
                l_89[i] = 0xA8L;
            for (i = 0; i < 3; i++)
                l_90[i] = 1UL;
            l_69 = func_83((safe_rshift_func_int16_t_s_s((((1L >= 5L) & 248UL) || l_37[3]), g_5)), l_89[1], l_90[2]);
            if (g_120.f8)
                break;
            l_166 = (safe_div_func_uint32_t_u_u(0x88CC17E2L, l_165));
            l_167 = g_120.f3;
        }
    }
    --g_170;
    for (g_98 = 0; (g_98 <= 52); g_98++)
    { /* block id: 110 */
        int16_t l_178 = 0x3A5FL;
        int32_t l_179[9] = {3L,3L,3L,3L,3L,3L,3L,3L,3L};
        uint32_t l_192 = 7UL;
        int i;
        for (p_29 = 0; (p_29 <= 1); p_29 += 1)
        { /* block id: 113 */
            int32_t l_175 = 0xFC4B7379L;
            int32_t l_176 = 0x8C446EDBL;
            int32_t l_177 = 0L;
            int32_t l_181 = 0xFE65D847L;
            int i, j;
            g_120.f4 = (l_169[(p_29 + 2)][p_29] == l_169[(p_29 + 5)][p_29]);
            g_186++;
            g_5 &= (+(safe_div_func_uint8_t_u_u(g_136[(p_29 + 2)], l_192)));
            l_179[0] = ((g_105 > l_178) != 1L);
        }
        g_5 = (((0xD6C3L & p_30) ^ 1L) | 0xA5CAD6F74C4BF40DLL);
        return g_105;
    }
    return p_29;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_46(int16_t  p_47, int64_t  p_48, int32_t  p_49, int8_t  p_50)
{ /* block id: 24 */
    uint64_t l_52 = 0x4A4D940870E26735LL;
    return l_52;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_98 g_105 g_42 g_120 g_127 g_131 g_147 g_136
 * writes: g_98 g_5 g_105 g_120.f4 g_127 g_131 g_136 g_147
 */
static int32_t  func_83(int16_t  p_84, int32_t  p_85, int8_t  p_86)
{ /* block id: 55 */
    int8_t l_97 = 1L;
    int32_t l_103 = 1L;
    uint32_t l_108 = 0x29ECF7F4L;
    int16_t l_154 = 6L;
    int16_t l_161 = 9L;
    int64_t l_162 = 1L;
    if ((safe_div_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((safe_mod_func_uint16_t_u_u(0xB586L, g_5)), l_97)), l_97)))
    { /* block id: 56 */
        ++g_98;
        for (g_5 = (-26); (g_5 > 26); g_5 = safe_add_func_uint16_t_u_u(g_5, 1))
        { /* block id: 60 */
            int8_t l_104 = 0L;
            g_105--;
            p_85 |= ((4L | g_98) | l_108);
        }
    }
    else
    { /* block id: 64 */
        int64_t l_113 = 1L;
        int32_t l_124 = (-1L);
        int32_t l_125[3][8][6] = {{{(-5L),6L,(-5L),0xF6804774L,0x1D0ACD33L,1L},{0x3C3FA534L,0xDB1BCEFEL,0x28086959L,0x7EC679D4L,0x1D0ACD33L,0L},{0x28086959L,6L,0L,0x7EC679D4L,1L,0xF6804774L},{0x3C3FA534L,4L,0L,0xF6804774L,0xE241EA34L,0L},{(-5L),4L,0x28086959L,1L,1L,1L},{(-5L),6L,(-5L),0xF6804774L,0x1D0ACD33L,1L},{0x3C3FA534L,0xDB1BCEFEL,0x28086959L,0x7EC679D4L,0x1D0ACD33L,0L},{0x28086959L,6L,0L,0x7EC679D4L,1L,0xF6804774L}},{{0x3C3FA534L,4L,0L,0xF6804774L,0xE241EA34L,0L},{(-5L),4L,0x28086959L,1L,1L,1L},{(-5L),6L,(-5L),0xF6804774L,0x1D0ACD33L,1L},{0x3C3FA534L,0xDB1BCEFEL,0x28086959L,0x7EC679D4L,0x1D0ACD33L,0L},{0x28086959L,6L,0L,0x7EC679D4L,1L,0xF6804774L},{0x3C3FA534L,4L,0L,0xF6804774L,0xE241EA34L,0L},{(-5L),4L,0x28086959L,1L,1L,1L},{(-5L),6L,(-5L),0xF6804774L,0x1D0ACD33L,1L}},{{0x3C3FA534L,0xDB1BCEFEL,0x28086959L,0x7EC679D4L,0x1D0ACD33L,0L},{0x28086959L,6L,0L,0x7EC679D4L,1L,0xF6804774L},{0x3C3FA534L,4L,0L,0xF6804774L,0xE241EA34L,0L},{(-5L),4L,0x28086959L,1L,1L,1L},{(-5L),6L,(-5L),0xF6804774L,0x1D0ACD33L,1L},{0x3C3FA534L,0xDB1BCEFEL,0x28086959L,0x7EC679D4L,0x1D0ACD33L,0L},{0x28086959L,6L,0L,0x7EC679D4L,1L,0xF6804774L},{0x3C3FA534L,4L,0L,0xF6804774L,0xE241EA34L,0L}}};
        int i, j, k;
        for (p_84 = 27; (p_84 == (-18)); p_84 = safe_sub_func_int16_t_s_s(p_84, 4))
        { /* block id: 67 */
            g_5 = (safe_mod_func_int8_t_s_s(p_85, 0x07L));
            l_113 = ((p_84 , g_98) == 0x46L);
            return g_42;
        }
        if ((safe_rshift_func_uint8_t_u_u((safe_add_func_int16_t_s_s((safe_mul_func_int16_t_s_s(((((g_120 , (-1L)) ^ p_86) >= 0x12B9BE39L) , l_113), g_5)), g_98)), 2)))
        { /* block id: 72 */
            g_120.f4 = l_113;
        }
        else
        { /* block id: 74 */
            uint8_t l_123 = 248UL;
            int32_t l_126[6] = {0x307BF795L,0L,0x307BF795L,0x307BF795L,0L,0x307BF795L};
            int i;
            g_5 = 0x3A3A19F5L;
            l_123 = ((((safe_div_func_int8_t_s_s((0xEE54L < 0UL), 0x25L)) | 0x4CL) <= l_113) || l_108);
            if (p_85)
                goto lbl_130;
lbl_130:
            g_127++;
            ++g_131;
        }
    }
    for (p_86 = 0; (p_86 > (-6)); p_86 = safe_sub_func_int16_t_s_s(p_86, 7))
    { /* block id: 84 */
        uint32_t l_137 = 0UL;
        int32_t l_146 = 0x70B1168EL;
        for (g_127 = 0; g_127 < 4; g_127 += 1)
        {
            g_136[g_127] = 0x32L;
        }
        l_137 = (4L < g_120.f1);
        if ((l_108 | 6L))
        { /* block id: 87 */
            int8_t l_144 = 0x95L;
            l_144 ^= ((safe_mod_func_int8_t_s_s((((safe_div_func_int64_t_s_s(((((safe_add_func_int64_t_s_s((0x68E7L && l_108), (-2L))) , l_103) > 3UL) < g_127), p_85)) | p_84) , l_137), 0xDDL)) , l_108);
            if (p_85)
                break;
        }
        else
        { /* block id: 90 */
            int32_t l_145 = 0x9E760767L;
            l_146 = l_145;
            if (g_131)
                continue;
            if (g_120.f3)
                continue;
            ++g_147;
        }
    }
    g_120.f4 &= (safe_add_func_int32_t_s_s((safe_add_func_int64_t_s_s((0x72AF336772AC288FLL >= 0x79D74A7D6E7BBDDALL), 1UL)), l_154));
    l_103 = ((safe_mul_func_int16_t_s_s((((safe_rshift_func_int16_t_s_s((safe_sub_func_int64_t_s_s(p_84, p_84)), l_161)) <= g_136[2]) & 18446744073709551614UL), l_162)) && p_85);
    return g_120.f4;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_120.f0, "g_120.f0", print_hash_value);
    transparent_crc(g_120.f1, "g_120.f1", print_hash_value);
    transparent_crc(g_120.f2, "g_120.f2", print_hash_value);
    transparent_crc(g_120.f3, "g_120.f3", print_hash_value);
    transparent_crc(g_120.f4, "g_120.f4", print_hash_value);
    transparent_crc(g_120.f5, "g_120.f5", print_hash_value);
    transparent_crc(g_120.f6, "g_120.f6", print_hash_value);
    transparent_crc(g_120.f7, "g_120.f7", print_hash_value);
    transparent_crc(g_120.f8, "g_120.f8", print_hash_value);
    transparent_crc(g_120.f9, "g_120.f9", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_136[i], "g_136[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_147, "g_147", print_hash_value);
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_180, "g_180", print_hash_value);
    transparent_crc(g_182, "g_182", print_hash_value);
    transparent_crc(g_183, "g_183", print_hash_value);
    transparent_crc(g_184, "g_184", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_185[i][j][k], "g_185[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_186, "g_186", print_hash_value);
    transparent_crc(g_193, "g_193", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_199[i][j], "g_199[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_202[i][j].f0, "g_202[i][j].f0", print_hash_value);
            transparent_crc(g_202[i][j].f1, "g_202[i][j].f1", print_hash_value);
            transparent_crc(g_202[i][j].f2, "g_202[i][j].f2", print_hash_value);
            transparent_crc(g_202[i][j].f3, "g_202[i][j].f3", print_hash_value);
            transparent_crc(g_202[i][j].f4, "g_202[i][j].f4", print_hash_value);
            transparent_crc(g_202[i][j].f5, "g_202[i][j].f5", print_hash_value);
            transparent_crc(g_202[i][j].f6, "g_202[i][j].f6", print_hash_value);
            transparent_crc(g_202[i][j].f7, "g_202[i][j].f7", print_hash_value);
            transparent_crc(g_202[i][j].f8, "g_202[i][j].f8", print_hash_value);
            transparent_crc(g_202[i][j].f9, "g_202[i][j].f9", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_226, "g_226", print_hash_value);
    transparent_crc(g_227, "g_227", print_hash_value);
    transparent_crc(g_237.f0, "g_237.f0", print_hash_value);
    transparent_crc(g_237.f1, "g_237.f1", print_hash_value);
    transparent_crc(g_237.f2, "g_237.f2", print_hash_value);
    transparent_crc(g_237.f3, "g_237.f3", print_hash_value);
    transparent_crc(g_237.f4, "g_237.f4", print_hash_value);
    transparent_crc(g_237.f5, "g_237.f5", print_hash_value);
    transparent_crc(g_237.f6, "g_237.f6", print_hash_value);
    transparent_crc(g_237.f7, "g_237.f7", print_hash_value);
    transparent_crc(g_237.f8, "g_237.f8", print_hash_value);
    transparent_crc(g_237.f9, "g_237.f9", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_238[i].f0, "g_238[i].f0", print_hash_value);
        transparent_crc(g_238[i].f1, "g_238[i].f1", print_hash_value);
        transparent_crc(g_238[i].f2, "g_238[i].f2", print_hash_value);
        transparent_crc(g_238[i].f3, "g_238[i].f3", print_hash_value);
        transparent_crc(g_238[i].f4, "g_238[i].f4", print_hash_value);
        transparent_crc(g_238[i].f5, "g_238[i].f5", print_hash_value);
        transparent_crc(g_238[i].f6, "g_238[i].f6", print_hash_value);
        transparent_crc(g_238[i].f7, "g_238[i].f7", print_hash_value);
        transparent_crc(g_238[i].f8, "g_238[i].f8", print_hash_value);
        transparent_crc(g_238[i].f9, "g_238[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_276.f0, "g_276.f0", print_hash_value);
    transparent_crc(g_276.f1, "g_276.f1", print_hash_value);
    transparent_crc(g_276.f2, "g_276.f2", print_hash_value);
    transparent_crc(g_276.f3, "g_276.f3", print_hash_value);
    transparent_crc(g_276.f4, "g_276.f4", print_hash_value);
    transparent_crc(g_276.f5, "g_276.f5", print_hash_value);
    transparent_crc(g_276.f6, "g_276.f6", print_hash_value);
    transparent_crc(g_276.f7, "g_276.f7", print_hash_value);
    transparent_crc(g_276.f8, "g_276.f8", print_hash_value);
    transparent_crc(g_276.f9, "g_276.f9", print_hash_value);
    transparent_crc(g_277.f0, "g_277.f0", print_hash_value);
    transparent_crc(g_277.f1, "g_277.f1", print_hash_value);
    transparent_crc(g_277.f2, "g_277.f2", print_hash_value);
    transparent_crc(g_277.f3, "g_277.f3", print_hash_value);
    transparent_crc(g_277.f4, "g_277.f4", print_hash_value);
    transparent_crc(g_277.f5, "g_277.f5", print_hash_value);
    transparent_crc(g_277.f6, "g_277.f6", print_hash_value);
    transparent_crc(g_277.f7, "g_277.f7", print_hash_value);
    transparent_crc(g_277.f8, "g_277.f8", print_hash_value);
    transparent_crc(g_277.f9, "g_277.f9", print_hash_value);
    transparent_crc(g_278.f0, "g_278.f0", print_hash_value);
    transparent_crc(g_278.f1, "g_278.f1", print_hash_value);
    transparent_crc(g_278.f2, "g_278.f2", print_hash_value);
    transparent_crc(g_278.f3, "g_278.f3", print_hash_value);
    transparent_crc(g_278.f4, "g_278.f4", print_hash_value);
    transparent_crc(g_278.f5, "g_278.f5", print_hash_value);
    transparent_crc(g_278.f6, "g_278.f6", print_hash_value);
    transparent_crc(g_278.f7, "g_278.f7", print_hash_value);
    transparent_crc(g_278.f8, "g_278.f8", print_hash_value);
    transparent_crc(g_278.f9, "g_278.f9", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_281[i][j], "g_281[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 95
   depth: 1, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 129
   depth: 2, occurrence: 30
   depth: 3, occurrence: 16
   depth: 4, occurrence: 8
   depth: 5, occurrence: 1
   depth: 6, occurrence: 5
   depth: 7, occurrence: 3
   depth: 8, occurrence: 3
   depth: 9, occurrence: 1
   depth: 10, occurrence: 3
   depth: 11, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 167
XXX times a non-volatile is write: 74
XXX times a volatile is read: 37
XXX    times read thru a pointer: 0
XXX times a volatile is write: 15
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 160
XXX percentage of non-volatile access: 82.3

XXX forward jumps: 3
XXX backward jumps: 0

XXX stmts: 125
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 38
   depth: 2, occurrence: 68

XXX percentage a fresh-made variable is used: 29.6
XXX percentage an existing variable is used: 70.4
********************* end of statistics **********************/

