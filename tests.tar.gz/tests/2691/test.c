/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11256956179069195298
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_6 = 0UL;
static int32_t g_8 = 1L;
static volatile uint32_t g_14 = 0UL;/* VOLATILE GLOBAL g_14 */
static volatile int32_t g_42 = 1L;/* VOLATILE GLOBAL g_42 */
static volatile uint64_t g_43 = 2UL;/* VOLATILE GLOBAL g_43 */
static int32_t g_47[8] = {0xC7E7C0CEL,0xC7E7C0CEL,0xC7E7C0CEL,0xC7E7C0CEL,0xC7E7C0CEL,0xC7E7C0CEL,0xC7E7C0CEL,0xC7E7C0CEL};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint32_t  func_4(uint64_t  p_5);
static int8_t  func_19(uint16_t  p_20, uint8_t  p_21);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_8 g_14 g_43
 * writes: g_8 g_14 g_43 g_47
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_46 = 5UL;
    int64_t l_48 = 0x5036FFE617092FF8LL;
    int32_t l_49 = 9L;
    int32_t l_50 = 0xD5DF5B04L;
    int32_t l_51 = (-1L);
    int32_t l_52 = 0x512ED403L;
    int32_t l_53 = 0xB1DCEDE6L;
    int32_t l_54 = 1L;
    int32_t l_55 = 8L;
    int32_t l_56 = 0xB53CF54CL;
    int32_t l_57 = 0L;
    int32_t l_58 = (-1L);
    int32_t l_59 = 0x7FCCEA59L;
    int32_t l_60 = 0x2EFAADADL;
    uint8_t l_61 = 255UL;
    g_47[3] = (safe_div_func_uint64_t_u_u((func_4(g_6) ^ l_46), (-5L)));
    ++l_61;
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_8 g_14 g_43
 * writes: g_8 g_14 g_43
 */
static uint32_t  func_4(uint64_t  p_5)
{ /* block id: 1 */
    int32_t l_7 = (-1L);
    int32_t l_9 = (-1L);
    int32_t l_10 = 0xD697E780L;
    int32_t l_11 = (-1L);
    int32_t l_12 = (-1L);
    int32_t l_13 = 0x3631E19EL;
    uint32_t l_41 = 0xF0B56FE1L;
    g_8 |= (l_7 ^ g_6);
    ++g_14;
    l_41 = (((safe_mul_func_int8_t_s_s(func_19((safe_mul_func_int8_t_s_s((((safe_mul_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(l_13, l_10)), (-1L))) == 0xA796D402L) <= p_5), p_5)), p_5), g_6)) , 0x7CBB40284818A88ALL) && p_5);
    g_43--;
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_14
 * writes:
 */
static int8_t  func_19(uint16_t  p_20, uint8_t  p_21)
{ /* block id: 4 */
    int64_t l_28 = 0xF0442E11914CC5C6LL;
    int32_t l_29 = 0x0EE1D459L;
    int32_t l_30 = (-1L);
    int32_t l_31 = (-1L);
    int32_t l_32 = 1L;
    uint32_t l_33 = 1UL;
    ++l_33;
    l_31 = (safe_lshift_func_int8_t_s_u((~((safe_lshift_func_int16_t_s_s(g_8, 7)) | 0xC0L)), g_14));
    l_31 ^= l_30;
    return p_20;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_47[i], "g_47[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 34
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 1
   depth: 4, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 16
XXX times a non-volatile is write: 7
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 18
XXX percentage of non-volatile access: 88.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 12

XXX percentage a fresh-made variable is used: 50.7
XXX percentage an existing variable is used: 49.3
********************* end of statistics **********************/

