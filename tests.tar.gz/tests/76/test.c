/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      265399178148815581
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_22[7][3] = {{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL},{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL},{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL},{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL},{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL},{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL},{0x8B060D2F38D927F7LL,(-2L),0x8B060D2F38D927F7LL}};
static uint32_t g_59 = 0x1060F33EL;
static int32_t g_62 = 0x8364B2CBL;
static int16_t g_72 = (-1L);
static int16_t g_89 = 0x1D9EL;
static int8_t g_107 = (-1L);
static int64_t g_116 = 0x9BA1A3DBB834B12ELL;
static volatile uint16_t g_117[1] = {65535UL};
static uint32_t g_134[6] = {0xE8E1B626L,0xE8E1B626L,0xE8E1B626L,0xE8E1B626L,0xE8E1B626L,0xE8E1B626L};
static int16_t g_135 = 0xBD9BL;
static uint16_t g_136 = 0xE426L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_6(const int64_t  p_7, int32_t  p_8);
static int32_t  func_34(uint64_t  p_35, uint64_t  p_36, int64_t  p_37, uint8_t  p_38);
static const int64_t  func_50(uint64_t  p_51);
static int32_t  func_73(int32_t  p_74, int16_t  p_75, uint64_t  p_76);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_22 g_59 g_72 g_62 g_89 g_107 g_117 g_134 g_136
 * writes: g_59 g_62 g_72 g_89 g_107 g_117 g_134 g_135 g_136
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_23 = 0xE9AB5C29L;
    const uint16_t l_106[10][8] = {{65535UL,0UL,65535UL,0xCD08L,0x258EL,2UL,0xF1BBL,65535UL},{0x8D8CL,65535UL,0x1A5AL,0UL,0x948FL,0x2B1DL,0xE207L,0x2B1DL},{0UL,0xE207L,7UL,0x366BL,0x42A4L,65535UL,0x10D5L,65534UL},{0xF1BBL,0x8F2FL,0UL,65535UL,0x6180L,0UL,8UL,0x366BL},{65535UL,0UL,0UL,0x948FL,65535UL,0x6180L,0x10D5L,0x42A4L},{0x6180L,0x4EDEL,7UL,65534UL,1UL,2UL,0x366BL,0xEB14L},{0xCD08L,0xE207L,0x6844L,0x1672L,65535UL,65535UL,0x1672L,0x6844L},{0x8D8CL,0x8D8CL,0x2B1DL,65535UL,0xEB14L,0xB0B7L,1UL,0x948FL},{0x8F2FL,65535UL,8UL,0x4F6AL,0UL,0UL,2UL,0x948FL},{65535UL,0x948FL,65535UL,65535UL,0x1672L,7UL,0UL,0x6844L}};
    int32_t l_115 = 0x6E128E9CL;
    const int32_t l_149 = 0L;
    int i, j;
    g_107 ^= (safe_rshift_func_int8_t_s_u(((((safe_lshift_func_int8_t_s_u(func_6((!(safe_div_func_uint32_t_u_u(((((safe_mul_func_uint16_t_u_u((safe_div_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_div_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(g_22[5][1], 14)), g_22[3][2])), g_22[5][2])), 0x41L)), 0xB919L)) <= (-7L)) , g_22[5][1]) > 0x27L), l_23))), g_22[4][1]), g_22[1][1])) | 18446744073709551607UL) & g_22[5][1]) , 0xE9L), l_106[0][0]));
    if (((safe_unary_minus_func_uint8_t_u((safe_mul_func_int8_t_s_s(l_23, 3UL)))) , 0x3B6D2253L))
    { /* block id: 71 */
        int32_t l_111[7];
        int i;
        for (i = 0; i < 7; i++)
            l_111[i] = 0xE36A62F8L;
        if (l_111[0])
        { /* block id: 72 */
            uint8_t l_114 = 0x7CL;
            uint8_t l_120 = 0xFDL;
            l_114 ^= ((safe_rshift_func_uint16_t_u_u((1L >= g_22[4][1]), 10)) , (-6L));
            ++g_117[0];
            l_120 = l_114;
            l_115 = ((((((safe_div_func_uint32_t_u_u((safe_sub_func_int64_t_s_s((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u(1UL, 3)), 0L)), 8L)), 0xD7C28814L)) > l_120) || g_117[0]) <= 0x42L) , g_22[1][1]) >= l_120);
        }
        else
        { /* block id: 77 */
            uint8_t l_133 = 255UL;
            g_134[0] = (safe_div_func_uint64_t_u_u((safe_add_func_uint8_t_u_u(0xE0L, l_133)), 18446744073709551609UL));
            g_135 = g_134[2];
            g_136 ^= ((1UL <= g_22[1][2]) || 0xC4L);
        }
    }
    else
    { /* block id: 82 */
        uint8_t l_148[2][5] = {{1UL,251UL,1UL,0xEEL,0xEEL},{1UL,251UL,1UL,0xEEL,0xEEL}};
        int i, j;
        l_115 &= ((+(safe_add_func_int16_t_s_s((safe_rshift_func_int8_t_s_u((safe_div_func_int64_t_s_s((safe_add_func_uint32_t_u_u((safe_add_func_int64_t_s_s(l_148[0][0], 0xD2EC4E0F54C3530BLL)), l_149)), g_59)), g_22[5][1])), l_23))) != g_117[0]);
        return l_106[7][2];
    }
    return g_89;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_59 g_72 g_62 g_89
 * writes: g_59 g_62 g_72 g_89
 */
static int8_t  func_6(const int64_t  p_7, int32_t  p_8)
{ /* block id: 1 */
    const uint16_t l_28[4][5] = {{65535UL,65535UL,65532UL,65532UL,65535UL},{8UL,0xE69CL,8UL,0xE69CL,8UL},{65535UL,65532UL,65532UL,65535UL,65535UL},{5UL,0xE69CL,5UL,0xE69CL,5UL}};
    int32_t l_100 = 0xA596AD70L;
    int i, j;
    for (p_8 = (-12); (p_8 > 15); p_8 = safe_add_func_uint32_t_u_u(p_8, 7))
    { /* block id: 4 */
        uint32_t l_27 = 18446744073709551614UL;
        int32_t l_95 = 1L;
        if (p_7)
        { /* block id: 5 */
            int32_t l_29 = 0x00A9E1A0L;
            l_29 = ((((safe_unary_minus_func_int16_t_s((((g_22[1][0] , l_27) & g_22[5][1]) , p_8))) || l_28[3][3]) < l_27) > 1L);
            l_29 &= (safe_lshift_func_uint16_t_u_s(((safe_mul_func_int8_t_s_s(l_27, 9UL)) ^ g_22[5][1]), g_22[5][1]));
        }
        else
        { /* block id: 8 */
            return g_22[5][1];
        }
        l_95 = func_34(((safe_sub_func_int8_t_s_s(((safe_sub_func_int16_t_s_s(0xB81FL, p_7)) > 0xDEL), l_27)) >= g_22[6][2]), g_22[2][2], p_7, g_22[6][0]);
        if (l_28[3][3])
            break;
        if (l_27)
            break;
    }
    l_100 ^= (safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s(0xE414L, l_28[0][0])), l_28[0][2]));
    for (g_89 = 2; (g_89 >= 0); g_89 -= 1)
    { /* block id: 60 */
        if (p_8)
            break;
        for (p_8 = 0; (p_8 <= 2); p_8 += 1)
        { /* block id: 64 */
            int32_t l_103[3];
            int i, j;
            for (i = 0; i < 3; i++)
                l_103[i] = 0xD7AA0E73L;
            l_103[1] = (((safe_add_func_uint64_t_u_u((((((g_22[(p_8 + 2)][p_8] , g_22[g_89][p_8]) && g_22[p_8][p_8]) && p_8) && 0x4953B525L) < g_72), 0x6DEC5612EDF4FAD4LL)) >= 0L) , l_28[3][3]);
        }
    }
    l_100 = (safe_sub_func_int64_t_s_s(p_8, g_62));
    return l_100;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_59 g_72 g_62
 * writes: g_59 g_62 g_72 g_89
 */
static int32_t  func_34(uint64_t  p_35, uint64_t  p_36, int64_t  p_37, uint8_t  p_38)
{ /* block id: 11 */
    int8_t l_49 = 0xB6L;
    int32_t l_66[6][4][4] = {{{(-1L),0xF156DE04L,0xB773B032L,(-1L)},{0x6449D4C0L,0xEC2C04DDL,0x27E0E8BBL,8L},{1L,1L,3L,0x6449D4C0L},{0x765A3FF5L,(-3L),4L,(-1L)}},{{0x891D9855L,6L,8L,6L},{1L,0x6449D4C0L,6L,0x96E53FD1L},{0x96E53FD1L,0x27E0E8BBL,(-1L),0x765A3FF5L},{0L,9L,(-1L),0xE3CFE890L}},{{0L,0x66F8A59DL,(-1L),(-2L)},{0x96E53FD1L,0xE3CFE890L,6L,8L},{1L,(-1L),8L,1L},{0x891D9855L,0xA2D53575L,4L,0x66F8A59DL}},{{0x765A3FF5L,4L,3L,1L},{1L,0x55714A8AL,0x27E0E8BBL,0x7B22F105L},{0x6449D4C0L,(-2L),0xB773B032L,0xB773B032L},{(-1L),(-1L),0xCA6AFE10L,0L}},{{0xB773B032L,1L,0x439D6F46L,(-1L)},{0x4114487FL,(-6L),0L,0x439D6F46L},{0xF156DE04L,(-6L),(-2L),(-1L)},{(-6L),1L,1L,0L}},{{(-9L),(-1L),0xF156DE04L,0xB773B032L},{0x27E0E8BBL,(-2L),(-3L),0x7B22F105L},{0xCA6AFE10L,0x55714A8AL,0x96E53FD1L,1L},{0xEC2C04DDL,4L,(-9L),0x66F8A59DL}}};
    const uint32_t l_67[10] = {4294967295UL,0x6F84C1F2L,4294967295UL,2UL,4294967295UL,2UL,2UL,4294967295UL,2UL,2UL};
    int i, j, k;
    for (p_36 = 0; (p_36 < 41); ++p_36)
    { /* block id: 14 */
        int32_t l_63[5];
        int i;
        for (i = 0; i < 5; i++)
            l_63[i] = 0x7725EFF8L;
        if ((safe_mul_func_uint16_t_u_u(((safe_mod_func_uint32_t_u_u(1UL, l_49)) ^ (-1L)), g_22[5][1])))
        { /* block id: 15 */
            l_63[0] = (func_50((((safe_lshift_func_int16_t_s_s((safe_add_func_int16_t_s_s(0x109DL, p_38)), 8)) | g_22[5][1]) != g_22[1][1])) ^ p_35);
        }
        else
        { /* block id: 21 */
            l_66[1][2][0] = (safe_mod_func_uint32_t_u_u(0x717E5ED5L, 0xD99D06D0L));
            if (l_67[5])
                break;
        }
        g_72 = (safe_rshift_func_int16_t_s_u(((safe_sub_func_int16_t_s_s(p_35, g_59)) != l_63[0]), 13));
        for (p_35 = 0; (p_35 <= 3); p_35 += 1)
        { /* block id: 28 */
            int i;
            g_89 = func_73(l_63[(p_35 + 1)], g_72, p_38);
            return p_38;
        }
    }
    for (p_38 = 0; (p_38 <= 25); p_38 = safe_add_func_uint16_t_u_u(p_38, 4))
    { /* block id: 45 */
        int16_t l_94 = 0L;
        if (((safe_mod_func_int32_t_s_s(l_94, g_62)) , 1L))
        { /* block id: 46 */
            return l_94;
        }
        else
        { /* block id: 48 */
            return p_37;
        }
    }
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_59
 * writes: g_59 g_62
 */
static const int64_t  func_50(uint64_t  p_51)
{ /* block id: 16 */
    int8_t l_56 = (-1L);
    int32_t l_57 = 0x2B60D90CL;
    int32_t l_58 = 0x211ABD84L;
    g_59++;
    g_62 = 0L;
    return p_51;
}


/* ------------------------------------------ */
/* 
 * reads : g_62 g_72 g_22 g_59
 * writes:
 */
static int32_t  func_73(int32_t  p_74, int16_t  p_75, uint64_t  p_76)
{ /* block id: 29 */
    int64_t l_79 = 3L;
    int32_t l_80 = (-1L);
    int32_t l_84[8][2] = {{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL},{0xD282E35AL,0xD282E35AL}};
    int i, j;
    l_79 ^= ((safe_mul_func_uint8_t_u_u(g_62, g_72)) != g_22[5][1]);
    if (g_72)
        goto lbl_81;
lbl_81:
    l_80 = (((((p_76 < (-6L)) , p_76) ^ 0xD8B1B829F48D0B90LL) , 0xD3L) != (-1L));
    if ((safe_sub_func_int8_t_s_s((l_84[2][0] >= g_59), l_80)))
    { /* block id: 33 */
        int64_t l_87 = 0xD53B930988C8CF6ELL;
        l_87 = ((safe_div_func_uint16_t_u_u((g_72 , g_72), l_79)) & g_22[5][1]);
    }
    else
    { /* block id: 35 */
        uint16_t l_88[8][6] = {{0UL,0x82C1L,0x3B26L,0xD6DAL,0x82C1L,4UL},{65526UL,4UL,0x3B26L,0UL,0xC121L,0xC121L},{65535UL,4UL,4UL,65535UL,0x82C1L,0xA93DL},{65535UL,0x82C1L,0xA93DL,0UL,4UL,0xA93DL},{65526UL,0xC121L,4UL,0xD6DAL,4UL,0xC121L},{0UL,0x82C1L,0x3B26L,0xD6DAL,0x82C1L,4UL},{65526UL,4UL,0x3B26L,0UL,0xC121L,0xC121L},{65535UL,4UL,4UL,65535UL,0x82C1L,0xA93DL}};
        int i, j;
        l_88[1][3] &= (l_80 == 3L);
    }
    return g_72;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_22[i][j], "g_22[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_117[i], "g_117[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_134[i], "g_134[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 39
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 17
breakdown:
   depth: 1, occurrence: 47
   depth: 2, occurrence: 9
   depth: 3, occurrence: 7
   depth: 4, occurrence: 6
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 17, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 97
XXX times a non-volatile is write: 30
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 11
XXX percentage of non-volatile access: 97.7

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 52
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 15
   depth: 2, occurrence: 18

XXX percentage a fresh-made variable is used: 32.8
XXX percentage an existing variable is used: 67.2
********************* end of statistics **********************/

