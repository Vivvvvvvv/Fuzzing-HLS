/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11917854155638009553
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_2[5] = {18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL,18446744073709551608UL};
static int32_t g_3 = 4L;
static int64_t g_37[6] = {0x18394D2570D97802LL,0L,0L,0x18394D2570D97802LL,0L,0L};
static int8_t g_42 = 0x84L;
static uint16_t g_43[4] = {0x0E88L,0x0E88L,0x0E88L,0x0E88L};
static uint64_t g_46 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_9(int32_t  p_10, int32_t  p_11, uint8_t  p_12, int8_t  p_13);
static uint32_t  func_14(const int64_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_37 g_42 g_46
 * writes: g_3 g_37 g_42 g_43 g_46
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_8 = 0xB66BAFCBL;
    int64_t l_24 = 0x72B90F9986E3E45BLL;
    for (g_3 = 3; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        int i;
        l_8 &= (safe_add_func_uint64_t_u_u((safe_div_func_int8_t_s_s(6L, g_2[g_3])), 0xA1220985A9576C3ALL));
        g_37[5] = func_9((func_14((safe_mod_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_add_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s(g_2[0], g_2[4])), l_24)) == 1L), 5)), l_8))) , g_2[g_3]), g_2[3], g_3, g_3);
        for (l_24 = 1; (l_24 <= 4); l_24 += 1)
        { /* block id: 21 */
            g_42 ^= (((((safe_sub_func_int16_t_s_s((((safe_add_func_int32_t_s_s((-9L), g_2[g_3])) , g_2[3]) != g_37[1]), g_2[g_3])) < g_2[2]) > 0x8D2CL) , (-5L)) || g_2[4]);
            g_43[3] = (g_2[0] <= g_3);
            g_46 |= (safe_div_func_uint32_t_u_u((g_2[g_3] <= 8UL), g_2[4]));
        }
    }
    return l_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int32_t  func_9(int32_t  p_10, int32_t  p_11, uint8_t  p_12, int8_t  p_13)
{ /* block id: 9 */
    uint32_t l_36 = 0x221494FBL;
    for (p_13 = 26; (p_13 == 1); p_13 = safe_sub_func_int16_t_s_s(p_13, 2))
    { /* block id: 12 */
        uint16_t l_29 = 65526UL;
        int32_t l_30 = 0x5CBF7935L;
        p_11 = 0x6A5B5CF0L;
        l_30 = ((g_2[4] , l_29) < l_29);
        l_30 = (safe_rshift_func_int8_t_s_s((((safe_unary_minus_func_int32_t_s((safe_mod_func_int32_t_s_s(0xECC33BABL, l_30)))) != p_12) & 0x2563L), g_2[1]));
    }
    return l_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static uint32_t  func_14(const int64_t  p_15)
{ /* block id: 5 */
    int32_t l_25[10] = {(-8L),0x4361A6B7L,(-8L),0x4361A6B7L,(-8L),0x4361A6B7L,(-8L),0x4361A6B7L,(-8L),0x4361A6B7L};
    int i;
    l_25[5] = g_2[2];
    l_25[5] ^= (~p_15);
    return l_25[6];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_37[i], "g_37[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_43[i], "g_43[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_46, "g_46", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 4
   depth: 3, occurrence: 3
   depth: 5, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 33
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 6
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 25.6
XXX percentage an existing variable is used: 74.4
********************* end of statistics **********************/

