/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10066212543838037702
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_3 = 0xFD49L;
static int16_t g_17 = 0x592CL;
static volatile uint32_t g_18 = 0xAA53F0D3L;/* VOLATILE GLOBAL g_18 */
static uint8_t g_22 = 251UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_8(uint32_t  p_9, uint16_t  p_10, int32_t  p_11, int64_t  p_12, uint64_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_18 g_22 g_17
 * writes: g_3 g_17 g_18 g_22
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2 = 0x94801897A4A12B57LL;
    int32_t l_16 = (-8L);
    int32_t l_21[1];
    int i;
    for (i = 0; i < 1; i++)
        l_21[i] = 0xC36FE5ABL;
    g_3 |= l_2;
    g_17 = (safe_div_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(func_8(((safe_add_func_uint8_t_u_u(g_3, 248UL)) , g_3), g_3, l_2, l_16, g_3), 0x9C71L)), 18446744073709551615UL));
    ++g_18;
    ++g_22;
    return g_17;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_8(uint32_t  p_9, uint16_t  p_10, int32_t  p_11, int64_t  p_12, uint64_t  p_13)
{ /* block id: 2 */
    p_11 = p_11;
    return p_13;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 11
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 93.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 7

XXX percentage a fresh-made variable is used: 41.2
XXX percentage an existing variable is used: 58.8
********************* end of statistics **********************/

