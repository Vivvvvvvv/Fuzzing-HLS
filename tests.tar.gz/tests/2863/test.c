/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11963997560539389638
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x897A4A12L;/* VOLATILE GLOBAL g_2 */
static int64_t g_14 = 0x33E34B64B5C6F8B8LL;
static int16_t g_19 = (-7L);


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint16_t  func_7(int32_t  p_8, int32_t  p_9, int16_t  p_10, uint8_t  p_11, int8_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_14
 * writes: g_2 g_19
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    const int8_t l_13[10] = {0x81L,0x81L,0x81L,0x81L,0x81L,0x81L,0x81L,0x81L,0x81L,0x81L};
    int32_t l_15 = 0xFBEFA5F9L;
    int i;
    g_2 &= 0x7E2799ACL;
    g_19 = ((((safe_add_func_uint16_t_u_u(func_7(((l_13[6] && l_13[1]) , g_2), g_14, l_15, l_13[6], l_13[7]), l_13[7])) || 0L) ^ 4UL) >= g_14);
    return l_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes:
 */
static uint16_t  func_7(int32_t  p_8, int32_t  p_9, int16_t  p_10, uint8_t  p_11, int8_t  p_12)
{ /* block id: 2 */
    int32_t l_16 = 1L;
    int32_t l_18[4] = {0x050678E0L,0x050678E0L,0x050678E0L,0x050678E0L};
    int i;
    l_16 = (g_14 && g_14);
    l_18[3] = ((!0xC5B641B4L) > 246UL);
    for (l_16 = 0; (l_16 <= 3); l_16 += 1)
    { /* block id: 7 */
        int i;
        return l_18[l_16];
    }
    return p_9;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 3
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 14
XXX times a non-volatile is write: 4
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 90

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 41.2
XXX percentage an existing variable is used: 58.8
********************* end of statistics **********************/

