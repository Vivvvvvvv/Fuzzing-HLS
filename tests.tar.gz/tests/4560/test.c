/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15238677664063404769
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint8_t  f0;
   uint16_t  f1;
   const uint32_t  f2;
   const volatile uint32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static uint64_t g_4 = 0UL;
static uint8_t g_5 = 0UL;
static uint32_t g_40 = 0UL;
static int16_t g_42 = (-4L);
static uint16_t g_52 = 0x2742L;
static struct S0 g_57 = {0x61L,0xE7D5L,0x2630673EL,0xFD7F9B64L};/* VOLATILE GLOBAL g_57 */
static uint8_t g_58 = 0xF0L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_6(uint32_t  p_7, const uint64_t  p_8, int16_t  p_9, int64_t  p_10);
static int32_t  func_13(uint64_t  p_14, uint32_t  p_15, uint64_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_40 g_42 g_57 g_58
 * writes: g_5 g_40 g_42 g_52 g_58
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_11 = 65534UL;
    g_5 ^= (safe_lshift_func_int16_t_s_u(0x69F4L, g_4));
    g_52 = func_6((((((0xB1C03809L && g_5) , l_11) | g_5) | g_5) >= 0UL), g_4, g_5, l_11);
    g_58 ^= ((safe_mod_func_int64_t_s_s(((safe_rshift_func_int16_t_s_s(((g_57 , g_5) && l_11), l_11)) <= l_11), g_57.f0)) | 247UL);
    return g_57.f2;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_40 g_42
 * writes: g_40 g_42
 */
static int32_t  func_6(uint32_t  p_7, const uint64_t  p_8, int16_t  p_9, int64_t  p_10)
{ /* block id: 2 */
    int32_t l_12[1];
    uint32_t l_51 = 18446744073709551615UL;
    int i;
    for (i = 0; i < 1; i++)
        l_12[i] = 0x900FDB69L;
    for (p_9 = 0; (p_9 <= 0); p_9 += 1)
    { /* block id: 5 */
        int i;
        l_12[p_9] = func_13((safe_rshift_func_int8_t_s_u(l_12[p_9], 2)), p_7, l_12[0]);
        if (l_12[p_9])
            break;
    }
    l_12[0] = (safe_mul_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(l_12[0], g_4)), p_10)), p_7));
    l_12[0] = (((safe_sub_func_int8_t_s_s(((((((2UL || 0x91L) < p_7) , 7L) , 0x5C3B3635L) ^ p_10) == 6UL), g_4)) == 0x2029L) && l_12[0]);
    l_51 ^= (g_4 <= 0xD79CL);
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_40 g_42
 * writes: g_40 g_42
 */
static int32_t  func_13(uint64_t  p_14, uint32_t  p_15, uint64_t  p_16)
{ /* block id: 6 */
    uint16_t l_37 = 65531UL;
    int16_t l_38 = 0x1C73L;
    int32_t l_39 = 0xF8859284L;
    l_39 = ((safe_div_func_uint8_t_u_u((!((safe_add_func_int32_t_s_s((safe_div_func_uint32_t_u_u(((((safe_mul_func_int8_t_s_s(((safe_div_func_int32_t_s_s(((safe_add_func_int32_t_s_s((((safe_rshift_func_int8_t_s_u((safe_add_func_int32_t_s_s((+(g_4 || l_37)), l_37)), 5)) & g_4) & 0x818264D9L), l_37)) && 8UL), l_37)) , (-3L)), 0xBBL)) , p_16) | l_37) && g_5), l_38)), p_15)) == 0x5ADFL)), 6UL)) >= p_15);
    g_40 = l_37;
    if (g_5)
        goto lbl_41;
lbl_41:
    l_39 = p_15;
    g_42 |= ((((p_14 != g_4) & l_37) <= 1UL) ^ g_40);
    return l_37;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_57.f0, "g_57.f0", print_hash_value);
    transparent_crc(g_57.f1, "g_57.f1", print_hash_value);
    transparent_crc(g_57.f2, "g_57.f2", print_hash_value);
    transparent_crc(g_57.f3, "g_57.f3", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 2
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 49
XXX times a non-volatile is write: 12
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 21.1
XXX percentage an existing variable is used: 78.9
********************* end of statistics **********************/

