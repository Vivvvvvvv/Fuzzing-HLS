/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17423541173972546414
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int32_t  f0;
   const int32_t  f1;
   uint8_t  f2;
   const uint64_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static uint8_t g_15 = 0x09L;
static struct S0 g_16 = {0xABC24891L,0x23F126C7L,1UL,1UL};
static int32_t g_27 = 2L;
static uint32_t g_30 = 0x66B3883FL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint8_t  func_10(uint32_t  p_11, struct S0  p_12);
static int8_t  func_21(int32_t  p_22, uint32_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_27
 * writes: g_15 g_27 g_30
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2 = 0x05DAE5A60D00585BLL;
    int32_t l_3[3];
    int64_t l_28[3];
    uint16_t l_29 = 0xEC02L;
    int i;
    for (i = 0; i < 3; i++)
        l_3[i] = 6L;
    for (i = 0; i < 3; i++)
        l_28[i] = 0xB0D69B45C761B8CELL;
    l_3[0] = l_2;
    g_30 = ((((safe_mod_func_uint64_t_u_u((((safe_div_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(func_10((safe_mul_func_int8_t_s_s(((l_2 , l_3[1]) == g_15), g_15)), g_16), g_16.f2)), g_16.f2)) , g_16.f2) ^ g_16.f0), l_28[2])) <= (-10L)) , l_2) && l_29);
    return l_3[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_16.f1 g_16.f2 g_27
 * writes: g_15 g_27
 */
static uint8_t  func_10(uint32_t  p_11, struct S0  p_12)
{ /* block id: 2 */
    uint32_t l_19 = 0x8C7FFFAAL;
    int32_t l_20[4] = {0xF32B7B88L,0xF32B7B88L,0xF32B7B88L,0xF32B7B88L};
    int i;
    l_20[2] = (safe_add_func_uint64_t_u_u(l_19, p_12.f0));
    l_20[2] = p_11;
    g_27 |= ((func_21(l_19, p_12.f2) , g_16.f2) < p_12.f1);
    return p_12.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_16.f1
 * writes: g_15
 */
static int8_t  func_21(int32_t  p_22, uint32_t  p_23)
{ /* block id: 5 */
    uint64_t l_26 = 18446744073709551611UL;
    for (g_15 = 0; (g_15 <= 17); ++g_15)
    { /* block id: 8 */
        return g_16.f1;
    }
    l_26 = p_23;
    return p_22;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16.f0, "g_16.f0", print_hash_value);
    transparent_crc(g_16.f1, "g_16.f1", print_hash_value);
    transparent_crc(g_16.f2, "g_16.f2", print_hash_value);
    transparent_crc(g_16.f3, "g_16.f3", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 2
   depth: 5, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 7
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 34.4
XXX percentage an existing variable is used: 65.6
********************* end of statistics **********************/

