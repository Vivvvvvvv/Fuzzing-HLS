/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2935669695468172908
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-6L);
static volatile int8_t g_8[2] = {(-1L),(-1L)};
static volatile int32_t g_9 = (-3L);/* VOLATILE GLOBAL g_9 */
static uint32_t g_11 = 0UL;
static volatile uint16_t g_35 = 0x91F1L;/* VOLATILE GLOBAL g_35 */
static int32_t g_54 = 0xCF63547AL;
static volatile int8_t g_55 = (-2L);/* VOLATILE GLOBAL g_55 */
static int8_t g_56 = 0xE7L;
static volatile uint64_t g_57 = 1UL;/* VOLATILE GLOBAL g_57 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_14(uint32_t  p_15, int32_t  p_16, uint64_t  p_17, uint16_t  p_18);
static int32_t  func_21(uint16_t  p_22, uint32_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_2 g_8 g_35 g_57
 * writes: g_11 g_35 g_2 g_57
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_3 = 1L;
    int32_t l_4 = 7L;
    int32_t l_5 = 3L;
    int32_t l_6 = 0x099CFE04L;
    int32_t l_7 = 0x80849F84L;
    int32_t l_10[8] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
    int i;
    ++g_11;
    l_7 |= (l_10[7] , l_10[3]);
    l_5 = func_14((safe_add_func_uint8_t_u_u((((((0UL != g_11) , l_3) >= g_2) ^ l_10[3]) != 5UL), g_11)), g_11, g_8[0], l_10[3]);
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_11 g_35 g_57
 * writes: g_35 g_2 g_57
 */
static int32_t  func_14(uint32_t  p_15, int32_t  p_16, uint64_t  p_17, uint16_t  p_18)
{ /* block id: 3 */
    uint16_t l_31 = 0xF486L;
    int32_t l_46 = 0xCF455DBFL;
    int32_t l_51 = (-1L);
    int32_t l_52 = 1L;
    int32_t l_53[10] = {(-1L),5L,0L,0L,5L,(-1L),5L,0L,0L,5L};
    int i;
    l_46 = func_21(((safe_mod_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u((safe_div_func_int8_t_s_s(((~p_15) < l_31), p_15)), 6)) == g_2), g_11)) || 0x0B63L), p_16);
    g_2 = (safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u(l_51, l_31)), 65527UL));
    if (g_2)
        goto lbl_60;
lbl_60:
    g_57++;
    l_53[8] = ((safe_mod_func_uint16_t_u_u((l_51 ^ p_18), g_11)) || l_52);
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_11
 * writes: g_35
 */
static int32_t  func_21(uint16_t  p_22, uint32_t  p_23)
{ /* block id: 4 */
    int64_t l_40[8];
    int i;
    for (i = 0; i < 8; i++)
        l_40[i] = 1L;
    for (p_22 = 0; (p_22 > 4); p_22++)
    { /* block id: 7 */
        int32_t l_34[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
        int32_t l_38 = 0xEFCECB2EL;
        int32_t l_39 = (-3L);
        uint32_t l_41 = 0UL;
        int i;
        ++g_35;
        l_41++;
        for (l_39 = 0; (l_39 == 27); l_39++)
        { /* block id: 12 */
            if (g_11)
                break;
        }
        for (l_39 = 2; (l_39 <= 8); l_39 += 1)
        { /* block id: 17 */
            int i;
            if (l_34[l_39])
                break;
        }
    }
    return g_35;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 25
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 28
XXX times a non-volatile is write: 10
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 26
XXX percentage of non-volatile access: 90.5

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 18
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 4
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 41
XXX percentage an existing variable is used: 59
********************* end of statistics **********************/

