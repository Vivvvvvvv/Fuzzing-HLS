/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8217790087457358535
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_4 = 0xD8E6E838L;
static int16_t g_14 = 0x0E1BL;
static int16_t g_42 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_16(uint32_t  p_17, int64_t  p_18, int32_t  p_19, int32_t  p_20, int8_t  p_21);
static int32_t  func_23(uint64_t  p_24, uint16_t  p_25, uint8_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_14
 * writes: g_4 g_14 g_42
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2 = 0L;
    int64_t l_3[5] = {6L,6L,6L,6L,6L};
    int i;
lbl_15:
    --g_4;
    for (l_2 = (-26); (l_2 == 5); ++l_2)
    { /* block id: 4 */
        uint32_t l_22 = 18446744073709551610UL;
        int32_t l_39[1];
        int i;
        for (i = 0; i < 1; i++)
            l_39[i] = 0x7B6A69EEL;
        for (g_4 = 0; (g_4 != 45); g_4++)
        { /* block id: 7 */
            uint8_t l_13 = 248UL;
            if (g_4)
                break;
            g_14 = (safe_sub_func_int32_t_s_s((l_13 != 9L), l_13));
            if (l_13)
                goto lbl_15;
            l_39[0] ^= func_16(g_4, g_14, g_4, l_22, g_4);
        }
        g_42 = (safe_add_func_int8_t_s_s((((g_4 , l_3[4]) , g_14) | l_3[4]), g_14));
    }
    return l_3[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_14
 * writes:
 */
static int32_t  func_16(uint32_t  p_17, int64_t  p_18, int32_t  p_19, int32_t  p_20, int8_t  p_21)
{ /* block id: 11 */
    int8_t l_27 = 0L;
    int32_t l_38[8] = {0xAD5B481DL,0xAD5B481DL,0xAD5B481DL,0xAD5B481DL,0xAD5B481DL,0xAD5B481DL,0xAD5B481DL,0xAD5B481DL};
    int i;
    p_20 = (func_23(g_4, g_14, l_27) && p_19);
    p_20 ^= (safe_mul_func_int16_t_s_s((safe_mod_func_int64_t_s_s((safe_add_func_uint32_t_u_u(((((safe_sub_func_int32_t_s_s((-5L), g_4)) | l_27) || l_27) >= l_27), g_4)), l_27)), l_27));
    l_38[3] = ((((+1L) == p_18) , (-1L)) < p_17);
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_23(uint64_t  p_24, uint16_t  p_25, uint8_t  p_26)
{ /* block id: 12 */
    int32_t l_28 = 7L;
    return l_28;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 31
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 28.9
XXX percentage an existing variable is used: 71.1
********************* end of statistics **********************/

