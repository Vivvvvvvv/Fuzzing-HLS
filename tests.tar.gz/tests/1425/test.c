/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6380513879379009639
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_11 = 0x1BAB5934L;
static int32_t g_12 = 0xA43B2B74L;
static int16_t g_13 = (-9L);
static volatile uint32_t g_19[6] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static uint64_t g_26 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static const uint64_t  func_1(void);
static uint64_t  func_4(uint16_t  p_5, int32_t  p_6, uint16_t  p_7);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_19 g_26 g_13
 * writes: g_19 g_26 g_12
 */
static const uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_10 = 4L;
    int32_t l_25[10];
    int i;
    for (i = 0; i < 10; i++)
        l_25[i] = 1L;
    l_25[7] |= (safe_sub_func_uint64_t_u_u(func_4(((safe_sub_func_uint8_t_u_u(((l_10 , l_10) | g_11), l_10)) , g_11), l_10, l_10), 0xB748ABB75DA2CA33LL));
    g_26--;
    g_12 = (((l_10 , g_13) ^ l_25[7]) ^ l_10);
    return l_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes: g_19
 */
static uint64_t  func_4(uint16_t  p_5, int32_t  p_6, uint16_t  p_7)
{ /* block id: 1 */
    uint32_t l_14 = 0x880E033CL;
    int32_t l_17 = 0xB0BF2465L;
    int32_t l_18 = 0x21E0BEC0L;
    l_14--;
    p_6 = 0x71013923L;
    if (l_14)
        goto lbl_22;
lbl_22:
    g_19[0]++;
    l_17 = (safe_lshift_func_int16_t_s_s((p_7 > 255UL), g_19[5]));
    return g_19[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_26, "g_26", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 14
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 6
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 86.4

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 10

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

