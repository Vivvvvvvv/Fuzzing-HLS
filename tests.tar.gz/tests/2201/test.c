/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10078182408564830305
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_2 = 0x8C6AL;/* VOLATILE GLOBAL g_2 */
static uint32_t g_31[10] = {0x0FAEB382L,0x84257392L,0x40826F39L,0x40826F39L,0x84257392L,0x0FAEB382L,0x84257392L,0x40826F39L,0x40826F39L,0x84257392L};
static uint32_t g_41 = 1UL;
static uint32_t g_42 = 0x70B1B9B9L;
static uint32_t g_47 = 9UL;
static int32_t g_52 = 0x99275A80L;
static uint64_t g_53 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint16_t  func_15(uint16_t  p_16);
static int16_t  func_21(uint64_t  p_22, uint32_t  p_23, int32_t  p_24, uint64_t  p_25, const int64_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_31 g_42 g_47 g_53 g_52
 * writes: g_2 g_41 g_42 g_47 g_52 g_31
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_5 = 0x16DF251D69F4288ALL;
    int32_t l_6 = (-5L);
    int32_t l_7 = 0x36CCB036L;
    int32_t l_8 = 1L;
    uint8_t l_9[8] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
    int i;
    --g_2;
    ++l_9[3];
    l_7 = ((~(safe_mul_func_int8_t_s_s((func_15(((g_2 || g_2) , g_2)) != l_5), l_6))) ^ g_53);
    g_52 ^= ((safe_mul_func_uint8_t_u_u(0xB2L, l_9[3])) != l_9[3]);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_31 g_42 g_47
 * writes: g_41 g_42 g_47 g_52 g_2 g_31
 */
static uint16_t  func_15(uint16_t  p_16)
{ /* block id: 3 */
    const int32_t l_32 = 0xB47E0FA1L;
    if (((safe_sub_func_int16_t_s_s(((safe_div_func_int16_t_s_s(func_21((safe_add_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u(65535UL, 1L)) & g_2), p_16)), g_31[5], p_16, g_31[8], l_32), l_32)) == g_31[4]), (-3L))) && l_32))
    { /* block id: 9 */
        int32_t l_45 = (-1L);
        int32_t l_46[4];
        int i;
        for (i = 0; i < 4; i++)
            l_46[i] = 0x87B25476L;
        --g_47;
        g_52 = (safe_mul_func_uint16_t_u_u((0xE34D1CD0L | l_46[2]), l_32));
        l_46[2] |= 0x481F04FEL;
    }
    else
    { /* block id: 13 */
        for (g_2 = 0; g_2 < 10; g_2 += 1)
        {
            g_31[g_2] = 18446744073709551612UL;
        }
    }
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_42
 * writes: g_41 g_42
 */
static int16_t  func_21(uint64_t  p_22, uint32_t  p_23, int32_t  p_24, uint64_t  p_25, const int64_t  p_26)
{ /* block id: 4 */
    int32_t l_34[10] = {0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L,0x437F1BD5L};
    int i;
    p_24 = (((((!((0xBA00L & l_34[0]) || l_34[2])) , p_24) > g_2) ^ 0xB3L) ^ 0x9DFEEE83ADEB9459LL);
    g_41 = ((safe_mod_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u((safe_sub_func_uint16_t_u_u((p_25 == 0x8592L), 0x74BFL)), 2)), 4294967293UL)) , 0x5156BE82L);
    ++g_42;
    return l_34[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_31[i], "g_31[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 19
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 9
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 12
XXX percentage of non-volatile access: 81.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 35.6
XXX percentage an existing variable is used: 64.4
********************* end of statistics **********************/

