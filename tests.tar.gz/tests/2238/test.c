/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3910998988902064015
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_11 = 0x25L;
static volatile int8_t g_19[10] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
static volatile int32_t g_20 = 7L;/* VOLATILE GLOBAL g_20 */
static uint8_t g_21 = 254UL;
static volatile int32_t g_25[3] = {0x7790660DL,0x7790660DL,0x7790660DL};
static volatile uint16_t g_74 = 1UL;/* VOLATILE GLOBAL g_74 */
static uint8_t g_86 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint8_t  func_4(uint16_t  p_5, int32_t  p_6);
static int16_t  func_78(uint8_t  p_79, int16_t  p_80, int32_t  p_81);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_21 g_11 g_25 g_20 g_74 g_86
 * writes: g_11 g_21 g_25 g_74
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_7 = 1L;
    int16_t l_55 = 0x1162L;
    int32_t l_66 = 0L;
    int32_t l_70 = 0x6C3A74F5L;
    int32_t l_73 = (-7L);
    int16_t l_84 = (-4L);
    uint32_t l_85 = 1UL;
    g_25[1] = (safe_div_func_uint16_t_u_u((((func_4(l_7, l_7) != (-1L)) >= g_25[0]) , 0x84BAL), 0x6799L));
    if ((safe_sub_func_int64_t_s_s(g_25[0], g_11)))
    { /* block id: 14 */
        uint32_t l_56 = 0x03F86127L;
        int32_t l_57 = 0x70C68704L;
        uint8_t l_58 = 0x04L;
        if ((safe_mod_func_uint64_t_u_u((func_4((safe_lshift_func_uint16_t_u_u((((safe_lshift_func_uint16_t_u_u((l_7 , 5UL), 6)) , l_7) , l_55), 12)), l_56) < l_56), l_55)))
        { /* block id: 15 */
            int32_t l_61 = 0x5EA8900EL;
            --l_58;
            if (l_56)
                goto lbl_62;
lbl_62:
            l_61 = l_56;
            return l_7;
        }
        else
        { /* block id: 20 */
            l_7 = (safe_mul_func_uint8_t_u_u((+g_25[1]), g_21));
            return g_20;
        }
    }
    else
    { /* block id: 24 */
        int16_t l_67 = 0x666CL;
        int32_t l_68 = 0L;
        int32_t l_69 = 0x3957630DL;
        int32_t l_71 = (-8L);
        int32_t l_72[7] = {0x892EBBAEL,0x892EBBAEL,0L,0x892EBBAEL,0x892EBBAEL,0L,0x892EBBAEL};
        int i;
        --g_74;
        l_72[0] = (~g_20);
        g_25[0] = (func_78(((((safe_mul_func_int16_t_s_s(g_21, 0x9B06L)) , l_84) , l_7) , g_25[0]), l_85, g_86) || g_21);
    }
    l_70 = g_20;
    return l_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_11
 * writes: g_11 g_21
 */
static uint8_t  func_4(uint16_t  p_5, int32_t  p_6)
{ /* block id: 1 */
    uint64_t l_8 = 0xCC25FA5FEF9D7865LL;
    int32_t l_9 = 0L;
    uint32_t l_10[5] = {1UL,1UL,1UL,1UL,1UL};
    uint64_t l_12 = 18446744073709551610UL;
    int32_t l_16 = 1L;
    int32_t l_17 = 0L;
    int32_t l_18 = 0x49A2F381L;
    int32_t l_24 = (-3L);
    int32_t l_26 = (-9L);
    int32_t l_27 = 0x1B16EB2DL;
    int32_t l_29 = 0xE6D54EC7L;
    int32_t l_33 = 0L;
    int32_t l_34[7];
    int16_t l_36 = 0xB7D8L;
    uint8_t l_40 = 247UL;
    int32_t l_43[7] = {1L,1L,1L,1L,1L,1L,1L};
    uint16_t l_44 = 0x4242L;
    int i;
    for (i = 0; i < 7; i++)
        l_34[i] = 0xA81D5F49L;
    l_9 = l_8;
    for (l_8 = 0; (l_8 <= 4); l_8 += 1)
    { /* block id: 5 */
        int32_t l_13 = 0x6695998AL;
        int32_t l_14 = 0x2AF0488FL;
        int32_t l_15 = 1L;
        int32_t l_28 = 0L;
        int32_t l_30 = 0x74307976L;
        int8_t l_31 = 0xE6L;
        int32_t l_32 = 0xAD7BA966L;
        int32_t l_35[7] = {0x574417F9L,0x574417F9L,0x574417F9L,0x574417F9L,0x574417F9L,0x574417F9L,0x574417F9L};
        int64_t l_37 = 0xE868E0133D4965DALL;
        int32_t l_38 = 0xD602FF7AL;
        int64_t l_39 = 0x1AC573C098B3027FLL;
        int i;
        g_11 = l_10[l_8];
        l_13 &= l_12;
        g_21--;
        l_40++;
    }
    --l_44;
    return g_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_11 g_21 g_20 g_86 g_74
 * writes: g_25
 */
static int16_t  func_78(uint8_t  p_79, int16_t  p_80, int32_t  p_81)
{ /* block id: 27 */
    int8_t l_92[5];
    uint64_t l_93 = 0x82E3256063715E5ELL;
    int32_t l_94 = 1L;
    int32_t l_95 = 0x28C89D87L;
    int32_t l_96 = (-2L);
    int32_t l_100 = 1L;
    int32_t l_101 = 0xE7A02F56L;
    int32_t l_104 = 4L;
    uint32_t l_105 = 1UL;
    int32_t l_142 = 0L;
    int32_t l_143 = (-5L);
    int32_t l_144[3];
    uint32_t l_145 = 9UL;
    int i;
    for (i = 0; i < 5; i++)
        l_92[i] = 0xCEL;
    for (i = 0; i < 3; i++)
        l_144[i] = 0xB4EEC52DL;
    if ((safe_sub_func_int32_t_s_s(((!(((safe_mod_func_uint64_t_u_u((0xA2L <= g_25[0]), p_79)) | g_11) <= l_92[1])) || l_92[1]), p_80)))
    { /* block id: 28 */
        int8_t l_97 = 9L;
        int32_t l_98 = 0x6B90ED9AL;
        int32_t l_99 = 0xCE5CD9F5L;
        int32_t l_102 = 0L;
        int32_t l_103[9] = {(-1L),0xF8D1E453L,(-1L),(-1L),0xF8D1E453L,(-1L),(-1L),(-1L),0x6D1E2CAAL};
        int i;
        l_93 = p_81;
        --l_105;
        for (l_101 = 22; (l_101 > (-6)); l_101 = safe_sub_func_uint16_t_u_u(l_101, 1))
        { /* block id: 33 */
            if (l_103[6])
                break;
            p_81 &= (-2L);
            l_95 |= ((g_21 & p_79) > p_81);
        }
    }
    else
    { /* block id: 38 */
        uint8_t l_122[6];
        int64_t l_127 = 0x7021987340CD4C67LL;
        int32_t l_134 = 1L;
        int32_t l_135 = 0x95206BB7L;
        int32_t l_136 = 0xC15363C4L;
        int32_t l_137 = (-6L);
        int32_t l_138 = 6L;
        int32_t l_139 = 0xE67F6E1AL;
        int32_t l_140 = 1L;
        int32_t l_141[5] = {1L,1L,1L,1L,1L};
        int i;
        for (i = 0; i < 6; i++)
            l_122[i] = 8UL;
        g_25[0] = (safe_lshift_func_uint8_t_u_s((safe_mod_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_s((1L == p_81), 2)), g_25[0])), 2));
        if (l_105)
            goto lbl_123;
        if ((safe_div_func_int32_t_s_s((g_20 != p_80), g_11)))
        { /* block id: 40 */
            l_122[5] = (safe_mod_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(((p_80 < p_80) & g_25[0]), 0xA8907691L)), 0x511D4011L));
lbl_123:
            p_81 &= 0x080F123DL;
            return l_101;
        }
        else
        { /* block id: 45 */
            uint32_t l_126 = 0xC0B5BC34L;
            p_81 = (((safe_lshift_func_int16_t_s_u(7L, l_122[4])) != 0x54L) , l_126);
            l_127 = ((l_122[1] , g_20) | g_86);
            g_25[0] = (safe_div_func_int16_t_s_s(((((((safe_mod_func_int32_t_s_s((safe_lshift_func_int8_t_s_u(l_126, l_126)), p_80)) , 0x94E8F9E78BCBB588LL) == p_79) > g_25[1]) , l_92[1]) ^ p_80), p_80));
        }
        l_145--;
        g_25[0] = (((l_140 || g_74) | 18446744073709551615UL) ^ p_81);
    }
    return p_80;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 79
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 51
   depth: 2, occurrence: 4
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 7, occurrence: 2
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 55
XXX times a non-volatile is write: 22
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 96
XXX percentage of non-volatile access: 79.4

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 16
   depth: 2, occurrence: 15

XXX percentage a fresh-made variable is used: 27.5
XXX percentage an existing variable is used: 72.5
********************* end of statistics **********************/

