/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6984922221275450243
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_4 = 1L;
static int64_t g_17 = 1L;
static uint32_t g_19 = 0x549EC71CL;
static volatile int8_t g_25 = 0xF9L;/* VOLATILE GLOBAL g_25 */
static volatile int8_t g_28 = 0x84L;/* VOLATILE GLOBAL g_28 */
static volatile int32_t g_29 = 0xB656D4C0L;/* VOLATILE GLOBAL g_29 */
static int8_t g_30 = 0x30L;
static volatile int64_t g_31[5] = {0xBD5D518144871830LL,0xBD5D518144871830LL,0xBD5D518144871830LL,0xBD5D518144871830LL,0xBD5D518144871830LL};
static volatile int16_t g_32[6] = {0x72A6L,0x72A6L,0x72A6L,0x72A6L,0x72A6L,0x72A6L};
static volatile uint32_t g_33[6] = {0x902820A3L,1UL,1UL,0x902820A3L,1UL,1UL};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint64_t  func_2(int64_t  p_3);
static int8_t  func_5(int32_t  p_6, const uint32_t  p_7, const int32_t  p_8);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_17 g_19 g_33 g_31
 * writes: g_17 g_19 g_4 g_33
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    const int64_t l_36 = 1L;
    int32_t l_37[7] = {0xC8B69768L,1L,1L,0xC8B69768L,1L,1L,0xC8B69768L};
    int i;
    l_37[3] = (func_2(g_4) && l_36);
    return g_31[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_17 g_19 g_33
 * writes: g_17 g_19 g_4 g_33
 */
static uint64_t  func_2(int64_t  p_3)
{ /* block id: 1 */
    const uint16_t l_9 = 0UL;
    int32_t l_20[4] = {0x2294BB48L,0x2294BB48L,0x2294BB48L,0x2294BB48L};
    int32_t l_22 = 0x82B00025L;
    int32_t l_23 = 0L;
    int32_t l_24 = (-3L);
    int32_t l_26[8] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
    int64_t l_27[5] = {0xB51404FC4B664FB7LL,0xB51404FC4B664FB7LL,0xB51404FC4B664FB7LL,0xB51404FC4B664FB7LL,0xB51404FC4B664FB7LL};
    int i;
    g_19 |= ((func_5(p_3, l_9, p_3) != g_4) >= g_4);
    for (g_17 = 3; (g_17 >= 0); g_17 -= 1)
    { /* block id: 11 */
        uint8_t l_21 = 0x1BL;
        int i;
        g_4 |= ((((((-1L) || 0x07AF9CA3EAA3E8F0LL) , l_20[g_17]) > l_21) < 0x3CL) < p_3);
        return p_3;
    }
    g_33[3]--;
    return l_26[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_17
 * writes: g_17
 */
static int8_t  func_5(int32_t  p_6, const uint32_t  p_7, const int32_t  p_8)
{ /* block id: 2 */
    const uint16_t l_12 = 3UL;
    int8_t l_13[7];
    uint32_t l_14[8];
    int32_t l_18 = 0xBF68593FL;
    int i;
    for (i = 0; i < 7; i++)
        l_13[i] = 0xEEL;
    for (i = 0; i < 8; i++)
        l_14[i] = 0x7E71F09AL;
    l_13[6] = ((((safe_add_func_int8_t_s_s(g_4, l_12)) ^ p_7) , l_12) > 0x9BL);
    l_14[4]++;
    g_17 |= (g_4 ^ 4294967294UL);
    l_18 &= 0x6840EB44L;
    return p_8;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_31[i], "g_31[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_32[i], "g_32[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_33[i], "g_33[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 19
XXX times a non-volatile is write: 8
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 93.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 48.9
XXX percentage an existing variable is used: 51.1
********************* end of statistics **********************/

