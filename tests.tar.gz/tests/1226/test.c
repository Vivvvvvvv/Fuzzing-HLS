/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3965400405006423091
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x9FDF99FFL;
static volatile int32_t g_5 = (-1L);/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = 0xD7953644L;
static volatile int16_t g_45 = 3L;/* VOLATILE GLOBAL g_45 */
static volatile uint32_t g_47 = 0UL;/* VOLATILE GLOBAL g_47 */
static volatile uint16_t g_64 = 65532UL;/* VOLATILE GLOBAL g_64 */
static uint64_t g_101 = 9UL;
static volatile uint16_t g_111 = 1UL;/* VOLATILE GLOBAL g_111 */
static volatile uint8_t g_120 = 0x55L;/* VOLATILE GLOBAL g_120 */
static volatile int32_t g_158 = 0x9039BF07L;/* VOLATILE GLOBAL g_158 */
static const volatile uint32_t g_177 = 1UL;/* VOLATILE GLOBAL g_177 */
static int64_t g_182 = 0x4FAEA5775FD7C9B7LL;
static int16_t g_187 = 0x501FL;
static int32_t g_188 = 0x2C08DF40L;
static volatile uint8_t g_189 = 1UL;/* VOLATILE GLOBAL g_189 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_10(int32_t  p_11);
static uint16_t  func_12(uint16_t  p_13, int32_t  p_14, uint32_t  p_15, int32_t  p_16, uint8_t  p_17);
static int8_t  func_24(int32_t  p_25, uint64_t  p_26, uint64_t  p_27, int8_t  p_28, int32_t  p_29);
static int32_t  func_30(int32_t  p_31, uint32_t  p_32, uint32_t  p_33, uint8_t  p_34, uint64_t  p_35);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_5 g_47 g_64 g_45 g_101 g_111 g_120 g_158 g_177 g_189 g_182
 * writes: g_2 g_6 g_5 g_47 g_64 g_101 g_111 g_120 g_189 g_158
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_18 = (-1L);
    int32_t l_178 = (-1L);
    int32_t l_186 = 0x1C9E7018L;
    int32_t l_196 = (-2L);
    for (g_2 = 0; (g_2 == (-6)); g_2--)
    { /* block id: 3 */
        uint32_t l_19 = 4294967288UL;
        int32_t l_174 = (-3L);
        int32_t l_180 = (-1L);
        int32_t l_181 = 0x7CA80160L;
        int32_t l_183 = 0xBB608991L;
        int32_t l_184 = (-6L);
        int16_t l_185 = 0x63D8L;
        for (g_6 = 0; (g_6 <= 16); g_6++)
        { /* block id: 6 */
            uint16_t l_9 = 0x6507L;
            g_5 = ((g_6 | l_9) , g_6);
        }
        if (func_10((func_12((((((((1L > g_6) && l_18) < 1L) ^ g_2) , l_19) , g_6) || l_19), g_2, g_2, g_6, g_2) & g_2)))
        { /* block id: 107 */
            int16_t l_173[3][6][6] = {{{5L,(-5L),0x2598L,0x3022L,9L,0x2598L},{0x3022L,9L,0x2598L,0x8AF0L,(-10L),5L},{0x3022L,(-5L),0x8AF0L,0x3022L,(-10L),0x2598L},{5L,9L,0x8AF0L,0x8AF0L,9L,5L},{5L,(-5L),0x2598L,0x3022L,9L,0x2598L},{0x3022L,9L,0x2598L,0x8AF0L,(-10L),5L}},{{0x3022L,(-5L),0x8AF0L,0x3022L,(-10L),0x2598L},{5L,9L,0x8AF0L,0x8AF0L,0x3022L,(-3L)},{(-3L),0x8AF0L,0xBC3AL,(-9L),0x3022L,0xBC3AL},{(-9L),0x3022L,0xBC3AL,6L,5L,(-3L)},{(-9L),0x8AF0L,6L,(-9L),5L,0xBC3AL},{(-3L),0x3022L,6L,6L,0x3022L,(-3L)}},{{(-3L),0x8AF0L,0xBC3AL,(-9L),0x3022L,0xBC3AL},{(-9L),0x3022L,0xBC3AL,6L,5L,(-3L)},{(-9L),0x8AF0L,6L,(-9L),5L,0xBC3AL},{(-3L),0x3022L,6L,6L,0x3022L,(-3L)},{(-3L),0x8AF0L,0xBC3AL,(-9L),0x3022L,0xBC3AL},{(-9L),0x3022L,0xBC3AL,6L,5L,(-3L)}}};
            int32_t l_179 = (-5L);
            int i, j, k;
            l_174 = (safe_add_func_int32_t_s_s((safe_add_func_uint32_t_u_u(((((safe_div_func_uint8_t_u_u(0x64L, 9UL)) < g_101) ^ g_120) , g_158), l_173[1][4][4])), 0L));
            l_174 ^= (l_18 && 1L);
            l_178 = (safe_mod_func_uint64_t_u_u(0x98A745DD4C412B3BLL, g_177));
            --g_189;
        }
        else
        { /* block id: 112 */
            g_158 = ((safe_mod_func_uint64_t_u_u((safe_mod_func_uint8_t_u_u(g_64, l_196)), g_182)) , l_180);
        }
        if (l_185)
            continue;
        if (g_5)
            break;
    }
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_64 g_6 g_47 g_101
 * writes: g_5 g_6 g_101
 */
static int32_t  func_10(int32_t  p_11)
{ /* block id: 71 */
    int32_t l_137[9][3][1];
    int32_t l_157 = (-3L);
    int i, j, k;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
                l_137[i][j][k] = 9L;
        }
    }
    if ((safe_sub_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(((!(-1L)) , g_5), 12)), l_137[4][1][0])))
    { /* block id: 72 */
        int64_t l_146 = 1L;
        for (p_11 = 0; (p_11 <= (-13)); p_11 = safe_sub_func_uint16_t_u_u(p_11, 9))
        { /* block id: 75 */
            uint32_t l_140 = 0x4206E045L;
            int32_t l_145 = (-7L);
            ++l_140;
            l_145 = (safe_sub_func_int16_t_s_s(((g_2 , 0x1FBB9A9CB853F4F8LL) > p_11), 0UL));
            l_146 |= g_64;
        }
    }
    else
    { /* block id: 80 */
        int32_t l_150 = 0xC7E325EDL;
        g_5 = (0xE6926EBDL <= g_2);
        if ((((l_137[4][1][0] >= g_2) , p_11) && g_6))
        { /* block id: 82 */
            const uint64_t l_149 = 0UL;
            l_150 &= (safe_mul_func_uint8_t_u_u((0xA199CCF4BB60450DLL == l_149), l_137[6][2][0]));
            l_150 = g_6;
            return p_11;
        }
        else
        { /* block id: 86 */
            g_6 = (((~(safe_mod_func_int64_t_s_s(((g_47 > g_2) && 0xB42BE2F3L), p_11))) != p_11) < g_101);
            return l_137[4][1][0];
        }
    }
    for (p_11 = 0; (p_11 >= 0); p_11 -= 1)
    { /* block id: 93 */
        uint8_t l_156 = 1UL;
        int32_t l_159 = 0x62DF2AD2L;
        int32_t l_160 = 0x1A507D19L;
        for (g_6 = 0; (g_6 <= 0); g_6 += 1)
        { /* block id: 96 */
            uint32_t l_161[6][10][3] = {{{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL},{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL},{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL},{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL},{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL}},{{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL},{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL},{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL},{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL},{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL}},{{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL},{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL},{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL},{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL},{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL}},{{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL},{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL},{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL},{0x996E1C07L,0UL,0x996E1C07L},{0UL,4294967289UL,9UL},{0x996E1C07L,9UL,1UL},{0UL,0xF6FD8681L,0UL}},{{0x996E1C07L,8UL,0xBE9BACE1L},{0UL,0UL,0x42F4987FL},{0x996E1C07L,0UL,0x996E1C07L},{0xE98AAFF4L,0UL,0x7893A053L},{0x9AC723E3L,1UL,0xF9B38B2FL},{0xE98AAFF4L,9UL,0xE98AAFF4L},{0x9AC723E3L,0x996E1C07L,4294967292UL},{0xE98AAFF4L,0x42F4987FL,0xC6E3E164L},{0x9AC723E3L,0xBE9BACE1L,0x9AC723E3L},{0xE98AAFF4L,0UL,0x7893A053L}},{{0x9AC723E3L,1UL,0xF9B38B2FL},{0xE98AAFF4L,9UL,0xE98AAFF4L},{0x9AC723E3L,0x996E1C07L,4294967292UL},{0xE98AAFF4L,0x42F4987FL,0xC6E3E164L},{0x9AC723E3L,0xBE9BACE1L,0x9AC723E3L},{0xE98AAFF4L,0UL,0x7893A053L},{0x9AC723E3L,1UL,0xF9B38B2FL},{0xE98AAFF4L,9UL,0xE98AAFF4L},{0x9AC723E3L,0x996E1C07L,4294967292UL},{0xE98AAFF4L,0x42F4987FL,0xC6E3E164L}}};
            int i, j, k;
            l_156 = (safe_lshift_func_uint16_t_u_s((p_11 == 0x1088D6ADL), 14));
            --l_161[5][0][2];
        }
        for (g_101 = 0; (g_101 <= 0); g_101 += 1)
        { /* block id: 102 */
            g_5 = (safe_lshift_func_uint16_t_u_u((!p_11), l_160));
        }
    }
    return l_157;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_47 g_64 g_45 g_2 g_101 g_111 g_120
 * writes: g_47 g_6 g_64 g_5 g_101 g_111 g_120
 */
static uint16_t  func_12(uint16_t  p_13, int32_t  p_14, uint32_t  p_15, int32_t  p_16, uint8_t  p_17)
{ /* block id: 9 */
    int32_t l_21[4] = {0xF34E401DL,0xF34E401DL,0xF34E401DL,0xF34E401DL};
    int i;
    p_16 = (safe_unary_minus_func_int64_t_s((g_5 != l_21[2])));
    p_16 = (safe_sub_func_uint64_t_u_u(((func_24(func_30((safe_mod_func_int32_t_s_s(0x2377963FL, 0x89E17716L)), l_21[2], g_6, p_14, l_21[2]), l_21[0], l_21[2], p_15, l_21[2]) == g_2) & g_2), 0xF73882F6EF7C0E05LL));
    l_21[2] = ((safe_add_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_u(((safe_add_func_int32_t_s_s((((safe_sub_func_uint64_t_u_u(p_16, p_14)) > p_14) || l_21[2]), 0x38544CA3L)) , l_21[3]), p_17)) >= p_17) , l_21[0]), g_101)) == (-10L));
    g_6 = ((((safe_unary_minus_func_int32_t_s((p_17 , p_15))) ^ 4294967286UL) | 0x6B8AB05D55F32A42LL) , 0xE96A6969L);
    return l_21[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_2 g_5 g_101 g_6 g_111 g_120
 * writes: g_5 g_101 g_6 g_111 g_120
 */
static int8_t  func_24(int32_t  p_25, uint64_t  p_26, uint64_t  p_27, int8_t  p_28, int32_t  p_29)
{ /* block id: 37 */
    uint32_t l_78 = 0x8AD0AF09L;
    int32_t l_82 = 0x2D98881BL;
    int32_t l_84 = 0x12EB5757L;
    uint16_t l_85 = 65527UL;
    g_5 = g_45;
    if ((safe_mul_func_uint8_t_u_u(0xBCL, l_78)))
    { /* block id: 39 */
        const int32_t l_81 = 0xE7D4E858L;
        int32_t l_83 = 0x667A95F2L;
        g_5 = (safe_div_func_uint8_t_u_u((p_26 < g_45), l_81));
        l_85++;
        for (p_28 = 0; (p_28 > 4); ++p_28)
        { /* block id: 44 */
            int64_t l_90 = (-8L);
            l_90 = (-1L);
        }
    }
    else
    { /* block id: 47 */
        int32_t l_91 = 0xC0B7B9EAL;
        uint16_t l_99 = 65532UL;
        uint16_t l_108 = 0xCAD7L;
        if (l_91)
        { /* block id: 48 */
            uint64_t l_98 = 0x645C98B20FBFF594LL;
            l_99 = ((((safe_div_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u((((((safe_lshift_func_int16_t_s_s(0x45F7L, 4)) < g_2) > 255UL) < p_27) || g_5), p_29)) & (-9L)), l_91)) == 3L) <= 1UL) > l_98);
        }
        else
        { /* block id: 50 */
            int16_t l_100 = 9L;
            g_101++;
            l_82 |= ((((((safe_add_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(((1L <= p_25) > 0L), p_29)), 0x25L)) != (-1L)) , l_99) < 4L) && 0x2EL) , l_85);
            g_6 |= 0x2DC7329AL;
            l_91 = ((((1UL & l_84) >= g_45) && g_6) != l_91);
        }
        g_5 &= ((((l_82 , 0x5DFA243BL) > p_27) <= l_108) != l_99);
        g_6 = ((safe_lshift_func_int16_t_s_u(g_5, 7)) >= p_29);
        l_84 &= (0xE37CL || 1L);
    }
    g_111--;
    for (p_28 = 21; (p_28 == 7); p_28 = safe_sub_func_int16_t_s_s(p_28, 4))
    { /* block id: 63 */
        int64_t l_116 = 0x68AB631009988348LL;
        int32_t l_117 = 4L;
        int32_t l_118 = 0xE0895C1BL;
        int32_t l_119[5];
        int i;
        for (i = 0; i < 5; i++)
            l_119[i] = (-1L);
        ++g_120;
    }
    return g_111;
}


/* ------------------------------------------ */
/* 
 * reads : g_47 g_64 g_45
 * writes: g_47 g_6 g_64
 */
static int32_t  func_30(int32_t  p_31, uint32_t  p_32, uint32_t  p_33, uint8_t  p_34, uint64_t  p_35)
{ /* block id: 11 */
    int64_t l_40 = 0x5DD3610CB4E3473ELL;
    int32_t l_43 = (-10L);
    int32_t l_46 = 0x95C3C62EL;
    uint32_t l_50[5][10] = {{0xA30FB9C0L,2UL,0x536CA9A4L,0xD416A781L,0UL,1UL,1UL,0UL,0xD416A781L,0x536CA9A4L},{0UL,0UL,4294967291UL,0xA30FB9C0L,0x53D1EDBCL,1UL,0xA8B5F6E5L,1UL,0x53D1EDBCL,0xA30FB9C0L},{0xA30FB9C0L,0x6C9A4A91L,0xA30FB9C0L,1UL,0x2C990B51L,0x536CA9A4L,0xA8B5F6E5L,0xA8B5F6E5L,0x536CA9A4L,0x2C990B51L},{4294967291UL,0UL,0UL,4294967291UL,0xA30FB9C0L,0x53D1EDBCL,1UL,0xA8B5F6E5L,1UL,0x53D1EDBCL},{0x536CA9A4L,2UL,0xA30FB9C0L,2UL,0x536CA9A4L,0xD416A781L,0UL,1UL,1UL,0UL}};
    int32_t l_58 = 0x80B7F2DBL;
    int32_t l_59 = 1L;
    int32_t l_60 = (-1L);
    int32_t l_62 = 1L;
    uint64_t l_75 = 0UL;
    int i, j;
    for (p_31 = 10; (p_31 == (-23)); --p_31)
    { /* block id: 14 */
        int32_t l_41 = (-1L);
        int32_t l_42 = 9L;
        int32_t l_44[6][8] = {{0xE495EE35L,0xAA787D30L,0xE495EE35L,(-6L),0xAA787D30L,1L,1L,0xAA787D30L},{0xAA787D30L,1L,1L,0xAA787D30L,(-6L),0xE495EE35L,0xAA787D30L,0xE495EE35L},{0xAA787D30L,1L,(-1L),1L,0xAA787D30L,(-1L),0L,0L},{0xE495EE35L,1L,(-6L),(-6L),1L,0xE495EE35L,1L,1L},{0L,1L,(-6L),0L,(-6L),1L,0L,0xE495EE35L},{1L,0xAA787D30L,(-1L),0L,0L,(-1L),0xAA787D30L,1L}};
        int i, j;
        g_47++;
    }
    if (((l_43 || g_47) | l_40))
    { /* block id: 17 */
        int32_t l_56 = 0xD06DB255L;
        int32_t l_63[8][7][4] = {{{0x50E9BCC6L,0xB1CD7F69L,0L,0L},{6L,6L,0x6A768714L,(-2L)},{0x6A768714L,(-2L),(-5L),0x006156DBL},{0x006156DBL,0xCF873A64L,6L,(-5L)},{0L,0xCF873A64L,(-10L),0x006156DBL},{0xCF873A64L,(-2L),0x9552BC05L,(-2L)},{7L,6L,0x69712D56L,0L}},{{0x9552BC05L,0xB1CD7F69L,0xB9066996L,0x4008F4F8L},{0L,0xB9066996L,0xCF873A64L,0x69712D56L},{0L,7L,0x50E9BCC6L,(-5L)},{0x6A768714L,6L,6L,0x6A768714L},{0xA6DD691DL,0xB9066996L,0x6A768714L,0L},{(-2L),(-5L),0x006156DBL,0xE5A9921AL},{0xE7089521L,(-10L),0L,0xE5A9921AL}},{{0xB9066996L,(-5L),0xCF873A64L,0L},{7L,0xB9066996L,7L,0x6A768714L},{0L,6L,0x9552BC05L,(-5L)},{0xE5A9921AL,7L,0L,6L},{0x69712D56L,0x50E9BCC6L,0L,(-10L)},{0xE5A9921AL,0x4008F4F8L,0x9552BC05L,0x9552BC05L},{0L,0L,7L,0x69712D56L}},{{7L,0x69712D56L,0xCF873A64L,0xB9066996L},{0xB9066996L,(-2L),0L,0xCF873A64L},{0xE7089521L,(-2L),0x006156DBL,0xB9066996L},{(-2L),0x69712D56L,0x6A768714L,0x69712D56L},{0xA6DD691DL,0L,6L,0x9552BC05L},{0x6A768714L,0x4008F4F8L,0x50E9BCC6L,(-10L)},{0x9552BC05L,0x50E9BCC6L,(-2L),6L}},{{0x9552BC05L,7L,0x50E9BCC6L,(-5L)},{0x6A768714L,6L,6L,0x6A768714L},{0xA6DD691DL,0xB9066996L,0x6A768714L,0L},{(-2L),(-5L),0x006156DBL,0xE5A9921AL},{0xE7089521L,(-10L),0L,0xE5A9921AL},{0xB9066996L,(-5L),0xCF873A64L,0L},{7L,0xB9066996L,7L,0x6A768714L}},{{0L,6L,0x9552BC05L,(-5L)},{0xE5A9921AL,7L,0L,6L},{0x69712D56L,0x50E9BCC6L,0L,(-10L)},{0xE5A9921AL,0x4008F4F8L,0x9552BC05L,0x9552BC05L},{0L,0L,7L,0x69712D56L},{7L,0x69712D56L,0xCF873A64L,0xB9066996L},{0xB9066996L,(-2L),0L,0xCF873A64L}},{{0xE7089521L,(-2L),0x006156DBL,0xB9066996L},{(-2L),0x69712D56L,0x6A768714L,0x69712D56L},{0xA6DD691DL,0L,6L,0x9552BC05L},{0x6A768714L,0x4008F4F8L,0x50E9BCC6L,(-10L)},{0x9552BC05L,0x50E9BCC6L,(-2L),6L},{0x9552BC05L,7L,0x50E9BCC6L,(-5L)},{0x6A768714L,6L,6L,0x6A768714L}},{{0xA6DD691DL,0xB9066996L,0x6A768714L,0L},{(-2L),(-5L),0x006156DBL,0xE5A9921AL},{0xE7089521L,(-10L),0L,0xE5A9921AL},{0xB9066996L,(-5L),0xCF873A64L,0L},{7L,0xB9066996L,7L,0x6A768714L},{0L,6L,0x9552BC05L,(-5L)},{0xE5A9921AL,7L,0L,6L}}};
        int16_t l_69[2];
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_69[i] = 0x5124L;
        for (p_35 = 0; (p_35 <= 4); p_35 += 1)
        { /* block id: 20 */
            uint32_t l_54[9][5] = {{0xB186EC4FL,0xB186EC4FL,0x7FA6FBAAL,0xB8CD6C33L,0xCCF04A32L},{0xD61797E2L,18446744073709551612UL,0x9A6E4C1CL,18446744073709551612UL,0xD61797E2L},{0xCCF04A32L,0xB8CD6C33L,0x7FA6FBAAL,0xB186EC4FL,0xB186EC4FL},{18446744073709551614UL,18446744073709551612UL,18446744073709551614UL,0x2A59A03CL,18446744073709551614UL},{0xCCF04A32L,0xB186EC4FL,0xB8CD6C33L,0xB8CD6C33L,0xB186EC4FL},{0xD61797E2L,0x2A59A03CL,0x9A6E4C1CL,0x2A59A03CL,0xD61797E2L},{0xB186EC4FL,0xB8CD6C33L,0xB8CD6C33L,0xB186EC4FL,0xCCF04A32L},{18446744073709551614UL,0x2A59A03CL,18446744073709551614UL,18446744073709551612UL,18446744073709551614UL},{0xB186EC4FL,0xB186EC4FL,0x7FA6FBAAL,0xB8CD6C33L,0xCCF04A32L}};
            int32_t l_55 = 0L;
            int32_t l_57 = 0xDB69C522L;
            int8_t l_61 = 0x31L;
            int i, j;
            g_6 = p_32;
            l_55 = (!((safe_add_func_int32_t_s_s(((1L <= l_54[0][2]) >= 0xB63BL), p_31)) > 255UL));
            ++g_64;
        }
        for (l_62 = (-6); (l_62 <= (-20)); l_62--)
        { /* block id: 27 */
            l_69[0] = p_31;
            return p_34;
        }
    }
    else
    { /* block id: 31 */
        int8_t l_70 = 0x0DL;
        int32_t l_71 = 0x78971D2FL;
        uint8_t l_72 = 0x4CL;
        l_59 = (((l_58 ^ 0xDF84107A49E812EDLL) <= p_31) ^ g_45);
        --l_72;
        p_31 = l_71;
    }
    return l_75;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_182, "g_182", print_hash_value);
    transparent_crc(g_187, "g_187", print_hash_value);
    transparent_crc(g_188, "g_188", print_hash_value);
    transparent_crc(g_189, "g_189", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 75
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 71
   depth: 2, occurrence: 18
   depth: 3, occurrence: 6
   depth: 4, occurrence: 5
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 15, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 109
XXX times a non-volatile is write: 41
XXX times a volatile is read: 17
XXX    times read thru a pointer: 0
XXX times a volatile is write: 12
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 90
XXX percentage of non-volatile access: 83.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 69
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 23
   depth: 2, occurrence: 28

XXX percentage a fresh-made variable is used: 32.8
XXX percentage an existing variable is used: 67.2
********************* end of statistics **********************/

