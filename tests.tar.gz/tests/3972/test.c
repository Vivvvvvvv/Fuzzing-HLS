/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9390936484035258339
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_9[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
static uint32_t g_15 = 0UL;
static uint32_t g_31 = 0xB0002500L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int64_t  func_2(uint16_t  p_3, int64_t  p_4, int8_t  p_5, uint16_t  p_6);
static int64_t  func_25(const uint8_t  p_26, int16_t  p_27, int8_t  p_28, int32_t  p_29);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_15
 * writes: g_31
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_10 = 255UL;
    int32_t l_46 = (-3L);
    l_46 &= (func_2((safe_add_func_int8_t_s_s(8L, 0xD3L)), g_9[6], g_9[6], l_10) == l_10);
    return l_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_9
 * writes: g_31
 */
static int64_t  func_2(uint16_t  p_3, int64_t  p_4, int8_t  p_5, uint16_t  p_6)
{ /* block id: 1 */
    int64_t l_16 = 0x4BA31E468A07C694LL;
    int32_t l_17 = 0xF68593F9L;
    l_16 = ((safe_mod_func_int16_t_s_s(((safe_div_func_uint16_t_u_u(g_15, 0x73B2L)) || p_5), 0x9A2BL)) , p_5);
    l_17 &= (0L == l_16);
    l_17 = (((((safe_add_func_uint32_t_u_u(((safe_unary_minus_func_uint32_t_u(((safe_div_func_uint8_t_u_u((safe_add_func_int64_t_s_s(func_25((safe_unary_minus_func_int64_t_s(8L)), g_9[2], g_15, l_17), 0x6BC6715623A55A41LL)), 0x45L)) == 6L))) && 0UL), g_9[6])) < l_16) == l_16) , p_5) , p_5);
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_15
 * writes: g_31
 */
static int64_t  func_25(const uint8_t  p_26, int16_t  p_27, int8_t  p_28, int32_t  p_29)
{ /* block id: 4 */
    int64_t l_44[10];
    int32_t l_45 = 9L;
    int i;
    for (i = 0; i < 10; i++)
        l_44[i] = 0x48718302CCA7A22FLL;
    for (p_27 = 6; (p_27 >= 2); p_27 -= 1)
    { /* block id: 7 */
        int i;
        if (g_9[(p_27 + 1)])
            break;
        g_31 = 0xED6C34F1L;
    }
    l_45 = (((safe_lshift_func_int16_t_s_u((((((((((safe_div_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_add_func_uint32_t_u_u((safe_div_func_int8_t_s_s(((safe_mod_func_uint8_t_u_u(p_26, p_29)) , l_44[7]), l_44[0])), p_26)), p_29)), g_15)) != (-1L)) > 0x8FF4L) < 0x93911E74L) != l_44[8]) != g_9[6]) ^ p_28) >= g_9[8]) & l_44[7]), l_44[1])) > l_44[7]) >= p_29);
    l_45 = ((p_27 == 3L) < 7UL);
    return p_29;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 12
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 14, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 37
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 21.4
XXX percentage an existing variable is used: 78.6
********************* end of statistics **********************/

