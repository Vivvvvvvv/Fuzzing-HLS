/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9393218838347713262
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const int8_t g_9 = 0x58L;
static uint64_t g_11 = 0xE1B88146CDEAD9BALL;
static int16_t g_27 = 0L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static const int32_t  func_2(int16_t  p_3);
static int16_t  func_4(const int32_t  p_5, int32_t  p_6, int16_t  p_7, int8_t  p_8);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_11
 * writes: g_11 g_27
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_10 = 0x3ED1L;
    int32_t l_26 = (-4L);
    l_26 = func_2(func_4(g_9, g_9, l_10, g_9));
    g_27 = l_10;
    return l_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes: g_11
 */
static const int32_t  func_2(int16_t  p_3)
{ /* block id: 4 */
    uint32_t l_15 = 5UL;
    int32_t l_16 = (-3L);
    for (g_11 = 0; (g_11 >= 50); ++g_11)
    { /* block id: 7 */
        uint64_t l_17 = 0UL;
        l_16 = l_15;
        ++l_17;
        return l_17;
    }
    l_16 = p_3;
    if (((safe_mod_func_uint32_t_u_u((g_11 , 0xFE24307AL), (-6L))) != 1UL))
    { /* block id: 13 */
        int32_t l_22 = 0xABC24891L;
        l_22 = p_3;
    }
    else
    { /* block id: 15 */
        uint64_t l_25 = 18446744073709551606UL;
        l_25 |= ((((safe_rshift_func_uint8_t_u_u(6UL, l_15)) > 0xEA28C7FFFAA23240LL) <= p_3) <= g_11);
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_11
 * writes: g_11
 */
static int16_t  func_4(const int32_t  p_5, int32_t  p_6, int16_t  p_7, int8_t  p_8)
{ /* block id: 1 */
    uint32_t l_12 = 1UL;
    g_11 &= (0xB7F3L == g_9);
    return l_12;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 18
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 44
XXX percentage an existing variable is used: 56
********************* end of statistics **********************/

