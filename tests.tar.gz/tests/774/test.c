/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16007773109382058882
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   const int32_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_4 = 0xFAB8L;
static uint32_t g_5 = 4294967295UL;
static uint32_t g_42 = 0x85A06C0FL;
static uint64_t g_43 = 0x284818A88ACC167DLL;
static uint32_t g_63 = 0xDE87198BL;
static int8_t g_66[9][7][4] = {{{3L,0x9DL,0x37L,0x14L},{0xEDL,0xB1L,0xEDL,0x14L},{0x37L,0x9DL,3L,0xCBL},{1L,1L,0x9DL,0x9DL},{0x86L,0x86L,0x9DL,0xEDL},{1L,0xE3L,3L,1L},{0x37L,3L,0xEDL,3L}},{{0xEDL,3L,0x37L,1L},{3L,0xE3L,1L,0xEDL},{0x9DL,0x86L,0x86L,0x9DL},{0x9DL,1L,1L,0xCBL},{3L,0x9DL,1L,3L},{1L,0xCBL,1L,3L},{1L,0x86L,0xB1L,0xE3L}},{{0xEDL,0x9DL,0x86L,0x86L},{0x14L,0x14L,0x86L,1L},{0xEDL,0x37L,0xB1L,0x9DL},{1L,0xB1L,1L,0xB1L},{1L,0xB1L,1L,0x9DL},{0xB1L,0x37L,0xEDL,1L},{0x86L,0x14L,0x14L,0x86L}},{{0x86L,0x9DL,0xEDL,0xE3L},{0xB1L,0x86L,1L,3L},{1L,0xCBL,1L,3L},{1L,0x86L,0xB1L,0xE3L},{0xEDL,0x9DL,0x86L,0x86L},{0x14L,0x14L,0x86L,1L},{0xEDL,0x37L,0xB1L,0x9DL}},{{1L,0xB1L,1L,0xB1L},{1L,0xB1L,1L,0x9DL},{0xB1L,0x37L,0xEDL,1L},{0x86L,0x14L,0x14L,0x86L},{0x86L,0x9DL,0xEDL,0xE3L},{0xB1L,0x86L,1L,3L},{1L,0xCBL,1L,3L}},{{1L,0x86L,0xB1L,0xE3L},{0xEDL,0x9DL,0x86L,0x86L},{0x14L,0x14L,0x86L,1L},{0xEDL,0x37L,0xB1L,0x9DL},{1L,0xB1L,1L,0xB1L},{1L,0xB1L,1L,0x9DL},{0xB1L,0x37L,0xEDL,1L}},{{0x86L,0x14L,0x14L,0x86L},{0x86L,0x9DL,0xEDL,0xE3L},{0xB1L,0x86L,1L,3L},{1L,0xCBL,1L,3L},{1L,0x86L,0xB1L,0xE3L},{0xEDL,0x9DL,0x86L,0x86L},{0x14L,0x14L,0x86L,1L}},{{0xEDL,0x37L,0xB1L,0x9DL},{1L,0xB1L,1L,0xB1L},{1L,0xB1L,1L,0x9DL},{0xB1L,0x37L,0xEDL,1L},{0x86L,0x14L,0x14L,0x86L},{0x86L,0x9DL,0xEDL,0xE3L},{0xB1L,0x86L,1L,3L}},{{1L,0xCBL,1L,3L},{1L,0x86L,0xB1L,0xE3L},{0xEDL,0x9DL,0x86L,0x86L},{0x14L,3L,0x14L,0x9DL},{1L,1L,0xCBL,0x86L},{0xEDL,0xCBL,0x9DL,0xCBL},{0x9DL,0xCBL,0xEDL,0x86L}}};
static int64_t g_69 = 4L;
static volatile struct S0 g_78 = {18446744073709551609UL,0xAE0A7320L};/* VOLATILE GLOBAL g_78 */
static int32_t g_79 = 8L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint32_t  func_14(const int16_t  p_15, uint32_t  p_16);
static const int16_t  func_17(int16_t  p_18, int32_t  p_19);
static uint8_t  func_26(const uint16_t  p_27, uint16_t  p_28, uint64_t  p_29, uint32_t  p_30);
static uint8_t  func_33(int32_t  p_34, uint8_t  p_35, int16_t  p_36, uint16_t  p_37, int8_t  p_38);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_43 g_42 g_63 g_66 g_69 g_78 g_79
 * writes: g_5 g_4 g_42 g_43 g_63 g_66 g_69 g_79
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_54 = 2L;
    int32_t l_80 = 0L;
    g_5 = (safe_div_func_int32_t_s_s((g_4 ^ 0x3B3152C5L), g_4));
    for (g_4 = 12; (g_4 != 24); g_4++)
    { /* block id: 4 */
        uint64_t l_10[10] = {0xE0369BD697E780CALL,18446744073709551615UL,0xE0369BD697E780CALL,0xE0369BD697E780CALL,18446744073709551615UL,0xE0369BD697E780CALL,0xE0369BD697E780CALL,18446744073709551615UL,0xE0369BD697E780CALL,0xE0369BD697E780CALL};
        int i;
        l_10[4] = (safe_mul_func_int8_t_s_s(g_4, 1UL));
        for (g_5 = (-28); (g_5 <= 58); g_5++)
        { /* block id: 8 */
            int32_t l_13 = (-10L);
            if (l_10[4])
                break;
            l_13 = g_5;
        }
    }
    l_80 ^= (((func_14(func_17(g_5, g_4), l_54) , l_54) ^ 0xE858L) , g_66[1][2][3]);
    for (g_69 = 0; (g_69 > (-28)); --g_69)
    { /* block id: 58 */
        l_80 = (((safe_rshift_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(l_80, g_43)), 1)) || 0x365AED0EL) & l_80);
        g_79 ^= 0L;
    }
    return g_78.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_42 g_43 g_63 g_66 g_69 g_4 g_78 g_79
 * writes: g_63 g_66 g_69 g_79
 */
static uint32_t  func_14(const int16_t  p_15, uint32_t  p_16)
{ /* block id: 33 */
    uint32_t l_55 = 0x318431BBL;
    int32_t l_56 = 0x7E410F71L;
    l_56 &= ((((((g_5 == g_42) == g_43) & 4L) | p_16) ^ l_55) != p_16);
    l_56 = 1L;
    if ((safe_rshift_func_int16_t_s_s((safe_add_func_uint64_t_u_u((g_43 < g_5), l_56)), p_16)))
    { /* block id: 36 */
        g_63 = (safe_mod_func_uint64_t_u_u(0x42F9032B81468F30LL, 0x42FC308456A9E5FALL));
    }
    else
    { /* block id: 38 */
        if (((((safe_rshift_func_int8_t_s_u((-1L), 2)) | g_63) < g_5) > g_43))
        { /* block id: 39 */
            g_66[0][3][0] = g_43;
            g_69 = (safe_div_func_uint32_t_u_u(((-6L) & p_15), 0x6B0C4F58L));
            l_56 = p_15;
        }
        else
        { /* block id: 43 */
            uint64_t l_70 = 8UL;
            l_70 = g_42;
            l_56 = (+(((safe_lshift_func_uint16_t_u_u((((safe_mul_func_int16_t_s_s(((g_66[0][3][0] && g_69) == (-9L)), g_4)) <= 0xE42CL) || 0x07L), 8)) , g_66[1][3][3]) == p_16));
        }
        for (g_63 = (-14); (g_63 != 23); ++g_63)
        { /* block id: 49 */
            l_56 = g_43;
        }
    }
    g_79 &= (g_78 , l_56);
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_43 g_5 g_4 g_42
 * writes: g_42 g_43
 */
static const int16_t  func_17(int16_t  p_18, int32_t  p_19)
{ /* block id: 13 */
    int32_t l_48 = 0xB6C7E7C0L;
    for (p_18 = 0; (p_18 < (-11)); p_18 = safe_sub_func_uint8_t_u_u(p_18, 7))
    { /* block id: 16 */
        int32_t l_46 = 8L;
        for (p_19 = (-20); (p_19 != 22); p_19 = safe_add_func_int64_t_s_s(p_19, 1))
        { /* block id: 19 */
            int16_t l_40 = 0xFA90L;
            int32_t l_53[3];
            int i;
            for (i = 0; i < 3; i++)
                l_53[i] = 0x70BB1DCEL;
            l_48 = (safe_mul_func_uint8_t_u_u((func_26((((safe_mod_func_uint8_t_u_u(func_33(((safe_unary_minus_func_int32_t_s(p_19)) != p_19), p_19, l_40, l_40, p_18), g_5)) != l_46) && l_46), p_19, g_4, p_18) , p_18), 0xCBL));
            l_53[2] = (safe_add_func_int16_t_s_s(((((safe_mul_func_int8_t_s_s((l_48 < l_40), p_18)) == p_19) != g_42) != 4294967295UL), p_18));
        }
        l_48 ^= 0xDCEDB1A7L;
        return l_46;
    }
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_26(const uint16_t  p_27, uint16_t  p_28, uint64_t  p_29, uint32_t  p_30)
{ /* block id: 24 */
    int32_t l_47 = 0x9E8BFA08L;
    return l_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_43
 * writes: g_42 g_43
 */
static uint8_t  func_33(int32_t  p_34, uint8_t  p_35, int16_t  p_36, uint16_t  p_37, int8_t  p_38)
{ /* block id: 20 */
    const uint16_t l_41[2] = {0x50E8L,0x50E8L};
    int i;
    g_42 = l_41[1];
    g_43++;
    return p_35;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_66[i][j][k], "g_66[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_78.f0, "g_78.f0", print_hash_value);
    transparent_crc(g_78.f1, "g_78.f1", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 38
   depth: 2, occurrence: 9
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 68
XXX times a non-volatile is write: 27
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 97.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 36
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 10
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 25.6
XXX percentage an existing variable is used: 74.4
********************* end of statistics **********************/

