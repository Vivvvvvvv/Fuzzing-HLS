/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16853378862150490206
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_5 = 3UL;
static uint16_t g_17 = 0x07C2L;
static uint8_t g_19 = 0UL;
static volatile int8_t g_38 = (-10L);/* VOLATILE GLOBAL g_38 */
static volatile uint64_t g_39 = 18446744073709551615UL;/* VOLATILE GLOBAL g_39 */
static volatile uint16_t g_40 = 65534UL;/* VOLATILE GLOBAL g_40 */
static uint32_t g_43 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int32_t  p_4);
static int32_t  func_6(int16_t  p_7, int8_t  p_8);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_19 g_17 g_39 g_40 g_43
 * writes: g_17 g_19 g_5 g_38 g_39 g_40 g_43
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_27 = 0x3AL;
    int32_t l_29 = 0L;
    g_19 = func_2(g_5, g_5);
    for (g_5 = 7; (g_5 == 28); ++g_5)
    { /* block id: 11 */
        int16_t l_28 = (-10L);
        int32_t l_37 = (-8L);
        l_29 &= ((+(((safe_mul_func_int16_t_s_s((safe_add_func_int8_t_s_s(((((0x77L || g_5) && g_5) && (-1L)) ^ 0x77D6446BL), (-4L))), l_27)) <= g_19) == l_28)) != g_19);
        if ((safe_sub_func_int32_t_s_s((safe_sub_func_uint32_t_u_u((~(safe_lshift_func_uint16_t_u_u(0xB36CL, 13))), g_17)), g_5)))
        { /* block id: 13 */
            l_37 = ((g_17 || l_29) == g_17);
            g_38 = (-1L);
        }
        else
        { /* block id: 16 */
            g_39 |= 0L;
            l_37 = l_37;
            g_40++;
        }
    }
    g_43 ^= ((((l_29 || l_29) >= g_5) ^ g_19) & g_40);
    return g_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes: g_17
 */
static int32_t  func_2(int32_t  p_3, int32_t  p_4)
{ /* block id: 1 */
    int32_t l_18[4];
    int i;
    for (i = 0; i < 4; i++)
        l_18[i] = 1L;
    g_17 = func_6(g_5, g_5);
    return l_18[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes:
 */
static int32_t  func_6(int16_t  p_7, int8_t  p_8)
{ /* block id: 2 */
    uint32_t l_13[7];
    int64_t l_14 = 0xFFAF07207182B474LL;
    uint32_t l_15[7];
    int32_t l_16 = (-1L);
    int i;
    for (i = 0; i < 7; i++)
        l_13[i] = 0x61C71BC7L;
    for (i = 0; i < 7; i++)
        l_15[i] = 0UL;
    l_14 = ((safe_rshift_func_uint16_t_u_s((safe_div_func_uint8_t_u_u(0x43L, p_7)), p_8)) < l_13[6]);
    l_16 = (((-1L) <= l_14) > l_15[1]);
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 1
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 28
XXX times a non-volatile is write: 9
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 88.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 2
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 39
XXX percentage an existing variable is used: 61
********************* end of statistics **********************/

