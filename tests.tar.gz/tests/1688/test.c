/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15944529058294748720
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint32_t g_6 = 0x638ECF54L;
static uint32_t g_15 = 4294967287UL;
static uint64_t g_16 = 0xF66B17B722BA7B7ELL;
static int32_t g_21 = 2L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_2(const uint32_t  p_3, int64_t  p_4, const uint64_t  p_5);
static uint16_t  func_9(uint8_t  p_10, int32_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_16
 * writes: g_15 g_16 g_21
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_25 = 0xD2L;
    l_25 |= func_2(g_6, g_6, g_6);
    return l_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_16
 * writes: g_15 g_16 g_21
 */
static int32_t  func_2(const uint32_t  p_3, int64_t  p_4, const uint64_t  p_5)
{ /* block id: 1 */
    int64_t l_17 = 0x0B168F928D9BA5F2LL;
    int32_t l_18 = 0x9C3997B0L;
    int32_t l_24 = 0xEAF6082FL;
    g_16 = ((safe_lshift_func_uint16_t_u_s(func_9(g_6, g_6), 8)) >= 18446744073709551610UL);
    l_18 = (((l_17 != 0x4129B85755261FC4LL) | (-1L)) , 7L);
    g_21 = ((safe_mod_func_int8_t_s_s((g_16 >= 0xB8L), p_5)) != l_18);
    for (l_18 = 12; (l_18 <= 2); --l_18)
    { /* block id: 10 */
        l_24 |= (l_17 >= 0x18L);
    }
    return l_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes: g_15
 */
static uint16_t  func_9(uint8_t  p_10, int32_t  p_11)
{ /* block id: 2 */
    int32_t l_14 = 3L;
    g_15 = (((safe_mul_func_int16_t_s_s(l_14, 0xBBD0L)) != p_10) != g_6);
    return p_10;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 2
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 7
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 40.9
XXX percentage an existing variable is used: 59.1
********************* end of statistics **********************/

