/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8376583798917626938
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_13 = 8UL;/* VOLATILE GLOBAL g_13 */
static int16_t g_14 = 3L;
static uint32_t g_33 = 4294967287UL;
static int32_t g_41[4] = {0x611CA4B3L,0x611CA4B3L,0x611CA4B3L,0x611CA4B3L};
static uint16_t g_42 = 1UL;
static uint32_t g_46 = 7UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int64_t  func_4(int32_t  p_5, uint64_t  p_6, int16_t  p_7);
static uint8_t  func_21(int32_t  p_22);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_14 g_33 g_42
 * writes: g_14 g_33 g_41 g_46
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_12 = 0x4BL;
    int32_t l_45 = 1L;
    l_45 |= (safe_add_func_int64_t_s_s(func_4((safe_sub_func_int16_t_s_s((safe_mod_func_int8_t_s_s((l_12 , l_12), g_13)), g_14)), g_14, g_14), l_12));
    g_46 = (l_45 != 1L);
    return l_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_13 g_33 g_42
 * writes: g_14 g_33 g_41
 */
static int64_t  func_4(int32_t  p_5, uint64_t  p_6, int16_t  p_7)
{ /* block id: 1 */
    int16_t l_17 = (-1L);
    int32_t l_18[4] = {3L,3L,3L,3L};
    uint64_t l_43[7] = {0x99B96BC712BAD479LL,0x332E0C280563ADE4LL,0x332E0C280563ADE4LL,0x99B96BC712BAD479LL,0x332E0C280563ADE4LL,0x332E0C280563ADE4LL,0x99B96BC712BAD479LL};
    int64_t l_44 = (-1L);
    int i;
    l_18[1] = (safe_add_func_int8_t_s_s((l_17 <= 0x65B49D585ED06576LL), g_14));
    p_5 = (safe_add_func_uint16_t_u_u((((func_21((safe_mul_func_int8_t_s_s(g_13, p_6))) & g_42) , g_14) , 0x4D46L), l_43[0]));
    l_44 = ((((g_33 > p_5) > g_13) <= 65529UL) ^ g_33);
    return g_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_13 g_33
 * writes: g_14 g_33 g_41
 */
static uint8_t  func_21(int32_t  p_22)
{ /* block id: 3 */
    uint8_t l_25[6];
    int32_t l_28 = (-1L);
    int32_t l_30 = 0xD10CAAD9L;
    int i;
    for (i = 0; i < 6; i++)
        l_25[i] = 255UL;
    for (g_14 = 5; (g_14 >= 1); g_14 -= 1)
    { /* block id: 6 */
        uint16_t l_26 = 0xEC00L;
        int32_t l_29 = 6L;
        int32_t l_31 = 0xA3DE81D5L;
        int32_t l_32 = 0x30F888C5L;
        if ((p_22 , g_13))
        { /* block id: 7 */
            int8_t l_27 = 0xD1L;
            l_26 = ((p_22 , (-1L)) | l_25[1]);
            g_33++;
            if (l_32)
                continue;
        }
        else
        { /* block id: 11 */
            uint32_t l_36 = 0xB6749EFEL;
            if (p_22)
                break;
            l_36--;
            if (l_25[4])
                continue;
            g_41[3] = (safe_mul_func_int8_t_s_s((-7L), 252UL));
        }
    }
    return g_33;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_41[i], "g_41[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 10
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 12
XXX percentage of non-volatile access: 90

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 1
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 45.5
XXX percentage an existing variable is used: 54.5
********************* end of statistics **********************/

