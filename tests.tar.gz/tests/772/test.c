/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4561458486147346342
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_3 = 0L;/* VOLATILE GLOBAL g_3 */
static int64_t g_7[8] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
static volatile uint64_t g_8 = 0xC08872FA4AD744D0LL;/* VOLATILE GLOBAL g_8 */
static uint32_t g_16 = 1UL;
static volatile uint64_t g_25 = 0xBB1A88AF16DE6EABLL;/* VOLATILE GLOBAL g_25 */
static uint16_t g_33 = 0x657CL;
static uint64_t g_34 = 1UL;
static volatile uint64_t g_39 = 18446744073709551615UL;/* VOLATILE GLOBAL g_39 */
static int32_t g_69 = (-1L);
static volatile uint64_t g_70 = 0UL;/* VOLATILE GLOBAL g_70 */
static volatile int8_t g_77 = 0L;/* VOLATILE GLOBAL g_77 */
static int64_t g_80 = 0L;
static uint8_t g_82 = 1UL;
static int64_t g_86 = 7L;
static int16_t g_95 = 1L;
static int32_t g_101[6] = {0x345427DAL,0x345427DAL,0x345427DAL,0x345427DAL,0x345427DAL,0x345427DAL};
static uint8_t g_110 = 0x04L;
static int16_t g_120 = 0x1EE0L;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_11(const uint8_t  p_12);
static int32_t  func_30(uint16_t  p_31);
static uint64_t  func_65(uint32_t  p_66);
static int64_t  func_97(uint64_t  p_98);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_3 g_25 g_16 g_7 g_39 g_34 g_70 g_82 g_86 g_69 g_80 g_101 g_77 g_110 g_120
 * writes: g_8 g_16 g_25 g_33 g_34 g_39 g_69 g_70 g_82 g_86 g_95 g_80 g_101 g_110 g_120
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0xAC789480L;
    int32_t l_4 = 0L;
    int32_t l_5 = 0x4D2EDC75L;
    int32_t l_6 = 0xA9D19AC1L;
    int16_t l_118 = 4L;
    uint16_t l_119[3][3];
    uint8_t l_121 = 0x0EL;
    int i, j;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
            l_119[i][j] = 0UL;
    }
    ++g_8;
    if (func_11((((4294967295UL < 5L) , l_4) | l_4)))
    { /* block id: 52 */
        for (g_69 = (-7); (g_69 != 28); g_69 = safe_add_func_int8_t_s_s(g_69, 7))
        { /* block id: 55 */
            l_4 = ((safe_rshift_func_uint16_t_u_u((g_7[6] & 4294967286UL), l_6)) & 0xD0F05760L);
        }
        for (l_6 = 11; (l_6 >= (-8)); --l_6)
        { /* block id: 60 */
            uint32_t l_96 = 0x731193F7L;
            uint8_t l_109 = 0UL;
            g_95 = (safe_div_func_uint64_t_u_u(func_30(l_2), g_86));
            if (l_96)
                break;
            g_110 = (func_97(((l_96 , 65530UL) , l_2)) , l_109);
        }
    }
    else
    { /* block id: 79 */
        uint32_t l_113[6] = {18446744073709551612UL,18446744073709551615UL,18446744073709551615UL,18446744073709551612UL,18446744073709551615UL,18446744073709551615UL};
        int i;
        l_5 = ((safe_add_func_uint32_t_u_u(0x09DF947BL, 0xCF223CDCL)) , g_110);
        --l_113[3];
    }
    g_120 |= ((((((safe_add_func_int8_t_s_s(l_2, 1UL)) & 0x970CE46CL) , l_4) <= l_118) > g_8) & l_119[2][0]);
    l_121 = g_69;
    return l_119[2][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_3 g_25 g_16 g_7 g_39 g_34 g_70 g_82 g_86
 * writes: g_16 g_25 g_33 g_34 g_39 g_69 g_70 g_82 g_86
 */
static int32_t  func_11(const uint8_t  p_12)
{ /* block id: 2 */
    int64_t l_15 = (-8L);
    uint16_t l_21 = 0x8E04L;
    int32_t l_22 = 0x83BBB66EL;
    int8_t l_57 = 0x2DL;
    g_16 = (safe_mod_func_uint64_t_u_u(p_12, l_15));
    l_22 = ((safe_div_func_uint32_t_u_u(((safe_rshift_func_int8_t_s_s((((l_21 != (-8L)) , 65526UL) , g_8), 7)) , g_3), l_21)) == 1L);
    for (l_21 = 0; (l_21 <= 2); l_21++)
    { /* block id: 7 */
        const uint32_t l_53 = 0xC132D45AL;
        int32_t l_54[8] = {0xA55CCBD9L,0x11A6C9C6L,0x11A6C9C6L,0xA55CCBD9L,0x11A6C9C6L,0x11A6C9C6L,0xA55CCBD9L,0x11A6C9C6L};
        int i;
        --g_25;
        for (g_16 = (-23); (g_16 > 39); g_16 = safe_add_func_int64_t_s_s(g_16, 5))
        { /* block id: 11 */
            l_22 = func_30(p_12);
            l_22 = ((safe_div_func_int16_t_s_s(((safe_div_func_int64_t_s_s((p_12 , 0xA3D85AA7F794FC7BLL), g_8)) || 9UL), l_53)) | 0xA95AL);
        }
        l_54[4] = (((func_30(g_16) && p_12) , 5L) < l_53);
        l_57 = (((safe_add_func_int64_t_s_s(l_54[0], l_53)) < g_34) <= p_12);
    }
    g_86 &= (((safe_div_func_uint64_t_u_u((~(((~(safe_div_func_uint8_t_u_u(((~(((func_65(g_7[1]) || p_12) & g_7[4]) ^ 0L)) , l_21), l_15))) == p_12) , 0L)), 0x6935E7B049BDD3DELL)) && (-7L)) == p_12);
    return l_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_39 g_34 g_8
 * writes: g_33 g_34 g_39
 */
static int32_t  func_30(uint16_t  p_31)
{ /* block id: 12 */
    uint16_t l_32 = 0UL;
    int32_t l_37 = 0xD748AEE5L;
    g_33 = (g_7[1] , l_32);
    g_34 = (0x2742L >= p_31);
    for (p_31 = 0; (p_31 == 2); ++p_31)
    { /* block id: 17 */
        uint8_t l_44[6][5] = {{0x7EL,0x7EL,0xBCL,0x7EL,0x7EL},{247UL,255UL,247UL,247UL,0x07L},{0x7EL,0xE9L,0xE9L,0x7EL,0xE9L},{0x07L,255UL,9UL,247UL,247UL},{0xBCL,0xE9L,0xBCL,0xBCL,0xE9L},{247UL,255UL,9UL,247UL,9UL}};
        int i, j;
        for (l_32 = 0; (l_32 <= 7); l_32 += 1)
        { /* block id: 20 */
            int32_t l_38 = 0x0EEB4983L;
            int i;
            ++g_39;
            l_37 &= (0xF44FB66CL >= g_7[l_32]);
        }
        l_37 = ((((safe_sub_func_uint32_t_u_u(((((g_39 && 0x7771L) != p_31) | p_31) | 0x76L), l_44[0][4])) , l_32) >= g_34) , l_44[2][3]);
        for (l_32 = 3; (l_32 < 39); l_32 = safe_add_func_int64_t_s_s(l_32, 6))
        { /* block id: 27 */
            return g_8;
        }
    }
    l_37 &= (safe_div_func_int64_t_s_s(0xC09C4F4FCF427579LL, 1L));
    return g_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_70 g_82
 * writes: g_69 g_70 g_82
 */
static uint64_t  func_65(uint32_t  p_66)
{ /* block id: 39 */
    uint16_t l_74 = 0UL;
    int32_t l_78 = 0xD5381D84L;
    int32_t l_79 = 1L;
    int32_t l_81[4][6][2] = {{{0x35737360L,0xB9571DA8L},{(-1L),0xB9571DA8L},{0x35737360L,(-1L)},{0x5FA60710L,0x5FA60710L},{1L,0x1F40AC15L},{0x35737360L,0L}},{{0x1F40AC15L,0xB9571DA8L},{0L,0x1F40AC15L},{0x5FA60710L,1L},{0x5FA60710L,0x1F40AC15L},{0L,0xB9571DA8L},{0x1F40AC15L,0L}},{{0x35737360L,0x1F40AC15L},{1L,0x5FA60710L},{0x5FA60710L,(-1L)},{0x35737360L,0xB9571DA8L},{(-1L),0xB9571DA8L},{0x35737360L,(-1L)}},{{0x5FA60710L,0x5FA60710L},{1L,0x1F40AC15L},{0x35737360L,0L},{0x1F40AC15L,0xB9571DA8L},{0L,0x1F40AC15L},{0x5FA60710L,1L}}};
    uint32_t l_85 = 8UL;
    int i, j, k;
    for (p_66 = 14; (p_66 == 56); p_66 = safe_add_func_uint16_t_u_u(p_66, 8))
    { /* block id: 42 */
        g_69 = 0x7CEE7E28L;
    }
    if (p_66)
        goto lbl_73;
lbl_73:
    --g_70;
    l_74++;
    --g_82;
    return l_85;
}


/* ------------------------------------------ */
/* 
 * reads : g_80 g_7 g_101 g_69 g_77
 * writes: g_80 g_101 g_69
 */
static int64_t  func_97(uint64_t  p_98)
{ /* block id: 63 */
    uint16_t l_100 = 1UL;
    int32_t l_102 = 0L;
    uint8_t l_107[2][10][9] = {{{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL}},{{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,255UL,255UL,255UL},{0x60L,9UL,255UL,9UL,0x60L,255UL,0x6DL,0x6DL,255UL},{0x78L,0x31L,255UL,0x31L,0x78L,255UL,0x6DL,0x6DL,255UL},{0x78L,0x31L,255UL,0x31L,0x78L,255UL,0x6DL,0x6DL,255UL},{0x78L,0x31L,255UL,0x31L,0x78L,255UL,0x6DL,0x6DL,255UL},{0x78L,0x31L,255UL,0x31L,0x78L,255UL,0x6DL,0x6DL,255UL},{0x78L,0x31L,255UL,0x31L,0x78L,255UL,0x6DL,0x6DL,255UL}}};
    int16_t l_108 = 0x28C1L;
    int i, j, k;
    for (g_80 = 1; (g_80 <= 7); g_80 += 1)
    { /* block id: 66 */
        int i;
        g_101[0] &= ((((!(((g_7[g_80] > 0x9AC7L) > p_98) & p_98)) <= g_80) != 0x21FDCAA3L) , l_100);
        for (g_69 = 7; (g_69 >= 0); g_69 -= 1)
        { /* block id: 70 */
            return g_69;
        }
    }
    l_102 = (0x7ACEL < 0xEFA8L);
    l_108 = ((((safe_lshift_func_uint8_t_u_u((((safe_add_func_uint8_t_u_u(((-1L) || p_98), 5L)) , 0xE17DL) == 0x050BL), p_98)) , 0x6E721E45L) || l_100) || l_107[1][8][4]);
    return g_77;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_101[i], "g_101[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 47
   depth: 2, occurrence: 17
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 71
XXX times a non-volatile is write: 35
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 48
XXX percentage of non-volatile access: 90.6

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 49
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 25
   depth: 1, occurrence: 14
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 42.3
XXX percentage an existing variable is used: 57.7
********************* end of statistics **********************/

