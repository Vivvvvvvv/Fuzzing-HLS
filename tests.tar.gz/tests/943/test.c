/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17413588201419484226
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_7 = 5UL;
static int16_t g_25 = 0xADC6L;
static uint8_t g_34 = 1UL;
static uint8_t g_54 = 1UL;
static int64_t g_60 = 0xF164E9E2562E968FLL;
static uint32_t g_89 = 0UL;
static volatile uint8_t g_91[7][10][3] = {{{0xCBL,0x67L,0x33L},{0x83L,7UL,0xEAL},{0xCBL,0x18L,0xE4L},{0x6CL,5UL,0x83L},{0x83L,254UL,255UL},{252UL,0xF8L,255UL},{252UL,3UL,252UL},{0x83L,250UL,0xEFL},{0x6CL,248UL,0xA1L},{0xCBL,0UL,6UL}},{{0x83L,0x3BL,255UL},{0xCBL,0x10L,0x5CL},{0x6CL,254UL,0x4BL},{0x83L,0x7DL,0x82L},{252UL,0UL,0UL},{252UL,1UL,0UL},{0xCBL,0xCBL,255UL},{4UL,255UL,1UL},{0UL,0x29L,246UL},{0xCBL,0x4BL,0x96L}},{{0UL,0xE4L,255UL},{4UL,0x1BL,255UL},{0xCBL,6UL,0x85L},{0x79L,248UL,1UL},{0x79L,6UL,4UL},{0xCBL,252UL,0x8BL},{4UL,247UL,0xB1L},{0UL,0x82L,0xCFL},{0xCBL,0x83L,0x3FL},{0UL,250UL,0xE3L}},{{4UL,255UL,0xCBL},{0xCBL,0x33L,0xA0L},{0x79L,0x80L,0UL},{0x79L,0xEFL,0x79L},{0xCBL,0x6CL,0xA0L},{4UL,0UL,254UL},{0UL,255UL,1UL},{0xCBL,250UL,1UL},{0UL,0x5CL,255UL},{4UL,0xEAL,1UL}},{{0xCBL,1UL,249UL},{0x79L,0xA1L,0xD7L},{0x79L,1UL,0UL},{0xCBL,0xCBL,255UL},{4UL,255UL,1UL},{0UL,0x29L,246UL},{0xCBL,0x4BL,0x96L},{0UL,0xE4L,255UL},{4UL,0x1BL,255UL},{0xCBL,6UL,0x85L}},{{0x79L,248UL,1UL},{0x79L,6UL,4UL},{0xCBL,252UL,0x8BL},{4UL,247UL,0xB1L},{0UL,0x82L,0xCFL},{0xCBL,0x83L,0x3FL},{0UL,250UL,0xE3L},{4UL,255UL,0xCBL},{0xCBL,0x33L,0xA0L},{0x79L,0x80L,0UL}},{{0x79L,0xEFL,0x79L},{0xCBL,0x6CL,0xA0L},{4UL,0UL,254UL},{0UL,255UL,1UL},{0xCBL,250UL,1UL},{0UL,0x5CL,255UL},{4UL,0xEAL,1UL},{0xCBL,1UL,249UL},{0x79L,0xA1L,0xD7L},{0x79L,1UL,0UL}}};
static uint64_t g_95 = 8UL;
static int32_t g_97[8] = {0xD117829FL,0x7FA6F0C6L,0xD117829FL,0xD117829FL,0x7FA6F0C6L,0xD117829FL,0xD117829FL,0x7FA6F0C6L};
static uint32_t g_98 = 1UL;
static uint32_t g_102[7][1][2] = {{{0x68497F57L,18446744073709551615UL}},{{0x216E9B38L,18446744073709551615UL}},{{0x68497F57L,0x216E9B38L}},{{7UL,7UL}},{{7UL,0x216E9B38L}},{{0x68497F57L,18446744073709551615UL}},{{0x216E9B38L,18446744073709551615UL}}};
static uint64_t g_104[9] = {0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL,0xEA743E715EE1BD55LL};
static uint32_t g_111 = 0x2A7E1DD4L;
static int32_t g_118 = 0L;
static int32_t g_125 = 4L;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint32_t  func_2(int8_t  p_3, uint32_t  p_4, int8_t  p_5);
static uint64_t  func_10(uint32_t  p_11, uint32_t  p_12);
static int32_t  func_30(int8_t  p_31, uint32_t  p_32, int16_t  p_33);
static int32_t  func_38(uint64_t  p_39, uint16_t  p_40, int16_t  p_41, uint32_t  p_42, int64_t  p_43);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_25 g_34 g_54 g_60 g_89 g_91 g_98 g_102 g_104 g_111 g_118 g_125 g_95
 * writes: g_25 g_7 g_34 g_54 g_60 g_89 g_91 g_95 g_98 g_102 g_104 g_111 g_118 g_125
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int8_t l_6[9][9][3] = {{{0x9BL,0xE7L,0x05L},{0xA8L,(-9L),0x14L},{0x31L,0L,0x9EL},{0x3EL,5L,5L},{0x31L,(-10L),1L},{0xA8L,0xD1L,0x19L},{0x9BL,1L,0x31L},{1L,0x14L,5L},{1L,1L,0x6FL}},{{1L,0xD1L,0x0CL},{0L,(-10L),0x3DL},{0x19L,5L,0xD1L},{0x3DL,0L,0x3DL},{1L,(-9L),0x0CL},{(-1L),0xE7L,0x6FL},{5L,1L,5L},{0xC9L,0x31L,0x31L},{5L,0xCDL,0x19L}},{{(-1L),0x5AL,1L},{1L,0x19L,5L},{0x3DL,0x6FL,0x9EL},{0x19L,0x19L,0x14L},{0L,0x5AL,0x05L},{1L,0xCDL,1L},{1L,0x31L,0x5AL},{1L,1L,1L},{0x9BL,0xE7L,0x05L}},{{0xA8L,(-9L),0x14L},{0x31L,0L,0x9EL},{0x3EL,5L,5L},{0x31L,(-10L),1L},{0xA8L,0xD1L,0x19L},{0x9BL,1L,0x31L},{1L,0x14L,5L},{1L,1L,0x6FL},{1L,0xD1L,0x0CL}},{{0L,(-10L),0x3DL},{0x19L,5L,0xD1L},{0x3DL,0L,0x3DL},{1L,(-9L),0x0CL},{(-1L),0xE7L,0x6FL},{5L,1L,5L},{0xC9L,0x31L,0x31L},{5L,0xCDL,0x19L},{(-1L),0x5AL,1L}},{{1L,0x19L,5L},{0x3DL,0x6FL,0x9EL},{0x19L,0x19L,0x14L},{0L,0x5AL,0x05L},{1L,0xCDL,1L},{1L,0x31L,0x5AL},{1L,1L,1L},{0x9BL,0xE7L,0x05L},{0xA8L,(-9L),0x14L}},{{0x31L,0L,0x9EL},{0x3EL,5L,5L},{0x31L,(-10L),1L},{0xA8L,0xD1L,0x19L},{0x9BL,1L,0x31L},{1L,0x14L,5L},{1L,1L,0x6FL},{1L,0xD1L,0x0CL},{0x9BL,0x05L,0x5AL}},{{0x14L,0x3EL,5L},{0x5AL,0x9BL,0x5AL},{(-9L),0xCDL,5L},{0x3DL,(-10L),0L},{0x3EL,1L,0xA8L},{1L,0xC9L,0xC9L},{0x3EL,0x0CL,0x14L},{0x3DL,0x31L,0x6FL},{(-9L),0x14L,0x3EL}},{{0x5AL,0L,(-1L)},{0x14L,0x14L,1L},{0x9BL,0x31L,0x9EL},{1L,0x0CL,0xD1L},{0x6FL,0xC9L,0x31L},{0xD1L,1L,0xD1L},{0xE7L,(-10L),0x9EL},{1L,0xCDL,1L},{0xC9L,0x9BL,(-1L)}}};
    int32_t l_29 = 0xBD2E84CBL;
    int i, j, k;
    if ((((func_2(l_6[4][6][1], g_7, g_7) && 7UL) ^ 0x7A68FAB8D2321210LL) , l_6[2][5][2]))
    { /* block id: 17 */
        int32_t l_28[7][6] = {{0x06C0F1A0L,0x0284818AL,(-1L),0x0284818AL,0x06C0F1A0L,(-1L)},{0x0284818AL,0x06C0F1A0L,(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),0x06C0F1A0L,0x0284818AL,(-1L)},{0x06C0F1A0L,0x0284818AL,(-1L),0x0284818AL,0x06C0F1A0L,(-1L)},{0x0284818AL,0x06C0F1A0L,(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),0x06C0F1A0L,0x0284818AL,(-1L)},{0x06C0F1A0L,0x0284818AL,(-1L),0x0284818AL,0x06C0F1A0L,(-1L)}};
        int i, j;
        l_29 = (safe_div_func_uint64_t_u_u(g_7, l_28[3][3]));
        for (g_7 = 0; (g_7 <= 5); g_7 += 1)
        { /* block id: 21 */
            int32_t l_103 = 0x9B8081AEL;
            g_102[6][0][1] ^= func_30(l_6[1][0][1], g_7, l_28[3][3]);
            g_104[8] = l_103;
        }
        if (((safe_mod_func_uint64_t_u_u((safe_add_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(g_25, l_6[4][6][1])), g_104[6])), g_98)) < 0UL))
        { /* block id: 73 */
            g_111--;
        }
        else
        { /* block id: 75 */
            l_28[3][3] = (safe_rshift_func_uint16_t_u_u(((g_98 > g_98) != l_6[4][6][1]), 4));
            g_118 = ((safe_add_func_uint32_t_u_u((((g_98 && 0x5037CFC119431DCFLL) != g_25) <= 0xCAAA0BFB30C423CDLL), g_98)) & 0xE96A0B7F3AE84E38LL);
            l_28[3][3] |= ((0xF0L < 0xB9L) | 0x70CACEDFL);
        }
        l_28[6][1] = ((((4294967295UL | g_60) || l_29) , l_28[3][3]) != 2L);
    }
    else
    { /* block id: 81 */
        int32_t l_124 = 0x96A4FF77L;
        for (g_7 = 0; (g_7 > 50); g_7 = safe_add_func_int8_t_s_s(g_7, 9))
        { /* block id: 84 */
            g_125 &= ((!(safe_sub_func_uint8_t_u_u(((g_118 ^ l_124) ^ (-3L)), 0x0CL))) >= g_91[0][8][1]);
        }
        return g_102[1][0][0];
    }
    l_29 |= (safe_div_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((safe_lshift_func_int16_t_s_s(l_6[4][6][1], 13)), l_6[0][1][0])), g_95));
    return g_98;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_25
 * writes: g_25
 */
static uint32_t  func_2(int8_t  p_3, uint32_t  p_4, int8_t  p_5)
{ /* block id: 1 */
    int16_t l_13 = 6L;
    g_25 &= ((safe_div_func_int64_t_s_s((func_10(p_4, l_13) == g_7), 1UL)) & 255UL);
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes:
 */
static uint64_t  func_10(uint32_t  p_11, uint32_t  p_12)
{ /* block id: 2 */
    int8_t l_16 = 0xA3L;
    int32_t l_21[1];
    int i;
    for (i = 0; i < 1; i++)
        l_21[i] = 1L;
    for (p_12 = (-26); (p_12 < 6); p_12++)
    { /* block id: 5 */
        l_16 = 4L;
    }
    l_21[0] = (safe_rshift_func_int16_t_s_s((safe_mod_func_uint64_t_u_u(0UL, 0x2CCD2044653FFD03LL)), 1));
    for (p_11 = (-17); (p_11 == 13); ++p_11)
    { /* block id: 11 */
        uint32_t l_24 = 0xE712C519L;
        l_24 |= p_12;
    }
    return g_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_25 g_54 g_7 g_60 g_89 g_91 g_98
 * writes: g_34 g_54 g_60 g_89 g_91 g_95 g_98
 */
static int32_t  func_30(int8_t  p_31, uint32_t  p_32, int16_t  p_33)
{ /* block id: 22 */
    int32_t l_37[6][6][7] = {{{(-8L),0x81FF7B51L,0xB81468F3L,0x1BF33464L,(-8L),(-2L),0x1BF33464L},{(-6L),0x040642FCL,0x06680214L,0x240E6013L,5L,1L,(-4L)},{(-1L),(-5L),0L,0x9D7FCCEAL,0xF25AD92EL,0x270BB1DCL,0L},{0xBD42F903L,0x240E6013L,0x469FD68CL,0xDE6A6B93L,1L,1L,7L},{(-8L),0x8409D7FFL,0x270BB1DCL,(-5L),(-1L),0x8409D7FFL,0xDB0E1D9DL},{0xFF2F0833L,0x240E6013L,(-9L),0xDFCA599FL,0x7CF3D009L,0x65B818E9L,5L}},{{0x6F7EBA05L,(-5L),(-9L),0x81FF7B51L,0x81FF7B51L,(-9L),(-5L)},{7L,0x040642FCL,0x6A5F6804L,(-8L),1L,0xDFCA599FL,1L},{0x1BECDE87L,0x81FF7B51L,0x270BB1DCL,3L,0xF25AD92EL,0x1BECDE87L,0x270BB1DCL},{0x7CF3D009L,0xE11E5463L,8L,(-8L),0x5A0349B8L,0x073E42CDL,0x7CF3D009L},{(-8L),0x270BB1DCL,0L,0x81FF7B51L,0x8409D7FFL,3L,0x1BF33464L},{0x352544EEL,0x2D1E5678L,0x352544EEL,0xDFCA599FL,7L,1L,1L}},{{0x81FF7B51L,0xF25AD92EL,0xB81468F3L,(-5L),0xF25AD92EL,0xE410F713L,(-5L)},{(-6L),1L,0x6A83B1D3L,0xE3FF50EDL,0x86E024B1L,0x2DD31843L,0x06680214L},{0xE410F713L,0x270BB1DCL,(-9L),(-7L),0x1BECDE87L,1L,1L},{0x0D3D7FBAL,1L,1L,1L,0x0D3D7FBAL,0x240E6013L,0x352544EEL},{0x9D7FCCEAL,(-2L),0xB81468F3L,3L,(-10L),(-6L),3L},{0x6A83B1D3L,0x65B818E9L,0xCEF36AA1L,0xF5B04CE9L,0xFF2F0833L,1L,0x86E024B1L}},{{0x9D7FCCEAL,3L,(-1L),0x9D7FCCEAL,0x8409D7FFL,(-5L),3L},{0x0D3D7FBAL,2L,0xFD7422E2L,0x040642FCL,0xFD7422E2L,2L,0x0D3D7FBAL},{0xE410F713L,0x1BECDE87L,0x4CEAA963L,(-9L),(-1L),0xE410F713L,(-9L)},{(-9L),0x65B818E9L,1L,1L,0x06680214L,(-8L),0xFF2F0833L},{0x1BECDE87L,(-1L),0x4CEAA963L,0x0DAEFF8EL,(-2L),(-9L),3L},{0x60EE42ACL,1L,0xFD7422E2L,0x2DD31843L,(-1L),0x2DD31843L,0xFD7422E2L}},{{(-1L),(-1L),(-1L),0L,0x1BECDE87L,0x81FF7B51L,0x270BB1DCL},{5L,1L,0xCEF36AA1L,1L,8L,2L,0x06680214L},{(-6L),3L,0xB81468F3L,(-10L),0x1BECDE87L,0xB81468F3L,(-1L)},{0x352544EEL,0x65B818E9L,1L,0x040642FCL,(-1L),0xDE6A6B93L,(-1L)},{0x9D7FCCEAL,(-10L),(-9L),0L,(-2L),(-6L),3L},{8L,0xDFCA599FL,0x6A83B1D3L,0xF5B04CE9L,0x06680214L,2L,8L}},{{(-1L),3L,(-5L),0x1BECDE87L,(-1L),0x1BF33464L,3L},{0x6A5F6804L,0x073E42CDL,0x60EE42ACL,1L,0xFD7422E2L,0x2DD31843L,(-1L)},{(-10L),0x8409D7FFL,0x4CEAA963L,0x4CEAA963L,0x8409D7FFL,(-10L),(-1L)},{(-9L),1L,(-6L),0xE3FF50EDL,0xFF2F0833L,(-8L),0x06680214L},{(-1L),1L,(-9L),0x0DAEFF8EL,(-10L),1L,0x270BB1DCL},{0x469FD68CL,1L,0x8A21DEC7L,1L,0x0D3D7FBAL,2L,0xFD7422E2L}}};
    int8_t l_79 = 0xF7L;
    int32_t l_88 = 0x2C1772BCL;
    int i, j, k;
    g_34 &= (p_33 >= p_32);
    for (p_33 = 0; (p_33 != 4); ++p_33)
    { /* block id: 26 */
        return l_37[5][1][3];
    }
    if (func_38(((safe_mod_func_int8_t_s_s((safe_div_func_uint16_t_u_u(((g_34 , p_32) && 1UL), 0xC5EBL)), 255UL)) || 0x6EA7L), g_34, l_37[2][4][2], g_25, l_37[5][4][0]))
    { /* block id: 42 */
        uint32_t l_59 = 18446744073709551606UL;
        for (g_34 = 0; (g_34 < 2); g_34++)
        { /* block id: 45 */
            if (g_7)
                break;
        }
        g_60 ^= (!(((l_37[2][3][0] <= l_59) <= g_34) && 0xB6A5CECFL));
        l_37[4][1][4] = (safe_sub_func_uint32_t_u_u((g_7 == p_33), g_60));
    }
    else
    { /* block id: 50 */
        int8_t l_65 = 0xCCL;
        int32_t l_70 = (-3L);
        int32_t l_90 = 0x2712D857L;
        l_37[0][5][3] = (safe_sub_func_uint16_t_u_u(l_65, l_65));
        if ((safe_mod_func_int16_t_s_s((safe_mod_func_int16_t_s_s(l_37[4][0][4], l_70)), 0xABFDL)))
        { /* block id: 52 */
            l_79 = (safe_mul_func_uint8_t_u_u((safe_div_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(((((safe_div_func_int64_t_s_s((-1L), g_7)) | p_31) == g_34) , p_32), g_25)), 0xE7CE4607L)), 255UL));
        }
        else
        { /* block id: 54 */
lbl_101:
            l_37[5][1][3] |= g_54;
        }
        if ((safe_lshift_func_uint16_t_u_u(((safe_mod_func_uint16_t_u_u(((g_54 && 5UL) || 0xC0L), l_79)) || p_31), 14)))
        { /* block id: 57 */
            int32_t l_87 = 9L;
            g_89 |= ((safe_mul_func_int16_t_s_s(((((~p_33) <= l_65) || l_37[5][1][3]) < l_87), l_88)) != p_33);
            l_90 = ((l_65 , g_89) > (-1L));
            g_91[6][6][2]--;
            l_90 = l_87;
        }
        else
        { /* block id: 62 */
            uint8_t l_94 = 0x46L;
            int32_t l_96 = 4L;
            g_95 = l_94;
            g_98++;
            return g_54;
        }
        if (l_70)
            goto lbl_101;
    }
    return l_79;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_54
 * writes: g_34 g_54
 */
static int32_t  func_38(uint64_t  p_39, uint16_t  p_40, int16_t  p_41, uint32_t  p_42, int64_t  p_43)
{ /* block id: 29 */
    int32_t l_53 = 0xE3094FC7L;
    int32_t l_55[3];
    int i;
    for (i = 0; i < 3; i++)
        l_55[i] = 0x064EC4FEL;
    for (g_34 = 10; (g_34 < 53); ++g_34)
    { /* block id: 32 */
        uint8_t l_50[4];
        int i;
        for (i = 0; i < 4; i++)
            l_50[i] = 0x2EL;
        l_50[3] = p_40;
        g_54 = ((safe_rshift_func_uint16_t_u_u(p_39, l_53)) && p_40);
        if ((g_54 ^ 251UL))
        { /* block id: 35 */
            return g_54;
        }
        else
        { /* block id: 37 */
            l_55[0] = p_43;
        }
    }
    return p_43;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_91[i][j][k], "g_91[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_95, "g_95", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_97[i], "g_97[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_98, "g_98", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_102[i][j][k], "g_102[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_104[i], "g_104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 37
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 51
   depth: 2, occurrence: 11
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 92
XXX times a non-volatile is write: 35
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 98.4

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 53
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 19
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 31.4
XXX percentage an existing variable is used: 68.6
********************* end of statistics **********************/

