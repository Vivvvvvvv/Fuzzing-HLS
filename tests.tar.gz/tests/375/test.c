/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3505503952055519275
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_13 = 0L;
static uint64_t g_16 = 0x8ACE4B0AD8EA5F34LL;
static volatile uint32_t g_25 = 18446744073709551615UL;/* VOLATILE GLOBAL g_25 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint8_t  func_8(const uint64_t  p_9, int32_t  p_10);
static int64_t  func_33(int32_t  p_34, int32_t  p_35);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_16 g_25
 * writes: g_16 g_25
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_14 = (-1L);
    uint32_t l_26[9][7] = {{0xAF03FA9AL,0xF19195C5L,18446744073709551615UL,18446744073709551615UL,0xF19195C5L,0xAF03FA9AL,0xF19195C5L},{8UL,18446744073709551615UL,0x576DBD8DL,2UL,18446744073709551615UL,2UL,0x576DBD8DL},{0x41536C74L,0x41536C74L,0xAF03FA9AL,18446744073709551615UL,0xAF03FA9AL,0x41536C74L,0x41536C74L},{0UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,0UL,0x8CB5C746L,0x576DBD8DL},{18446744073709551610UL,0xF19195C5L,18446744073709551610UL,0xAF03FA9AL,0xAF03FA9AL,18446744073709551610UL,0xF19195C5L},{0x576DBD8DL,0x9FCB6EA4L,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551610UL,0xAF03FA9AL,0xAF03FA9AL,18446744073709551610UL,0x41536C74L,18446744073709551615UL,18446744073709551610UL},{0x576DBD8DL,18446744073709551615UL,8UL,0x9FCB6EA4L,8UL,18446744073709551615UL,0x576DBD8DL},{0xAF03FA9AL,18446744073709551610UL,0xF19195C5L,18446744073709551610UL,0xAF03FA9AL,0xAF03FA9AL,18446744073709551610UL}};
    int32_t l_50 = 0x0B09DE24L;
    int i, j;
    if (((safe_mul_func_uint16_t_u_u(((((safe_add_func_uint16_t_u_u((func_8((((safe_div_func_uint64_t_u_u((g_13 ^ l_14), 1UL)) > 18446744073709551611UL) | 0x2DL), g_13) , 0UL), 65535UL)) ^ l_14) & 0UL) & l_14), 65535UL)) | 0x2C5DL))
    { /* block id: 4 */
        uint16_t l_20 = 0x18F4L;
        int64_t l_23 = 0L;
        int32_t l_24[3][6] = {{1L,0xD790F958L,1L,1L,0xD790F958L,1L},{1L,0xD790F958L,1L,1L,0xD790F958L,1L},{1L,0xD790F958L,1L,1L,0xD790F958L,1L}};
        int i, j;
        l_20 = (safe_lshift_func_uint8_t_u_u((((((g_13 != 0x3DL) & 0xCBL) == g_13) > 0x9A5A165F5C9B8DB3LL) , 0UL), 1));
        for (l_20 = 10; (l_20 == 29); l_20 = safe_add_func_int32_t_s_s(l_20, 3))
        { /* block id: 8 */
            l_24[1][4] = l_23;
        }
    }
    else
    { /* block id: 11 */
        int8_t l_30 = 0x5FL;
lbl_27:
        g_25 = 0x3FB18BA7L;
        for (l_14 = 6; (l_14 >= 0); l_14 -= 1)
        { /* block id: 15 */
            if (g_13)
                goto lbl_27;
        }
        for (g_16 = 0; (g_16 == 19); g_16 = safe_add_func_int16_t_s_s(g_16, 1))
        { /* block id: 20 */
            l_30 = g_13;
        }
        l_50 = ((safe_sub_func_int64_t_s_s(func_33(l_30, g_13), l_14)) > g_25);
    }
    return g_25;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_16
 */
static uint8_t  func_8(const uint64_t  p_9, int32_t  p_10)
{ /* block id: 1 */
    const int64_t l_15 = 0x6F885EA6EDAD94E8LL;
    int32_t l_17 = 0x8D96753FL;
    g_16 = l_15;
    return l_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_16
 * writes: g_16
 */
static int64_t  func_33(int32_t  p_34, int32_t  p_35)
{ /* block id: 23 */
    uint16_t l_38 = 65535UL;
    int32_t l_39 = 0x30833618L;
lbl_49:
    l_39 = (safe_mod_func_int64_t_s_s((-9L), l_38));
    for (p_35 = 0; (p_35 == 1); p_35 = safe_add_func_int8_t_s_s(p_35, 3))
    { /* block id: 27 */
        uint32_t l_44[8][1][1] = {{{0x76A90D26L}},{{1UL}},{{0x76A90D26L}},{{1UL}},{{0x76A90D26L}},{{1UL}},{{0x76A90D26L}},{{1UL}}};
        int8_t l_45 = (-9L);
        int32_t l_47 = 1L;
        int i, j, k;
        for (p_34 = 20; (p_34 > 9); p_34--)
        { /* block id: 30 */
            int16_t l_46 = (-3L);
            int32_t l_48 = 0xFFEA059EL;
            l_39 = func_8((((0x265DL || l_44[3][0][0]) <= l_45) <= 0xCEC4L), g_13);
            l_47 = l_46;
            l_48 = ((-9L) < g_16);
            if (l_38)
                goto lbl_49;
        }
    }
    return p_35;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 7
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 14
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 11
XXX percentage of non-volatile access: 93

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 7
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 54.5
XXX percentage an existing variable is used: 45.5
********************* end of statistics **********************/

