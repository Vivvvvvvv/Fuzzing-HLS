/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16463578368865974518
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[3] = {(-3L),(-3L),(-3L)};
static uint64_t g_3 = 0x19C5A654FDDD3F46LL;
static uint32_t g_5 = 0x82D83D78L;
static uint32_t g_20 = 0UL;
static uint64_t g_21 = 0xE67684593F6A0837LL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_9(int64_t  p_10, int32_t  p_11);
static int32_t  func_14(int32_t  p_15, int32_t  p_16, int16_t  p_17, const int16_t  p_18, int8_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_5 g_20 g_21
 * writes: g_3 g_5 g_20 g_21
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_12 = 0x8E486AEBL;
    int32_t l_22 = (-1L);
    int16_t l_25 = 4L;
    g_3 = (g_2[2] && g_2[2]);
    for (g_3 = 0; (g_3 <= 2); g_3 += 1)
    { /* block id: 4 */
        int i;
        return g_2[g_3];
    }
    g_5 ^= ((+g_2[2]) > 0x25FCC58A012E1DFELL);
    for (g_3 = 0; (g_3 == 35); g_3 = safe_add_func_uint32_t_u_u(g_3, 1))
    { /* block id: 10 */
        uint8_t l_8 = 0x22L;
        int32_t l_23 = 0xE623B26DL;
        uint32_t l_24 = 0xA3D88101L;
        for (g_5 = 0; (g_5 <= 2); g_5 += 1)
        { /* block id: 13 */
            int i;
            l_8 |= (5UL >= 0x8CAFA32FD2D1A4E6LL);
            l_22 = func_9(g_2[g_5], l_12);
            l_23 = g_20;
        }
        l_22 = ((g_20 | 1UL) == g_21);
        if (l_22)
            break;
        if (l_24)
            break;
    }
    return l_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_5
 * writes: g_20 g_21
 */
static int32_t  func_9(int64_t  p_10, int32_t  p_11)
{ /* block id: 15 */
    int8_t l_13 = 0x29L;
    l_13 ^= 1L;
    g_20 = func_14(g_2[2], p_11, g_3, p_10, l_13);
    g_21 = p_10;
    return l_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes:
 */
static int32_t  func_14(int32_t  p_15, int32_t  p_16, int16_t  p_17, const int16_t  p_18, int8_t  p_19)
{ /* block id: 17 */
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 6
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 12
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 82.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 18
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 5
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 44.4
XXX percentage an existing variable is used: 55.6
********************* end of statistics **********************/

