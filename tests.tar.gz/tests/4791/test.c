/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1161147301370475796
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_2 = 0x5BAF43B7C7CE53D8LL;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0xEEDE0B40L;/* VOLATILE GLOBAL g_3 */
static uint32_t g_9 = 0x7249AAEDL;
static int32_t g_12 = (-1L);
static uint64_t g_35 = 0x494DFD99643747C9LL;
static volatile uint32_t g_40 = 18446744073709551615UL;/* VOLATILE GLOBAL g_40 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint32_t  func_13(int64_t  p_14, uint32_t  p_15, int16_t  p_16, const uint32_t  p_17, uint64_t  p_18);
static int8_t  func_19(uint32_t  p_20, uint32_t  p_21, uint32_t  p_22, int16_t  p_23, int64_t  p_24);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_12 g_3 g_35 g_40
 * writes: g_9 g_12 g_35 g_40
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_4 = 0UL;
    int32_t l_7 = 0xC5534BF8L;
    int32_t l_8[2];
    int i;
    for (i = 0; i < 2; i++)
        l_8[i] = 0xF7FBF212L;
    --l_4;
    l_7 = l_4;
    for (l_7 = 1; (l_7 >= 0); l_7 -= 1)
    { /* block id: 5 */
        uint8_t l_31 = 0xA4L;
        int32_t l_43 = 0x1D497C24L;
        for (l_4 = 0; (l_4 <= 1); l_4 += 1)
        { /* block id: 8 */
            int i;
            g_9 |= l_8[l_7];
            g_12 |= (safe_add_func_uint64_t_u_u(18446744073709551615UL, (-8L)));
            g_12 = l_8[l_4];
            g_12 = ((func_13((((func_19((safe_mul_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_u(0xFA4CL, l_8[l_7])) <= 0xA6AED1D2L), 0x193FE696L)), l_31)), g_12, g_3, g_12, l_8[l_7]) || 0x7DL) > g_12) < g_9), l_4, g_12, l_8[l_7], g_12) , 0x8991F32AFCB06A9BLL) || l_4);
        }
        l_43 = l_31;
        g_12 = (safe_mul_func_int16_t_s_s(l_43, l_31));
    }
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_40
 * writes: g_40
 */
static uint32_t  func_13(int64_t  p_14, uint32_t  p_15, int16_t  p_16, const uint32_t  p_17, uint64_t  p_18)
{ /* block id: 15 */
    int8_t l_38 = (-5L);
    int32_t l_39[9] = {0xF620A341L,0xF620A341L,0xF620A341L,0xF620A341L,0xF620A341L,0xF620A341L,0xF620A341L,0xF620A341L,0xF620A341L};
    int i;
    ++g_40;
    l_39[0] = l_39[0];
    return l_39[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_35
 * writes: g_35
 */
static int8_t  func_19(uint32_t  p_20, uint32_t  p_21, uint32_t  p_22, int16_t  p_23, int64_t  p_24)
{ /* block id: 12 */
    int16_t l_32 = (-1L);
    int32_t l_33 = 8L;
    int32_t l_34[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
    int i;
    --g_35;
    return p_20;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 20
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 4
   depth: 20, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 12
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 15
XXX percentage of non-volatile access: 92.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 3
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 32.6
XXX percentage an existing variable is used: 67.4
********************* end of statistics **********************/

