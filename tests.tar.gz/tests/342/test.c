/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15886179733223135826
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-1L);
static const volatile int64_t g_20 = 1L;/* VOLATILE GLOBAL g_20 */
static uint16_t g_49 = 0xCEFCL;
static int8_t g_50 = (-3L);
static int32_t g_58 = 0L;
static int16_t g_63 = 0xFD08L;
static int32_t g_65[10][3] = {{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L},{5L,0L,5L}};
static volatile int32_t g_77 = 2L;/* VOLATILE GLOBAL g_77 */
static uint16_t g_87 = 0x4D63L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int16_t  func_6(int64_t  p_7, int32_t  p_8, const uint32_t  p_9);
static int32_t  func_26(const uint8_t  p_27, uint8_t  p_28, int32_t  p_29);
static uint16_t  func_35(int32_t  p_36, const int32_t  p_37, int32_t  p_38, uint16_t  p_39, int8_t  p_40);
static int32_t  func_43(uint32_t  p_44, const uint16_t  p_45, uint16_t  p_46, uint8_t  p_47);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_20 g_50 g_49 g_58 g_77 g_65 g_87 g_63
 * writes: g_2 g_49 g_50 g_58 g_65 g_87
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_3 = 0L;
    int32_t l_163 = 0xC9016659L;
    uint8_t l_164 = 0x8FL;
    if ((g_2 != l_3))
    { /* block id: 1 */
        int64_t l_10[2];
        int32_t l_25 = 2L;
        int i;
        for (i = 0; i < 2; i++)
            l_10[i] = (-1L);
        if ((safe_mul_func_int8_t_s_s((func_6((g_2 <= l_10[0]), g_2, g_2) , g_20), 0xC4L)))
        { /* block id: 22 */
            g_2 &= g_20;
        }
        else
        { /* block id: 24 */
            l_25 = ((safe_add_func_int16_t_s_s(0x6E85L, (-1L))) >= g_20);
            l_25 = func_26(((l_25 , g_2) >= l_3), l_10[0], l_25);
        }
        if (g_2)
        { /* block id: 31 */
            return l_25;
        }
        else
        { /* block id: 33 */
            g_2 = l_10[0];
        }
        g_2 = 5L;
    }
    else
    { /* block id: 37 */
        int32_t l_41 = (-1L);
        uint8_t l_160 = 0x90L;
        for (g_2 = (-30); (g_2 == 18); g_2 = safe_add_func_int32_t_s_s(g_2, 3))
        { /* block id: 40 */
            const uint8_t l_42 = 0x0AL;
            g_65[2][1] = ((safe_add_func_uint16_t_u_u(func_35((l_41 <= g_20), l_42, g_2, l_41, g_2), (-10L))) , g_87);
        }
lbl_161:
        for (g_87 = 0; (g_87 <= 28); g_87++)
        { /* block id: 89 */
            if (l_41)
                break;
            return g_65[8][1];
        }
        if ((l_3 > g_77))
        { /* block id: 93 */
            int32_t l_159[6][10][4] = {{{0xA667C512L,1L,(-2L),0x95C60AA6L},{0xFDD691CFL,0x39B40A8AL,5L,1L},{0x38B3E490L,(-7L),0L,0x76ED3A1DL},{0x9036F656L,0x6597B285L,0x6597B285L,0x9036F656L},{0x77550297L,(-1L),(-1L),(-1L)},{0x38B3E490L,(-1L),2L,1L},{0x76ED3A1DL,(-4L),0xCBDE4370L,1L},{0xCCDA527CL,(-1L),(-6L),(-1L)},{(-2L),(-1L),0xF4E79440L,1L},{0x9E10CE32L,0x9036F656L,1L,0L}},{{0xBB1C3948L,0xCD23E7C5L,1L,0x84356361L},{0xA667C512L,0x6597B285L,0xBB1C3948L,0x8A7D9E7FL},{0xCCDA527CL,0xA0577EC2L,1L,0xBB1C3948L},{0x6479049CL,0x38B3E490L,(-1L),0x38F02CE6L},{(-1L),0L,(-1L),(-1L)},{(-1L),0xCD23E7C5L,(-1L),1L},{0x4978895DL,2L,0x9036F656L,(-7L)},{0x95C60AA6L,0x86230F59L,0xC09CC95DL,(-1L)},{1L,(-1L),(-1L),(-7L)},{0x76ED3A1DL,0xF4E79440L,0x221AC852L,0xF4E79440L}},{{0x9036F656L,(-1L),0xC95E86A8L,2L},{0xA667C512L,0xD83BFFE3L,0xF4E79440L,(-7L)},{(-6L),(-2L),(-1L),0L},{(-6L),0xBB1C3948L,0xF4E79440L,0x95C60AA6L},{0xA667C512L,0L,0xC95E86A8L,(-1L)},{0x9036F656L,0xA0577EC2L,0x221AC852L,0xC95E86A8L},{0x76ED3A1DL,(-1L),(-1L),0x8A7D9E7FL},{1L,0xDD3993F1L,0xC09CC95DL,(-1L)},{0x95C60AA6L,0xBB1C3948L,0x9036F656L,(-1L)},{0x4978895DL,0x9036F656L,(-1L),(-1L)}},{{(-1L),0x86230F59L,(-1L),2L},{(-1L),5L,(-1L),1L},{0x6479049CL,0xFDD691CFL,1L,0xF4E79440L},{0xCCDA527CL,(-1L),0xBB1C3948L,0x6479049CL},{0xA667C512L,(-1L),1L,(-1L)},{0xBB1C3948L,(-2L),1L,1L},{0x9E10CE32L,0x9E10CE32L,0xF4E79440L,0x84356361L},{(-2L),0xDD3993F1L,(-6L),(-1L)},{0xCCDA527CL,0x38B3E490L,0xCBDE4370L,(-6L)},{0x76ED3A1DL,0x38B3E490L,2L,(-1L)}},{{0x38B3E490L,0xDD3993F1L,(-1L),0x84356361L},{0x77550297L,0x9E10CE32L,0x9036F656L,1L},{1L,(-2L),0xCCDA527CL,(-1L)},{0x95C60AA6L,(-1L),1L,0x6479049CL},{(-1L),(-1L),2L,0xF4E79440L},{(-1L),0xFDD691CFL,0x221AC852L,1L},{2L,5L,0xBB1C3948L,2L},{(-2L),0x86230F59L,(-7L),(-1L)},{(-6L),0x9036F656L,0L,(-1L)},{0x9E10CE32L,0xBB1C3948L,1L,(-1L)}},{{(-1L),0xDD3993F1L,0xC95E86A8L,0x8A7D9E7FL},{2L,(-1L),0xCBDE4370L,0xFDD691CFL},{1L,0x77550297L,1L,0x11D30B9BL},{0x84356361L,0xCCDA527CL,1L,0x8A7D9E7FL},{(-1L),(-7L),0xB4616CE4L,0xCCDA527CL},{(-6L),0x4978895DL,0xB4616CE4L,0xCD23E7C5L},{(-1L),(-1L),1L,0xDD3993F1L},{0x84356361L,(-9L),1L,1L},{1L,1L,(-2L),9L},{(-1L),0xC09CC95DL,0xFDD691CFL,(-1L)}}};
            int i, j, k;
            g_65[9][0] = ((((((safe_rshift_func_uint8_t_u_s((g_63 > 1UL), 1)) && g_50) , g_58) <= l_159[4][7][0]) >= l_160) && g_63);
            if (g_63)
                goto lbl_161;
            g_65[3][2] |= (g_49 >= g_2);
        }
        else
        { /* block id: 97 */
            int32_t l_162 = 0L;
            l_163 = (l_3 , l_162);
        }
        g_65[3][2] = l_164;
    }
    g_65[8][0] |= g_50;
    return l_164;
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_2
 * writes: g_2
 */
static int16_t  func_6(int64_t  p_7, int32_t  p_8, const uint32_t  p_9)
{ /* block id: 2 */
    int16_t l_16 = 1L;
    for (p_8 = 0; (p_8 <= (-6)); p_8--)
    { /* block id: 5 */
        int8_t l_15 = 0x35L;
        int32_t l_17 = 1L;
        l_17 = (((((safe_div_func_int16_t_s_s(l_15, l_15)) & l_16) ^ l_16) && l_15) >= p_9);
        for (p_7 = (-10); (p_7 == 26); p_7 = safe_add_func_int16_t_s_s(p_7, 4))
        { /* block id: 9 */
            g_2 = (l_15 & (-1L));
            if (g_20)
                break;
            return g_20;
        }
        for (l_16 = (-26); (l_16 >= (-16)); ++l_16)
        { /* block id: 16 */
            l_17 = (g_2 , 0xCEDB7758L);
            return l_17;
        }
    }
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static int32_t  func_26(const uint8_t  p_27, uint8_t  p_28, int32_t  p_29)
{ /* block id: 26 */
    int16_t l_30 = 0x891FL;
    g_2 ^= 0x073E70D2L;
    return l_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_2 g_50 g_49 g_58 g_77 g_65 g_87
 * writes: g_49 g_50 g_58 g_65 g_87
 */
static uint16_t  func_35(int32_t  p_36, const int32_t  p_37, int32_t  p_38, uint16_t  p_39, int8_t  p_40)
{ /* block id: 41 */
    const int32_t l_48 = 9L;
    int32_t l_55 = (-1L);
    int32_t l_64 = 1L;
    int32_t l_67 = (-1L);
    int32_t l_68 = 1L;
    int32_t l_91 = 3L;
    int32_t l_97 = 0L;
    int32_t l_98 = 0x65E09581L;
    int32_t l_109 = 0x1085DA10L;
    int32_t l_110 = 1L;
    int32_t l_111 = 0x4E4A0A60L;
    int32_t l_113 = 0x57E6E873L;
    int32_t l_114 = 1L;
    int32_t l_116 = 0x7C284333L;
    int32_t l_117 = 0x9363F815L;
    int32_t l_119 = 0x3CB4EFB5L;
    int32_t l_121 = 9L;
    int32_t l_122 = (-2L);
    int32_t l_123[7][8][4] = {{{0L,(-4L),(-1L),0x23CA64ADL},{0x5F1CA18EL,0x30389EC3L,(-1L),(-10L)},{1L,0x23CA64ADL,0x23CA64ADL,1L},{0x393C2DF5L,1L,0x40387E0AL,0L},{6L,(-10L),(-1L),0L},{0x44EAF9A5L,(-1L),0xD0C6BF6CL,0L},{0xC6C2C343L,(-10L),(-4L),0L},{0x30389EC3L,1L,0xC9FB339EL,1L}},{{0L,0x23CA64ADL,0L,(-10L)},{0L,0x30389EC3L,0L,0x23CA64ADL},{0x6111E293L,(-4L),0x79608170L,5L},{0L,(-9L),0L,0x5F1CA18EL},{0xD0C6BF6CL,0L,0xEDB9B1DFL,0x28F678E9L},{0x30389EC3L,0x6111E293L,(-1L),1L},{1L,(-1L),0xD0C6BF6CL,1L},{(-3L),6L,(-3L),0xC6C2C343L}},{{6L,0x6111E293L,0xE4B147B7L,0x6111E293L},{0x0DEA165FL,0xD0C6BF6CL,0x23CA64ADL,0x5F1CA18EL},{0x40387E0AL,(-1L),0xF24B42E2L,(-1L)},{0x5F1CA18EL,(-4L),1L,0xDEDC864EL},{0x5F1CA18EL,0xEDB9B1DFL,0xF24B42E2L,(-10L)},{0x40387E0AL,0xDEDC864EL,0x23CA64ADL,0x40387E0AL},{0x0DEA165FL,1L,0xE4B147B7L,7L},{6L,0xA42CAA49L,(-3L),0L}},{{(-3L),5L,0xD0C6BF6CL,0L},{1L,(-10L),(-1L),7L},{0x30389EC3L,0xC6C2C343L,0xEDB9B1DFL,1L},{0xD0C6BF6CL,0xDEDC864EL,0L,0xA42CAA49L},{0L,0x30389EC3L,0x79608170L,0xDEDC864EL},{0x6111E293L,0xF24B42E2L,0L,5L},{0L,(-1L),0L,0L},{0L,0L,0xC9FB339EL,0x6111E293L}},{{0x30389EC3L,0x28F678E9L,(-4L),1L},{0xC6C2C343L,6L,0xD0C6BF6CL,(-4L)},{0x44EAF9A5L,6L,(-1L),1L},{6L,0x28F678E9L,0x40387E0AL,0x6111E293L},{0x393C2DF5L,0L,0x23CA64ADL,0L},{1L,(-1L),(-1L),5L},{0x5F1CA18EL,0xF24B42E2L,(-1L),0xDEDC864EL},{0L,0x393C2DF5L,(-2L),(-1L)}},{{0xEDB9B1DFL,0xD0C6BF6CL,0L,0xEDB9B1DFL},{0xA42CAA49L,(-1L),0xC9FB339EL,0L},{0x8848F550L,(-4L),0x5D9FCA90L,0x79608170L},{0xE80B3DF5L,(-3L),0x44EAF9A5L,0L},{0xF24B42E2L,(-1L),1L,0L},{1L,0xF24B42E2L,1L,0xC9FB339EL},{(-3L),0xD0C6BF6CL,1L,(-4L)},{0L,1L,0x973AC029L,0xD0C6BF6CL}},{{1L,0L,0x973AC029L,(-1L)},{0L,(-1L),1L,0x40387E0AL},{(-3L),(-1L),1L,0x23CA64ADL},{1L,0x23CA64ADL,1L,(-1L)},{0xF24B42E2L,0x28F678E9L,0x44EAF9A5L,(-1L)},{0xE80B3DF5L,0x8848F550L,0x5D9FCA90L,0xF24B42E2L},{0x8848F550L,0x23CA64ADL,0xC9FB339EL,1L},{0xA42CAA49L,(-3L),0L,0x40387E0AL}}};
    int16_t l_124[5][2][5] = {{{(-7L),(-1L),(-1L),1L,1L},{1L,0x4222L,1L,0x1F87L,0xEDD0L}},{{(-1L),(-1L),(-7L),1L,0xEDD0L},{0xDC99L,(-8L),(-8L),0xDC99L,1L}},{{0L,0xDC99L,(-7L),0xEDD0L,(-1L)},{0L,(-7L),1L,(-7L),0L}},{{0xDC99L,1L,(-1L),0xEDD0L,(-8L)},{(-1L),1L,0xDC99L,0xDC99L,1L}},{{1L,(-7L),0L,1L,(-8L)},{(-7L),0xDC99L,0L,0x1F87L,0L}}};
    int32_t l_147[8][6] = {{0x48362037L,0x48362037L,0x514B0433L,2L,0x514B0433L,0x48362037L},{0x514B0433L,0L,2L,2L,0L,0x514B0433L},{0x48362037L,0x514B0433L,2L,0x514B0433L,0x48362037L,0x48362037L},{1L,0x514B0433L,0x514B0433L,1L,0L,1L},{1L,0L,1L,0x514B0433L,0x514B0433L,1L},{0x48362037L,0x48362037L,0x514B0433L,2L,0x514B0433L,0x48362037L},{0x514B0433L,0L,2L,2L,0L,0x514B0433L},{0x48362037L,0x514B0433L,2L,0x514B0433L,0x48362037L,0x48362037L}};
    int i, j, k;
    if (func_43(p_40, l_48, g_20, p_40))
    { /* block id: 46 */
        uint16_t l_61 = 1UL;
        int32_t l_66 = (-4L);
        int32_t l_92 = (-1L);
        int32_t l_94 = (-1L);
        int32_t l_95 = 0x366C4368L;
        int32_t l_100 = 0x4F54FDF1L;
        int32_t l_103 = (-1L);
        int32_t l_104 = 0x391AF2E2L;
        int32_t l_105 = 1L;
        int32_t l_106 = (-3L);
        int32_t l_107 = 3L;
        int32_t l_108 = 0xA455C58EL;
        int32_t l_112 = 0x845225C7L;
        int32_t l_115 = 0x75E1209EL;
        int32_t l_118 = 0x04EFFBF5L;
        int32_t l_120[9][4] = {{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L},{0xA50812B2L,0xA50812B2L,0xA50812B2L,0xA50812B2L}};
        int32_t l_138 = (-9L);
        int32_t l_142 = 0x84D8DA12L;
        uint32_t l_143 = 0x4E75D9F9L;
        int i, j;
        if ((g_50 == g_49))
        { /* block id: 47 */
            uint16_t l_54[6] = {0xC987L,0xC987L,0xC987L,0xC987L,0xC987L,0xC987L};
            uint8_t l_62 = 0xBEL;
            int i;
            l_55 = ((safe_mod_func_uint64_t_u_u(p_39, l_54[5])) , l_54[2]);
            g_58 = (safe_mul_func_uint8_t_u_u(((p_38 || (-1L)) >= p_40), 0UL));
            l_55 ^= ((safe_mul_func_uint16_t_u_u(((g_50 , g_50) > p_39), 0x1B00L)) == g_58);
            l_62 = ((((l_61 & g_50) || g_50) , p_39) >= l_48);
        }
        else
        { /* block id: 52 */
            uint32_t l_69 = 0UL;
            const uint32_t l_76 = 7UL;
            l_69--;
            g_65[3][2] |= (safe_mul_func_uint16_t_u_u((((((((safe_mod_func_uint16_t_u_u((p_40 == l_61), g_2)) , 1UL) > 1UL) < l_76) | g_77) != g_50) <= l_69), 0L));
            if (g_2)
                goto lbl_84;
lbl_84:
            g_65[3][2] = ((((safe_sub_func_int16_t_s_s((((safe_lshift_func_int16_t_s_s((safe_sub_func_int16_t_s_s((p_40 | p_37), g_20)), 7)) ^ 0x0D0C570BL) | l_66), g_58)) && p_39) & p_38) , (-10L));
            g_87 = ((safe_add_func_int32_t_s_s(((l_66 & 0UL) && p_37), p_36)) != p_38);
        }
        for (g_87 = 0; (g_87 <= 2); g_87 += 1)
        { /* block id: 61 */
            int64_t l_88 = (-1L);
            int32_t l_89 = (-9L);
            int32_t l_90 = 0xCC553FEAL;
            int32_t l_93 = 0L;
            int32_t l_96 = 0x67A1E796L;
            int32_t l_99 = (-1L);
            int32_t l_101 = 0xE2D46470L;
            int32_t l_102[4];
            uint64_t l_125 = 0UL;
            int i;
            for (i = 0; i < 4; i++)
                l_102[i] = 0L;
            l_88 &= l_61;
            ++l_125;
        }
        for (l_109 = 0; (l_109 == (-14)); l_109 = safe_sub_func_uint16_t_u_u(l_109, 5))
        { /* block id: 67 */
            uint64_t l_130 = 0x6D8BF474991CB954LL;
            int32_t l_133 = 0x228373B8L;
            int32_t l_134 = 0x09ED61E2L;
            uint32_t l_135 = 5UL;
            int32_t l_139 = 8L;
            int32_t l_140 = 1L;
            int32_t l_141 = 5L;
            l_130--;
            --l_135;
            if (l_134)
                break;
            l_143--;
        }
    }
    else
    { /* block id: 73 */
        int8_t l_152 = 7L;
        for (l_117 = 0; (l_117 <= 3); l_117 += 1)
        { /* block id: 76 */
            uint16_t l_146 = 0x1280L;
            g_65[7][1] = 0xB5B473D7L;
            g_65[2][2] = (((((p_36 != p_40) , l_146) | 0x83L) <= l_147[7][0]) == 0xAFL);
            g_65[6][1] = (safe_div_func_int8_t_s_s(p_39, g_87));
            p_38 = (safe_rshift_func_int8_t_s_s(g_20, l_152));
        }
    }
    g_65[3][2] ^= (safe_mod_func_int8_t_s_s(((l_64 , 0L) < 6UL), p_37));
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_49 g_50
 */
static int32_t  func_43(uint32_t  p_44, const uint16_t  p_45, uint16_t  p_46, uint8_t  p_47)
{ /* block id: 42 */
    int32_t l_51 = 0x17F4926AL;
    g_49 = ((0x8A83A56CF6D70783LL >= 18446744073709551611UL) > 65535UL);
    g_50 = g_2;
    return l_51;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_65[i][j], "g_65[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 86
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 64
   depth: 2, occurrence: 17
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 4
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 104
XXX times a non-volatile is write: 43
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 126
XXX percentage of non-volatile access: 93

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 63
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 14
   depth: 2, occurrence: 36

XXX percentage a fresh-made variable is used: 23.8
XXX percentage an existing variable is used: 76.2
********************* end of statistics **********************/

