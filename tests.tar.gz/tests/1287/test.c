/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7184715639158780956
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_7[5] = {0x3FL,0x3FL,0x3FL,0x3FL,0x3FL};
static int16_t g_19 = 0x28D5L;
static uint64_t g_26[8][10][3] = {{{0x23579942796A450CLL,9UL,0UL},{0x18DB06862EAE2646LL,18446744073709551615UL,0xFEBDAB6AC39B398ELL},{0x116971DB95674643LL,0UL,18446744073709551613UL},{0xE7EA1B14898D08F4LL,0x7CDD5376E30F4AEDLL,0x23A35E06C0838563LL},{18446744073709551615UL,0UL,0xFFDE63B6910C3349LL},{18446744073709551615UL,0xFFDE63B6910C3349LL,0x99DB2213AABDC9A8LL},{5UL,1UL,18446744073709551615UL},{5UL,0x17BB5C02AC6AA04DLL,18446744073709551615UL},{18446744073709551615UL,0x7F668CDE333B8FBALL,18446744073709551607UL},{18446744073709551615UL,0x23579942796A450CLL,0x23579942796A450CLL}},{{0xE7EA1B14898D08F4LL,0x498A597FB6F8A3E0LL,0xA36FE54384F3AC16LL},{0x116971DB95674643LL,0x18DB06862EAE2646LL,0xC3E1B8D8131DDA87LL},{0x18DB06862EAE2646LL,0UL,0x094951162D50C857LL},{0x23579942796A450CLL,18446744073709551609UL,0x116971DB95674643LL},{0x116971DB95674643LL,18446744073709551615UL,0xFFDE63B6910C3349LL},{5UL,0x498A597FB6F8A3E0LL,0xD594484F75DF1563LL},{0UL,0x23A35E06C0838563LL,9UL},{18446744073709551613UL,18446744073709551615UL,0UL},{3UL,0x9C309AB83EB61943LL,0x17BB5C02AC6AA04DLL},{0xCE61FA7BB34E4A53LL,18446744073709551609UL,0x99DB2213AABDC9A8LL}},{{18446744073709551607UL,0xD594484F75DF1563LL,0x99DB2213AABDC9A8LL},{0x7F668CDE333B8FBALL,0UL,0x17BB5C02AC6AA04DLL},{0x23A35E06C0838563LL,0x18DB06862EAE2646LL,0UL},{9UL,0xFFDE63B6910C3349LL,9UL},{0UL,0x094951162D50C857LL,0xD594484F75DF1563LL},{0x99DB2213AABDC9A8LL,0UL,0xFFDE63B6910C3349LL},{0x80453D47EBDCF28DLL,5UL,0x116971DB95674643LL},{0x9C309AB83EB61943LL,0xA36FE54384F3AC16LL,1UL},{0x80453D47EBDCF28DLL,0x7F668CDE333B8FBALL,0x64E785C2F4FE10EFLL},{0x99DB2213AABDC9A8LL,5UL,0UL}},{{0UL,18446744073709551613UL,18446744073709551615UL},{9UL,0UL,0xFEBDAB6AC39B398ELL},{0x23A35E06C0838563LL,18446744073709551607UL,0UL},{0x7F668CDE333B8FBALL,0x17BB5C02AC6AA04DLL,18446744073709551607UL},{18446744073709551607UL,0x17BB5C02AC6AA04DLL,0UL},{0xCE61FA7BB34E4A53LL,18446744073709551607UL,0UL},{3UL,0UL,0xC3E1B8D8131DDA87LL},{18446744073709551613UL,18446744073709551613UL,0xCE61FA7BB34E4A53LL},{0UL,5UL,18446744073709551613UL},{5UL,0x7F668CDE333B8FBALL,0x18DB06862EAE2646LL}},{{0x116971DB95674643LL,0xA36FE54384F3AC16LL,0x094951162D50C857LL},{18446744073709551615UL,5UL,0x18DB06862EAE2646LL},{0x498A597FB6F8A3E0LL,0UL,18446744073709551613UL},{0UL,0x094951162D50C857LL,0xCE61FA7BB34E4A53LL},{0x544BD1A6F32215F8LL,0xFFDE63B6910C3349LL,0xC3E1B8D8131DDA87LL},{0UL,0x18DB06862EAE2646LL,0UL},{18446744073709551608UL,0UL,0UL},{6UL,0xD594484F75DF1563LL,18446744073709551607UL},{6UL,18446744073709551609UL,0UL},{18446744073709551608UL,0x9C309AB83EB61943LL,0xFEBDAB6AC39B398ELL}},{{0UL,18446744073709551615UL,18446744073709551615UL},{0x544BD1A6F32215F8LL,0x23A35E06C0838563LL,0UL},{0UL,0x498A597FB6F8A3E0LL,0x64E785C2F4FE10EFLL},{0x498A597FB6F8A3E0LL,18446744073709551615UL,1UL},{18446744073709551615UL,9UL,0x116971DB95674643LL},{0x116971DB95674643LL,18446744073709551615UL,0xFFDE63B6910C3349LL},{5UL,0x498A597FB6F8A3E0LL,0xD594484F75DF1563LL},{0UL,0x23A35E06C0838563LL,9UL},{18446744073709551613UL,18446744073709551615UL,0UL},{3UL,0x9C309AB83EB61943LL,0x17BB5C02AC6AA04DLL}},{{0xCE61FA7BB34E4A53LL,18446744073709551609UL,0x99DB2213AABDC9A8LL},{18446744073709551607UL,0xD594484F75DF1563LL,0x99DB2213AABDC9A8LL},{0x7F668CDE333B8FBALL,0UL,0x17BB5C02AC6AA04DLL},{0x23A35E06C0838563LL,0x18DB06862EAE2646LL,0UL},{9UL,0xFFDE63B6910C3349LL,9UL},{0UL,0x094951162D50C857LL,0xD594484F75DF1563LL},{0x99DB2213AABDC9A8LL,0UL,0xFFDE63B6910C3349LL},{0x80453D47EBDCF28DLL,5UL,0x116971DB95674643LL},{0x9C309AB83EB61943LL,0xA36FE54384F3AC16LL,1UL},{0x80453D47EBDCF28DLL,0x7F668CDE333B8FBALL,0x64E785C2F4FE10EFLL}},{{0x99DB2213AABDC9A8LL,5UL,0UL},{0UL,18446744073709551613UL,18446744073709551615UL},{9UL,0UL,0xFEBDAB6AC39B398ELL},{0x23A35E06C0838563LL,18446744073709551607UL,0UL},{0x7F668CDE333B8FBALL,0x17BB5C02AC6AA04DLL,18446744073709551607UL},{18446744073709551607UL,0x17BB5C02AC6AA04DLL,0UL},{0xCE61FA7BB34E4A53LL,18446744073709551607UL,0UL},{3UL,18446744073709551615UL,0x64E785C2F4FE10EFLL},{0xCE61FA7BB34E4A53LL,0xCE61FA7BB34E4A53LL,18446744073709551615UL},{18446744073709551610UL,6UL,0xCE61FA7BB34E4A53LL}}};
static uint32_t g_30 = 2UL;
static volatile uint32_t g_31 = 0xC34309E9L;/* VOLATILE GLOBAL g_31 */
static volatile uint8_t g_64 = 252UL;/* VOLATILE GLOBAL g_64 */
static uint8_t g_85 = 255UL;
static int16_t g_90 = 0x70D1L;
static int64_t g_105 = (-3L);
static uint8_t g_113 = 0xACL;
static volatile int64_t g_119 = 0L;/* VOLATILE GLOBAL g_119 */
static uint16_t g_120 = 0x5192L;
static uint8_t g_135 = 250UL;
static uint8_t g_152 = 0x96L;
static volatile uint32_t g_154 = 0x28D9ABBAL;/* VOLATILE GLOBAL g_154 */
static int8_t g_155 = 3L;
static uint16_t g_156 = 0xA9B4L;
static uint32_t g_157 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint8_t  func_34(int16_t  p_35, const int16_t  p_36, uint16_t  p_37);
static int16_t  func_45(int8_t  p_46, int32_t  p_47, uint16_t  p_48, const uint64_t  p_49);
static int8_t  func_62(uint8_t  p_63);
static int32_t  func_79(int16_t  p_80, uint64_t  p_81, uint16_t  p_82);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_26 g_30 g_31 g_64 g_19 g_85 g_90 g_105 g_119 g_113 g_135 g_152 g_156
 * writes: g_19 g_26 g_30 g_31 g_64 g_85 g_90 g_105 g_113 g_119 g_120 g_135 g_152 g_154 g_155 g_156 g_157
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = 1L;
    int32_t l_12[5][1][1] = {{{0L}},{{0L}},{{0L}},{{0L}},{{0L}}};
    int i, j, k;
    if ((l_2 < 0xC1EC2DB2L))
    { /* block id: 1 */
        const uint8_t l_11[8] = {3UL,3UL,0x7EL,3UL,3UL,0x7EL,3UL,3UL};
        int i;
        for (l_2 = 0; (l_2 == (-18)); --l_2)
        { /* block id: 4 */
            int64_t l_8 = 0x55CC25BFC88EB987LL;
            l_8 = ((safe_rshift_func_uint8_t_u_s(0xC3L, g_7[2])) & g_7[2]);
        }
        l_12[4][0][0] = (safe_div_func_int64_t_s_s(l_11[7], (-1L)));
        g_19 = (safe_lshift_func_uint16_t_u_u((safe_add_func_int16_t_s_s(((((safe_lshift_func_uint16_t_u_u(7UL, 4)) == g_7[2]) | g_7[2]) || g_7[2]), 0x16B5L)), 3));
    }
    else
    { /* block id: 9 */
        int8_t l_22 = (-6L);
        int32_t l_23 = 0x69FF4CAAL;
        const int64_t l_50 = 5L;
        l_23 ^= (safe_rshift_func_int8_t_s_u(((l_22 | g_7[3]) , 0L), 2));
        for (l_2 = 0; (l_2 > (-24)); l_2 = safe_sub_func_uint32_t_u_u(l_2, 8))
        { /* block id: 13 */
            uint16_t l_29 = 0UL;
            --g_26[7][0][1];
            g_30 ^= l_29;
            g_31++;
            g_154 = (func_34((safe_lshift_func_int16_t_s_u((safe_lshift_func_uint8_t_u_s((safe_div_func_int16_t_s_s((safe_unary_minus_func_uint16_t_u((func_45(l_22, l_22, g_26[7][0][1], l_50) && g_64))), g_26[7][0][1])), g_7[4])), 10)), g_26[7][0][1], l_29) , 0xF8345FCBL);
        }
        g_155 = g_90;
        g_156 &= (g_113 > l_12[4][0][0]);
    }
    g_157 = (g_7[1] & l_12[4][0][0]);
    l_12[4][0][0] = (safe_mul_func_int16_t_s_s(g_105, (-1L)));
    return g_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_113 g_135 g_7 g_26 g_152
 * writes: g_135 g_152
 */
static uint8_t  func_34(int16_t  p_35, const int16_t  p_36, uint16_t  p_37)
{ /* block id: 67 */
    uint16_t l_136 = 65535UL;
    int32_t l_137 = 8L;
    int32_t l_153 = (-1L);
    g_135 ^= g_113;
    l_137 = (g_7[2] , l_136);
    for (l_136 = 0; (l_136 != 22); l_136++)
    { /* block id: 72 */
        uint32_t l_148 = 0x4B4BCE18L;
        int32_t l_149 = 4L;
        l_149 ^= ((safe_mod_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((safe_lshift_func_int16_t_s_s((((safe_add_func_uint32_t_u_u(0x0E5F2579L, 0x88B3BFF7L)) && 0xCCE49B202198C401LL) < l_148), g_7[2])) < p_36), p_36)), p_36)) >= g_26[3][6][0]);
        g_152 |= (safe_lshift_func_uint8_t_u_u((((7UL < l_149) , p_36) != (-1L)), 2));
        l_153 = (p_35 , (-1L));
    }
    return g_26[6][9][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_26 g_31 g_19 g_85 g_90 g_7 g_105 g_30 g_119
 * writes: g_64 g_19 g_85 g_90 g_105 g_30 g_113 g_119 g_120
 */
static int16_t  func_45(int8_t  p_46, int32_t  p_47, uint16_t  p_48, const uint64_t  p_49)
{ /* block id: 17 */
    uint32_t l_51 = 0UL;
    int32_t l_124[3];
    uint32_t l_125 = 0x081ECF37L;
    int32_t l_134 = 0x3C38EFF2L;
    int i;
    for (i = 0; i < 3; i++)
        l_124[i] = 0x9A7EFCC6L;
    l_51 &= 0x708C9934L;
lbl_133:
    if (((safe_lshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(((safe_lshift_func_int16_t_s_s((safe_div_func_int8_t_s_s(func_62(((l_51 , 65532UL) <= (-1L))), p_46)), p_46)) , (-3L)), g_26[4][3][2])), 15)), g_7[2])) , l_51))
    { /* block id: 38 */
        int8_t l_91[5];
        int32_t l_96 = 0xF8686667L;
        int i;
        for (i = 0; i < 5; i++)
            l_91[i] = 0x20L;
        l_91[2] = 0xED92BB84L;
        l_96 = ((safe_add_func_int64_t_s_s((safe_add_func_int16_t_s_s(((((l_91[4] ^ l_91[0]) ^ l_91[2]) , p_46) ^ p_46), 0xABB6L)), 0xE344E30A6D4616B4LL)) , p_48);
    }
    else
    { /* block id: 41 */
        int64_t l_118 = 0x32190EF9F67763B3LL;
        g_105 ^= (safe_div_func_uint8_t_u_u((((safe_div_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u(((-10L) != l_51), 4)), 13)), 0x59D8L)) ^ l_51) & 248UL), 249UL));
        for (g_30 = 9; (g_30 <= 8); g_30--)
        { /* block id: 45 */
            int64_t l_112[8];
            int i;
            for (i = 0; i < 8; i++)
                l_112[i] = 1L;
            g_113 = ((safe_lshift_func_int8_t_s_s(((safe_lshift_func_int8_t_s_s(0x7CL, 3)) == l_112[4]), 1)) <= 255UL);
            g_119 ^= ((((safe_sub_func_uint16_t_u_u(((p_46 < 0x40L) > l_118), p_48)) , p_48) && 0UL) , 0x035E89B0L);
        }
        g_120 = 0x093E2C01L;
    }
    if ((!(((safe_add_func_int16_t_s_s(((l_124[0] && g_30) && p_49), l_124[1])) != l_125) , 65533UL)))
    { /* block id: 51 */
        uint32_t l_126 = 0x1BEEAF45L;
        int32_t l_127[3][9][9] = {{{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)}},{{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L},{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L)},{0x01AA1EC4L,(-9L),0x01AA1EC4L,0xC174C20FL,0xF6D4BD0DL,0xC174C20FL,0x01AA1EC4L,(-9L),0x01AA1EC4L}},{{(-1L),0x91174088L,(-1L),(-1L),0x91174088L,(-1L),(-1L),(-1L),6L},{0x47574C55L,0xC174C20FL,0x47574C55L,0xFD6114BBL,0x01AA1EC4L,0xFD6114BBL,0x47574C55L,0xC174C20FL,0x47574C55L},{6L,(-1L),6L,6L,(-1L),6L,6L,(-1L),6L},{0x47574C55L,0xC174C20FL,0x47574C55L,0xFD6114BBL,0x01AA1EC4L,0xFD6114BBL,0x47574C55L,0xC174C20FL,0x47574C55L},{6L,(-1L),6L,6L,(-1L),6L,6L,(-1L),6L},{0x47574C55L,0xC174C20FL,0x47574C55L,0xFD6114BBL,0x01AA1EC4L,0xFD6114BBL,0x47574C55L,0xC174C20FL,0x47574C55L},{6L,(-1L),6L,6L,(-1L),6L,6L,(-1L),6L},{0x47574C55L,0xC174C20FL,0x47574C55L,0xFD6114BBL,0x01AA1EC4L,0xFD6114BBL,0x47574C55L,0xC174C20FL,0x47574C55L},{6L,(-1L),6L,6L,(-1L),6L,6L,(-1L),6L}}};
        int i, j, k;
        l_127[0][8][0] = (g_26[7][0][1] <= l_126);
    }
    else
    { /* block id: 53 */
        for (g_105 = 27; (g_105 <= 26); g_105 = safe_sub_func_uint32_t_u_u(g_105, 7))
        { /* block id: 56 */
            int16_t l_130 = 0xC627L;
            l_130 |= g_64;
        }
        for (g_105 = 11; (g_105 >= (-11)); g_105 = safe_sub_func_uint32_t_u_u(g_105, 7))
        { /* block id: 61 */
            if (g_30)
                goto lbl_133;
            if (p_46)
                break;
        }
    }
    return l_134;
}


/* ------------------------------------------ */
/* 
 * reads : g_64 g_26 g_31 g_19 g_85 g_90
 * writes: g_64 g_19 g_85 g_90
 */
static int8_t  func_62(uint8_t  p_63)
{ /* block id: 19 */
    volatile uint32_t l_71 = 7UL;/* VOLATILE GLOBAL l_71 */
    g_64++;
    for (p_63 = 0; (p_63 > 49); ++p_63)
    { /* block id: 23 */
        uint16_t l_83 = 1UL;
        l_71 = (((safe_sub_func_int16_t_s_s(0x8915L, p_63)) , g_26[3][9][2]) , g_31);
        if (p_63)
            continue;
        for (g_19 = 0; (g_19 < 10); g_19 = safe_add_func_int64_t_s_s(g_19, 8))
        { /* block id: 28 */
            uint64_t l_84 = 0xBB28B9DDA2685807LL;
            g_90 |= (safe_mod_func_int8_t_s_s((~(safe_add_func_int32_t_s_s(func_79(l_83, g_26[1][6][0], l_84), g_19))), 1UL));
            return p_63;
        }
    }
    return p_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_85
 * writes: g_85
 */
static int32_t  func_79(int16_t  p_80, uint64_t  p_81, uint16_t  p_82)
{ /* block id: 29 */
    uint32_t l_88 = 18446744073709551615UL;
    uint64_t l_89 = 1UL;
    --g_85;
    l_88 = (-8L);
    return l_89;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_19, "g_19", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_26[i][j][k], "g_26[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_152, "g_152", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 16
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 83
XXX times a non-volatile is write: 34
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 39
XXX percentage of non-volatile access: 92.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 51
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 21
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 42.7
XXX percentage an existing variable is used: 57.3
********************* end of statistics **********************/

