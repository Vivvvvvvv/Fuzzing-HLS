/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6243818544708398259
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint32_t  f0;
   int32_t  f1;
   int16_t  f2;
   uint16_t  f3;
   const uint16_t  f4;
   uint8_t  f5;
   volatile uint32_t  f6;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint64_t g_2 = 2UL;/* VOLATILE GLOBAL g_2 */
static int32_t g_20 = 0xE9378F1EL;
static struct S0 g_41 = {0xEB077CB1L,0xB1996FCDL,1L,0UL,4UL,0x53L,0x03E1FE01L};/* VOLATILE GLOBAL g_41 */
static volatile uint32_t g_55 = 0xA068CF11L;/* VOLATILE GLOBAL g_55 */
static int16_t g_87 = 0xBFDFL;
static volatile int8_t g_89 = 0x65L;/* VOLATILE GLOBAL g_89 */
static volatile uint16_t g_90[5][1] = {{0xD6C5L},{0xD6C5L},{0xD6C5L},{0xD6C5L},{0xD6C5L}};
static volatile uint64_t g_95 = 18446744073709551615UL;/* VOLATILE GLOBAL g_95 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static const int32_t  func_7(int32_t  p_8, uint64_t  p_9, const int32_t  p_10);
static int32_t  func_11(int32_t  p_12, int8_t  p_13, uint32_t  p_14);
static uint16_t  func_26(uint32_t  p_27, int64_t  p_28);
static struct S0  func_38(int8_t  p_39);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_20 g_41 g_55 g_90 g_95 g_87
 * writes: g_20 g_41.f1 g_55 g_90 g_95
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_3 = 0x5BF25CBDL;
    uint32_t l_4[2];
    int16_t l_119 = (-1L);
    uint32_t l_120 = 0xBEA24D65L;
    int32_t l_130[5] = {6L,6L,6L,6L,6L};
    int i;
    for (i = 0; i < 2; i++)
        l_4[i] = 0xAB6EC79CL;
    l_3 |= g_2;
    for (l_3 = 1; (l_3 >= 0); l_3 -= 1)
    { /* block id: 4 */
        int i;
        if (((safe_sub_func_uint8_t_u_u((func_7(func_11(((safe_rshift_func_uint8_t_u_s((safe_add_func_int32_t_s_s((!l_4[l_3]), g_2)), 0)) < g_20), g_20, g_20), l_3, l_3) & l_119), g_41.f3)) && 0L))
        { /* block id: 73 */
            int16_t l_129 = (-6L);
            l_120 |= l_4[l_3];
            l_130[0] = (safe_mod_func_int64_t_s_s((safe_rshift_func_uint8_t_u_u((((safe_add_func_int8_t_s_s((safe_add_func_int8_t_s_s(2L, 1L)), l_129)) & l_129) == g_41.f1), 3)), l_120));
        }
        else
        { /* block id: 76 */
            g_41.f1 = g_87;
            if (g_41.f3)
                break;
        }
        l_130[4] = (g_41.f0 || g_90[3][0]);
        for (l_120 = 0; (l_120 <= 4); l_120 += 1)
        { /* block id: 83 */
            int i;
            return l_130[(l_3 + 1)];
        }
    }
    g_41.f1 = (g_41.f2 & g_41.f1);
    return g_41.f1;
}


/* ------------------------------------------ */
/* 
 * reads : g_41.f2 g_41.f5 g_2 g_20 g_41.f6 g_41.f0 g_41.f1 g_90 g_55 g_95 g_41.f4
 * writes: g_41.f1 g_20 g_90 g_95
 */
static const int32_t  func_7(int32_t  p_8, uint64_t  p_9, const int32_t  p_10)
{ /* block id: 44 */
    int32_t l_64 = (-10L);
    uint64_t l_67 = 18446744073709551615UL;
    int32_t l_110 = 0xF414216AL;
    if ((safe_sub_func_int64_t_s_s((safe_mod_func_int32_t_s_s(((safe_mul_func_uint8_t_u_u(((l_64 > g_41.f2) ^ l_64), l_64)) , g_41.f5), l_64)), g_2)))
    { /* block id: 45 */
        uint32_t l_68 = 0UL;
        g_41.f1 = p_10;
        g_20 = (safe_add_func_int16_t_s_s((l_67 < l_68), 0x54AEL));
        return l_67;
    }
    else
    { /* block id: 49 */
        int8_t l_83 = 1L;
        int32_t l_85 = (-5L);
        g_20 = (safe_rshift_func_int16_t_s_s((safe_mod_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u(((((((safe_div_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_div_func_uint64_t_u_u(0x3239552BC05D4008LL, 0x0CF873A649E5A992LL)), g_20)), 8L)), l_83)) && p_8) || 6UL) , 1UL) | l_83) == 3L), l_83)) , l_67), 4294967286UL)), l_83));
        if ((g_41.f6 , g_41.f0))
        { /* block id: 51 */
            return p_10;
        }
        else
        { /* block id: 53 */
            uint16_t l_84 = 0UL;
            int32_t l_86 = 2L;
            int32_t l_88 = 7L;
            g_20 = g_41.f1;
            g_41.f1 = ((0L & 1UL) | l_84);
            ++g_90[0][0];
            g_41.f1 = (0xD9L | g_55);
        }
        for (l_64 = 0; (l_64 <= (-16)); l_64 = safe_sub_func_uint8_t_u_u(l_64, 8))
        { /* block id: 61 */
            if (g_55)
                break;
        }
        g_95++;
    }
    if ((((safe_mod_func_uint64_t_u_u((((!((safe_sub_func_int64_t_s_s(p_10, l_67)) >= g_41.f6)) && p_10) == g_41.f4), l_67)) , l_67) , l_67))
    { /* block id: 66 */
        uint64_t l_103 = 0x6C405962D98881B1LL;
        int32_t l_106 = 0x9B40CD91L;
        int32_t l_107 = 1L;
        int32_t l_108 = 7L;
        int32_t l_109 = 0x8AA41095L;
        uint32_t l_111 = 0x3A679AE6L;
        l_103++;
        ++l_111;
    }
    else
    { /* block id: 69 */
        uint32_t l_118 = 0xD5CA7D7AL;
        p_8 = (safe_rshift_func_int16_t_s_u((safe_sub_func_uint16_t_u_u((p_9 >= l_118), 0xAA94L)), 8));
    }
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_2 g_41 g_55
 * writes: g_20 g_41.f1 g_55
 */
static int32_t  func_11(int32_t  p_12, int8_t  p_13, uint32_t  p_14)
{ /* block id: 5 */
    uint64_t l_21 = 18446744073709551615UL;
    int32_t l_43 = 0x34EF9DEAL;
    int8_t l_44[6][10] = {{1L,8L,(-1L),0x74L,(-1L),1L,1L,(-1L),0x74L,(-1L)},{0x74L,0x74L,0x5CL,(-1L),0x0DL,0xA8L,(-1L),(-2L),0xE5L,9L},{(-2L),0x77L,(-1L),0x08L,0x42L,0x08L,(-1L),0x77L,(-2L),0x74L},{8L,0x74L,0xE5L,0x0DL,9L,0x90L,0x5CL,0x74L,0x74L,0x5CL},{0x42L,0xE5L,0xA8L,0xA8L,0xE5L,0x42L,0x90L,(-1L),1L,1L},{1L,0x74L,(-2L),0x77L,(-1L),0x08L,0x42L,0x08L,(-1L),0x77L}};
    int i, j;
    ++l_21;
    if (((safe_mul_func_int8_t_s_s((func_26(((safe_unary_minus_func_uint16_t_u((safe_mul_func_int16_t_s_s((0xF2F34E40L < 0x018EBDB8L), g_20)))) > g_20), g_2) <= l_21), l_21)) != l_21))
    { /* block id: 10 */
        uint8_t l_34 = 0xD1L;
        l_34 = 0L;
    }
    else
    { /* block id: 12 */
        uint16_t l_37 = 0xEC73L;
        for (p_13 = (-9); (p_13 >= 1); p_13++)
        { /* block id: 15 */
            int64_t l_42[6] = {7L,7L,0xC62ED5BB0C7F2BACLL,7L,7L,0xC62ED5BB0C7F2BACLL};
            int i;
            l_37 = (p_13 >= g_2);
            g_20 = p_13;
            l_42[5] = (func_38(((g_2 , p_14) ^ 0x5DL)) , p_13);
            l_43 |= p_12;
        }
        for (g_41.f1 = 5; (g_41.f1 >= 0); g_41.f1 -= 1)
        { /* block id: 27 */
            return p_12;
        }
    }
    for (l_21 = (-5); (l_21 < 17); l_21 = safe_add_func_int16_t_s_s(l_21, 9))
    { /* block id: 33 */
        g_20 &= (safe_rshift_func_uint16_t_u_s(((~65535UL) , l_43), g_41.f5));
        for (l_43 = 0; (l_43 > 21); l_43 = safe_add_func_int64_t_s_s(l_43, 4))
        { /* block id: 37 */
            uint32_t l_52[9] = {0x2088C4B5L,0x2088C4B5L,18446744073709551614UL,0x2088C4B5L,0x2088C4B5L,18446744073709551614UL,0x2088C4B5L,0x2088C4B5L,18446744073709551614UL};
            int i;
            return l_52[0];
        }
        g_41.f1 &= (safe_add_func_int8_t_s_s(l_21, 0x13L));
    }
    ++g_55;
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_20
 * writes: g_20
 */
static uint16_t  func_26(uint32_t  p_27, int64_t  p_28)
{ /* block id: 7 */
    g_20 = ((safe_sub_func_int32_t_s_s(5L, p_28)) != g_20);
    return p_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_41
 * writes: g_20
 */
static struct S0  func_38(int8_t  p_39)
{ /* block id: 18 */
    uint64_t l_40 = 3UL;
    l_40 = (0x442F2AA787D30FA2LL == p_39);
    g_20 = l_40;
    return g_41;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_41.f0, "g_41.f0", print_hash_value);
    transparent_crc(g_41.f1, "g_41.f1", print_hash_value);
    transparent_crc(g_41.f2, "g_41.f2", print_hash_value);
    transparent_crc(g_41.f3, "g_41.f3", print_hash_value);
    transparent_crc(g_41.f4, "g_41.f4", print_hash_value);
    transparent_crc(g_41.f5, "g_41.f5", print_hash_value);
    transparent_crc(g_41.f6, "g_41.f6", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_90[i][j], "g_90[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_95, "g_95", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 56
   depth: 2, occurrence: 14
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 78
XXX times a non-volatile is write: 33
XXX times a volatile is read: 13
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 61
XXX percentage of non-volatile access: 87.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 53
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 19
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 26.5
XXX percentage an existing variable is used: 73.5
********************* end of statistics **********************/

