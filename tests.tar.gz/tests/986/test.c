/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10736613572286590111
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[3] = {(-1L),(-1L),(-1L)};
static volatile int32_t g_4 = 6L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5[7] = {1L,0x4D8E5CCCL,1L,1L,0x4D8E5CCCL,1L,1L};
static uint8_t g_38[5] = {0x81L,0x81L,0x81L,0x81L,0x81L};
static uint64_t g_40 = 0UL;
static uint16_t g_90[6][3] = {{9UL,0UL,9UL},{9UL,65531UL,0UL},{65531UL,9UL,9UL},{0UL,9UL,1UL},{4UL,65531UL,0x6936L},{0UL,0UL,0x6936L}};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint8_t  func_15(int16_t  p_16, int32_t  p_17, int64_t  p_18, int16_t  p_19, uint64_t  p_20);
static uint16_t  func_32(int32_t  p_33, int32_t  p_34, uint64_t  p_35);
static int32_t  func_57(int32_t  p_58, const uint16_t  p_59, int8_t  p_60, const int32_t  p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3 g_2 g_4 g_38 g_40 g_90
 * writes: g_5 g_3 g_38 g_40 g_4 g_90
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_21 = 8L;
    int32_t l_48 = 0L;
    uint16_t l_51 = 0UL;
    for (g_5[5] = 4; (g_5[5] != 20); g_5[5] = safe_add_func_int64_t_s_s(g_5[5], 2))
    { /* block id: 3 */
        uint16_t l_12 = 0x0234L;
        const uint8_t l_27 = 0xF3L;
        int32_t l_28 = 0L;
        int32_t l_46 = (-1L);
        int8_t l_47 = 0xC7L;
        int32_t l_50 = 3L;
        if ((safe_lshift_func_uint8_t_u_u((((safe_rshift_func_uint8_t_u_s(l_12, g_3[2])) && 0x4727CAD7L) == l_12), 6)))
        { /* block id: 4 */
            int16_t l_39 = 0xED52L;
            if (g_2)
                break;
            g_3[2] = ((safe_mod_func_uint16_t_u_u(((func_15(((0x59L < 0xF1L) && (-7L)), l_21, l_12, g_2, g_5[2]) <= 0x3CL) , g_4), g_5[5])) >= l_27);
            l_28 &= g_3[2];
            g_40 ^= (safe_add_func_uint64_t_u_u((~(func_32(g_3[2], g_5[1], l_21) == 0x60E0L)), l_39));
        }
        else
        { /* block id: 20 */
            int8_t l_41 = 0xA9L;
            int32_t l_42 = (-9L);
            l_42 = (((l_12 <= g_4) > l_41) >= 7L);
            l_21 = 0x5D1AFC43L;
            return l_28;
        }
        for (l_28 = (-17); (l_28 <= (-11)); l_28 = safe_add_func_int8_t_s_s(l_28, 3))
        { /* block id: 27 */
            uint32_t l_45 = 1UL;
            int32_t l_49 = 0x13F4B1A2L;
            g_4 = l_45;
            --l_51;
        }
        if (((safe_mod_func_int8_t_s_s((~7UL), l_51)) == g_5[5]))
        { /* block id: 31 */
            uint64_t l_62 = 0x0E960871E8EE6221LL;
            l_46 = func_57(l_62, l_62, l_12, l_27);
        }
        else
        { /* block id: 78 */
            int16_t l_102 = 0L;
            int32_t l_103 = (-5L);
            l_103 = ((((((safe_mod_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((safe_lshift_func_int8_t_s_u(l_48, g_90[4][1])), 14)), g_40)) | l_50), 1UL)) && g_90[2][1]) && 4294967295UL) , 0x6A42263F48BF6E67LL) & 0xF7BC9C4D8F350A0FLL) , l_102);
            l_21 = g_4;
            l_48 = l_21;
        }
    }
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint8_t  func_15(int16_t  p_16, int32_t  p_17, int64_t  p_18, int16_t  p_19, uint64_t  p_20)
{ /* block id: 6 */
    int32_t l_26 = 0x99314E76L;
    l_26 = (((safe_mod_func_uint64_t_u_u((((safe_rshift_func_int8_t_s_s(l_26, 1)) , 1UL) , p_20), g_3[1])) & p_19) && p_20);
    return l_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_38
 * writes: g_38
 */
static uint16_t  func_32(int32_t  p_33, int32_t  p_34, uint64_t  p_35)
{ /* block id: 11 */
    for (p_35 = 18; (p_35 != 2); p_35--)
    { /* block id: 14 */
        p_33 ^= g_3[2];
    }
    g_38[3] |= ((((g_2 != p_33) , g_3[2]) ^ 0xE1602A05008D6DB9LL) < p_34);
    return g_3[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_5 g_4 g_2 g_38 g_40 g_90
 * writes: g_40 g_90
 */
static int32_t  func_57(int32_t  p_58, const uint16_t  p_59, int8_t  p_60, const int32_t  p_61)
{ /* block id: 32 */
    uint8_t l_63 = 0UL;
    uint64_t l_64 = 0xFB84C81E2E8C41CELL;
    int32_t l_65 = 2L;
    int32_t l_68 = 0xA2D62018L;
    int32_t l_69 = 0L;
    int32_t l_71 = 1L;
    int32_t l_72 = 7L;
    l_63 = (p_61 != 0x3AE8L);
lbl_80:
    if ((0x4219042FL >= l_64))
    { /* block id: 34 */
        int32_t l_70 = 0x1E1499B6L;
        l_65 = l_63;
        for (l_63 = 6; (l_63 < 33); ++l_63)
        { /* block id: 38 */
            uint32_t l_73 = 0x0E03A846L;
            ++l_73;
            return g_3[2];
        }
        p_58 = (safe_add_func_int8_t_s_s(g_5[3], g_4));
    }
    else
    { /* block id: 43 */
        return g_3[2];
    }
    if (l_71)
    { /* block id: 46 */
        for (l_65 = 0; (l_65 != 20); l_65 = safe_add_func_int16_t_s_s(l_65, 5))
        { /* block id: 49 */
            p_58 |= 7L;
            if (p_58)
                goto lbl_80;
        }
        if ((l_63 , l_64))
        { /* block id: 53 */
            p_58 = (safe_sub_func_uint8_t_u_u(p_61, g_2));
        }
        else
        { /* block id: 55 */
            return l_64;
        }
    }
    else
    { /* block id: 58 */
        for (l_63 = 0; (l_63 <= 4); l_63 += 1)
        { /* block id: 61 */
            int i;
            p_58 = ((safe_add_func_uint16_t_u_u(65535UL, 0UL)) == 2UL);
            p_58 = (((-8L) > g_38[l_63]) > 1UL);
            l_72 = p_60;
            if (g_3[2])
                continue;
        }
        for (g_40 = 0; (g_40 <= 2); g_40 += 1)
        { /* block id: 69 */
            uint32_t l_91 = 18446744073709551607UL;
            int i;
            l_69 ^= g_3[g_40];
            g_90[2][1] &= (~(safe_mod_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u(1UL, g_3[g_40])), g_38[(g_40 + 1)])));
            --l_91;
            p_58 = func_15(p_58, p_60, p_58, p_61, p_61);
        }
    }
    return l_71;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_38[i], "g_38[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_90[i][j], "g_90[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 31
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 12
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 59
XXX times a non-volatile is write: 32
XXX times a volatile is read: 21
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 41
XXX percentage of non-volatile access: 79.8

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 50
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 12
   depth: 2, occurrence: 27

XXX percentage a fresh-made variable is used: 27.4
XXX percentage an existing variable is used: 72.6
********************* end of statistics **********************/

