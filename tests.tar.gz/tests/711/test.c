/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9142512428710221153
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   int32_t  f1;
   int16_t  f2;
   volatile uint32_t  f3;
   int32_t  f4;
   int64_t  f5;
   int64_t  f6;
   uint64_t  f7;
   volatile int32_t  f8;
   int8_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static int8_t g_9 = 0x75L;
static volatile int16_t g_21 = (-1L);/* VOLATILE GLOBAL g_21 */
static int32_t g_37 = 0xF190218FL;
static volatile int16_t g_38 = 0x63FEL;/* VOLATILE GLOBAL g_38 */
static volatile uint32_t g_42 = 4294967295UL;/* VOLATILE GLOBAL g_42 */
static uint8_t g_79[4] = {249UL,249UL,249UL,249UL};
static uint8_t g_96 = 0x01L;
static int16_t g_113 = 1L;
static struct S0 g_114 = {0UL,4L,0x535FL,1UL,0x55CD4276L,0xE3E29BDB73D745D2LL,0xD446D23EE2624C86LL,0x8505D4F8719566CBLL,0x554E5FB2L,0x4BL};/* VOLATILE GLOBAL g_114 */


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static int32_t  func_2(int64_t  p_3, uint32_t  p_4, uint8_t  p_5, uint8_t  p_6);
static int64_t  func_7(int32_t  p_8);
static uint16_t  func_29(const uint8_t  p_30, uint16_t  p_31, int32_t  p_32, int8_t  p_33);
static int32_t  func_46(int16_t  p_47, int32_t  p_48);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_21 g_42 g_37 g_79 g_38 g_96 g_114
 * writes: g_9 g_42 g_37 g_79 g_96 g_113
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int32_t l_82[5];
    int i;
    for (i = 0; i < 5; i++)
        l_82[i] = 0x57AA2608L;
    g_113 = func_2(func_7(g_9), l_82[0], l_82[2], l_82[0]);
    return g_114;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_79 g_9 g_96 g_37 g_21
 * writes: g_37 g_9 g_96
 */
static int32_t  func_2(int64_t  p_3, uint32_t  p_4, uint8_t  p_5, uint8_t  p_6)
{ /* block id: 56 */
    uint16_t l_85 = 65532UL;
    int32_t l_86 = 0L;
    int32_t l_101 = 0xBAA0A5B8L;
    int32_t l_102 = 1L;
lbl_91:
    l_86 = (safe_mul_func_int8_t_s_s(((((((5UL && 0x8AE84C8BL) <= l_85) && 0xB5L) , l_85) , l_85) < l_85), (-4L)));
    for (p_5 = 0; (p_5 <= 45); p_5 = safe_add_func_int8_t_s_s(p_5, 3))
    { /* block id: 60 */
        uint32_t l_92[4];
        volatile int32_t l_93[10];
        int i;
        for (i = 0; i < 4; i++)
            l_92[i] = 18446744073709551615UL;
        for (i = 0; i < 10; i++)
            l_93[i] = 1L;
        g_37 = ((((0x4C0ED61DL & 0xE10C3079L) && g_38) <= g_79[0]) , 1L);
        for (g_9 = 14; (g_9 < (-14)); g_9 = safe_sub_func_uint16_t_u_u(g_9, 7))
        { /* block id: 64 */
            int32_t l_94 = (-1L);
            int32_t l_95 = 0L;
            if (g_9)
                goto lbl_91;
            g_37 = (p_3 , l_92[2]);
            l_93[4] = g_38;
            --g_96;
        }
        g_37 = ((0UL ^ g_37) != 0x5C23L);
        l_93[4] = ((g_21 >= (-9L)) && 255UL);
    }
    for (p_5 = 0; (p_5 == 16); ++p_5)
    { /* block id: 75 */
        int64_t l_103 = 0x35B4449FB5A3AA3BLL;
        for (g_96 = 0; (g_96 <= 3); g_96 += 1)
        { /* block id: 78 */
            uint8_t l_104 = 0UL;
            l_104--;
        }
        for (g_96 = 0; (g_96 <= 15); g_96 = safe_add_func_uint64_t_u_u(g_96, 1))
        { /* block id: 83 */
            int32_t l_111 = 0xEC08A347L;
            g_37 = (((safe_mul_func_int16_t_s_s(0xC860L, g_9)) , l_111) | g_37);
            if (p_4)
                break;
        }
        g_37 ^= (safe_unary_minus_func_uint8_t_u((((1UL < 0x82B1A140D65803A0LL) >= p_6) | p_4)));
        if (l_85)
            break;
    }
    return l_102;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_21 g_42 g_37 g_79
 * writes: g_9 g_42 g_37 g_79
 */
static int64_t  func_7(int32_t  p_8)
{ /* block id: 1 */
    uint64_t l_10[3][7][8] = {{{0x6F37D437F1BD53D2LL,0x8E6BAE055A24B834LL,3UL,18446744073709551615UL,0UL,3UL,0xB323FA9DFEEE83ADLL,18446744073709551606UL},{18446744073709551615UL,0UL,0x840CC74BF7A83239LL,0xFDB6968939F5FA31LL,0x3DE467B47E0FA1A8LL,0x840CC74BF7A83239LL,0UL,3UL},{3UL,0UL,18446744073709551606UL,0x6F37D437F1BD53D2LL,0UL,0xF851F08A1BAB0C3ELL,18446744073709551609UL,0xF851F08A1BAB0C3ELL},{0x6F37D437F1BD53D2LL,0xA9C1C73B017290B1LL,18446744073709551614UL,0xA9C1C73B017290B1LL,0x6F37D437F1BD53D2LL,0x981C5860BC23CEA2LL,0x8E6BAE055A24B834LL,0UL},{0x6E31BB000E2E4ED3LL,18446744073709551615UL,1UL,0x592404E5477A75E3LL,18446744073709551609UL,0x840CC74BF7A83239LL,0x592404E5477A75E3LL,0xA9C1C73B017290B1LL},{0UL,0UL,0x5156BE8236511F0BLL,0UL,18446744073709551614UL,0xE45661C443818264LL,18446744073709551615UL,3UL},{0x592404E5477A75E3LL,18446744073709551615UL,0xB323FA9DFEEE83ADLL,1UL,0x6E31BB000E2E4ED3LL,3UL,0x592404E5477A75E3LL,0xAA8E55A44198D72ALL}},{{18446744073709551615UL,0x840CC74BF7A83239LL,18446744073709551614UL,18446744073709551613UL,0xFAEB382E58099740LL,0x0E6B6CD333563700LL,0x0E6B6CD333563700LL,0xFAEB382E58099740LL},{0UL,0x1EDD1EDB6B7BE2D3LL,0x1EDD1EDB6B7BE2D3LL,0UL,0x5156BE8236511F0BLL,0x981C5860BC23CEA2LL,0xAA8E55A44198D72ALL,0x0E6B6CD333563700LL},{18446744073709551615UL,18446744073709551606UL,0x3DE467B47E0FA1A8LL,0xFAEB382E58099740LL,0x6E31BB000E2E4ED3LL,0x8E6BAE055A24B834LL,0xFDB6968939F5FA31LL,18446744073709551606UL},{0x1EDD1EDB6B7BE2D3LL,18446744073709551606UL,0x0E6B6CD333563700LL,3UL,0xF3E141B6BA00B6FBLL,0x981C5860BC23CEA2LL,18446744073709551613UL,0UL},{1UL,0x1EDD1EDB6B7BE2D3LL,0xE45661C443818264LL,0x840CC74BF7A83239LL,0x1EDD1EDB6B7BE2D3LL,0x0E6B6CD333563700LL,0UL,0xAFC1DA7BC9995890LL},{0xAA8E55A44198D72ALL,0x840CC74BF7A83239LL,0xA9C1C73B017290B1LL,0xF851F08A1BAB0C3ELL,0xFDB6968939F5FA31LL,3UL,0xFDB6968939F5FA31LL,0xF851F08A1BAB0C3ELL},{3UL,18446744073709551615UL,3UL,0x981C5860BC23CEA2LL,1UL,0xE45661C443818264LL,3UL,0x6E31BB000E2E4ED3LL}},{{0UL,0x0E6B6CD333563700LL,0x1EDD1EDB6B7BE2D3LL,0x840CC74BF7A83239LL,0xE45661C443818264LL,0x1EDD1EDB6B7BE2D3LL,1UL,18446744073709551613UL},{0UL,0xF851F08A1BAB0C3ELL,18446744073709551606UL,0xFDB6968939F5FA31LL,1UL,18446744073709551615UL,0x592404E5477A75E3LL,18446744073709551606UL},{3UL,0xFAEB382E58099740LL,0xAFC1DA7BC9995890LL,0x5156BE8236511F0BLL,0xFDB6968939F5FA31LL,0x39384257392715EELL,18446744073709551615UL,1UL},{0xAA8E55A44198D72ALL,0x981C5860BC23CEA2LL,0x5156BE8236511F0BLL,0UL,0x1EDD1EDB6B7BE2D3LL,0x1EDD1EDB6B7BE2D3LL,0UL,0x5156BE8236511F0BLL},{1UL,1UL,0x8E6BAE055A24B834LL,0UL,0xF3E141B6BA00B6FBLL,18446744073709551609UL,18446744073709551615UL,0xAA8E55A44198D72ALL},{0x1EDD1EDB6B7BE2D3LL,18446744073709551615UL,0xAFC1DA7BC9995890LL,0x0E6B6CD333563700LL,0x6E31BB000E2E4ED3LL,18446744073709551615UL,0x1EDD1EDB6B7BE2D3LL,0xAA8E55A44198D72ALL},{18446744073709551615UL,0xE45661C443818264LL,18446744073709551614UL,0UL,0x5156BE8236511F0BLL,0x0E6B6CD333563700LL,1UL,0x5156BE8236511F0BLL}}};
    int32_t l_18[6];
    int i, j, k;
    for (i = 0; i < 6; i++)
        l_18[i] = (-10L);
    for (p_8 = 2; (p_8 >= 0); p_8 -= 1)
    { /* block id: 4 */
        uint64_t l_16 = 0xD0C6A332E525B78CLL;
        int32_t l_20[6][7] = {{1L,0xF0912742L,(-5L),1L,0x630673EEL,0xB720FAE2L,1L},{1L,3L,1L,1L,1L,3L,1L},{(-1L),0xF0912742L,1L,0x7E7D1C2BL,0x630673EEL,3L,(-1L)},{1L,0xF0912742L,(-5L),1L,0x630673EEL,0xB720FAE2L,1L},{1L,3L,1L,1L,1L,3L,1L},{(-1L),0xF0912742L,1L,0x7E7D1C2BL,0x630673EEL,3L,(-1L)}};
        int i, j;
        for (g_9 = 0; (g_9 <= 2); g_9 += 1)
        { /* block id: 7 */
            uint32_t l_11 = 18446744073709551609UL;
            if (p_8)
                break;
            l_11 = (l_10[2][4][1] , g_9);
            l_16 = (safe_div_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(255UL, 0x19L)), g_9));
        }
        if (g_9)
        { /* block id: 12 */
            int64_t l_17[5][4] = {{0x5A5481F04FECCDF4LL,0x5A5481F04FECCDF4LL,0x191B86007675E6D9LL,0x5A5481F04FECCDF4LL},{0x5A5481F04FECCDF4LL,0x76A10B913A861D8DLL,0x76A10B913A861D8DLL,0x5A5481F04FECCDF4LL},{0x76A10B913A861D8DLL,0x5A5481F04FECCDF4LL,0x76A10B913A861D8DLL,0x76A10B913A861D8DLL},{0x5A5481F04FECCDF4LL,0x5A5481F04FECCDF4LL,0x191B86007675E6D9LL,0x5A5481F04FECCDF4LL},{0x5A5481F04FECCDF4LL,0x76A10B913A861D8DLL,0x76A10B913A861D8DLL,0x5A5481F04FECCDF4LL}};
            int32_t l_19 = 2L;
            int32_t l_22 = 2L;
            int32_t l_23[7] = {0x7C93E255L,0x7C93E255L,0x7C93E255L,0x7C93E255L,0x7C93E255L,0x7C93E255L,0x7C93E255L};
            uint8_t l_24 = 0x11L;
            int i, j;
            --l_24;
            return g_21;
        }
        else
        { /* block id: 15 */
            if (p_8)
                break;
        }
        l_20[1][5] = (safe_mul_func_int16_t_s_s((((func_29(g_21, g_9, g_9, p_8) != p_8) > 0xCFDEL) >= p_8), 0UL));
        g_37 = (g_37 > p_8);
        for (g_9 = 2; (g_9 >= 0); g_9 -= 1)
        { /* block id: 50 */
            l_18[2] = (safe_div_func_int16_t_s_s(p_8, g_21));
            return p_8;
        }
    }
    return l_10[0][0][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_42 g_21 g_37 g_79
 * writes: g_42 g_37 g_79
 */
static uint16_t  func_29(const uint8_t  p_30, uint16_t  p_31, int32_t  p_32, int8_t  p_33)
{ /* block id: 18 */
    int16_t l_34 = 0xEA11L;
    int32_t l_41 = 5L;
    int32_t l_71 = 0x2BB1B770L;
    l_34 = (g_9 >= g_9);
    for (l_34 = 0; (l_34 != (-11)); l_34--)
    { /* block id: 22 */
        int32_t l_39 = 1L;
        int32_t l_40 = 2L;
        ++g_42;
        if (((+l_41) >= g_21))
        { /* block id: 24 */
            return g_42;
        }
        else
        { /* block id: 26 */
            l_71 &= func_46(((l_41 , (-1L)) , 0x0014L), p_31);
        }
    }
    g_79[0] ^= (((safe_lshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u(((((+((0x780AL ^ g_42) > 0L)) && g_37) && l_41) > p_32), g_37)), g_9)), 4)) != 0xCFB0C79AL) ^ p_32);
    return g_79[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_9 g_37
 * writes: g_37
 */
static int32_t  func_46(int16_t  p_47, int32_t  p_48)
{ /* block id: 27 */
    uint16_t l_62[4] = {8UL,8UL,8UL,8UL};
    int32_t l_68 = 0xFCF0F435L;
    int i;
    for (p_47 = 6; (p_47 < (-26)); p_47 = safe_sub_func_int8_t_s_s(p_47, 1))
    { /* block id: 30 */
        int16_t l_61 = (-1L);
        l_62[2] &= ((safe_add_func_int32_t_s_s((safe_rshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_u((safe_sub_func_int64_t_s_s((((((safe_lshift_func_int8_t_s_u(((0x6454C9BF6A774B63LL || l_61) == p_47), 3)) < 5UL) <= p_48) == g_42) <= g_9), 0x02AC2FF03E53C530LL)), 5)), 5)), g_9)) | 0x42485FC01934DB4ALL);
        g_37 = (((safe_lshift_func_uint16_t_u_u((((safe_div_func_int64_t_s_s((~l_62[2]), l_62[2])) == 0x9D34L) > p_47), 8)) && 1UL) || g_42);
        l_68 = g_37;
        for (l_61 = 22; (l_61 < 9); --l_61)
        { /* block id: 36 */
            return g_9;
        }
    }
    return l_62[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_79[i], "g_79[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_114.f0, "g_114.f0", print_hash_value);
    transparent_crc(g_114.f1, "g_114.f1", print_hash_value);
    transparent_crc(g_114.f2, "g_114.f2", print_hash_value);
    transparent_crc(g_114.f3, "g_114.f3", print_hash_value);
    transparent_crc(g_114.f4, "g_114.f4", print_hash_value);
    transparent_crc(g_114.f5, "g_114.f5", print_hash_value);
    transparent_crc(g_114.f6, "g_114.f6", print_hash_value);
    transparent_crc(g_114.f7, "g_114.f7", print_hash_value);
    transparent_crc(g_114.f8, "g_114.f8", print_hash_value);
    transparent_crc(g_114.f9, "g_114.f9", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 37
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 45
   depth: 2, occurrence: 17
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 71
XXX times a non-volatile is write: 32
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 50
XXX percentage of non-volatile access: 88

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 51
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 19
   depth: 2, occurrence: 18

XXX percentage a fresh-made variable is used: 31.9
XXX percentage an existing variable is used: 68.1
********************* end of statistics **********************/

