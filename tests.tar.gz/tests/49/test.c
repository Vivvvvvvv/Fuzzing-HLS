/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3356563988022274666
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_2[6][2] = {{0x62L,0x0CL},{0x0CL,0x62L},{0x0CL,0x0CL},{0x62L,0x0CL},{0x0CL,0x62L},{0x0CL,0x0CL}};
static int32_t g_3 = 0x643CDF98L;
static int16_t g_29 = 0x3C9EL;
static uint8_t g_45 = 253UL;
static uint8_t g_56 = 0x7EL;
static uint64_t g_78 = 1UL;
static int8_t g_81 = 9L;
static uint64_t g_88 = 2UL;
static uint8_t g_124 = 0UL;
static volatile uint16_t g_125 = 0xA92DL;/* VOLATILE GLOBAL g_125 */
static int32_t g_129[6][3] = {{0L,0x28BBEDE7L,0x28BBEDE7L},{0x28BBEDE7L,(-1L),0x8A2AEEF2L},{0L,(-1L),0L},{0x743DCC97L,0x28BBEDE7L,0x8A2AEEF2L},{0x743DCC97L,0x743DCC97L,0x28BBEDE7L},{0L,0x28BBEDE7L,0x28BBEDE7L}};
static uint32_t g_149 = 0x5193B0A3L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_4(int32_t  p_5, uint32_t  p_6);
static int16_t  func_7(const uint32_t  p_8, int16_t  p_9, int64_t  p_10);
static uint16_t  func_11(int8_t  p_12);
static int8_t  func_18(int64_t  p_19, const int32_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_29 g_45 g_56 g_78 g_88 g_81 g_125 g_129 g_149
 * writes: g_3 g_29 g_45 g_56 g_78 g_81 g_88 g_124 g_125 g_129 g_149
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_140 = 0xB29366B1L;
    int32_t l_146 = 0x76D5697FL;
    int32_t l_147[3];
    int i;
    for (i = 0; i < 3; i++)
        l_147[i] = 7L;
    for (g_3 = 0; (g_3 <= 1); g_3 += 1)
    { /* block id: 3 */
        int32_t l_139 = 1L;
        int32_t l_148 = (-3L);
        g_129[3][2] = func_4((func_7(g_2[0][0], g_3, g_3) , g_2[2][0]), g_2[0][0]);
        g_129[4][1] |= (((safe_div_func_int8_t_s_s((g_45 & g_3), g_78)) && l_139) && 0x0C6D9DE4CBC4FE30LL);
        for (g_45 = 0; (g_45 <= 1); g_45 += 1)
        { /* block id: 105 */
            int i, j;
            l_140 = 0xCF321D07L;
            g_129[3][1] = (safe_mod_func_uint16_t_u_u((0x2765BD87C1AF1848LL < g_2[(g_45 + 4)][g_45]), g_2[(g_3 + 2)][g_45]));
            if (g_88)
                break;
            g_129[3][2] = 0x2AD158D1L;
        }
        g_129[2][2] = (-9L);
        for (g_81 = 1; (g_81 >= 0); g_81 -= 1)
        { /* block id: 114 */
            int32_t l_145[1][8][3] = {{{0x9B3848CAL,0x276630CEL,0x9B3848CAL},{0x9B3848CAL,0x276630CEL,0x9B3848CAL},{0x9B3848CAL,0x276630CEL,0x9B3848CAL},{0x9B3848CAL,0x276630CEL,0x9B3848CAL},{0x9B3848CAL,0x276630CEL,0x9B3848CAL},{0x9B3848CAL,0x9B3848CAL,(-1L)},{(-1L),0x9B3848CAL,(-1L)},{(-1L),0x9B3848CAL,(-1L)}}};
            int i, j, k;
            l_146 = (((safe_lshift_func_int8_t_s_u(((5UL != l_145[0][2][2]) && g_45), l_139)) || 0x3AC7BCD1L) > 0x840EC183001FCD46LL);
            g_149--;
        }
    }
    l_147[0] = (safe_mod_func_int64_t_s_s((g_45 & 0x2AL), g_45));
    return g_81;
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_88 g_3 g_56 g_29 g_81 g_125 g_2 g_78
 * writes: g_124 g_125 g_129 g_78
 */
static int32_t  func_4(int32_t  p_5, uint32_t  p_6)
{ /* block id: 64 */
    uint16_t l_98 = 0UL;
    uint64_t l_107 = 0x79BBF3D30447F09CLL;
    int32_t l_108 = 0x1B06647EL;
    uint32_t l_134 = 0xF3FA6EFEL;
    for (p_6 = 0; (p_6 != 56); ++p_6)
    { /* block id: 67 */
        int16_t l_97 = 8L;
        int32_t l_116 = 0xB51010FFL;
        int16_t l_128 = 1L;
        --l_98;
        if ((safe_rshift_func_int16_t_s_u((p_6 , l_98), g_45)))
        { /* block id: 69 */
            uint32_t l_109 = 0x81B1F863L;
            l_108 &= (((((((safe_mul_func_uint8_t_u_u((((((safe_rshift_func_int8_t_s_u(l_107, l_107)) == 65535UL) || p_5) <= 0xCCAC8DB39B42ED19LL) | l_98), p_6)) && g_88) <= 1L) > 0x4C5E220DL) && 0L) != l_107) | l_97);
            ++l_109;
        }
        else
        { /* block id: 72 */
            const uint32_t l_117 = 0x6E007783L;
            l_116 = ((safe_lshift_func_uint16_t_u_s((safe_sub_func_uint32_t_u_u(l_108, l_97)), g_3)) , l_97);
            p_5 = ((g_56 > 0L) > 0L);
            p_5 = (l_117 & (-5L));
            return l_117;
        }
        if ((safe_lshift_func_int8_t_s_s((g_29 != p_6), 4)))
        { /* block id: 78 */
            g_124 = (safe_sub_func_uint64_t_u_u((safe_rshift_func_int8_t_s_u((0UL == l_116), g_81)), p_6));
            g_125++;
        }
        else
        { /* block id: 81 */
            l_128 ^= 0x27C01AD3L;
        }
    }
    for (l_98 = 0; (l_98 <= 1); l_98 += 1)
    { /* block id: 87 */
        uint8_t l_133 = 0xBFL;
        for (l_108 = 0; (l_108 <= 1); l_108 += 1)
        { /* block id: 90 */
            int i, j;
            g_129[3][2] = 0x54B2775FL;
            p_5 |= (!(safe_add_func_int16_t_s_s((((0x21D6552DL < 0x62D5AFF6L) | 18446744073709551608UL) , g_2[(l_108 + 1)][l_108]), l_133)));
        }
        for (g_78 = 0; (g_78 <= 1); g_78 += 1)
        { /* block id: 96 */
            --l_134;
        }
    }
    return g_78;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_29 g_45 g_56 g_78 g_88
 * writes: g_29 g_45 g_56 g_78 g_81 g_88
 */
static int16_t  func_7(const uint32_t  p_8, int16_t  p_9, int64_t  p_10)
{ /* block id: 4 */
    int32_t l_13 = 3L;
    int32_t l_89 = 0xD6DDE4B2L;
    g_81 = ((((func_11(l_13) || p_10) > l_13) == p_9) <= p_9);
    for (p_10 = 0; (p_10 <= 1); ++p_10)
    { /* block id: 51 */
        int32_t l_86 = 0x84500A6BL;
        int32_t l_94 = 0xF4E0B4B7L;
        for (g_78 = 22; (g_78 != 47); g_78++)
        { /* block id: 54 */
            uint16_t l_87 = 0x2EF8L;
            g_88 = ((l_86 && p_8) > l_87);
            l_89 = ((l_87 >= 0L) , g_88);
            return p_8;
        }
        if (g_45)
            continue;
        l_89 |= (safe_mod_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u(g_29, p_8)), l_13));
        l_94 &= (l_86 , g_45);
    }
    return g_2[5][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_29 g_45 g_56 g_78
 * writes: g_29 g_45 g_56 g_78
 */
static uint16_t  func_11(int8_t  p_12)
{ /* block id: 5 */
    uint8_t l_25[7] = {0xBDL,0xBDL,0xBDL,0xBDL,0xBDL,0xBDL,0xBDL};
    int32_t l_74 = 0x92FBB161L;
    int32_t l_75 = 0L;
    int32_t l_76 = 0L;
    int32_t l_77[9][9][3] = {{{(-1L),0x28A4BD3CL,0L},{0x1ADEC5ABL,0x11537C3EL,0L},{1L,0L,0x1A718AF6L},{0L,0x755D88D3L,4L},{6L,0x755D88D3L,0x1C601181L},{(-9L),0L,0x96DCF8DEL},{0x11537C3EL,0x11537C3EL,(-4L)},{(-1L),0x28A4BD3CL,(-1L)},{(-1L),0x5FAC05FCL,4L}},{{1L,0x73013A2AL,0x37E92B0DL},{(-1L),(-1L),4L},{0x11537C3EL,0x1ADEC5ABL,(-1L)},{4L,0L,(-4L)},{(-10L),0x5FAC05FCL,0x96DCF8DEL},{(-1L),0xD269A62DL,0x1C601181L},{0x1ADEC5ABL,(-10L),4L},{0x1ADEC5ABL,(-1L),0x1A718AF6L},{(-1L),(-1L),0L}},{{(-10L),0x755D88D3L,0L},{4L,0x73013A2AL,0x03C69C83L},{0x11537C3EL,(-10L),0x96DCF8DEL},{(-1L),(-9L),(-1L)},{1L,(-10L),0L},{(-1L),0x73013A2AL,(-7L)},{(-1L),0x755D88D3L,1L},{0x11537C3EL,(-1L),0L},{(-9L),(-1L),(-4L)}},{{6L,(-10L),(-4L)},{0L,0xD269A62DL,0L},{1L,0x5FAC05FCL,1L},{0x1ADEC5ABL,0L,(-7L)},{(-1L),0x1ADEC5ABL,0L},{6L,(-1L),(-1L)},{0x28A4BD3CL,0x73013A2AL,0x96DCF8DEL},{6L,0x5FAC05FCL,0x03C69C83L},{(-1L),0x28A4BD3CL,0L}},{{0x1ADEC5ABL,0x11537C3EL,0L},{1L,0L,0x1A718AF6L},{0L,0x755D88D3L,4L},{6L,0x755D88D3L,0x1C601181L},{(-9L),0L,0x96DCF8DEL},{0x11537C3EL,0x11537C3EL,(-4L)},{(-1L),0x28A4BD3CL,(-1L)},{(-1L),0x5FAC05FCL,4L},{1L,0x73013A2AL,0x37E92B0DL}},{{(-1L),(-1L),4L},{0x11537C3EL,0x1ADEC5ABL,(-1L)},{4L,0L,(-4L)},{(-10L),0x5FAC05FCL,0x96DCF8DEL},{(-1L),0xD269A62DL,0x1C601181L},{0x1ADEC5ABL,(-10L),4L},{0x1ADEC5ABL,(-1L),0x1A718AF6L},{(-1L),(-1L),0L},{(-10L),0x755D88D3L,0L}},{{4L,0x73013A2AL,0x03C69C83L},{0x11537C3EL,(-10L),0x96DCF8DEL},{(-1L),(-9L),(-1L)},{1L,(-10L),0L},{(-1L),0x73013A2AL,0L},{0x1EE1831FL,(-1L),(-6L)},{1L,0L,0x2479274DL},{1L,0x39FE21ACL,6L},{0x700432F2L,(-3L),6L}},{{(-8L),0xF0E5992BL,0x2479274DL},{(-1L),0xA37A7FFAL,(-6L)},{0L,(-8L),0L},{0x39FE21ACL,0L,4L},{0x700432F2L,0L,0xAF0014B0L},{0x2280F24AL,(-2L),0x5FAC05FCL},{0x700432F2L,0xA37A7FFAL,1L},{0x39FE21ACL,0x2280F24AL,0x2479274DL},{0L,1L,4L}},{{(-1L),(-8L),0x45391C29L},{(-8L),(-1L),0xD269A62DL},{0x700432F2L,(-1L),0x1361DE36L},{1L,(-8L),0x5FAC05FCL},{1L,1L,6L},{0x1EE1831FL,0x2280F24AL,0xAF0014B0L},{0L,0xA37A7FFAL,0xD269A62DL},{(-1L),(-2L),(-1L)},{0x39FE21ACL,0L,0xD269A62DL}}};
    int i, j, k;
    for (p_12 = 5; (p_12 <= 4); p_12 = safe_sub_func_int16_t_s_s(p_12, 8))
    { /* block id: 8 */
        int64_t l_73 = 1L;
        l_73 = (((safe_mul_func_int8_t_s_s(func_18(((safe_sub_func_int32_t_s_s(((safe_mul_func_int8_t_s_s(l_25[2], 248UL)) & p_12), p_12)) , g_2[2][1]), p_12), 0UL)) > g_3) <= 0x9E21L);
    }
    g_78++;
    l_75 = l_76;
    return l_77[7][5][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_2 g_45 g_56
 * writes: g_29 g_45 g_56
 */
static int8_t  func_18(int64_t  p_19, const int32_t  p_20)
{ /* block id: 9 */
    uint32_t l_38 = 18446744073709551615UL;
    int32_t l_39 = 0x6883CE71L;
    uint64_t l_49 = 0xA42286E0DAEE2552LL;
    for (p_19 = 15; (p_19 != (-28)); --p_19)
    { /* block id: 12 */
        int32_t l_28 = 0x41B87000L;
        l_28 ^= (((1UL <= p_19) == 255UL) && 0x5609L);
    }
    if (((0L >= g_3) , 0xFC167656L))
    { /* block id: 15 */
        int64_t l_33 = 0L;
        int32_t l_40[8] = {0x510212AEL,0x510212AEL,0x510212AEL,0x510212AEL,0x510212AEL,0x510212AEL,0x510212AEL,0x510212AEL};
        int i;
        for (p_19 = 0; (p_19 <= 1); p_19 += 1)
        { /* block id: 18 */
            g_29 = (p_19 | g_3);
        }
        if ((((~(safe_rshift_func_int8_t_s_u(g_29, 0))) != l_33) , g_2[3][0]))
        { /* block id: 21 */
            int32_t l_34 = 0xBA684A08L;
            int32_t l_35 = 1L;
            l_35 |= l_34;
            l_35 = (l_35 || g_29);
            l_39 = ((safe_mod_func_int32_t_s_s((l_38 , 0x26529694L), g_3)) && p_20);
            l_40[7] = ((p_19 > 1UL) >= p_19);
        }
        else
        { /* block id: 26 */
            int16_t l_46[9][9] = {{0L,0x35F2L,(-1L),0L,0x6DF3L,0L,(-1L),0x35F2L,0L},{1L,0L,(-1L),1L,0x20B8L,1L,1L,1L,1L},{(-1L),0x6DF3L,0xDCFDL,0xDCFDL,0x6DF3L,(-1L),1L,0xAFC4L,0xDCFDL},{1L,0x20B8L,1L,(-1L),0L,1L,1L,0L,(-1L)},{0L,0x6DF3L,0L,(-1L),0x35F2L,0L,1L,9L,(-1L)},{0x2A45L,0L,1L,0x2A45L,0xF913L,0x2A45L,1L,0L,0x2A45L},{3L,0x35F2L,0xDCFDL,(-1L),8L,3L,(-1L),0xAFC4L,(-1L)},{1L,0xF913L,(-1L),(-1L),0xF913L,1L,0x3744L,1L,(-1L)},{3L,8L,(-1L),0xDCFDL,0x35F2L,3L,3L,0x35F2L,0xDCFDL}};
            int i, j;
            g_45 = ((~(safe_rshift_func_uint16_t_u_u((safe_unary_minus_func_int16_t_s(p_20)), p_20))) & (-3L));
            l_39 ^= (g_29 & g_3);
            l_46[4][6] = (((g_45 == g_45) , g_2[4][1]) , 0x43B57941L);
            l_49 &= (safe_div_func_int8_t_s_s(l_46[1][0], p_20));
        }
    }
    else
    { /* block id: 32 */
        const uint32_t l_55 = 1UL;
        uint32_t l_59 = 0x5AD7CBC1L;
        int32_t l_60 = 0xB33B75CAL;
        if ((((+((safe_lshift_func_uint16_t_u_u((safe_div_func_int8_t_s_s(l_55, g_2[4][1])), g_2[4][0])) == 7L)) == 0L) | 0x251D1740L))
        { /* block id: 33 */
            g_56 &= (4294967295UL != 0x39CA31B8L);
            l_60 &= ((safe_lshift_func_int8_t_s_u(l_59, p_20)) != 1L);
        }
        else
        { /* block id: 36 */
            l_60 = ((safe_mul_func_int8_t_s_s(((safe_mod_func_int16_t_s_s(((safe_sub_func_int16_t_s_s((safe_sub_func_int16_t_s_s((safe_div_func_uint32_t_u_u(((p_20 != 0xC533BF95235BB1E2LL) < g_29), p_19)), 0xDD37L)), 0xBA14L)) < p_19), 0x2796L)) && p_19), g_3)) || 0x06CD8FDAL);
            return g_45;
        }
        l_39 = (safe_add_func_int8_t_s_s(g_29, l_38));
    }
    return g_2[0][1];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_129[i][j], "g_129[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_149, "g_149", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 49
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 66
   depth: 2, occurrence: 20
   depth: 3, occurrence: 12
   depth: 4, occurrence: 6
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 121
XXX times a non-volatile is write: 54
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 33
XXX percentage of non-volatile access: 99.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 70
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 20
   depth: 2, occurrence: 34

XXX percentage a fresh-made variable is used: 27.5
XXX percentage an existing variable is used: 72.5
********************* end of statistics **********************/

