/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7332309304950521578
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_7 = (-7L);
static uint32_t g_14 = 1UL;
static int32_t g_27 = 0x9E62B560L;
static int32_t g_28 = (-1L);
static uint32_t g_31 = 0x5BEAC3EFL;
static volatile int32_t g_36 = (-1L);/* VOLATILE GLOBAL g_36 */
static volatile uint64_t g_38 = 0x9E4A0435E45DB0FFLL;/* VOLATILE GLOBAL g_38 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(int16_t  p_3, uint16_t  p_4, int16_t  p_5, const int32_t  p_6);
static int32_t  func_11(int8_t  p_12, int16_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_14 g_31 g_38 g_36 g_27
 * writes: g_14 g_27 g_31 g_38
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_8 = (-10L);
    const uint32_t l_9 = 0xA622A149L;
    int32_t l_29 = 0xDDC87778L;
    int32_t l_30 = 0L;
    int32_t l_51 = 1L;
    g_27 = func_2(g_7, l_8, g_7, l_9);
    --g_31;
    for (l_29 = 0; (l_29 >= (-20)); l_29 = safe_sub_func_int8_t_s_s(l_29, 2))
    { /* block id: 17 */
        int32_t l_37 = 0x71E9942CL;
        const uint64_t l_44 = 0x996E1580EB60F9AALL;
        g_38--;
        l_30 &= ((+(safe_rshift_func_int16_t_s_s(((((-1L) >= g_36) && 0x19FA4A60L) | l_44), l_8))) & 5L);
        l_30 &= (safe_mod_func_uint16_t_u_u(((g_27 == g_7) >= 2UL), l_9));
    }
    l_51 = ((((safe_mul_func_uint16_t_u_u(((safe_div_func_int32_t_s_s(0x5EB7F464L, 0x128B293CL)) ^ (-1L)), 0x3980L)) , 0xC5C2L) >= 65534UL) , g_14);
    return l_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_14
 * writes: g_14
 */
static int32_t  func_2(int16_t  p_3, uint16_t  p_4, int16_t  p_5, const int32_t  p_6)
{ /* block id: 1 */
    uint64_t l_10[3];
    int32_t l_22 = 1L;
    int i;
    for (i = 0; i < 3; i++)
        l_10[i] = 0x2CA3C0BF90A23371LL;
    for (p_3 = 0; (p_3 <= 2); p_3 += 1)
    { /* block id: 4 */
        const int32_t l_21 = 0x74DA8628L;
        int32_t l_26 = (-1L);
        int i;
        g_14 = func_11(l_10[p_3], l_10[p_3]);
        l_22 = ((((safe_mod_func_uint16_t_u_u((safe_sub_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(l_21, 0)), p_5)), 4L)) || l_10[p_3]) | p_3) < l_10[2]);
        l_26 = (safe_mul_func_int8_t_s_s((!((l_10[0] & l_21) , l_21)), p_3));
        if (g_14)
            break;
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_7
 * writes:
 */
static int32_t  func_11(int8_t  p_12, int16_t  p_13)
{ /* block id: 5 */
    return g_7;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 27
XXX times a non-volatile is write: 10
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 94.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 7

XXX percentage a fresh-made variable is used: 43.6
XXX percentage an existing variable is used: 56.4
********************* end of statistics **********************/

