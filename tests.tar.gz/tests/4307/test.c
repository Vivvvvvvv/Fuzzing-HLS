/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2733227879395244026
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int16_t  f0;
   volatile int64_t  f1;
   uint32_t  f2;
   int8_t  f3;
   uint32_t  f4;
   int16_t  f5;
   uint16_t  f6;
   const uint64_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static const volatile int16_t g_15 = 0xD1AFL;/* VOLATILE GLOBAL g_15 */
static uint16_t g_16 = 0UL;
static int16_t g_28 = 1L;
static uint32_t g_29 = 1UL;
static struct S0 g_31 = {0xD538L,1L,1UL,0x4DL,1UL,0x688DL,0x39BEL,18446744073709551609UL};/* VOLATILE GLOBAL g_31 */
static int16_t g_32 = 0L;
static int32_t g_37 = (-8L);


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static struct S0  func_2(int16_t  p_3, uint32_t  p_4, uint16_t  p_5);
static int8_t  func_18(int64_t  p_19, int8_t  p_20, uint8_t  p_21, uint32_t  p_22, uint32_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_31 g_29 g_37 g_28
 * writes: g_28 g_29 g_32 g_37
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_14[1];
    int32_t l_17[4];
    int i;
    for (i = 0; i < 1; i++)
        l_14[i] = 0x17473468L;
    for (i = 0; i < 4; i++)
        l_17[i] = (-1L);
    g_32 = (func_2(((safe_rshift_func_int16_t_s_s((safe_div_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u((((safe_lshift_func_uint16_t_u_u((l_14[0] && g_15), l_14[0])) | 4UL) , l_14[0]), l_14[0])) , l_14[0]) | 65528UL), g_16)), l_14[0])) , l_17[1]), g_16, g_16) , l_17[3]);
    g_37 |= ((safe_add_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((g_16 && l_14[0]), g_29)), l_17[1])) >= 0L);
    return g_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_31
 * writes: g_28 g_29
 */
static struct S0  func_2(int16_t  p_3, uint32_t  p_4, uint16_t  p_5)
{ /* block id: 1 */
    int64_t l_24 = (-1L);
    int32_t l_30 = 0x9611CA4BL;
    g_29 = ((func_18(p_5, g_16, l_24, g_16, l_24) ^ 0x87L) && p_5);
    l_30 = p_4;
    l_30 ^= 0xB72B416CL;
    return g_31;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_28
 */
static int8_t  func_18(int64_t  p_19, int8_t  p_20, uint8_t  p_21, uint32_t  p_22, uint32_t  p_23)
{ /* block id: 2 */
    int8_t l_27 = 0x9DL;
    g_28 = (safe_add_func_int8_t_s_s(l_27, 0xD3L));
    return l_27;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_31.f0, "g_31.f0", print_hash_value);
    transparent_crc(g_31.f1, "g_31.f1", print_hash_value);
    transparent_crc(g_31.f2, "g_31.f2", print_hash_value);
    transparent_crc(g_31.f3, "g_31.f3", print_hash_value);
    transparent_crc(g_31.f4, "g_31.f4", print_hash_value);
    transparent_crc(g_31.f5, "g_31.f5", print_hash_value);
    transparent_crc(g_31.f6, "g_31.f6", print_hash_value);
    transparent_crc(g_31.f7, "g_31.f7", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 1
   depth: 5, occurrence: 1
   depth: 8, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 6
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 97

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 9
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 9

XXX percentage a fresh-made variable is used: 36.4
XXX percentage an existing variable is used: 63.6
********************* end of statistics **********************/

