/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17612561020254810681
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3[7][4][9] = {{{0xFEF5379AL,0x276CC72BL,0x757520C2L,0x116E074FL,1L,(-6L),3L,0xF0BDE8AFL,0x7A5B7D8CL},{(-8L),0xAAFE30F5L,4L,0xBC75B167L,0x40437E10L,0x99DA9727L,(-8L),1L,0x289FFF12L},{(-2L),0xF0BDE8AFL,(-6L),(-7L),1L,0x8664A116L,0x662DB8E9L,0L,0xBD791F9EL},{(-1L),0x33631AF6L,0x289FFF12L,0x99DA9727L,0xAAFE30F5L,0x289FFF12L,0x5D742CC3L,1L,(-8L)}},{{(-1L),0x095E04A2L,3L,0x1734826AL,0xF5E3D1AAL,0x1CB6A7F4L,0xE17C927DL,0xF0BDE8AFL,0x8664A116L},{(-8L),0x3E5C7D81L,(-10L),(-10L),(-8L),(-10L),(-10L),0x3E5C7D81L,1L},{8L,0x757520C2L,0xE7A4860CL,0x493E623BL,0x1CB6A7F4L,0x883EB999L,0xD89C1C50L,0xBD791F9EL,0xEFB659BAL},{0L,0L,(-5L),1L,0x5D742CC3L,0L,1L,(-1L),0x7A5EAFB5L}},{{8L,0x1CB6A7F4L,0xD89C1C50L,(-1L),(-6L),0xE7A4860CL,0xCB6D64BDL,0x116E074FL,0x8555145CL},{1L,0x1EF4FC6AL,0x9310C13FL,0xC9ED9BA0L,(-1L),0x2AFD77CCL,(-5L),0xBC75B167L,0x9310C13FL},{0xB4415E40L,0x1CB6A7F4L,2L,0x8555145CL,0xAEA0A9F4L,4L,0x493E623BL,(-7L),8L},{(-8L),0L,8L,7L,0x99DA9727L,1L,1L,0x99DA9727L,7L}},{{2L,0x757520C2L,2L,0xE7A4860CL,0x116E074FL,2L,0x58D83F7CL,0x1734826AL,0x7A4EF21DL},{(-10L),0x3E5C7D81L,0x9310C13FL,(-1L),0x1EF4FC6AL,(-10L),7L,(-8L),1L},{0xE7A4860CL,(-1L),0xD89C1C50L,0xE7A4860CL,0x7A5B7D8CL,0x4DBC0BA8L,0xC5530C4EL,0x5B1B6FD4L,0x58D83F7CL},{0xC9ED9BA0L,(-6L),(-5L),7L,0xA4F69A75L,(-1L),0x2AFD77CCL,0xE6D4F288L,(-1L)}},{{0x8A6EBBFAL,0L,0xE7A4860CL,0x8555145CL,0x7A5B7D8CL,0xEFB659BAL,2L,3L,0xD89C1C50L},{8L,4L,(-10L),0xC9ED9BA0L,0x1EF4FC6AL,0x5B0E446DL,0L,0L,0L},{0xEFB659BAL,0x116E074FL,(-1L),(-1L),0x116E074FL,0xEFB659BAL,4L,0x7A5B7D8CL,0xB4415E40L},{0L,0xE6D4F288L,0x7A5EAFB5L,1L,0x99DA9727L,(-1L),(-8L),0xBF5F40E1L,0L}},{{4L,(-6L),0x7A4EF21DL,0x493E623BL,0xAEA0A9F4L,0x4DBC0BA8L,4L,0xFEF5379AL,2L},{0x5B0E446DL,0xBF5F40E1L,(-1L),(-10L),(-1L),(-10L),0L,4L,0xC9ED9BA0L},{(-1L),0x662DB8E9L,2L,0x4DBC0BA8L,(-6L),2L,2L,0xFEF5379AL,0xCB6D64BDL},{0x9310C13FL,1L,(-8L),0x52BF390FL,0x5D742CC3L,1L,0x2AFD77CCL,0xBF5F40E1L,(-10L)}},{{0xCB6D64BDL,0x7A5B7D8CL,0xC5530C4EL,4L,0x1CB6A7F4L,4L,0xC5530C4EL,0x7A5B7D8CL,0xCB6D64BDL},{0L,0x289FFF12L,0L,(-5L),(-8L),0x2AFD77CCL,7L,0L,0xC9ED9BA0L},{0x8555145CL,0xBD791F9EL,0x493E623BL,9L,2L,1L,9L,(-1L),1L},{0x40437E10L,1L,0xA0122D80L,0x33631AF6L,(-1L),0L,7L,1L,0L}}};
static uint32_t g_5 = 0x3E4F9F01L;
static uint64_t g_14 = 0x54ED7DDA2347DC7ALL;
static uint16_t g_85[10][3] = {{0xBC01L,0x90A8L,0x90A8L},{0x8CC6L,9UL,0x47DCL},{0xBC01L,65535UL,0xBC01L},{0UL,0x8CC6L,0x47DCL},{0x8CB1L,0x8CB1L,0x90A8L},{65533UL,0x8CC6L,0x8CC6L},{0x90A8L,65535UL,65531UL},{65533UL,9UL,65533UL},{0x8CB1L,0x90A8L,65531UL},{0UL,0UL,0x8CC6L}};
static volatile uint32_t g_107 = 1UL;/* VOLATILE GLOBAL g_107 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_8(int32_t  p_9, int8_t  p_10, int32_t  p_11, int64_t  p_12);
static uint8_t  func_43(int64_t  p_44, uint16_t  p_45);
static int8_t  func_46(const int16_t  p_47, int32_t  p_48, int64_t  p_49, uint32_t  p_50);
static const int32_t  func_65(const int32_t  p_66, uint16_t  p_67, int64_t  p_68, uint16_t  p_69);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_5 g_14 g_85 g_107
 * writes: g_3 g_5 g_85
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2[3];
    int8_t l_4 = 0L;
    int32_t l_15 = 0x6214FB9BL;
    int32_t l_21 = 5L;
    int32_t l_22 = (-1L);
    uint32_t l_23 = 5UL;
    int32_t l_29 = 0L;
    int i;
    for (i = 0; i < 3; i++)
        l_2[i] = (-1L);
    for (g_3[1][1][4] = 2; (g_3[1][1][4] >= 0); g_3[1][1][4] -= 1)
    { /* block id: 3 */
        const int64_t l_13[10][7][3] = {{{0xD46FEDEA8F4439D3LL,(-10L),0L},{0xC5B2E90E87CA6189LL,0xD18CDA47519AD364LL,0L},{0L,1L,0L},{1L,3L,0xDE0F7F7A374779CFLL},{0x2EB69FE4373440B9LL,0L,(-10L)},{0xEB7CCD0311C0D400LL,(-6L),(-1L)},{0L,0x18A8DC8D62BAD2CCLL,1L}},{{0xEB7CCD0311C0D400LL,0xB5251BB39D90DC6CLL,0x7D3B875039639DBCLL},{0x2EB69FE4373440B9LL,(-8L),0xE15D11E9056FF37ELL},{1L,0xD1A1FBCDA4F1DFBALL,0xA3BBE75688AFC007LL},{0L,1L,1L},{0xC5B2E90E87CA6189LL,0L,(-7L)},{0xD46FEDEA8F4439D3LL,0xCA48CC9215A14429LL,0L},{0x513B6624E94FA9F1LL,0x330C202EAB385FAELL,0xBCFA1F81FC11418CLL}},{{0x20603003393D3B28LL,0L,(-8L)},{0x5B94995FB43C6211LL,0x330C202EAB385FAELL,(-1L)},{0L,0xCA48CC9215A14429LL,0x4644DEA1A09BBF73LL},{(-4L),0L,0x7D3B875039639DBCLL},{0L,1L,6L},{0x67E6262DCCEB0059LL,0xD1A1FBCDA4F1DFBALL,0xC5B2E90E87CA6189LL},{6L,(-8L),0x22C044B22B5D7664LL}},{{0xC5B2E90E87CA6189LL,0xB5251BB39D90DC6CLL,0xEE77D733C455447BLL},{0x4B8798E375BC53ECLL,0x18A8DC8D62BAD2CCLL,0L},{1L,(-6L),0xEE77D733C455447BLL},{0xB92745916079B8BCLL,0L,0x22C044B22B5D7664LL},{(-5L),3L,0xC5B2E90E87CA6189LL},{0L,1L,6L},{0x7D3B875039639DBCLL,0xD18CDA47519AD364LL,0x7D3B875039639DBCLL}},{{(-8L),(-10L),0x4644DEA1A09BBF73LL},{0xF94618C45603FBD5LL,0xD1A1FBCDA4F1DFBALL,(-1L)},{0x7991EE5052BDF33DLL,0L,(-8L)},{0xC5B2E90E87CA6189LL,(-1L),0xBCFA1F81FC11418CLL},{0x7991EE5052BDF33DLL,(-1L),0L},{0xF94618C45603FBD5LL,0x0F1F8A7072EE8FFCLL,(-7L)},{(-8L),0L,1L}},{{0x7D3B875039639DBCLL,1L,0xA3BBE75688AFC007LL},{0L,8L,0xE15D11E9056FF37ELL},{(-5L),1L,0x7D3B875039639DBCLL},{0xB92745916079B8BCLL,0x22C044B22B5D7664LL,1L},{1L,0xD1A1FBCDA4F1DFBALL,(-1L)},{0x4B8798E375BC53ECLL,0x22C044B22B5D7664LL,(-10L)},{0xC5B2E90E87CA6189LL,1L,0xDE0F7F7A374779CFLL}},{{6L,8L,0L},{0x67E6262DCCEB0059LL,1L,0L},{0L,0L,0L},{(-4L),0x0F1F8A7072EE8FFCLL,1L},{0L,(-1L),6L},{0x5B94995FB43C6211LL,(-1L),0x7D3B875039639DBCLL},{0x20603003393D3B28LL,0x4B8798E375BC53ECLL,0xCA48CC9215A14429LL}},{{(-1L),(-6L),0xEB7CCD0311C0D400LL},{6L,6L,0x4B8798E375BC53ECLL},{0x5B94995FB43C6211LL,0xD1A1FBCDA4F1DFBALL,0xE5BE992D143BF1F8LL},{1L,0L,1L},{(-1L),0x7DFBF73ECB6AEF2DLL,0x1DE2FC23FAAB93B5LL},{1L,0L,6L},{0L,1L,(-5L)}},{{0x4B8798E375BC53ECLL,0x20603003393D3B28LL,8L},{0L,(-1L),0xBCFA1F81FC11418CLL},{1L,0xD46FEDEA8F4439D3LL,(-1L)},{(-1L),(-6L),0x7D3B875039639DBCLL},{1L,0L,0L},{0x5B94995FB43C6211LL,0x30E041B8CD5F0970LL,(-5L)},{6L,0x2EB69FE4373440B9LL,1L}},{{(-1L),0x0F4CAC200E08B7C8LL,0xC4A2FBAA6DCE64F8LL},{0x22C044B22B5D7664LL,0L,0xD46FEDEA8F4439D3LL},{(-7L),0x0F4CAC200E08B7C8LL,(-4L)},{0x4B8798E375BC53ECLL,0x2EB69FE4373440B9LL,0x18A8DC8D62BAD2CCLL},{0xDE0F7F7A374779CFLL,0x30E041B8CD5F0970LL,0xBCFA1F81FC11418CLL},{0L,0L,1L},{0xC5B2E90E87CA6189LL,(-6L),0x5B94995FB43C6211LL}}};
        int i, j, k;
        g_5--;
        if (l_2[g_3[1][1][4]])
            break;
        l_15 &= func_8((l_13[6][2][1] <= g_3[1][1][4]), g_5, l_4, g_14);
        l_15 = (l_2[g_3[1][1][4]] , l_13[5][2][1]);
    }
    g_3[1][1][4] = (~(g_5 != g_5));
    if (((safe_rshift_func_uint16_t_u_s((l_15 > g_5), 6)) && g_3[1][1][4]))
    { /* block id: 12 */
        int32_t l_19 = 3L;
        int32_t l_20[5];
        int i;
        for (i = 0; i < 5; i++)
            l_20[i] = 0x0BDFC586L;
lbl_26:
        l_19 = g_3[3][2][7];
        l_20[4] = func_8((((l_19 , (-1L)) == l_19) >= g_5), g_3[1][1][4], g_3[1][1][4], l_15);
        ++l_23;
        if (l_4)
            goto lbl_26;
    }
    else
    { /* block id: 17 */
        const int64_t l_30 = 1L;
        g_3[0][1][2] = (safe_add_func_uint64_t_u_u(func_8(g_14, g_14, g_5, g_5), 0x46250C50EEEE7CDALL));
        g_3[1][1][4] = (((l_29 > g_3[1][1][4]) , l_30) & 0x10C6DFD39EDE0374LL);
    }
    if ((((((safe_sub_func_int32_t_s_s((l_22 >= (-1L)), l_29)) && l_4) , l_22) || 1L) , l_23))
    { /* block id: 21 */
        int32_t l_93 = (-3L);
        g_3[1][1][4] = (safe_lshift_func_int8_t_s_u(((safe_unary_minus_func_uint16_t_u(((safe_sub_func_uint64_t_u_u((safe_lshift_func_int16_t_s_u((((safe_unary_minus_func_int8_t_s(((((safe_add_func_uint8_t_u_u(func_43((func_46(l_23, g_5, g_14, g_3[0][2][6]) , g_85[0][0]), l_29), g_14)) , 0xEC9AL) , g_3[1][1][4]) , l_21))) , l_93) != 0xEAL), 4)), 0x4F830CD010C7F523LL)) == 0xCAL))) , l_15), 3));
        if ((safe_lshift_func_int8_t_s_s(l_29, l_4)))
        { /* block id: 51 */
            uint8_t l_98[4] = {0x5FL,0x5FL,0x5FL,0x5FL};
            int i;
            g_3[1][1][4] = (((((safe_mul_func_uint8_t_u_u(g_5, g_85[0][0])) <= g_3[1][1][4]) < l_98[1]) , 2UL) || g_85[9][0]);
        }
        else
        { /* block id: 53 */
            l_15 = (l_23 ^ 0x6D7480F3EF49E9CALL);
        }
        for (l_15 = 0; (l_15 <= 3); l_15 += 1)
        { /* block id: 58 */
            uint64_t l_103 = 18446744073709551615UL;
            int32_t l_105 = (-2L);
            if (g_85[6][2])
                break;
            g_3[1][1][4] = (safe_mod_func_int16_t_s_s((((safe_add_func_int16_t_s_s((((l_93 && l_103) == l_23) | g_85[3][2]), g_5)) || l_103) & 0x483EC63FL), g_14));
            l_105 = (safe_unary_minus_func_int32_t_s((l_103 >= 0x0ACD80C3L)));
        }
        return l_2[0];
    }
    else
    { /* block id: 64 */
        g_3[2][3][6] = (!(246UL > g_107));
    }
    return g_85[8][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes:
 */
static int32_t  func_8(int32_t  p_9, int8_t  p_10, int32_t  p_11, int64_t  p_12)
{ /* block id: 6 */
    return g_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_85
 * writes:
 */
static uint8_t  func_43(int64_t  p_44, uint16_t  p_45)
{ /* block id: 45 */
    uint32_t l_86 = 1UL;
    int32_t l_87 = 1L;
    int32_t l_92 = 0x1D65C57BL;
    l_87 = l_86;
    l_87 = l_87;
    l_92 |= (((((safe_rshift_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_u((((p_45 , p_45) & 1UL) && l_87), l_87)) , l_87), 3)) , g_85[5][2]) && 0UL) && 0xE4L) ^ p_44);
    return p_45;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_14 g_3 g_85
 * writes: g_5 g_3 g_85
 */
static int8_t  func_46(const int16_t  p_47, int32_t  p_48, int64_t  p_49, uint32_t  p_50)
{ /* block id: 22 */
    int16_t l_58 = 0x9F7CL;
    int32_t l_60 = 0x04AAC6DBL;
    int32_t l_61 = 2L;
    if (p_48)
    { /* block id: 23 */
        uint64_t l_53 = 0xCEC79C0CF39239E7LL;
        int32_t l_57[7] = {8L,8L,(-1L),8L,8L,(-1L),8L};
        int32_t l_59 = 9L;
        uint8_t l_62 = 9UL;
        int i;
        for (p_50 = 15; (p_50 >= 55); p_50 = safe_add_func_int64_t_s_s(p_50, 2))
        { /* block id: 26 */
            return l_53;
        }
        for (g_5 = 0; (g_5 >= 11); g_5 = safe_add_func_int16_t_s_s(g_5, 9))
        { /* block id: 31 */
            uint64_t l_56[10] = {7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL};
            int i;
            g_3[4][0][6] = (func_8(l_56[6], g_5, g_5, p_47) && 0UL);
            g_3[6][1][8] = l_56[6];
        }
        l_62--;
    }
    else
    { /* block id: 36 */
        int32_t l_80[1];
        int i;
        for (i = 0; i < 1; i++)
            l_80[i] = 0x7F434AC2L;
        l_80[0] = func_65((safe_mod_func_uint8_t_u_u((((safe_add_func_int8_t_s_s((safe_mod_func_uint64_t_u_u((safe_add_func_int32_t_s_s((safe_div_func_int32_t_s_s(5L, 0x12FDF6FDL)), 0x4D21CDEBL)), p_49)), g_14)) ^ p_47) | l_80[0]), p_50)), g_14, g_5, g_3[1][1][4]);
    }
    g_85[6][2] ^= ((g_3[1][1][8] < 0UL) <= 0x183DL);
    return l_58;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int32_t  func_65(const int32_t  p_66, uint16_t  p_67, int64_t  p_68, uint16_t  p_69)
{ /* block id: 37 */
    uint8_t l_81 = 255UL;
    int32_t l_84[4] = {0xC76D5E06L,0xC76D5E06L,0xC76D5E06L,0xC76D5E06L};
    int i;
    l_81++;
    l_84[0] = (l_81 , l_81);
    return p_66;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_3[i][j][k], "g_3[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_85[i][j], "g_85[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_107, "g_107", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 32
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 44
   depth: 2, occurrence: 11
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 97
XXX times a non-volatile is write: 29
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 99.2

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 43
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 19
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 22.7
XXX percentage an existing variable is used: 77.3
********************* end of statistics **********************/

