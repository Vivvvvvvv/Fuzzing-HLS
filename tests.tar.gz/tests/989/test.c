/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15424294065168953524
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xEA5D6C05L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = (-3L);
static volatile uint16_t g_6[2] = {0x74DDL,0x74DDL};
static uint32_t g_87 = 7UL;
static int16_t g_95 = 0L;
static const int32_t g_96 = 0xA517386FL;
static volatile int16_t g_111 = 0x971DL;/* VOLATILE GLOBAL g_111 */
static volatile uint32_t g_112 = 0x18A5C642L;/* VOLATILE GLOBAL g_112 */
static volatile int64_t g_120 = 0xA016C9CC5FAE8CD7LL;/* VOLATILE GLOBAL g_120 */
static int32_t g_121 = 0x1D5E08CEL;
static volatile int16_t g_122 = 0x1657L;/* VOLATILE GLOBAL g_122 */
static uint16_t g_123 = 65531UL;
static int32_t g_207[4][2] = {{(-1L),(-2L)},{(-1L),(-1L)},{(-2L),(-1L)},{(-1L),(-2L)}};
static volatile uint64_t g_210 = 18446744073709551613UL;/* VOLATILE GLOBAL g_210 */
static volatile uint16_t g_213 = 0UL;/* VOLATILE GLOBAL g_213 */
static int64_t g_219[2][8][5] = {{{2L,0x0C7B68BE60ADCB03LL,1L,0x91E2AD39FB383223LL,0x91E2AD39FB383223LL},{0x0C7B68BE60ADCB03LL,2L,0x0C7B68BE60ADCB03LL,1L,0x91E2AD39FB383223LL},{5L,(-5L),0x91E2AD39FB383223LL,(-5L),5L},{0x0C7B68BE60ADCB03LL,(-5L),2L,5L,2L},{2L,2L,0x91E2AD39FB383223LL,5L,(-1L)},{(-5L),0x0C7B68BE60ADCB03LL,0x0C7B68BE60ADCB03LL,(-5L),2L},{(-5L),5L,1L,1L,5L},{2L,5L,0x91E2AD39FB383223LL,2L,2L}},{{5L,(-1L),5L,0x91E2AD39FB383223LL,2L},{1L,0x0C7B68BE60ADCB03LL,2L,0x0C7B68BE60ADCB03LL,1L},{5L,0x0C7B68BE60ADCB03LL,(-1L),1L,(-1L)},{(-1L),(-1L),2L,1L,(-5L)},{0x0C7B68BE60ADCB03LL,5L,5L,0x0C7B68BE60ADCB03LL,(-1L)},{0x0C7B68BE60ADCB03LL,1L,0x91E2AD39FB383223LL,0x91E2AD39FB383223LL,1L},{(-1L),5L,0x91E2AD39FB383223LL,2L,2L},{5L,(-1L),5L,0x91E2AD39FB383223LL,2L}}};
static uint8_t g_221 = 0x5BL;
static uint16_t g_224 = 0xA6DBL;
static volatile int32_t g_235 = 0xBFF38EDEL;/* VOLATILE GLOBAL g_235 */
static volatile int64_t g_238 = 0x47D80A4BD07CE890LL;/* VOLATILE GLOBAL g_238 */
static volatile uint32_t g_239 = 0xE0F7AC18L;/* VOLATILE GLOBAL g_239 */
static volatile int16_t g_248 = 0xEEEBL;/* VOLATILE GLOBAL g_248 */
static int32_t g_249 = 6L;
static volatile uint64_t g_255 = 4UL;/* VOLATILE GLOBAL g_255 */
static volatile uint8_t g_295[10][7] = {{0x96L,250UL,1UL,250UL,0x96L,1UL,1UL},{0x5BL,0x8CL,255UL,0x8CL,0x5BL,1UL,1UL},{0x96L,250UL,1UL,250UL,0x96L,1UL,1UL},{0x5BL,0x8CL,255UL,0x8CL,0x5BL,1UL,1UL},{0x96L,250UL,1UL,250UL,0x96L,1UL,1UL},{0x5BL,0x8CL,255UL,0x8CL,0x5BL,1UL,1UL},{0x96L,250UL,1UL,250UL,0x96L,1UL,1UL},{0x5BL,0x8CL,255UL,0x8CL,0x5BL,1UL,1UL},{0x96L,250UL,1UL,250UL,0x96L,1UL,1UL},{0x5BL,0x8CL,255UL,0x8CL,0x5BL,1UL,1UL}};
static volatile uint16_t g_299[1] = {65535UL};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static const int32_t  func_9(int16_t  p_10, uint32_t  p_11, const uint64_t  p_12);
static int8_t  func_18(uint64_t  p_19, const uint32_t  p_20, uint16_t  p_21);
static uint64_t  func_22(uint64_t  p_23, const int32_t  p_24, const uint64_t  p_25, int8_t  p_26);
static uint64_t  func_42(uint32_t  p_43, int8_t  p_44, int8_t  p_45, uint8_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_2 g_87 g_95 g_96 g_112 g_123 g_121 g_111 g_120 g_122 g_210 g_213 g_207 g_221 g_224 g_239 g_255 g_219 g_238 g_235 g_295 g_249 g_299
 * writes: g_3 g_6 g_2 g_112 g_123 g_87 g_210 g_213 g_221 g_224 g_239 g_121 g_255 g_249 g_235 g_295 g_299 g_95
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_268 = 0x9A8C75DFL;
    int32_t l_293[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
    const int16_t l_313 = (-5L);
    int64_t l_325 = (-9L);
    int i;
    for (g_3 = 0; (g_3 > 29); g_3 = safe_add_func_uint32_t_u_u(g_3, 6))
    { /* block id: 3 */
        --g_6[0];
    }
    if (g_2)
    { /* block id: 6 */
        const uint64_t l_13 = 0x8E17B844A754320ELL;
        g_249 = func_9((0x0EF3L <= l_13), l_13, g_3);
    }
    else
    { /* block id: 187 */
        int16_t l_272[9][8] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
        uint16_t l_273 = 0x6B00L;
        int32_t l_291 = (-5L);
        int i, j;
        for (g_221 = 0; (g_221 <= 1); g_221 += 1)
        { /* block id: 190 */
            int32_t l_267 = 0xADA9CF79L;
            int i;
            g_249 = (4UL || 254UL);
            l_268 ^= ((g_6[g_221] > g_3) ^ l_267);
        }
        if ((safe_rshift_func_uint8_t_u_s(((((~l_272[5][7]) >= 0xCEL) >= l_273) && g_239), g_219[0][0][4])))
        { /* block id: 194 */
            return g_239;
        }
        else
        { /* block id: 196 */
            g_249 = (((safe_sub_func_uint32_t_u_u((safe_mod_func_int64_t_s_s(l_273, 1UL)), l_272[5][2])) ^ g_238) != 1L);
        }
        if (((l_272[5][7] ^ 0x3AL) >= 0xA8L))
        { /* block id: 199 */
            int32_t l_290 = 1L;
            l_291 = ((safe_mod_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((safe_div_func_uint64_t_u_u((safe_lshift_func_int16_t_s_s((safe_sub_func_uint64_t_u_u(((safe_lshift_func_uint8_t_u_u(l_268, 5)) > 0x97L), l_273)), l_268)), g_235)), g_221)), g_219[0][0][4])) == l_290);
        }
        else
        { /* block id: 201 */
            const int8_t l_292 = (-1L);
            int32_t l_294[10][9][2] = {{{0x7B5F1760L,0x3B4F77BAL},{0x7B5F1760L,(-9L)},{0x67C3347CL,0xA8A3FE75L},{(-9L),0x06A69714L},{3L,(-5L)},{0x09877FA4L,0x979C1DC0L},{0x979C1DC0L,(-1L)},{0x3B4F77BAL,0x422F2D61L},{2L,0x494EE0FEL}},{{(-5L),3L},{0xAD1B8BF9L,0xD6C18F84L},{0x32FE9E5AL,0x3267F2E3L},{(-5L),0xB12AC074L},{(-2L),2L},{0xD3B134FBL,0xAD1B8BF9L},{0x07937118L,(-2L)},{0x70F0F86BL,0x67C3347CL},{(-7L),(-5L)}},{{(-1L),0x3924B468L},{0xA8A3FE75L,0x3924B468L},{(-1L),(-5L)},{(-7L),0x67C3347CL},{0x70F0F86BL,(-2L)},{0x07937118L,0xAD1B8BF9L},{0xD3B134FBL,2L},{(-2L),0xB12AC074L},{(-5L),0x3267F2E3L}},{{0x32FE9E5AL,0xD6C18F84L},{0xAD1B8BF9L,3L},{(-5L),0x494EE0FEL},{2L,0x422F2D61L},{0x3B4F77BAL,(-1L)},{0x979C1DC0L,0x979C1DC0L},{0x09877FA4L,(-5L)},{3L,0x06A69714L},{(-9L),0xA8A3FE75L}},{{0x67C3347CL,(-9L)},{0x7B5F1760L,0x3B4F77BAL},{0x7B5F1760L,(-9L)},{0x67C3347CL,0xA8A3FE75L},{(-9L),0x06A69714L},{3L,(-5L)},{0x09877FA4L,0x979C1DC0L},{0x979C1DC0L,(-1L)},{0x3B4F77BAL,0x422F2D61L}},{{2L,0x494EE0FEL},{(-5L),3L},{0xAD1B8BF9L,0xD6C18F84L},{0x32FE9E5AL,0x3267F2E3L},{(-5L),0xB12AC074L},{(-2L),2L},{0xD3B134FBL,0xAD1B8BF9L},{0x07937118L,(-2L)},{0x70F0F86BL,0x67C3347CL}},{{(-7L),(-5L)},{(-1L),0x3924B468L},{0xA8A3FE75L,0x3924B468L},{(-1L),(-5L)},{(-7L),0x67C3347CL},{0x70F0F86BL,(-2L)},{0x07937118L,0xAD1B8BF9L},{0xD3B134FBL,2L},{(-2L),0xB12AC074L}},{{(-5L),0x3267F2E3L},{0x32FE9E5AL,0xD6C18F84L},{0xAD1B8BF9L,3L},{(-5L),0x494EE0FEL},{2L,0x422F2D61L},{0x3B4F77BAL,(-1L)},{0x979C1DC0L,0x979C1DC0L},{0x09877FA4L,(-5L)},{3L,0x06A69714L}},{{(-9L),0xA8A3FE75L},{0x67C3347CL,(-9L)},{0x7B5F1760L,0x3B4F77BAL},{0x7B5F1760L,(-9L)},{0x67C3347CL,0xA8A3FE75L},{(-9L),0x06A69714L},{3L,(-5L)},{0x09877FA4L,0x979C1DC0L},{0x979C1DC0L,(-1L)}},{{0x3B4F77BAL,0x422F2D61L},{2L,0x494EE0FEL},{(-5L),3L},{0xAD1B8BF9L,0xD6C18F84L},{0x32FE9E5AL,0x3267F2E3L},{(-5L),0xB12AC074L},{(-2L),2L},{0xD3B134FBL,0xAD1B8BF9L},{0x07937118L,(-2L)}}};
            int8_t l_298 = (-1L);
            int i, j, k;
            g_235 = l_292;
            ++g_295[3][2];
            g_249 |= 0x42F11C63L;
            g_299[0]--;
        }
        for (l_273 = 0; (l_273 <= 59); l_273 = safe_add_func_int16_t_s_s(l_273, 3))
        { /* block id: 209 */
            uint32_t l_306 = 18446744073709551615UL;
            g_2 = ((safe_rshift_func_int8_t_s_u((l_306 , g_111), g_224)) == g_219[0][6][1]);
            g_235 = (9L | l_291);
            g_3 &= (safe_add_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s(((((safe_mod_func_uint16_t_u_u(((l_291 > g_295[3][2]) < 0x0FL), l_313)) & g_219[0][0][4]) , l_293[0]) , l_268), 13)), g_219[0][7][3]));
        }
    }
    for (g_95 = 6; (g_95 >= 0); g_95 -= 1)
    { /* block id: 217 */
        int8_t l_314 = 0xEFL;
        uint16_t l_326 = 0UL;
        int32_t l_327 = 0xF3A3253BL;
        if (g_239)
            break;
        if (l_314)
            continue;
        g_235 = (3UL != l_293[8]);
        for (l_314 = 0; (l_314 <= 6); l_314 += 1)
        { /* block id: 223 */
            int32_t l_328[5][2] = {{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}};
            uint8_t l_329[1];
            int i, j;
            for (i = 0; i < 1; i++)
                l_329[i] = 250UL;
            l_327 = (safe_add_func_uint64_t_u_u((((((safe_div_func_uint8_t_u_u((((((safe_mod_func_int32_t_s_s(((safe_mul_func_uint8_t_u_u((((safe_lshift_func_uint8_t_u_s((g_295[g_95][l_314] > 0x84L), g_249)) , 0x37CE5ED3L) > g_221), l_325)) & l_314), l_314)) , l_326) & g_123) , g_224) , 255UL), g_219[0][0][4])) , l_314) || g_2) >= l_314) <= g_87), l_326));
            --l_329[0];
            if (l_313)
                break;
            l_328[1][0] = (l_328[0][0] >= g_2);
        }
    }
    return g_219[0][0][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_87 g_95 g_96 g_112 g_123 g_121 g_111 g_120 g_2 g_122 g_210 g_213 g_207 g_221 g_224 g_239 g_255
 * writes: g_3 g_2 g_112 g_123 g_87 g_210 g_213 g_221 g_224 g_239 g_121 g_255
 */
static const int32_t  func_9(int16_t  p_10, uint32_t  p_11, const uint64_t  p_12)
{ /* block id: 7 */
    int64_t l_225 = 5L;
    int32_t l_231 = 0x561C6BE3L;
    int32_t l_245 = 1L;
    int16_t l_246 = 0x5A3AL;
    int32_t l_250 = 0x75EE9091L;
    int32_t l_251 = 0x50D92D6BL;
    int32_t l_252 = 1L;
    int32_t l_253 = 6L;
lbl_258:
    if ((safe_add_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(0x3C6FL, 2)), 0x66D210EC3203BD65LL)))
    { /* block id: 8 */
        uint64_t l_31[4] = {0xDAB551FA4C821046LL,0xDAB551FA4C821046LL,0xDAB551FA4C821046LL,0xDAB551FA4C821046LL};
        int i;
        if (g_3)
        { /* block id: 9 */
            g_224 |= (func_18(func_22((((safe_div_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s((g_6[0] , p_12), p_10)), p_11)) | p_10) , l_31[3]), g_3, g_3, l_31[1]), p_11, g_95) & p_10);
        }
        else
        { /* block id: 146 */
            return l_31[3];
        }
        if (l_225)
        { /* block id: 149 */
            return p_11;
        }
        else
        { /* block id: 151 */
            return l_31[3];
        }
    }
    else
    { /* block id: 154 */
        uint32_t l_230 = 5UL;
        int32_t l_237 = (-1L);
        int32_t l_247 = 0x340F112FL;
        int32_t l_254[9] = {0x7BA80373L,0x7BA80373L,0x7BA80373L,0x7BA80373L,0x7BA80373L,0x7BA80373L,0x7BA80373L,0x7BA80373L,0x7BA80373L};
        int i;
        for (g_123 = 3; (g_123 != 36); ++g_123)
        { /* block id: 157 */
            g_2 = (0xBF7BL || g_87);
            l_231 ^= (((((safe_sub_func_uint64_t_u_u(((((65535UL <= g_123) == l_230) <= l_230) <= g_122), p_12)) > 0x38C1CB93L) && g_122) ^ 1UL) <= p_11);
        }
        for (p_11 = 0; (p_11 >= 39); p_11 = safe_add_func_int16_t_s_s(p_11, 7))
        { /* block id: 163 */
            int8_t l_234 = 0xCBL;
            int32_t l_236[9] = {0x737D9CE7L,0x666E4592L,0x737D9CE7L,0x666E4592L,0x737D9CE7L,0x666E4592L,0x737D9CE7L,0x666E4592L,0x737D9CE7L};
            int i;
            ++g_239;
            if (l_236[3])
                continue;
            if (p_12)
                break;
        }
        for (g_121 = 0; (g_121 == 15); g_121++)
        { /* block id: 170 */
            int32_t l_244[3];
            int i;
            for (i = 0; i < 3; i++)
                l_244[i] = 0x1164B7CAL;
            l_244[0] = 0x6B02DDAEL;
            if (l_237)
                continue;
            return g_123;
        }
        --g_255;
    }
    l_252 &= 0x6F6A9FABL;
    if (g_224)
        goto lbl_258;
    for (g_121 = 23; (g_121 < 9); g_121--)
    { /* block id: 181 */
        uint32_t l_261 = 0x43484084L;
        int32_t l_266 = 0xA5C68B7BL;
        --l_261;
        l_266 = (safe_mul_func_int8_t_s_s(p_11, 0x3EL));
    }
    return l_231;
}


/* ------------------------------------------ */
/* 
 * reads : g_87 g_2 g_3 g_122 g_95 g_96 g_123 g_210 g_213 g_207 g_6 g_221
 * writes: g_87 g_3 g_210 g_213 g_2 g_221
 */
static int8_t  func_18(uint64_t  p_19, const uint32_t  p_20, uint16_t  p_21)
{ /* block id: 113 */
    int64_t l_183 = 0xD4900E7B76DE95A8LL;
    int32_t l_192 = (-1L);
    int32_t l_208 = (-6L);
    int32_t l_209[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int i;
    l_183 = ((safe_add_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((4294967288UL == 4294967295UL), p_21)), 0x246DL)) < p_20);
    for (g_87 = 0; (g_87 >= 33); g_87 = safe_add_func_uint8_t_u_u(g_87, 1))
    { /* block id: 117 */
        int16_t l_187 = 0xAA2BL;
        int32_t l_202[8][7] = {{1L,(-1L),(-9L),0x15C78119L,0xCB3DCC72L,0x15C78119L,(-9L)},{0x9CDD84AAL,0x9CDD84AAL,0x6CCB9D5BL,0x24197F75L,(-1L),0x05891831L,1L},{1L,0x15C78119L,0x6CCB9D5BL,0x6CCB9D5BL,0x15C78119L,1L,0xCB3DCC72L},{(-1L),0x6CCB9D5BL,(-9L),0xCB3DCC72L,(-1L),(-1L),0xCB3DCC72L},{0x24197F75L,0xA33BDD32L,0x24197F75L,0x05891831L,0xCB3DCC72L,(-1L),1L},{(-9L),0x6CCB9D5BL,(-1L),0x05891831L,(-1L),0x6CCB9D5BL,(-9L)},{0x6CCB9D5BL,0x15C78119L,1L,0xCB3DCC72L,0x9CDD84AAL,(-1L),0x9CDD84AAL},{0x6CCB9D5BL,0x9CDD84AAL,0x9CDD84AAL,0x6CCB9D5BL,0x24197F75L,(-1L),0x05891831L}};
        int i, j;
        l_187 |= (~l_183);
        if ((p_21 > l_183))
        { /* block id: 119 */
            uint32_t l_193[9] = {4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL,4294967289UL};
            int i;
            g_3 ^= (safe_rshift_func_int16_t_s_u(g_2, l_187));
            if (p_20)
                continue;
            l_193[4] ^= (safe_add_func_uint16_t_u_u((((((p_21 || p_19) | g_122) || 0x64883662L) & l_192) == g_87), g_95));
        }
        else
        { /* block id: 123 */
            int32_t l_201[3][6];
            int32_t l_203 = 0xD3DD64F9L;
            int32_t l_204 = 0x04C9F34FL;
            int32_t l_205 = 0xE3425DD3L;
            int32_t l_206[3][1][3] = {{{0x2B5C891FL,0L,0x2B5C891FL}},{{0x53A83723L,0x53A83723L,0x53A83723L}},{{0x2B5C891FL,0L,0x2B5C891FL}}};
            int i, j, k;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 6; j++)
                    l_201[i][j] = 0x04C19E56L;
            }
            g_3 &= 1L;
            g_3 ^= ((safe_mod_func_uint8_t_u_u((+((((safe_sub_func_uint32_t_u_u((((safe_mod_func_uint32_t_u_u(((p_19 <= l_187) , l_201[1][0]), g_96)) , 18446744073709551613UL) , p_21), l_187)) || 4294967290UL) || p_21) | 0x06L)), g_123)) || p_19);
            --g_210;
            return p_19;
        }
        for (l_183 = 1; (l_183 >= 0); l_183 -= 1)
        { /* block id: 131 */
            int32_t l_216 = 0L;
            int i, j;
            g_213++;
            l_216 = (0x4191B569L & g_207[(l_183 + 2)][l_183]);
        }
        for (p_19 = 17; (p_19 > 55); p_19++)
        { /* block id: 137 */
            int8_t l_220 = 0xFEL;
            l_209[4] ^= (-1L);
            l_202[1][6] = 0x42F1CC1EL;
            g_2 = (0UL <= g_6[0]);
            g_221++;
        }
    }
    return l_183;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_87 g_95 g_96 g_112 g_123 g_121 g_111 g_120 g_2 g_122
 * writes: g_3 g_2 g_112 g_123 g_87
 */
static uint64_t  func_22(uint64_t  p_23, const int32_t  p_24, const uint64_t  p_25, int8_t  p_26)
{ /* block id: 10 */
    int16_t l_47 = 0L;
    uint32_t l_48[9] = {18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL,18446744073709551610UL};
    int32_t l_49[6][1][8] = {{{0x68F57F54L,(-6L),0x9150040BL,(-1L),(-6L),(-1L),0x9150040BL,(-6L)}},{{1L,0x9150040BL,0x68F57F54L,1L,(-1L),(-1L),1L,0x68F57F54L}},{{(-6L),(-6L),0xB0BADCABL,1L,1L,0xB0BADCABL,1L,1L}},{{0x68F57F54L,1L,0x68F57F54L,(-1L),1L,0x9150040BL,0x9150040BL,1L}},{{1L,0x9150040BL,0x9150040BL,1L,(-1L),0x68F57F54L,1L,0x68F57F54L}},{{1L,1L,0xB0BADCABL,1L,1L,0xB0BADCABL,(-6L),(-6L)}}};
    int32_t l_50 = (-4L);
    uint32_t l_133 = 0UL;
    int8_t l_155 = (-10L);
    uint16_t l_168 = 65532UL;
    int i, j, k;
lbl_173:
    if ((((safe_div_func_int8_t_s_s((safe_div_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_s((safe_div_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((func_42(l_47, l_48[0], l_49[0][0][1], l_50) | g_87), g_87)), p_26)), p_25)) & l_48[0]), l_50)), g_87)) | 0xE450DE0BL) , p_25))
    { /* block id: 50 */
        int8_t l_97 = 0x3AL;
        int32_t l_98 = 0xCBDA1257L;
        for (p_26 = 0; (p_26 <= (-9)); p_26 = safe_sub_func_uint64_t_u_u(p_26, 5))
        { /* block id: 53 */
            g_2 = (safe_unary_minus_func_int8_t_s((((((safe_add_func_int16_t_s_s(((safe_sub_func_uint32_t_u_u((g_3 == (-9L)), g_6[0])) , g_95), 0xC8CCL)) <= p_25) , 0x75L) , 0x18FE3B64D7EEACC2LL) && 0xC7A95E7740573921LL)));
            if (g_96)
                continue;
            l_98 = l_97;
            if (g_3)
                continue;
        }
        for (l_50 = 21; (l_50 >= (-1)); l_50--)
        { /* block id: 61 */
            uint16_t l_103 = 0xBAD6L;
            int32_t l_110[1][1];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                    l_110[i][j] = 0xD0160B5CL;
            }
            l_103 &= ((((safe_lshift_func_uint16_t_u_u(0xD270L, p_24)) < 0L) && (-1L)) != p_25);
            g_3 ^= (safe_sub_func_uint16_t_u_u((safe_div_func_int8_t_s_s(((safe_sub_func_int8_t_s_s((((((p_23 <= 0x295DFDCAL) > 0UL) || p_23) , 0xEAL) < g_6[1]), p_24)) && l_98), l_98)), 65533UL));
            ++g_112;
        }
        for (l_97 = 29; (l_97 == (-18)); l_97--)
        { /* block id: 68 */
            uint8_t l_117 = 255UL;
            int32_t l_118 = 0x479DA46AL;
            int32_t l_119 = 0L;
            l_118 = l_117;
            g_123++;
            l_119 = (safe_sub_func_uint16_t_u_u((safe_unary_minus_func_int32_t_s(((safe_rshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u(l_117, 1UL)), 8)) && l_133))), 0x182CL));
            g_2 = ((safe_rshift_func_uint16_t_u_s(l_97, g_121)) < (-1L));
        }
    }
    else
    { /* block id: 74 */
        uint64_t l_148 = 0xB29079C9DB8D8D30LL;
        g_3 = (safe_add_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((safe_lshift_func_int8_t_s_s((safe_add_func_uint8_t_u_u((((safe_sub_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(0xDDL, 0)), p_25)) , l_148) , l_50), l_49[0][0][1])), 3)), g_96)), g_111));
    }
    for (p_26 = 0; (p_26 >= 0); p_26 -= 1)
    { /* block id: 79 */
        uint32_t l_153 = 0UL;
        int32_t l_154 = (-8L);
        g_2 = ((((safe_add_func_int8_t_s_s((((safe_div_func_int64_t_s_s(p_26, p_26)) < g_120) | g_121), p_25)) && 0x95DD02E5D8015DFALL) || l_153) >= 0xF139L);
        for (l_133 = 0; (l_133 <= 0); l_133 += 1)
        { /* block id: 83 */
            g_2 ^= 3L;
        }
        l_154 = 0L;
        if ((((255UL == p_25) , p_26) > l_155))
        { /* block id: 87 */
            uint16_t l_156 = 0x7ECEL;
            l_156--;
            l_154 = (g_95 , p_26);
            l_50 = (((((safe_div_func_int8_t_s_s((g_122 , 0x6FL), 2UL)) > 1UL) , 6UL) , 0UL) ^ g_123);
            g_3 &= (safe_div_func_int64_t_s_s((((safe_mod_func_uint16_t_u_u(g_123, l_47)) < l_153) | p_26), g_122));
        }
        else
        { /* block id: 92 */
            l_154 = (((safe_unary_minus_func_int64_t_s(g_123)) ^ 0x1652FD55L) , g_6[0]);
            l_154 = ((safe_mod_func_int8_t_s_s(0L, 0x70L)) > l_168);
        }
        for (g_87 = 0; (g_87 <= 0); g_87 += 1)
        { /* block id: 98 */
            int32_t l_172 = 0x64B399E4L;
            l_172 ^= (+((safe_mul_func_int8_t_s_s(((p_25 && 0x16BB71A4F7F7094BLL) ^ 0xEAL), p_23)) < l_153));
            if (p_25)
                goto lbl_173;
        }
    }
    for (l_168 = 0; (l_168 == 45); ++l_168)
    { /* block id: 105 */
        uint64_t l_176 = 0UL;
        if (g_96)
        { /* block id: 106 */
            ++l_176;
        }
        else
        { /* block id: 108 */
            return p_25;
        }
    }
    return g_6[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_6
 * writes: g_3 g_2
 */
static uint64_t  func_42(uint32_t  p_43, int8_t  p_44, int8_t  p_45, uint8_t  p_46)
{ /* block id: 11 */
    int16_t l_57 = 0x497CL;
    int32_t l_63 = (-5L);
    for (p_44 = 0; (p_44 >= (-22)); --p_44)
    { /* block id: 14 */
        uint32_t l_58 = 0xDBB9A2F7L;
        for (p_46 = (-26); (p_46 >= 22); p_46 = safe_add_func_int8_t_s_s(p_46, 7))
        { /* block id: 17 */
            l_57 = (safe_div_func_uint32_t_u_u(0xF40BF68DL, p_43));
            g_3 = (0x7EEDL < l_58);
            l_63 ^= (safe_lshift_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u(l_58, l_58)), p_43));
        }
        return p_46;
    }
    for (l_57 = 0; (l_57 == (-16)); l_57--)
    { /* block id: 26 */
        int32_t l_75 = 0L;
        for (p_46 = 0; (p_46 >= 46); p_46++)
        { /* block id: 29 */
            int32_t l_76 = 0x9BECC425L;
            l_63 = (safe_mod_func_uint64_t_u_u((((safe_mul_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(((((safe_unary_minus_func_int16_t_s(((0L == 8L) , 0L))) , l_63) < l_75) & l_76), g_3)), p_43)) & 1UL) & g_3), 18446744073709551615UL));
            l_63 = ((g_6[0] > p_44) != p_46);
            return g_6[0];
        }
        l_63 &= 7L;
        for (p_46 = 0; (p_46 <= 22); ++p_46)
        { /* block id: 37 */
            l_63 &= g_6[0];
        }
        for (l_63 = 0; (l_63 <= 1); l_63 += 1)
        { /* block id: 42 */
            int i;
            g_3 = (safe_lshift_func_uint16_t_u_s(((safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_u(g_6[l_63], p_44)), p_45)) , 0xCE5FL), g_3));
            if (g_6[l_63])
                break;
            g_2 = g_3;
        }
    }
    l_63 = (safe_mod_func_uint32_t_u_u(g_6[0], l_57));
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_207[i][j], "g_207[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_219[i][j][k], "g_219[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_221, "g_221", print_hash_value);
    transparent_crc(g_224, "g_224", print_hash_value);
    transparent_crc(g_235, "g_235", print_hash_value);
    transparent_crc(g_238, "g_238", print_hash_value);
    transparent_crc(g_239, "g_239", print_hash_value);
    transparent_crc(g_248, "g_248", print_hash_value);
    transparent_crc(g_249, "g_249", print_hash_value);
    transparent_crc(g_255, "g_255", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_295[i][j], "g_295[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_299[i], "g_299[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 100
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 129
   depth: 2, occurrence: 39
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
   depth: 5, occurrence: 9
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 4
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 2
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 200
XXX times a non-volatile is write: 76
XXX times a volatile is read: 32
XXX    times read thru a pointer: 0
XXX times a volatile is write: 19
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 152
XXX percentage of non-volatile access: 84.4

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 131
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 38
   depth: 2, occurrence: 73

XXX percentage a fresh-made variable is used: 28.3
XXX percentage an existing variable is used: 71.7
********************* end of statistics **********************/

