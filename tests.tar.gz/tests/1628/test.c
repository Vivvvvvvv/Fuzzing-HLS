/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10601133130140660556
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint16_t g_5 = 65535UL;
static volatile int64_t g_10 = 0xD374006310FECAFELL;/* VOLATILE GLOBAL g_10 */
static volatile int32_t g_20 = 0xF9E3D3B0L;/* VOLATILE GLOBAL g_20 */
static int8_t g_22[7] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
static volatile int8_t g_24 = 0xA2L;/* VOLATILE GLOBAL g_24 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint16_t  func_2(const int32_t  p_3, uint32_t  p_4);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_10 g_20 g_24
 * writes: g_20 g_22 g_24
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_6[4] = {0UL,0UL,0UL,0UL};
    uint8_t l_23 = 0x9DL;
    uint32_t l_25 = 4294967295UL;
    int32_t l_26[1];
    int i;
    for (i = 0; i < 1; i++)
        l_26[i] = 4L;
    l_23 = (func_2(g_5, l_6[0]) < g_5);
    g_24 = g_10;
    l_26[0] = ((g_24 , l_25) , 0xD840DFE9L);
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_5 g_20
 * writes: g_20 g_22
 */
static uint16_t  func_2(const int32_t  p_3, uint32_t  p_4)
{ /* block id: 1 */
    const uint16_t l_7 = 0x1F07L;
    int32_t l_11 = 0x3E0566A9L;
    int32_t l_12 = 1L;
    if ((l_7 < l_7))
    { /* block id: 2 */
        uint32_t l_13 = 6UL;
        for (p_4 = 9; (p_4 >= 40); p_4++)
        { /* block id: 5 */
            return l_7;
        }
        --l_13;
        l_11 = ((g_10 > (-2L)) <= g_5);
    }
    else
    { /* block id: 10 */
        int32_t l_16 = 0xE3B6F9B6L;
lbl_19:
        l_16 &= g_5;
        for (l_16 = 8; (l_16 < (-11)); l_16 = safe_sub_func_int64_t_s_s(l_16, 4))
        { /* block id: 14 */
            int64_t l_21 = 1L;
            if (l_16)
                goto lbl_19;
            g_20 &= 0x863718BDL;
            if (g_5)
                break;
            g_22[5] = ((-1L) ^ l_21);
        }
    }
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_24, "g_24", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 15
XXX times a non-volatile is write: 8
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 11
XXX percentage of non-volatile access: 82.1

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 5
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 55.6
XXX percentage an existing variable is used: 44.4
********************* end of statistics **********************/

