/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15725663125010627252
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 2L;
static volatile int32_t g_4 = 3L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0x12F8BA79L;/* VOLATILE GLOBAL g_5 */
static int32_t g_6 = 0x68F57F54L;
static uint32_t g_32 = 0xCC853D3CL;
static volatile uint8_t g_46 = 0x1FL;/* VOLATILE GLOBAL g_46 */
static volatile int64_t g_59 = (-4L);/* VOLATILE GLOBAL g_59 */
static uint8_t g_60[4] = {0x14L,0x14L,0x14L,0x14L};
static uint32_t g_64[10] = {0xE5C5CB2EL,0xE5C5CB2EL,0UL,0x7295DFDCL,0UL,0xE5C5CB2EL,0xE5C5CB2EL,0UL,0x7295DFDCL,0UL};
static uint8_t g_95[1][10] = {{0xF7L,0xF7L,0xF7L,0xF7L,0xF7L,0xF7L,0xF7L,0xF7L,0xF7L,0xF7L}};
static volatile uint64_t g_100 = 0x522CE914191B5690LL;/* VOLATILE GLOBAL g_100 */
static volatile uint32_t g_128 = 1UL;/* VOLATILE GLOBAL g_128 */
static volatile int64_t g_137 = 0x4B8DB84F2A5F7610LL;/* VOLATILE GLOBAL g_137 */
static volatile int32_t g_154 = 0xB73E6FF0L;/* VOLATILE GLOBAL g_154 */
static int32_t g_155 = (-1L);


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint64_t  func_7(uint32_t  p_8, int32_t  p_9, uint32_t  p_10);
static const int32_t  func_15(int32_t  p_16, uint32_t  p_17, int32_t  p_18, int16_t  p_19);
static int32_t  func_23(int16_t  p_24, int32_t  p_25);
static int32_t  func_72(uint64_t  p_73, int8_t  p_74, uint32_t  p_75, uint32_t  p_76, const uint64_t  p_77);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_4 g_32 g_5 g_46 g_60 g_64 g_59 g_95 g_100 g_128 g_137
 * writes: g_3 g_6 g_5 g_32 g_4 g_46 g_60 g_64 g_95 g_100 g_128
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[10][7][3] = {{{0xAED1D25BL,0L,1L},{1L,0x248C66F5L,9L},{1L,0x63AB1943L,1L},{0L,1L,0xD7494DFDL},{0xE6F7FBF2L,1L,3L},{1L,1L,0x98AAC1E0L},{0x7C914A3AL,0x67120DD9L,0xC8D535DDL}},{{1L,0xD7494DFDL,0xBA6B42BEL},{0xA1E1C5A3L,0xC8D535DDL,(-5L)},{0x6FE23A26L,5L,0xC5051DD2L},{0x3203BD65L,0xAED1D25BL,(-1L)},{0xBA6B42BEL,5L,(-1L)},{2L,0xC8D535DDL,(-5L)},{0x8AAF0A9BL,0xD7494DFDL,(-1L)}},{{(-5L),0x7C914A3AL,0xAED6B657L},{(-1L),0L,(-1L)},{(-7L),0L,(-5L)},{0x50E35260L,7L,(-1L)},{0x7D7C1188L,0x97E7C14AL,(-1L)},{(-1L),0x56810853L,0xC5051DD2L},{0x7D7C1188L,1L,(-5L)}},{{0x50E35260L,1L,0xBA6B42BEL},{(-7L),3L,0x7D7C1188L},{(-1L),0L,(-3L)},{(-5L),3L,(-4L)},{0x8AAF0A9BL,1L,0xDE0B4074L},{2L,1L,0x3203BD65L},{0xBA6B42BEL,0x56810853L,0xFC5674FAL}},{{0x3203BD65L,0x97E7C14AL,0x3203BD65L},{0x6FE23A26L,7L,0xDE0B4074L},{0xA1E1C5A3L,0L,(-4L)},{0xC5051DD2L,0L,(-3L)},{0x9C4C8D3CL,0x7C914A3AL,0x7D7C1188L},{0xC5051DD2L,0xD7494DFDL,0xBA6B42BEL},{0xA1E1C5A3L,0xC8D535DDL,(-5L)}},{{0x6FE23A26L,5L,0xC5051DD2L},{0x3203BD65L,0xAED1D25BL,(-1L)},{0xBA6B42BEL,5L,(-1L)},{2L,0xC8D535DDL,(-5L)},{0x8AAF0A9BL,0xD7494DFDL,(-1L)},{(-5L),0x7C914A3AL,0xAED6B657L},{(-1L),0L,(-1L)}},{{(-7L),0L,(-5L)},{0x50E35260L,7L,(-1L)},{0x7D7C1188L,0x97E7C14AL,(-1L)},{(-1L),0x56810853L,0xC5051DD2L},{0x7D7C1188L,1L,(-5L)},{0x50E35260L,1L,0xBA6B42BEL},{(-7L),3L,0x7D7C1188L}},{{(-1L),0L,(-3L)},{(-5L),3L,(-4L)},{0x8AAF0A9BL,1L,0xDE0B4074L},{2L,1L,0x3203BD65L},{0xBA6B42BEL,0x56810853L,0xFC5674FAL},{0x3203BD65L,0x97E7C14AL,0x3203BD65L},{0x6FE23A26L,7L,0xDE0B4074L}},{{0xA1E1C5A3L,0L,(-4L)},{0xC5051DD2L,0L,(-3L)},{0x9C4C8D3CL,0x7C914A3AL,0x7D7C1188L},{0xC5051DD2L,0xD7494DFDL,0xBA6B42BEL},{0xA1E1C5A3L,0xC8D535DDL,(-5L)},{0x6FE23A26L,5L,0xC5051DD2L},{0x3203BD65L,0xAED1D25BL,(-1L)}},{{0xBA6B42BEL,5L,(-1L)},{2L,0xC8D535DDL,(-5L)},{0x8AAF0A9BL,0xD7494DFDL,(-1L)},{(-5L),0x7C914A3AL,0xAED6B657L},{(-1L),0L,(-1L)},{(-7L),0L,(-5L)},{0x50E35260L,7L,(-1L)}}};
    int32_t l_69 = 0x5D0160B5L;
    int16_t l_164 = 0L;
    int i, j, k;
    for (g_3 = 2; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        for (g_6 = 2; (g_6 >= 0); g_6 -= 1)
        { /* block id: 6 */
            g_5 = 0x2FBF3F07L;
            return g_4;
        }
        for (g_6 = 2; (g_6 >= 0); g_6 -= 1)
        { /* block id: 12 */
            int32_t l_11 = 0x3B72B46FL;
            l_11 = (func_7((((0xDC8FF05C8A2DB637LL != l_2[7][2][0]) <= 0xF9L) < g_3), l_2[5][1][0], l_11) < 18446744073709551615UL);
            ++g_64[8];
            l_69 ^= ((safe_mul_func_int8_t_s_s(((g_60[3] >= g_59) , g_60[2]), g_3)) & l_2[9][0][2]);
        }
    }
    g_4 |= (safe_mul_func_uint16_t_u_u(0xD276L, l_2[3][0][1]));
    if (((g_4 , g_60[1]) > 0xFEL))
    { /* block id: 56 */
        uint64_t l_82[7][6][6] = {{{18446744073709551613UL,0x672C646EC4B94AD5LL,0UL,0UL,0x862B899241723947LL,4UL},{0x5CD318D08C10FD05LL,18446744073709551615UL,0x16570B7C7C066171LL,7UL,0x9FFA4CC697D3C620LL,0x8D5FDB64883662F3LL},{0xBE86AE0A1952B13BLL,6UL,0xF6FF1804477D5BCDLL,18446744073709551615UL,0x4A185305F7132E54LL,1UL},{1UL,0UL,1UL,0x45791C840D7AA6B0LL,0xBE86AE0A1952B13BLL,18446744073709551615UL},{0x2E3B7FEC2A52D84ELL,0xE8C1B3C7CD66DA80LL,2UL,0xBE86AE0A1952B13BLL,0xAE681B6975085CE8LL,0x0205F7226B515A1FLL},{0x2E8F47D9D0DECC6ELL,1UL,1UL,3UL,1UL,1UL}},{{0xF6FF1804477D5BCDLL,2UL,0x15C65D3447928101LL,18446744073709551613UL,18446744073709551610UL,0x8BC828D9300DF10CLL},{18446744073709551610UL,1UL,0x672C646EC4B94AD5LL,0UL,18446744073709551610UL,0xD85B24B621E9F3CFLL},{1UL,1UL,0x2E294E6100BB5F28LL,0xF1F5868DEE43C49ELL,18446744073709551610UL,0UL},{0x3FE182C0C4DA8BF3LL,2UL,0x2E33F915BDED7856LL,1UL,1UL,0x4A35B98692F7AB6CLL},{18446744073709551615UL,1UL,1UL,18446744073709551615UL,0xAE681B6975085CE8LL,0xA79CFC9B2F6CA1BELL},{18446744073709551609UL,0xE8C1B3C7CD66DA80LL,18446744073709551612UL,1UL,0xBE86AE0A1952B13BLL,0UL}},{{0x066B76CAEA256EE4LL,0UL,2UL,8UL,0x4A185305F7132E54LL,18446744073709551613UL},{18446744073709551611UL,6UL,1UL,0x875C6BA716740609LL,0x9FFA4CC697D3C620LL,0xD6804023D1C57EA6LL},{18446744073709551607UL,18446744073709551615UL,0x066B76CAEA256EE4LL,18446744073709551611UL,0x862B899241723947LL,0xC3B02FF5F5FB1240LL},{0x2E3B7FEC2A52D84ELL,0UL,0UL,0xF6FF1804477D5BCDLL,0x13493370524A1A4ELL,0xCF6FCF68907D73F8LL},{0UL,2UL,18446744073709551607UL,0UL,0x15C65D3447928101LL,1UL},{1UL,1UL,18446744073709551615UL,0x037CFBB67B20451BLL,0xD16BB71A4F7F7094LL,0UL}},{{1UL,18446744073709551613UL,0UL,0x5B3985E7E01DFB5DLL,18446744073709551610UL,18446744073709551610UL},{0UL,8UL,0x5DD30C446B92DD07LL,0x4A185305F7132E54LL,0UL,0UL},{18446744073709551606UL,0UL,0xB088A057ECED5480LL,1UL,0UL,0x70FE6C1E6BC95214LL},{0x15C65D3447928101LL,0x672C646EC4B94AD5LL,18446744073709551607UL,0x9FFA4CC697D3C620LL,0x2751B8D994F87C28LL,18446744073709551615UL},{0x2397AFB7A7CBF150LL,0xB5B2358A988067FCLL,18446744073709551612UL,1UL,0x45791C840D7AA6B0LL,0xAE681B6975085CE8LL},{1UL,2UL,0xF285608B997ADCAFLL,0x8D5FDB64883662F3LL,18446744073709551615UL,18446744073709551610UL}},{{0x862B899241723947LL,6UL,0x7760C71652FD558ALL,0xCF6FCF68907D73F8LL,0xF1F5868DEE43C49ELL,18446744073709551607UL},{0xF285608B997ADCAFLL,1UL,0x5CD318D08C10FD05LL,0x2E33F915BDED7856LL,0x2E33F915BDED7856LL,0x5CD318D08C10FD05LL},{0x2E3B7FEC2A52D84ELL,0x2E3B7FEC2A52D84ELL,1UL,0xB088A057ECED5480LL,0UL,0UL},{0x6D126375140D4900LL,18446744073709551609UL,0UL,7UL,0xC3D7FAD0BDB4F01BLL,1UL},{0x7760C71652FD558ALL,0x6D126375140D4900LL,0UL,0x735CC4819D74962ELL,0x2E3B7FEC2A52D84ELL,0UL},{18446744073709551615UL,0x735CC4819D74962ELL,1UL,0x672C646EC4B94AD5LL,18446744073709551610UL,0x5CD318D08C10FD05LL}},{{0x672C646EC4B94AD5LL,18446744073709551610UL,0x5CD318D08C10FD05LL,0x6459F139C94463E9LL,18446744073709551614UL,18446744073709551607UL},{1UL,1UL,0x7760C71652FD558ALL,1UL,18446744073709551615UL,18446744073709551610UL},{18446744073709551615UL,0x9C88BF8F4ABBE4CDLL,0xF077B29079C9DB8DLL,1UL,18446744073709551606UL,1UL},{0x2BCA0CB05F298898LL,0xDDE4D78B1D698337LL,0xCF6FCF68907D73F8LL,0UL,0x4A35B98692F7AB6CLL,18446744073709551606UL},{0xF6FF1804477D5BCDLL,18446744073709551615UL,18446744073709551615UL,18446744073709551609UL,0UL,0x2397AFB7A7CBF150LL},{18446744073709551610UL,0x6459F139C94463E9LL,0x70FE6C1E6BC95214LL,1UL,1UL,0x066B76CAEA256EE4LL}},{{0UL,0xD6804023D1C57EA6LL,0x862B899241723947LL,0x4A35B98692F7AB6CLL,8UL,0xDFAB55DA1D3BC2F6LL},{18446744073709551615UL,7UL,0xB5B2358A988067FCLL,7UL,0UL,0x16570B7C7C066171LL},{1UL,0x2BCA0CB05F298898LL,8UL,18446744073709551607UL,0x5CD318D08C10FD05LL,0xD16BB71A4F7F7094LL},{0x70FE6C1E6BC95214LL,0xF077B29079C9DB8DLL,0x5CD318D08C10FD05LL,0UL,3UL,0xF285608B997ADCAFLL},{0xBE86AE0A1952B13BLL,1UL,18446744073709551612UL,0xE8C1B3C7CD66DA80LL,18446744073709551609UL,0xF6FF1804477D5BCDLL},{18446744073709551610UL,0UL,0xB088A057ECED5480LL,2UL,0x8BC828D9300DF10CLL,0x5DD30C446B92DD07LL}}};
        int i, j, k;
        l_2[2][3][2] = func_72((((safe_div_func_int32_t_s_s((safe_mod_func_int32_t_s_s(((g_64[2] < l_2[0][1][0]) & g_59), g_64[8])), l_82[1][0][5])) < g_3) & 18446744073709551615UL), g_3, l_2[7][4][1], g_64[8], l_69);
        return g_95[0][0];
    }
    else
    { /* block id: 98 */
        int16_t l_127[7][9] = {{0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L},{1L,0x238CL,1L,1L,0x238CL,1L,1L,0x238CL,1L},{0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L},{1L,0x238CL,1L,1L,0x238CL,1L,1L,0x238CL,1L},{0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L},{1L,0x238CL,1L,1L,0x238CL,1L,1L,0x238CL,1L},{0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L,0x31F8L,0x5402L,0x31F8L}};
        uint8_t l_136 = 251UL;
        int32_t l_142 = (-1L);
        int16_t l_152[5] = {0xBC98L,0xBC98L,0xBC98L,0xBC98L,0xBC98L};
        uint32_t l_163[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
        int i, j;
        ++g_128;
        for (g_3 = 0; (g_3 <= 6); g_3 += 1)
        { /* block id: 102 */
            int32_t l_135 = (-1L);
            g_6 &= (safe_add_func_uint32_t_u_u((((safe_div_func_int8_t_s_s((g_32 > l_2[9][3][2]), l_135)) == l_136) > l_135), g_137));
            l_142 = ((safe_rshift_func_int8_t_s_s((safe_mod_func_int64_t_s_s((((l_135 , 0x6D7AE1D0CBB2B500LL) , l_2[0][3][0]) > 0UL), g_32)), g_4)) , g_64[8]);
        }
        for (l_69 = 0; (l_69 <= 0); l_69 += 1)
        { /* block id: 108 */
            int16_t l_151 = 0xA9FAL;
            int32_t l_153[2];
            uint32_t l_156[9] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
            int i;
            for (i = 0; i < 2; i++)
                l_153[i] = (-1L);
            g_4 = g_60[(l_69 + 1)];
            l_2[4][6][1] ^= (((safe_div_func_uint64_t_u_u((safe_mod_func_int32_t_s_s((safe_rshift_func_uint8_t_u_u(g_5, l_142)), g_64[5])), g_60[(l_69 + 1)])) , l_127[4][6]) >= g_3);
            g_5 = ((safe_add_func_uint64_t_u_u(l_69, 5L)) , l_127[0][5]);
            --l_156[1];
        }
        for (l_136 = (-4); (l_136 <= 15); l_136 = safe_add_func_uint16_t_u_u(l_136, 7))
        { /* block id: 116 */
            l_142 = (g_46 && l_2[2][1][0]);
            l_2[6][6][0] = (safe_mul_func_int16_t_s_s(((((((g_59 , 0xE079L) , l_163[5]) | g_64[5]) < 0L) > l_69) ^ 1UL), l_2[2][6][2]));
        }
    }
    return l_164;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_6 g_3 g_5 g_46 g_4 g_60
 * writes: g_32 g_4 g_46 g_60
 */
static uint64_t  func_7(uint32_t  p_8, int32_t  p_9, uint32_t  p_10)
{ /* block id: 13 */
    uint8_t l_14[5];
    int32_t l_56[4][6] = {{0xD0A3AFD5L,0x517386F7L,0x828E342BL,0x828E342BL,0x517386F7L,0xD0A3AFD5L},{0xD0A3AFD5L,0xACC20013L,(-7L),0x828E342BL,0xACC20013L,0x828E342BL},{0xD0A3AFD5L,(-1L),0xD0A3AFD5L,0x828E342BL,(-1L),(-7L)},{0xD0A3AFD5L,0x517386F7L,0x828E342BL,0x828E342BL,0x517386F7L,0xD0A3AFD5L}};
    int64_t l_57 = 0x7EDFD6319DC0990ELL;
    int32_t l_58[9] = {0x08467E5FL,0x721BC9AFL,0x08467E5FL,0x08467E5FL,0x721BC9AFL,0x08467E5FL,0x08467E5FL,0x721BC9AFL,0x08467E5FL};
    int32_t l_63 = (-1L);
    int i, j;
    for (i = 0; i < 5; i++)
        l_14[i] = 254UL;
    for (p_10 = 0; (p_10 >= 6); p_10 = safe_add_func_int8_t_s_s(p_10, 5))
    { /* block id: 16 */
        int32_t l_20 = 0L;
        for (p_9 = 4; (p_9 >= 0); p_9 -= 1)
        { /* block id: 19 */
            int32_t l_49 = 0L;
            int i;
            l_49 = (func_15(l_14[p_9], l_20, p_9, p_8) == (-7L));
        }
        p_9 = (p_10 ^ l_20);
    }
    p_9 = (safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((((safe_div_func_int32_t_s_s(g_4, p_9)) || l_14[4]) ^ (-6L)) == g_3), g_6)), p_8));
    ++g_60[1];
    return l_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_6 g_3 g_5 g_46
 * writes: g_32 g_4 g_46
 */
static const int32_t  func_15(int32_t  p_16, uint32_t  p_17, int32_t  p_18, int16_t  p_19)
{ /* block id: 20 */
    uint16_t l_26 = 0xBA27L;
    int32_t l_45 = 0x450DE0B5L;
    if ((safe_div_func_int32_t_s_s(func_23(p_16, l_26), p_18)))
    { /* block id: 27 */
        int32_t l_42 = 0x345D18A9L;
        for (p_18 = 0; (p_18 <= (-27)); p_18--)
        { /* block id: 30 */
            return g_32;
        }
        l_42 = (((!(p_18 ^ p_18)) , p_16) <= g_5);
        g_4 = p_19;
    }
    else
    { /* block id: 35 */
        for (g_32 = 0; (g_32 >= 47); ++g_32)
        { /* block id: 38 */
            --g_46;
        }
    }
    return l_45;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_6 g_3 g_5
 * writes: g_32 g_4
 */
static int32_t  func_23(int16_t  p_24, int32_t  p_25)
{ /* block id: 21 */
    uint16_t l_27 = 0xB09EL;
    int32_t l_28 = 1L;
    int32_t l_29 = 0xEF28F0E4L;
    int32_t l_30 = 0L;
    int32_t l_31 = 0xA86E60E4L;
    l_27 = 0x3E9BECC4L;
    g_32--;
    l_31 = ((safe_lshift_func_int16_t_s_s(0x1A33L, l_30)) ^ g_6);
    g_4 = (safe_div_func_int32_t_s_s(p_25, g_3));
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_60 g_32 g_95 g_100 g_4 g_46 g_5 g_64
 * writes: g_6 g_3 g_95 g_100 g_4 g_5
 */
static int32_t  func_72(uint64_t  p_73, int8_t  p_74, uint32_t  p_75, uint32_t  p_76, const uint64_t  p_77)
{ /* block id: 57 */
    uint32_t l_87 = 4294967292UL;
    int32_t l_91 = 1L;
    int32_t l_92 = 1L;
    int32_t l_93[5][8] = {{0x34FACA1CL,(-7L),0x6036CB78L,0x58918311L,0x6036CB78L,(-7L),0x34FACA1CL,0x34FACA1CL},{(-7L),0x58918311L,(-10L),(-10L),(-10L),0x34FACA1CL,0x6036CB78L,0x34FACA1CL},{(-10L),0x34FACA1CL,0x6036CB78L,0x34FACA1CL,(-10L),0x723A6807L,0x723A6807L,(-10L)},{0x34FACA1CL,0x58918311L,0x58918311L,0x34FACA1CL,0x28CDBBAEL,(-10L),0x28CDBBAEL,0x34FACA1CL},{0x58918311L,0x28CDBBAEL,0x58918311L,0x723A6807L,0x6036CB78L,0x6036CB78L,0x723A6807L,0x58918311L}};
    int32_t l_94 = 1L;
    uint64_t l_98 = 0xD8F9DEAA75BC96B2LL;
    int i, j;
lbl_123:
    for (g_6 = 14; (g_6 < 13); g_6 = safe_sub_func_uint32_t_u_u(g_6, 7))
    { /* block id: 60 */
        int8_t l_107[5];
        int i;
        for (i = 0; i < 5; i++)
            l_107[i] = 0xAEL;
        if ((safe_div_func_uint32_t_u_u(l_87, l_87)))
        { /* block id: 61 */
            int32_t l_90[4][4] = {{0x044AB526L,0x044AB526L,0x66C24980L,0xBCBDF4B4L},{0xBCBDF4B4L,1L,0x66C24980L,1L},{0x044AB526L,1L,(-1L),0x66C24980L},{1L,1L,1L,1L}};
            int i, j;
            g_3 = (safe_div_func_uint8_t_u_u((((g_60[1] | l_90[1][0]) | g_32) || (-1L)), 253UL));
            g_95[0][0]++;
            l_98 = l_90[3][1];
        }
        else
        { /* block id: 65 */
            int64_t l_99[8] = {0x16D794BBEC019993LL,0x16D794BBEC019993LL,0x16D794BBEC019993LL,0x16D794BBEC019993LL,0x16D794BBEC019993LL,0x16D794BBEC019993LL,0x16D794BBEC019993LL,0x16D794BBEC019993LL};
            int i;
            if (p_74)
                break;
            ++g_100;
            g_4 |= ((safe_add_func_int32_t_s_s((-1L), g_60[2])) || p_77);
            l_107[4] = (((safe_sub_func_uint16_t_u_u(g_46, g_6)) , g_32) == g_95[0][0]);
        }
        if (g_6)
            continue;
        for (p_73 = 8; (p_73 > 23); ++p_73)
        { /* block id: 74 */
            uint8_t l_110[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
            int i;
            ++l_110[5];
            l_92 = (0x68L == g_95[0][0]);
        }
    }
    for (p_76 = 1; (p_76 >= 34); p_76 = safe_add_func_int32_t_s_s(p_76, 2))
    { /* block id: 81 */
        int8_t l_117 = 0xEFL;
        l_117 = (safe_rshift_func_uint16_t_u_u(0x40A6L, 11));
    }
    for (p_73 = (-11); (p_73 != 50); ++p_73)
    { /* block id: 86 */
        int32_t l_122 = 1L;
        if ((safe_div_func_int16_t_s_s(l_122, l_122)))
        { /* block id: 87 */
            return l_122;
        }
        else
        { /* block id: 89 */
            int8_t l_126 = (-3L);
            if (l_87)
                goto lbl_123;
            l_126 = (safe_mul_func_int8_t_s_s((g_5 >= 0UL), 1UL));
            g_5 = ((-7L) <= 0x35E13616L);
        }
    }
    return g_64[8];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_60[i], "g_60[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_64[i], "g_64[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_95[i][j], "g_95[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 51
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 63
   depth: 2, occurrence: 23
   depth: 3, occurrence: 5
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 100
XXX times a non-volatile is write: 40
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 11
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 91
XXX percentage of non-volatile access: 84.8

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 67
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 19
   depth: 2, occurrence: 29

XXX percentage a fresh-made variable is used: 26.2
XXX percentage an existing variable is used: 73.8
********************* end of statistics **********************/

