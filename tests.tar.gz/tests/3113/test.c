/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8122590758852022947
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int16_t g_10[9] = {0x923EL,0x923EL,0x923EL,0x923EL,0x923EL,0x923EL,0x923EL,0x923EL,0x923EL};
static uint32_t g_29[6] = {0x0547507AL,0x0547507AL,0x0547507AL,0x0547507AL,0x0547507AL,0x0547507AL};
static uint32_t g_35 = 18446744073709551615UL;
static int32_t g_42 = (-1L);


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_6(uint32_t  p_7);
static int32_t  func_14(int32_t  p_15, uint8_t  p_16, uint64_t  p_17, uint64_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_29 g_35
 * writes: g_35 g_42
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9 = 0x0D37AD43L;
    g_42 = (safe_lshift_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(func_6(((safe_unary_minus_func_int32_t_s(l_9)) , l_9)), l_9)), 4));
    return g_29[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_29 g_35
 * writes: g_35
 */
static uint32_t  func_6(uint32_t  p_7)
{ /* block id: 1 */
    uint16_t l_11[9] = {65534UL,0UL,65534UL,65534UL,0UL,65534UL,65534UL,0UL,65534UL};
    int64_t l_30 = 3L;
    int64_t l_31 = 0xFD55BE9843C6BCFBLL;
    int32_t l_41[6] = {0x983D4F39L,0x983D4F39L,0x983D4F39L,0x983D4F39L,0x983D4F39L,0x983D4F39L};
    int i;
    l_11[0]--;
    l_41[2] = func_14(((((((((safe_add_func_int32_t_s_s(((safe_sub_func_int32_t_s_s((((((((((((safe_sub_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_s(l_11[5], 15)), 18446744073709551615UL)), l_11[8])) < g_10[1]) != l_11[7]) , l_11[8]) != l_11[8]) , g_10[1]) & 1L) < g_29[2]) || 0xAA3E8F08877E0698LL) || g_29[3]) == p_7), p_7)) > 0xD4B082B0L), l_11[7])) , g_29[1]) >= l_30) , g_29[2]) & (-1L)) > l_30) , 0xCB51404FC4B664FBLL) , l_31), p_7, l_30, p_7);
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_35 g_10
 * writes: g_35
 */
static int32_t  func_14(int32_t  p_15, uint8_t  p_16, uint64_t  p_17, uint64_t  p_18)
{ /* block id: 3 */
    int8_t l_32[5];
    uint64_t l_40[2];
    int i;
    for (i = 0; i < 5; i++)
        l_32[i] = 1L;
    for (i = 0; i < 2; i++)
        l_40[i] = 0x85CA7DBC8B697689LL;
    p_15 ^= 0x60D1F283L;
    l_32[0] = p_16;
    g_35 ^= (safe_mod_func_int32_t_s_s(l_32[1], l_32[3]));
    l_40[0] = (safe_add_func_int16_t_s_s((safe_add_func_int8_t_s_s(0xD5L, l_32[0])), 0x11E7L));
    return g_10[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_29[i], "g_29[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 28
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 28, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 27
XXX times a non-volatile is write: 7
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 91.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 10

XXX percentage a fresh-made variable is used: 28.9
XXX percentage an existing variable is used: 71.1
********************* end of statistics **********************/

