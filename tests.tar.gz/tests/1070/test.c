/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14802554032176005645
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint8_t  f0;
   uint32_t  f1;
   int64_t  f2;
   int32_t  f3;
   uint32_t  f4;
   uint32_t  f5;
   volatile int16_t  f6;
   const volatile uint16_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_6 = 18446744073709551606UL;/* VOLATILE GLOBAL g_6 */
static volatile uint64_t g_9 = 0x47597A61EEFB6F65LL;/* VOLATILE GLOBAL g_9 */
static const int32_t g_11[4][10][1] = {{{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L}},{{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L}},{{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L}},{{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L},{1L},{0xE7975358L}}};
static uint32_t g_12[9] = {0xC9CA3191L,0xC9CA3191L,0xC9CA3191L,0xC9CA3191L,0xC9CA3191L,0xC9CA3191L,0xC9CA3191L,0xC9CA3191L,0xC9CA3191L};
static uint16_t g_18 = 0xF0DFL;
static uint32_t g_23[3][1] = {{4294967289UL},{4294967289UL},{4294967289UL}};
static uint32_t g_24 = 18446744073709551608UL;
static int8_t g_42 = 9L;
static int64_t g_75 = 6L;
static volatile uint8_t g_77 = 1UL;/* VOLATILE GLOBAL g_77 */
static uint32_t g_82[10] = {0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL,0xDF4F35DDL};
static uint16_t g_87 = 0x88E1L;
static int32_t g_93 = 0xBB4FD8EDL;
static uint16_t g_94[7][7][5] = {{{0xEF58L,65535UL,0UL,0xCB54L,65527UL},{7UL,65531UL,4UL,65531UL,7UL},{65535UL,0UL,1UL,0xEF58L,0xAF95L},{0x5831L,65526UL,0x3380L,65534UL,65535UL},{65527UL,65535UL,9UL,0UL,0xAF95L},{0UL,65534UL,65535UL,0UL,7UL},{0xAF95L,65535UL,0UL,8UL,65527UL}},{{5UL,0x3E88L,0x3380L,0x0393L,0x3380L},{0xAF95L,0xAF95L,65531UL,0xCB54L,65535UL},{0UL,0x0393L,4UL,0x42DFL,0UL},{65527UL,0UL,0xCCD1L,8UL,0xEF58L},{0x5831L,0x0393L,0x5831L,0x3E88L,65535UL},{65535UL,0xAF95L,65535UL,0UL,8UL},{7UL,0x3E88L,65535UL,65535UL,0UL}},{{0xEF58L,65535UL,65535UL,0xEF58L,65535UL},{5UL,65534UL,0x5831L,65526UL,0x3380L},{8UL,65535UL,0xCCD1L,0xCB54L,1UL},{7UL,65526UL,4UL,65526UL,7UL},{65535UL,0UL,65531UL,0xEF58L,65535UL},{0x5831L,65531UL,0x3380L,65535UL,65535UL},{1UL,65535UL,0UL,0UL,65535UL}},{{0UL,65535UL,65535UL,0x3E88L,7UL},{65535UL,65535UL,9UL,8UL,1UL},{5UL,0UL,0x3380L,0x42DFL,0x3380L},{65535UL,0xAF95L,1UL,0xCB54L,65535UL},{0UL,0x42DFL,4UL,0x0393L,0UL},{1UL,0UL,0UL,8UL,8UL},{0x5831L,0x42DFL,0x5831L,0UL,65535UL}},{{65535UL,0xAF95L,0xCB54L,0UL,0xEF58L},{7UL,0UL,65535UL,65534UL,0UL},{8UL,65535UL,0xCB54L,0xEF58L,65535UL},{5UL,65535UL,0x5831L,65531UL,0x3380L},{0xEF58L,65535UL,0UL,0xCB54L,65527UL},{7UL,65531UL,4UL,65531UL,7UL},{65535UL,0UL,1UL,0xEF58L,0xAF95L}},{{0x5831L,65526UL,0x3380L,65534UL,65535UL},{65527UL,65535UL,9UL,0UL,0xAF95L},{0UL,65534UL,65535UL,0UL,7UL},{0xAF95L,65535UL,0UL,8UL,65527UL},{5UL,0x3E88L,0x3380L,0x0393L,0x3380L},{0xAF95L,0xAF95L,65531UL,0xCB54L,65535UL},{0UL,0x0393L,4UL,0x42DFL,0UL}},{{65527UL,0UL,0xCCD1L,8UL,0xEF58L},{0x5831L,0x0393L,0x5831L,0x3E88L,65535UL},{65535UL,0xAF95L,65535UL,0UL,8UL},{7UL,0x3E88L,65535UL,65535UL,0UL},{0xEF58L,65535UL,65535UL,0xEF58L,65535UL},{5UL,65534UL,0x5831L,65526UL,0x3380L},{8UL,65535UL,0xCCD1L,0xCB54L,1UL}}};
static volatile struct S0 g_129 = {0UL,0x93B24359L,0L,-2L,4294967289UL,0UL,0x9804L,0UL};/* VOLATILE GLOBAL g_129 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint64_t  func_27(int8_t  p_28);
static uint8_t  func_48(uint64_t  p_49);
static const int16_t  func_63(uint16_t  p_64);
static uint16_t  func_69(uint32_t  p_70, uint8_t  p_71, const int32_t  p_72, uint16_t  p_73);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_9 g_11 g_12 g_18 g_24 g_42 g_77 g_75 g_94 g_82 g_93 g_23 g_87 g_129
 * writes: g_6 g_9 g_12 g_18 g_23 g_24 g_42 g_75 g_77 g_82 g_87 g_93 g_94
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_4 = 18446744073709551615UL;
    int32_t l_5 = 0x14C90D29L;
    int32_t l_17 = (-7L);
    if (((safe_mod_func_int32_t_s_s(l_4, l_4)) == l_4))
    { /* block id: 1 */
        g_6--;
        g_9 = g_6;
    }
    else
    { /* block id: 4 */
        int8_t l_10 = 0x7DL;
        g_12[4] &= ((g_9 , l_10) & g_11[1][1][0]);
        for (l_5 = 0; (l_5 == 10); l_5 = safe_add_func_uint64_t_u_u(l_5, 1))
        { /* block id: 8 */
            int64_t l_15 = 0x23D4A1CF04157736LL;
            int32_t l_16 = 0x043EEF7DL;
            g_18--;
            g_23[2][0] = ((safe_add_func_uint8_t_u_u(((1UL || l_10) >= 1UL), (-1L))) , g_18);
            ++g_24;
        }
        l_17 = ((func_27(l_4) && 0x3A0AE147BCB459ADLL) >= l_17);
    }
    for (g_87 = 24; (g_87 < 38); g_87++)
    { /* block id: 78 */
        int32_t l_121 = 0L;
        if (g_24)
        { /* block id: 79 */
            g_93 &= (l_121 ^ 0xA33BL);
        }
        else
        { /* block id: 81 */
            uint32_t l_122 = 4294967295UL;
            --l_122;
            g_93 = (safe_add_func_int8_t_s_s(((safe_mod_func_int32_t_s_s((g_129 , g_11[1][1][0]), l_122)) != l_121), l_122));
            if (g_129.f2)
                break;
        }
    }
    return l_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_12 g_18 g_42 g_6 g_24 g_77 g_75 g_94 g_82 g_93 g_9 g_23
 * writes: g_42 g_18 g_75 g_77 g_82 g_87 g_93 g_94
 */
static uint64_t  func_27(int8_t  p_28)
{ /* block id: 13 */
    uint32_t l_39[4][3] = {{0xEE879096L,4294967295UL,0xEE879096L},{0x996FD0FEL,0x996FD0FEL,0x996FD0FEL},{0xEE879096L,4294967295UL,0xEE879096L},{0x996FD0FEL,0x996FD0FEL,0x996FD0FEL}};
    int32_t l_47[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
    int32_t l_118 = 0x53720512L;
    int i, j;
    if ((safe_mod_func_uint64_t_u_u((safe_rshift_func_int8_t_s_s((safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u(((safe_mul_func_int8_t_s_s(((l_39[2][1] && p_28) >= p_28), 255UL)) && 0x8E181F51B4373C94LL), g_11[1][1][0])), g_12[4])), p_28)), 0x0E56979F9F4AEC70LL)))
    { /* block id: 14 */
        uint16_t l_45 = 0xE240L;
        int32_t l_107 = 0x280801E7L;
        g_42 = (safe_rshift_func_uint8_t_u_u(p_28, 6));
        for (g_18 = 0; (g_18 <= 34); ++g_18)
        { /* block id: 18 */
            int32_t l_46[10] = {0xF2B6367AL,6L,0xF2B6367AL,0xF2B6367AL,6L,0xF2B6367AL,0xF2B6367AL,6L,0xF2B6367AL,0xF2B6367AL};
            int i;
            l_47[0] = (((l_45 && 1L) > l_46[7]) <= g_11[0][6][0]);
            l_107 = (func_48((safe_mod_func_int8_t_s_s(((safe_add_func_int8_t_s_s((safe_div_func_uint32_t_u_u((~((((safe_lshift_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((safe_rshift_func_int16_t_s_u(func_63(((safe_mod_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(func_69(((p_28 < g_11[1][1][0]) < g_42), p_28, g_6, p_28), p_28)), g_12[7])) ^ g_42)), l_45)), p_28)), p_28)) <= 0xB3AEB4CD7CE17D65LL) , g_12[8]) , p_28)), g_12[8])), 0xE3L)) || g_9), 0x6CL))) >= l_45);
        }
    }
    else
    { /* block id: 59 */
        return l_47[0];
    }
    if ((safe_div_func_int16_t_s_s(7L, l_47[7])))
    { /* block id: 62 */
        if (g_42)
        { /* block id: 63 */
            uint16_t l_110 = 0xFBA8L;
            l_110++;
            return p_28;
        }
        else
        { /* block id: 66 */
            const int16_t l_113[10] = {1L,0xD9EAL,0xD9EAL,1L,0xE0F9L,1L,0xD9EAL,0xD9EAL,1L,0xE0F9L};
            int i;
            g_93 |= (l_113[1] || p_28);
        }
    }
    else
    { /* block id: 69 */
        uint64_t l_114 = 0x2B5330BC39A6180ELL;
        int32_t l_115 = 0x0C04CD9FL;
        l_115 ^= (g_9 && l_114);
    }
    l_118 |= ((safe_sub_func_int64_t_s_s(((((((g_75 && g_23[1][0]) > g_82[6]) || l_47[0]) , p_28) >= g_24) || 0x6601A515L), p_28)) > l_39[2][1]);
    return p_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_93 g_11 g_77
 * writes: g_93
 */
static uint8_t  func_48(uint64_t  p_49)
{ /* block id: 45 */
    int8_t l_99[9][7][4] = {{{8L,0x0BL,(-2L),0xECL},{0x96L,5L,0x9DL,0x8CL},{0xABL,0L,9L,0x00L},{(-1L),0x18L,0xA9L,1L},{0xBEL,(-5L),0xFFL,(-4L)},{0x0EL,1L,0x61L,8L},{0xDFL,(-2L),5L,0x20L}},{{8L,(-4L),9L,9L},{(-1L),(-1L),0xA0L,0L},{0xDFL,0L,0x0EL,5L},{8L,0x61L,1L,0x0EL},{0x18L,0x61L,0x05L,5L},{0x61L,0L,0xBAL,0L},{0xD2L,(-1L),0xC9L,9L}},{{0xA7L,(-4L),0xBEL,0x20L},{0xECL,(-2L),0x0BL,8L},{0x2EL,1L,0xC7L,(-4L)},{0xC9L,(-5L),(-10L),1L},{(-4L),0x18L,5L,0x00L},{0xA7L,0L,0x5AL,0x8CL},{8L,0x5AL,0xA2L,0xBAL}},{{(-5L),0xFFL,0xADL,0x12L},{0xA2L,(-1L),(-4L),(-9L)},{0x7FL,0x61L,0x55L,0x3BL},{(-10L),0x2EL,0xC7L,0x77L},{4L,0x12L,0x1FL,8L},{0xABL,0xA2L,0xD9L,0xECL},{0x5AL,(-1L),0xD9L,(-1L)}},{{0xA9L,0xA0L,0xECL,0x3EL},{(-9L),0x64L,0x5DL,3L},{9L,0L,0x1FL,4L},{0xF2L,0x1FL,0x68L,(-2L)},{3L,0L,0L,0L},{0x7FL,(-5L),0x65L,0L},{0x00L,(-4L),0L,0x5AL}},{{0x7BL,0L,0xA2L,9L},{(-2L),0x1FL,(-9L),0x1FL},{0x77L,(-5L),0L,1L},{(-4L),0xA9L,0xFFL,0x3EL},{0x7AL,1L,1L,0xA2L},{0x7AL,0x61L,0xFFL,0x7BL},{(-4L),0xA2L,0L,0x0EL}},{{0x77L,0L,(-9L),(-1L)},{(-2L),0xC9L,0xA2L,0x3BL},{0x7BL,0xDAL,0L,0x12L},{0x00L,8L,0x65L,0x7AL},{0x7FL,0xFFL,0L,0x3DL},{3L,0x2EL,0x68L,(-1L)},{0xF2L,0L,0x1FL,0xEEL}},{{9L,0xD2L,0x5DL,0xECL},{(-9L),0x61L,0xECL,0x00L},{0xA9L,0x65L,0xD9L,0L},{0x5AL,0x64L,0xD9L,1L},{0xABL,0x46L,0x1FL,(-3L)},{4L,0xC2L,0xC7L,(-2L)},{(-10L),0L,0x55L,(-9L)}},{{0x7FL,0xECL,(-4L),0x55L},{0xA2L,(-4L),0xADL,0L},{(-5L),1L,0xA2L,0x89L},{8L,0xC2L,0x7AL,0x1FL},{0xB6L,0L,0x5AL,(-10L)},{(-4L),0x55L,0x6AL,0L},{0x12L,1L,0x5CL,(-1L)}}};
    int i, j, k;
    g_93 ^= l_99[0][0][3];
    for (p_49 = 0; (p_49 < 10); p_49++)
    { /* block id: 49 */
        int8_t l_106[7] = {0xD3L,0x95L,0x95L,0xD3L,0x95L,0x95L,0xD3L};
        int i;
        if (g_11[0][7][0])
        { /* block id: 50 */
            g_93 = ((((safe_mul_func_uint16_t_u_u((((safe_sub_func_int64_t_s_s((((l_99[0][4][1] & g_77) , 0x5FCA2CADL) > l_106[0]), p_49)) >= p_49) , 65532UL), 6UL)) , 0L) < p_49) && p_49);
        }
        else
        { /* block id: 52 */
            g_93 = ((9L || p_49) && 65535UL);
        }
    }
    return p_49;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int16_t  func_63(uint16_t  p_64)
{ /* block id: 43 */
    const uint32_t l_98 = 0x1B5A5E52L;
    return l_98;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_77 g_12 g_75 g_94 g_82 g_93
 * writes: g_75 g_77 g_82 g_87 g_93 g_94
 */
static uint16_t  func_69(uint32_t  p_70, uint8_t  p_71, const int32_t  p_72, uint16_t  p_73)
{ /* block id: 20 */
    int32_t l_76 = 1L;
    if (p_71)
    { /* block id: 21 */
        uint32_t l_74 = 0x9C83BDEEL;
        l_74 &= g_24;
        g_75 = 0x8D667733L;
    }
    else
    { /* block id: 24 */
        uint64_t l_85 = 1UL;
        int32_t l_86 = 0xFFE8FED2L;
        int32_t l_92 = 0xE0ADFBA6L;
        ++g_77;
        for (l_76 = 19; (l_76 != 20); l_76++)
        { /* block id: 28 */
            g_82[6] = l_76;
            return g_12[4];
        }
        for (l_76 = 0; (l_76 >= (-28)); l_76 = safe_sub_func_int8_t_s_s(l_76, 5))
        { /* block id: 34 */
            l_86 = (((l_85 || p_71) < g_77) ^ p_73);
            g_87 = l_86;
            g_93 = ((safe_rshift_func_uint8_t_u_s((safe_lshift_func_uint8_t_u_u(((((0x45C746EAL != 0L) > l_76) | l_76) , p_73), g_75)), p_72)) || l_92);
        }
        g_94[4][5][3]--;
    }
    g_93 = (((!g_82[0]) , l_76) , p_70);
    return g_93;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_11[i][j][k], "g_11[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_18, "g_18", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_23[i][j], "g_23[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_82[i], "g_82[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_94[i][j][k], "g_94[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_129.f0, "g_129.f0", print_hash_value);
    transparent_crc(g_129.f1, "g_129.f1", print_hash_value);
    transparent_crc(g_129.f2, "g_129.f2", print_hash_value);
    transparent_crc(g_129.f3, "g_129.f3", print_hash_value);
    transparent_crc(g_129.f4, "g_129.f4", print_hash_value);
    transparent_crc(g_129.f5, "g_129.f5", print_hash_value);
    transparent_crc(g_129.f6, "g_129.f6", print_hash_value);
    transparent_crc(g_129.f7, "g_129.f7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 40
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 23
breakdown:
   depth: 1, occurrence: 55
   depth: 2, occurrence: 11
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 11, occurrence: 1
   depth: 23, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 92
XXX times a non-volatile is write: 32
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 54
XXX percentage of non-volatile access: 91.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 51
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 18
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 31.3
XXX percentage an existing variable is used: 68.7
********************* end of statistics **********************/

