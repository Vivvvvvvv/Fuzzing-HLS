/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14496593019759021619
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_8 = 0xBEL;
static volatile int8_t g_11 = 6L;/* VOLATILE GLOBAL g_11 */
static int8_t g_12 = 0xBFL;
static volatile int32_t g_13 = 0x6F97812AL;/* VOLATILE GLOBAL g_13 */
static int8_t g_14 = 7L;
static int8_t g_15 = 0x32L;
static volatile uint8_t g_16 = 0UL;/* VOLATILE GLOBAL g_16 */
static uint32_t g_65[9] = {0x40913DB3L,0x40913DB3L,0x40913DB3L,0x40913DB3L,0x40913DB3L,0x40913DB3L,0x40913DB3L,0x40913DB3L,0x40913DB3L};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_21(int8_t  p_22);
static int32_t  func_23(int8_t  p_24, uint16_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_16 g_14 g_13 g_12 g_11 g_15 g_65
 * writes: g_8 g_16 g_14 g_13 g_65
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2 = 2UL;
    int32_t l_9[9] = {0xEB200688L,0x4F094650L,0xEB200688L,0x4F094650L,0xEB200688L,0x4F094650L,0xEB200688L,0x4F094650L,0xEB200688L};
    int i;
    if (l_2)
    { /* block id: 1 */
        uint32_t l_7 = 0UL;
        g_8 = (safe_add_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(l_7, 10)), 1UL));
        return g_8;
    }
    else
    { /* block id: 4 */
        for (g_8 = 0; (g_8 <= 8); g_8 += 1)
        { /* block id: 7 */
            int32_t l_10 = 0L;
            int i;
            g_16++;
            g_65[1] &= (safe_add_func_int32_t_s_s(func_21((func_23((safe_add_func_int8_t_s_s(l_9[g_8], l_10)), g_14) , (-5L))), g_15));
        }
        return g_13;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_8 g_13 g_12 g_11
 * writes: g_13
 */
static int32_t  func_21(int8_t  p_22)
{ /* block id: 18 */
    int32_t l_40[10];
    int32_t l_51[2];
    uint32_t l_60 = 0x87C631DBL;
    int i;
    for (i = 0; i < 10; i++)
        l_40[i] = 1L;
    for (i = 0; i < 2; i++)
        l_51[i] = (-1L);
    if ((p_22 != p_22))
    { /* block id: 19 */
        int32_t l_41 = 0x914BE495L;
        g_13 = ((safe_mod_func_uint32_t_u_u((((7UL ^ g_16) != 0x14D4L) == p_22), 0xD9C8C74CL)) != 0x5CFEB4E5L);
        l_41 = ((g_16 > l_40[4]) , l_40[2]);
    }
    else
    { /* block id: 22 */
        int16_t l_55 = 0xD2C9L;
        g_13 &= ((safe_div_func_uint64_t_u_u(l_40[8], g_8)) ^ (-1L));
        for (p_22 = 0; (p_22 < (-21)); p_22--)
        { /* block id: 26 */
            int64_t l_50 = (-5L);
            l_51[1] = ((safe_div_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_s((l_50 > p_22), 0)), 0x199447610B5C7B12LL)) >= 0x3DL);
            l_55 = ((+((safe_add_func_uint16_t_u_u(g_16, p_22)) ^ p_22)) != g_12);
            if (p_22)
                continue;
            if (l_40[5])
                break;
        }
        return p_22;
    }
    g_13 = (safe_rshift_func_int8_t_s_s((((((((safe_mod_func_int64_t_s_s(l_40[7], l_51[1])) >= 0x00L) >= 0xC6C9A4A91A3D0676LL) <= g_11) <= p_22) , p_22) != g_12), l_60));
    l_51[0] = (safe_mul_func_uint8_t_u_u(p_22, p_22));
    for (l_60 = 25; (l_60 >= 41); l_60 = safe_add_func_int64_t_s_s(l_60, 5))
    { /* block id: 38 */
        l_51[1] = 0x828C2071L;
    }
    return g_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_13
 * writes: g_14 g_13
 */
static int32_t  func_23(int8_t  p_24, uint16_t  p_25)
{ /* block id: 9 */
    uint32_t l_30[1];
    int i;
    for (i = 0; i < 1; i++)
        l_30[i] = 0x80278EE3L;
    for (g_14 = 0; (g_14 < 18); ++g_14)
    { /* block id: 12 */
        uint32_t l_34 = 0xCFD8F271L;
        int32_t l_35 = (-7L);
        l_30[0]--;
        l_35 ^= (safe_unary_minus_func_uint64_t_u((l_30[0] , l_34)));
    }
    g_13 = (safe_mul_func_uint16_t_u_u(65532UL, 0x9E5AL));
    return g_13;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_65[i], "g_65[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 8
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 13
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 22
XXX percentage of non-volatile access: 80.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 27
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 12
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 33.9
XXX percentage an existing variable is used: 66.1
********************* end of statistics **********************/

