/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3292214348224927948
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint32_t g_22[1] = {0x7D50F82BL};
static volatile uint64_t g_23 = 18446744073709551615UL;/* VOLATILE GLOBAL g_23 */
static int32_t g_28 = 0xF9E3D3B0L;
static volatile int8_t g_32 = 0L;/* VOLATILE GLOBAL g_32 */
static int32_t g_33 = 1L;
static int32_t g_36 = 0L;
static int8_t g_37 = 0xA5L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint16_t  func_10(int32_t  p_11, uint64_t  p_12, uint32_t  p_13, int64_t  p_14, int16_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_22 g_23 g_28 g_36
 * writes: g_23 g_28
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_21[3];
    int32_t l_27 = 0x65786371L;
    int32_t l_34[8];
    int16_t l_35 = 0x22ABL;
    int64_t l_38 = 0xF4864854668DACB3LL;
    uint32_t l_39 = 0xB63E91CBL;
    int i;
    for (i = 0; i < 3; i++)
        l_21[i] = 0xFE8B0D19L;
    for (i = 0; i < 8; i++)
        l_34[i] = 7L;
    g_28 &= (safe_sub_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u(func_10((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_int32_t_s(((l_21[1] ^ (-5L)) ^ g_22[0]))), 1L)), l_21[1])), l_21[1], g_22[0], g_22[0], l_21[1]), 8)), g_22[0])), l_27)), l_27));
    if (l_27)
        goto lbl_31;
lbl_31:
    l_27 |= (safe_lshift_func_int8_t_s_u(1L, 3));
    l_39++;
    return g_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_23
 * writes: g_23
 */
static uint16_t  func_10(int32_t  p_11, uint64_t  p_12, uint32_t  p_13, int64_t  p_14, int16_t  p_15)
{ /* block id: 1 */
    int32_t l_26 = 8L;
    --g_23;
    return l_26;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 12
XXX times a non-volatile is write: 3
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 93.8

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 7

XXX percentage a fresh-made variable is used: 51.9
XXX percentage an existing variable is used: 48.1
********************* end of statistics **********************/

