/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      26873452090815245
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-5L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = 4L;
static int32_t g_32 = 0xBCCBF785L;
static int8_t g_34 = 0x3DL;
static volatile uint32_t g_35[3][10] = {{0x9389D0E1L,0x06CF3632L,0x9389D0E1L,0x9389D0E1L,0x06CF3632L,0x9389D0E1L,0x9389D0E1L,0x06CF3632L,0x9389D0E1L,0x9389D0E1L},{0x06CF3632L,0x06CF3632L,0x85184BF4L,0x06CF3632L,0x06CF3632L,0x85184BF4L,0x06CF3632L,0x06CF3632L,0x85184BF4L,0x06CF3632L},{0x06CF3632L,0x9389D0E1L,0x9389D0E1L,0x06CF3632L,0x9389D0E1L,0x9389D0E1L,0x06CF3632L,0x9389D0E1L,0x9389D0E1L,0x06CF3632L}};
static uint8_t g_95[2][4][3] = {{{4UL,0xD5L,0xE6L},{0UL,255UL,0UL},{0UL,4UL,0xE6L},{0x15L,0x15L,0xE6L}},{{2UL,4UL,4UL},{0xE6L,0x15L,255UL},{0xE6L,0UL,0xE6L},{0xE6L,0UL,255UL}}};
static uint32_t g_128 = 0x993E846AL;
static int64_t g_130 = 0x3639C8BEE33383FDLL;
static uint32_t g_135 = 18446744073709551610UL;
static uint32_t g_138 = 0x29FEAD6BL;
static uint64_t g_209[9][6] = {{8UL,18446744073709551615UL,0UL,0x6FDDE1F1B1ED0898LL,0UL,8UL},{0UL,1UL,0x6FDDE1F1B1ED0898LL,0x6FDDE1F1B1ED0898LL,1UL,0UL},{8UL,0UL,0x6FDDE1F1B1ED0898LL,0UL,18446744073709551615UL,8UL},{7UL,0UL,0UL,7UL,1UL,7UL},{7UL,1UL,7UL,0UL,0UL,7UL},{8UL,18446744073709551615UL,0UL,0x6FDDE1F1B1ED0898LL,0UL,8UL},{0UL,1UL,0x6FDDE1F1B1ED0898LL,0x6FDDE1F1B1ED0898LL,1UL,0UL},{8UL,0UL,0x6FDDE1F1B1ED0898LL,0UL,18446744073709551615UL,8UL},{7UL,0UL,0UL,7UL,1UL,7UL}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int16_t  func_7(uint32_t  p_8, int8_t  p_9, const uint8_t  p_10, const uint16_t  p_11);
static const int32_t  func_42(const uint32_t  p_43, int16_t  p_44);
static int32_t  func_49(uint64_t  p_50, int8_t  p_51, int64_t  p_52);
static uint16_t  func_80(int32_t  p_81, int64_t  p_82, uint32_t  p_83);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_35 g_32 g_34 g_95 g_128 g_130 g_135 g_209
 * writes: g_4 g_3 g_35 g_32 g_34 g_95 g_128 g_130 g_135 g_138 g_209
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_183 = 0xB6L;
    uint64_t l_184 = 0xEC332B00AC53F835LL;
    int32_t l_201 = 1L;
    int32_t l_208[6] = {0xA891246EL,0xA891246EL,0xA891246EL,0xA891246EL,0xA891246EL,0xA891246EL};
    int i;
    if ((0x8B13ECA4L < 4294967293UL))
    { /* block id: 1 */
        int64_t l_2[2];
        int i;
        for (i = 0; i < 2; i++)
            l_2[i] = 0L;
        for (g_4 = 1; (g_4 >= 0); g_4 -= 1)
        { /* block id: 4 */
            int i;
            return l_2[g_4];
        }
        l_184 = (((safe_lshift_func_int16_t_s_s(func_7(g_3, g_4, g_4, l_2[0]), l_2[1])) > 255UL) | l_183);
        return g_35[2][4];
    }
    else
    { /* block id: 143 */
        int16_t l_196 = 0xBB2BL;
        uint16_t l_197 = 1UL;
        int32_t l_202 = 0x5C33B20CL;
        g_3 &= l_183;
        if (((safe_div_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u(((safe_lshift_func_int16_t_s_s((!(((safe_lshift_func_int16_t_s_u((((safe_div_func_uint16_t_u_u((l_183 > g_32), 0x68D1L)) ^ g_130) != l_196), 8)) ^ g_135) < l_197)), 15)) & g_32), 3)), 0xD15EB048L)) , 0xA615A5E8L))
        { /* block id: 145 */
            int32_t l_200 = 0x24118919L;
            l_201 = (safe_div_func_uint64_t_u_u((g_95[1][2][1] , l_200), l_200));
        }
        else
        { /* block id: 147 */
            uint16_t l_203 = 0xC1BAL;
            --l_203;
            l_201 = g_95[0][2][0];
            l_202 = (safe_add_func_uint8_t_u_u((l_184 <= (-4L)), l_203));
        }
    }
    g_209[7][0]--;
    return l_208[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_35 g_32 g_34 g_95 g_128 g_130 g_135
 * writes: g_4 g_3 g_35 g_32 g_34 g_95 g_128 g_130 g_135 g_138
 */
static int16_t  func_7(uint32_t  p_8, int8_t  p_9, const uint8_t  p_10, const uint16_t  p_11)
{ /* block id: 7 */
    int64_t l_15 = (-1L);
    int32_t l_30 = (-2L);
    int32_t l_31 = 0L;
    int32_t l_33 = 0L;
    uint64_t l_40 = 18446744073709551614UL;
    int8_t l_157 = 5L;
    int32_t l_162 = (-7L);
    int64_t l_163 = 0xFA4D0A6DBD2E68FDLL;
    uint16_t l_171 = 65535UL;
    uint32_t l_182 = 0xAA5DA819L;
    if (g_3)
    { /* block id: 8 */
        int8_t l_12[2];
        int32_t l_16 = 0x13CA4D9AL;
        int32_t l_17 = (-1L);
        int32_t l_18 = 0L;
        int32_t l_19[8][7] = {{0x1DBA1DD7L,(-5L),8L,2L,0x4A219909L,0x4A219909L,2L},{0x82169286L,0x8D514FAFL,0x82169286L,1L,0x073D4C46L,1L,0xD505BC98L},{(-1L),0L,0L,8L,9L,8L,0L},{0x073D4C46L,0x073D4C46L,0x42B4CF22L,1L,0x6E1459F4L,1L,0x8D514FAFL},{0x1EFE0C23L,1L,0x4A219909L,(-1L),(-1L),0x4A219909L,1L},{0L,0x82ECC90CL,0x073D4C46L,0x82169286L,0x6E1459F4L,1L,1L},{0x4A219909L,(-1L),9L,1L,9L,(-1L),0x4A219909L},{1L,1L,0x6E1459F4L,0x82169286L,0x073D4C46L,0x82ECC90CL,0L}};
        int i, j;
        for (i = 0; i < 2; i++)
            l_12[i] = 0L;
        g_4 = (-1L);
        for (p_9 = 1; (p_9 >= 0); p_9 -= 1)
        { /* block id: 12 */
            uint64_t l_20[8] = {0UL,18446744073709551609UL,18446744073709551609UL,0UL,18446744073709551609UL,18446744073709551609UL,0UL,18446744073709551609UL};
            int i;
            g_3 = (((safe_div_func_uint8_t_u_u(((7L == g_3) | g_4), 0xA0L)) == g_4) , 0x02AFF635L);
            l_15 = (((p_11 != g_3) && 0x0DFBL) == 0x3CL);
            ++l_20[6];
        }
        for (l_17 = 0; (l_17 >= 8); l_17 = safe_add_func_int32_t_s_s(l_17, 6))
        { /* block id: 19 */
            int16_t l_28 = 0x7DE2L;
            int32_t l_29[7] = {0x3E240190L,0x3E240190L,0xEC7DFFC5L,0x3E240190L,0x3E240190L,0xEC7DFFC5L,0x3E240190L};
            int i;
            l_28 = ((+(((safe_sub_func_int32_t_s_s(((g_3 ^ p_9) ^ l_15), g_4)) == g_4) >= p_9)) > p_8);
            ++g_35[0][1];
        }
    }
    else
    { /* block id: 23 */
        uint64_t l_41 = 18446744073709551609UL;
        int32_t l_152 = (-6L);
        int32_t l_156 = 0xC513462EL;
        l_41 = (safe_div_func_int32_t_s_s((p_10 & 65535UL), l_40));
        l_152 |= func_42(l_15, p_10);
        for (l_31 = 2; (l_31 >= 0); l_31 -= 1)
        { /* block id: 114 */
            l_33 = (((safe_mul_func_uint16_t_u_u((~(0x72L || l_156)), 0xC06CL)) <= g_95[0][0][2]) >= l_157);
            l_152 &= (((p_11 ^ l_157) < g_4) <= g_95[1][2][2]);
        }
        l_152 |= (((((safe_mod_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_s(0xA0F7L, 8)) <= p_11) || l_156), g_35[0][1])) && 0xE2AE1708L) || 65531UL) , l_162) != g_128);
    }
    l_163 &= (((l_15 | p_10) != l_162) , (-7L));
    g_3 = 4L;
    if ((((safe_div_func_int64_t_s_s(((((safe_div_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(((~g_34) && p_10), p_10)), l_171)) == g_130) == p_9) ^ l_30), 0x087EC753228B0A1BLL)) != 0x14A8CDCFL) < p_9))
    { /* block id: 122 */
        int32_t l_173 = (-1L);
        l_173 |= (+0UL);
        for (l_40 = 28; (l_40 >= 30); ++l_40)
        { /* block id: 126 */
            l_31 |= (-7L);
        }
        g_32 |= 0xD4EEA7A9L;
        l_30 = (0x65E4L ^ p_10);
    }
    else
    { /* block id: 131 */
        const uint32_t l_178 = 4294967294UL;
        int32_t l_179 = 1L;
        l_179 &= ((((safe_mod_func_uint64_t_u_u(l_178, g_4)) <= p_11) >= g_128) > p_11);
        if ((((4294967295UL == p_9) , 0xDFL) & 0x5CL))
        { /* block id: 133 */
            l_31 = 9L;
            return p_10;
        }
        else
        { /* block id: 136 */
            uint64_t l_180 = 18446744073709551611UL;
            int32_t l_181 = (-9L);
            l_181 = l_180;
        }
    }
    return l_182;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_4 g_34 g_35 g_3 g_95 g_128 g_130 g_135
 * writes: g_32 g_4 g_3 g_34 g_95 g_128 g_130 g_135 g_138
 */
static const int32_t  func_42(const uint32_t  p_43, int16_t  p_44)
{ /* block id: 25 */
    uint8_t l_55 = 255UL;
    int32_t l_140 = 9L;
    for (g_32 = 0; (g_32 != 14); g_32 = safe_add_func_uint16_t_u_u(g_32, 7))
    { /* block id: 28 */
        uint64_t l_56[1][4] = {{1UL,1UL,1UL,1UL}};
        int i, j;
        for (g_4 = 0; (g_4 != (-24)); g_4 = safe_sub_func_int8_t_s_s(g_4, 3))
        { /* block id: 31 */
            int16_t l_57 = 0xEB37L;
            g_138 = func_49(((safe_sub_func_uint8_t_u_u((p_43 < l_55), 0x67L)) != 0L), l_56[0][1], l_57);
            l_140 = (+((p_43 | g_35[0][5]) != p_44));
        }
        if ((((1UL < 0x0CL) , g_3) ^ p_44))
        { /* block id: 92 */
            uint8_t l_141[4] = {0xFAL,0xFAL,0xFAL,0xFAL};
            int32_t l_146 = 0xAE147BCBL;
            int i;
            l_141[2] = ((0x01L && 2UL) , l_56[0][1]);
            if (l_56[0][1])
                break;
            if (l_56[0][1])
                continue;
            l_146 &= (safe_sub_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_u((((((-3L) != g_128) >= g_35[2][0]) || g_95[1][1][0]) != g_32), 7)), p_43));
        }
        else
        { /* block id: 97 */
            l_140 = g_35[0][1];
        }
        if (g_95[1][2][0])
            break;
        for (p_44 = 0; (p_44 <= 28); p_44 = safe_add_func_uint16_t_u_u(p_44, 9))
        { /* block id: 103 */
            int32_t l_149 = 0L;
            l_140 &= (-3L);
            l_149 ^= l_56[0][2];
        }
    }
    l_140 = ((((safe_sub_func_int16_t_s_s((0xBA2CB814C848226CLL ^ p_44), g_95[1][2][2])) == 0L) ^ l_55) ^ p_44);
    for (g_130 = 0; g_130 < 2; g_130 += 1)
    {
        for (g_138 = 0; g_138 < 4; g_138 += 1)
        {
            for (g_3 = 0; g_3 < 3; g_3 += 1)
            {
                g_95[g_130][g_138][g_3] = 1UL;
            }
        }
    }
    return l_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_35 g_32 g_3 g_95 g_4 g_128 g_130 g_135
 * writes: g_3 g_34 g_95 g_128 g_130 g_135
 */
static int32_t  func_49(uint64_t  p_50, int8_t  p_51, int64_t  p_52)
{ /* block id: 32 */
    uint64_t l_60 = 0xB7BAF68603386B47LL;
    int32_t l_62 = 0xB77DEECCL;
    int32_t l_133 = 0x07845806L;
    int32_t l_134[6][8] = {{1L,0x7AEF2808L,(-10L),0x7AEF2808L,1L,0xB3E5AADBL,1L,0x7AEF2808L},{8L,0x7AEF2808L,8L,0x84A0DC95L,1L,0x84A0DC95L,8L,0x7AEF2808L},{1L,0x84A0DC95L,8L,0x7AEF2808L,8L,0x84A0DC95L,1L,0x84A0DC95L},{1L,0x7AEF2808L,(-10L),0x7AEF2808L,1L,0xB3E5AADBL,1L,0x7AEF2808L},{8L,0x7AEF2808L,8L,0x84A0DC95L,1L,0x84A0DC95L,8L,0x7AEF2808L},{1L,0x84A0DC95L,8L,0x7AEF2808L,(-10L),0xB3E5AADBL,8L,0xB3E5AADBL}};
    int i, j;
    if (p_50)
    { /* block id: 33 */
        for (p_52 = 0; (p_52 != 14); p_52++)
        { /* block id: 36 */
            return g_34;
        }
    }
    else
    { /* block id: 39 */
        uint8_t l_129 = 1UL;
        if (l_60)
        { /* block id: 40 */
            int64_t l_73 = 0x905910508B3DEF23LL;
            l_62 &= (((!g_35[1][4]) | 0x9CC0F79F61339852LL) && p_51);
            g_3 &= (safe_mod_func_uint32_t_u_u(0x34CD2740L, g_32));
            g_3 = ((safe_mul_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_u((safe_mod_func_uint8_t_u_u(l_73, l_73)), 15)), g_34)), 3L)) != g_32);
        }
        else
        { /* block id: 44 */
            g_130 |= (safe_sub_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(((safe_mod_func_uint16_t_u_u(func_80((safe_rshift_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(((-3L) >= g_35[1][1]), g_34)), 8)), g_34, p_52), (-6L))) , l_129), (-9L))), p_51));
            g_3 = ((((safe_mul_func_uint16_t_u_u((g_32 != p_50), g_34)) > p_51) <= l_62) , l_129);
            g_3 ^= p_52;
            return l_129;
        }
    }
    g_135--;
    return l_133;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_95 g_35 g_32 g_4 g_3 g_128
 * writes: g_34 g_95 g_3 g_128
 */
static uint16_t  func_80(int32_t  p_81, int64_t  p_82, uint32_t  p_83)
{ /* block id: 45 */
    const int8_t l_90[8] = {0x03L,0x03L,0x03L,0x03L,0x03L,0x03L,0x03L,0x03L};
    uint32_t l_91 = 1UL;
    int32_t l_94 = 0xBD2E7792L;
    int i;
    if ((((safe_sub_func_int8_t_s_s(l_90[2], 0xC0L)) , l_91) , 0x7DCD999CL))
    { /* block id: 46 */
        uint8_t l_105[1];
        int32_t l_106 = (-7L);
        int i;
        for (i = 0; i < 1; i++)
            l_105[i] = 0UL;
lbl_100:
        for (g_34 = 0; (g_34 < (-13)); g_34 = safe_sub_func_int64_t_s_s(g_34, 8))
        { /* block id: 49 */
            g_95[1][2][2]++;
            if (g_95[1][2][2])
                break;
            p_81 = (((0x4047L == g_35[0][1]) == (-5L)) || 0x0B00L);
            if (g_95[1][2][2])
                continue;
        }
        for (p_83 = (-2); (p_83 < 26); ++p_83)
        { /* block id: 57 */
            uint8_t l_101 = 0xEBL;
            if (g_34)
                goto lbl_100;
            l_94 = l_101;
        }
        p_81 &= g_95[1][2][2];
        for (p_83 = 0; (p_83 >= 18); ++p_83)
        { /* block id: 64 */
            p_81 ^= (!(g_35[0][7] && l_105[0]));
            l_106 = (-9L);
            p_81 = ((+(safe_lshift_func_int16_t_s_s((+(((0L | 250UL) <= 8UL) , g_35[0][1])), 15))) <= p_83);
        }
    }
    else
    { /* block id: 69 */
        int8_t l_126[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
        int i;
        g_3 = g_95[0][1][0];
        for (p_83 = (-10); (p_83 != 4); p_83++)
        { /* block id: 73 */
            uint8_t l_127 = 246UL;
            if (p_82)
                break;
            g_128 ^= (safe_mul_func_uint8_t_u_u(((safe_div_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(((safe_unary_minus_func_int8_t_s((safe_lshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_add_func_uint8_t_u_u((((g_32 != g_4) < p_82) > l_91), l_126[8])) & 1L), 12)), 5)))) ^ l_127), p_81)), 0xD3L)) < g_3), 0L));
            p_81 = (g_35[0][1] >= 0x13L);
        }
        l_94 = g_34;
    }
    return p_82;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_35[i][j], "g_35[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_95[i][j][k], "g_95[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_138, "g_138", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_209[i][j], "g_209[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 64
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 98
   depth: 2, occurrence: 18
   depth: 3, occurrence: 7
   depth: 4, occurrence: 7
   depth: 5, occurrence: 2
   depth: 6, occurrence: 5
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 142
XXX times a non-volatile is write: 57
XXX times a volatile is read: 18
XXX    times read thru a pointer: 0
XXX times a volatile is write: 9
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 91
XXX percentage of non-volatile access: 88.1

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 93
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 31
   depth: 2, occurrence: 45

XXX percentage a fresh-made variable is used: 27.5
XXX percentage an existing variable is used: 72.5
********************* end of statistics **********************/

