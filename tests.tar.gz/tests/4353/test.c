/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9079801667086838401
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_3[1] = {(-1L)};
static int16_t g_4 = 0x629AL;
static int32_t g_32 = 0x818264D9L;
static uint32_t g_38 = 18446744073709551615UL;
static int16_t g_42 = 0L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_5(uint32_t  p_6, uint64_t  p_7, int32_t  p_8);
static int16_t  func_11(int16_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_32 g_38 g_42
 * writes: g_3 g_4 g_32 g_38 g_42
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_2 = 0x125D16DFL;
    uint16_t l_43 = 0x5476L;
    g_3[0] |= l_2;
    g_4 = (l_2 == 8L);
    g_38 ^= (func_5(((safe_mul_func_int16_t_s_s(func_11((((safe_rshift_func_int8_t_s_u((safe_add_func_uint32_t_u_u((+(safe_sub_func_int8_t_s_s((safe_lshift_func_uint16_t_u_u(l_2, g_4)), g_4))), g_4)), g_3[0])) , l_2) , g_3[0])), 0x50FAL)) > g_4), g_3[0], g_3[0]) && 0x8A1BAB0CL);
    for (g_38 = 0; (g_38 > 57); g_38++)
    { /* block id: 19 */
        int64_t l_41[4];
        int i;
        for (i = 0; i < 4; i++)
            l_41[i] = 0x9A3E2BE8CA404523LL;
        g_42 |= ((1L || 0xF5AB171C2502870BLL) == l_41[2]);
        if (g_42)
            continue;
        if (g_3[0])
            continue;
        l_43 &= 1L;
    }
    return l_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_32
 * writes: g_32
 */
static int32_t  func_5(uint32_t  p_6, uint64_t  p_7, int32_t  p_8)
{ /* block id: 6 */
    uint16_t l_29 = 65535UL;
    if ((((((((safe_mul_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(g_4, p_8)), l_29)) , g_4) , p_8) ^ p_7) , l_29) , p_8) > l_29))
    { /* block id: 7 */
lbl_33:
        g_32 = ((safe_rshift_func_int16_t_s_u(0x7F1BL, p_8)) != 0UL);
        return p_6;
    }
    else
    { /* block id: 10 */
        uint16_t l_34 = 0xB323L;
        int32_t l_37 = 0x017290B1L;
        if (l_29)
            goto lbl_33;
        l_34 = g_3[0];
        l_37 = ((safe_mul_func_int8_t_s_s(p_7, g_32)) || 0xAA9CL);
    }
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_3
 * writes:
 */
static int16_t  func_11(int16_t  p_12)
{ /* block id: 3 */
    uint32_t l_24 = 0xB4DFECBEL;
    l_24 ^= (((safe_mod_func_int64_t_s_s(g_4, 7L)) == g_3[0]) ^ g_4);
    return g_3[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 2
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 9, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 18
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 9

XXX percentage a fresh-made variable is used: 27.3
XXX percentage an existing variable is used: 72.7
********************* end of statistics **********************/

