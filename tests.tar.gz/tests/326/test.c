/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2950235692706074433
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_9 = 0x891F782AL;/* VOLATILE GLOBAL g_9 */
static uint32_t g_10 = 0x29AA810DL;
static int16_t g_19[5] = {0x0E6BL,0x0E6BL,0x0E6BL,0x0E6BL,0x0E6BL};
static volatile int64_t g_54 = (-1L);/* VOLATILE GLOBAL g_54 */
static volatile uint16_t g_59 = 0x27BAL;/* VOLATILE GLOBAL g_59 */
static uint32_t g_72 = 0x3B115E53L;
static int32_t g_74 = (-1L);
static int32_t g_80 = (-7L);
static volatile int8_t g_90 = 0x95L;/* VOLATILE GLOBAL g_90 */
static volatile int16_t g_93[4] = {6L,6L,6L,6L};
static uint64_t g_94 = 0UL;
static uint64_t g_98 = 18446744073709551615UL;
static volatile uint32_t g_104 = 0xF0D5E471L;/* VOLATILE GLOBAL g_104 */
static uint32_t g_109 = 1UL;
static uint64_t g_152[8][3][7] = {{{0xA8EEED4EC5B3E99CLL,18446744073709551615UL,18446744073709551609UL,0x78E06A8B3183DA37LL,18446744073709551609UL,18446744073709551615UL,0xA8EEED4EC5B3E99CLL},{18446744073709551613UL,0xE9EF75D212FF8156LL,2UL,0x326A3C1A26C4C03FLL,18446744073709551615UL,0xF15DF2204A484DF5LL,1UL},{0x24A4583ED9FA1170LL,2UL,18446744073709551615UL,0x13A31308165012FDLL,0xED1463E212FD216ELL,0xE67BC55C7163CAD6LL,0xE67BC55C7163CAD6LL}},{{0xAD79404BF6FAEDB3LL,0x38440B9AA1BD0BA1LL,2UL,0x38440B9AA1BD0BA1LL,0xAD79404BF6FAEDB3LL,0UL,18446744073709551607UL},{9UL,18446744073709551615UL,18446744073709551609UL,0xA8EEED4EC5B3E99CLL,0x78E06A8B3183DA37LL,0UL,0xED1463E212FD216ELL},{0x38440B9AA1BD0BA1LL,0UL,0x06D9094550C6410FLL,0x9E37C7E8E6B6787CLL,18446744073709551607UL,18446744073709551607UL,0x9E37C7E8E6B6787CLL}},{{0xED1463E212FD216ELL,2UL,0xED1463E212FD216ELL,9UL,1UL,0x2D7022298E17D4CALL,0UL},{0x38440B9AA1BD0BA1LL,0x92528784709BD9AFLL,0xE9EF75D212FF8156LL,0x326A3C1A26C4C03FLL,0x9E37C7E8E6B6787CLL,18446744073709551613UL,18446744073709551615UL},{0x0F5FC00A9F045B8BLL,0xED1463E212FD216ELL,0x2D7022298E17D4CALL,18446744073709551609UL,18446744073709551609UL,0x2D7022298E17D4CALL,0xED1463E212FD216ELL}},{{18446744073709551615UL,0xF810095C91DE4319LL,18446744073709551615UL,2UL,0x92528784709BD9AFLL,18446744073709551607UL,0x1ACA1152ABA5E185LL},{2UL,18446744073709551615UL,0xE67BC55C7163CAD6LL,18446744073709551615UL,0UL,0xA8EEED4EC5B3E99CLL,18446744073709551615UL},{0x326A3C1A26C4C03FLL,0UL,2UL,2UL,0UL,0x326A3C1A26C4C03FLL,0UL}},{{0xE67BC55C7163CAD6LL,18446744073709551615UL,0x0F5FC00A9F045B8BLL,18446744073709551609UL,9UL,0xC918E1F83D26D1B1LL,1UL},{0x1ACA1152ABA5E185LL,0x9E37C7E8E6B6787CLL,0xF810095C91DE4319LL,0x326A3C1A26C4C03FLL,0x06D9094550C6410FLL,0UL,0x06D9094550C6410FLL},{9UL,18446744073709551615UL,18446744073709551615UL,9UL,18446744073709551615UL,18446744073709551609UL,0xA8EEED4EC5B3E99CLL}},{{18446744073709551607UL,0UL,0UL,0x9E37C7E8E6B6787CLL,18446744073709551615UL,0xAD79404BF6FAEDB3LL,2UL},{0xC918E1F83D26D1B1LL,18446744073709551615UL,0xA8EEED4EC5B3E99CLL,2UL,0xE67BC55C7163CAD6LL,2UL,0xA8EEED4EC5B3E99CLL},{0xF810095C91DE4319LL,0xF810095C91DE4319LL,18446744073709551613UL,1UL,0xAD79404BF6FAEDB3LL,0UL,0x06D9094550C6410FLL}},{{0x78E06A8B3183DA37LL,0xED1463E212FD216ELL,0x24A4583ED9FA1170LL,18446744073709551615UL,0xC918E1F83D26D1B1LL,18446744073709551615UL,1UL},{0UL,0x92528784709BD9AFLL,0xAD79404BF6FAEDB3LL,0x06D9094550C6410FLL,0xAD79404BF6FAEDB3LL,0x92528784709BD9AFLL,0UL},{18446744073709551615UL,2UL,9UL,0x24A4583ED9FA1170LL,0xE67BC55C7163CAD6LL,1UL,18446744073709551615UL}},{{2UL,0UL,0x38440B9AA1BD0BA1LL,18446744073709551615UL,18446744073709551615UL,0x1ACA1152ABA5E185LL,0x1ACA1152ABA5E185LL},{18446744073709551615UL,0x13A31308165012FDLL,9UL,0x13A31308165012FDLL,18446744073709551615UL,0x78E06A8B3183DA37LL,0xED1463E212FD216ELL},{18446744073709551613UL,1UL,0xAD79404BF6FAEDB3LL,0UL,0x06D9094550C6410FLL,0xE9EF75D212FF8156LL,18446744073709551615UL}}};
static uint32_t g_155 = 0UL;
static volatile uint8_t g_158 = 0x4FL;/* VOLATILE GLOBAL g_158 */
static uint8_t g_163 = 0x46L;
static uint64_t g_170 = 18446744073709551615UL;
static volatile uint8_t g_178 = 0xA5L;/* VOLATILE GLOBAL g_178 */
static uint32_t g_187 = 0x13C66138L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint16_t  func_22(uint8_t  p_23, uint32_t  p_24, int16_t  p_25, const int32_t  p_26);
static int8_t  func_33(uint64_t  p_34, uint8_t  p_35, uint8_t  p_36, int32_t  p_37, const uint64_t  p_38);
static int32_t  func_42(int32_t  p_43);
static uint32_t  func_65(int32_t  p_66);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_10 g_19 g_59 g_74 g_94 g_93 g_98 g_90 g_104 g_109 g_72 g_80 g_152 g_155 g_158 g_170 g_54 g_178 g_187
 * writes: g_19 g_10 g_59 g_72 g_74 g_94 g_98 g_104 g_109 g_152 g_155 g_158 g_163 g_170 g_178 g_187
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_8 = 0x42L;
    int8_t l_18 = (-3L);
    uint32_t l_128[4][4][7] = {{{0xA95BEA92L,0x845370BFL,18446744073709551607UL,0x81BD54BCL,0UL,0x54FA892FL,0x0DAFEA22L},{18446744073709551615UL,18446744073709551615UL,2UL,1UL,5UL,5UL,1UL},{1UL,18446744073709551608UL,1UL,1UL,0x0DAFEA22L,0x0C049AA4L,0xA95BEA92L},{2UL,18446744073709551615UL,18446744073709551615UL,0xD5DAD174L,18446744073709551615UL,18446744073709551615UL,2UL}},{{18446744073709551607UL,0x845370BFL,0xA95BEA92L,18446744073709551615UL,0x0ED61D3EL,0x0C049AA4L,0x0ED61D3EL},{18446744073709551615UL,0x9E070DDBL,0x9E070DDBL,18446744073709551615UL,18446744073709551615UL,5UL,0xD5DAD174L},{0xF6BF143AL,0x6F2EC8A6L,0xA95BEA92L,0x1309CA0AL,1UL,0x54FA892FL,0UL},{18446744073709551615UL,2UL,18446744073709551615UL,1UL,0x9E070DDBL,0xD5DAD174L,0xD5DAD174L}},{{18446744073709551607UL,18446744073709551606UL,1UL,18446744073709551606UL,0xA95BEA92L,0x81BD54BCL,0xE053DA94L},{18446744073709551615UL,18446744073709551615UL,8UL,18446744073709551615UL,5UL,18446744073709551615UL,8UL},{0xE053DA94L,1UL,0x0ED61D3EL,0x845370BFL,18446744073709551607UL,18446744073709551606UL,1UL},{18446744073709551615UL,18446744073709551615UL,0x9E070DDBL,0x9E070DDBL,18446744073709551615UL,18446744073709551615UL,5UL}},{{0xA95BEA92L,0x5DDD0FC4L,18446744073709551612UL,0x6F2EC8A6L,18446744073709551607UL,0x0C049AA4L,0UL},{1UL,1UL,1UL,2UL,5UL,0x10C3079EL,18446744073709551615UL},{18446744073709551612UL,0x5DDD0FC4L,0xA95BEA92L,18446744073709551606UL,0xA95BEA92L,0x5DDD0FC4L,18446744073709551612UL},{0x9E070DDBL,18446744073709551615UL,18446744073709551615UL,5UL,0xD5DAD174L,0x10C3079EL,0xD5DAD174L}}};
    int32_t l_129 = (-5L);
    int32_t l_151 = (-4L);
    uint32_t l_156[1][2];
    int32_t l_171 = 0x097C1867L;
    int64_t l_172[9][6] = {{0x32BFE363783EF79ELL,1L,0x001B998DD83BD61ELL,0xA76550C97FB4A33CLL,0x3546297E8E832C57LL,3L},{9L,(-1L),1L,(-1L),0x635C2736A9738C80LL,0x02434DA7C746F662LL},{9L,0x02434DA7C746F662LL,(-1L),0xA76550C97FB4A33CLL,0L,0x635C2736A9738C80LL},{0x32BFE363783EF79ELL,0x3546297E8E832C57LL,0L,0x3546297E8E832C57LL,0x32BFE363783EF79ELL,1L},{0L,0x001B998DD83BD61ELL,1L,(-1L),0xB2B969A7E2A24FF4LL,0xA216054A38BF424DLL},{0L,1L,(-1L),0x001B998DD83BD61ELL,0L,0xA216054A38BF424DLL},{1L,(-1L),1L,3L,1L,1L},{0L,0L,0L,0L,1L,0x635C2736A9738C80LL},{3L,1L,(-1L),1L,0xA76550C97FB4A33CLL,0x02434DA7C746F662LL}};
    int32_t l_173 = 0x11747086L;
    int32_t l_174 = 0L;
    int32_t l_175 = 0x5E50017FL;
    int32_t l_176 = 0L;
    int32_t l_177 = 0xE7167807L;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_156[i][j] = 0x3C740145L;
    }
    if ((safe_mod_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((safe_div_func_int16_t_s_s(l_8, g_9)), l_8)), g_10)))
    { /* block id: 1 */
        uint64_t l_11[1];
        int32_t l_110 = (-3L);
        int32_t l_116[4];
        uint32_t l_119[3];
        int i;
        for (i = 0; i < 1; i++)
            l_11[i] = 0x1D2250DB85613717LL;
        for (i = 0; i < 4; i++)
            l_116[i] = 0xAFD932BCL;
        for (i = 0; i < 3; i++)
            l_119[i] = 0xCECFDE0DL;
        if (((g_10 , l_8) , l_11[0]))
        { /* block id: 2 */
            uint32_t l_27[5][5][10] = {{{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L}},{{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L}},{{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L}},{{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L}},{{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L},{0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L,0x150FAEB3L}}};
            int32_t l_111 = (-5L);
            int i, j, k;
            g_19[1] = ((safe_mod_func_int32_t_s_s(((safe_mod_func_int64_t_s_s((safe_sub_func_uint32_t_u_u(g_9, 7UL)), g_10)) & g_10), l_11[0])) & l_18);
            g_109 |= (safe_mod_func_uint16_t_u_u(func_22(l_27[0][4][4], g_10, l_18, l_8), l_11[0]));
            l_110 = 0xA4BDFCF0L;
            l_111 ^= g_94;
        }
        else
        { /* block id: 61 */
            g_74 &= ((safe_mul_func_int8_t_s_s(g_19[1], g_93[3])) , l_8);
        }
        for (g_109 = 0; (g_109 <= 3); g_109 += 1)
        { /* block id: 66 */
            int i;
            return g_93[g_109];
        }
        if ((((safe_sub_func_uint16_t_u_u(l_116[1], l_116[1])) ^ g_10) || l_18))
        { /* block id: 69 */
            uint64_t l_122 = 18446744073709551615UL;
            int32_t l_123 = 1L;
            g_74 = g_59;
            l_119[1] = ((safe_rshift_func_int8_t_s_u((l_18 || l_18), g_74)) , l_116[1]);
            l_123 |= ((safe_lshift_func_uint16_t_u_s(g_109, g_90)) & l_122);
            g_74 &= (((safe_lshift_func_int16_t_s_s(0x4F03L, l_18)) || l_116[2]) <= g_10);
        }
        else
        { /* block id: 74 */
            l_129 = ((safe_sub_func_uint8_t_u_u((((((l_8 || g_72) > l_128[0][1][0]) == (-1L)) >= l_116[1]) != l_128[0][1][0]), 0xF7L)) != 0x2FE9L);
        }
    }
    else
    { /* block id: 77 */
        const int32_t l_138 = (-9L);
        int32_t l_139[7] = {1L,1L,1L,1L,1L,1L,1L};
        uint32_t l_147 = 0x719566CBL;
        int i;
        if ((safe_rshift_func_int16_t_s_u((safe_lshift_func_int16_t_s_u(((safe_mod_func_uint16_t_u_u(((((safe_lshift_func_uint8_t_u_u(g_19[3], l_138)) ^ 0x14L) == l_138) != 0xEC11135BL), l_138)) <= l_128[2][0][0]), g_80)), 4)))
        { /* block id: 78 */
            l_139[3] &= 1L;
        }
        else
        { /* block id: 80 */
            return g_90;
        }
        g_74 = g_10;
        if ((safe_mul_func_int8_t_s_s((((g_80 || l_8) > l_18) , 0xA0L), g_19[1])))
        { /* block id: 84 */
            uint64_t l_148 = 18446744073709551615UL;
            volatile int32_t l_149 = 0xDEA466ACL;/* VOLATILE GLOBAL l_149 */
            int32_t l_150 = 0xC1622462L;
            l_149 = (((((((safe_mod_func_uint32_t_u_u((((safe_sub_func_uint32_t_u_u(((+l_147) & l_129), g_19[1])) > g_59) & l_129), g_98)) < g_94) | g_94) && g_93[3]) | l_148) <= l_18) , g_93[1]);
            ++g_152[5][2][1];
            return l_151;
        }
        else
        { /* block id: 88 */
            g_155 = (((0UL ^ l_138) , g_94) & (-7L));
            return g_59;
        }
    }
    for (g_74 = 2; (g_74 >= 0); g_74 -= 1)
    { /* block id: 95 */
        uint64_t l_165 = 0UL;
        if ((g_155 == l_156[0][0]))
        { /* block id: 96 */
            int64_t l_157[10] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
            int i;
            if (l_157[1])
                break;
            return l_157[9];
        }
        else
        { /* block id: 99 */
            --g_158;
        }
        for (l_129 = 0; (l_129 <= 3); l_129 += 1)
        { /* block id: 104 */
            int32_t l_164 = (-7L);
            g_163 = (((safe_rshift_func_int8_t_s_s(((0x0DL > 255UL) || g_59), g_152[2][1][3])) || 0x2D0EFE05FA8ED5CDLL) ^ l_128[1][3][0]);
            if (l_164)
                break;
        }
        if (l_165)
            break;
        if (((safe_mul_func_int16_t_s_s(((((safe_rshift_func_uint8_t_u_u((0xD1DEL ^ g_93[3]), g_152[5][0][1])) | 1UL) & l_129) | g_98), g_152[1][0][3])) , 0xE0119A80L))
        { /* block id: 109 */
            g_170 &= (0x56EE47DEF404FB78LL || (-8L));
        }
        else
        { /* block id: 111 */
            if (l_151)
                break;
            if (g_98)
                continue;
            return l_156[0][0];
        }
        for (l_129 = 0; (l_129 <= 4); l_129 += 1)
        { /* block id: 118 */
            return g_54;
        }
    }
    g_178--;
    for (l_171 = 26; (l_171 >= (-13)); --l_171)
    { /* block id: 125 */
        for (l_18 = 17; (l_18 < 5); --l_18)
        { /* block id: 128 */
            uint16_t l_185 = 5UL;
            int32_t l_186 = (-5L);
            l_186 = l_185;
            g_187++;
            return l_171;
        }
    }
    return l_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_19 g_59 g_9 g_74 g_94 g_93 g_98 g_90 g_104
 * writes: g_10 g_19 g_59 g_72 g_74 g_94 g_98 g_104
 */
static uint16_t  func_22(uint8_t  p_23, uint32_t  p_24, int16_t  p_25, const int32_t  p_26)
{ /* block id: 4 */
    int32_t l_30 = 0x23CEA2FFL;
    uint32_t l_39 = 4294967292UL;
    int32_t l_108 = (-4L);
    for (g_10 = 0; (g_10 > 50); ++g_10)
    { /* block id: 7 */
        l_30 = ((((-4L) == 0xEDB6B7BEL) || p_25) & 18446744073709551615UL);
        if (p_24)
            break;
    }
    for (p_24 = 0; p_24 < 5; p_24 += 1)
    {
        g_19[p_24] = (-2L);
    }
    l_108 = (safe_div_func_int8_t_s_s(func_33(l_30, l_30, l_39, l_30, l_39), p_24));
    return l_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_19 g_59 g_9 g_74 g_94 g_93 g_98 g_90 g_104
 * writes: g_10 g_59 g_72 g_74 g_94 g_98 g_104
 */
static int8_t  func_33(uint64_t  p_34, uint8_t  p_35, uint8_t  p_36, int32_t  p_37, const uint64_t  p_38)
{ /* block id: 12 */
    int32_t l_107 = 0x71C77DD3L;
    for (g_10 = 0; (g_10 <= 4); g_10 += 1)
    { /* block id: 15 */
        uint32_t l_101 = 0x70066BE3L;
        for (p_34 = 0; (p_34 <= 4); p_34 += 1)
        { /* block id: 18 */
            int i;
            g_98 &= ((safe_mul_func_int32_t_s_s(func_42(((-6L) != 0xF88592840CC74BF7LL)), 0UL)) , g_19[g_10]);
            p_37 = (safe_add_func_uint8_t_u_u((g_90 && g_19[g_10]), p_35));
            l_101++;
        }
    }
    g_104++;
    g_74 = (l_107 , 0xB2A6A610L);
    return g_104;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_59 g_9 g_10 g_74 g_94 g_93
 * writes: g_59 g_72 g_74 g_94
 */
static int32_t  func_42(int32_t  p_43)
{ /* block id: 19 */
    int8_t l_44 = 0xE8L;
    int32_t l_45 = 0L;
    int32_t l_46 = (-8L);
    int32_t l_53 = (-1L);
    int32_t l_55 = 6L;
    int32_t l_58 = 1L;
    l_44 &= (-7L);
    if ((0x5AB171C2502870B1LL | 18446744073709551615UL))
    { /* block id: 21 */
        uint16_t l_47 = 0xCE33L;
        int32_t l_52 = 1L;
        uint32_t l_75 = 0xEC3887D1L;
        l_47--;
        for (l_45 = 0; (l_45 <= 4); l_45 += 1)
        { /* block id: 25 */
            int32_t l_50 = 0xA4206971L;
            int32_t l_51 = 0x2FDDD0C6L;
            int32_t l_56 = 0xD99275A8L;
            int32_t l_57[8][4] = {{0xA861D8D4L,4L,0x81F04FECL,0x81F04FECL},{0x76A10B91L,0x76A10B91L,0xA861D8D4L,0x81F04FECL},{0x81F04FECL,0x76A10B91L,0x81F04FECL,0x85C3B363L},{0x81F04FECL,0x85C3B363L,0x85C3B363L,0x81F04FECL},{0xA861D8D4L,0x85C3B363L,4L,0x85C3B363L},{0x85C3B363L,0x76A10B91L,4L,4L},{0xA861D8D4L,0xA861D8D4L,0x85C3B363L,4L},{0x81F04FECL,0x76A10B91L,0x81F04FECL,0x85C3B363L}};
            int i, j;
            if (g_19[l_45])
                break;
            g_59--;
            l_52 |= (((safe_mod_func_int16_t_s_s((~((((func_65((safe_mul_func_int16_t_s_s((g_19[1] < g_9), 1L))) ^ g_19[1]) , g_74) ^ 0x410AL) , g_59)), l_75)) > l_45) & p_43);
        }
    }
    else
    { /* block id: 36 */
        int8_t l_76 = 0x7CL;
        int32_t l_77 = 0x3F190218L;
        int32_t l_78 = 0x08E63FEEL;
        int32_t l_79 = 5L;
        int32_t l_81 = 0x43B3BE7BL;
        int32_t l_82 = 3L;
        uint8_t l_83 = 8UL;
        uint32_t l_97 = 0xF6A774B6L;
        --l_83;
        for (l_77 = 3; (l_77 >= 0); l_77 -= 1)
        { /* block id: 40 */
            int32_t l_89 = (-1L);
            int32_t l_91 = 1L;
            int32_t l_92[10] = {0x88FCBDC2L,0L,0L,0x88FCBDC2L,0L,0x88FCBDC2L,0L,0L,0x88FCBDC2L,0L};
            int i;
            l_89 = (+(safe_lshift_func_uint16_t_u_s(g_19[(l_77 + 1)], p_43)));
            ++g_94;
            if (l_97)
                continue;
        }
    }
    l_46 ^= ((p_43 && 0UL) | g_93[3]);
    return l_53;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_19 g_59 g_74
 * writes: g_72 g_74
 */
static uint32_t  func_65(int32_t  p_66)
{ /* block id: 28 */
    uint64_t l_69[3];
    int32_t l_73 = 0xF870A655L;
    int i;
    for (i = 0; i < 3; i++)
        l_69[i] = 0xFAE2361AE7D51263LL;
    l_69[2] = g_10;
    g_72 = ((safe_rshift_func_int16_t_s_s(((p_66 || g_19[1]) > 0L), 9)) | g_59);
    l_73 = (g_10 && p_66);
    g_74 |= g_10;
    return g_19[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_93[i], "g_93[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_109, "g_109", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_152[i][j][k], "g_152[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_187, "g_187", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 84
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 81
   depth: 2, occurrence: 17
   depth: 3, occurrence: 5
   depth: 4, occurrence: 6
   depth: 5, occurrence: 3
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 120
XXX times a non-volatile is write: 46
XXX times a volatile is read: 20
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 85
XXX percentage of non-volatile access: 86.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 81
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 22
   depth: 1, occurrence: 19
   depth: 2, occurrence: 40

XXX percentage a fresh-made variable is used: 37.7
XXX percentage an existing variable is used: 62.3
********************* end of statistics **********************/

