/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3565998927041335153
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_5 = 0x1739L;
static uint32_t g_7 = 0x28EA3888L;
static volatile uint64_t g_10 = 18446744073709551612UL;/* VOLATILE GLOBAL g_10 */
static volatile int8_t g_18 = (-10L);/* VOLATILE GLOBAL g_18 */
static int32_t g_19 = 6L;
static uint32_t g_22 = 4294967286UL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(uint32_t  p_3);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_10 g_22
 * writes: g_7 g_10 g_22
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_4[5] = {4UL,4UL,4UL,4UL,4UL};
    int32_t l_13 = 0x52F34111L;
    int32_t l_20 = 0xD2CC9105L;
    int32_t l_21[6] = {0x361A6B71L,0x361A6B71L,0x361A6B71L,0x361A6B71L,0x361A6B71L,0x361A6B71L};
    int i;
    if (func_2(l_4[4]))
    { /* block id: 5 */
        uint16_t l_14 = 0xE1E0L;
        ++g_10;
        l_14++;
    }
    else
    { /* block id: 8 */
        uint64_t l_17 = 18446744073709551608UL;
        return l_17;
    }
    --g_22;
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_7
 * writes: g_7
 */
static int32_t  func_2(uint32_t  p_3)
{ /* block id: 1 */
    int32_t l_6 = 6L;
    l_6 = g_5;
    g_7++;
    return p_3;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 13
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 5
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 90

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 9
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 81.2
XXX percentage an existing variable is used: 18.8
********************* end of statistics **********************/

