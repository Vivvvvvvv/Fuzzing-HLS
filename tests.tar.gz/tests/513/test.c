/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6094568561634371933
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint64_t g_2 = 0x837BC75286E871D9LL;/* VOLATILE GLOBAL g_2 */
static const int64_t g_10 = 0L;
static int8_t g_14 = 1L;
static uint32_t g_21 = 0xA0E1C2A9L;
static volatile uint32_t g_24 = 0xA7AD11E7L;/* VOLATILE GLOBAL g_24 */
static int8_t g_27 = 0L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_10 g_24
 * writes: g_14 g_21 g_24 g_27
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_4[9][9] = {{0x060DL,7L,1L,(-4L),1L,7L,0x060DL,8L,0xC427L},{0L,0x01E6L,(-1L),0L,1L,4L,1L,0L,(-1L)},{(-4L),(-4L),0x80BEL,0xAEB5L,0xC427L,1L,7L,8L,7L},{(-1L),0L,0x01E6L,0x01E6L,0L,(-1L),4L,1L,5L},{8L,0x3E7EL,0x80BEL,1L,0x060DL,0x060DL,1L,0x80BEL,0x3E7EL},{0L,0x6F18L,(-1L),0x01E6L,1L,(-2L),0L,0L,(-2L)},{1L,7L,8L,7L,1L,0xC427L,0xAEB5L,0x80BEL,(-4L)},{4L,0x6F18L,0x01E6L,4L,0L,4L,0x01E6L,0x6F18L,4L},{0x3E7EL,1L,1L,1L,0x80BEL,0xC427L,1L,0xC427L,0x80BEL}};
    int32_t l_23 = 0x2B782624L;
    int i, j;
    if ((0x039B642CL <= g_2))
    { /* block id: 1 */
        int32_t l_3 = 0x67E307B5L;
        uint64_t l_16 = 0UL;
        l_3 = 0x00FE1CA2L;
lbl_15:
        for (l_3 = 1; (l_3 <= 8); l_3 += 1)
        { /* block id: 5 */
            uint32_t l_5 = 4294967295UL;
            int32_t l_11[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i;
            --l_5;
            l_11[4] = (safe_rshift_func_uint8_t_u_u((g_2 | g_10), 2));
        }
        if ((safe_mul_func_int16_t_s_s((l_4[2][6] & 0x785734CB441791E6LL), g_2)))
        { /* block id: 9 */
            g_14 = (l_4[1][3] , 0x5F4B3F4BL);
        }
        else
        { /* block id: 11 */
            if (l_3)
                goto lbl_15;
            l_16 = 0x1A812C00L;
        }
        g_21 = (safe_lshift_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_s(65535UL, 10)) | 0UL), 3));
    }
    else
    { /* block id: 16 */
        uint32_t l_22 = 4294967295UL;
        l_23 ^= l_22;
        --g_24;
    }
    g_27 = 0x83DE37D6L;
    return l_23;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 6
XXX times a non-volatile is write: 9
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 78.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 6
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 66.7
XXX percentage an existing variable is used: 33.3
********************* end of statistics **********************/

