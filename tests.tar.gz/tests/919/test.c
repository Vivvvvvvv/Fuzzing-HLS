/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13850666272775110407
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_5 = 0x38462751L;
static uint32_t g_7 = 0x215E1ABEL;
static int32_t g_16 = (-7L);


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_16
 * writes: g_7
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_6 = 0x8E1BL;
    int8_t l_10 = 0L;
    int32_t l_11[4][9] = {{0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L},{0xE6BC044BL,8L,0xE6BC044BL,8L,0xE6BC044BL,8L,0xE6BC044BL,8L,0xE6BC044BL},{0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L,0x22515546L},{0xE6BC044BL,8L,0xE6BC044BL,8L,0xE6BC044BL,8L,0xE6BC044BL,8L,0xE6BC044BL}};
    int i, j;
    g_7 = (safe_div_func_int16_t_s_s(((((!g_5) != g_5) >= 0x7EL) , l_6), g_5));
    l_11[0][3] ^= (((safe_rshift_func_uint16_t_u_s(g_5, l_6)) , l_10) ^ g_5);
    l_11[0][3] = (safe_mul_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(l_11[3][1], l_10)) >= g_7), g_16));
    return l_6;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 6
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 3
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 4
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 4

XXX percentage a fresh-made variable is used: 37.5
XXX percentage an existing variable is used: 62.5
********************* end of statistics **********************/

