/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15891764615792209280
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 1L;/* VOLATILE GLOBAL g_3 */
static int8_t g_6[10][6][4] = {{{9L,(-10L),0xC6L,(-1L)},{0L,0x4DL,0x10L,0x41L},{(-4L),0xD9L,(-7L),0x1BL},{(-7L),0x1BL,0x1BL,(-7L)},{(-1L),0xD3L,0x41L,0x10L},{9L,1L,(-1L),0xC6L}},{{9L,0x4DL,6L,0xC6L},{(-6L),1L,(-7L),0x10L},{0xC4L,0xD3L,9L,(-7L)},{0x4DL,0x1BL,7L,0x1BL},{9L,0xD9L,1L,0x41L},{0x9EL,0x4DL,(-4L),0x4AL}},{{1L,9L,0xC6L,0xC4L},{1L,(-6L),(-4L),0xC6L},{0x1BL,0xC4L,1L,0L},{0L,0x4DL,0x14L,0x14L},{9L,9L,0L,1L},{(-1L),0x9EL,0xC6L,(-4L)}},{{7L,0L,0xC4L,0xC6L},{0x10L,0L,0x4AL,(-4L)},{0L,0x9EL,(-10L),1L},{0xD3L,9L,(-7L),0x14L},{0xC6L,0x4DL,0xC6L,0L},{0x41L,0xC4L,(-6L),0xC6L}},{{6L,(-6L),0xD9L,0xC4L},{0L,9L,0xD9L,0x4AL},{6L,9L,(-6L),(-10L)},{0x41L,(-1L),0xC6L,(-7L)},{0xC6L,(-7L),(-7L),0xC6L},{0xD3L,(-4L),(-10L),(-6L)}},{{0L,0L,0x4AL,0xD9L},{0x10L,9L,0xC4L,0xD9L},{7L,0L,0xC6L,(-6L)},{(-1L),(-4L),0L,0xC6L},{9L,(-7L),0x14L,(-7L)},{0L,(-1L),1L,(-10L)}},{{0x1BL,9L,(-4L),0x4AL},{1L,9L,0xC6L,0xC4L},{1L,(-6L),(-4L),0xC6L},{0x1BL,0xC4L,1L,0L},{0L,0x4DL,0x14L,0x14L},{9L,9L,0L,1L}},{{(-1L),0x9EL,0xC6L,(-4L)},{7L,0L,0xC4L,0xC6L},{0x10L,0L,0x4AL,(-4L)},{0L,0x9EL,(-10L),1L},{0xD3L,9L,(-7L),0x14L},{0xC6L,0x4DL,0xC6L,0L}},{{0x41L,0xC4L,(-6L),0xC6L},{6L,(-6L),0xD9L,0xC4L},{0L,9L,0xD9L,0x4AL},{6L,9L,(-6L),(-10L)},{0x41L,(-1L),0xC6L,(-7L)},{0xC6L,(-7L),(-7L),0xC6L}},{{0xD3L,(-4L),(-10L),(-6L)},{0L,0L,0x4AL,0xD9L},{0x10L,9L,0xC4L,0xD9L},{7L,0L,0xC6L,(-6L)},{(-1L),(-4L),0L,0xC6L},{9L,0xC6L,0x4DL,0xC6L}}};
static const int64_t g_25 = 0x93F8DE905F4D0C65LL;
static volatile int32_t g_26 = 0xED761E7FL;/* VOLATILE GLOBAL g_26 */
static volatile int32_t g_27[3][8][7] = {{{0x231D5762L,0xADAF8D98L,0x3236C217L,0xF9491450L,0x265D6326L,1L,(-10L)},{5L,0xB047C147L,(-10L),1L,0x265D6326L,0xF9491450L,0x3236C217L},{0xB047C147L,5L,0xC684CA67L,(-1L),0x265D6326L,(-9L),0L},{0xADAF8D98L,0x231D5762L,1L,0xA4122E7DL,0x265D6326L,0x3B7DC4B5L,1L},{0xFAFECEB2L,6L,(-1L),0x64BFCE93L,0x265D6326L,0x64BFCE93L,(-1L)},{(-1L),(-1L),1L,0x3B7DC4B5L,0x265D6326L,0xA4122E7DL,1L},{6L,0xFAFECEB2L,0L,(-9L),0x265D6326L,(-1L),0xC684CA67L},{0x231D5762L,0xADAF8D98L,0x3236C217L,0xF9491450L,0x265D6326L,1L,(-10L)}},{{5L,0xB047C147L,(-10L),1L,0x265D6326L,0xF9491450L,0x3236C217L},{0xB047C147L,5L,0xC684CA67L,(-1L),0x265D6326L,(-9L),0L},{0xADAF8D98L,0x231D5762L,1L,0xA4122E7DL,0x265D6326L,0x3B7DC4B5L,1L},{0xFAFECEB2L,6L,(-1L),0x64BFCE93L,0x265D6326L,0x64BFCE93L,(-1L)},{(-1L),(-1L),1L,0x3B7DC4B5L,0x265D6326L,0xA4122E7DL,1L},{6L,0xFAFECEB2L,0L,(-9L),0x265D6326L,(-1L),0xC684CA67L},{0x231D5762L,0xADAF8D98L,0x3236C217L,0xF9491450L,0x265D6326L,1L,(-10L)},{5L,0xB047C147L,(-10L),1L,0x265D6326L,0xF9491450L,0x3236C217L}},{{0xB047C147L,5L,0xC684CA67L,(-1L),0x265D6326L,(-9L),0L},{0xADAF8D98L,0x231D5762L,1L,0xA4122E7DL,0x265D6326L,0x3B7DC4B5L,1L},{0xFAFECEB2L,6L,(-1L),0x64BFCE93L,0x265D6326L,0x64BFCE93L,(-1L)},{(-1L),(-1L),1L,0x3B7DC4B5L,0x265D6326L,0xA4122E7DL,1L},{6L,0xFAFECEB2L,0L,(-9L),0x265D6326L,(-1L),0xC684CA67L},{0x231D5762L,0xADAF8D98L,0x3236C217L,0xF9491450L,0x265D6326L,1L,(-10L)},{5L,0xB047C147L,(-10L),1L,0x265D6326L,0xF9491450L,0x3236C217L},{0xB047C147L,5L,0xC684CA67L,(-1L),0x265D6326L,(-9L),0L}}};
static int32_t g_28 = 0xC7E1EFC3L;
static uint8_t g_132 = 8UL;
static uint16_t g_151 = 0xFD11L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static const int32_t  func_22(const uint64_t  p_23, uint32_t  p_24);
static int32_t  func_48(int32_t  p_49, uint64_t  p_50);
static uint8_t  func_59(uint32_t  p_60, int32_t  p_61, uint16_t  p_62, const uint8_t  p_63, int8_t  p_64);
static const uint16_t  func_65(int16_t  p_66);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_25 g_28 g_27 g_26 g_132 g_151
 * writes: g_3 g_28 g_27 g_132 g_151 g_26
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = (-1L);
    int32_t l_4 = 7L;
    int16_t l_183 = (-10L);
    if (l_2)
    { /* block id: 1 */
        uint8_t l_5 = 0UL;
        l_4 ^= ((g_3 > l_2) , l_2);
        l_5 = l_4;
    }
    else
    { /* block id: 4 */
        int16_t l_21[1];
        int i;
        for (i = 0; i < 1; i++)
            l_21[i] = 0L;
        for (l_2 = 0; (l_2 <= 3); l_2 += 1)
        { /* block id: 7 */
            int8_t l_20 = 2L;
            g_3 = (safe_div_func_int32_t_s_s(((safe_add_func_uint64_t_u_u((safe_rshift_func_int8_t_s_u(((~(((safe_div_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s(l_20, l_20)), 1UL)) ^ 0x8CL), (-1L))) || 65535UL) > g_3)) , g_6[5][4][1]), 3)), l_21[0])) <= g_6[0][3][1]), g_6[1][4][2]));
            g_3 = (((0xC93846F2633933B8LL | 5L) <= l_20) != 65535UL);
            g_3 = func_22(g_25, l_2);
            g_26 = (((0x0814L < (-5L)) ^ l_21[0]) || g_151);
        }
        g_27[2][2][3] = ((+(l_21[0] , l_183)) , g_3);
    }
    return g_6[8][2][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_3 g_6 g_25 g_27 g_26 g_132 g_151
 * writes: g_28 g_27 g_132 g_151 g_26
 */
static const int32_t  func_22(const uint64_t  p_23, uint32_t  p_24)
{ /* block id: 10 */
    int32_t l_47[1][1];
    int32_t l_141 = 0xEB179A86L;
    int32_t l_144 = 0xA6757B94L;
    int32_t l_148 = 0xC000487FL;
    uint64_t l_181 = 0x03B0C7BE276FF74ALL;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_47[i][j] = 0x1CC5CA36L;
    }
    for (p_24 = 0; (p_24 <= 3); p_24 += 1)
    { /* block id: 13 */
        uint64_t l_30 = 0x5BDF5444FE378062LL;
        for (g_28 = 3; (g_28 >= 0); g_28 -= 1)
        { /* block id: 16 */
            int64_t l_29[7][1] = {{0xED6CA138DBEC8B24LL},{0x4446CA37EAD942A2LL},{0xED6CA138DBEC8B24LL},{0x4446CA37EAD942A2LL},{0xED6CA138DBEC8B24LL},{0x4446CA37EAD942A2LL},{0xED6CA138DBEC8B24LL}};
            int i, j;
            ++l_30;
            return g_3;
        }
        return l_30;
    }
    for (g_28 = 2; (g_28 >= 0); g_28 -= 1)
    { /* block id: 24 */
        int32_t l_34 = (-1L);
        uint16_t l_35 = 65535UL;
        uint32_t l_46 = 0x61810894L;
        int32_t l_145 = 0L;
        int32_t l_146 = (-8L);
        int32_t l_149 = (-1L);
        int32_t l_150[1];
        uint32_t l_170[8] = {0x69BDC768L,0x69BDC768L,18446744073709551611UL,0x69BDC768L,0x69BDC768L,18446744073709551611UL,0x69BDC768L,0x69BDC768L};
        int i;
        for (i = 0; i < 1; i++)
            l_150[i] = 0xF440EA31L;
        for (p_24 = 0; (p_24 <= 2); p_24 += 1)
        { /* block id: 27 */
            l_34 ^= (~g_28);
            if (l_35)
                break;
            l_47[0][0] = (safe_rshift_func_int8_t_s_u((safe_rshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u((safe_mul_func_int16_t_s_s((safe_lshift_func_int8_t_s_s(g_6[9][3][2], l_46)), p_24)), g_25)), 14)), g_27[2][2][3]));
        }
        if (func_48(((safe_sub_func_int8_t_s_s((safe_rshift_func_int16_t_s_s((65527UL > (-1L)), 12)), p_23)) , p_24), g_25))
        { /* block id: 75 */
            int64_t l_135[6] = {1L,0L,1L,1L,1L,0L};
            int32_t l_136 = 0x2E85F590L;
            int32_t l_137 = 0x1AF41016L;
            int8_t l_138 = (-1L);
            int32_t l_139 = 0x1F7435F2L;
            int32_t l_140 = 0x16177B4BL;
            int32_t l_142 = 0L;
            int32_t l_143 = 0x839C7493L;
            int32_t l_147[4];
            int i;
            for (i = 0; i < 4; i++)
                l_147[i] = 1L;
            g_151++;
            if (p_24)
                break;
            l_149 ^= (((safe_rshift_func_uint8_t_u_u(l_47[0][0], l_47[0][0])) != p_24) , 0x608D486CL);
            g_26 = (safe_div_func_int64_t_s_s(((safe_div_func_int32_t_s_s(((safe_sub_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((8UL || 0xD913FAE4BFFE4561LL), 0xBCC1L)), p_23)) | 0x28DE542F5EF4C97ALL), l_147[1])) , g_28), 0xFD788535DF793C26LL));
        }
        else
        { /* block id: 80 */
            l_170[7] = (safe_mul_func_int16_t_s_s((((safe_lshift_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u(l_141, p_24)) >= 0x3AE872CBL), 3)) | p_24) & 0xEA7A1799D2B88D7CLL), 9L));
            if (p_23)
                break;
        }
        for (l_46 = 0; (l_46 <= 2); l_46 += 1)
        { /* block id: 86 */
            g_26 ^= ((~(safe_lshift_func_uint8_t_u_u((p_24 , p_24), 5))) && g_151);
            g_26 = (!(safe_add_func_uint8_t_u_u(0xCAL, p_24)));
            l_146 = ((-1L) > g_151);
            if (p_23)
                continue;
        }
    }
    if ((safe_mod_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u(p_23, p_24)) <= l_148), l_144)))
    { /* block id: 93 */
        l_181 = (-2L);
    }
    else
    { /* block id: 95 */
        return l_148;
    }
    return l_141;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_26 g_6 g_3 g_27 g_28 g_132
 * writes: g_27 g_132
 */
static int32_t  func_48(int32_t  p_49, uint64_t  p_50)
{ /* block id: 32 */
    uint32_t l_119 = 0xABECF346L;
    uint16_t l_120 = 0UL;
    int32_t l_122 = 0x9FCAAD6EL;
    int32_t l_123 = 0xC420A7EEL;
    int32_t l_124 = 0xC837B64FL;
    int32_t l_125 = 0xE8ABCB01L;
    int32_t l_126 = 5L;
    int32_t l_127 = (-1L);
    int8_t l_128 = 0x3EL;
    int32_t l_129 = 0L;
    int32_t l_130 = 0x2AD0072BL;
    int32_t l_131[9] = {0xD0A0F2B4L,0x313BC257L,0xD0A0F2B4L,0xD0A0F2B4L,0x313BC257L,0xD0A0F2B4L,0xD0A0F2B4L,0x313BC257L,0xD0A0F2B4L};
    int i;
    for (p_50 = 0; (p_50 < 36); p_50++)
    { /* block id: 35 */
        int8_t l_101 = 1L;
        int32_t l_109[5];
        const int32_t l_121 = 0xFE2E2A71L;
        int i;
        for (i = 0; i < 5; i++)
            l_109[i] = 9L;
        for (p_49 = (-2); (p_49 > 10); ++p_49)
        { /* block id: 38 */
            uint32_t l_108 = 0x2D68B998L;
            l_101 = (func_59(g_25, g_26, p_50, g_6[0][4][3], g_6[8][0][2]) , g_28);
            l_109[3] = (safe_add_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((safe_mod_func_int64_t_s_s(g_3, l_108)), p_50)) >= p_49), p_50));
        }
        for (l_101 = 16; (l_101 != 4); l_101--)
        { /* block id: 66 */
            g_27[2][2][3] &= (safe_unary_minus_func_int16_t_s((0xA7C04A76FC58545DLL < p_49)));
            l_109[3] |= ((safe_mod_func_int64_t_s_s(((((((safe_rshift_func_int8_t_s_s((((((safe_add_func_uint16_t_u_u(0x915BL, l_119)) | 0UL) & 0xD6E8L) != p_50) , g_3), l_119)) ^ p_49) , 0L) ^ g_6[7][1][1]) && l_119) < l_120), l_121)) & g_25);
        }
        if (p_49)
            break;
    }
    l_122 = 0x6ED31E0CL;
    ++g_132;
    return p_49;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_3 g_27 g_28
 * writes: g_27
 */
static uint8_t  func_59(uint32_t  p_60, int32_t  p_61, uint16_t  p_62, const uint8_t  p_63, int8_t  p_64)
{ /* block id: 39 */
    uint32_t l_81 = 18446744073709551612UL;
    int32_t l_100[2][5][7] = {{{1L,(-1L),1L,2L,2L,1L,(-1L)},{2L,(-1L),(-1L),(-1L),(-1L),2L,(-1L)},{1L,2L,2L,1L,(-1L),1L,2L},{(-9L),(-9L),2L,(-1L),2L,(-9L),(-9L)},{(-9L),2L,(-1L),2L,(-9L),(-9L),2L}},{{1L,(-1L),1L,2L,2L,1L,(-1L)},{2L,(-1L),(-1L),(-1L),(-1L),2L,(-1L)},{1L,2L,2L,1L,(-1L),1L,2L},{(-9L),(-9L),2L,(-1L),2L,(-9L),(-9L)},{(-9L),2L,(-1L),2L,(-9L),(-9L),2L}}};
    int i, j, k;
    for (p_60 = 0; (p_60 <= 3); p_60 += 1)
    { /* block id: 42 */
        uint64_t l_82 = 18446744073709551613UL;
        if ((func_65(g_6[9][0][0]) , g_27[1][0][3]))
        { /* block id: 47 */
            g_27[2][2][3] ^= (((l_81 || l_82) , g_28) > l_81);
        }
        else
        { /* block id: 49 */
            uint16_t l_93 = 7UL;
            int32_t l_94[4][4][5] = {{{0xE2574B05L,0xDA5914D9L,(-1L),(-3L),(-1L)},{(-1L),(-1L),0xEC4757C6L,0x35580C9BL,0L},{(-1L),1L,0L,0xEA379FF8L,1L},{0xE2574B05L,3L,(-1L),(-4L),0x34C0AFD8L}},{{(-10L),1L,1L,(-10L),(-1L)},{0xE2A20AB3L,(-1L),1L,0L,0xEA379FF8L},{0L,0xDA5914D9L,(-1L),0xE2574B05L,1L},{3L,0xE2A20AB3L,0L,0L,0xE2A20AB3L}},{{1L,(-3L),0xEC4757C6L,(-10L),0xE2A20AB3L},{0xDA5914D9L,0x34C0AFD8L,(-1L),(-4L),1L},{(-3L),(-4L),0x35580C9BL,0xEA379FF8L,0xEA379FF8L},{0xDA5914D9L,0xEC4757C6L,0xDA5914D9L,0x35580C9BL,(-1L)}},{{1L,0xEC4757C6L,0xE2574B05L,(-3L),0x34C0AFD8L},{3L,(-4L),0xEA379FF8L,(-1L),1L},{0L,0x34C0AFD8L,0xE2574B05L,0x34C0AFD8L,0L},{0xE2A20AB3L,(-3L),0xDA5914D9L,0x34C0AFD8L,(-1L)}}};
            int32_t l_97 = (-8L);
            int i, j, k;
            l_94[3][1][2] &= ((safe_add_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u((safe_add_func_int8_t_s_s(((((((safe_mod_func_int16_t_s_s(((safe_div_func_int64_t_s_s(((-4L) > l_81), 0x3F23DC045D86B466LL)) && l_81), p_61)) != l_93) == 0x32CE8EB2L) >= p_60) && p_64) != 0x11EE9290L), p_60)), 1L)) >= g_27[2][1][6]), g_28)) < 0xAD6F16DAB5352CA7LL);
            l_97 &= ((safe_div_func_int32_t_s_s(l_94[3][1][2], g_6[1][2][3])) == 0x4C9D4284L);
            g_27[2][2][3] = (g_27[0][7][2] < p_62);
        }
        for (l_81 = 0; (l_81 <= 3); l_81 += 1)
        { /* block id: 56 */
            l_100[1][0][5] &= (((safe_sub_func_int8_t_s_s(l_81, p_64)) > 0L) < 0UL);
        }
    }
    return p_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static const uint16_t  func_65(int16_t  p_66)
{ /* block id: 43 */
    int8_t l_67 = 1L;
    int32_t l_68 = (-5L);
    int32_t l_69 = 0xDC3D349FL;
    int32_t l_70 = (-1L);
    int32_t l_71 = 0L;
    int32_t l_72 = 0x29C5D079L;
    int32_t l_73[10];
    int8_t l_74[5][10][5] = {{{8L,0xEFL,0xA4L,0xB4L,0xDBL},{(-1L),0x71L,5L,6L,6L},{(-1L),0xACL,(-1L),(-1L),(-9L)},{(-1L),0xBBL,8L,0x52L,(-1L)},{(-1L),0x16L,0L,0xF6L,0x5AL},{0L,0x30L,8L,(-1L),0L},{0xFCL,0L,(-8L),3L,(-3L)},{(-5L),0L,0x5AL,(-1L),0L},{7L,1L,0x2CL,0x79L,(-1L)},{0xBBL,0xC8L,0xE5L,(-3L),0x25L}},{{0L,(-1L),0xF6L,(-3L),3L},{1L,4L,0x9FL,0x52L,0xB7L},{6L,0xBAL,0L,0x1DL,0x71L},{0x48L,(-3L),1L,0xFCL,(-1L)},{0L,(-1L),0x87L,(-8L),(-3L)},{0L,0xACL,5L,0L,0xE5L},{0x48L,(-5L),0xACL,1L,0L},{6L,0L,0xBAL,0L,0x2CL},{1L,0xF6L,(-1L),0x7CL,0L},{0L,(-8L),0x8BL,1L,4L}},{{0xBBL,1L,0xE7L,1L,1L},{7L,0xA4L,0x92L,0xC8L,0x16L},{(-5L),0xFCL,0xFCL,(-5L),1L},{0xFCL,8L,0xEEL,0xB4L,0L},{3L,0xEFL,0xC4L,0xDCL,0L},{0x30L,6L,0x7CL,0xB4L,0x48L},{1L,0xA6L,0xBBL,(-5L),0L},{(-8L),3L,(-3L),0xC8L,1L},{(-8L),0x71L,0L,1L,0L},{0xEEL,0xC4L,3L,1L,1L}},{{(-1L),0x92L,0L,0x7CL,8L},{3L,0L,3L,0L,1L},{3L,0xB7L,0x9BL,1L,0x7CL},{8L,0x52L,(-8L),0L,0x41L},{1L,(-7L),7L,(-8L),(-7L)},{0x33L,(-7L),0x48L,0xFCL,1L},{0x25L,0x52L,0x41L,0x1DL,0xEEL},{0xE8L,0xB7L,0L,0x52L,0xACL},{0xC4L,0L,0x4FL,(-3L),(-8L)},{0x1DL,0x92L,4L,(-3L),3L}},{{(-7L),0xC4L,0x28L,0x79L,0xC8L},{0x4FL,0x71L,6L,(-1L),0x98L},{(-9L),3L,(-8L),3L,(-9L)},{0xE7L,0xA6L,0x44L,0x30L,(-3L)},{(-1L),0xE5L,0xE7L,(-7L),0L},{5L,0x4FL,1L,0x25L,1L},{0xDCL,(-7L),0x2CL,0L,0xBAL},{1L,0L,(-8L),(-1L),0xB7L},{(-8L),0x2CL,0x92L,0xB9L,0xBBL},{8L,0x1DL,1L,(-1L),8L}}};
    int64_t l_75 = 0L;
    int8_t l_76 = 0L;
    int8_t l_77[10][3] = {{0xA1L,0xA1L,0xDFL},{0xEBL,0xEBL,1L},{0xA1L,0xA1L,0xDFL},{0xEBL,0xEBL,1L},{0xA1L,0xA1L,0xDFL},{0xEBL,0xEBL,1L},{0xA1L,0xA1L,0xDFL},{0xEBL,0xEBL,1L},{0xA1L,0xA1L,0xDFL},{0xEBL,0xEBL,1L}};
    uint8_t l_78[6];
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_73[i] = 0x6030DEE2L;
    for (i = 0; i < 6; i++)
        l_78[i] = 1UL;
    l_67 ^= g_3;
    --l_78[1];
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_27[i][j][k], "g_27[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 68
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 54
   depth: 2, occurrence: 15
   depth: 3, occurrence: 5
   depth: 4, occurrence: 7
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 102
XXX times a non-volatile is write: 31
XXX times a volatile is read: 13
XXX    times read thru a pointer: 0
XXX times a volatile is write: 11
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 117
XXX percentage of non-volatile access: 84.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 59
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 16
   depth: 2, occurrence: 28

XXX percentage a fresh-made variable is used: 23.8
XXX percentage an existing variable is used: 76.2
********************* end of statistics **********************/

