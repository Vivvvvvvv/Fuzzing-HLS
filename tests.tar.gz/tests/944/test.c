/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8272786657641653394
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_4 = 0xE7D8A870L;
static int32_t g_11 = 0x35E1F6F0L;
static uint32_t g_12 = 0x9141A9C2L;
static uint8_t g_15 = 0xEAL;
static volatile uint8_t g_16 = 1UL;/* VOLATILE GLOBAL g_16 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_12 g_16
 * writes: g_4 g_12 g_15 g_16
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_5 = 0xA772L;
    int32_t l_8 = (-1L);
    l_5 |= (safe_rshift_func_int8_t_s_u(g_4, 3));
    for (g_4 = 0; (g_4 >= 56); g_4++)
    { /* block id: 4 */
        if (g_4)
            break;
        l_8 = (g_4 < g_4);
        for (l_8 = 24; (l_8 < 25); ++l_8)
        { /* block id: 9 */
            g_12--;
            g_15 = (g_4 && 0x4D03L);
            if (g_4)
                break;
        }
        g_16 |= 0L;
    }
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 5

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 93.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 53.8
XXX percentage an existing variable is used: 46.2
********************* end of statistics **********************/

