/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1955850770641131386
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_5 = 0x6B6EL;
static int32_t g_8 = (-7L);
static int32_t g_15[4] = {0x061A6520L,0x061A6520L,0x061A6520L,0x061A6520L};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_8
 * writes: g_5 g_8 g_15
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_4 = 0UL;
    int32_t l_22[7] = {0xCADD6352L,0xCADD6352L,0L,0xCADD6352L,0xCADD6352L,0L,0xCADD6352L};
    int32_t l_26[10] = {9L,(-1L),(-1L),9L,(-1L),(-1L),9L,(-1L),(-1L),9L};
    int i;
    g_5 |= (((safe_add_func_int64_t_s_s(7L, l_4)) == l_4) != 0L);
    if (g_5)
    { /* block id: 2 */
        uint8_t l_17 = 0xE3L;
        g_8 |= (safe_rshift_func_int16_t_s_u(0x464FL, g_5));
        for (g_8 = 0; (g_8 <= (-19)); g_8--)
        { /* block id: 6 */
            uint16_t l_16 = 0x520EL;
            g_15[0] = ((safe_mod_func_uint64_t_u_u(((safe_mod_func_uint32_t_u_u(0x9D81479BL, 0xE4145C17L)) == g_5), g_8)) != g_8);
            if (l_16)
                continue;
            ++l_17;
        }
    }
    else
    { /* block id: 11 */
        uint32_t l_23[8];
        int32_t l_27 = 0x34A2C930L;
        int32_t l_31 = 1L;
        int i;
        for (i = 0; i < 8; i++)
            l_23[i] = 1UL;
        for (g_8 = 22; (g_8 > (-15)); --g_8)
        { /* block id: 14 */
            uint64_t l_28 = 0x82B357F039D3CD36LL;
            ++l_23[0];
            l_26[5] &= g_8;
            l_28++;
        }
        return l_31;
    }
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_15[i], "g_15[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 4
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 48
XXX percentage an existing variable is used: 52
********************* end of statistics **********************/

