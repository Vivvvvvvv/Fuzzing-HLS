/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17845557944393381093
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_9 = 3UL;
static int64_t g_18 = 0x3BFA32A17D0B0A35LL;
static uint32_t g_30 = 0x2F744ED2L;
static int32_t g_43 = 1L;
static int8_t g_54 = (-4L);


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int16_t  func_2(const uint16_t  p_3, int8_t  p_4, int64_t  p_5, int16_t  p_6, int32_t  p_7);
static int32_t  func_12(int32_t  p_13, uint32_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_18 g_30 g_43
 * writes: g_18 g_30 g_43 g_54
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    const uint8_t l_8 = 0x99L;
    uint16_t l_51 = 65526UL;
    l_51 = (func_2(l_8, g_9, l_8, g_9, g_9) & g_9);
    g_54 = (safe_rshift_func_uint8_t_u_u(((g_30 | g_30) , g_18), l_8));
    return l_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_18 g_30 g_43
 * writes: g_18 g_30 g_43
 */
static int16_t  func_2(const uint16_t  p_3, int8_t  p_4, int64_t  p_5, int16_t  p_6, int32_t  p_7)
{ /* block id: 1 */
    int16_t l_17 = 0L;
    int32_t l_28[1];
    int32_t l_48 = 0x4C655EF1L;
    int32_t l_50[3];
    int i;
    for (i = 0; i < 1; i++)
        l_28[i] = 0x025EC560L;
    for (i = 0; i < 3; i++)
        l_50[i] = 0x5B292197L;
    if ((safe_mul_func_int16_t_s_s((((((func_12((safe_lshift_func_int8_t_s_u(g_9, 5)), l_17) , l_17) ^ l_17) || 0x4A938F738F585950LL) > l_28[0]) , 3L), p_3)))
    { /* block id: 7 */
        int16_t l_29 = 0x40E7L;
        l_29 &= (-5L);
        g_30 ^= (p_6 || g_9);
    }
    else
    { /* block id: 10 */
        uint16_t l_49 = 0xD34EL;
        if ((((((safe_mul_func_int16_t_s_s(g_30, g_9)) ^ 18446744073709551615UL) < g_18) && 1L) & g_30))
        { /* block id: 11 */
            uint16_t l_33 = 65535UL;
            --l_33;
            l_28[0] = ((l_33 > 18446744073709551615UL) && p_5);
        }
        else
        { /* block id: 14 */
            int32_t l_36 = 0xD0CD8A6CL;
            l_36 &= g_30;
            g_43 |= ((safe_mod_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((safe_lshift_func_int16_t_s_s(g_30, p_3)), 0)), 250UL)) & 0x39L);
            l_28[0] ^= (((p_6 & (-7L)) != l_36) <= g_43);
        }
        l_49 |= ((((((safe_rshift_func_uint16_t_u_u((safe_div_func_uint16_t_u_u(g_30, p_3)), 6)) | l_48) ^ g_18) >= g_9) ^ 0xF1A7L) >= 0xE38EDFC7A8F60F1BLL);
    }
    l_50[0] |= ((g_18 , l_28[0]) <= p_6);
    return g_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_18
 * writes: g_18
 */
static int32_t  func_12(int32_t  p_13, uint32_t  p_14)
{ /* block id: 2 */
    int32_t l_19 = 0x4A87FCE6L;
    int32_t l_26 = 0xBC9B780FL;
    int32_t l_27 = 0x68FDADF8L;
    g_18 = (g_9 , 0xCF4A4163L);
    l_19 ^= (0x88586FD5D70512A3LL > p_13);
    l_27 &= (safe_mul_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s((safe_rshift_func_uint8_t_u_s((p_13 , g_18), 6)), l_19)) | l_26), g_9));
    return g_9;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 48
XXX times a non-volatile is write: 14
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 19
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 4
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 29
XXX percentage an existing variable is used: 71
********************* end of statistics **********************/

