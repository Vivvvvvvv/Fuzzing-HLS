/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8168142643262201055
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3[9] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static uint32_t g_16 = 0UL;
static int8_t g_19 = 0xE8L;
static uint32_t g_37 = 0xE9C7D4E7L;
static uint64_t g_45[10] = {0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL,0x5D0016D172E30E5DLL};
static uint8_t g_49 = 0x08L;
static uint32_t g_50 = 0x0EA8EDF9L;
static uint64_t g_76[4] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static volatile uint8_t g_77 = 0x59L;/* VOLATILE GLOBAL g_77 */
static uint8_t g_83 = 0xC7L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_5(int8_t  p_6, int32_t  p_7);
static const int32_t  func_8(uint8_t  p_9, int16_t  p_10);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_16 g_37 g_45 g_19 g_50 g_49 g_83
 * writes: g_16 g_19 g_37 g_45 g_49 g_50 g_76 g_77 g_83
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2 = (-1L);
    int32_t l_4 = 0L;
    uint16_t l_48 = 2UL;
    int32_t l_67 = 0x3F497EEEL;
    l_4 = ((l_2 == g_3[1]) >= g_3[3]);
    if (func_5(l_4, g_3[1]))
    { /* block id: 24 */
        l_4 = (safe_lshift_func_int16_t_s_s(1L, l_4));
    }
    else
    { /* block id: 26 */
        int64_t l_42[5] = {2L,2L,2L,2L,2L};
        int8_t l_43[10];
        int32_t l_44[7] = {0x43C7F34FL,0x43C7F34FL,(-2L),0x43C7F34FL,0x43C7F34FL,(-2L),0x43C7F34FL};
        int i;
        for (i = 0; i < 10; i++)
            l_43[i] = 0x92L;
        g_37++;
        l_44[1] ^= ((safe_lshift_func_int16_t_s_u((((l_42[1] == l_43[5]) || g_16) | g_3[2]), g_3[2])) > 65526UL);
        g_45[5]++;
        l_48 = ((l_43[4] & g_16) ^ l_2);
    }
    for (l_4 = 0; (l_4 <= 9); l_4 += 1)
    { /* block id: 34 */
        int32_t l_75 = 0x3AE4B2FCL;
        int i;
        g_49 = g_45[l_4];
        g_50 = ((g_45[l_4] > g_45[l_4]) & g_45[l_4]);
        if (g_3[5])
            break;
        if (((safe_sub_func_int16_t_s_s(((safe_add_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u(g_19, 0x523FL)) || 5UL), g_37)), g_50)), g_49)) != l_2), l_2)) || l_48))
        { /* block id: 38 */
            int64_t l_70 = (-9L);
            l_67 = (+(+(((safe_div_func_int32_t_s_s((safe_add_func_uint32_t_u_u(g_49, 0xC76156DDL)), l_4)) | g_16) > g_19)));
            l_70 |= (safe_rshift_func_int8_t_s_u(g_45[3], 5));
            if (l_70)
                break;
        }
        else
        { /* block id: 42 */
            int64_t l_82 = 9L;
            g_76[1] = (safe_lshift_func_uint16_t_u_u((safe_div_func_int8_t_s_s(6L, l_75)), 13));
            g_77 = 0x63326EEDL;
            l_67 = (safe_sub_func_uint64_t_u_u((safe_sub_func_int64_t_s_s(0xF68CB34FF331764CLL, g_45[l_4])), l_82));
            ++g_83;
        }
    }
    return g_3[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_16
 * writes: g_16 g_19
 */
static int32_t  func_5(int8_t  p_6, int32_t  p_7)
{ /* block id: 2 */
    int32_t l_13[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
    uint16_t l_14 = 0x1D65L;
    int i;
    if ((func_8(((safe_rshift_func_int8_t_s_s((((g_3[1] ^ l_13[3]) || 0xDF5EF889L) >= l_13[0]), g_3[0])) < l_13[3]), l_14) , p_6))
    { /* block id: 7 */
lbl_25:
        g_19 = (g_16 , g_3[1]);
        l_13[3] = (safe_add_func_uint8_t_u_u((safe_add_func_int32_t_s_s(l_13[3], g_3[1])), g_16));
    }
    else
    { /* block id: 10 */
        uint32_t l_24 = 0xD2F55126L;
        int32_t l_27 = (-5L);
        l_24 = ((g_16 ^ l_13[3]) <= 0xCFCBL);
        l_13[2] = (p_6 & l_13[6]);
        if (p_6)
            goto lbl_25;
        for (p_7 = 1; (p_7 <= 8); p_7 += 1)
        { /* block id: 16 */
            int i;
            l_27 = (+g_3[p_7]);
            l_13[5] ^= (safe_sub_func_uint16_t_u_u((!65531UL), p_6));
            l_13[7] = ((safe_sub_func_int8_t_s_s(((((safe_rshift_func_int16_t_s_s((0x2F34C933L || 0x7672A6DFL), 1)) , g_16) != g_3[1]) || 0xDB9E588CL), 7L)) < p_6);
            return l_24;
        }
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_16
 * writes: g_16
 */
static const int32_t  func_8(uint8_t  p_9, int16_t  p_10)
{ /* block id: 3 */
    int32_t l_15 = 0x421DD2EBL;
    l_15 |= (0x3F15L | g_3[1]);
    ++g_16;
    return l_15;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_45[i], "g_45[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_76[i], "g_76[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 25
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 37
   depth: 2, occurrence: 8
   depth: 3, occurrence: 8
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 63
XXX times a non-volatile is write: 24
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 98.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 35
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 15
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 30.9
XXX percentage an existing variable is used: 69.1
********************* end of statistics **********************/

