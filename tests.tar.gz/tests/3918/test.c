/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6517043978174543185
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_6 = 0x985A9576C3A0B8EELL;/* VOLATILE GLOBAL g_6 */
static int64_t g_8 = 0x0815898F01BA028ELL;
static volatile int32_t g_9 = 0x15FDC8DFL;/* VOLATILE GLOBAL g_9 */
static volatile uint32_t g_15 = 0xE3E45BBBL;/* VOLATILE GLOBAL g_15 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_15 g_8
 * writes: g_15
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0x4E2DB58EL;
    int32_t l_3 = 0x9E57AD95L;
    int32_t l_4 = 0x029BF390L;
    int32_t l_5 = 0x290BE443L;
    int32_t l_7[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint32_t l_10 = 0x74952F34L;
    int i;
    --l_10;
    for (l_4 = 27; (l_4 < (-22)); --l_4)
    { /* block id: 4 */
        return g_9;
    }
    --g_15;
    l_5 ^= (safe_rshift_func_int16_t_s_s(0x4220L, l_7[2]));
    return g_8;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 7
   depth: 2, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 3
XXX times a non-volatile is write: 3
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 75

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 6
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 58.8
XXX percentage an existing variable is used: 41.2
********************* end of statistics **********************/

