/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12772137197203042704
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x35A7AB5BL;
static int64_t g_59[2] = {0x14ABDC482A8E6F95LL,0x14ABDC482A8E6F95LL};
static int32_t g_65 = 0xCBD99A0AL;
static uint16_t g_66 = 0x90BCL;
static uint16_t g_149 = 65535UL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint64_t  func_14(uint64_t  p_15);
static int64_t  func_30(int64_t  p_31, uint8_t  p_32, int8_t  p_33, int8_t  p_34, uint32_t  p_35);
static int32_t  func_47(const uint64_t  p_48, int8_t  p_49);
static int8_t  func_52(int64_t  p_53, uint16_t  p_54, const int64_t  p_55);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_66 g_59 g_65 g_149
 * writes: g_3 g_59 g_66 g_65 g_149
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2[10][5][2] = {{{3UL,3UL},{1UL,0x5755261FC42FF18CLL},{1UL,3UL},{3UL,0x165352F76EC7516ALL},{3UL,0xB831966C4779D44FLL}},{{3UL,18446744073709551607UL},{1UL,1UL},{1UL,18446744073709551607UL},{3UL,0xB831966C4779D44FLL},{3UL,0x165352F76EC7516ALL}},{{3UL,3UL},{1UL,0x5755261FC42FF18CLL},{1UL,3UL},{3UL,0x165352F76EC7516ALL},{3UL,0xB831966C4779D44FLL}},{{3UL,18446744073709551607UL},{1UL,1UL},{1UL,18446744073709551607UL},{3UL,0xB831966C4779D44FLL},{3UL,0x165352F76EC7516ALL}},{{3UL,3UL},{1UL,0x5755261FC42FF18CLL},{3UL,3UL},{9UL,0x5755261FC42FF18CLL},{3UL,1UL}},{{9UL,0UL},{3UL,3UL},{3UL,0UL},{9UL,1UL},{3UL,0x5755261FC42FF18CLL}},{{9UL,3UL},{3UL,18446744073709551607UL},{3UL,3UL},{9UL,0x5755261FC42FF18CLL},{3UL,1UL}},{{9UL,0UL},{3UL,3UL},{3UL,0UL},{9UL,1UL},{3UL,0x5755261FC42FF18CLL}},{{9UL,3UL},{3UL,18446744073709551607UL},{3UL,3UL},{9UL,0x5755261FC42FF18CLL},{3UL,1UL}},{{9UL,0UL},{3UL,3UL},{3UL,0UL},{9UL,1UL},{3UL,0x5755261FC42FF18CLL}}};
    int32_t l_10 = 0x0F6DAE1DL;
    uint32_t l_150 = 0x8AF15EAAL;
    int32_t l_161 = 1L;
    int i, j, k;
    if (l_2[9][3][1])
    { /* block id: 1 */
        return g_3;
    }
    else
    { /* block id: 3 */
        int64_t l_6[2];
        uint8_t l_9[4][3][3] = {{{0x7AL,0x96L,0x96L},{0x9AL,252UL,7UL},{0x7AL,0x9DL,0x7AL}},{{0x5FL,0x9AL,7UL},{246UL,246UL,0x96L},{1UL,0x9AL,0x9AL}},{{0x96L,0x9DL,0x90L},{1UL,252UL,1UL},{246UL,0x96L,0x90L}},{{0x5FL,0x5FL,0x9AL},{0x7AL,0x96L,0x96L},{0x9AL,252UL,7UL}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_6[i] = 0x41B0CE7AEBB1BB30LL;
        for (g_3 = 20; (g_3 >= (-21)); g_3 = safe_sub_func_int8_t_s_s(g_3, 5))
        { /* block id: 6 */
            if (g_3)
                break;
        }
        l_6[1] ^= (-1L);
        for (g_3 = 0; (g_3 < (-23)); g_3 = safe_sub_func_uint8_t_u_u(g_3, 2))
        { /* block id: 12 */
            int32_t l_13[3][9] = {{3L,3L,0x2B3F54C3L,0x2B3F54C3L,3L,3L,0x2B3F54C3L,0x2B3F54C3L,3L},{0xAA6F5761L,0xE3C23917L,0xAA6F5761L,0xE3C23917L,0xAA6F5761L,0xE3C23917L,0xAA6F5761L,0xE3C23917L,0xAA6F5761L},{3L,0x2B3F54C3L,0x2B3F54C3L,3L,3L,0x2B3F54C3L,0x2B3F54C3L,3L,3L}};
            int i, j;
            l_10 |= ((((l_6[1] , g_3) ^ l_6[0]) , l_9[1][0][2]) != l_6[1]);
            l_13[1][0] |= (safe_sub_func_int16_t_s_s(l_2[9][3][1], g_3));
        }
        l_150 = (func_14(l_10) <= 0xE208CE9429D60EDBLL);
    }
    g_65 = (((safe_mul_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u((g_3 >= g_59[1]), l_161)) || 0x4805B927L), l_2[9][3][1])), l_150)) < 65535UL), g_65)) <= g_3), 0xF3C3L)) & l_2[9][3][1]) != 4UL);
    l_10 = (((l_2[3][0][0] & g_3) , 0xB14FC1BAL) , l_10);
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_66 g_59 g_65 g_149
 * writes: g_3 g_59 g_66 g_65 g_149
 */
static uint64_t  func_14(uint64_t  p_15)
{ /* block id: 16 */
    uint32_t l_21 = 18446744073709551615UL;
    int16_t l_22[1];
    int32_t l_26 = 0xB9AA6B35L;
    int i;
    for (i = 0; i < 1; i++)
        l_22[i] = (-2L);
    if ((g_3 ^ 18446744073709551615UL))
    { /* block id: 17 */
        uint64_t l_23 = 0UL;
        int32_t l_25 = 0L;
        for (g_3 = 26; (g_3 == 0); g_3--)
        { /* block id: 20 */
            uint32_t l_18 = 0x9D45C545L;
            l_18++;
        }
        if ((0x04L ^ 255UL))
        { /* block id: 23 */
            uint32_t l_24 = 18446744073709551610UL;
            l_21 = (0L ^ 0x5E5AB8BFL);
            l_23 = (((p_15 , p_15) , l_22[0]) || 1UL);
            l_25 = ((g_3 | l_24) && p_15);
            l_26 = 6L;
        }
        else
        { /* block id: 28 */
            l_25 = 0xCC76BF08L;
            g_3 = 0L;
            l_25 = p_15;
        }
        for (p_15 = 0; (p_15 > 50); p_15 = safe_add_func_int64_t_s_s(p_15, 3))
        { /* block id: 35 */
            uint32_t l_29 = 0x36DE7EBAL;
            return l_29;
        }
        l_25 |= (func_30(g_3, p_15, l_22[0], g_3, g_3) && (-7L));
    }
    else
    { /* block id: 105 */
        uint64_t l_148 = 18446744073709551609UL;
        for (g_3 = (-17); (g_3 > 6); g_3 = safe_add_func_int16_t_s_s(g_3, 3))
        { /* block id: 108 */
            uint32_t l_147[8][10] = {{4294967291UL,0x444549C7L,0xA46C974FL,0x22FFCB45L,0x74225E66L,0x602B377AL,4294967291UL,0x5FA698E6L,0x602B377AL,0xA46C974FL},{0x444549C7L,0x5FA698E6L,0UL,0x444549C7L,0x74225E66L,4294967295UL,0x74225E66L,0x444549C7L,0UL,0x5FA698E6L},{0x74225E66L,4294967291UL,4294967291UL,0x01976A6AL,0x8858CDCFL,4294967291UL,0x5FA698E6L,0xA46C974FL,4294967291UL,0UL},{0x22FFCB45L,0x444549C7L,0x8858CDCFL,0x602B377AL,0UL,4294967291UL,4294967291UL,0UL,0x602B377AL,0x8858CDCFL},{0x74225E66L,0x74225E66L,1UL,0UL,4294967292UL,4294967295UL,0x01976A6AL,0x74225E66L,0x96941D4DL,0x01976A6AL},{0x444549C7L,0x22FFCB45L,4294967291UL,0UL,0x22FFCB45L,0x602B377AL,0x01976A6AL,0x602B377AL,0x22FFCB45L,0UL},{4294967291UL,0x74225E66L,4294967291UL,4294967291UL,0x01976A6AL,0x8858CDCFL,4294967291UL,0x5FA698E6L,0xA46C974FL,4294967291UL},{0x5FA698E6L,0x444549C7L,4294967292UL,4294967291UL,4294967295UL,0x5FA698E6L,0x22FFCB45L,0x22FFCB45L,0x5FA698E6L,4294967295UL}};
            int i, j;
            g_65 = ((((l_147[5][5] != p_15) | g_59[0]) | p_15) | g_59[1]);
            g_149 |= ((((((g_59[1] | l_147[0][6]) , g_65) && g_59[1]) | l_148) | g_59[1]) || p_15);
            return p_15;
        }
    }
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_66 g_59 g_65
 * writes: g_3 g_59 g_66 g_65
 */
static int64_t  func_30(int64_t  p_31, uint8_t  p_32, int8_t  p_33, int8_t  p_34, uint32_t  p_35)
{ /* block id: 38 */
    uint32_t l_40 = 18446744073709551607UL;
    int32_t l_46 = 0L;
    const uint32_t l_117 = 4294967295UL;
    uint32_t l_136 = 5UL;
    uint64_t l_144[5];
    int i;
    for (i = 0; i < 5; i++)
        l_144[i] = 0x9CE858CEDA5373E3LL;
    for (g_3 = 0; (g_3 <= (-7)); g_3 = safe_sub_func_int8_t_s_s(g_3, 6))
    { /* block id: 41 */
        int32_t l_60 = 0x9037596CL;
        int32_t l_114 = 0xEF6F4DFAL;
        for (p_34 = 1; (p_34 > 19); ++p_34)
        { /* block id: 44 */
            int32_t l_45 = 0x4D42BE3CL;
            l_40--;
            l_46 = (safe_lshift_func_int16_t_s_u(p_34, l_45));
            l_46 = 0xB16E5D1CL;
            l_46 = func_47((safe_mul_func_uint8_t_u_u((func_52(g_3, g_3, l_45) >= 0x59L), l_60)), p_35);
        }
        l_60 = g_59[1];
        if ((safe_lshift_func_uint8_t_u_s((l_60 & 3UL), l_60)))
        { /* block id: 72 */
            uint64_t l_103 = 0xBC7E195E0419DFFBLL;
            int32_t l_104 = 0xE8D53535L;
            l_104 = (safe_lshift_func_int16_t_s_u(((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint8_t_u_s((((safe_rshift_func_int16_t_s_s(l_103, g_3)) , 4L) >= 0x6B16355718CB2972LL), 6)), 5)) != g_65), g_65));
            if (g_66)
                break;
        }
        else
        { /* block id: 75 */
            uint8_t l_105 = 0xC2L;
            int32_t l_108 = 1L;
            ++l_105;
            if (l_108)
                break;
            g_65 = ((~(safe_sub_func_uint16_t_u_u(p_34, g_59[1]))) && p_34);
        }
        l_114 &= ((safe_rshift_func_uint16_t_u_u(p_35, l_60)) == 0x2EC2C21BE7324BB9LL);
    }
    if (((g_65 & 0x8794F9328A2DDD91LL) , p_33))
    { /* block id: 82 */
        return l_40;
    }
    else
    { /* block id: 84 */
        int64_t l_135 = 0L;
lbl_143:
        if ((((safe_mod_func_uint64_t_u_u(((-8L) == l_117), g_3)) , g_59[1]) , 0xBBC66260L))
        { /* block id: 85 */
            int16_t l_124 = 0x63A1L;
            uint32_t l_125 = 0xE79E523DL;
            int32_t l_126 = 0x46ADFC38L;
            l_126 |= (((safe_rshift_func_int8_t_s_s((safe_mod_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u((l_124 > g_59[0]), (-10L))) ^ 0x9966L), p_31)), 3)) != l_125) != p_32);
            g_3 = ((safe_add_func_int32_t_s_s(l_46, g_59[0])) ^ l_126);
        }
        else
        { /* block id: 88 */
            int8_t l_133 = 0x29L;
            int32_t l_134 = 4L;
            g_3 &= g_59[0];
            l_46 = (safe_div_func_int16_t_s_s(((((((safe_div_func_uint64_t_u_u((((p_33 >= (-5L)) , (-5L)) ^ p_31), 0x44CA3D13A51B20E9LL)) & 0xCA46356B4AE7F92FLL) < 2UL) , 0L) || 1L) >= 0xBD15L), 1L));
            g_3 = ((0x2148F47512D4483BLL & 3L) , l_117);
            ++l_136;
        }
        if ((safe_unary_minus_func_uint64_t_u((safe_div_func_int16_t_s_s(p_34, l_40)))))
        { /* block id: 94 */
            int16_t l_142 = 0xF48CL;
            l_142 = ((g_66 <= 0x50E2895D01DBD879LL) ^ 0xBA22L);
            g_65 = g_3;
            if (l_40)
                goto lbl_143;
            g_3 = l_142;
        }
        else
        { /* block id: 99 */
            return l_135;
        }
        return l_144[0];
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_66 g_59 g_3 g_65
 * writes: g_66 g_65
 */
static int32_t  func_47(const uint64_t  p_48, int8_t  p_49)
{ /* block id: 51 */
    int16_t l_61 = (-1L);
    int32_t l_62 = (-5L);
    int32_t l_63 = (-2L);
    int32_t l_64[10][3] = {{0xDECA68EBL,0xD58F1AF8L,0xD58F1AF8L},{1L,0x73A67FE4L,0x73A67FE4L},{0xDECA68EBL,0xD58F1AF8L,0xD58F1AF8L},{1L,0x73A67FE4L,0x73A67FE4L},{0xDECA68EBL,0xD58F1AF8L,0xD58F1AF8L},{1L,0x73A67FE4L,0x73A67FE4L},{0xDECA68EBL,0xD58F1AF8L,0xD58F1AF8L},{1L,0x73A67FE4L,0x73A67FE4L},{0xDECA68EBL,0xD58F1AF8L,0xD58F1AF8L},{1L,0x73A67FE4L,0x73A67FE4L}};
    int i, j;
    ++g_66;
    for (p_49 = 19; (p_49 < 9); --p_49)
    { /* block id: 55 */
        uint32_t l_80 = 0x3FE16D89L;
        if ((safe_lshift_func_uint16_t_u_u((g_59[1] != 0x11L), 10)))
        { /* block id: 56 */
            int32_t l_81 = 7L;
            g_65 = ((+(safe_rshift_func_int8_t_s_u(((((safe_mod_func_int32_t_s_s(((safe_mod_func_uint8_t_u_u((((l_80 , p_49) > g_59[1]) , l_63), (-1L))) ^ l_64[0][1]), g_3)) != p_49) || l_80) ^ l_81), 3))) & g_59[1]);
            l_81 = l_80;
            g_65 = g_59[1];
            g_65 &= (safe_mul_func_uint16_t_u_u(65528UL, p_49));
        }
        else
        { /* block id: 61 */
            int16_t l_84 = 0x2C7FL;
            int32_t l_85 = 0x1CF63C10L;
            if (l_84)
                break;
            l_85 ^= (((0xC67607BBC662C875LL < l_64[0][1]) , 0x9E040F3C6490BB39LL) ^ l_62);
        }
    }
    g_65 &= (~(safe_add_func_uint64_t_u_u(((((safe_lshift_func_uint8_t_u_s(g_59[1], g_59[1])) , p_48) , p_49) && g_3), g_59[1])));
    l_62 &= (safe_mod_func_int32_t_s_s((-1L), g_3));
    return g_59[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_59
 */
static int8_t  func_52(int64_t  p_53, uint16_t  p_54, const int64_t  p_55)
{ /* block id: 48 */
    int64_t l_58 = 0x6B30262A889E4E2CLL;
    g_59[1] = (((safe_div_func_uint64_t_u_u(p_53, l_58)) , g_3) & g_3);
    return l_58;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_59[i], "g_59[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 50
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 77
   depth: 2, occurrence: 16
   depth: 3, occurrence: 10
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 3
   depth: 11, occurrence: 1
   depth: 12, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 135
XXX times a non-volatile is write: 52
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 75
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 19
   depth: 2, occurrence: 41

XXX percentage a fresh-made variable is used: 27
XXX percentage an existing variable is used: 73
********************* end of statistics **********************/

