/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17293158432893466201
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_5 = 0x45L;
static int32_t g_6 = 0x4F2887CFL;
static uint32_t g_31 = 18446744073709551613UL;
static uint32_t g_44 = 0x5D742CC3L;
static int8_t g_45[1] = {0x16L};
static volatile uint16_t g_46[1] = {65526UL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_9(int16_t  p_10);
static uint16_t  func_12(int8_t  p_13, int8_t  p_14, const uint32_t  p_15, const uint8_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_31 g_46 g_44
 * writes: g_6 g_31 g_44 g_46
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_4 = (-5L);
    uint64_t l_49[3];
    int32_t l_50 = 0L;
    int i;
    for (i = 0; i < 3; i++)
        l_49[i] = 18446744073709551615UL;
    g_6 ^= (safe_rshift_func_int8_t_s_u((l_4 , g_5), 3));
    g_44 = (safe_sub_func_uint16_t_u_u(((func_9(l_4) >= l_4) || l_4), g_5));
    g_46[0]--;
    l_49[1] = g_44;
    return l_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_5 g_31
 * writes: g_6 g_31
 */
static int64_t  func_9(int16_t  p_10)
{ /* block id: 2 */
    uint64_t l_11[5] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
    int32_t l_42 = 0L;
    int i;
    for (g_6 = 0; (g_6 <= 4); g_6 += 1)
    { /* block id: 5 */
        uint64_t l_17 = 0xD2466E9F08664A11LL;
        int8_t l_43 = 0L;
        for (p_10 = 0; (p_10 <= 4); p_10 += 1)
        { /* block id: 8 */
            int i;
            l_42 = (func_12((l_11[g_6] ^ p_10), l_17, p_10, g_5) > g_5);
            l_42 |= ((p_10 ^ (-1L)) & p_10);
            return l_42;
        }
        l_43 |= g_6;
    }
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_31 g_6
 * writes: g_31
 */
static uint16_t  func_12(int8_t  p_13, int8_t  p_14, const uint32_t  p_15, const uint8_t  p_16)
{ /* block id: 9 */
    uint32_t l_22 = 18446744073709551613UL;
    uint32_t l_40 = 1UL;
    uint32_t l_41[4];
    int i;
    for (i = 0; i < 4; i++)
        l_41[i] = 0x20C256FAL;
    for (p_14 = 0; (p_14 == (-23)); p_14 = safe_sub_func_uint32_t_u_u(p_14, 9))
    { /* block id: 12 */
        const int32_t l_20 = (-1L);
        int32_t l_21 = 0L;
        l_21 = (l_20 <= (-10L));
        --l_22;
        l_21 &= ((safe_unary_minus_func_uint8_t_u((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_s(((~p_16) > (-2L)), l_22)), g_5)))) & p_13);
        l_21 = (p_16 , p_16);
    }
    g_31 |= ((l_22 | 0x04L) && p_15);
    l_41[0] = (((safe_mul_func_uint16_t_u_u((((safe_div_func_int32_t_s_s(((safe_lshift_func_int8_t_s_u((p_14 ^ g_5), p_13)) == g_31), l_22)) < g_5) && 0L), l_40)) | l_22) != g_6);
    return l_22;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_45[i], "g_45[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_46[i], "g_46[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 21
   depth: 2, occurrence: 5
   depth: 3, occurrence: 3
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 41
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 98.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 6
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 32.1
XXX percentage an existing variable is used: 67.9
********************* end of statistics **********************/

