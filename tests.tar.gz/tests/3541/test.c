/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14707662101432098700
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_6[4] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static int32_t g_29 = 0x4854668DL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint64_t  func_11(int32_t  p_12, int16_t  p_13, uint16_t  p_14, uint32_t  p_15, int32_t  p_16);
static int8_t  func_19(const uint16_t  p_20, int16_t  p_21, int8_t  p_22);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_29
 * writes:
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_5[10] = {(-10L),(-10L),0xC6L,(-10L),(-10L),0xC6L,(-10L),(-10L),0xC6L,(-10L)};
    uint32_t l_7 = 0UL;
    int32_t l_8 = (-1L);
    uint32_t l_33[8] = {0xC0C7FD57L,0x4B13B106L,0x4B13B106L,0xC0C7FD57L,0x4B13B106L,0x4B13B106L,0xC0C7FD57L,0x4B13B106L};
    int i;
    l_7 = ((safe_rshift_func_int8_t_s_s(((safe_unary_minus_func_int8_t_s(((0UL < 0x08L) , l_5[8]))) ^ l_5[8]), g_6[1])) , 7L);
    l_8 = g_6[0];
    l_33[7] ^= ((safe_mod_func_int32_t_s_s((((func_11((safe_div_func_int8_t_s_s(func_19((g_6[3] <= l_5[8]), l_5[3], l_5[7]), l_5[8])), g_29, l_8, g_6[1], l_8) < g_6[1]) , g_6[1]) > (-1L)), l_5[8])) != 4294967287UL);
    return g_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint64_t  func_11(int32_t  p_12, int16_t  p_13, uint16_t  p_14, uint32_t  p_15, int32_t  p_16)
{ /* block id: 6 */
    uint16_t l_32 = 3UL;
    p_16 |= (((safe_add_func_uint32_t_u_u((l_32 , g_6[1]), 4294967295UL)) , l_32) || p_15);
    return g_6[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_29
 * writes:
 */
static int8_t  func_19(const uint16_t  p_20, int16_t  p_21, int8_t  p_22)
{ /* block id: 3 */
    int8_t l_27[7] = {0x7CL,0x7CL,0x7CL,0x7CL,0x7CL,0x7CL,0x7CL};
    int32_t l_28 = 0xEA5D840DL;
    int i;
    l_28 = ((safe_sub_func_uint64_t_u_u((safe_div_func_int32_t_s_s(((p_22 || 0x23L) , l_27[0]), l_27[1])), g_6[0])) <= g_6[1]);
    return g_29;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_29, "g_29", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 9
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 28
XXX times a non-volatile is write: 5
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 8

XXX percentage a fresh-made variable is used: 27.3
XXX percentage an existing variable is used: 72.7
********************* end of statistics **********************/

