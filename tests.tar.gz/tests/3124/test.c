/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13702020092686848445
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_11[7] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
static int64_t g_22 = (-2L);


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint16_t  func_7(int16_t  p_8, uint64_t  p_9, const uint32_t  p_10);
static int32_t  func_13(const uint32_t  p_14, uint64_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_22
 * writes: g_11
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_4 = 0x0BB743D8L;
    uint32_t l_5 = 0UL;
    int32_t l_6 = 1L;
    uint32_t l_24 = 0x1C8B9BA5L;
    uint32_t l_73 = 0UL;
    int64_t l_83 = 0x7D06F957EEBE8445LL;
    l_6 |= (safe_mod_func_int32_t_s_s(l_4, l_5));
    if ((func_7(l_4, g_11[3], g_11[3]) , 8L))
    { /* block id: 5 */
        const int8_t l_23 = 1L;
        int32_t l_69 = 0x8557C7BDL;
        int32_t l_70 = 0xBB0E3CFEL;
        int32_t l_71 = 0x96E53FD1L;
        int32_t l_72 = 0x6AFE108DL;
        l_6 &= func_13((((((safe_sub_func_int64_t_s_s((safe_add_func_int16_t_s_s((((safe_add_func_int16_t_s_s(((g_11[2] , 0xB92280643B8A277ELL) | g_11[0]), 0L)) <= l_5) & 0x68CB667F5AEE0CD9LL), (-8L))), 0UL)) || g_22) < l_23) == (-1L)) >= l_24), g_22);
        --l_73;
        l_72 = (((((safe_unary_minus_func_int8_t_s((((safe_sub_func_uint16_t_u_u((((safe_lshift_func_uint16_t_u_s((l_73 > 65534UL), g_22)) && 0x8DL) == 0x8DL), l_71)) <= 0UL) & (-10L)))) , g_11[3]) ^ 0UL) == l_73) , g_11[2]);
        g_11[5] = ((safe_rshift_func_uint16_t_u_u(l_5, 9)) , l_83);
    }
    else
    { /* block id: 26 */
        uint32_t l_92 = 1UL;
        int16_t l_94 = (-4L);
lbl_93:
        l_6 = ((safe_mul_func_int8_t_s_s((safe_sub_func_int32_t_s_s(0xB2271DC8L, g_11[3])), 0x18L)) < 4L);
        if ((safe_lshift_func_int8_t_s_s(((safe_add_func_uint64_t_u_u((l_92 , 0x5E9CB1239EB3E32ELL), g_11[3])) ^ g_11[5]), 6)))
        { /* block id: 28 */
            uint32_t l_95 = 0xD53B9309L;
            if (l_5)
                goto lbl_93;
            g_11[4] = ((-1L) >= l_24);
            l_95 = (l_92 && l_94);
            return g_22;
        }
        else
        { /* block id: 33 */
            int32_t l_96 = 1L;
            l_96 |= g_22;
        }
    }
    return g_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes:
 */
static uint16_t  func_7(int16_t  p_8, uint64_t  p_9, const uint32_t  p_10)
{ /* block id: 2 */
    int32_t l_12 = (-3L);
    l_12 = g_11[3];
    return g_11[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_11
 * writes: g_11
 */
static int32_t  func_13(const uint32_t  p_14, uint64_t  p_15)
{ /* block id: 6 */
    uint32_t l_27 = 0UL;
    uint64_t l_28 = 0xE10B49F2B7826243LL;
    int32_t l_42 = (-2L);
    int32_t l_46 = 1L;
    int32_t l_49 = 0xBA6E3211L;
    int32_t l_52 = (-5L);
    int32_t l_53[10] = {0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L,0x0F33E235L};
    int16_t l_55[7];
    int64_t l_56 = 1L;
    uint32_t l_58 = 0x99D06D0CL;
    int16_t l_65 = 0x7B22L;
    int i;
    for (i = 0; i < 7; i++)
        l_55[i] = 0xD72FL;
    g_11[3] &= g_22;
    if ((((safe_add_func_uint64_t_u_u(((0x0CA3L > 8L) ^ 0x7684L), 0xA644184EB300A9E1LL)) && l_27) , l_28))
    { /* block id: 8 */
        uint32_t l_40 = 18446744073709551608UL;
        int32_t l_41 = 0x5CCEB8A0L;
        int32_t l_43 = (-3L);
        int16_t l_44 = 0x46EDL;
        int32_t l_45 = (-1L);
        int32_t l_47 = 0x4A2B52F1L;
        int32_t l_48 = 1L;
        int64_t l_50 = 0L;
        int32_t l_51 = 0x2B60D90CL;
        int32_t l_54 = (-1L);
        int32_t l_57[3];
        int i;
        for (i = 0; i < 3; i++)
            l_57[i] = 8L;
        for (p_15 = 0; (p_15 >= 22); p_15 = safe_add_func_uint16_t_u_u(p_15, 1))
        { /* block id: 11 */
            int64_t l_39[6] = {0x094BF7D69FDB81FDLL,0x094BF7D69FDB81FDLL,0x094BF7D69FDB81FDLL,0x094BF7D69FDB81FDLL,0x094BF7D69FDB81FDLL,0x094BF7D69FDB81FDLL};
            int i;
            l_41 ^= ((((safe_div_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(l_39[3], g_11[1])), g_11[5])), 4UL)), l_40)) <= p_14) , g_22) && 0xE831E341F56A6D98LL);
            if (g_22)
                break;
        }
        g_11[3] = 0x05B3B6ACL;
        --l_58;
    }
    else
    { /* block id: 17 */
        uint64_t l_66 = 0UL;
        g_11[3] = (safe_rshift_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_s((g_11[0] >= l_53[6]), l_65)) , g_11[3]) || l_66), g_22));
    }
    l_42 = (safe_rshift_func_int16_t_s_u(1L, 1));
    return g_22;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_11[i], "g_11[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_22, "g_22", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 42
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 50
XXX times a non-volatile is write: 17
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 10
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 42.4
XXX percentage an existing variable is used: 57.6
********************* end of statistics **********************/

