/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5044578452715122726
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_4 = 6UL;
static volatile int32_t g_21 = 0L;/* VOLATILE GLOBAL g_21 */
static uint64_t g_22 = 18446744073709551606UL;
static int8_t g_25 = 0L;
static int8_t g_28[9] = {(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L),(-2L)};
static int16_t g_37 = 3L;
static int64_t g_39 = 0xA514227F44FB66C1LL;
static uint32_t g_42 = 0UL;
static volatile int8_t g_46 = 0x9AL;/* VOLATILE GLOBAL g_46 */
static volatile int16_t g_47 = 0xF884L;/* VOLATILE GLOBAL g_47 */
static int16_t g_48 = 0x07DBL;
static volatile int16_t g_52 = (-6L);/* VOLATILE GLOBAL g_52 */
static int16_t g_54 = (-7L);
static volatile uint8_t g_55[6][5][8] = {{{9UL,255UL,249UL,0xC9L,0x57L,0UL,0x60L,1UL},{0x6CL,0xC9L,7UL,0x55L,0UL,0x52L,0xE8L,0x60L},{0UL,0x52L,0xE8L,0x60L,0x60L,0xE8L,0x52L,0UL},{0x8EL,0xCBL,1UL,0xA2L,1UL,0x60L,0UL,0x57L},{0x39L,0xE8L,255UL,0x1AL,0xA2L,249UL,255UL,9UL}},{{255UL,0x8EL,1UL,0UL,4UL,0x60L,0x1AL,0UL},{9UL,247UL,0x8EL,0x60L,0x8EL,247UL,9UL,3UL},{0x52L,9UL,255UL,1UL,7UL,0xC1L,0x39L,1UL},{4UL,3UL,249UL,0xA2L,7UL,255UL,0xCFL,0x60L},{0x52L,0x6CL,248UL,1UL,0x8EL,0x1AL,0x57L,0x57L}},{{9UL,4UL,0xCBL,0xCBL,4UL,9UL,248UL,0x39L},{255UL,255UL,0x5AL,0x8EL,0xC9L,0x39L,0x52L,0x76L},{1UL,0xE8L,3UL,0x8EL,0xB5L,0xCFL,7UL,0x39L},{7UL,0xB5L,0xC1L,0xCBL,249UL,0x57L,0x6CL,0x57L},{0xC1L,1UL,0x52L,1UL,0xC1L,248UL,0x76L,0x60L}},{{0x39L,0x1AL,247UL,0xA2L,0x5AL,0x52L,1UL,1UL},{1UL,0x55L,247UL,1UL,9UL,7UL,0x76L,3UL},{0x5AL,255UL,0x52L,0x60L,0UL,0x6CL,0x6CL,0UL},{0UL,0xC1L,0xC1L,0UL,3UL,0x76L,7UL,9UL},{0xE8L,0xCFL,3UL,0x57L,1UL,1UL,0x52L,0x5AL}},{{0x6CL,0xCFL,0x5AL,0xC9L,0x60L,0x76L,248UL,0xC1L},{0xB5L,0xC1L,0xCBL,249UL,0x57L,0x6CL,0x57L,249UL},{248UL,255UL,248UL,255UL,0x39L,7UL,0xCFL,0xB5L},{0xA2L,0x55L,249UL,9UL,0x76L,0x52L,0x39L,0xC9L},{0xA2L,0x1AL,255UL,0xE8L,0x39L,248UL,9UL,4UL}},{{248UL,1UL,0x8EL,0x1AL,0x57L,0x57L,0x1AL,0x8EL},{0xB5L,0xB5L,1UL,0x6CL,0x60L,0xCFL,255UL,7UL},{0x6CL,0xE8L,0UL,0x5AL,1UL,0x39L,0xC1L,7UL},{0xE8L,255UL,4UL,0x6CL,255UL,1UL,0xE8L,7UL},{0xC1L,0xCBL,249UL,0x57L,0x6CL,0x57L,249UL,0xCBL}}};
static volatile int32_t g_58 = 0x87E8D9F6L;/* VOLATILE GLOBAL g_58 */
static int8_t g_59 = 1L;
static uint32_t g_60[6] = {18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL,18446744073709551612UL};
static int16_t g_91[1][5][9] = {{{8L,(-2L),0xECA3L,0xECA3L,(-2L),8L,(-2L),0xECA3L,0xECA3L},{6L,6L,8L,0xECA3L,8L,6L,6L,8L,0xECA3L},{0L,(-2L),0L,8L,8L,0L,(-2L),0L,8L},{0L,8L,8L,0L,(-2L),0L,8L,8L,0L},{6L,8L,0xECA3L,8L,6L,6L,8L,0xECA3L,8L}}};
static int8_t g_92 = 0L;
static int32_t g_94 = (-1L);
static volatile int32_t g_122 = 8L;/* VOLATILE GLOBAL g_122 */
static int64_t g_123 = (-9L);
static volatile int8_t g_128 = 0x32L;/* VOLATILE GLOBAL g_128 */
static volatile uint32_t g_133 = 7UL;/* VOLATILE GLOBAL g_133 */
static uint32_t g_136 = 4UL;
static int32_t g_151 = 0x7775BE2AL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint8_t  func_6(const uint32_t  p_7, int8_t  p_8, uint64_t  p_9, int32_t  p_10, int32_t  p_11);
static const int32_t  func_14(int64_t  p_15, uint16_t  p_16, uint32_t  p_17, int32_t  p_18);
static int16_t  func_29(int16_t  p_30, uint64_t  p_31, int64_t  p_32, int16_t  p_33);
static uint16_t  func_72(const uint32_t  p_73, int16_t  p_74);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_22 g_21 g_25 g_37 g_28 g_39 g_55 g_60 g_59 g_52 g_42 g_92 g_48 g_133 g_136 g_151 g_123
 * writes: g_21 g_22 g_25 g_28 g_37 g_39 g_42 g_55 g_60 g_59 g_91 g_92 g_94 g_133 g_122 g_136 g_151
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_5[6];
    int32_t l_112 = (-1L);
    int i;
    for (i = 0; i < 6; i++)
        l_5[i] = 0x2FA4L;
    l_5[0] = ((safe_mul_func_uint16_t_u_u(g_4, g_4)) , 1L);
    l_112 = (func_6((safe_sub_func_int32_t_s_s(func_14(l_5[5], g_4, g_4, g_4), l_5[0])), l_112, g_48, l_5[0], l_5[0]) == l_5[0]);
    return g_92;
}


/* ------------------------------------------ */
/* 
 * reads : g_133 g_60 g_136 g_25 g_37 g_55 g_151 g_123 g_39 g_22 g_4 g_28
 * writes: g_133 g_122 g_136 g_25 g_151
 */
static uint8_t  func_6(const uint32_t  p_7, int8_t  p_8, uint64_t  p_9, int32_t  p_10, int32_t  p_11)
{ /* block id: 74 */
    const int32_t l_113[9][2][4] = {{{(-1L),(-1L),0x7C4FE17DL,(-1L)},{(-1L),(-1L),0L,(-1L)}},{{(-1L),(-9L),(-1L),0L},{0x59E71000L,0L,1L,(-1L)}},{{(-10L),0x59E71000L,0L,0L},{(-1L),(-1L),0L,1L}},{{(-10L),1L,1L,(-10L)},{0x59E71000L,(-1L),(-1L),(-4L)}},{{(-1L),(-4L),0L,(-1L)},{(-1L),(-1L),0x7C4FE17DL,(-1L)}},{{(-1L),(-4L),(-1L),(-4L)},{0x9D1050BFL,(-1L),(-9L),(-10L)}},{{0L,1L,(-1L),1L},{(-1L),(-1L),1L,0L}},{{(-1L),0x59E71000L,(-1L),(-1L)},{0L,0L,(-9L),0L}},{{0x9D1050BFL,(-9L),(-1L),(-1L)},{(-1L),(-1L),0x7C4FE17DL,(-1L)}}};
    int32_t l_117 = 0L;
    int32_t l_118 = 0xFB1128C1L;
    int32_t l_127 = 0L;
    int32_t l_129 = (-2L);
    int32_t l_130[3][6] = {{0x4F7A5021L,0x692C56C0L,0x692C56C0L,0x4F7A5021L,0L,0x4F7A5021L},{0x4F7A5021L,0L,0x4F7A5021L,0x692C56C0L,0x692C56C0L,0x4F7A5021L},{1L,1L,0x692C56C0L,0x5449CDFCL,0x692C56C0L,1L}};
    int i, j, k;
    if (l_113[6][0][3])
    { /* block id: 75 */
        int32_t l_120 = (-1L);
        int32_t l_124 = 0x41CF223CL;
        int32_t l_125 = (-4L);
        int32_t l_126 = 0xDE629050L;
lbl_145:
        for (p_10 = 0; (p_10 <= 5); p_10 += 1)
        { /* block id: 78 */
            int8_t l_114 = 0x64L;
            int32_t l_115 = (-1L);
            int32_t l_116 = 0L;
            int32_t l_119 = (-1L);
            int32_t l_121 = 0x21404140L;
            int32_t l_131 = 0x8970CE46L;
            int32_t l_132 = 0L;
            int i;
            ++g_133;
            g_122 = (g_60[p_10] < 0x2074A6A36E0413CFLL);
            ++g_136;
            l_118 ^= (-1L);
        }
        p_10 = (((((safe_add_func_uint8_t_u_u((safe_div_func_uint8_t_u_u(l_130[2][1], p_8)), (-9L))) > l_126) != p_10) || 0x2DL) , p_11);
        for (g_25 = 14; (g_25 <= 11); --g_25)
        { /* block id: 87 */
            if (g_136)
                goto lbl_145;
            if (g_37)
                continue;
            g_151 ^= ((safe_rshift_func_int8_t_s_u((safe_mod_func_int16_t_s_s((safe_unary_minus_func_uint8_t_u(((p_10 == 0xAF8CB8F1L) , 249UL))), l_125)), 1)) ^ g_55[3][0][1]);
        }
        g_122 = (((safe_div_func_int8_t_s_s(0x21L, g_123)) & l_127) || 18446744073709551615UL);
    }
    else
    { /* block id: 93 */
        if (((safe_mod_func_uint32_t_u_u(0UL, p_11)) < p_7))
        { /* block id: 94 */
            int64_t l_156 = 3L;
            l_130[2][5] ^= (g_39 < l_156);
            l_127 |= (safe_lshift_func_uint8_t_u_u((safe_div_func_int16_t_s_s((((safe_mul_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_u(g_22, p_8)) & p_10), l_129)) >= l_156) ^ g_37), 0xF1F5L)), 4));
            p_10 = ((safe_div_func_uint16_t_u_u((l_156 >= 0xC498L), g_4)) | 0x5D39L);
        }
        else
        { /* block id: 98 */
            int32_t l_177 = 0x9AD93880L;
            g_122 = ((safe_div_func_int32_t_s_s((safe_add_func_int64_t_s_s((safe_mul_func_uint8_t_u_u((safe_rshift_func_int8_t_s_u(((safe_sub_func_uint64_t_u_u(l_177, l_177)) != p_11), p_11)), p_7)), 0x132FC06C70737C93LL)), p_11)) == g_28[1]);
            return p_9;
        }
    }
    return l_118;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_22 g_21 g_25 g_37 g_28 g_39 g_55 g_60 g_59 g_52 g_42 g_92
 * writes: g_21 g_22 g_25 g_28 g_37 g_39 g_42 g_55 g_60 g_59 g_91 g_92 g_94
 */
static const int32_t  func_14(int64_t  p_15, uint16_t  p_16, uint32_t  p_17, int32_t  p_18)
{ /* block id: 2 */
    const int8_t l_95 = 0x7DL;
    for (p_17 = 21; (p_17 > 23); p_17++)
    { /* block id: 5 */
        uint64_t l_26 = 0xEFE0CD1B7E280BFELL;
        int32_t l_27 = 1L;
        if (g_4)
        { /* block id: 6 */
            g_21 = (g_4 , 0xADCA1A1FL);
        }
        else
        { /* block id: 8 */
            ++g_22;
        }
        g_25 = p_17;
        if (((g_21 ^ 1UL) , l_26))
        { /* block id: 12 */
            int32_t l_93 = (-2L);
            g_28[1] = ((l_27 & g_25) || p_16);
            l_27 = (func_29(p_18, p_17, p_16, p_17) >= p_18);
            g_94 = (((p_15 >= 255UL) | 7UL) < l_93);
            l_93 ^= (0xDC054819E5EE4ADBLL ^ l_95);
        }
        else
        { /* block id: 61 */
            int8_t l_98 = (-3L);
            l_98 = (safe_sub_func_int32_t_s_s(l_95, g_42));
            return g_92;
        }
        for (g_92 = 0; (g_92 <= 15); g_92 = safe_add_func_int32_t_s_s(g_92, 7))
        { /* block id: 67 */
            int64_t l_101 = 0x68EE181CB01B0954LL;
            uint64_t l_102[1][6][10] = {{{0UL,1UL,0UL,18446744073709551606UL,0UL,1UL,0UL,8UL,0xEDAB18E11B1975C8LL,6UL},{8UL,18446744073709551615UL,1UL,0xC748E3606EC16123LL,0UL,0UL,0xC748E3606EC16123LL,1UL,18446744073709551615UL,8UL},{0x171BA0D895055D0CLL,18446744073709551615UL,0xEDAB18E11B1975C8LL,18446744073709551608UL,18446744073709551606UL,6UL,0UL,6UL,18446744073709551606UL,18446744073709551608UL},{18446744073709551608UL,1UL,18446744073709551608UL,18446744073709551615UL,18446744073709551606UL,0UL,8UL,8UL,8UL,18446744073709551608UL},{1UL,0xC748E3606EC16123LL,0UL,0UL,0xC748E3606EC16123LL,1UL,18446744073709551615UL,8UL,18446744073709551606UL,0xEDAB18E11B1975C8LL},{0x171BA0D895055D0CLL,0xEDAB18E11B1975C8LL,0UL,1UL,8UL,1UL,0UL,0xEDAB18E11B1975C8LL,0x171BA0D895055D0CLL,1UL}}};
            int32_t l_111 = 0x8FF55284L;
            int i, j, k;
            l_102[0][4][2]++;
            l_111 = (safe_mod_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_s(g_52, 4)), 7)), l_102[0][2][5]));
            if (l_102[0][4][2])
                continue;
        }
    }
    return g_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_37 g_28 g_22 g_21 g_39 g_55 g_60 g_4 g_59 g_52 g_42
 * writes: g_37 g_39 g_22 g_42 g_55 g_60 g_59 g_91 g_92
 */
static int16_t  func_29(int16_t  p_30, uint64_t  p_31, int64_t  p_32, int16_t  p_33)
{ /* block id: 14 */
    const uint8_t l_36 = 247UL;
    int32_t l_45[7] = {0x2C82F3C0L,(-7L),0x2C82F3C0L,0x2C82F3C0L,(-7L),0x2C82F3C0L,0x2C82F3C0L};
    int i;
    if ((safe_lshift_func_int16_t_s_u(p_32, p_32)))
    { /* block id: 15 */
        int64_t l_38 = 0x20EEB4983CA30775LL;
        g_37 ^= l_36;
        g_39 = (l_38 && p_30);
        return g_28[1];
    }
    else
    { /* block id: 19 */
        int64_t l_49 = (-1L);
        int32_t l_50 = 5L;
        int32_t l_51[6][9] = {{4L,0x038BE40EL,9L,(-6L),(-1L),0x6D35DF96L,0x6D35DF96L,(-1L),(-6L)},{(-3L),(-6L),(-3L),(-7L),(-10L),(-3L),0x6340C09CL,0x6340C09CL,(-3L)},{9L,0x038BE40EL,4L,0x038BE40EL,9L,(-6L),(-1L),0x6D35DF96L,0x6D35DF96L},{(-1L),(-1L),(-3L),(-7L),(-3L),(-1L),(-1L),(-10L),0xEB447FD3L},{0x1C5AB2A4L,1L,0x038BE40EL,(-6L),0x23986B29L,(-6L),0x038BE40EL,1L,0x1C5AB2A4L},{(-1L),0x16884ADDL,0x6340C09CL,(-10L),0xB5F277F1L,(-3L),0xB5F277F1L,(-10L),0x6340C09CL}};
        int32_t l_53 = (-3L);
        int i, j;
        for (g_22 = (-26); (g_22 >= 17); ++g_22)
        { /* block id: 22 */
            g_42 = (18446744073709551615UL >= g_21);
        }
        for (g_39 = 0; (g_39 <= 8); g_39++)
        { /* block id: 27 */
            return l_36;
        }
        --g_55[2][1][0];
        g_60[0]++;
    }
    for (g_22 = 22; (g_22 >= 55); g_22 = safe_add_func_uint16_t_u_u(g_22, 5))
    { /* block id: 35 */
        int32_t l_65 = 1L;
        return l_65;
    }
    g_92 = ((safe_div_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_s((func_72(((safe_sub_func_int64_t_s_s(((safe_mul_func_int16_t_s_s(((safe_mul_func_int8_t_s_s((0xD4AEL | 7UL), p_33)) > g_22), p_30)) != p_30), p_32)) | 0L), g_4) , 65535UL), 6)), 0xAA55A693L)), 65535UL)) | 4294967293UL);
    return l_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_59 g_52 g_42 g_39
 * writes: g_22 g_59 g_91
 */
static uint16_t  func_72(const uint32_t  p_73, int16_t  p_74)
{ /* block id: 38 */
    int16_t l_84 = 0x96A4L;
    int32_t l_89 = (-1L);
    int32_t l_90 = 0x15C25834L;
    for (g_22 = 6; (g_22 <= 45); g_22 = safe_add_func_int16_t_s_s(g_22, 1))
    { /* block id: 41 */
        int64_t l_83 = 0L;
        l_84 ^= l_83;
    }
    if (p_74)
    { /* block id: 44 */
        for (g_59 = 0; (g_59 >= 29); g_59 = safe_add_func_int32_t_s_s(g_59, 1))
        { /* block id: 47 */
            l_89 |= (safe_rshift_func_uint8_t_u_s(g_52, g_42));
        }
        l_90 = g_39;
        g_91[0][2][5] = (((p_74 & 18446744073709551615UL) ^ p_73) , l_90);
    }
    else
    { /* block id: 52 */
        l_89 &= p_74;
    }
    return l_90;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_28[i], "g_28[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_55[i][j][k], "g_55[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_60[i], "g_60[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_91[i][j][k], "g_91[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_92, "g_92", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 67
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 62
   depth: 2, occurrence: 18
   depth: 3, occurrence: 4
   depth: 4, occurrence: 5
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 12, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 100
XXX times a non-volatile is write: 37
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 60
XXX percentage of non-volatile access: 92.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 62
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 22
   depth: 2, occurrence: 26

XXX percentage a fresh-made variable is used: 39.2
XXX percentage an existing variable is used: 60.8
********************* end of statistics **********************/

