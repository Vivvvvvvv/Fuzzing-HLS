/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13305090758233129262
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2[9] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
static uint32_t g_13 = 0x4307A329L;
static int16_t g_45 = (-1L);
static uint8_t g_47 = 0xCAL;
static uint32_t g_51 = 9UL;
static volatile uint8_t g_54 = 0x99L;/* VOLATILE GLOBAL g_54 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_16(int64_t  p_17, int8_t  p_18, uint16_t  p_19, int32_t  p_20);
static const int32_t  func_25(int64_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_45 g_47 g_54
 * writes: g_2 g_13 g_45 g_47 g_51 g_54
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    const uint64_t l_12[3] = {5UL,5UL,5UL};
    int32_t l_50 = 1L;
    int32_t l_65 = (-1L);
    int32_t l_66 = 3L;
    int32_t l_67 = 0xC80F86AEL;
    int32_t l_68 = (-6L);
    int32_t l_69 = (-3L);
    int32_t l_70[6] = {(-4L),7L,(-4L),(-4L),7L,(-4L)};
    int8_t l_71[3];
    int32_t l_72 = 1L;
    uint16_t l_73[10] = {0xC082L,0xC082L,0xC082L,0xC082L,0xC082L,0xC082L,0xC082L,0xC082L,0xC082L,0xC082L};
    int i;
    for (i = 0; i < 3; i++)
        l_71[i] = (-3L);
    for (g_2[3] = (-26); (g_2[3] != 13); g_2[3]++)
    { /* block id: 3 */
        uint16_t l_22[3];
        uint16_t l_52 = 0UL;
        int32_t l_53 = 0x55EA0D0AL;
        int i;
        for (i = 0; i < 3; i++)
            l_22[i] = 0x5A12L;
        g_13 = (safe_mod_func_int32_t_s_s(((safe_mul_func_int8_t_s_s((((!(safe_mod_func_int32_t_s_s(((0L <= 0x5EE2L) , l_12[2]), 1L))) || 0x3F23E93DL) | 0x486B6FEB9E9D60A2LL), 0x52L)) || 0x3417L), g_2[7]));
        if (((((safe_sub_func_int64_t_s_s(g_2[3], g_13)) == l_12[2]) && l_12[0]) < g_2[6]))
        { /* block id: 5 */
            uint16_t l_21 = 0x7B88L;
            g_47 ^= ((func_16((l_21 , (-1L)), l_22[0], l_21, l_12[2]) , 0x6A17L) | l_22[0]);
            if (l_12[2])
                break;
            l_50 = ((safe_mul_func_int8_t_s_s((((l_21 != g_47) < g_2[3]) > g_13), 0xFAL)) || g_13);
        }
        else
        { /* block id: 17 */
            if (g_45)
                break;
            g_51 = (1L == 255UL);
            l_53 = l_52;
        }
        ++g_54;
    }
    l_50 = ((((safe_rshift_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_u(((safe_mod_func_int16_t_s_s(((safe_add_func_int8_t_s_s((l_12[2] ^ g_45), l_12[2])) <= g_13), l_50)) , 255UL), 5)) ^ 0x43E03EB4L) | g_47), g_47)) & l_12[2]) < 0L) > l_12[2]);
    l_73[2]++;
    for (l_66 = 0; (l_66 > 20); l_66++)
    { /* block id: 28 */
        if (g_2[4])
            break;
    }
    return l_12[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_45
 * writes: g_45
 */
static int32_t  func_16(int64_t  p_17, int8_t  p_18, uint16_t  p_19, int32_t  p_20)
{ /* block id: 6 */
    uint32_t l_36 = 0xDE082ADEL;
    int32_t l_46[10];
    int i;
    for (i = 0; i < 10; i++)
        l_46[i] = 0xB9BDD189L;
    p_20 = ((((safe_div_func_uint64_t_u_u((func_25(g_2[3]) | l_36), p_18)) <= g_13) != 65535UL) ^ 0x473ECFB8L);
    g_45 ^= ((safe_rshift_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((safe_div_func_uint8_t_u_u((safe_div_func_int8_t_s_s((0x698BL != p_18), 0x69L)), g_2[8])), l_36)), g_13)) || 0xC8E11F3177355A2CLL);
    l_46[2] = (-1L);
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_13
 * writes:
 */
static const int32_t  func_25(int64_t  p_26)
{ /* block id: 7 */
    uint32_t l_34 = 8UL;
    int32_t l_35 = 0L;
    l_35 = ((((safe_mul_func_int16_t_s_s((!(safe_sub_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s((((l_34 & p_26) , (-8L)) != 0x0E74L), g_13)), 0xCEL))), p_26)) >= 0xB3883FAAL) , 1L) , (-1L));
    return p_26;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 24
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 47
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 24
XXX percentage of non-volatile access: 98.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 24.7
XXX percentage an existing variable is used: 75.3
********************* end of statistics **********************/

