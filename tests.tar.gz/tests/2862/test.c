/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17862155672430750300
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint32_t g_6 = 0xAA39ED08L;
static int64_t g_19 = (-1L);
static uint8_t g_21 = 1UL;
static volatile int8_t g_26 = 0L;/* VOLATILE GLOBAL g_26 */
static uint16_t g_27 = 0x2357L;
static int64_t g_33[4] = {6L,6L,6L,6L};
static volatile uint32_t g_35 = 1UL;/* VOLATILE GLOBAL g_35 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, int8_t  p_4);
static int64_t  func_10(uint32_t  p_11, uint64_t  p_12, const int32_t  p_13, uint32_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_19 g_21 g_27 g_33 g_35
 * writes: g_19 g_21 g_27 g_33 g_35
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    const uint8_t l_5 = 0xF8L;
    int32_t l_34 = 0x2215F8F5L;
    int32_t l_38 = 0x3AC16B40L;
    g_33[1] ^= func_2((l_5 >= g_6), l_5);
    for (g_27 = 0; (g_27 <= 3); g_27 += 1)
    { /* block id: 19 */
        int i;
        l_34 = g_33[g_27];
        g_35 = (-1L);
        l_38 ^= (safe_lshift_func_int16_t_s_u(g_35, l_34));
    }
    for (l_38 = 3; (l_38 >= 0); l_38 -= 1)
    { /* block id: 26 */
        int16_t l_39 = 0L;
        l_34 = (0xDC9A81FFL & l_39);
    }
    return g_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_19 g_21 g_27
 * writes: g_19 g_21 g_27
 */
static int32_t  func_2(uint64_t  p_3, int8_t  p_4)
{ /* block id: 1 */
    uint64_t l_18 = 0xD5FEAF86F25DB2B0LL;
    int32_t l_20 = 0x17C0EC0DL;
    uint16_t l_32 = 0x10EFL;
    if (((!(((safe_mod_func_int64_t_s_s((func_10(g_6, p_4, p_3, g_6) < l_18), g_6)) & 0xA97FL) , 0xEF9953E80C6548AALL)) > p_3))
    { /* block id: 7 */
        g_19 ^= (((0xAA237F4AL >= p_3) >= g_6) || p_3);
    }
    else
    { /* block id: 9 */
        uint8_t l_24 = 249UL;
        int32_t l_25[2];
        int i;
        for (i = 0; i < 2; i++)
            l_25[i] = 0x8131DDA8L;
        ++g_21;
        l_24 = g_6;
        --g_27;
    }
    l_20 = (safe_sub_func_int16_t_s_s((l_20 ^ 0x6746L), 8UL));
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static int64_t  func_10(uint32_t  p_11, uint64_t  p_12, const int32_t  p_13, uint32_t  p_14)
{ /* block id: 2 */
    uint32_t l_15 = 0x969AC54CL;
    int32_t l_16 = 0x90350D8AL;
lbl_17:
    l_15 = (0L > 1L);
    l_16 = (((g_6 == 0x3E19F23EL) , p_13) , l_15);
    if (l_15)
        goto lbl_17;
    return l_16;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_33[i], "g_33[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_35, "g_35", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 21
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 13
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 19
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 8

XXX percentage a fresh-made variable is used: 43.9
XXX percentage an existing variable is used: 56.1
********************* end of statistics **********************/

