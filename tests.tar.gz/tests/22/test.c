/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7467975943538387608
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int16_t g_11 = 9L;/* VOLATILE GLOBAL g_11 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes:
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_10[10][1][6] = {{{0xC41AC3DCL,0x09CB0BEFL,0UL,0x3FF14EB4L,0UL,0x09CB0BEFL}},{{0xC41AC3DCL,0x3BA20B95L,0x3FF14EB4L,0x9F6D4A0DL,0x756A3367L,0xD0714AD3L}},{{4294967292UL,0x3FF14EB4L,0xC41AC3DCL,1UL,1UL,0xC41AC3DCL}},{{0x3FF14EB4L,0x3FF14EB4L,4294967295UL,4294967292UL,0x756A3367L,1UL}},{{0x09CB0BEFL,0x3BA20B95L,0x9F6D4A0DL,4294967295UL,0UL,4294967295UL}},{{0x9F6D4A0DL,0x09CB0BEFL,0x9F6D4A0DL,0xD0714AD3L,0x3FF14EB4L,1UL}},{{0x184DCC80L,0xD0714AD3L,4294967295UL,9UL,0xC41AC3DCL,0xC41AC3DCL}},{{9UL,0xC41AC3DCL,0xC41AC3DCL,9UL,0x09CB0BEFL,0x3BA20B95L}},{{0x9F6D4A0DL,0xC41AC3DCL,4294967295UL,0x3BA20B95L,1UL,4294967292UL}},{{1UL,0x09CB0BEFL,0x184DCC80L,0x09CB0BEFL,1UL,0x756A3367L}}};
    int32_t l_12[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
    int i, j, k;
    l_12[5] = (safe_mod_func_uint64_t_u_u((safe_lshift_func_int16_t_s_s((safe_div_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(((l_10[7][0][5] < l_10[7][0][5]) ^ (-8L)), g_11)), 1L)), 5)), 1L));
    return l_12[6];
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 2
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 3
XXX times a non-volatile is write: 1
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 80

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 60
XXX percentage an existing variable is used: 40
********************* end of statistics **********************/

