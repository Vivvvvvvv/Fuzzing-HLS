/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5188284429874219568
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0L;
static int32_t g_4 = 0x76C51653L;
static uint64_t g_25 = 0x30477AE2718B9628LL;
static int32_t g_26 = 0xB4D258D0L;
static int32_t g_66 = 0L;
static volatile int32_t g_94 = 0x3F132C5AL;/* VOLATILE GLOBAL g_94 */
static volatile uint32_t g_125 = 0xEA876B16L;/* VOLATILE GLOBAL g_125 */
static volatile int64_t g_156 = 5L;/* VOLATILE GLOBAL g_156 */
static int32_t g_158 = 0x482750ABL;
static int32_t g_160[10][3] = {{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L},{0x23BF6274L,0x23BF6274L,0x23BF6274L}};
static uint32_t g_164 = 0x0F596B17L;
static uint64_t g_180 = 0x9A46C974F601976ALL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_8(uint16_t  p_9, int32_t  p_10, int8_t  p_11, uint32_t  p_12);
static int16_t  func_13(int32_t  p_14, uint32_t  p_15);
static uint64_t  func_16(int64_t  p_17, uint32_t  p_18, uint32_t  p_19, int32_t  p_20);
static uint16_t  func_34(int32_t  p_35, const int16_t  p_36, int32_t  p_37, int64_t  p_38);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_25 g_26 g_66 g_94 g_125 g_164 g_160 g_180 g_158 g_156
 * writes: g_3 g_4 g_25 g_26 g_66 g_125 g_164 g_160 g_180 g_94 g_158
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[1][6][10] = {{{0x5252CB13L,0x38ECF54CL,0L,0x63126FF2L,0x38ECF54CL,0x63126FF2L,0L,0x38ECF54CL,0x5252CB13L,0x5252CB13L},{(-10L),8L,0xC69AED23L,0x38ECF54CL,0x38ECF54CL,0xC69AED23L,0L,0x63126FF2L,0x38ECF54CL,0x63126FF2L},{0x5252CB13L,0xC69AED23L,0xC4530722L,0x5252CB13L,0xC4530722L,0xC69AED23L,0x5252CB13L,(-1L),(-1L),0x5252CB13L},{(-1L),0x63126FF2L,0xC4530722L,0xC4530722L,0x63126FF2L,(-1L),0xC69AED23L,0x63126FF2L,0xC69AED23L,(-1L)},{0L,0x63126FF2L,0x38ECF54CL,0x63126FF2L,0L,0x38ECF54CL,0x5252CB13L,0x5252CB13L,0x38ECF54CL,0L},{0L,0xC69AED23L,0xC69AED23L,0L,0xC4530722L,(-1L),0L,(-1L),0xC4530722L,0L}}};
    int i, j, k;
    for (g_3 = 0; (g_3 <= 0); g_3 += 1)
    { /* block id: 3 */
        const int32_t l_7 = 0x3D069F49L;
        int32_t l_296 = 0x752B4E38L;
        uint32_t l_324[3];
        int i;
        for (i = 0; i < 3; i++)
            l_324[i] = 0x66B716D7L;
        for (g_4 = 0; (g_4 >= 0); g_4 -= 1)
        { /* block id: 6 */
            l_2[0][4][4] &= ((safe_rshift_func_int16_t_s_u(l_7, 1)) , 0xACD40988L);
            g_160[9][1] = func_8((func_13(g_4, g_3) ^ 65527UL), g_3, g_4, l_2[0][4][6]);
            l_296 = (safe_div_func_uint32_t_u_u(0xDBBD370AL, g_158));
        }
        if (((safe_mod_func_uint8_t_u_u(((0L <= 7L) ^ l_296), g_164)) <= 0xDDL))
        { /* block id: 197 */
            const int64_t l_307 = 0xC72E30379E35B24FLL;
            int32_t l_308 = 0x5753EDEEL;
            l_308 = (safe_add_func_uint8_t_u_u((safe_div_func_int64_t_s_s((safe_mod_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u(l_296, 0x2FL)), l_307)), 0x8B95D9890B11C7D0LL)), l_2[0][2][5]));
            g_160[9][1] = (safe_rshift_func_uint16_t_u_s(((((l_307 | g_160[9][1]) , 1UL) & g_4) && 65534UL), l_307));
        }
        else
        { /* block id: 200 */
            g_26 = 1L;
            if (l_2[0][4][5])
                continue;
            g_66 = (safe_add_func_uint64_t_u_u(((l_7 | g_158) <= (-6L)), l_7));
        }
        for (g_66 = 0; (g_66 >= 0); g_66 -= 1)
        { /* block id: 207 */
            uint32_t l_323 = 2UL;
            l_296 = ((safe_div_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_u(((safe_mul_func_uint8_t_u_u((safe_mod_func_int64_t_s_s((((18446744073709551615UL & l_323) ^ 4294967292UL) , g_160[0][2]), 18446744073709551615UL)), g_158)) , l_323), l_323)) < l_7), 0x20149C64L)), 0x5D48113CL)) ^ l_323);
            g_4 = ((((l_324[0] , g_180) && 0x3D1FL) >= g_180) | 65533UL);
            if (g_94)
                break;
            if (l_323)
                continue;
        }
    }
    return g_66;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_180 g_26 g_3 g_156 g_160 g_4 g_164 g_66 g_125
 * writes: g_25 g_180 g_160 g_94 g_66
 */
static int32_t  func_8(uint16_t  p_9, int32_t  p_10, int8_t  p_11, uint32_t  p_12)
{ /* block id: 145 */
    uint32_t l_232 = 18446744073709551611UL;
    int32_t l_240 = 1L;
    int8_t l_242 = (-4L);
    int32_t l_250[5];
    int32_t l_270 = 0x18535F4CL;
    int32_t l_283 = (-1L);
    int i;
    for (i = 0; i < 5; i++)
        l_250[i] = 0L;
lbl_254:
    for (g_25 = 0; (g_25 <= 2); g_25 += 1)
    { /* block id: 148 */
        int32_t l_239 = (-9L);
        l_232--;
        if (l_232)
            break;
        for (g_180 = 0; (g_180 <= 2); g_180 += 1)
        { /* block id: 153 */
            int i, j;
            g_160[(g_180 + 6)][g_180] = (safe_add_func_uint8_t_u_u((1L & l_232), 1UL));
            return g_26;
        }
        l_240 = (safe_mul_func_int16_t_s_s(p_9, l_239));
        for (p_11 = 0; (p_11 <= 2); p_11 += 1)
        { /* block id: 160 */
            return p_9;
        }
    }
    if ((safe_unary_minus_func_uint8_t_u(0UL)))
    { /* block id: 164 */
        uint32_t l_249 = 18446744073709551607UL;
        int32_t l_259 = 0xA937B62AL;
        int32_t l_269[1][6][5] = {{{(-5L),(-5L),0x15CD3094L,0x15CD3094L,(-5L)},{(-6L),(-9L),(-6L),(-9L),(-6L)},{(-5L),0x15CD3094L,0x15CD3094L,(-5L),(-5L)},{0L,(-9L),0L,(-9L),0L},{(-5L),(-5L),0x15CD3094L,0x15CD3094L,(-5L)},{(-6L),(-9L),(-6L),(-9L),(-6L)}}};
        int32_t l_271 = 0xF5FAAF09L;
        int i, j, k;
        if (((l_242 && l_240) && 0UL))
        { /* block id: 165 */
            g_94 = ((safe_lshift_func_int8_t_s_s((p_11 || p_10), g_3)) && 0x5DL);
            l_250[1] = (safe_mul_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_s((p_9 >= p_10), g_156)) >= 18446744073709551610UL) >= p_9), l_249));
            g_160[9][1] = ((safe_unary_minus_func_uint32_t_u((safe_sub_func_int64_t_s_s(g_26, p_10)))) && 0x79F787DA68F4A9C1LL);
            g_160[9][1] &= (l_232 , p_11);
        }
        else
        { /* block id: 170 */
            if (g_3)
                goto lbl_254;
            g_66 = p_11;
        }
        for (l_249 = 0; (l_249 != 44); ++l_249)
        { /* block id: 176 */
            return g_160[9][1];
        }
        l_259 = ((safe_div_func_uint16_t_u_u(0xF7CDL, p_11)) && 0x3D6FL);
        if ((((safe_lshift_func_uint8_t_u_u((((((0x1581L && l_250[0]) != g_4) | p_9) ^ l_250[1]) <= g_164), 0)) != g_26) != g_66))
        { /* block id: 180 */
            uint64_t l_262 = 18446744073709551609UL;
            int32_t l_263 = 0x9CEF6D55L;
            int32_t l_264 = 0x5DD1E5A3L;
            int32_t l_265 = 0x88EDF5FAL;
            int32_t l_266 = 0x6D4E311FL;
            int32_t l_267 = 3L;
            int32_t l_268[10] = {0x023C09FFL,0x99ADD518L,0x023C09FFL,0x023C09FFL,0x99ADD518L,0x023C09FFL,0x023C09FFL,0x99ADD518L,0x023C09FFL,0x023C09FFL};
            uint32_t l_272 = 1UL;
            int i;
            g_66 = ((l_249 >= g_125) || g_164);
            g_66 = (l_262 && (-1L));
            ++l_272;
            l_269[0][2][2] ^= p_11;
        }
        else
        { /* block id: 185 */
            return p_11;
        }
    }
    else
    { /* block id: 188 */
        int32_t l_284 = 4L;
        int32_t l_285[9] = {0x9B259799L,0x9B259799L,0x9B259799L,0x9B259799L,0x9B259799L,0x9B259799L,0x9B259799L,0x9B259799L,0x9B259799L};
        int i;
        l_250[1] = (safe_rshift_func_uint8_t_u_u(((~((safe_rshift_func_int8_t_s_u((safe_sub_func_uint32_t_u_u(((((+p_9) < 250UL) == 1L) >= 0xE9B1BF55L), l_240)), 3)) || g_180)) , p_9), l_283));
        l_285[0] = (0x1E83L < l_284);
    }
    l_250[2] = (safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((((safe_div_func_int8_t_s_s((((safe_rshift_func_int16_t_s_u(((g_164 && 0UL) | g_125), g_3)) ^ g_26) && l_270), 0x26L)) , l_250[1]) != p_9), g_66)), 0xF9L));
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_25 g_26 g_4 g_66 g_94 g_125 g_164 g_160 g_180 g_158 g_156
 * writes: g_25 g_26 g_66 g_125 g_164 g_160 g_180 g_94 g_158
 */
static int16_t  func_13(int32_t  p_14, uint32_t  p_15)
{ /* block id: 8 */
    int32_t l_21 = 0xC3997B09L;
    int32_t l_192 = 0xEDB9B34AL;
    int32_t l_210[1][1];
    int8_t l_212[6][1][6] = {{{1L,1L,0xB6L,7L,0xB6L,1L}},{{0xB6L,(-1L),7L,7L,(-1L),0xB6L}},{{1L,0xB6L,7L,0xB6L,1L,1L}},{{0xDEL,0xB6L,0xB6L,0xDEL,(-1L),0xDEL}},{{0xDEL,(-1L),0xDEL,0xB6L,0xB6L,0xDEL}},{{1L,1L,0xB6L,7L,0xB6L,1L}}};
    uint32_t l_213 = 0x3934F947L;
    int32_t l_230 = 0x8AC3F262L;
    int32_t l_231 = 0x136BF034L;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_210[i][j] = 2L;
    }
    if ((func_16((1UL || g_3), l_21, g_3, l_21) , g_160[9][1]))
    { /* block id: 93 */
        int16_t l_187 = (-8L);
        g_160[2][0] ^= ((g_158 || 0x17L) >= l_21);
        for (p_14 = 0; (p_14 > (-9)); p_14--)
        { /* block id: 97 */
            int8_t l_185 = 0xDAL;
            l_185 = (-1L);
            return g_164;
        }
        if ((g_160[9][1] && 0x023438911B318C58LL))
        { /* block id: 101 */
            int8_t l_186 = 0xB9L;
            return l_186;
        }
        else
        { /* block id: 103 */
            return l_187;
        }
    }
    else
    { /* block id: 106 */
        uint8_t l_193 = 0UL;
        g_94 ^= ((((safe_sub_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u(((l_192 < g_26) , p_15), l_21)), g_164)) > p_14) | p_15) , l_192);
        ++l_193;
        g_160[2][0] = l_192;
        l_21 &= (-1L);
    }
    for (p_14 = (-18); (p_14 > 6); ++p_14)
    { /* block id: 114 */
        g_26 &= (safe_rshift_func_uint8_t_u_u(((+(safe_rshift_func_int16_t_s_u(g_158, g_160[5][1]))) | 0x23397FCBD7A91C2ELL), g_125));
    }
    if ((~0x625639F1L))
    { /* block id: 117 */
        uint64_t l_207 = 0x2E68C3BF28D7A2F4LL;
        int32_t l_208 = 9L;
        int32_t l_209 = 3L;
        int32_t l_211[6];
        int i;
        for (i = 0; i < 6; i++)
            l_211[i] = 0x00B97599L;
        for (p_15 = 0; (p_15 > 39); ++p_15)
        { /* block id: 120 */
            uint8_t l_206 = 0x31L;
            l_206 = 0xFC1BAD84L;
            l_207 = p_15;
            if (l_21)
                break;
            if (g_156)
                continue;
        }
lbl_222:
        --l_213;
        if (((safe_rshift_func_uint8_t_u_u((((((safe_unary_minus_func_uint16_t_u((+(p_15 > 0xF4BBL)))) != 0L) ^ 0xADE1354FL) , 0xFD3CF241C91009C5LL) & 0x1794BD295D964B4BLL), 4)) >= 4294967287UL))
        { /* block id: 127 */
            int32_t l_221 = 0x3EDA46FEL;
            l_221 = ((((safe_unary_minus_func_int16_t_s(p_14)) == 0L) | g_94) , 0xDD47E45AL);
        }
        else
        { /* block id: 129 */
            if (l_213)
                goto lbl_222;
        }
    }
    else
    { /* block id: 132 */
        const uint32_t l_229 = 0UL;
        g_160[4][0] |= (p_15 & g_164);
        for (g_158 = 0; (g_158 <= (-16)); g_158--)
        { /* block id: 136 */
            uint8_t l_225 = 0x80L;
            l_225 = 1L;
            if (p_15)
                break;
            g_26 = ((safe_lshift_func_uint16_t_u_u(((safe_unary_minus_func_uint32_t_u(g_156)) , l_229), 9)) < p_15);
        }
        l_230 = g_160[3][1];
    }
    l_21 |= l_210[0][0];
    return l_231;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_26 g_4 g_66 g_94 g_125 g_3 g_164 g_160 g_180
 * writes: g_25 g_26 g_66 g_125 g_164 g_160 g_180
 */
static uint64_t  func_16(int64_t  p_17, uint32_t  p_18, uint32_t  p_19, int32_t  p_20)
{ /* block id: 9 */
    uint64_t l_24 = 0x11EC1FCC8AF95342LL;
    uint32_t l_139 = 0x319732ECL;
    int32_t l_152 = 0x1F99661AL;
    int32_t l_153 = (-1L);
    int32_t l_154 = 0L;
    int32_t l_155 = (-9L);
    int32_t l_157 = 0xDFC38D33L;
    int32_t l_159 = (-9L);
    int32_t l_161 = 0x952D19C5L;
    int32_t l_162 = 1L;
    int32_t l_163 = (-1L);
    int32_t l_179 = 0x10C5E2D5L;
    for (p_18 = 0; (p_18 > 53); p_18 = safe_add_func_uint8_t_u_u(p_18, 5))
    { /* block id: 12 */
        uint8_t l_31 = 0xC5L;
        int32_t l_32[2][8] = {{(-7L),0xB137D370L,(-7L),0xB137D370L,(-7L),0xB137D370L,(-7L),0xB137D370L},{(-7L),0xB137D370L,(-7L),0xB137D370L,(-7L),0xB137D370L,(-7L),0xB137D370L}};
        int i, j;
        if (p_20)
        { /* block id: 13 */
            if (p_17)
                break;
            g_25 |= l_24;
        }
        else
        { /* block id: 16 */
            g_26 = g_25;
            l_32[0][4] = (safe_sub_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u(g_25, l_31)), g_26));
            l_32[1][1] |= (!((func_34((safe_sub_func_uint16_t_u_u((0x79L < l_31), l_24)), p_18, l_24, p_18) || 0x9726L) , p_18));
        }
        if ((~(safe_mod_func_int64_t_s_s((safe_sub_func_int32_t_s_s(g_4, g_66)), l_24))))
        { /* block id: 65 */
            return g_66;
        }
        else
        { /* block id: 67 */
            uint64_t l_140 = 18446744073709551615UL;
            int32_t l_141 = 0x8A2DDD91L;
            p_20 = g_26;
            l_141 &= ((safe_add_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_u(((((safe_div_func_uint8_t_u_u(p_19, p_20)) , l_139) , p_18) <= l_140), 5)) ^ l_32[0][4]), l_24)) && 0x48D72D2710542879LL);
            p_20 = (safe_lshift_func_int16_t_s_u((+(safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(((((safe_unary_minus_func_int64_t_s((safe_mul_func_uint16_t_u_u((l_141 | g_3), 0x201BL)))) || l_140) && 0UL) | (-1L)), g_94)), g_25))), l_140));
        }
        return g_125;
    }
    --g_164;
    for (p_20 = 0; (p_20 <= 2); p_20 += 1)
    { /* block id: 77 */
        int64_t l_172 = 0x5295FBE9E82CB70CLL;
        int32_t l_175 = 0x1EBD87E6L;
        int32_t l_176[2];
        int i;
        for (i = 0; i < 2; i++)
            l_176[i] = 0x1BA22EFFL;
        for (g_25 = 0; (g_25 <= 2); g_25 += 1)
        { /* block id: 80 */
            int i, j;
            g_160[(g_25 + 2)][p_20] = (safe_add_func_uint8_t_u_u(g_160[(g_25 + 2)][p_20], g_160[g_25][g_25]));
        }
        for (g_26 = 2; (g_26 >= 0); g_26 -= 1)
        { /* block id: 85 */
            int32_t l_171 = (-7L);
            int16_t l_177 = 0x6E1CL;
            int32_t l_178 = 0x5E602B37L;
            int i, j;
            l_172 ^= ((safe_rshift_func_int16_t_s_u((((g_160[(p_20 + 6)][p_20] , p_17) <= p_17) , l_171), l_171)) >= g_3);
            l_175 &= ((safe_rshift_func_int8_t_s_s((g_160[(p_20 + 6)][p_20] == (-4L)), l_159)) > 0L);
            g_180--;
            return p_18;
        }
    }
    return p_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_66 g_26 g_25 g_94 g_125
 * writes: g_66 g_26 g_125
 */
static uint16_t  func_34(int32_t  p_35, const int16_t  p_36, int32_t  p_37, int64_t  p_38)
{ /* block id: 19 */
    uint16_t l_41 = 0UL;
    int32_t l_54 = (-1L);
    int16_t l_76 = (-1L);
    int32_t l_93 = (-6L);
    int32_t l_103 = 0x567EB876L;
    int32_t l_104[9] = {0x0B13A75CL,0x0B13A75CL,0x0B13A75CL,0x0B13A75CL,0x0B13A75CL,0x0B13A75CL,0x0B13A75CL,0x0B13A75CL,0x0B13A75CL};
    uint64_t l_112 = 0xC109E68FEE3948B2LL;
    int i;
    l_41 = p_35;
    l_54 ^= (safe_sub_func_int32_t_s_s(((safe_mul_func_uint8_t_u_u(((safe_sub_func_int8_t_s_s((safe_mod_func_int32_t_s_s((safe_sub_func_int64_t_s_s((safe_sub_func_int64_t_s_s(((g_4 , 1UL) >= 4294967295UL), p_36)), l_41)), g_4)), g_4)) != l_41), 1UL)) >= l_41), p_37));
    if ((safe_sub_func_uint32_t_u_u(7UL, l_41)))
    { /* block id: 22 */
        uint16_t l_59[5] = {0xEC37L,0xEC37L,0xEC37L,0xEC37L,0xEC37L};
        int32_t l_63 = 0xC0429090L;
        int i;
        l_54 = p_36;
        for (p_37 = 0; (p_37 <= (-4)); --p_37)
        { /* block id: 26 */
            uint64_t l_62 = 18446744073709551615UL;
            l_59[2]--;
            l_63 = ((p_36 , l_62) & (-1L));
            g_66 = ((safe_rshift_func_uint8_t_u_s((l_41 , 0x17L), l_62)) >= 0L);
            l_54 = (safe_unary_minus_func_int8_t_s(((((safe_rshift_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(g_66, 0xCC76L)) , 0UL), 15)) , p_36) & g_66) < p_36)));
        }
    }
    else
    { /* block id: 32 */
        uint64_t l_84 = 2UL;
        int32_t l_86[8] = {0x92507BCDL,0x92507BCDL,0x92507BCDL,0x92507BCDL,0x92507BCDL,0x92507BCDL,0x92507BCDL,0x92507BCDL};
        uint8_t l_95 = 0x48L;
        int8_t l_124 = 0x7EL;
        int i;
lbl_77:
        p_37 = p_36;
        if ((((safe_mul_func_int8_t_s_s(((((safe_lshift_func_uint16_t_u_s((0xB4BC0730L == p_36), 13)) , p_38) < l_54) >= l_76), p_38)) & l_54) < g_26))
        { /* block id: 34 */
            if (l_54)
                goto lbl_77;
            g_26 = ((((-4L) >= g_66) ^ 0xEA4F543A9B16E5D1LL) && g_26);
        }
        else
        { /* block id: 37 */
            uint32_t l_85 = 0xE2CD5B9AL;
            l_85 = ((safe_rshift_func_int16_t_s_u((safe_lshift_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((l_84 || (-10L)) , g_66), 0xB39CL)), 13)), p_38)) <= l_84);
            l_86[5] = l_85;
            return l_76;
        }
        if ((((((p_35 && 0xB29A1B0FL) == 0x54B5BC1773A67FE4LL) >= p_36) > 8UL) & g_25))
        { /* block id: 42 */
            int64_t l_91 = 0L;
            int32_t l_92 = 0xF357798EL;
            p_37 = ((safe_rshift_func_uint8_t_u_s((safe_mul_func_int16_t_s_s(p_37, 0xBD99L)), 0)) > 0L);
            if (l_41)
                goto lbl_98;
lbl_98:
            l_95--;
            l_54 = (safe_rshift_func_uint16_t_u_s((p_37 >= g_25), p_35));
            return p_37;
        }
        else
        { /* block id: 48 */
            uint16_t l_105[7] = {0xE82DL,0xE82DL,0xE82DL,0xE82DL,0xE82DL,0xE82DL,0xE82DL};
            int i;
            p_37 = (safe_add_func_int16_t_s_s((l_86[5] == p_37), 65535UL));
            l_105[2]--;
        }
        if (g_94)
        { /* block id: 52 */
            uint32_t l_108 = 0xA35DC676L;
            l_104[5] = (0xDA5FL != 0x52C7L);
            p_37 |= l_108;
        }
        else
        { /* block id: 55 */
            const int64_t l_123 = 0x0FED72739EBEB9EELL;
            l_112 = (((safe_sub_func_int8_t_s_s((~l_104[5]), g_26)) , l_95) | p_38);
            p_37 = ((safe_lshift_func_uint16_t_u_u((safe_div_func_uint64_t_u_u((safe_add_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u(g_66, 0L)) > 0x18DFC5AEL), p_38)), l_86[5])), p_37)) && 0x42L);
            g_66 &= ((((safe_mul_func_int8_t_s_s(l_95, l_123)) , l_84) >= 0xB7496171L) && g_94);
            g_125++;
        }
    }
    return l_54;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_160[i][j], "g_160[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_180, "g_180", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 98
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 137
   depth: 2, occurrence: 26
   depth: 3, occurrence: 12
   depth: 4, occurrence: 10
   depth: 5, occurrence: 4
   depth: 6, occurrence: 4
   depth: 7, occurrence: 4
   depth: 8, occurrence: 3
   depth: 9, occurrence: 6
   depth: 11, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 230
XXX times a non-volatile is write: 88
XXX times a volatile is read: 12
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 140
XXX percentage of non-volatile access: 95.5

XXX forward jumps: 1
XXX backward jumps: 3

XXX stmts: 134
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 39
   depth: 2, occurrence: 76

XXX percentage a fresh-made variable is used: 20.2
XXX percentage an existing variable is used: 79.8
********************* end of statistics **********************/

