/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1497470527450158460
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const uint16_t g_5 = 0UL;
static uint32_t g_6 = 0x34EEA2A3L;
static uint32_t g_12[1] = {0x8018D9DCL};
static uint64_t g_15 = 0UL;
static uint32_t g_20[2] = {8UL,8UL};
static int32_t g_29[8] = {1L,1L,1L,1L,1L,1L,1L,1L};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(uint32_t  p_3);
static int32_t  func_7(uint16_t  p_8);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_15 g_20
 * writes: g_6 g_12 g_15 g_20 g_29
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_4 = 18446744073709551606UL;
    int32_t l_28 = 0x8D08F492L;
    l_28 |= func_2(l_4);
    g_29[7] = 1L;
    l_28 = (safe_rshift_func_uint8_t_u_s(0x85L, 2));
    return g_20[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_15
 * writes: g_6 g_12 g_15 g_20
 */
static int32_t  func_2(uint32_t  p_3)
{ /* block id: 1 */
    uint64_t l_21 = 0x4A7D2AE857B1A094LL;
    int32_t l_27 = (-1L);
    g_6 ^= (((g_5 , 0xA39EL) , 4294967289UL) | g_5);
    if (g_5)
        goto lbl_22;
lbl_22:
    l_21 = func_7(((g_6 && 0x8EB98764L) , 3UL));
    l_27 = (safe_lshift_func_int8_t_s_s((((safe_rshift_func_int8_t_s_u(l_21, 1)) & l_21) || (-1L)), l_21));
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_15
 * writes: g_12 g_15 g_20
 */
static int32_t  func_7(uint16_t  p_8)
{ /* block id: 3 */
    uint8_t l_11 = 0xA1L;
    int32_t l_18 = 0x6F25DB2BL;
    g_12[0] = ((safe_div_func_int64_t_s_s((l_11 | l_11), g_5)) != 0xC54CL);
    g_15 &= (((safe_rshift_func_int16_t_s_s(p_8, 11)) ^ 7UL) | l_11);
    l_18 ^= ((safe_rshift_func_int8_t_s_u(p_8, 2)) && p_8);
    g_20[1] = (((!(l_11 , 255UL)) > l_11) | 8L);
    return l_18;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15, "g_15", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_20[i], "g_20[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_29[i], "g_29[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 5
   depth: 5, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 19
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 14

XXX percentage a fresh-made variable is used: 41.4
XXX percentage an existing variable is used: 58.6
********************* end of statistics **********************/

