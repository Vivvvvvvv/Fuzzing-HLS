/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11361022438446340628
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint64_t  f0;
   uint32_t  f1;
   int8_t  f2;
   const int32_t  f3;
   volatile uint64_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_33 = 0xAB653B1DL;/* VOLATILE GLOBAL g_33 */
static uint64_t g_38[9] = {0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL,0xED1D25BB0866193FLL};
static volatile struct S0 g_43 = {0xA72D50FA8FAD7494LL,0xFD996437L,0x7CL,0x14A3A6D7L,0x04549C4B05EF1355LL};/* VOLATILE GLOBAL g_43 */
static int64_t g_52[3][1] = {{0xFF05C8A2DB6377F0LL},{0xFF05C8A2DB6377F0LL},{0xFF05C8A2DB6377F0LL}};
static uint32_t g_74[8] = {0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL};
static uint64_t g_87[8][5] = {{1UL,0x796D0A3AFD543CBDLL,0x796D0A3AFD543CBDLL,1UL,0x796D0A3AFD543CBDLL},{0x7A95E77405739219LL,0x12577EDFD6319DC0LL,0xBA517386F7313610LL,0x12577EDFD6319DC0LL,0x7A95E77405739219LL},{0x796D0A3AFD543CBDLL,1UL,0x796D0A3AFD543CBDLL,0x796D0A3AFD543CBDLL,1UL},{0x7A95E77405739219LL,6UL,0xCB67721BC9AF00AFLL,0x12577EDFD6319DC0LL,0xCB67721BC9AF00AFLL},{1UL,1UL,1UL,1UL,1UL},{0xCB67721BC9AF00AFLL,6UL,0xBA517386F7313610LL,0x3B64D7EEACC20013LL,0xCB67721BC9AF00AFLL},{0x796D0A3AFD543CBDLL,1UL,1UL,0x796D0A3AFD543CBDLL,1UL},{0xCB67721BC9AF00AFLL,6UL,0x7A95E77405739219LL,6UL,0xCB67721BC9AF00AFLL}};
static int64_t g_93[2][6] = {{(-1L),0x0E05D1EE040EEAA4LL,(-1L),(-1L),0x0E05D1EE040EEAA4LL,(-1L)},{(-1L),0x0E05D1EE040EEAA4LL,(-1L),(-1L),0x0E05D1EE040EEAA4LL,(-1L)}};
static struct S0 g_94 = {8UL,7UL,0xB1L,-4L,6UL};/* VOLATILE GLOBAL g_94 */
static uint64_t g_100[3] = {0xFD02479DA46A1361LL,0xFD02479DA46A1361LL,0xFD02479DA46A1361LL};
static volatile uint8_t g_102 = 1UL;/* VOLATILE GLOBAL g_102 */
static volatile int16_t g_106[5] = {(-4L),(-4L),(-4L),(-4L),(-4L)};
static int16_t g_109 = 0x68DEL;
static uint32_t g_110 = 0x9EEE8C1BL;
static uint32_t g_111 = 4294967295UL;
static volatile int32_t g_112 = 7L;/* VOLATILE GLOBAL g_112 */
static int8_t g_115 = 0xB0L;
static uint32_t g_121 = 0UL;
static int64_t g_123 = 0xFAB55DA1D3BC2F6DLL;
static int8_t g_126 = (-2L);
static volatile uint16_t g_127 = 5UL;/* VOLATILE GLOBAL g_127 */
static volatile uint32_t g_128 = 0UL;/* VOLATILE GLOBAL g_128 */
static uint16_t g_134[1] = {6UL};
static volatile uint32_t g_137 = 5UL;/* VOLATILE GLOBAL g_137 */
static uint64_t g_153 = 0x7C066171E037CFBBLL;
static volatile uint32_t g_156 = 0xFB0DB9FFL;/* VOLATILE GLOBAL g_156 */
static volatile int64_t g_159 = 0x6BB71A4F7F7094B0LL;/* VOLATILE GLOBAL g_159 */
static uint32_t g_161 = 0xD9D0DECCL;
static volatile int16_t g_164 = 0xF10CL;/* VOLATILE GLOBAL g_164 */
static volatile uint64_t g_165 = 0xBE6BB7537BB743FELL;/* VOLATILE GLOBAL g_165 */
static int64_t g_171 = 0xBB1848449B04C19ELL;
static volatile uint32_t g_172 = 4294967295UL;/* VOLATILE GLOBAL g_172 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int64_t  func_11(uint8_t  p_12, uint32_t  p_13);
static uint8_t  func_14(int64_t  p_15, uint32_t  p_16, uint64_t  p_17, int32_t  p_18);
static struct S0  func_21(uint8_t  p_22, const int32_t  p_23, int64_t  p_24, uint32_t  p_25, int8_t  p_26);
static uint8_t  func_27(const int32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_33 g_38 g_43 g_52 g_74 g_87 g_93 g_94 g_100 g_102 g_110 g_115 g_128 g_106 g_137 g_156 g_165 g_172
 * writes: g_33 g_38 g_74 g_87 g_93 g_100 g_102 g_106 g_109 g_111 g_112 g_115 g_121 g_123 g_126 g_127 g_128 g_134 g_137 g_153 g_94.f1 g_156 g_159 g_161 g_165 g_94.f2 g_171 g_172
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2 = (-1L);
    int32_t l_135 = (-1L);
    int32_t l_136[6][1];
    int i, j;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_136[i][j] = 0L;
    }
    if ((l_2 != l_2))
    { /* block id: 1 */
        const uint64_t l_29[7] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL};
        const int8_t l_51 = 0xDBL;
        int16_t l_120 = 0x4ABBL;
        int i;
        for (l_2 = 0; (l_2 != 28); ++l_2)
        { /* block id: 4 */
            g_121 = (safe_div_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((safe_sub_func_int64_t_s_s(func_11(func_14(((safe_mod_func_uint32_t_u_u(((((func_21(func_27(l_29[3]), l_51, l_2, g_52[0][0], g_52[1][0]) , l_2) , l_2) , l_2) >= g_94.f3), l_2)) != 0xC952145FL), l_2, g_94.f2, g_94.f1), g_94.f3), 0x4A185305F7132E54LL)), l_120)), g_94.f3));
        }
        if (l_120)
        { /* block id: 74 */
            int8_t l_122 = 8L;
            g_123 = (0x6EL != l_122);
            g_126 = (safe_sub_func_uint32_t_u_u((1L ^ l_2), 0x0E7D168DL));
        }
        else
        { /* block id: 77 */
            int8_t l_133 = 3L;
            g_127 = 0xC65D3447L;
            g_128++;
            g_134[0] = (safe_sub_func_uint64_t_u_u(g_106[4], l_133));
        }
        g_137++;
    }
    else
    { /* block id: 83 */
        uint32_t l_144[2][1][4] = {{{18446744073709551606UL,18446744073709551606UL,8UL,18446744073709551606UL}},{{18446744073709551606UL,1UL,1UL,18446744073709551606UL}}};
        volatile int32_t l_145 = 0L;/* VOLATILE GLOBAL l_145 */
        uint16_t l_148 = 2UL;
        int i, j, k;
        l_145 = (((safe_mul_func_int8_t_s_s((safe_add_func_uint16_t_u_u(l_136[5][0], l_144[1][0][2])), g_115)) > g_87[4][3]) , g_106[4]);
        l_136[3][0] &= ((safe_mul_func_int8_t_s_s(l_148, 0xC5L)) == 18446744073709551615UL);
        g_153 = (safe_mod_func_uint32_t_u_u(((safe_sub_func_uint16_t_u_u(g_102, l_2)) > 247UL), 4294967291UL));
        for (g_94.f1 = (-24); (g_94.f1 > 45); g_94.f1 = safe_add_func_int32_t_s_s(g_94.f1, 1))
        { /* block id: 89 */
            g_156--;
        }
    }
    g_159 = g_94.f4;
    if (g_43.f1)
    { /* block id: 94 */
        int16_t l_160[4][7][7] = {{{1L,(-1L),(-1L),0L,(-2L),1L,5L},{3L,(-8L),0x37D7L,0x99E4L,(-5L),3L,0x9889L},{1L,0L,(-1L),(-1L),0L,1L,0x92E3L},{3L,(-5L),0x99E4L,0x37D7L,(-8L),3L,1L},{1L,(-2L),0L,(-1L),(-1L),1L,0x354AL},{0xF1EAL,(-5L),1L,0x99E4L,0xFF18L,0xF1EAL,1L},{0x6375L,0L,0xCFE6L,0L,(-1L),0x6375L,0x92E3L}},{{0xD73FL,(-8L),1L,1L,(-8L),0xD73FL,0x9889L},{0x6375L,(-1L),0L,0xCFE6L,0L,0x6375L,5L},{0xF1EAL,0xFF18L,0x99E4L,1L,(-5L),0xF1EAL,0x76DEL},{1L,(-1L),(-1L),0L,(-2L),1L,5L},{3L,(-8L),0x37D7L,0x99E4L,(-5L),3L,0x9889L},{1L,0L,(-1L),(-1L),0L,1L,0x92E3L},{3L,(-5L),0x99E4L,0x37D7L,(-8L),3L,1L}},{{1L,(-2L),0L,(-1L),(-1L),1L,0x354AL},{0xF1EAL,(-5L),1L,0x99E4L,0xFF18L,0xF1EAL,1L},{0x6375L,0L,0xCFE6L,0L,(-1L),0x6375L,0x92E3L},{0xD73FL,(-8L),1L,1L,(-8L),0xD73FL,0x9889L},{0x6375L,(-1L),0L,0xCFE6L,0L,0x6375L,5L},{0xF1EAL,0xFF18L,0x99E4L,1L,(-5L),0xF1EAL,0x76DEL},{1L,0xCFE6L,0x92E3L,0xB2C2L,0L,(-10L),0x962EL}},{{0x8564L,5L,0x189EL,0x4E4CL,0x37D7L,0x8564L,0x2842L},{1L,8L,0x92E3L,0x92E3L,8L,1L,0xB621L},{0x8564L,0x37D7L,0x4E4CL,0x189EL,5L,0x8564L,0x397AL},{(-10L),0L,0xB2C2L,0x92E3L,0xCFE6L,(-10L),0x24A1L},{0x46D1L,0x37D7L,0x9889L,0x4E4CL,0x99E4L,0x46D1L,0x397AL},{0x8992L,8L,0xB7A7L,0xB2C2L,0xCFE6L,0x8992L,0xB621L},{8L,5L,0x9889L,0x9889L,5L,8L,0x2842L}}};
        int32_t l_162 = 1L;
        int64_t l_163[3];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_163[i] = (-1L);
        l_160[0][4][4] = 0L;
        g_161 = l_136[5][0];
        ++g_165;
    }
    else
    { /* block id: 98 */
        for (g_94.f2 = 0; (g_94.f2 <= 0); g_94.f2 += 1)
        { /* block id: 101 */
            int32_t l_170[9] = {0xEB6903EBL,0xEB6903EBL,2L,0xEB6903EBL,0xEB6903EBL,2L,0xEB6903EBL,0xEB6903EBL,2L};
            int i;
            g_171 = ((safe_add_func_int64_t_s_s(l_136[0][0], (-8L))) >= l_170[6]);
            if (g_106[0])
                continue;
            g_172 &= (-2L);
            l_170[4] = 0xE4C78807L;
        }
    }
    return g_87[4][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_115 g_100
 * writes: g_111 g_112 g_115
 */
static int64_t  func_11(uint8_t  p_12, uint32_t  p_13)
{ /* block id: 61 */
    g_111 = p_13;
    g_112 = 9L;
    for (p_13 = 0; (p_13 != 53); ++p_13)
    { /* block id: 66 */
        int32_t l_116 = 0x1B8D994FL;
        g_115 ^= p_12;
        l_116 ^= g_115;
        l_116 = (safe_unary_minus_func_int32_t_s(((safe_div_func_uint8_t_u_u(0x78L, 251UL)) , p_13)));
    }
    return g_100[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_110
 * writes: g_38 g_109
 */
static uint8_t  func_14(int64_t  p_15, uint32_t  p_16, uint64_t  p_17, int32_t  p_18)
{ /* block id: 57 */
    for (p_15 = 0; p_15 < 9; p_15 += 1)
    {
        g_38[p_15] = 18446744073709551606UL;
    }
    g_109 = (safe_add_func_int64_t_s_s(p_17, p_16));
    return g_110;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_43.f4 g_52 g_43.f0 g_43 g_74 g_87 g_33 g_93 g_94 g_100 g_102
 * writes: g_74 g_87 g_93 g_100 g_102 g_106
 */
static struct S0  func_21(uint8_t  p_22, const int32_t  p_23, int64_t  p_24, uint32_t  p_25, int8_t  p_26)
{ /* block id: 22 */
    uint64_t l_57 = 5UL;
    int32_t l_58 = 0x22489AFFL;
lbl_105:
    l_58 = (safe_mod_func_uint8_t_u_u(((safe_sub_func_uint64_t_u_u(l_57, g_38[5])) != g_43.f4), g_52[1][0]));
    if (((safe_lshift_func_int8_t_s_u((safe_add_func_int64_t_s_s(((safe_mul_func_uint16_t_u_u((0x61L == g_43.f0), l_57)) < g_38[5]), 0xF3E63D4D864B91BFLL)), p_26)) >= g_38[5]))
    { /* block id: 24 */
        int32_t l_73 = 0xF882D778L;
        for (l_57 = 0; (l_57 > 44); l_57 = safe_add_func_uint32_t_u_u(l_57, 7))
        { /* block id: 27 */
            int32_t l_75 = (-2L);
            g_74[1] = (((((safe_rshift_func_uint16_t_u_u((safe_add_func_int8_t_s_s(((safe_mul_func_int8_t_s_s(0L, 0UL)) & l_58), (-2L))), p_24)) && 0x1AA8L) | 1UL) , g_43.f4) >= l_73);
            if (p_23)
                continue;
            l_73 |= (l_75 == 18446744073709551615UL);
            return g_43;
        }
        for (p_26 = 0; (p_26 == 23); p_26++)
        { /* block id: 35 */
            int16_t l_86 = 8L;
            g_87[4][3] &= (safe_div_func_int32_t_s_s(((safe_add_func_int64_t_s_s(((((((((((safe_mul_func_uint8_t_u_u((((safe_mod_func_int16_t_s_s((((p_24 , l_58) || 248UL) , l_86), 2UL)) | 0x77E47599L) ^ p_24), g_43.f2)) , 0x95891F92L) , p_23) <= g_74[0]) , p_26) , g_74[1]) , g_43.f0) < g_38[5]) && l_86) > (-5L)), g_38[0])) , g_52[0][0]), p_26));
            g_93[1][2] ^= ((safe_mod_func_uint64_t_u_u((!(((safe_rshift_func_int16_t_s_u((((g_38[6] >= g_33) ^ 0xBCF7L) & (-2L)), p_26)) , p_23) <= g_38[5])), 18446744073709551615UL)) < l_58);
            return g_94;
        }
        l_58 ^= (safe_sub_func_uint8_t_u_u(p_24, g_94.f2));
    }
    else
    { /* block id: 41 */
        int32_t l_99 = (-1L);
        g_100[2] ^= (safe_mul_func_uint16_t_u_u(65531UL, l_99));
        for (p_24 = 0; (p_24 <= 2); p_24 += 1)
        { /* block id: 45 */
            int64_t l_101 = 0xFAE8CD77E09021D5LL;
            ++g_102;
        }
        if (p_25)
        { /* block id: 48 */
            return g_43;
        }
        else
        { /* block id: 50 */
            if (g_94.f1)
                goto lbl_105;
            g_106[4] = 6L;
        }
        l_99 = (g_43.f2 >= l_99);
    }
    return g_94;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_38 g_43
 * writes: g_33 g_38
 */
static uint8_t  func_27(const int32_t  p_28)
{ /* block id: 5 */
    int16_t l_30 = 1L;
    int32_t l_31 = 1L;
    int32_t l_32 = (-9L);
    l_30 = 0L;
    g_33--;
    for (l_30 = 29; (l_30 < (-4)); l_30--)
    { /* block id: 10 */
        int32_t l_44 = 0x418EB0BAL;
        g_38[5]--;
        for (l_32 = 0; (l_32 <= (-25)); l_32 = safe_sub_func_int64_t_s_s(l_32, 2))
        { /* block id: 14 */
            uint32_t l_45 = 6UL;
            int32_t l_48 = 0xED1B4B1CL;
            l_31 = ((g_43 , g_43.f2) <= g_38[5]);
            --l_45;
            l_48 |= (0x967268F57F54AB10LL & l_45);
        }
    }
    l_31 = (safe_lshift_func_uint8_t_u_s(((((l_30 ^ 7UL) <= l_32) || l_32) , l_32), 6));
    return p_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_38[i], "g_38[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_43.f0, "g_43.f0", print_hash_value);
    transparent_crc(g_43.f1, "g_43.f1", print_hash_value);
    transparent_crc(g_43.f2, "g_43.f2", print_hash_value);
    transparent_crc(g_43.f3, "g_43.f3", print_hash_value);
    transparent_crc(g_43.f4, "g_43.f4", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_52[i][j], "g_52[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_74[i], "g_74[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_87[i][j], "g_87[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_93[i][j], "g_93[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_94.f0, "g_94.f0", print_hash_value);
    transparent_crc(g_94.f1, "g_94.f1", print_hash_value);
    transparent_crc(g_94.f2, "g_94.f2", print_hash_value);
    transparent_crc(g_94.f3, "g_94.f3", print_hash_value);
    transparent_crc(g_94.f4, "g_94.f4", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_100[i], "g_100[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_102, "g_102", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_106[i], "g_106[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_109, "g_109", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_126, "g_126", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_134[i], "g_134[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_153, "g_153", print_hash_value);
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_161, "g_161", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_165, "g_165", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 58
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 22
breakdown:
   depth: 1, occurrence: 76
   depth: 2, occurrence: 18
   depth: 3, occurrence: 5
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 2
   depth: 20, occurrence: 1
   depth: 22, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 93
XXX times a non-volatile is write: 38
XXX times a volatile is read: 17
XXX    times read thru a pointer: 0
XXX times a volatile is write: 12
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 62
XXX percentage of non-volatile access: 81.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 67
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 23
   depth: 2, occurrence: 25

XXX percentage a fresh-made variable is used: 38.7
XXX percentage an existing variable is used: 61.3
********************* end of statistics **********************/

