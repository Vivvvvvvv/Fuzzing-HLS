/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1297196857850113234
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   int16_t  f1;
   int64_t  f2;
   volatile int32_t  f3;
   int32_t  f4;
   uint32_t  f5;
   volatile int32_t  f6;
   uint32_t  f7;
   uint16_t  f8;
   const int64_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_2[2][10] = {{65532UL,0x9C21L,7UL,7UL,0x9C21L,65532UL,0x9C21L,7UL,7UL,0x9C21L},{65532UL,0x9C21L,7UL,7UL,0x9C21L,65532UL,0x9C21L,7UL,7UL,0x9C21L}};
static int32_t g_40[9][2] = {{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L},{0xE4C12F69L,0xE4C12F69L}};
static int8_t g_53 = (-9L);
static int32_t g_82 = 0x2403636CL;
static volatile struct S0 g_112 = {0x623CC279L,0x0817L,8L,0x0B3DF572L,0x7C4FD0C6L,0xF6C93038L,0xEC31A112L,4294967288UL,65535UL,1L};/* VOLATILE GLOBAL g_112 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint32_t  func_6(uint64_t  p_7);
static uint16_t  func_10(int32_t  p_11, int64_t  p_12, int16_t  p_13, uint32_t  p_14, uint64_t  p_15);
static int32_t  func_22(int8_t  p_23, const int32_t  p_24, int32_t  p_25);
static uint64_t  func_27(uint32_t  p_28, int8_t  p_29, const uint16_t  p_30, uint32_t  p_31, uint8_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_40 g_53 g_82 g_112
 * writes: g_40 g_53
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_3 = 0x61D594D0L;
    int32_t l_70 = 1L;
    int32_t l_71[1];
    int64_t l_89 = (-1L);
    uint8_t l_91 = 247UL;
    uint8_t l_116 = 0x69L;
    int i;
    for (i = 0; i < 1; i++)
        l_71[i] = 0xE1B0F05BL;
    if ((((((0xE58D020BL == 1L) != g_2[1][0]) ^ l_3) || 18446744073709551615UL) && l_3))
    { /* block id: 1 */
        int32_t l_16 = 0xDB7758B3L;
        int32_t l_63 = 8L;
        int32_t l_72 = (-3L);
        uint32_t l_73[1][5] = {{0x9A233967L,0x9A233967L,0x9A233967L,0x9A233967L,0x9A233967L}};
        int i, j;
        for (l_3 = 0; (l_3 == 57); l_3++)
        { /* block id: 4 */
            int8_t l_17 = (-2L);
            uint32_t l_58 = 4294967295UL;
            int32_t l_60 = 0x309CE07BL;
            l_60 ^= ((func_6((((safe_rshift_func_int8_t_s_u(((func_10(l_16, l_17, l_3, g_2[1][0], l_16) != g_2[1][0]) , 8L), l_17)) ^ l_3) | l_58)) < 4L) & l_3);
        }
        if ((safe_add_func_uint64_t_u_u(l_3, 0xE216D7279364560FLL)))
        { /* block id: 40 */
            int8_t l_64 = 0x26L;
            l_63 = ((g_2[1][0] == l_16) ^ l_16);
            l_64 &= ((-2L) >= g_40[8][0]);
        }
        else
        { /* block id: 43 */
            uint8_t l_69 = 1UL;
            l_69 &= (((safe_mod_func_int32_t_s_s(((safe_add_func_uint64_t_u_u(g_53, g_2[1][3])) < (-1L)), g_2[0][2])) , g_2[1][0]) , 0x77D8654EL);
            g_40[1][0] = (g_2[1][0] == g_40[8][0]);
        }
        l_73[0][4]--;
        g_40[8][0] = l_71[0];
    }
    else
    { /* block id: 49 */
        uint16_t l_78[2];
        int32_t l_83[8][6][4] = {{{0xC74F2DDDL,1L,0xB5CE3A63L,6L},{(-6L),0x944068BDL,1L,(-6L)},{(-10L),(-6L),(-10L),0x484B0976L},{0xC74F2DDDL,0xB5CE3A63L,0x7FF15597L,0x944068BDL},{6L,(-10L),(-6L),0xB5CE3A63L},{0x179D1615L,1L,(-6L),0x434CA839L}},{{6L,1L,0x7FF15597L,0x7FF15597L},{0xC74F2DDDL,0xC74F2DDDL,(-10L),0x179D1615L},{(-10L),0x179D1615L,1L,(-6L)},{(-6L),(-1L),0xC74F2DDDL,1L},{0L,(-1L),0x03F479F8L,(-6L)},{(-1L),0x179D1615L,0x484B0976L,0x179D1615L}},{{0xD406D4EBL,0xC74F2DDDL,0xB5CE3A63L,0x7FF15597L},{0x484B0976L,1L,1L,0x434CA839L},{0x7FF15597L,1L,(-1L),0xB5CE3A63L},{0x7FF15597L,(-10L),1L,0x944068BDL},{0x484B0976L,0xB5CE3A63L,0xB5CE3A63L,0x484B0976L},{0xD406D4EBL,(-6L),0x484B0976L,(-6L)}},{{(-1L),0x944068BDL,0x03F479F8L,6L},{0L,0x434CA839L,0xC74F2DDDL,6L},{(-6L),0x944068BDL,1L,(-6L)},{(-10L),(-6L),(-10L),0x484B0976L},{0xC74F2DDDL,0xB5CE3A63L,0x7FF15597L,0x944068BDL},{6L,(-10L),(-6L),0xB5CE3A63L}},{{0x179D1615L,1L,(-6L),0x434CA839L},{6L,1L,0x7FF15597L,0x7FF15597L},{0xC74F2DDDL,0xC74F2DDDL,(-10L),0x179D1615L},{(-10L),0x179D1615L,1L,(-6L)},{(-6L),(-1L),0xC74F2DDDL,1L},{0L,(-1L),0x03F479F8L,(-6L)}},{{(-1L),0x179D1615L,0x484B0976L,0x179D1615L},{0xD406D4EBL,0xC74F2DDDL,0xB5CE3A63L,0x7FF15597L},{0x484B0976L,1L,1L,0x434CA839L},{0x7FF15597L,1L,(-1L),0xB5CE3A63L},{0x7FF15597L,(-10L),1L,0x944068BDL},{0x484B0976L,0xB5CE3A63L,0xB5CE3A63L,0x484B0976L}},{{0xD406D4EBL,(-6L),0x484B0976L,(-6L)},{(-1L),0x944068BDL,0x03F479F8L,6L},{0L,0x434CA839L,0xC74F2DDDL,6L},{(-6L),0x944068BDL,1L,(-6L)},{(-10L),(-6L),(-10L),0x484B0976L},{0xC74F2DDDL,0xB5CE3A63L,0x7FF15597L,0x944068BDL}},{{6L,(-10L),(-6L),0xB5CE3A63L},{0x179D1615L,1L,(-6L),0x434CA839L},{6L,1L,0x7FF15597L,0x7FF15597L},{0xC74F2DDDL,0xC74F2DDDL,(-10L),0x179D1615L},{(-10L),0x179D1615L,1L,(-6L)},{(-6L),(-1L),0xC74F2DDDL,1L}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_78[i] = 1UL;
        for (g_53 = 0; (g_53 <= (-1)); g_53--)
        { /* block id: 52 */
            l_70 = l_78[0];
            l_83[7][4][1] = ((~((((((safe_add_func_uint32_t_u_u((g_40[8][0] > 1L), l_78[0])) , (-1L)) & g_2[1][0]) <= g_82) < 0x4AE9C2412408B304LL) && 0x62F93B9B47BED265LL)) , 1L);
        }
        for (l_70 = (-2); (l_70 <= 9); l_70++)
        { /* block id: 58 */
            int8_t l_88 = 1L;
            int32_t l_90 = 0x02998B4EL;
            int32_t l_96 = 0xF81597F8L;
            l_71[0] = (((safe_mul_func_int16_t_s_s(g_2[1][0], 65531UL)) | g_2[1][0]) & g_40[2][0]);
            l_71[0] = g_53;
            l_91++;
            l_96 |= ((safe_add_func_int32_t_s_s(g_53, l_90)) >= l_83[7][4][1]);
        }
        g_40[8][0] = ((((safe_mul_func_uint16_t_u_u((((((safe_lshift_func_uint8_t_u_u(0x74L, 0)) >= l_89) <= l_70) , 0x04L) & g_53), 0UL)) > 0x9266L) != 18446744073709551615UL) > l_78[1]);
        g_40[8][0] = l_71[0];
    }
    if (l_89)
        goto lbl_101;
lbl_101:
    l_70 = ((0xFA6F56A42CAA49FFLL < l_71[0]) != l_70);
lbl_117:
    l_71[0] = (safe_sub_func_uint8_t_u_u((((safe_sub_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((safe_add_func_uint32_t_u_u((g_112 , g_40[4][0]), g_40[8][0])), g_82)), l_89)), g_82)) || 1L) < g_82), l_71[0]));
    for (l_89 = 0; (l_89 != (-27)); l_89--)
    { /* block id: 72 */
        uint64_t l_118[3];
        int i;
        for (i = 0; i < 3; i++)
            l_118[i] = 0xD06322BA3B598201LL;
        g_40[8][0] = (+l_116);
        if ((((l_116 && 0xA8L) < 0x6848F5E8599F0A17LL) && g_112.f8))
        { /* block id: 74 */
            if (l_3)
                goto lbl_117;
            return l_118[2];
        }
        else
        { /* block id: 77 */
            uint8_t l_119 = 0xB9L;
            l_70 = (((0xD644C502L && l_119) , 0x13L) <= g_112.f0);
            g_40[8][0] = l_118[2];
            return l_119;
        }
    }
    return l_70;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_6(uint64_t  p_7)
{ /* block id: 36 */
    uint8_t l_59 = 4UL;
    return l_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_40 g_53
 * writes: g_40 g_53
 */
static uint16_t  func_10(int32_t  p_11, int64_t  p_12, int16_t  p_13, uint32_t  p_14, uint64_t  p_15)
{ /* block id: 5 */
    const int32_t l_26 = 0L;
    uint32_t l_57 = 0xF9BD85DDL;
    for (p_12 = 0; (p_12 == (-9)); --p_12)
    { /* block id: 8 */
        uint32_t l_56 = 1UL;
        for (p_13 = 0; (p_13 < 5); p_13 = safe_add_func_int8_t_s_s(p_13, 8))
        { /* block id: 11 */
            l_56 = func_22(p_15, l_26, p_14);
        }
    }
    return l_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_40 g_53
 * writes: g_40 g_53
 */
static int32_t  func_22(int8_t  p_23, const int32_t  p_24, int32_t  p_25)
{ /* block id: 12 */
    uint64_t l_33 = 18446744073709551612UL;
    if ((func_27(p_24, l_33, l_33, g_2[1][3], p_24) , 1L))
    { /* block id: 21 */
        p_25 = (safe_mul_func_uint8_t_u_u((((~g_2[0][3]) <= p_23) , g_2[1][0]), l_33));
    }
    else
    { /* block id: 23 */
        int8_t l_52 = 0x21L;
        for (p_23 = 0; (p_23 > (-22)); --p_23)
        { /* block id: 26 */
            g_53 &= (((safe_mod_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u((((safe_rshift_func_uint8_t_u_s(p_25, l_52)) >= 0x1ED30906L) ^ 0L), g_40[0][0])) > l_52), 0x2D17L)) < p_23) < 0xA6L);
            g_40[8][0] = (safe_div_func_int8_t_s_s(g_2[1][5], p_23));
        }
    }
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_40
 * writes: g_40
 */
static uint64_t  func_27(uint32_t  p_28, int8_t  p_29, const uint16_t  p_30, uint32_t  p_31, uint8_t  p_32)
{ /* block id: 13 */
    for (p_28 = (-18); (p_28 < 42); p_28 = safe_add_func_uint64_t_u_u(p_28, 8))
    { /* block id: 16 */
        uint32_t l_36 = 3UL;
        --l_36;
        g_40[8][0] &= (safe_unary_minus_func_uint32_t_u(g_2[1][5]));
    }
    return p_30;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_40[i][j], "g_40[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_112.f0, "g_112.f0", print_hash_value);
    transparent_crc(g_112.f1, "g_112.f1", print_hash_value);
    transparent_crc(g_112.f2, "g_112.f2", print_hash_value);
    transparent_crc(g_112.f3, "g_112.f3", print_hash_value);
    transparent_crc(g_112.f4, "g_112.f4", print_hash_value);
    transparent_crc(g_112.f5, "g_112.f5", print_hash_value);
    transparent_crc(g_112.f6, "g_112.f6", print_hash_value);
    transparent_crc(g_112.f7, "g_112.f7", print_hash_value);
    transparent_crc(g_112.f8, "g_112.f8", print_hash_value);
    transparent_crc(g_112.f9, "g_112.f9", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 45
   depth: 2, occurrence: 12
   depth: 3, occurrence: 3
   depth: 4, occurrence: 5
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 3
   depth: 10, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 90
XXX times a non-volatile is write: 34
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 97.6

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 47
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 15
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 23.1
XXX percentage an existing variable is used: 76.9
********************* end of statistics **********************/

