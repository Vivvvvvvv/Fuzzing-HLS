/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1135452352895179752
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_2[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static volatile int32_t g_3 = 0x8B108F82L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0xD4EA6801L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6[6] = {0xEEE2FDE2L,0xEEE2FDE2L,1L,0xEEE2FDE2L,0xEEE2FDE2L,1L};
static int32_t g_7 = 0x9D94B4B1L;
static volatile uint16_t g_68 = 0xAF57L;/* VOLATILE GLOBAL g_68 */
static uint8_t g_119 = 0xFDL;
static uint64_t g_120 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int8_t  func_14(const uint32_t  p_15, int16_t  p_16);
static uint8_t  func_30(uint8_t  p_31, uint64_t  p_32, uint32_t  p_33, uint64_t  p_34, uint32_t  p_35);
static int32_t  func_79(const int16_t  p_80, const uint32_t  p_81, uint32_t  p_82, int32_t  p_83);
static uint64_t  func_98(uint16_t  p_99, int64_t  p_100);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_7 g_6 g_4 g_5 g_3 g_68 g_119 g_120
 * writes: g_7 g_3 g_68 g_6 g_119 g_5 g_120
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_9 = 0x6B77L;
    const int8_t l_55 = (-1L);
    int32_t l_59 = (-5L);
    int32_t l_60 = 0xC0AC77ACL;
    int32_t l_62 = 1L;
    if (g_2[6])
    { /* block id: 1 */
        uint32_t l_8 = 1UL;
        int32_t l_25 = 0xD4856CD8L;
        uint64_t l_58 = 18446744073709551614UL;
        int32_t l_61 = 1L;
        int32_t l_64 = 0x20B25230L;
        int32_t l_65 = 1L;
        for (g_7 = 1; (g_7 <= 9); g_7 += 1)
        { /* block id: 4 */
            int i;
            l_8 ^= g_2[g_7];
            return l_9;
        }
        if (((safe_lshift_func_uint8_t_u_u(g_6[3], g_2[7])) , 0x6890C544L))
        { /* block id: 8 */
            l_25 = (safe_sub_func_int8_t_s_s(func_14((safe_rshift_func_int16_t_s_s(0L, 1)), g_7), l_8));
        }
        else
        { /* block id: 18 */
            int8_t l_38 = (-1L);
            int32_t l_53 = 0xCC114FF6L;
            int32_t l_63 = (-1L);
            int32_t l_66 = 9L;
            int32_t l_67 = 0x20C2888AL;
            l_53 = ((safe_lshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_u(func_30(((safe_add_func_int16_t_s_s((((-7L) == l_9) | g_4), l_25)) , g_5), l_25, l_38, g_2[6], l_9), g_2[0])), g_2[7])) | l_38);
            g_3 = ((+l_55) && l_25);
            l_59 &= (safe_lshift_func_uint16_t_u_s(func_30(l_58, g_7, g_4, l_58, l_38), l_58));
            ++g_68;
        }
    }
    else
    { /* block id: 29 */
        int64_t l_71 = 0x5039A24791A13C53LL;
        int32_t l_72[3][2] = {{1L,1L},{5L,1L},{1L,5L}};
        int i, j;
        for (g_7 = 0; (g_7 <= 5); g_7 += 1)
        { /* block id: 32 */
            int32_t l_73 = (-1L);
            int32_t l_74[3];
            int32_t l_75 = 0x10705E77L;
            uint32_t l_76 = 0x359916A5L;
            int i;
            for (i = 0; i < 3; i++)
                l_74[i] = 0xA07078C3L;
            l_76++;
            g_5 = func_79(g_6[g_7], g_2[6], g_7, g_7);
            g_120 &= g_5;
        }
        l_60 = ((safe_mul_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((g_120 < l_72[0][0]), 3)), 1)) || l_72[0][1]) || 0x667C2D9536661290LL), g_120)) >= 1L);
        for (l_71 = 0; (l_71 <= 5); l_71 += 1)
        { /* block id: 65 */
            int32_t l_129 = (-1L);
            int i;
            l_129 &= ((safe_add_func_uint16_t_u_u(g_6[l_71], (-2L))) && g_68);
        }
    }
    return l_60;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_14(const uint32_t  p_15, int16_t  p_16)
{ /* block id: 9 */
    uint32_t l_19 = 18446744073709551615UL;
    l_19++;
    for (l_19 = 27; (l_19 <= 36); l_19++)
    { /* block id: 13 */
        int8_t l_24 = 0x31L;
        l_24 = 5L;
    }
    return l_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_6 g_3
 * writes:
 */
static uint8_t  func_30(uint8_t  p_31, uint64_t  p_32, uint32_t  p_33, uint64_t  p_34, uint32_t  p_35)
{ /* block id: 19 */
    uint32_t l_39 = 0UL;
    int32_t l_40 = 1L;
    l_40 = l_39;
    l_40 = (safe_rshift_func_uint16_t_u_u((safe_div_func_int64_t_s_s(((safe_add_func_int32_t_s_s(func_14(g_7, g_6[5]), p_33)) , g_3), g_7)), 6));
    l_40 ^= (safe_mod_func_int64_t_s_s((safe_add_func_uint16_t_u_u(((((safe_lshift_func_uint8_t_u_u(p_31, 0)) == l_39) != p_34) | g_6[4]), p_32)), 0xCB296AD982FC9AEBLL));
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_2 g_119
 * writes: g_6 g_3 g_119
 */
static int32_t  func_79(const int16_t  p_80, const uint32_t  p_81, uint32_t  p_82, int32_t  p_83)
{ /* block id: 34 */
    uint8_t l_92 = 248UL;
    uint32_t l_101 = 1UL;
    int32_t l_114[7];
    uint32_t l_116 = 1UL;
    int i;
    for (i = 0; i < 7; i++)
        l_114[i] = 0xAD585B88L;
    g_6[2] = (safe_lshift_func_int16_t_s_u(((func_14((safe_rshift_func_uint8_t_u_u(248UL, 5)), p_83) , (-6L)) && g_4), 6));
    for (p_82 = 1; (p_82 != 24); p_82++)
    { /* block id: 38 */
        uint32_t l_93 = 0x9BA90DD0L;
        int8_t l_108[10] = {0xBFL,0xBFL,0xBFL,0xBFL,0xBFL,0xBFL,0xBFL,0xBFL,0xBFL,0xBFL};
        int32_t l_112 = 0L;
        int32_t l_113 = (-1L);
        int32_t l_115 = 0L;
        int i;
        for (p_83 = (-10); (p_83 >= 10); p_83++)
        { /* block id: 41 */
            return l_92;
        }
        if ((l_92 ^ g_6[0]))
        { /* block id: 44 */
            if (l_93)
                break;
        }
        else
        { /* block id: 46 */
            int64_t l_107 = (-7L);
            int32_t l_109 = 0L;
            l_108[4] |= ((safe_mod_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(((((func_98(p_82, l_101) >= 4L) , l_93) >= 0x90BBL) == l_107), p_82)), l_93)) <= p_83);
            l_109 |= 0x133AA3A0L;
            g_6[1] ^= (safe_rshift_func_int16_t_s_s(g_2[2], 13));
        }
        --l_116;
        g_119 |= (0x65DCL | g_6[2]);
    }
    l_114[3] = (((l_101 > g_2[6]) | 4294967295UL) < 0xBB0DECA3L);
    return p_81;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_3
 */
static uint64_t  func_98(uint16_t  p_99, int64_t  p_100)
{ /* block id: 47 */
    uint16_t l_106 = 0UL;
    g_3 = ((((safe_add_func_uint16_t_u_u((safe_sub_func_int8_t_s_s(l_106, 0x12L)), 65526UL)) <= l_106) & l_106) > l_106);
    return l_106;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 43
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 42
   depth: 2, occurrence: 10
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 4
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 66
XXX times a non-volatile is write: 24
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 76
XXX percentage of non-volatile access: 81.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 10
   depth: 2, occurrence: 16

XXX percentage a fresh-made variable is used: 27.9
XXX percentage an existing variable is used: 72.1
********************* end of statistics **********************/

