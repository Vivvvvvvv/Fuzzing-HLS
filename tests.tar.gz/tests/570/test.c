/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16710385455291397972
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2 = 0xC0L;
static int16_t g_5 = 0xE53DL;
static uint8_t g_6 = 0x7EL;
static const volatile uint64_t g_24 = 0xAD5BEFA1E1C5A3D7LL;/* VOLATILE GLOBAL g_24 */
static uint32_t g_28 = 18446744073709551608UL;
static volatile uint32_t g_40 = 0UL;/* VOLATILE GLOBAL g_40 */
static int64_t g_45[6] = {8L,8L,8L,8L,8L,8L};
static volatile uint8_t g_59 = 0x60L;/* VOLATILE GLOBAL g_59 */
static uint8_t g_67 = 0x17L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_11(int8_t  p_12, uint64_t  p_13, int16_t  p_14, uint16_t  p_15);
static int8_t  func_16(int32_t  p_17, int64_t  p_18, uint16_t  p_19, uint16_t  p_20, uint32_t  p_21);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_24 g_5 g_28 g_40 g_45 g_59 g_67
 * writes: g_2 g_6 g_28 g_40 g_45 g_59 g_67
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_22 = 0x320E32CFL;
    int32_t l_58 = 0xD8E2DC66L;
    --g_2;
    ++g_6;
    if (((safe_add_func_uint32_t_u_u((func_11(func_16(l_22, g_6, l_22, g_2, g_6), g_5, g_5, g_5) <= 0xA5L), 0xD4D864B9L)) >= 0xF520L))
    { /* block id: 27 */
        uint64_t l_66[4][2] = {{0x851AA8C97D735F31LL,0x851AA8C97D735F31LL},{0x851AA8C97D735F31LL,0x851AA8C97D735F31LL},{0x851AA8C97D735F31LL,0x851AA8C97D735F31LL},{0x851AA8C97D735F31LL,0x851AA8C97D735F31LL}};
        int i, j;
        if (((((l_22 | l_22) , l_22) && g_24) & 0x4D19633EL))
        { /* block id: 28 */
            g_59++;
            g_67 = (safe_sub_func_int64_t_s_s((l_66[3][0] ^ 0L), l_66[2][1]));
            return g_67;
        }
        else
        { /* block id: 32 */
            return l_22;
        }
    }
    else
    { /* block id: 35 */
        for (g_6 = 0; (g_6 <= 5); g_6 += 1)
        { /* block id: 38 */
            int i;
            return g_45[g_6];
        }
        return g_2;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_24 g_28 g_6 g_40 g_45
 * writes: g_28 g_40 g_45
 */
static int8_t  func_11(int8_t  p_12, uint64_t  p_13, int16_t  p_14, uint16_t  p_15)
{ /* block id: 8 */
    int8_t l_31 = 0x13L;
    int32_t l_39 = 7L;
    int32_t l_57 = 0L;
    if ((((4294967295UL ^ p_15) == l_31) , 0L))
    { /* block id: 9 */
        int8_t l_35 = 1L;
        int32_t l_44 = (-5L);
        l_35 = ((+func_16((safe_mul_func_uint8_t_u_u(g_2, (-1L))), g_5, g_24, g_28, g_2)) , g_2);
        if ((safe_mod_func_int32_t_s_s(((~l_35) || g_6), l_35)))
        { /* block id: 11 */
            ++g_40;
            return p_12;
        }
        else
        { /* block id: 14 */
            uint8_t l_43 = 2UL;
            l_44 = l_43;
            g_45[1] = (((0x9DL || g_24) , l_35) > g_28);
        }
    }
    else
    { /* block id: 18 */
        for (p_12 = 0; (p_12 <= 5); p_12 += 1)
        { /* block id: 21 */
            int32_t l_51 = (-3L);
            int i;
            l_51 = func_16((safe_lshift_func_uint16_t_u_u((((safe_rshift_func_int16_t_s_s(((~(0x2DL == 9UL)) | 1L), 1)) || 0x6BL) || g_45[p_12]), 1)), g_24, l_31, g_45[p_12], p_12);
        }
    }
    l_57 &= (~(safe_rshift_func_uint16_t_u_u(((((safe_rshift_func_uint8_t_u_s((func_16(l_39, p_13, g_6, l_39, l_39) , 8UL), 5)) < 0x84L) , (-1L)) || p_14), l_31)));
    return l_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_6 g_5 g_2 g_28
 * writes: g_28
 */
static int8_t  func_16(int32_t  p_17, int64_t  p_18, uint16_t  p_19, uint16_t  p_20, uint32_t  p_21)
{ /* block id: 3 */
    uint16_t l_23[10];
    int32_t l_25 = 0L;
    int32_t l_26 = 1L;
    int32_t l_27 = 0L;
    int i;
    for (i = 0; i < 10; i++)
        l_23[i] = 65527UL;
    for (p_20 = 0; p_20 < 10; p_20 += 1)
    {
        l_23[p_20] = 65535UL;
    }
    l_25 = (((((g_24 | g_6) ^ g_5) & l_23[3]) <= g_2) < g_5);
    --g_28;
    return p_19;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_45[i], "g_45[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 22
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 26
   depth: 2, occurrence: 2
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 51
XXX times a non-volatile is write: 12
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 90

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 6
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 31.4
XXX percentage an existing variable is used: 68.6
********************* end of statistics **********************/

