/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15164217509957488245
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0L;
static volatile uint64_t g_11 = 18446744073709551615UL;/* VOLATILE GLOBAL g_11 */
static uint32_t g_19 = 0x7A140552L;
static volatile int8_t g_21 = 0x3FL;/* VOLATILE GLOBAL g_21 */
static volatile uint8_t g_24 = 0x7EL;/* VOLATILE GLOBAL g_24 */
static int16_t g_32 = 0x2E0FL;
static volatile int64_t g_35 = 0x0F12AFBCAE26E165LL;/* VOLATILE GLOBAL g_35 */
static uint64_t g_37 = 18446744073709551615UL;
static uint16_t g_40[9] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static uint32_t g_48 = 0xEE72C95CL;
static volatile int32_t g_51 = 0L;/* VOLATILE GLOBAL g_51 */
static int8_t g_52 = 0xB4L;
static uint16_t g_53 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_6(uint16_t  p_7, const int8_t  p_8, uint32_t  p_9);
static int32_t  func_12(const int32_t  p_13, int32_t  p_14, uint32_t  p_15, uint8_t  p_16, int64_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_11 g_24 g_21 g_19 g_37 g_40 g_48 g_53
 * writes: g_2 g_11 g_19 g_24 g_37 g_40 g_48 g_53
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_22 = 0x5DA2A0C0L;
    int32_t l_31 = (-1L);
    int32_t l_34[5] = {0x53674F9AL,0x53674F9AL,0x53674F9AL,0x53674F9AL,0x53674F9AL};
    int32_t l_41[2];
    uint32_t l_42[1];
    int i;
    for (i = 0; i < 2; i++)
        l_41[i] = 0L;
    for (i = 0; i < 1; i++)
        l_42[i] = 0UL;
    for (g_2 = 0; (g_2 != 13); g_2 = safe_add_func_int32_t_s_s(g_2, 1))
    { /* block id: 3 */
        int32_t l_29 = 0x40A7FCC6L;
        int32_t l_33 = 0L;
        int8_t l_36 = 0xB7L;
        if ((+func_6(g_2, g_2, g_2)))
        { /* block id: 11 */
            int64_t l_23[8] = {0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL,0x0E81DE9829CBC21BLL};
            int i;
            ++g_24;
            if (g_2)
                goto lbl_43;
            l_29 |= (((safe_rshift_func_uint8_t_u_u(((-1L) & l_23[4]), 7)) || 0x0366L) <= g_21);
            if (g_19)
                break;
        }
        else
        { /* block id: 15 */
            uint32_t l_30 = 18446744073709551609UL;
            if (l_30)
                break;
        }
        ++g_37;
        g_40[2] |= g_11;
    }
lbl_43:
    l_42[0] = ((((((((l_41[1] | g_40[7]) ^ l_34[4]) | 0x26845D487C7592E0LL) , g_24) ^ g_37) & l_34[4]) < g_40[7]) < g_2);
    for (g_2 = 0; (g_2 < (-1)); g_2 = safe_sub_func_int64_t_s_s(g_2, 3))
    { /* block id: 25 */
        int32_t l_49 = 0L;
        int32_t l_50 = 1L;
        for (g_19 = 0; (g_19 <= 51); g_19 = safe_add_func_uint8_t_u_u(g_19, 8))
        { /* block id: 28 */
            g_48 ^= l_34[0];
            l_41[0] = (0x405A9AD1L || 0UL);
        }
        g_53++;
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_11
 * writes: g_11 g_19
 */
static int8_t  func_6(uint16_t  p_7, const int8_t  p_8, uint32_t  p_9)
{ /* block id: 4 */
    uint16_t l_10 = 0xAE7BL;
    int32_t l_20 = 0x16AAC895L;
    g_11 = ((((0x23FA3A92L == l_10) >= g_2) ^ p_7) , 0xB1647C2CL);
    l_20 = func_12(p_9, g_11, g_2, l_10, p_8);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_19
 */
static int32_t  func_12(const int32_t  p_13, int32_t  p_14, uint32_t  p_15, uint8_t  p_16, int64_t  p_17)
{ /* block id: 6 */
    uint32_t l_18 = 18446744073709551610UL;
    g_19 = ((p_16 & l_18) != l_18);
    return l_18;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_40[i], "g_40[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 27
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 12
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 87.5

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 5
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 45.8
XXX percentage an existing variable is used: 54.2
********************* end of statistics **********************/

