/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18409552529673807752
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 2L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0x108F8256L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 1L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0xEA6801FCL;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = 4L;/* VOLATILE GLOBAL g_6 */
static int32_t g_7[1] = {1L};
static uint16_t g_19[7] = {0xBD48L,0xBD48L,0xBD48L,0xBD48L,0xBD48L,0xBD48L,0xBD48L};


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_3 g_19
 * writes: g_7
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_10 = 0x21F1L;
    for (g_7[0] = (-25); (g_7[0] >= 24); g_7[0]++)
    { /* block id: 3 */
        const int64_t l_13 = 7L;
        int32_t l_18 = 0x41311E2DL;
        l_10 = g_7[0];
        if (((((((safe_mod_func_uint16_t_u_u((g_3 & l_10), 0xC70AL)) ^ g_7[0]) <= g_7[0]) < l_10) > l_13) & l_13))
        { /* block id: 5 */
            return l_10;
        }
        else
        { /* block id: 7 */
            l_18 &= (safe_lshift_func_int8_t_s_s((safe_lshift_func_int8_t_s_s(g_7[0], 6)), 6));
        }
    }
    return g_19[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 5
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 11
XXX times a non-volatile is write: 3
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 8
XXX percentage of non-volatile access: 93.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 6
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 2
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 30.8
XXX percentage an existing variable is used: 69.2
********************* end of statistics **********************/

