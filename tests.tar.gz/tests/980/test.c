/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13452598478579656520
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_5 = (-4L);/* VOLATILE GLOBAL g_5 */
static uint32_t g_9[6][7][4] = {{{1UL,0xE2DB80EBL,1UL,18446744073709551610UL},{0x407858F9L,0xE2DB80EBL,0x407858F9L,0xD4A55F07L},{0xE2DB80EBL,0xF39CEE24L,0x4B4B1328L,0x214F1636L},{0x214F1636L,18446744073709551610UL,1UL,0xF39CEE24L},{0x1145714FL,1UL,1UL,0x1145714FL},{0x214F1636L,0xD4A55F07L,0x4B4B1328L,0x407858F9L},{0xE2DB80EBL,18446744073709551609UL,0x407858F9L,4UL}},{{0x407858F9L,4UL,1UL,4UL},{1UL,18446744073709551609UL,18446744073709551610UL,0x407858F9L},{0UL,0xD4A55F07L,4UL,0x1145714FL},{18446744073709551610UL,1UL,0xF39CEE24L,0xF39CEE24L},{18446744073709551610UL,18446744073709551610UL,0xE2DB80EBL,0xD4A55F07L},{0x407858F9L,1UL,4UL,18446744073709551609UL},{0x1145714FL,0x214F1636L,0UL,4UL}},{{0xF39CEE24L,0x214F1636L,0xF39CEE24L,18446744073709551609UL},{0x214F1636L,1UL,1UL,0xD4A55F07L},{0xD4A55F07L,4UL,0x1145714FL,1UL},{18446744073709551610UL,0x1145714FL,0x1145714FL,18446744073709551610UL},{0xD4A55F07L,18446744073709551609UL,1UL,0xF39CEE24L},{0x214F1636L,0x4B4B1328L,0xF39CEE24L,0xE2DB80EBL},{0xF39CEE24L,0xE2DB80EBL,0UL,0xE2DB80EBL}},{{0x1145714FL,0x4B4B1328L,4UL,0xF39CEE24L},{0x407858F9L,18446744073709551609UL,0xE2DB80EBL,18446744073709551610UL},{4UL,0x1145714FL,1UL,1UL},{4UL,4UL,0xE2DB80EBL,0xD4A55F07L},{0x407858F9L,1UL,4UL,18446744073709551609UL},{0x1145714FL,0x214F1636L,0UL,4UL},{0xF39CEE24L,0x214F1636L,0xF39CEE24L,18446744073709551609UL}},{{0x214F1636L,1UL,1UL,0xD4A55F07L},{0xD4A55F07L,4UL,0x1145714FL,1UL},{18446744073709551610UL,0x1145714FL,0x1145714FL,18446744073709551610UL},{0xD4A55F07L,18446744073709551609UL,1UL,0xF39CEE24L},{0x214F1636L,0x4B4B1328L,0xF39CEE24L,0xE2DB80EBL},{0xF39CEE24L,0xE2DB80EBL,0UL,0xE2DB80EBL},{0x1145714FL,0x4B4B1328L,4UL,0xF39CEE24L}},{{0x407858F9L,18446744073709551609UL,0xE2DB80EBL,18446744073709551610UL},{4UL,0x1145714FL,1UL,1UL},{4UL,4UL,0xE2DB80EBL,0xD4A55F07L},{0x407858F9L,1UL,4UL,18446744073709551609UL},{0x1145714FL,0x214F1636L,0UL,4UL},{0xF39CEE24L,0x214F1636L,0xF39CEE24L,18446744073709551609UL},{0x214F1636L,1UL,1UL,0xD4A55F07L}}};
static volatile uint16_t g_57 = 0xAE89L;/* VOLATILE GLOBAL g_57 */
static volatile int32_t g_62 = 1L;/* VOLATILE GLOBAL g_62 */
static uint8_t g_70 = 7UL;
static volatile uint64_t g_73 = 0UL;/* VOLATILE GLOBAL g_73 */
static int32_t g_78 = 0x7822E843L;
static uint32_t g_87 = 0UL;
static uint32_t g_88 = 8UL;
static int16_t g_110 = 0L;
static uint8_t g_114 = 0x02L;
static int8_t g_123[2][2] = {{0xCDL,0xCDL},{0xCDL,0xCDL}};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_14(const int8_t  p_15);
static int32_t  func_16(const uint16_t  p_17, uint32_t  p_18, uint32_t  p_19);
static int8_t  func_30(int64_t  p_31, uint32_t  p_32, const int32_t  p_33, uint8_t  p_34);
static uint64_t  func_41(int32_t  p_42, int16_t  p_43, uint32_t  p_44, int32_t  p_45, int32_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_9 g_57 g_62 g_70 g_73 g_87 g_78 g_88
 * writes: g_9 g_57 g_70 g_73 g_78 g_87 g_88 g_110 g_114 g_123
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_4 = 0xE87DF2F4L;
    int32_t l_6 = (-1L);
    int32_t l_7 = 8L;
    int32_t l_8[10][9][2] = {{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}},{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}}};
    int i, j, k;
    if (((safe_rshift_func_uint16_t_u_u(l_4, 8)) , g_5))
    { /* block id: 1 */
        int16_t l_12[8][2][6] = {{{0x104AL,0x64DBL,0x3F2AL,0x104AL,0x104AL,0x3F2AL},{0x104AL,0x104AL,0x3F2AL,0x64DBL,0x104AL,0x3565L}},{{0x104AL,0x64DBL,0x3F2AL,0x104AL,0x104AL,0x3F2AL},{0x104AL,0x104AL,0x3F2AL,0x64DBL,0x104AL,0x3565L}},{{0x104AL,0x64DBL,0x3F2AL,0x104AL,0x104AL,0x3F2AL},{0x104AL,0x104AL,0x3F2AL,0x64DBL,0x104AL,0x3565L}},{{0x104AL,0x64DBL,0x3F2AL,0x104AL,0x104AL,0x3F2AL},{0x104AL,0x104AL,0x3F2AL,0x64DBL,0x104AL,0x3565L}},{{0x104AL,0x64DBL,0x3F2AL,0x104AL,0x104AL,0x3F2AL},{0x104AL,0x104AL,0x3F2AL,0x64DBL,0x104AL,0x3565L}},{{0x104AL,0x64DBL,0x3F2AL,0x104AL,0x104AL,0x3F2AL},{0x104AL,0x104AL,0x3F2AL,0x64DBL,0x104AL,0x3565L}},{{0x104AL,0x64DBL,0x3F2AL,(-10L),(-10L),0x64DBL},{(-10L),(-10L),0x64DBL,0xA36AL,(-10L),0x104AL}},{{(-10L),0xA36AL,0x64DBL,(-10L),(-10L),0x64DBL},{(-10L),(-10L),0x64DBL,0xA36AL,(-10L),0x104AL}}};
        int i, j, k;
        ++g_9[3][4][1];
        return l_12[2][1][1];
    }
    else
    { /* block id: 4 */
        const uint16_t l_13 = 0x96ADL;
        int32_t l_90 = 0L;
        l_7 ^= (7L == l_13);
        if ((func_14(g_9[0][0][0]) , l_4))
        { /* block id: 12 */
            uint8_t l_35 = 0UL;
            g_88 = ((safe_rshift_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s(((func_16((func_14(func_30(l_7, g_5, g_9[1][4][0], l_35)) || l_6), l_35, g_9[3][0][2]) & g_9[0][1][2]) , l_8[2][7][0]), g_9[2][0][1])), g_9[0][2][1])) ^ g_9[0][1][2]);
        }
        else
        { /* block id: 44 */
            uint64_t l_89 = 0xA911A91DCBA93E3FLL;
            int32_t l_105 = 3L;
            l_90 &= (g_73 & l_89);
            l_105 = (safe_unary_minus_func_uint16_t_u(((((safe_lshift_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u((((safe_unary_minus_func_int16_t_s((((((safe_mul_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u((safe_sub_func_uint16_t_u_u((l_89 | g_62), g_78)), 4)) , 5L), l_8[2][7][0])) || 0xEC10F06FL) | g_78) & 1L) && 4UL))) == 0x8116371AL) != 1L), 5)) ^ l_13), 13)) , 0xE0775E61L) ^ 0L) , g_9[3][4][1])));
            return g_87;
        }
        if ((safe_div_func_uint32_t_u_u(g_9[3][4][1], l_90)))
        { /* block id: 49 */
            int32_t l_113 = 0x394F6C93L;
            g_110 = (safe_lshift_func_uint8_t_u_u(g_73, 7));
            g_114 = (safe_mod_func_int8_t_s_s((((((0x36L & g_5) < l_113) > l_90) <= 0x2834994DL) , g_57), 7UL));
        }
        else
        { /* block id: 52 */
            uint64_t l_119[5];
            int32_t l_120[3][5][7] = {{{0xC2E7BD33L,0x9C40DF3FL,0x12DC1848L,(-1L),0x982BA979L,0L,0x30712596L},{0L,0L,0x51E9D581L,0xDE9004F7L,1L,(-8L),0x4DB1C9D1L},{(-1L),0x9C40DF3FL,0xCEE68397L,0xC0DD118EL,(-1L),1L,0x51E9D581L},{0xCF47AE02L,0xC2E7BD33L,0x99BD49C4L,0x9C40DF3FL,0x4DB1C9D1L,1L,0x30712596L},{(-1L),1L,(-4L),1L,0x938C4D50L,(-1L),0xCF47AE02L}},{{0x4E873C8DL,0x0374A045L,(-4L),(-7L),1L,0x6B9C5361L,0L},{(-7L),0xDE9004F7L,0x99BD49C4L,0x982BA979L,0x982BA979L,0x99BD49C4L,0xDE9004F7L},{9L,(-7L),0xCEE68397L,0xCF47AE02L,2L,0xC0DD118EL,0x9C40DF3FL},{0x938C4D50L,1L,0x51E9D581L,(-4L),0xCFDDCEC7L,0x6B9C5361L,1L},{0xCF47AE02L,0xCFDDCEC7L,0x12DC1848L,0xCF47AE02L,0x30712596L,0x27632A01L,0L}},{{0x9C40DF3FL,1L,0x938C4D50L,0x982BA979L,0x4E873C8DL,0x61D7ECA5L,1L},{(-4L),1L,(-1L),(-7L),0x9C40DF3FL,1L,(-4L)},{0xC2E7BD33L,(-7L),(-1L),1L,0x9C40DF3FL,0x70086F9DL,0xCFDDCEC7L},{(-7L),(-8L),0x6B9C5361L,0x9C40DF3FL,0x4E873C8DL,0x4E873C8DL,0x9C40DF3FL},{1L,0x0374A045L,1L,0xC0DD118EL,0x30712596L,0L,(-8L)}}};
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_119[i] = 0UL;
            l_120[1][4][4] = ((safe_mod_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((((l_90 < l_90) > g_9[5][3][2]) , 0xBF819026L), g_57)), l_119[0])) , g_88);
        }
        g_123[1][1] = (safe_mul_func_int8_t_s_s(l_6, g_62));
    }
    return g_9[3][4][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_5
 * writes:
 */
static int32_t  func_14(const int8_t  p_15)
{ /* block id: 6 */
    int32_t l_20 = 0L;
    int32_t l_24 = 0xE3202F60L;
    int8_t l_25 = 0xDEL;
    l_24 = func_16(p_15, l_20, g_9[1][4][2]);
    return l_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_5
 * writes:
 */
static int32_t  func_16(const uint16_t  p_17, uint32_t  p_18, uint32_t  p_19)
{ /* block id: 7 */
    int8_t l_23 = (-6L);
    l_23 = (safe_mod_func_uint8_t_u_u(0UL, g_9[3][4][1]));
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_5 g_57 g_62 g_70 g_73 g_87
 * writes: g_57 g_70 g_73 g_78 g_87
 */
static int8_t  func_30(int64_t  p_31, uint32_t  p_32, const int32_t  p_33, uint8_t  p_34)
{ /* block id: 13 */
    uint32_t l_38 = 0x627F1A9FL;
    int32_t l_60 = 0L;
    int8_t l_71 = (-7L);
    if (((g_9[3][4][1] > g_5) <= g_9[3][4][1]))
    { /* block id: 14 */
        uint8_t l_56[9][8] = {{0xCDL,255UL,0x08L,0xF8L,0x08L,255UL,0xCDL,0xF8L},{0xCDL,255UL,0x08L,4UL,0x08L,255UL,0xCDL,4UL},{0xCDL,255UL,0x08L,0xF8L,0x08L,255UL,0xCDL,0xF8L},{0xCDL,255UL,0x08L,4UL,0x08L,255UL,0xCDL,4UL},{0xCDL,255UL,0x08L,0xF8L,0x08L,255UL,0xCDL,0xF8L},{0xCDL,255UL,0x08L,4UL,0x08L,255UL,0xCDL,4UL},{0xCDL,255UL,0x08L,0xF8L,0x08L,255UL,0xCDL,0xF8L},{0xCDL,255UL,0x08L,4UL,0x08L,255UL,0xCDL,4UL},{0xCDL,255UL,0x08L,0xF8L,0x08L,255UL,0xCDL,0xF8L}};
        int32_t l_61 = 0x1534BB8EL;
        int i, j;
        if (((safe_sub_func_int64_t_s_s((g_9[5][5][3] & 0x09421A0E57C1F20CLL), 0x20C2888A0E7B2E1DLL)) ^ l_38))
        { /* block id: 15 */
            uint64_t l_63 = 0x899D3D8B2F938724LL;
            l_60 = func_16((safe_add_func_uint64_t_u_u(func_41((((((safe_sub_func_int32_t_s_s((safe_div_func_int32_t_s_s((((safe_rshift_func_int8_t_s_u((safe_sub_func_int32_t_s_s((+((g_9[3][4][1] , g_5) , g_9[3][4][1])), 0x05E7732CL)), 5)) | g_9[4][6][0]) != 5L), p_33)), 4294967288UL)) == (-1L)) || g_9[3][4][1]) || 8UL) | p_34), l_56[4][7], p_31, g_9[4][0][2], g_9[2][2][3]), g_9[1][2][0])), p_31, g_9[2][1][3]);
            ++l_63;
        }
        else
        { /* block id: 21 */
            int8_t l_66 = 1L;
            l_60 |= (p_31 != g_62);
            return l_66;
        }
    }
    else
    { /* block id: 25 */
        int32_t l_69[5][4][2] = {{{0xB50B9A65L,0x6699CBFFL},{(-1L),0xB50B9A65L},{0x6699CBFFL,0x78ED0E11L},{(-3L),(-3L)}},{{(-1L),(-3L)},{(-3L),0x78ED0E11L},{0x6699CBFFL,0xB50B9A65L},{(-1L),0x6699CBFFL}},{{0xB50B9A65L,0x78ED0E11L},{0xB50B9A65L,0x6699CBFFL},{(-1L),0xB50B9A65L},{0x6699CBFFL,0x78ED0E11L}},{{(-3L),(-3L)},{(-1L),(-3L)},{(-3L),0x78ED0E11L},{0x6699CBFFL,0xB50B9A65L}},{{(-1L),0x6699CBFFL},{0xB50B9A65L,0x78ED0E11L},{0xB50B9A65L,0x6699CBFFL},{(-1L),0xB50B9A65L}}};
        int i, j, k;
        for (p_32 = 0; (p_32 <= 3); p_32 += 1)
        { /* block id: 28 */
            int64_t l_72 = 0x89E610DA34DBBD83LL;
            l_60 = (safe_mod_func_int16_t_s_s(l_69[4][0][0], (-6L)));
            g_70 |= l_38;
            g_73++;
            l_69[4][0][0] = ((l_69[1][1][1] ^ p_34) && g_70);
        }
        l_69[2][3][1] = (((l_69[4][0][0] ^ p_32) | 0xF460CB50322C85E5LL) >= 0x61BCL);
        for (l_60 = 0; (l_60 < 8); l_60 = safe_add_func_uint16_t_u_u(l_60, 1))
        { /* block id: 37 */
            g_78 = p_33;
        }
    }
    g_87 ^= (safe_add_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_mul_func_int8_t_s_s((0L || 2L), g_9[3][4][1])), g_62)), p_34)), g_9[3][4][1]));
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_57
 * writes: g_57
 */
static uint64_t  func_41(int32_t  p_42, int16_t  p_43, uint32_t  p_44, int32_t  p_45, int32_t  p_46)
{ /* block id: 16 */
    --g_57;
    return p_43;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_9[i][j][k], "g_9[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_123[i][j], "g_123[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 38
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 22
breakdown:
   depth: 1, occurrence: 36
   depth: 2, occurrence: 10
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 15, occurrence: 1
   depth: 18, occurrence: 1
   depth: 22, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 74
XXX times a non-volatile is write: 22
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 41
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 37
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 10
   depth: 2, occurrence: 16

XXX percentage a fresh-made variable is used: 33
XXX percentage an existing variable is used: 67
********************* end of statistics **********************/

