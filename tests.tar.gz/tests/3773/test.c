/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18226226065916029571
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-1L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = (-1L);
static volatile int64_t g_27 = 1L;/* VOLATILE GLOBAL g_27 */
static volatile uint64_t g_30 = 0x04FC4B664FB7D476LL;/* VOLATILE GLOBAL g_30 */
static volatile uint32_t g_36 = 0xC36C1D66L;/* VOLATILE GLOBAL g_36 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int8_t  func_5(int32_t  p_6, int16_t  p_7, int32_t  p_8);
static uint8_t  func_9(uint8_t  p_10, uint64_t  p_11, uint32_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_30 g_36
 * writes: g_4 g_3 g_30 g_36
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2[5] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
    int32_t l_34 = (-4L);
    int32_t l_35 = 1L;
    int i;
    for (g_4 = 3; (g_4 >= 0); g_4 -= 1)
    { /* block id: 3 */
        int i;
        return l_2[g_4];
    }
    g_4 = (func_5(l_2[4], g_4, l_2[3]) < g_4);
    g_36--;
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_30
 * writes: g_3 g_30
 */
static int8_t  func_5(int32_t  p_6, int16_t  p_7, int32_t  p_8)
{ /* block id: 6 */
    uint8_t l_25 = 0xA5L;
    int32_t l_26 = 0x86A4ABFFL;
    uint8_t l_33 = 247UL;
    p_8 ^= (func_9((safe_div_func_int64_t_s_s((safe_unary_minus_func_int32_t_s(((0x6950A4BAL | p_6) || g_3))), g_4)), g_4, g_4) < 7L);
    for (p_6 = (-4); (p_6 == (-22)); p_6 = safe_sub_func_uint64_t_u_u(p_6, 9))
    { /* block id: 14 */
        int32_t l_24[8];
        int32_t l_28 = (-1L);
        int32_t l_29 = 1L;
        int i;
        for (i = 0; i < 8; i++)
            l_24[i] = 0xCA3EAA3EL;
        p_8 &= (safe_sub_func_int64_t_s_s(((safe_lshift_func_uint16_t_u_s(l_24[0], l_25)) <= 0x21L), p_6));
        g_3 = (g_3 | p_8);
        l_26 ^= g_3;
        ++g_30;
    }
    return l_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint8_t  func_9(uint8_t  p_10, uint64_t  p_11, uint32_t  p_12)
{ /* block id: 7 */
    uint32_t l_16 = 7UL;
    int32_t l_17[2];
    int i;
    for (i = 0; i < 2; i++)
        l_17[i] = 1L;
    l_17[0] = l_16;
    l_17[0] = ((g_3 != l_17[0]) , 0x294BB489L);
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 13
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 19
XXX times a non-volatile is write: 8
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 18
XXX percentage of non-volatile access: 77.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 32.5
XXX percentage an existing variable is used: 67.5
********************* end of statistics **********************/

