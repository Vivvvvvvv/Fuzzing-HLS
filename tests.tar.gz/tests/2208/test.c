/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7904232325457843160
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_14 = 0x924C0001L;
static int16_t g_28 = 0xBF74L;
static uint64_t g_37 = 18446744073709551611UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_2(uint64_t  p_3, int64_t  p_4, int32_t  p_5, int32_t  p_6);
static int32_t  func_7(uint32_t  p_8, uint64_t  p_9, uint8_t  p_10, uint32_t  p_11, uint16_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_28
 * writes: g_14 g_37
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_13 = 0L;
    int16_t l_15 = 0xA095L;
    int32_t l_38[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int i;
    l_38[4] ^= (func_2((func_7(l_13, g_14, l_15, g_14, l_15) , 0UL), g_28, l_13, g_28) > l_13);
    return g_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_14
 * writes: g_37
 */
static uint32_t  func_2(uint64_t  p_3, int64_t  p_4, int32_t  p_5, int32_t  p_6)
{ /* block id: 11 */
    uint64_t l_35 = 0x49A5C1B09C821F99LL;
    int32_t l_36 = 0xA21B78CDL;
    l_36 = (safe_add_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u(((((((safe_div_func_int64_t_s_s((0x52F093D7F285F402LL != p_6), g_28)) || g_28) > 0x4DL) == p_4) ^ 9UL) ^ 255UL), 8L)), l_35));
    g_37 = (g_28 == g_28);
    return g_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes: g_14
 */
static int32_t  func_7(uint32_t  p_8, uint64_t  p_9, uint8_t  p_10, uint32_t  p_11, uint16_t  p_12)
{ /* block id: 1 */
    int8_t l_16[3];
    int8_t l_26 = (-3L);
    int i;
    for (i = 0; i < 3; i++)
        l_16[i] = 0xB4L;
    l_16[1] = (g_14 | g_14);
    for (g_14 = 0; (g_14 > 14); g_14 = safe_add_func_uint64_t_u_u(g_14, 9))
    { /* block id: 5 */
        int16_t l_21 = 0x6335L;
        int32_t l_27 = 0x88380095L;
        l_21 ^= (((safe_mod_func_uint64_t_u_u(((0xFEBFB2C41AC3DC99LL | 0x509CB0BEFCDF11BBLL) > 0x5AC3D6C1DFE936BELL), p_10)) & p_8) || p_12);
        l_27 = (safe_sub_func_int8_t_s_s(((safe_add_func_uint16_t_u_u((p_12 > l_26), g_14)) , 0xC7L), g_14));
        if (l_16[2])
            continue;
    }
    return g_14;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 7
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 34.3
XXX percentage an existing variable is used: 65.7
********************* end of statistics **********************/

