/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5555890924109673996
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[8] = {0xB0F73838L,0xB0F73838L,0xB0F73838L,0xB0F73838L,0xB0F73838L,0xB0F73838L,0xB0F73838L,0xB0F73838L};
static volatile uint16_t g_3 = 0xB165L;/* VOLATILE GLOBAL g_3 */
static uint32_t g_25 = 0xF7D96711L;
static volatile int32_t g_37[7] = {(-9L),(-9L),(-9L),(-9L),(-9L),(-9L),(-9L)};
static uint64_t g_40 = 0x87C2657A772BE76DLL;
static const int64_t g_47 = (-4L);
static uint64_t g_48 = 0x30732BAB2BD68E48LL;
static uint8_t g_53 = 0x61L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const uint16_t  func_6(uint16_t  p_7, const int32_t  p_8, uint32_t  p_9);
static uint16_t  func_12(int32_t  p_13, uint32_t  p_14, int32_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_25 g_2 g_40 g_47
 * writes: g_3 g_25 g_37 g_40 g_48 g_53
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    const int32_t l_18 = 1L;
    int32_t l_19 = 1L;
    g_3++;
    g_48 = (((((func_6((safe_rshift_func_uint16_t_u_s(func_12(((safe_mod_func_uint32_t_u_u(((-8L) ^ l_18), l_19)) && 0x17AB6DAD816F93BDLL), g_3, l_19), l_19)), l_19, l_18) >= g_47) && g_2[7]) && 0x309F33D48A24E228LL) >= g_47) != l_18);
    g_53 = (safe_add_func_uint32_t_u_u(((((safe_add_func_uint32_t_u_u(l_18, 0x161DBFA2L)) | g_2[7]) <= 3L) <= 0x1ECBC59AL), g_47));
    return g_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_40 g_2
 * writes: g_40
 */
static const uint16_t  func_6(uint16_t  p_7, const int32_t  p_8, uint32_t  p_9)
{ /* block id: 9 */
    int64_t l_38 = (-1L);
    int32_t l_39[5] = {0L,0L,0L,0L,0L};
    int i;
    ++g_40;
    l_39[2] &= ((safe_sub_func_int8_t_s_s(p_8, p_9)) && p_9);
    l_39[3] = (((safe_div_func_int16_t_s_s(1L, (-1L))) , 0xC1846E972F33BC6CLL) > g_2[7]);
    return l_39[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_2
 * writes: g_25 g_37
 */
static uint16_t  func_12(int32_t  p_13, uint32_t  p_14, int32_t  p_15)
{ /* block id: 2 */
    int8_t l_24 = (-9L);
    int16_t l_30 = 0xF5A2L;
    int32_t l_33[2];
    int i;
    for (i = 0; i < 2; i++)
        l_33[i] = 0xB6930509L;
    g_25 = (safe_mul_func_int16_t_s_s((safe_div_func_int8_t_s_s(p_13, p_14)), l_24));
    l_30 &= (safe_mul_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((g_25 < g_2[2]), g_25)), g_25));
    if (p_14)
        goto lbl_34;
lbl_34:
    l_33[1] = (((safe_sub_func_int16_t_s_s(l_24, l_24)) || p_14) <= g_2[7]);
    g_37[5] = ((safe_div_func_uint8_t_u_u(((((g_2[7] < g_25) , l_30) > p_14) | p_15), 0xB2L)) , 0xF0D4A7C7L);
    return l_33[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_37[i], "g_37[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 16
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 8
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 15
XXX percentage of non-volatile access: 80.9

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 14

XXX percentage a fresh-made variable is used: 28.8
XXX percentage an existing variable is used: 71.2
********************* end of statistics **********************/

