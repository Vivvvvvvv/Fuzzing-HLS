/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16519338280584714328
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_8 = (-1L);
static int32_t g_9[1][3] = {{1L,1L,1L}};
static volatile int16_t g_25 = 0x8838L;/* VOLATILE GLOBAL g_25 */
static int32_t g_44 = 0x55BB5FB4L;
static volatile uint16_t g_97 = 0xFF72L;/* VOLATILE GLOBAL g_97 */
static uint32_t g_100 = 1UL;
static uint64_t g_114 = 3UL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const int32_t  func_10(int32_t  p_11, uint32_t  p_12, uint64_t  p_13, int8_t  p_14, int16_t  p_15);
static uint32_t  func_22(uint64_t  p_23, uint32_t  p_24);
static int32_t  func_30(int16_t  p_31, uint16_t  p_32, uint32_t  p_33, uint8_t  p_34, int32_t  p_35);
static int8_t  func_40(int32_t  p_41, uint32_t  p_42, int64_t  p_43);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_9 g_25 g_44 g_97 g_114
 * writes: g_9 g_25 g_8 g_44 g_97 g_100 g_114
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2 = 0UL;
    int32_t l_115[4] = {0L,0L,0L,0L};
    int i;
    if (l_2)
    { /* block id: 1 */
        uint32_t l_7 = 4294967295UL;
        for (l_2 = 11; (l_2 == 14); l_2 = safe_add_func_int8_t_s_s(l_2, 8))
        { /* block id: 4 */
            int32_t l_16 = 0L;
            g_9[0][1] = (((safe_sub_func_uint32_t_u_u(l_7, 0x00011151L)) == g_8) > g_8);
            g_100 = func_10(l_16, g_8, l_7, l_16, l_2);
            if (g_25)
                continue;
        }
    }
    else
    { /* block id: 68 */
        const int64_t l_104[10][8] = {{0x86CBD83D76CE6111LL,0x54A6F35BB462C2F1LL,(-2L),0x54A6F35BB462C2F1LL,0x86CBD83D76CE6111LL,0x57B7439DAF5B9146LL,4L,0x12365208590E4044LL},{0x784999CA7B65799CLL,2L,(-10L),0x3A0BC11C586F400ALL,0xEC67F3A6B8F9AD1ELL,(-8L),(-5L),0x54A6F35BB462C2F1LL},{0x3A0BC11C586F400ALL,0x75BA722EB29FA799LL,(-10L),0L,0x57B7439DAF5B9146LL,0xEC67F3A6B8F9AD1ELL,4L,0x86CBD83D76CE6111LL},{0xEC67F3A6B8F9AD1ELL,(-2L),(-2L),0x12365208590E4044LL,0x22D3B1C7E41B645FLL,(-9L),0x54A6F35BB462C2F1LL,0xEA8031382D9615D0LL},{0x0ACBBF453DDAA5E5LL,0xD0B17AAFE8A4A7E5LL,(-10L),0xE0B1FDE04AB730D5LL,1L,1L,0xE0B1FDE04AB730D5LL,0x75BA722EB29FA799LL},{(-2L),(-2L),0x25F5692BD29671F1LL,(-8L),1L,(-1L),0xEC67F3A6B8F9AD1ELL,(-1L)},{7L,0x4EFEA996BB96E4AELL,0x6B1FF0AA6A4DFBEFLL,1L,0x12365208590E4044LL,0x86CBD83D76CE6111LL,0x07C177FA41F08C6BLL,(-1L)},{0x4EFEA996BB96E4AELL,(-1L),0xD0B17AAFE8A4A7E5LL,(-8L),0x2D310D2121A4FECFLL,0x22D3B1C7E41B645FLL,0x86CBD83D76CE6111LL,0x75BA722EB29FA799LL},{4L,1L,(-2L),0x2D310D2121A4FECFLL,(-5L),4L,0xE0B1FDE04AB730D5LL,1L},{1L,(-9L),0x86CBD83D76CE6111LL,2L,0x86CBD83D76CE6111LL,(-9L),1L,0x3A0BC11C586F400ALL}};
        int i, j;
        if (g_9[0][1])
        { /* block id: 69 */
            uint32_t l_101[1][3];
            uint32_t l_109 = 18446744073709551615UL;
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 3; j++)
                    l_101[i][j] = 0UL;
            }
            l_101[0][2] |= g_8;
            g_44 |= (safe_mod_func_uint64_t_u_u(l_104[9][0], l_104[9][0]));
            l_109 = (safe_mul_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(((-1L) | l_104[9][0]), g_25)), g_9[0][1]));
        }
        else
        { /* block id: 73 */
            g_114 &= (safe_lshift_func_int8_t_s_u((safe_add_func_uint16_t_u_u(((l_2 != (-1L)) < l_2), g_44)), 3));
            return l_104[9][0];
        }
        l_115[0] = (l_2 , 0xF2D2C60FL);
        for (g_8 = 0; (g_8 <= 6); g_8++)
        { /* block id: 80 */
            int32_t l_118 = 0x81135C14L;
            if (l_104[9][0])
                break;
            return l_118;
        }
        for (l_2 = (-6); (l_2 < 35); l_2++)
        { /* block id: 86 */
            return g_8;
        }
    }
    return l_115[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_25 g_8 g_44 g_97
 * writes: g_25 g_8 g_44 g_97
 */
static const int32_t  func_10(int32_t  p_11, uint32_t  p_12, uint64_t  p_13, int8_t  p_14, int16_t  p_15)
{ /* block id: 6 */
    uint32_t l_17 = 0UL;
    int32_t l_21 = (-1L);
    uint8_t l_96 = 4UL;
    l_17 ^= (g_9[0][1] && 5L);
    l_21 = ((~((safe_mul_func_uint8_t_u_u(1UL, l_17)) == l_17)) , 1L);
    l_96 = (func_22(p_15, p_13) && p_11);
    g_97--;
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_8 g_9 g_44
 * writes: g_25 g_8 g_44
 */
static uint32_t  func_22(uint64_t  p_23, uint32_t  p_24)
{ /* block id: 9 */
    uint16_t l_45 = 0xDEDBL;
    uint32_t l_46 = 0x4B505D01L;
    int32_t l_85 = 0x696F087CL;
    int32_t l_87[9] = {1L,0xA10FB8DAL,1L,1L,0xA10FB8DAL,1L,1L,0xA10FB8DAL,1L};
    uint32_t l_88 = 5UL;
    int i;
    for (p_23 = 0; (p_23 <= 0); p_23 += 1)
    { /* block id: 12 */
        uint32_t l_26 = 0xBE26B5CFL;
        int32_t l_29 = 0L;
        int32_t l_86[8][2] = {{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L},{0x6E85BCF7L,0x6E85BCF7L}};
        int i, j;
        g_25 &= (-1L);
        for (g_8 = 0; (g_8 <= 0); g_8 += 1)
        { /* block id: 16 */
            l_26--;
            l_29 = 5L;
        }
        l_29 = func_30((((safe_div_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u(func_40(p_24, g_9[0][0], l_26), 4)), p_23)) , 1L) , l_45), p_24, p_23, p_24, l_46);
        ++l_88;
        for (g_44 = 0; (g_44 >= 0); g_44 -= 1)
        { /* block id: 54 */
            uint64_t l_91 = 0x92485D133FD70792LL;
            int i, j;
            l_91++;
            if (g_9[g_44][(g_44 + 1)])
                break;
            l_85 ^= ((safe_div_func_int32_t_s_s(g_9[0][1], l_91)) > p_23);
            if (g_8)
                continue;
        }
    }
    return p_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_25 g_44 g_9 g_8
 * writes: g_44
 */
static int32_t  func_30(int16_t  p_31, uint16_t  p_32, uint32_t  p_33, uint8_t  p_34, int32_t  p_35)
{ /* block id: 23 */
    uint64_t l_51 = 0x0DEEA39BA5493A50LL;
    int32_t l_75[8][7][4] = {{{(-8L),1L,0x3647B8CEL,(-1L)},{0x3647B8CEL,(-1L),0xE3EED797L,0xE2804CE6L},{0x90776C57L,0xAC2F6E58L,0xC8B8AFECL,0L},{0xE2804CE6L,0x3647B8CEL,0x1CDA016EL,0xF0AA60CBL},{0xB3385642L,0xA3D91D69L,(-1L),0x5E3C92ACL},{0xD3007418L,(-8L),0x15B503A7L,0x8F9F05BBL},{9L,0xC8B8AFECL,(-1L),(-5L)}},{{0xD8BAA40DL,1L,0x6EF1402EL,1L},{0xA3D91D69L,0L,0L,0xA3D91D69L},{0xE3EED797L,8L,0xBE5B5757L,1L},{0xE4C4DC47L,0L,1L,(-7L)},{0L,9L,0xAC2F6E58L,(-7L)},{0x0B76A7FFL,0L,0x2ED8564FL,1L},{1L,8L,0xF7D061DAL,0xA3D91D69L}},{{0xF0AA60CBL,0L,0L,1L},{1L,1L,0xF0AA60CBL,(-5L)},{0x15B503A7L,0xC8B8AFECL,(-1L),0x8F9F05BBL},{1L,(-8L),0L,0x5E3C92ACL},{0xBE5B5757L,0xA3D91D69L,0L,0xF0AA60CBL},{0x41AB8767L,0x3647B8CEL,(-7L),0L},{0L,0xAC2F6E58L,0x741E9346L,0xE2804CE6L}},{{0L,(-1L),0xE2804CE6L,(-1L)},{0x6993EB33L,1L,(-1L),1L},{(-1L),0xB3385642L,0x41AB8767L,0xE4C4DC47L},{0x6EF1402EL,(-5L),0x90776C57L,9L},{0x6EF1402EL,0x6A6ECCD2L,0x41AB8767L,0x19FDEE13L},{(-1L),9L,(-1L),0x90776C57L},{0x6993EB33L,(-1L),0xE2804CE6L,0xB8F99D24L}},{{0L,(-1L),0x741E9346L,0xBE5B5757L},{0L,(-8L),(-7L),0L},{0x41AB8767L,(-7L),0L,0xBDC21833L},{0xBE5B5757L,0xF7D061DAL,0x90776C57L,(-7L)},{0xA3D91D69L,0xFA339BCAL,0xF7D061DAL,0x5E3C92ACL},{0L,0x3647B8CEL,0xB8F99D24L,0x22B282FFL},{0xD8BAA40DL,0x2ED8564FL,1L,1L}},{{0xB8F99D24L,0xB8F99D24L,0x6A6ECCD2L,0x3647B8CEL},{0x41AB8767L,0xF0AA60CBL,0xA55AEF27L,0x15B503A7L},{(-7L),(-1L),0x5E3C92ACL,0xA55AEF27L},{1L,(-1L),(-8L),0x15B503A7L},{(-1L),0xF0AA60CBL,0x1CDA016EL,0x3647B8CEL},{0xFA339BCAL,0xB8F99D24L,9L,1L},{9L,0x2ED8564FL,0xF0AA60CBL,0x22B282FFL}},{{0x741E9346L,0x3647B8CEL,0xAC2F6E58L,0x5E3C92ACL},{0xE3EED797L,0xFA339BCAL,0L,(-7L)},{1L,0xF7D061DAL,0xD3007418L,0x2ED8564FL},{0x6EF1402EL,(-1L),0x0B76A7FFL,0x90776C57L},{0xBE5B5757L,(-5L),(-1L),0x1CDA016EL},{(-1L),0xAC2F6E58L,0xFA339BCAL,0L},{1L,0x6993EB33L,1L,(-1L)}},{{(-5L),0xE3EED797L,0x3647B8CEL,1L},{0xA55AEF27L,0x19FDEE13L,0L,0xE3EED797L},{(-8L),0L,0L,(-1L)},{0xA55AEF27L,0x6EF1402EL,0x3647B8CEL,0x8F9F05BBL},{(-5L),0x41AB8767L,1L,0xD3007418L},{1L,0xD3007418L,0xFA339BCAL,0xBE5B5757L},{(-1L),0x5E3C92ACL,(-1L),9L}}};
    int i, j, k;
    if (((((safe_mod_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(0x73L, 1L)), 0x92L)) | g_25) ^ l_51) | g_44))
    { /* block id: 24 */
        int64_t l_66 = 0x1147C038D03D8E66LL;
        int32_t l_67 = 0xCD5918CDL;
        if (((safe_mul_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(65535UL, 0xD913L)), 1L)) > g_9[0][2]))
        { /* block id: 25 */
            g_44 = (safe_rshift_func_int16_t_s_u(((safe_mul_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((safe_add_func_int32_t_s_s(((((((safe_lshift_func_int16_t_s_u(0L, 10)) == l_66) != 0xB8F5L) < g_25) < 0x67L) & l_51), p_32)), p_34)), p_32)) || g_25), 15));
            g_44 &= (p_32 && p_31);
        }
        else
        { /* block id: 28 */
            l_67 = 0x34C2E397L;
            g_44 = (~p_35);
        }
        for (p_31 = (-7); (p_31 >= 5); ++p_31)
        { /* block id: 34 */
            uint64_t l_71 = 6UL;
            l_71 = p_32;
            g_44 = (safe_sub_func_int64_t_s_s((l_71 == 0x28F8F04B7466640DLL), 0x46F18880ABB00F61LL));
            l_75[7][0][1] = (safe_unary_minus_func_uint64_t_u(((((((2L && l_66) ^ (-3L)) < (-5L)) && l_67) >= g_8) , 1UL)));
        }
        for (l_66 = (-24); (l_66 >= 2); l_66 = safe_add_func_uint64_t_u_u(l_66, 6))
        { /* block id: 41 */
            int32_t l_82 = 9L;
            g_44 = (safe_sub_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_s(g_9[0][1], g_9[0][1])) >= l_66), l_82));
            if (g_9[0][1])
                continue;
        }
    }
    else
    { /* block id: 45 */
        int32_t l_84 = 0x23AE71BBL;
        l_84 &= (~p_34);
        l_75[2][6][0] = 0xC4852B1BL;
    }
    return l_75[7][0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_8
 * writes: g_44
 */
static int8_t  func_40(int32_t  p_41, uint32_t  p_42, int64_t  p_43)
{ /* block id: 20 */
    g_44 = (p_42 < 0L);
    return g_8;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_9[i][j], "g_9[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 34
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 56
   depth: 2, occurrence: 13
   depth: 3, occurrence: 2
   depth: 4, occurrence: 6
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 79
XXX times a non-volatile is write: 35
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 38
XXX percentage of non-volatile access: 94.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 54
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 15
   depth: 2, occurrence: 26

XXX percentage a fresh-made variable is used: 30.4
XXX percentage an existing variable is used: 69.6
********************* end of statistics **********************/

