/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11142549402903545692
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_10 = 0UL;/* VOLATILE GLOBAL g_10 */
static const int16_t g_12 = 0x5653L;
static int32_t g_50 = 0xAABDC9A8L;
static volatile int64_t g_69 = 0x87C03C79A39DA5D7LL;/* VOLATILE GLOBAL g_69 */
static uint64_t g_71[5] = {18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(int32_t  p_3, const uint8_t  p_4, uint32_t  p_5);
static int64_t  func_15(int16_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_50 g_71
 * writes: g_50 g_71
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int8_t l_11[7];
    int32_t l_67 = 0x915CED7CL;
    int32_t l_68[4];
    int64_t l_70[9];
    int i;
    for (i = 0; i < 7; i++)
        l_11[i] = 7L;
    for (i = 0; i < 4; i++)
        l_68[i] = 4L;
    for (i = 0; i < 9; i++)
        l_70[i] = 0x4F91E2C0253A1071LL;
    if (func_2(((safe_lshift_func_int16_t_s_u((safe_mod_func_uint16_t_u_u(g_10, l_11[3])), l_11[3])) > l_11[2]), g_12, g_12))
    { /* block id: 18 */
        int32_t l_56 = 0x95372A71L;
        l_56 |= (g_10 , l_11[1]);
    }
    else
    { /* block id: 20 */
        uint64_t l_66 = 0x53CC61BBCB567DFBLL;
        l_67 = ((((((((safe_lshift_func_uint8_t_u_s((((((safe_mod_func_uint8_t_u_u(((safe_mod_func_int16_t_s_s((~((safe_add_func_int64_t_s_s(((g_10 && g_12) , l_66), l_11[3])) & (-3L))), g_50)) & l_11[3]), 3L)) != g_50) || 0x2DL) != 3UL) ^ l_66), 5)) <= l_11[4]) , l_66) == l_11[5]) != (-1L)) >= l_11[3]) > l_66) && 1UL);
    }
    --g_71[3];
    l_68[1] = 0x85807939L;
    return l_70[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_50
 * writes: g_50
 */
static int32_t  func_2(int32_t  p_3, const uint8_t  p_4, uint32_t  p_5)
{ /* block id: 1 */
    uint32_t l_55 = 18446744073709551615UL;
    l_55 = (safe_mod_func_int64_t_s_s(func_15(((p_3 <= g_10) || g_12)), 0x08385637EAC691C6LL));
    return l_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_50
 * writes: g_50
 */
static int64_t  func_15(int16_t  p_16)
{ /* block id: 2 */
    uint32_t l_41 = 0xDB956746L;
    uint8_t l_53 = 0xA0L;
    int32_t l_54 = 0L;
    if (p_16)
    { /* block id: 3 */
        const int16_t l_37 = 0xF995L;
        int32_t l_38[6] = {(-1L),0x7EA1B148L,0x7EA1B148L,(-1L),0x7EA1B148L,0x7EA1B148L};
        int i;
        l_38[3] = (safe_rshift_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s((safe_sub_func_uint16_t_u_u((safe_div_func_int16_t_s_s(((((safe_lshift_func_int16_t_s_u((safe_div_func_int16_t_s_s(((safe_lshift_func_int16_t_s_u((safe_add_func_int32_t_s_s((((safe_sub_func_uint32_t_u_u(g_10, g_12)) || l_37) && p_16), l_37)), p_16)) ^ 0x2151L), 0xADAAL)), g_12)) != 0xD2AE857B1A094951LL) || 0x2D50C857617C0EC0LL) , g_10), 0x5243L)), 0UL)), p_16)), 9L)), 1));
    }
    else
    { /* block id: 5 */
        for (p_16 = 0; (p_16 < 27); p_16 = safe_add_func_uint16_t_u_u(p_16, 5))
        { /* block id: 8 */
            uint8_t l_49 = 0x26L;
            if (l_41)
                break;
            g_50 |= (safe_mul_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_s((safe_unary_minus_func_uint32_t_u(((safe_add_func_int64_t_s_s(((((l_41 != l_41) && 0x76L) | 0x4AEDF2FFA36FE543LL) != p_16), l_41)) <= g_12))), 7)) ^ g_10) <= l_49), 0x899DL));
            g_50 = p_16;
        }
    }
    l_54 = (safe_sub_func_int32_t_s_s((((((((l_41 > g_12) != l_41) , 0L) , 0x9E13A3A1L) , g_12) , l_53) || 0L), l_53));
    return l_41;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_71[i], "g_71[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 20
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 2
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 17, occurrence: 1
   depth: 20, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 46
XXX times a non-volatile is write: 10
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 16
XXX percentage of non-volatile access: 88.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 4
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 25.7
XXX percentage an existing variable is used: 74.3
********************* end of statistics **********************/

