/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11900786168890742068
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_4 = 0x4C8D3C89L;
static int64_t g_40 = (-1L);
static uint8_t g_52[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
static volatile int32_t g_55 = (-1L);/* VOLATILE GLOBAL g_55 */
static uint32_t g_63 = 0xDCF67A9FL;
static volatile uint32_t g_73 = 4294967295UL;/* VOLATILE GLOBAL g_73 */
static uint64_t g_76 = 0xCC2001377BC7A95ELL;
static uint32_t g_80 = 0xF91B2076L;
static uint32_t g_87 = 18446744073709551612UL;
static volatile uint32_t g_94 = 0x6BCB33D2L;/* VOLATILE GLOBAL g_94 */
static int64_t g_102 = 1L;
static uint32_t g_111[9] = {0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L,0x1DF0E7D1L};
static uint16_t g_135 = 0x19D7L;
static uint32_t g_146 = 0x743FEE94L;
static int32_t g_160 = 1L;
static int64_t g_174 = (-1L);


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const int32_t  func_7(int8_t  p_8);
static int32_t  func_9(uint8_t  p_10, const int8_t  p_11, uint32_t  p_12, uint64_t  p_13);
static int32_t  func_15(int16_t  p_16, uint16_t  p_17, int64_t  p_18, uint32_t  p_19);
static int32_t  func_26(int8_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_40 g_63 g_55 g_52 g_73 g_76 g_80 g_94 g_111 g_135 g_87 g_160 g_146
 * writes: g_4 g_40 g_52 g_63 g_73 g_76 g_80 g_87 g_94 g_102 g_111 g_135 g_146 g_160 g_174
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_177 = 0xDBB096D4882EDD94LL;
    int32_t l_202 = 0x92E38BFBL;
    uint32_t l_205 = 0xCBFBA9A8L;
    int32_t l_208 = 0xDEFCC240L;
    if (((((safe_rshift_func_uint16_t_u_u(0xB407L, g_4)) <= 9L) != 0xAA6E6F7FBF2121F9LL) != g_4))
    { /* block id: 1 */
        uint8_t l_178 = 0UL;
        int32_t l_180 = 0xE60ADCB0L;
        for (g_4 = 16; (g_4 != 16); g_4 = safe_add_func_uint64_t_u_u(g_4, 7))
        { /* block id: 4 */
            g_174 = func_7(g_4);
        }
        g_160 = ((safe_mul_func_uint16_t_u_u(l_177, g_52[5])) > l_177);
        l_178 = 0L;
        if ((((g_55 == l_178) < g_160) != 0x8CD386D9L))
        { /* block id: 156 */
            int32_t l_179 = (-8L);
            l_180 = (l_179 , 5L);
            return g_94;
        }
        else
        { /* block id: 159 */
            int64_t l_185 = 0x17D95232D534F489LL;
            g_160 |= 0xFC5022FEL;
            g_160 = (safe_rshift_func_int16_t_s_u(((safe_mod_func_uint32_t_u_u(l_185, l_180)) , 0x97BBL), 9));
            return g_111[8];
        }
    }
    else
    { /* block id: 164 */
        uint16_t l_200[3][4][10] = {{{0xED59L,0xDAC3L,0x7CE1L,0xC19FL,0x7CE1L,0xDAC3L,0xED59L,0xB6B9L,0x5A2FL,65534UL},{0x7CE1L,0x8C1CL,65527UL,0xF8A2L,0xB6B9L,0UL,1UL,1UL,0UL,0xB6B9L},{0x5A2FL,0x8C1CL,0x8C1CL,0x5A2FL,0UL,0x7CE1L,0xED59L,65534UL,1UL,0xF067L},{65527UL,0UL,0xF8A2L,0xC19FL,1UL,65527UL,1UL,0xC19FL,0xF8A2L,0UL}},{{0x93B7L,0x5A2FL,0xF067L,0xB6B9L,0x8C1CL,65529UL,0xED59L,0xF8A2L,0x9CE5L,0x9CE5L},{0x5A2FL,65534UL,65529UL,65527UL,65527UL,65529UL,65534UL,0x5A2FL,0xB6B9L,0xED59L},{0x93B7L,0xF067L,0xC19FL,0x5A2FL,0x7CE1L,65527UL,1UL,0xED59L,1UL,65527UL},{0xDAC3L,0x7CE1L,0xC19FL,0x7CE1L,0xDAC3L,0xED59L,0xB6B9L,0x5A2FL,65534UL,65529UL}},{{0xB6B9L,0x8C1CL,65529UL,0xED59L,0xF8A2L,0x9CE5L,0x9CE5L,0xF8A2L,0xED59L,65529UL},{0xED59L,0xED59L,0xF067L,65529UL,0xDAC3L,0UL,0xF8A2L,0xC19FL,1UL,65527UL},{0xC19FL,1UL,0xF8A2L,65534UL,0x7CE1L,65534UL,0xF8A2L,1UL,0xC19FL,0xED59L},{0x8C1CL,0xED59L,1UL,0xDAC3L,65527UL,0x93B7L,0x9CE5L,0x7CE1L,0x7CE1L,0x9CE5L}}};
        int i, j, k;
        for (g_146 = 0; (g_146 > 33); g_146++)
        { /* block id: 167 */
            int16_t l_201[6][9][4] = {{{0x84F2L,0x1C0EL,0xC18CL,0x32F4L},{(-9L),4L,0xC18CL,0xED1CL},{0x84F2L,(-1L),0x6B02L,0x0B9BL},{0x0CBBL,0xD92DL,(-1L),0x6BC9L},{(-1L),0x6BC9L,1L,(-9L)},{0x36F6L,0x84F2L,0x155EL,0xEEF5L},{6L,0x32F4L,0xEEF5L,0x0841L},{0xAD68L,0xED83L,1L,(-10L)},{(-9L),0xED1CL,(-1L),1L}},{{1L,0xBD07L,0x0E74L,0x0B9BL},{4L,0x510BL,0x510BL,4L},{0xBD07L,0x7360L,1L,0x23A6L},{0x155EL,0xAD68L,0xD92DL,0x0E74L},{1L,0x32F4L,0x912EL,0x0E74L},{0xED83L,0xAD68L,0x0B9BL,0x23A6L},{(-9L),0x7360L,0xD850L,4L},{(-1L),0x510BL,0xD3E8L,0x0B9BL},{0xED1CL,0xBD07L,0x8418L,1L}},{{0x510BL,0xED1CL,1L,(-10L)},{0x8418L,0xED83L,0xBD07L,0x0841L},{0x6BC9L,0x32F4L,(-1L),0xEEF5L},{0x1C0EL,0x84F2L,1L,(-9L)},{(-9L),0x6BC9L,(-1L),0x6BC9L},{0x93EEL,0xD92DL,0x0841L,0x0B9BL},{0x7360L,(-1L),0x36F6L,0xED1CL},{0xD92DL,4L,(-6L),0x6B02L},{(-10L),0x6773L,0x32F4L,1L}},{{(-1L),0x6B02L,0x0B9BL,(-1L)},{0L,(-6L),0x93EEL,(-1L)},{0x0841L,0x36F6L,0x84F2L,0x155EL},{0x6773L,(-9L),(-1L),0x1C0EL},{0xD92DL,0x32F4L,1L,0x510BL},{(-9L),0x155EL,(-6L),0xEEF5L},{0xF950L,0L,(-9L),(-1L)},{0x8418L,0x6B02L,0xD850L,0xD850L},{(-8L),(-8L),0xAD68L,0x912EL}},{{0x0841L,0x510BL,0x1C0EL,(-1L)},{0xBDE9L,0x6DFCL,1L,0x1C0EL},{0x36F6L,0x6DFCL,(-10L),(-1L)},{0x6DFCL,0x510BL,(-6L),0x912EL},{1L,(-8L),0xF950L,0xD850L},{0xBD07L,0x6B02L,1L,(-1L)},{(-6L),0L,(-1L),0xEEF5L},{0x0841L,0x155EL,1L,0x510BL},{0x4B7CL,0x32F4L,0xC18CL,0x1C0EL}},{{0x510BL,(-9L),0x6DFCL,0x155EL},{0x32F4L,0x36F6L,(-6L),(-1L)},{0x23A6L,(-6L),0x23A6L,(-1L)},{0x155EL,0x6B02L,(-1L),1L},{(-3L),0x6773L,0xED83L,0x6B02L},{0x0841L,0xBD07L,0xED83L,0x8418L},{(-3L),0x23A6L,(-1L),0x1C0EL},{0x155EL,(-10L),0x23A6L,0xD92DL},{0x23A6L,0xD92DL,(-6L),0x0841L}}};
            int i, j, k;
            g_160 = l_177;
            if (g_111[8])
                continue;
            g_160 &= (safe_mul_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(((safe_add_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((((safe_sub_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u(l_200[1][1][6], 0x561C6BE3L)), 4294967293UL)) & 0xAB88L) , g_146), l_201[5][7][0])), l_177)) != g_52[0]), 4)), 0x9E8CL));
        }
    }
    l_202 = g_80;
    for (g_135 = (-28); (g_135 > 6); g_135++)
    { /* block id: 176 */
        l_205++;
    }
    return l_208;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_40 g_63 g_55 g_52 g_73 g_76 g_80 g_94 g_111 g_135 g_87
 * writes: g_40 g_52 g_63 g_73 g_76 g_80 g_87 g_94 g_102 g_111 g_135 g_146 g_160
 */
static const int32_t  func_7(int8_t  p_8)
{ /* block id: 5 */
    int8_t l_14 = 0x7FL;
    int32_t l_129 = 0xCBF15030L;
    int32_t l_152 = 0xE39E102BL;
    uint8_t l_173 = 0x91L;
lbl_164:
    if (func_9((0x52568108531D14CDLL & g_4), p_8, l_14, l_14))
    { /* block id: 102 */
        int32_t l_134[7][5] = {{0x394782D3L,0L,0x394782D3L,0x100BB5F2L,0L},{0x67F932FAL,0xA0CB05F2L,0x100BB5F2L,0x67F932FAL,0x100BB5F2L},{0x67F932FAL,0x67F932FAL,1L,0L,(-1L)},{0x394782D3L,(-1L),0x100BB5F2L,0x100BB5F2L,(-1L)},{(-1L),0xA0CB05F2L,0x394782D3L,(-1L),0x100BB5F2L},{0L,(-1L),1L,(-1L),0L},{0x394782D3L,0x67F932FAL,0xA0CB05F2L,0x100BB5F2L,0x67F932FAL}};
        uint64_t l_139 = 0x8D04C5E4B60272E8LL;
        int8_t l_145 = (-6L);
        int i, j;
lbl_136:
        for (g_80 = 0; (g_80 <= 5); g_80 += 1)
        { /* block id: 105 */
            int i;
            l_129 = (safe_div_func_int32_t_s_s((g_52[g_80] , g_111[(g_80 + 2)]), 0xBE62397AL));
        }
        for (l_14 = (-1); (l_14 == (-28)); l_14--)
        { /* block id: 110 */
            g_135 = (safe_mod_func_uint64_t_u_u(l_134[1][0], 9UL));
        }
        if (g_76)
            goto lbl_136;
        for (g_63 = 9; (g_63 != 23); ++g_63)
        { /* block id: 116 */
            uint8_t l_144 = 8UL;
            l_139--;
            g_146 = (safe_mod_func_uint32_t_u_u(((l_144 , l_145) , 0x0DF10CB6L), 0xBEBE6BB7L));
            if (p_8)
                break;
            if (l_134[1][0])
                break;
        }
    }
    else
    { /* block id: 122 */
        int16_t l_151 = (-7L);
        l_152 |= (safe_div_func_uint64_t_u_u((((safe_div_func_uint32_t_u_u((p_8 , l_151), p_8)) , g_135) , p_8), l_129));
        for (g_76 = 0; (g_76 > 21); g_76++)
        { /* block id: 126 */
            int32_t l_159 = 0x44AB526FL;
            l_159 &= (safe_add_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u(p_8, l_152)), l_129));
            return p_8;
        }
        g_160 = p_8;
        for (p_8 = 17; (p_8 >= (-10)); --p_8)
        { /* block id: 133 */
            int64_t l_163 = 1L;
            g_160 = (l_163 <= g_4);
        }
        if (g_80)
            goto lbl_164;
    }
    for (g_63 = 1; (g_63 <= 5); g_63 += 1)
    { /* block id: 140 */
        int64_t l_169 = 0xDBBAE03F5253A837LL;
        if (p_8)
            goto lbl_164;
        for (g_87 = 0; (g_87 <= 5); g_87 += 1)
        { /* block id: 144 */
            int32_t l_170 = 1L;
            int i;
            l_169 |= ((safe_mul_func_int8_t_s_s((safe_add_func_uint16_t_u_u(g_111[(g_87 + 1)], (-10L))), g_111[g_63])) , 0x1CDE3425L);
            l_170 = (((g_52[g_87] , p_8) || 0x83L) > l_129);
            l_170 = g_111[8];
        }
    }
    l_173 ^= (((((((safe_mod_func_uint8_t_u_u(7UL, 0x94L)) ^ p_8) , g_111[8]) && 0x0C68L) && (-7L)) > p_8) || g_52[5]);
    return l_129;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_40 g_63 g_55 g_52 g_73 g_76 g_80 g_94
 * writes: g_40 g_52 g_63 g_73 g_76 g_80 g_87 g_94 g_102 g_111
 */
static int32_t  func_9(uint8_t  p_10, const int8_t  p_11, uint32_t  p_12, uint64_t  p_13)
{ /* block id: 6 */
    int64_t l_20 = 0x46B43D2717F4039ELL;
    int32_t l_112 = 1L;
    int8_t l_117 = 0xF7L;
    int16_t l_123 = 1L;
    l_112 = func_15(l_20, p_12, g_4, l_20);
    l_112 = ((((safe_add_func_uint32_t_u_u(((((((((((((safe_mod_func_int8_t_s_s(((((l_112 <= 7UL) < l_117) ^ p_10) ^ l_117), g_80)) <= 0xE86AL) && 3UL) | p_10) && 0xA7L) & p_10) || 0x7FADL) & (-1L)) , l_112) , p_10) <= g_52[0]) || p_10), 0x1652FD55L)) | 0xEEAC9F24D48F7C91LL) != 8L) || g_4);
    for (g_80 = 0; (g_80 < 22); g_80 = safe_add_func_int8_t_s_s(g_80, 1))
    { /* block id: 92 */
        int16_t l_120 = (-7L);
        int32_t l_126 = 1L;
        l_112 = (l_120 > p_12);
        for (l_117 = 29; (l_117 > (-24)); l_117 = safe_sub_func_uint64_t_u_u(l_117, 7))
        { /* block id: 96 */
            l_123 = ((p_11 , 3UL) >= l_120);
        }
        l_126 = (((((safe_sub_func_int32_t_s_s(p_11, l_120)) | 0x05L) || l_20) > 5L) ^ g_55);
    }
    return g_94;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_40 g_63 g_55 g_52 g_73 g_76 g_80 g_94
 * writes: g_40 g_52 g_63 g_73 g_76 g_80 g_87 g_94 g_102 g_111
 */
static int32_t  func_15(int16_t  p_16, uint16_t  p_17, int64_t  p_18, uint32_t  p_19)
{ /* block id: 7 */
    uint64_t l_21 = 1UL;
    int32_t l_45[8][2][7] = {{{0x06054615L,0xFA46B4C0L,0xFA46B4C0L,0x06054615L,0xFA46B4C0L,0xFA46B4C0L,0x06054615L},{6L,(-1L),6L,7L,0x7974D377L,7L,6L}},{{0x06054615L,0x06054615L,0x8CE68266L,0x06054615L,0x06054615L,0x8CE68266L,0x06054615L},{0x7974D377L,7L,6L,(-1L),6L,7L,0x7974D377L}},{{0xFA46B4C0L,0x06054615L,0xFA46B4C0L,0xFA46B4C0L,0x06054615L,0xFA46B4C0L,0xFA46B4C0L},{0x7974D377L,(-1L),0xFF74B76FL,(-1L),0x7974D377L,0xB72B46FAL,6L}},{{0xFA46B4C0L,0x8CE68266L,0x8CE68266L,0xFA46B4C0L,0x8CE68266L,0x8CE68266L,0xFA46B4C0L},{0xFF74B76FL,7L,0xFF74B76FL,0xB72B46FAL,6L,0xB72B46FAL,0xFF74B76FL}},{{0xFA46B4C0L,0xFA46B4C0L,0x06054615L,0xFA46B4C0L,0xFA46B4C0L,0x06054615L,0xFA46B4C0L},{6L,0xB72B46FAL,0xFF74B76FL,7L,0xFF74B76FL,0xB72B46FAL,6L}},{{0x8CE68266L,0xFA46B4C0L,0x8CE68266L,0x8CE68266L,0xFA46B4C0L,0x8CE68266L,0x8CE68266L},{6L,7L,0x7974D377L,7L,6L,(-1L),6L}},{{0xFA46B4C0L,0x8CE68266L,0x8CE68266L,0xFA46B4C0L,0x8CE68266L,0x8CE68266L,0xFA46B4C0L},{0xFF74B76FL,7L,0xFF74B76FL,0xB72B46FAL,6L,0xB72B46FAL,0xFF74B76FL}},{{0xFA46B4C0L,0xFA46B4C0L,0x06054615L,0xFA46B4C0L,0xFA46B4C0L,0x06054615L,0xFA46B4C0L},{6L,0xB72B46FAL,0xFF74B76FL,7L,0xFF74B76FL,0xB72B46FAL,6L}}};
    const uint8_t l_109[5][2] = {{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL},{7UL,7UL}};
    int i, j, k;
lbl_64:
    l_21--;
    for (p_19 = (-25); (p_19 == 8); p_19 = safe_add_func_int32_t_s_s(p_19, 1))
    { /* block id: 11 */
        uint8_t l_31 = 0x0FL;
        int32_t l_51 = 0x119B5F81L;
        g_40 ^= func_26((((safe_mod_func_int32_t_s_s(((p_18 & p_16) ^ g_4), 0xD38CA8C9L)) , l_21) <= l_31), g_4);
        if (((safe_add_func_int64_t_s_s(((g_4 & 1UL) , p_16), 0x242EA6AE20245597LL)) & g_40))
        { /* block id: 23 */
            const uint16_t l_44[1] = {3UL};
            int i;
            if (g_40)
                break;
            l_45[6][1][6] = (~(l_44[0] || g_40));
            l_51 = ((~(((safe_mul_func_int16_t_s_s((((safe_lshift_func_uint16_t_u_u(0xE63DL, l_21)) <= 0xA6CBABA27FA52E96LL) , p_17), p_16)) == 5UL) == p_16)) != l_44[0]);
        }
        else
        { /* block id: 27 */
            g_52[0] = g_4;
        }
        for (p_18 = 0; (p_18 == 24); p_18 = safe_add_func_int16_t_s_s(p_18, 8))
        { /* block id: 32 */
            uint16_t l_56 = 0x075FL;
            ++l_56;
        }
        for (p_16 = 1; (p_16 >= 0); p_16 -= 1)
        { /* block id: 37 */
            const uint32_t l_61 = 0x4ED1E225L;
            uint32_t l_62[6][3];
            int32_t l_67 = 0x55BD1B84L;
            int i, j;
            for (i = 0; i < 6; i++)
            {
                for (j = 0; j < 3; j++)
                    l_62[i][j] = 0xC26B3FA4L;
            }
            g_63 &= ((((safe_rshift_func_uint8_t_u_s(l_61, 7)) && 0xC1E9780CE5FA5B82LL) >= 0x9CL) >= l_62[0][1]);
            if (p_17)
                goto lbl_64;
            l_67 = (safe_add_func_uint64_t_u_u(g_55, p_18));
        }
    }
    for (g_40 = 0; (g_40 < (-15)); g_40--)
    { /* block id: 45 */
        int8_t l_72 = 1L;
        for (p_16 = 0; (p_16 <= 1); p_16 += 1)
        { /* block id: 48 */
            int i;
            return g_52[p_16];
        }
        if ((safe_div_func_uint16_t_u_u((1L & p_18), g_63)))
        { /* block id: 51 */
            l_45[5][0][6] = ((g_55 | l_45[6][1][6]) , 0x2D295891L);
        }
        else
        { /* block id: 53 */
            return l_45[6][1][6];
        }
        if (((l_45[5][1][1] <= 1UL) || l_72))
        { /* block id: 56 */
            g_73--;
            if (l_21)
                continue;
            g_76++;
        }
        else
        { /* block id: 60 */
            uint32_t l_79[2][10][7] = {{{0x1E6F706CL,0x3AA5B3E5L,0x3AA5B3E5L,0x1E6F706CL,8UL,0xF00AFC62L,0x02D27084L},{0xCCB67721L,0xF00AFC62L,6UL,8UL,8UL,6UL,0xF00AFC62L},{8UL,0xCCB67721L,1UL,0UL,0x3AA5B3E5L,0x02D27084L,0x02D27084L},{1UL,0xCCB67721L,8UL,0xCCB67721L,1UL,0UL,0x3AA5B3E5L},{6UL,0xF00AFC62L,0xCCB67721L,0UL,0xF3B42422L,0UL,0xCCB67721L},{0x3AA5B3E5L,0x3AA5B3E5L,0x1E6F706CL,8UL,0xF00AFC62L,0x02D27084L,6UL},{6UL,0UL,0x1E6F706CL,0x1E6F706CL,0UL,6UL,0xF3B42422L},{1UL,0x1E6F706CL,0xCCB67721L,0xF3B42422L,0xF00AFC62L,0xF00AFC62L,0xF3B42422L},{8UL,0xFD6319DCL,8UL,0x02D27084L,0xF3B42422L,1UL,6UL},{0xCCB67721L,0x1E6F706CL,1UL,0x02D27084L,1UL,0x1E6F706CL,0xCCB67721L}},{{0x1E6F706CL,0UL,6UL,0xF3B42422L,0x3AA5B3E5L,1UL,0x3AA5B3E5L},{0x1E6F706CL,0x3AA5B3E5L,0x3AA5B3E5L,0x1E6F706CL,8UL,0xF00AFC62L,0x02D27084L},{0xCCB67721L,0xF00AFC62L,6UL,8UL,8UL,6UL,0xF00AFC62L},{8UL,0xCCB67721L,1UL,0UL,0x3AA5B3E5L,0x02D27084L,0x02D27084L},{1UL,0xCCB67721L,8UL,0xCCB67721L,1UL,0UL,0x3AA5B3E5L},{6UL,0xF00AFC62L,0xCCB67721L,0UL,0xF00AFC62L,0x1E6F706CL,0xFD6319DCL},{0x02D27084L,0x02D27084L,0x3AA5B3E5L,0UL,1UL,0xCCB67721L,8UL},{8UL,0x1E6F706CL,0x3AA5B3E5L,0x3AA5B3E5L,0x1E6F706CL,8UL,0xF00AFC62L},{6UL,0x3AA5B3E5L,0xFD6319DCL,0xF00AFC62L,1UL,1UL,0xF00AFC62L},{0UL,0xF3B42422L,0UL,0xCCB67721L,0xF00AFC62L,6UL,8UL}}};
            int i, j, k;
            l_45[6][1][6] |= ((((p_17 , g_4) , 0xA3AFD543L) < l_79[1][9][6]) , g_55);
        }
        g_80++;
    }
    for (g_40 = 0; (g_40 > 29); ++g_40)
    { /* block id: 67 */
        uint32_t l_85 = 0x94A5162CL;
        int32_t l_86 = (-1L);
        int32_t l_93[9][2] = {{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L},{0x2479DA46L,0x2479DA46L}};
        int i, j;
        if (p_19)
        { /* block id: 68 */
            l_86 = l_85;
        }
        else
        { /* block id: 70 */
            uint32_t l_92 = 1UL;
            if (g_73)
                break;
            g_87 = (p_19 && g_80);
            l_45[6][1][6] = (safe_rshift_func_int8_t_s_u((safe_lshift_func_uint16_t_u_u(g_76, p_16)), p_19));
            l_92 = (-1L);
        }
        l_86 |= (((0x1DF8105AL > l_45[4][0][1]) >= 1UL) & p_19);
        g_94--;
        if (((safe_rshift_func_int8_t_s_u(((((safe_add_func_int16_t_s_s(l_45[6][0][1], 0L)) > l_93[5][1]) <= l_45[2][1][4]) , 0L), 5)) | l_93[5][1]))
        { /* block id: 78 */
            uint32_t l_101 = 0UL;
            l_101 ^= (0xB882180DL >= l_86);
            g_102 = (((((g_80 || g_80) , 0xF4L) > g_80) < 0x71674060L) >= 0x45L);
            l_45[6][1][6] = (safe_sub_func_int64_t_s_s((((((safe_div_func_int8_t_s_s((safe_div_func_uint8_t_u_u(((l_45[0][1][0] > 0x8ECB2A787E59EB03LL) && g_52[0]), p_19)), g_40)) == 255UL) < 0x83L) & 0x3F915BDED785604ALL) , l_45[6][1][6]), l_109[3][0]));
        }
        else
        { /* block id: 82 */
            uint32_t l_110 = 0xD5AEA95DL;
            l_110 = 0xB672C646L;
            g_111[8] = ((((p_17 ^ g_94) || p_17) ^ g_63) && g_55);
        }
    }
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static int32_t  func_26(int8_t  p_27, uint32_t  p_28)
{ /* block id: 12 */
    int32_t l_32[9] = {0xD04549C4L,0x47C914A3L,0xD04549C4L,0x47C914A3L,0xD04549C4L,0x47C914A3L,0xD04549C4L,0x47C914A3L,0xD04549C4L};
    int i;
    for (p_27 = 8; (p_27 >= 3); p_27 -= 1)
    { /* block id: 15 */
        int64_t l_39 = 0L;
        int i;
        l_32[p_27] = l_32[p_27];
        l_32[p_27] = ((safe_mod_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((safe_add_func_int64_t_s_s(1L, l_32[p_27])), g_4)), p_28)) == 0x68L);
        l_39 = 0x0079D62BL;
    }
    l_32[7] = g_4;
    return p_27;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_52[i], "g_52[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_111[i], "g_111[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_135, "g_135", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_174, "g_174", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 64
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 21
breakdown:
   depth: 1, occurrence: 97
   depth: 2, occurrence: 28
   depth: 3, occurrence: 8
   depth: 4, occurrence: 6
   depth: 5, occurrence: 7
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 3
   depth: 10, occurrence: 2
   depth: 21, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 163
XXX times a non-volatile is write: 72
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 72
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 1
XXX backward jumps: 3

XXX stmts: 102
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 35
   depth: 2, occurrence: 47

XXX percentage a fresh-made variable is used: 30.8
XXX percentage an existing variable is used: 69.2
********************* end of statistics **********************/

