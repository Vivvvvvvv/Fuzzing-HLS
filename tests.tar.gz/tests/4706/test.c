/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13138239558097161420
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-1L);
static int16_t g_6 = 0xD811L;
static volatile uint16_t g_7[10] = {0xA2B3L,1UL,0xCABFL,0xCABFL,1UL,0xA2B3L,1UL,0xCABFL,0xCABFL,1UL};
static volatile int8_t g_18 = 0xB6L;/* VOLATILE GLOBAL g_18 */
static volatile int16_t g_21 = 0xE3D3L;/* VOLATILE GLOBAL g_21 */
static int32_t g_46 = 0L;
static uint64_t g_47 = 0x3592E7BAA9D707D8LL;
static volatile uint32_t g_54 = 4294967286UL;/* VOLATILE GLOBAL g_54 */
static uint8_t g_77 = 0x12L;
static int32_t g_82 = 0xF4E4D73BL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_25(uint8_t  p_26, uint32_t  p_27, int32_t  p_28);
static const uint64_t  func_29(uint32_t  p_30, int32_t  p_31, uint64_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_6 g_2 g_21 g_47 g_18 g_46 g_54 g_77 g_82
 * writes: g_7 g_47 g_54 g_46 g_77 g_82
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_3 = 0x96L;
    int32_t l_4 = (-1L);
    int32_t l_5[2];
    uint64_t l_93 = 18446744073709551615UL;
    int i;
    for (i = 0; i < 2; i++)
        l_5[i] = 0x9CFE0482L;
    --g_7[2];
    if (((safe_sub_func_int64_t_s_s(g_7[2], 0x566A927213EC752FLL)) < l_5[0]))
    { /* block id: 2 */
        int64_t l_20 = 5L;
        int32_t l_75 = (-1L);
        int32_t l_76 = 0x174ED7B9L;
        if ((safe_mul_func_int8_t_s_s((safe_sub_func_int16_t_s_s((safe_div_func_uint16_t_u_u(1UL, 0x9051L)), l_5[1])), g_7[2])))
        { /* block id: 3 */
            int32_t l_19 = 0x93BD5DE1L;
            uint8_t l_22 = 0xD7L;
            l_22++;
            l_5[0] = (func_25((func_29((safe_sub_func_uint32_t_u_u(0x7C422D5FL, 0x2ABF7C2FL)), l_3, g_6) , g_18), g_2, g_46) , l_20);
            l_5[0] = (0x7588L < g_46);
            g_46 &= ((safe_lshift_func_uint8_t_u_u(255UL, 3)) , l_20);
        }
        else
        { /* block id: 22 */
            uint32_t l_73 = 4294967290UL;
            int32_t l_74[10] = {0x66485393L,0xA6F2DB44L,(-1L),(-1L),0xA6F2DB44L,0x66485393L,0xA6F2DB44L,(-1L),(-1L),0xA6F2DB44L};
            int i;
            l_73 = l_20;
            g_46 ^= 6L;
            l_74[3] = l_20;
        }
        g_46 = g_18;
        for (l_3 = 0; (l_3 <= 9); l_3 += 1)
        { /* block id: 30 */
            --g_77;
            g_46 = l_5[1];
        }
        g_82 |= (safe_add_func_int16_t_s_s(l_75, l_20));
    }
    else
    { /* block id: 35 */
        uint64_t l_86 = 0x974433F2F19166C0LL;
        int32_t l_87 = 0xAE0D08F1L;
        l_87 = ((safe_sub_func_uint8_t_u_u((+(((0x96L & l_86) > 18446744073709551610UL) <= g_46)), 1L)) && g_46);
        for (g_82 = 22; (g_82 <= (-17)); g_82 = safe_sub_func_int32_t_s_s(g_82, 7))
        { /* block id: 39 */
            int64_t l_90 = 0xBF40F8590C99E848LL;
            g_46 ^= (g_2 <= l_90);
            g_46 = g_47;
            if (g_18)
                continue;
        }
        l_87 = ((((safe_lshift_func_uint8_t_u_s(g_54, 3)) , 4294967295UL) && g_21) , g_82);
        l_5[0] = ((((0UL == g_18) , l_5[0]) && l_86) , g_2);
    }
    --l_93;
    return g_77;
}


/* ------------------------------------------ */
/* 
 * reads : g_54 g_7 g_2 g_46
 * writes: g_54
 */
static int32_t  func_25(uint8_t  p_26, uint32_t  p_27, int32_t  p_28)
{ /* block id: 10 */
    int8_t l_50 = (-4L);
    int32_t l_51 = (-1L);
    int32_t l_52 = (-6L);
    int32_t l_53[9];
    int i;
    for (i = 0; i < 9; i++)
        l_53[i] = 0x8E0EA626L;
    ++g_54;
    for (l_50 = 0; (l_50 >= 0); --l_50)
    { /* block id: 14 */
        return p_26;
    }
    l_51 &= ((safe_lshift_func_uint8_t_u_s((((safe_add_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u(((safe_mul_func_uint16_t_u_u((((safe_lshift_func_int8_t_s_u((safe_add_func_uint8_t_u_u(((-1L) == p_26), l_53[2])), 5)) , (-6L)) & p_26), 0x4E19L)) >= 0x64L), g_7[6])), g_2)) || 0x2E4BCB8161DBFA2FLL) , g_46), 3)) | 0xC59A6287L);
    return p_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_21 g_47
 * writes: g_47
 */
static const uint64_t  func_29(uint32_t  p_30, int32_t  p_31, uint64_t  p_32)
{ /* block id: 5 */
    int32_t l_37 = 0L;
    int32_t l_42 = 0L;
    int32_t l_43 = 7L;
    int32_t l_44 = 0x9867F5D1L;
    int32_t l_45[6] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
    int i;
    l_37 = (safe_mul_func_uint16_t_u_u(0x0DFEL, g_2));
    l_42 = (((safe_sub_func_int32_t_s_s(((safe_mul_func_uint8_t_u_u(l_37, g_21)) , p_31), p_31)) > l_37) > 4L);
    g_47++;
    return l_44;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 40
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 10, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 41
XXX times a non-volatile is write: 24
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 37
XXX percentage of non-volatile access: 84.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 33
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 9
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

