/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14391238244208341664
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_4 = 0xDAL;
static volatile int64_t g_5[2] = {0x4E1265AB3E90A624LL,0x4E1265AB3E90A624LL};
static volatile int64_t g_10[6] = {(-5L),(-1L),(-1L),(-5L),(-1L),(-1L)};
static volatile uint16_t g_13 = 0x100CL;/* VOLATILE GLOBAL g_13 */
static uint32_t g_20 = 18446744073709551609UL;
static int32_t g_27 = 0x6B379904L;
static int8_t g_34[10] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
static volatile uint64_t g_36 = 18446744073709551615UL;/* VOLATILE GLOBAL g_36 */
static volatile uint16_t g_56[9] = {65531UL,65530UL,65531UL,65531UL,65530UL,65531UL,65531UL,65530UL,65531UL};
static uint32_t g_58 = 18446744073709551615UL;
static int32_t g_61 = (-1L);
static uint8_t g_70 = 1UL;
static uint16_t g_74 = 0xCEC8L;
static int32_t g_76 = 0xDBD1BD9FL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint32_t  func_2(uint32_t  p_3);
static int16_t  func_41(int8_t  p_42, int8_t  p_43, uint32_t  p_44, uint32_t  p_45, uint32_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_13 g_20 g_36 g_10 g_5 g_27 g_58 g_61
 * writes: g_13 g_20 g_36 g_56 g_58 g_61 g_70 g_74 g_76
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_39 = 0x5BF8L;
    int32_t l_64 = 0x0F0C0ED6L;
    if ((func_2(g_4) , l_39))
    { /* block id: 22 */
        g_61 &= (+(((func_41(((safe_add_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u(251UL, g_5[1])) ^ l_39), g_27)) == l_39), l_39, l_39, l_39, g_27) , g_20) , g_10[2]) <= 0x62CCL));
        l_64 = (((safe_div_func_uint32_t_u_u(0xAADAF8D9L, 5UL)) > 1L) && 6UL);
    }
    else
    { /* block id: 30 */
        int32_t l_69[2];
        int i;
        for (i = 0; i < 2; i++)
            l_69[i] = (-1L);
        g_70 = (safe_mod_func_uint64_t_u_u((safe_mod_func_int64_t_s_s((g_5[0] > l_69[1]), l_69[0])), l_69[0]));
        if ((~(safe_lshift_func_uint8_t_u_u(l_64, 6))))
        { /* block id: 32 */
            uint64_t l_75 = 0x2E3BD65BDF5444FELL;
            g_74 = (-3L);
            g_76 = (g_61 , l_75);
        }
        else
        { /* block id: 35 */
            uint32_t l_79 = 18446744073709551615UL;
            uint32_t l_80 = 4294967290UL;
            l_80 = (safe_sub_func_uint32_t_u_u(l_79, l_39));
        }
    }
    return g_10[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_20 g_4 g_36 g_10
 * writes: g_13 g_20 g_36
 */
static uint32_t  func_2(uint32_t  p_3)
{ /* block id: 1 */
    uint8_t l_6 = 0xE7L;
    int32_t l_11 = 0x18E418A5L;
    int32_t l_23 = 5L;
    int32_t l_29 = 0xDBCABEBFL;
    int16_t l_30[4];
    int i;
    for (i = 0; i < 4; i++)
        l_30[i] = 0xAF90L;
    if (p_3)
    { /* block id: 2 */
        int64_t l_9 = 0x80444555950707DFLL;
        int32_t l_12[4] = {0xE17C1097L,0xE17C1097L,0xE17C1097L,0xE17C1097L};
        int i;
        ++l_6;
        g_13--;
        g_20 ^= (safe_mod_func_int16_t_s_s((safe_sub_func_uint64_t_u_u(((l_6 == l_11) > p_3), 0L)), 65535UL));
    }
    else
    { /* block id: 6 */
        uint32_t l_26 = 9UL;
        int32_t l_28[9] = {1L,1L,0xCFF15CC7L,1L,1L,0xCFF15CC7L,1L,1L,0xCFF15CC7L};
        uint8_t l_31 = 0UL;
        int i;
        l_23 &= (safe_div_func_int8_t_s_s((g_4 && l_11), l_6));
        for (g_20 = 0; (g_20 != 49); g_20 = safe_add_func_int32_t_s_s(g_20, 7))
        { /* block id: 10 */
            if (l_26)
                break;
        }
        --l_31;
        for (p_3 = 0; (p_3 <= 5); p_3 += 1)
        { /* block id: 16 */
            int32_t l_35 = 0x62B2FAA9L;
            int i;
            ++g_36;
            return g_10[p_3];
        }
    }
    return l_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_58
 * writes: g_56 g_58
 */
static int16_t  func_41(int8_t  p_42, int8_t  p_43, uint32_t  p_44, uint32_t  p_45, uint32_t  p_46)
{ /* block id: 23 */
    int8_t l_55 = (-4L);
    int32_t l_57 = (-1L);
    g_56[8] = ((safe_rshift_func_int8_t_s_u(((safe_mod_func_uint64_t_u_u((p_46 != 1UL), l_55)) , p_42), 2)) , 0x39C1D55EL);
    l_57 |= (-1L);
    ++g_58;
    return l_55;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_36, "g_36", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_56[i], "g_56[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 33
XXX times a non-volatile is write: 14
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 85.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 25
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 11
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

