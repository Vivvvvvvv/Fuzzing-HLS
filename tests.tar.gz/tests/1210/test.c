/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3251940439155037672
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0L;
static uint32_t g_6 = 1UL;
static uint32_t g_18 = 18446744073709551607UL;
static int64_t g_24 = 0x216709E149CFF29CLL;
static uint16_t g_37 = 0x2A93L;
static int64_t g_50 = 1L;
static uint8_t g_57 = 0xAFL;
static uint32_t g_58 = 0xF1398883L;
static uint64_t g_61 = 18446744073709551607UL;
static uint32_t g_76[4][7][6] = {{{0x93872454L,0UL,0x3152899DL,0x7CB4F910L,0x3152899DL,0UL},{0x178D33F6L,0x93872454L,0x3152899DL,9UL,18446744073709551615UL,0x7CB4F910L},{0x8899A862L,9UL,0UL,0UL,9UL,0x8899A862L},{0UL,9UL,0x8899A862L,18446744073709551609UL,18446744073709551615UL,0x3152899DL},{0x3152899DL,0x93872454L,0x178D33F6L,0x93872454L,0x3152899DL,9UL},{0x3152899DL,0UL,0x93872454L,18446744073709551609UL,0UL,0UL},{0UL,18446744073709551615UL,18446744073709551615UL,0UL,0x178D33F6L,0UL}},{{0x8899A862L,0UL,0x93872454L,9UL,0UL,0UL},{9UL,18446744073709551609UL,9UL,0x93872454L,0UL,0x8899A862L},{18446744073709551615UL,0x3152899DL,0x178D33F6L,9UL,9UL,0x178D33F6L},{0x7CB4F910L,0x7CB4F910L,18446744073709551615UL,9UL,0x3152899DL,0x93872454L},{18446744073709551615UL,18446744073709551615UL,0x8899A862L,0x93872454L,0x8899A862L,18446744073709551615UL},{9UL,18446744073709551615UL,0x8899A862L,0UL,0x7CB4F910L,0x93872454L},{0x178D33F6L,0UL,18446744073709551615UL,18446744073709551615UL,0UL,0x178D33F6L}},{{18446744073709551615UL,0UL,0x178D33F6L,0UL,0x7CB4F910L,0x8899A862L},{0x8899A862L,18446744073709551615UL,9UL,18446744073709551615UL,0x8899A862L,0UL},{0x8899A862L,18446744073709551615UL,18446744073709551615UL,0UL,0x3152899DL,0x3152899DL},{18446744073709551615UL,0x7CB4F910L,0x7CB4F910L,18446744073709551615UL,9UL,0x3152899DL},{0x178D33F6L,0x3152899DL,18446744073709551615UL,0UL,0UL,0UL},{9UL,18446744073709551609UL,9UL,0x93872454L,0UL,0x8899A862L},{18446744073709551615UL,0x3152899DL,0x178D33F6L,9UL,9UL,0x178D33F6L}},{{0x7CB4F910L,0x7CB4F910L,18446744073709551615UL,9UL,0x3152899DL,0x93872454L},{18446744073709551615UL,18446744073709551615UL,0x8899A862L,0x93872454L,0x8899A862L,18446744073709551615UL},{9UL,18446744073709551615UL,0x8899A862L,0UL,0x7CB4F910L,0x93872454L},{0x178D33F6L,0UL,18446744073709551615UL,18446744073709551615UL,0UL,0x178D33F6L},{18446744073709551615UL,0UL,0x178D33F6L,0UL,0x7CB4F910L,0x8899A862L},{0x8899A862L,18446744073709551615UL,9UL,18446744073709551615UL,0x8899A862L,0UL},{0x8899A862L,18446744073709551615UL,18446744073709551615UL,0UL,0x3152899DL,0x3152899DL}}};
static int32_t g_87 = 1L;
static uint32_t g_88[1][4] = {{9UL,9UL,9UL,9UL}};
static int32_t g_95 = 0x296E5626L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_8(int32_t  p_9, uint8_t  p_10, uint32_t  p_11);
static int32_t  func_25(int32_t  p_26);
static int64_t  func_27(int64_t  p_28, int32_t  p_29);
static int16_t  func_32(uint32_t  p_33, uint32_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_24 g_18 g_37 g_57 g_58 g_50 g_61 g_88
 * writes: g_2 g_6 g_18 g_24 g_37 g_50 g_57 g_58 g_61 g_76 g_87 g_88 g_95
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_5 = 255UL;
    for (g_2 = 13; (g_2 == 14); g_2++)
    { /* block id: 3 */
        uint16_t l_7 = 6UL;
        int32_t l_97 = (-1L);
        g_6 |= ((l_5 , 0x56A9EF72D4EA6801LL) , g_2);
        l_7 |= 0x4888999DL;
        l_97 = func_8(g_2, l_7, l_5);
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_24 g_18 g_2 g_37 g_57 g_58 g_50 g_61 g_88
 * writes: g_6 g_18 g_24 g_37 g_50 g_57 g_58 g_61 g_76 g_87 g_88 g_95
 */
static int32_t  func_8(int32_t  p_9, uint8_t  p_10, uint32_t  p_11)
{ /* block id: 6 */
    uint8_t l_23 = 255UL;
    int32_t l_96 = 0x6318FFE4L;
    for (g_6 = 0; (g_6 <= 5); g_6 = safe_add_func_uint64_t_u_u(g_6, 7))
    { /* block id: 9 */
        uint64_t l_17 = 0x924B541145714FFDLL;
        for (p_10 = 0; (p_10 <= 20); p_10++)
        { /* block id: 12 */
            g_18 = ((((~l_17) && p_9) , g_6) > 0xC7D2L);
        }
    }
    g_24 &= (((((((safe_add_func_uint64_t_u_u(((safe_add_func_int64_t_s_s(0x809B4AF7BDD48407LL, l_23)) || 6UL), 0xDA8DB8846B51F0EFLL)) ^ 0x7FL) >= p_9) & 0x3DL) , p_11) , p_11) & l_23);
    l_96 = func_25((func_27((safe_add_func_int16_t_s_s((func_32((safe_div_func_int64_t_s_s(p_9, (-1L))), g_18) , 0xDD33L), 1UL)), p_11) >= 9UL));
    return p_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_57 g_58 g_50 g_6 g_37 g_18 g_61 g_88 g_2
 * writes: g_57 g_58 g_61 g_76 g_87 g_88 g_95
 */
static int32_t  func_25(int32_t  p_26)
{ /* block id: 34 */
    int64_t l_55 = 0x7C1F20CF68020C28LL;
    int64_t l_66 = 0xA60B10F657D2A19DLL;
    int32_t l_67 = (-6L);
    if ((g_24 ^ l_55))
    { /* block id: 35 */
        g_57 |= (~p_26);
        if (g_57)
            goto lbl_81;
    }
    else
    { /* block id: 37 */
        int16_t l_71[4] = {(-1L),(-1L),(-1L),(-1L)};
        int i;
        g_58 &= g_24;
        if ((((((7L <= g_50) | 3UL) > g_6) || p_26) , (-1L)))
        { /* block id: 39 */
            int32_t l_70 = 1L;
            g_61 |= (safe_rshift_func_int16_t_s_u(g_37, g_18));
            l_67 = ((safe_add_func_int8_t_s_s(((safe_sub_func_int64_t_s_s(((((p_26 | 0x2423L) , l_55) & g_6) , g_6), (-7L))) || p_26), g_50)) && l_66);
            l_71[1] = (safe_rshift_func_uint8_t_u_u(((l_70 < 0xF474372BB1342F27LL) & p_26), 2));
        }
        else
        { /* block id: 43 */
            g_76[0][0][5] = (((safe_add_func_uint8_t_u_u((safe_sub_func_int16_t_s_s(((l_71[3] & p_26) != p_26), p_26)), (-1L))) < 6UL) >= g_50);
        }
    }
lbl_81:
    l_67 = (safe_rshift_func_int16_t_s_s((safe_sub_func_int64_t_s_s((l_67 <= l_66), p_26)), p_26));
    for (l_67 = 0; (l_67 == (-5)); l_67--)
    { /* block id: 51 */
        uint64_t l_86 = 0xF3046699CBFF9F6CLL;
        l_86 = (safe_sub_func_uint16_t_u_u(65528UL, p_26));
        g_87 = l_86;
        for (g_61 = 0; (g_61 <= 3); g_61 += 1)
        { /* block id: 56 */
            --g_88[0][3];
        }
    }
    for (g_57 = (-25); (g_57 < 47); g_57++)
    { /* block id: 62 */
        for (l_67 = 0; (l_67 <= (-18)); l_67--)
        { /* block id: 65 */
            return g_2;
        }
        g_95 = (0x099BCB137123A743LL >= g_57);
    }
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_24 g_2 g_37
 * writes: g_37 g_6 g_50
 */
static int64_t  func_27(int64_t  p_28, int32_t  p_29)
{ /* block id: 19 */
    int16_t l_44[1];
    int i;
    for (i = 0; i < 1; i++)
        l_44[i] = 0x48C0L;
    g_37 = p_29;
    for (g_6 = 3; (g_6 < 9); g_6 = safe_add_func_int16_t_s_s(g_6, 3))
    { /* block id: 23 */
        int16_t l_45 = 0x1A76L;
        int32_t l_46 = 0x9242039CL;
        if (g_24)
            break;
        if ((((safe_mod_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_s(0xD982L, 12)) , p_29), l_44[0])) != 0xB108F980L) && l_44[0]))
        { /* block id: 25 */
            l_46 = (l_45 , p_29);
        }
        else
        { /* block id: 27 */
            uint16_t l_49[1][5] = {{65535UL,65535UL,65535UL,65535UL,65535UL}};
            int8_t l_54[9][1][9] = {{{0xC9L,1L,(-1L),1L,0xC9L,(-1L),(-1L),0xC9L,1L}},{{1L,(-1L),1L,(-1L),(-1L),(-1L),(-1L),1L,(-1L)}},{{(-1L),1L,(-1L),(-1L),(-1L),(-1L),1L,(-1L),1L}},{{1L,0xC9L,(-1L),(-1L),0xC9L,1L,(-1L),1L,0xC9L}},{{1L,1L,1L,1L,(-1L),0xC9L,(-1L),1L,1L}},{{(-1L),(-1L),(-1L),0xC9L,0x58L,0xC9L,(-1L),(-1L),(-1L)}},{{1L,1L,0x58L,(-1L),0x58L,1L,0xC9L,0xC9L,1L}},{{(-1L),1L,(-1L),1L,(-1L),(-1L),(-1L),(-1L),1L}},{{0xC9L,0x58L,0xC9L,(-1L),(-1L),(-1L),(-1L),0xC9L,0x58L}}};
            int i, j, k;
            l_49[0][4] = (((safe_mod_func_int64_t_s_s((p_28 & l_46), g_2)) >= g_37) < p_29);
            g_50 = l_44[0];
            l_46 &= (((((safe_lshift_func_int8_t_s_s((~p_29), l_49[0][4])) & g_24) <= 0xA0L) & l_54[0][0][3]) & p_28);
        }
    }
    return p_29;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_32(uint32_t  p_33, uint32_t  p_34)
{ /* block id: 17 */
    return p_34;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_76[i][j][k], "g_76[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_87, "g_87", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_88[i][j], "g_88[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_95, "g_95", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 29
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 37
   depth: 2, occurrence: 13
   depth: 3, occurrence: 1
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 78
XXX times a non-volatile is write: 30
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 15
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 31.5
XXX percentage an existing variable is used: 68.5
********************* end of statistics **********************/

