/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13423891478363632665
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_2 = 0UL;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_5 = 4L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = (-1L);/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7 = 0xE1D925B0L;/* VOLATILE GLOBAL g_7 */
static int32_t g_8[2][6][7] = {{{0x6DF37D45L,1L,0x2E5664DCL,0x2E5664DCL,1L,0x6DF37D45L,1L},{0xD4F2887CL,0x6DF37D45L,0x6DF37D45L,0xD4F2887CL,1L,0xD4F2887CL,0x6DF37D45L},{0xBA07E4FCL,0xBA07E4FCL,0x6DF37D45L,0x2E5664DCL,0x6DF37D45L,0xBA07E4FCL,0xBA07E4FCL},{0xBA07E4FCL,0x6DF37D45L,0x2E5664DCL,0x6DF37D45L,0xBA07E4FCL,0xBA07E4FCL,0x6DF37D45L},{0xD4F2887CL,1L,0xD4F2887CL,0x6DF37D45L,0x6DF37D45L,0xD4F2887CL,1L},{0x6DF37D45L,1L,0x2E5664DCL,0x2E5664DCL,1L,0x6DF37D45L,1L}},{{0xD4F2887CL,0x6DF37D45L,0x6DF37D45L,0xD4F2887CL,0xBA07E4FCL,0x2E5664DCL,0xD4F2887CL},{0x6DF37D45L,0x6DF37D45L,0xD4F2887CL,1L,0xD4F2887CL,0x6DF37D45L,0x6DF37D45L},{0x6DF37D45L,0xD4F2887CL,1L,0xD4F2887CL,0x6DF37D45L,0x6DF37D45L,0xD4F2887CL},{0x2E5664DCL,0xBA07E4FCL,0x2E5664DCL,0xD4F2887CL,0xD4F2887CL,0x2E5664DCL,0xBA07E4FCL},{0xD4F2887CL,0xBA07E4FCL,1L,1L,0xBA07E4FCL,0xD4F2887CL,0xBA07E4FCL},{0x2E5664DCL,0xD4F2887CL,0xD4F2887CL,0x2E5664DCL,0xBA07E4FCL,0x2E5664DCL,0xD4F2887CL}}};
static int32_t g_12[9] = {0x2E7CCC89L,0x9310C13FL,0x2E7CCC89L,0x2E7CCC89L,0x9310C13FL,0x2E7CCC89L,0x2E7CCC89L,0x9310C13FL,0x2E7CCC89L};
static volatile uint32_t g_65 = 1UL;/* VOLATILE GLOBAL g_65 */
static volatile uint32_t g_158 = 0xFFBA643CL;/* VOLATILE GLOBAL g_158 */
static uint8_t g_184 = 0xF5L;
static const int64_t g_197[3] = {0x6682BC353FDA3CCDLL,0x6682BC353FDA3CCDLL,0x6682BC353FDA3CCDLL};
static int64_t g_198 = 0x6315F1035ACF5656LL;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_30(int64_t  p_31);
static int32_t  func_32(uint64_t  p_33, int32_t  p_34, int32_t  p_35);
static int32_t  func_45(int32_t  p_46, int32_t  p_47, uint32_t  p_48, uint8_t  p_49, uint64_t  p_50);
static int32_t  func_57(uint8_t  p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_8 g_12 g_5 g_6 g_7 g_65 g_158 g_184 g_197 g_198
 * writes: g_2 g_8 g_12 g_65 g_6 g_7 g_158 g_184 g_198
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_11[7][2];
    int32_t l_16 = 5L;
    int8_t l_26 = 0x3DL;
    int32_t l_27 = 1L;
    int32_t l_195 = 0x90F1C1E6L;
    uint8_t l_196 = 0UL;
    uint8_t l_201 = 0x45L;
    int64_t l_202[5] = {0xE49FE0A111EAA1ADLL,0xE49FE0A111EAA1ADLL,0xE49FE0A111EAA1ADLL,0xE49FE0A111EAA1ADLL,0xE49FE0A111EAA1ADLL};
    int32_t l_203 = 4L;
    int32_t l_204 = 0x8AAC9750L;
    int32_t l_205 = 0xC9156F24L;
    int32_t l_206 = (-4L);
    int32_t l_207 = 0x6236462BL;
    uint16_t l_208[5][10][5] = {{{0x495DL,0xB3A1L,0x49E0L,0xAED4L,0UL},{0x6BA0L,0x5D32L,0UL,0x5D32L,0x6BA0L},{0xD032L,0xA6A7L,0UL,0x8F51L,1UL},{1UL,0UL,0x49E0L,0UL,0x76E8L},{0x76E8L,6UL,0xC467L,0xA6A7L,1UL},{0UL,0UL,0UL,0x66E0L,0x6BA0L},{1UL,0UL,0x1092L,0x1132L,0UL},{2UL,6UL,65527UL,0x9037L,0x1634L},{1UL,0UL,65532UL,0x1132L,0x5AA2L},{0xEA9DL,0xA6A7L,0x867CL,0x66E0L,0x6BB9L}},{{0xEA9DL,0x5D32L,65526UL,0xA6A7L,0x033FL},{1UL,0xB3A1L,0xE563L,0UL,0xD032L},{2UL,0x1132L,65526UL,0x8F51L,65535UL},{1UL,4UL,0x867CL,0x5D32L,65535UL},{0UL,0x4A4FL,65532UL,0xAED4L,0xD032L},{0x76E8L,0xAED4L,65527UL,2UL,0x033FL},{1UL,0x4A4FL,0x1092L,0x6302L,0x6BB9L},{0xD032L,4UL,0UL,0x6302L,0x5AA2L},{0x6BA0L,0x1132L,0xC467L,2UL,0x1634L},{0x495DL,0xB3A1L,0x49E0L,0xAED4L,0UL}},{{0x6BA0L,0x5D32L,0UL,0x5D32L,0x6BA0L},{0xD032L,0xA6A7L,0UL,0x8F51L,1UL},{1UL,0UL,0x49E0L,0UL,0x76E8L},{0x76E8L,6UL,0xC467L,0xA6A7L,1UL},{0UL,0UL,0UL,0x66E0L,0x6BA0L},{1UL,0UL,0x1092L,0x1132L,0UL},{2UL,6UL,65527UL,0x9037L,0x1634L},{1UL,0x2A12L,9UL,0xCDA2L,0x9037L},{65527UL,0xA5C9L,65535UL,0x30F8L,0xAED4L},{65527UL,1UL,65533UL,0xA5C9L,0x6302L}},{{0x66E0L,0xE491L,0x06D3L,0UL,0x1132L},{0xB3A1L,0xCDA2L,65533UL,0x84E0L,6UL},{1UL,9UL,65535UL,1UL,6UL},{0UL,65531UL,9UL,0x5CE3L,0x1132L},{1UL,0x5CE3L,0xFFB3L,1UL,0x6302L},{0x8F51L,65531UL,65532UL,1UL,0xAED4L},{0x1132L,9UL,0xBBA6L,1UL,0x9037L},{0x5D32L,0xCDA2L,0UL,1UL,1UL},{0UL,0xE491L,1UL,0x5CE3L,0UL},{0x5D32L,1UL,65535UL,1UL,0x5D32L}},{{0x1132L,0xA5C9L,65535UL,0x84E0L,1UL},{0x8F51L,0x2A12L,1UL,0UL,1UL},{1UL,1UL,0UL,0xA5C9L,1UL},{0UL,0UL,0xBBA6L,0x30F8L,0x5D32L},{1UL,0UL,65532UL,0xCDA2L,0UL},{0xB3A1L,1UL,0xFFB3L,65535UL,1UL},{0x66E0L,0x2A12L,9UL,0xCDA2L,0x9037L},{65527UL,0xA5C9L,65535UL,0x30F8L,0xAED4L},{65527UL,1UL,65533UL,0xA5C9L,0x6302L},{0x66E0L,0xE491L,0x06D3L,0UL,0x1132L}}};
    int i, j, k;
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 2; j++)
            l_11[i][j] = 0x412DF3D3L;
    }
    ++g_2;
    for (g_8[0][4][6] = (-11); (g_8[0][4][6] == (-8)); ++g_8[0][4][6])
    { /* block id: 4 */
        const uint32_t l_15 = 0x3F5E3D1AL;
        for (g_12[2] = 1; (g_12[2] >= 0); g_12[2] -= 1)
        { /* block id: 7 */
            uint32_t l_19 = 1UL;
            int32_t l_20[1];
            int i, j;
            for (i = 0; i < 1; i++)
                l_20[i] = 0x6A0122D8L;
            l_16 = (((((safe_mod_func_int64_t_s_s(((0x64L || l_11[(g_12[2] + 2)][g_12[2]]) >= l_11[(g_12[2] + 2)][g_12[2]]), g_8[1][0][2])) ^ (-3L)) && 0xD1CB6A7F4EA14C55LL) | l_11[5][0]) ^ l_15);
            if (l_15)
                goto lbl_23;
            l_16 = ((safe_mod_func_int8_t_s_s((-1L), l_11[4][1])) || g_5);
            l_20[0] |= ((((l_19 >= g_12[2]) >= l_15) , 1L) || g_12[2]);
            l_16 = g_5;
        }
        if (g_12[2])
            continue;
    }
    l_16 = (l_11[6][1] > g_12[2]);
    if ((g_8[0][4][6] & 0x5E0CL))
    { /* block id: 16 */
        l_16 ^= 0x3631AF66L;
    }
    else
    { /* block id: 18 */
lbl_23:
        for (l_16 = 11; (l_16 < (-3)); l_16 = safe_sub_func_int64_t_s_s(l_16, 2))
        { /* block id: 21 */
            g_8[0][4][6] |= 0L;
        }
        g_12[2] = (((safe_div_func_int64_t_s_s((g_6 , g_7), l_26)) < l_27) >= 0L);
        for (l_26 = 2; (l_26 <= 8); l_26 += 1)
        { /* block id: 28 */
            int i;
            g_198 |= (safe_rshift_func_int16_t_s_s(((func_30(g_12[l_26]) != l_195) < l_196), g_197[1]));
            if (g_12[l_26])
                continue;
            l_16 &= (((safe_mod_func_int64_t_s_s(g_8[1][2][0], l_201)) >= 1L) , g_6);
            --l_208[3][6][1];
        }
        for (g_198 = (-11); (g_198 < 10); g_198++)
        { /* block id: 132 */
            g_8[0][4][6] = (safe_rshift_func_int8_t_s_s(g_6, g_198));
        }
    }
    return g_8[0][4][6];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_8 g_6 g_12 g_7 g_65 g_5 g_158 g_184
 * writes: g_8 g_12 g_65 g_6 g_7 g_158 g_184
 */
static int32_t  func_30(int64_t  p_31)
{ /* block id: 29 */
    int64_t l_36 = 0x5D742CC3231A2955LL;
    int8_t l_166[4][9] = {{0xF4L,0x48L,0xF4L,0x96L,6L,0x96L,0xF4L,0x48L,0xF4L},{0x3BL,(-1L),0x3BL,0x3BL,(-1L),0x3BL,0x3BL,(-1L),0x3BL},{0xF4L,0x48L,0xF4L,0x96L,6L,0x96L,0xF4L,0x48L,0xF4L},{0x3BL,(-1L),0x3BL,0x3BL,(-1L),0x3BL,0x3BL,(-1L),0x3BL}};
    volatile int32_t l_167[7][2][6] = {{{(-5L),0L,0L,0xCDD564CCL,0xFA5ED00FL,0xCDD564CCL},{0x83EC63F9L,0L,0x83EC63F9L,7L,1L,0L}},{{0xBF98E9D9L,6L,0x83EC63F9L,0xBF98E9D9L,0L,0xCDD564CCL},{0xCDD564CCL,2L,0L,0xBF98E9D9L,1L,7L}},{{0xBF98E9D9L,1L,7L,7L,1L,0xBF98E9D9L},{0x83EC63F9L,2L,(-5L),0xCDD564CCL,0L,0xBF98E9D9L}},{{(-5L),6L,7L,0L,(-5L),1L},{0xBD3F7DA1L,0L,0x193F4887L,1L,0xBF98E9D9L,1L}},{{2L,0L,2L,1L,(-5L),0x193F4887L},{0x2AC20AD1L,0xCDD564CCL,2L,0x2AC20AD1L,0L,1L}},{{1L,0x83EC63F9L,0x193F4887L,0x2AC20AD1L,7L,1L},{0x2AC20AD1L,7L,1L,1L,7L,0x2AC20AD1L}},{{2L,0x83EC63F9L,0xBD3F7DA1L,1L,0L,0x2AC20AD1L},{0xBD3F7DA1L,0xCDD564CCL,1L,0x193F4887L,(-5L),1L}}};
    int32_t l_189[8][8][4] = {{{0x5185A720L,0x7174AD0AL,0L,0x09820496L},{(-6L),0xFBDDCB5EL,0xFBDDCB5EL,(-6L)},{1L,1L,5L,0x39E8B652L},{(-1L),(-10L),0L,0x9C788934L},{(-4L),0x8FC1CA03L,0L,0x9C788934L},{0x6A3FBE80L,(-10L),0x18CD6108L,0x39E8B652L},{0L,1L,0xEB59E71AL,(-6L)},{0x5F9BD9F5L,0xFBDDCB5EL,4L,0x09820496L}},{{0L,0x7174AD0AL,(-4L),0xD3B7CBDBL},{4L,0xF0DDE49BL,0x36159998L,0x42D7DE4DL},{0L,0x09820496L,0L,1L},{7L,(-1L),0x42D7DE4DL,9L},{0x90200DE2L,0L,0xD061763CL,0L},{0L,0x468687B3L,1L,0x68F9EE32L},{0x7DF49458L,0L,7L,2L},{0x51E7AA7DL,0x90200DE2L,0L,0x7DF49458L}},{{0x213AF986L,(-4L),0x5F9BD9F5L,6L},{0x7174AD0AL,0x18CD6108L,0L,(-5L)},{(-10L),(-6L),9L,0L},{0x1D303672L,(-3L),0L,0L},{0xA0E25620L,0x82345026L,0x4148523EL,1L},{2L,(-5L),0L,0x468687B3L},{0xD3B7CBDBL,0L,0xD3B7CBDBL,0x9AFE7670L},{(-1L),0x36159998L,(-5L),0x9DF94D2BL}},{{0x09820496L,0L,0x90200DE2L,0x36159998L},{5L,0x39E8B652L,0x90200DE2L,0x1D303672L},{0x09820496L,0x45DB1E34L,(-5L),1L},{(-1L),0x68F9EE32L,0xD3B7CBDBL,0x33A9D292L},{0xD3B7CBDBL,0x33A9D292L,0L,0L},{2L,0xD3B7CBDBL,0x4148523EL,0x098F6E79L},{0xA0E25620L,4L,0L,0x54A65339L},{0x1D303672L,7L,9L,0x213AF986L}},{{(-10L),1L,0L,0x80609C47L},{0x7174AD0AL,0L,0x5F9BD9F5L,0L},{0x213AF986L,(-1L),0L,1L},{0x51E7AA7DL,0xEB59E71AL,7L,0x6A3FBE80L},{0x7DF49458L,0xD061763CL,1L,(-10L)},{0x18CD6108L,0x8FC1CA03L,(-8L),0L},{0xD061763CL,0L,0xD3B7CBDBL,4L},{(-1L),0L,0x9DF94D2BL,0x36159998L}},{{(-10L),1L,(-8L),(-8L)},{1L,0x68F9EE32L,2L,0xFBDDCB5EL},{7L,0xF074F619L,0L,0L},{0L,0L,0x90200DE2L,9L},{0x42D7DE4DL,0L,0xD5100AA5L,(-1L)},{0x098F6E79L,0L,0x213AF986L,0xD5100AA5L},{2L,0L,0L,(-1L)},{0L,0L,0x09820496L,9L}},{{0L,0L,0L,0L},{0x6A3FBE80L,0xF074F619L,1L,0xFBDDCB5EL},{0x45DB1E34L,0x68F9EE32L,6L,(-8L)},{1L,1L,1L,0x36159998L},{0x82345026L,0L,1L,4L},{0x54A65339L,0L,0x098F6E79L,0L},{0x09820496L,0x8FC1CA03L,0L,(-10L)},{4L,(-8L),0L,0x098F6E79L}},{{0x7DF49458L,0x90200DE2L,0x9C788934L,0x68F9EE32L},{0L,0xA0E25620L,7L,0x42D7DE4DL},{5L,(-10L),0x1D303672L,0x5185A720L},{(-8L),0x5F9BD9F5L,0L,0xF074F619L},{7L,(-1L),0L,0x51E7AA7DL},{0xD5100AA5L,0L,1L,0x8FC1CA03L},{1L,0x9AFE7670L,0xF074F619L,0x213AF986L},{0x4148523EL,0L,0x7174AD0AL,0L}}};
    int64_t l_194 = 1L;
    int i, j, k;
    l_166[2][6] ^= func_32((p_31 , p_31), g_2, l_36);
    if ((((p_31 <= g_12[2]) != g_12[8]) , p_31))
    { /* block id: 109 */
        uint16_t l_170 = 65533UL;
        int32_t l_179 = 0x2ED0F463L;
        int32_t l_180 = 0xF2F34FABL;
        if (g_8[0][4][6])
        { /* block id: 110 */
            int32_t l_168 = 0xB358CFB8L;
            int32_t l_169 = 4L;
lbl_173:
            l_167[5][0][4] = g_158;
            --l_170;
            if (l_36)
                goto lbl_173;
        }
        else
        { /* block id: 114 */
            int32_t l_178[4] = {0x20809C30L,0x20809C30L,0x20809C30L,0x20809C30L};
            uint64_t l_181 = 0x6ED2C106F47B0E09LL;
            int i;
            l_179 &= ((safe_mod_func_int16_t_s_s((((safe_rshift_func_int8_t_s_u(l_178[3], 6)) != l_178[0]) , g_65), 8UL)) | 0x9638L);
            --l_181;
            ++g_184;
        }
        l_167[5][0][4] ^= 1L;
    }
    else
    { /* block id: 120 */
        l_189[4][7][0] &= (((safe_mul_func_uint16_t_u_u(l_166[0][2], 0xBAB9L)) & g_5) | l_36);
    }
    l_194 = (((((safe_add_func_int32_t_s_s((safe_add_func_uint32_t_u_u(((g_8[1][3][2] , l_189[4][7][0]) < l_167[5][0][4]), 0xEA0349FBL)), g_184)) , 0x73L) >= l_189[4][7][0]) , p_31) & g_184);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_6 g_12 g_7 g_65 g_2 g_5 g_158
 * writes: g_8 g_12 g_65 g_6 g_7 g_158
 */
static int32_t  func_32(uint64_t  p_33, int32_t  p_34, int32_t  p_35)
{ /* block id: 30 */
    uint8_t l_44[2][8] = {{0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L},{0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L,0x49L}};
    uint32_t l_51 = 4294967289UL;
    int32_t l_131[10][9] = {{0xCDA5772CL,(-1L),0x29A3F835L,0xFAE57973L,(-1L),(-1L),0xFAE57973L,0x29A3F835L,(-1L)},{(-9L),0xC9214CF6L,0L,5L,0x4E6814E7L,(-1L),0L,(-1L),0xCDA5772CL},{0L,0xFAE57973L,0xC9214CF6L,0xC8CA251FL,0x29A3F835L,(-1L),0x29A3F835L,0xC8CA251FL,0xC9214CF6L},{0xC9214CF6L,0xC9214CF6L,9L,0xCDA5772CL,0xF39239E7L,6L,0x29A3F835L,(-1L),(-9L)},{5L,(-1L),2L,0L,(-9L),0L,0L,(-9L),0L},{9L,6L,9L,(-1L),(-1L),(-1L),0xFAE57973L,(-9L),0xF39239E7L},{6L,2L,0xC9214CF6L,0xF39239E7L,0xFAE57973L,(-1L),0L,(-1L),(-1L)},{9L,0xC9214CF6L,0xC9214CF6L,9L,0xCDA5772CL,0xF39239E7L,6L,0x29A3F835L,(-1L)},{0x29A3F835L,(-9L),5L,0xC9214CF6L,1L,2L,0xFAE57973L,0xFAE57973L,2L},{0xCDA5772CL,0L,9L,0L,0xCDA5772CL,0x29A3F835L,(-9L),5L,0xC9214CF6L}};
    int8_t l_135[9] = {7L,7L,7L,7L,7L,7L,7L,7L,7L};
    uint32_t l_137 = 0UL;
    int i, j;
    g_8[0][4][6] = (safe_sub_func_int16_t_s_s((~(((safe_sub_func_int32_t_s_s((safe_add_func_uint8_t_u_u(((((((l_44[1][1] ^ p_35) & l_44[1][1]) & g_8[0][5][6]) < (-2L)) & g_6) | 0x5D0BC5DE30EA3BBELL), g_12[1])), l_44[0][7])) , 2UL) | g_8[0][4][6])), p_33));
    if (func_45(l_44[0][3], g_7, l_44[0][0], l_44[1][1], l_51))
    { /* block id: 86 */
        int16_t l_129 = 0xCCD6L;
        int32_t l_130 = 0x869B1D06L;
        int32_t l_132 = (-1L);
        int32_t l_133 = 0x87F110A1L;
        int32_t l_134[1];
        int32_t l_136[5][1] = {{0x268D07ABL},{0x36CF2371L},{0x268D07ABL},{0x36CF2371L},{0x268D07ABL}};
        uint32_t l_155[5];
        int i, j;
        for (i = 0; i < 1; i++)
            l_134[i] = 0x19FD917EL;
        for (i = 0; i < 5; i++)
            l_155[i] = 0x4458DFD4L;
        l_130 ^= (((safe_sub_func_int8_t_s_s((safe_unary_minus_func_int64_t_s((safe_rshift_func_uint8_t_u_u((((safe_rshift_func_int16_t_s_s(p_33, l_129)) , g_5) && p_33), p_33)))), g_12[7])) > 2L) & l_129);
        ++l_137;
        for (l_132 = 0; (l_132 == 11); l_132 = safe_add_func_uint16_t_u_u(l_132, 3))
        { /* block id: 91 */
            int32_t l_142 = (-1L);
            int32_t l_143 = 7L;
            int32_t l_144 = (-8L);
            int32_t l_145 = 0x4F96F3BDL;
            int32_t l_146 = 1L;
            int32_t l_147 = 0xFA0D3B92L;
            int32_t l_148 = 0x0C7566D7L;
            int32_t l_149 = (-8L);
            int32_t l_150 = 6L;
            int32_t l_151 = 0x81183D2FL;
            int32_t l_152 = 1L;
            int32_t l_153[5][7] = {{0x01747DCEL,(-1L),0x5B8FE26FL,1L,(-1L),0xBF85D4ADL,(-6L)},{0x01747DCEL,0xD6E2808CL,(-10L),0x5B8FE26FL,(-10L),0xD6E2808CL,0x01747DCEL},{(-6L),0xBF85D4ADL,(-1L),1L,0x5B8FE26FL,(-1L),0x01747DCEL},{0x5B8FE26FL,0x01747DCEL,(-1L),(-1L),0x01747DCEL,0x5B8FE26FL,(-6L)},{0xD6E2808CL,(-1L),(-1L),(-6L),0x0A817FA5L,0x5B8FE26FL,0x5B8FE26FL}};
            int32_t l_154 = 0xF174FA8EL;
            int i, j;
            l_155[0]--;
            if (l_155[0])
                continue;
            g_7 &= 0xA54E84F8L;
            if (g_6)
                continue;
        }
    }
    else
    { /* block id: 97 */
        int16_t l_165 = 0x908BL;
        for (p_34 = 1; (p_34 <= 8); p_34 += 1)
        { /* block id: 100 */
            int i;
            g_158--;
            g_12[p_34] = (safe_rshift_func_uint8_t_u_u(g_12[p_34], 7));
            l_165 ^= ((((safe_add_func_uint64_t_u_u(g_158, g_8[0][4][6])) == g_8[0][4][6]) >= p_35) || 4294967287UL);
            return g_12[p_34];
        }
    }
    return g_158;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_7 g_65 g_2 g_8 g_5 g_6
 * writes: g_12 g_65 g_8 g_6
 */
static int32_t  func_45(int32_t  p_46, int32_t  p_47, uint32_t  p_48, uint8_t  p_49, uint64_t  p_50)
{ /* block id: 32 */
    int64_t l_56 = (-9L);
    int32_t l_79 = 7L;
    uint16_t l_80 = 0UL;
    uint64_t l_81 = 0x1A03DC57991EE505LL;
lbl_107:
    for (p_48 = 0; (p_48 <= 8); p_48 += 1)
    { /* block id: 35 */
        int i;
        g_12[p_48] = ((((((safe_div_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s(0x11L, g_12[p_48])), p_46)) , l_56) || g_12[p_48]) , 0xD46FEDEAL) && p_48) | g_12[p_48]);
        if (func_57(g_7))
        { /* block id: 42 */
            uint8_t l_70 = 0x9BL;
            int i;
            g_12[p_48] = (safe_mod_func_int64_t_s_s(l_56, l_70));
            g_8[0][4][6] = (safe_lshift_func_int8_t_s_u((-3L), 1));
            g_12[p_48] = (safe_lshift_func_int8_t_s_s((((safe_lshift_func_int16_t_s_s((l_56 > p_49), g_8[1][3][3])) != 0x4946A2B7F3A40B10LL) ^ p_46), p_47));
            p_47 = 0x685F0820L;
        }
        else
        { /* block id: 47 */
            g_8[0][1][0] &= (safe_sub_func_uint32_t_u_u(((0UL || g_12[p_48]) < p_46), l_56));
        }
        for (p_46 = 1; (p_46 >= 0); p_46 -= 1)
        { /* block id: 52 */
            if (p_48)
                break;
            l_79 = l_56;
            return p_48;
        }
    }
    l_81 = (((p_47 <= l_80) <= p_46) , g_12[3]);
    g_12[2] = p_50;
    if ((((safe_sub_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s(p_50, 0x4B92745916079B8BLL)), 3)), l_56)) > g_5) < l_56))
    { /* block id: 60 */
        int64_t l_94[6];
        int i;
        for (i = 0; i < 6; i++)
            l_94[i] = 1L;
        if ((safe_lshift_func_int16_t_s_s((safe_mod_func_int64_t_s_s(((l_56 ^ g_12[2]) && 1UL), l_56)), g_8[1][2][1])))
        { /* block id: 61 */
            g_8[0][4][3] &= (safe_sub_func_int16_t_s_s(((g_12[8] & 1L) >= l_56), l_94[4]));
            g_12[2] = (g_8[0][4][6] ^ 0x5DL);
        }
        else
        { /* block id: 64 */
            g_12[2] |= (safe_mod_func_uint32_t_u_u(1UL, l_94[4]));
        }
    }
    else
    { /* block id: 67 */
        const int8_t l_105 = 0x15L;
        int32_t l_121 = 0x19E1A970L;
        if (((l_56 && p_50) , 0xC3BF42E1L))
        { /* block id: 68 */
            int16_t l_106 = 8L;
            l_79 = ((((!((safe_mul_func_int16_t_s_s(g_6, p_46)) || (-1L))) < p_48) < g_8[1][3][6]) , p_47);
            l_106 &= (safe_mod_func_int32_t_s_s(((!(safe_div_func_int16_t_s_s((0x25DA6338L < p_49), l_105))) , 0L), l_105));
            g_8[1][1][2] = 5L;
            if (p_46)
                goto lbl_107;
        }
        else
        { /* block id: 73 */
            g_12[6] = g_65;
            return g_65;
        }
        if (((safe_sub_func_int8_t_s_s((0xAC9CL >= g_5), g_12[2])) , l_105))
        { /* block id: 77 */
            uint32_t l_110 = 0xDC8FC35AL;
            g_6 = (l_105 | p_50);
            l_110 = (p_47 >= g_5);
            p_47 |= (safe_div_func_int64_t_s_s((0x401F3C7BL == l_110), 0x1F96505D7E5B14ABLL));
        }
        else
        { /* block id: 81 */
            l_121 = (((safe_add_func_uint64_t_u_u((((((!((safe_mod_func_uint16_t_u_u(((safe_div_func_uint8_t_u_u((+(1L == g_8[0][2][0])), l_105)) , l_105), g_8[1][3][1])) || p_46)) , p_48) >= 4294967294UL) , 0xD410C6DFL) < g_2), 0xEBA52E2A0AD3F44FLL)) || p_46) <= 0x6A7E7D71L);
        }
    }
    return l_80;
}


/* ------------------------------------------ */
/* 
 * reads : g_65 g_2
 * writes: g_65
 */
static int32_t  func_57(uint8_t  p_58)
{ /* block id: 37 */
    uint16_t l_59[5] = {1UL,1UL,1UL,1UL,1UL};
    int32_t l_64 = 0x2F50FADEL;
    int i;
    l_59[4] = 0L;
    l_64 = ((safe_add_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_u(p_58, p_58)) , p_58), p_58)) > 4294967295UL);
    g_65++;
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_8[i][j][k], "g_8[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    transparent_crc(g_184, "g_184", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_197[i], "g_197[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_198, "g_198", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 72
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 91
   depth: 2, occurrence: 20
   depth: 3, occurrence: 3
   depth: 4, occurrence: 7
   depth: 5, occurrence: 8
   depth: 6, occurrence: 5
   depth: 8, occurrence: 3
   depth: 9, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 139
XXX times a non-volatile is write: 55
XXX times a volatile is read: 27
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 160
XXX percentage of non-volatile access: 85.1

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 87
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 20
   depth: 2, occurrence: 46

XXX percentage a fresh-made variable is used: 19.7
XXX percentage an existing variable is used: 80.3
********************* end of statistics **********************/

