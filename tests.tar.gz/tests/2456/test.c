/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2590565218878288779
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_10 = 0xE81A7ECCL;
static int16_t g_21 = 0x370CL;
static volatile int16_t g_30 = 0x2A41L;/* VOLATILE GLOBAL g_30 */
static volatile uint32_t g_31 = 0x07A051AAL;/* VOLATILE GLOBAL g_31 */
static int32_t g_42 = 0x95830AF3L;
static int64_t g_44 = 0x78833E6FCB758C9ELL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_6(int32_t  p_7, uint16_t  p_8);
static uint16_t  func_12(uint8_t  p_13, const uint32_t  p_14, int64_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_31 g_30 g_44
 * writes: g_21 g_30 g_31 g_42 g_44
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_9 = 0xBC5021C3L;
    uint16_t l_43 = 1UL;
    g_44 |= (((safe_mul_func_int8_t_s_s(((((((safe_lshift_func_uint16_t_u_u(func_6(l_9, g_10), g_10)) ^ l_9) >= g_10) , g_10) != g_10) | l_9), g_10)) & (-6L)) | l_43);
    return g_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_31 g_30
 * writes: g_21 g_30 g_31 g_42
 */
static uint16_t  func_6(int32_t  p_7, uint16_t  p_8)
{ /* block id: 1 */
    int32_t l_11 = 0xD16652D0L;
    int32_t l_39 = (-9L);
    p_7 |= l_11;
    if ((func_12((!(((p_8 & g_10) < l_11) & 0x84L)), l_11, p_8) && g_10))
    { /* block id: 8 */
        const int16_t l_29 = 0L;
        p_7 = (-10L);
        p_7 = ((safe_div_func_uint16_t_u_u((safe_add_func_int16_t_s_s(((~(safe_lshift_func_int16_t_s_s((p_8 > l_11), 15))) | l_29), 1L)), 0xC870L)) != g_21);
        g_30 = 0x524BE18AL;
        g_31--;
    }
    else
    { /* block id: 13 */
        uint16_t l_38 = 65531UL;
        l_39 ^= (((((((safe_mod_func_int32_t_s_s((safe_lshift_func_int8_t_s_s((g_21 != 0xC3387DD7L), 5)), l_38)) != p_8) && g_30) | 0xACD6BCE8L) , p_7) && 2L) , 9L);
        g_42 = ((safe_mod_func_int64_t_s_s((p_7 && g_31), p_7)) && (-1L));
    }
    return l_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_21
 * writes: g_21
 */
static uint16_t  func_12(uint8_t  p_13, const uint32_t  p_14, int64_t  p_15)
{ /* block id: 3 */
    int16_t l_19 = 0xA0CDL;
    int32_t l_20 = 5L;
    l_20 = (((((((((safe_sub_func_int8_t_s_s((-9L), 1UL)) ^ l_19) & g_10) || l_19) < g_10) >= (-6L)) & l_19) < 65529UL) ^ p_15);
    l_20 = l_19;
    g_21 |= (-9L);
    return p_14;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 20
   depth: 4, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 37
XXX times a non-volatile is write: 9
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 92

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 6

XXX percentage a fresh-made variable is used: 28
XXX percentage an existing variable is used: 72
********************* end of statistics **********************/

