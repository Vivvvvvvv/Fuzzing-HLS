/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5695094794432399973
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = (-3L);
static uint32_t g_3[9] = {0x6DA5043CL,0x6DA5043CL,0x6DA5043CL,0x6DA5043CL,0x6DA5043CL,0x6DA5043CL,0x6DA5043CL,0x6DA5043CL,0x6DA5043CL};
static int32_t g_18 = 0L;
static uint32_t g_20 = 0xD9935FF5L;
static uint8_t g_28 = 255UL;
static int8_t g_31 = 0x0FL;
static volatile int32_t g_32 = 0x8F3B1AD3L;/* VOLATILE GLOBAL g_32 */
static volatile uint32_t g_33 = 18446744073709551615UL;/* VOLATILE GLOBAL g_33 */
static int8_t g_51 = 0x07L;
static int8_t g_52[10] = {0x9FL,0x4AL,0x9FL,0x9FL,0x4AL,0x9FL,0x9FL,0x4AL,0x9FL,0x9FL};
static int8_t g_55 = 0L;
static int64_t g_67 = 0xFEAA3CE9D1BBA4BALL;
static volatile int64_t g_68 = 1L;/* VOLATILE GLOBAL g_68 */
static int32_t g_69 = 0xF089E30CL;
static int8_t g_70 = (-1L);
static int8_t g_71 = 0x0BL;
static uint32_t g_72 = 0x01D2D5FAL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int8_t  func_9(uint32_t  p_10, int8_t  p_11, uint16_t  p_12);
static int16_t  func_40(uint64_t  p_41, uint32_t  p_42, int16_t  p_43, uint32_t  p_44);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_18 g_20 g_28 g_31 g_33 g_32 g_51 g_72 g_70 g_55
 * writes: g_3 g_18 g_20 g_28 g_31 g_33 g_51 g_52 g_55 g_67 g_72
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_6 = (-6L);
    g_3[7] = ((((g_2 , g_2) , g_2) , 249UL) , g_2);
    if (((safe_sub_func_int16_t_s_s((((0x52A26F3FL & l_6) && g_3[6]) && 0xB3BFA32AL), l_6)) >= 0x13B2L))
    { /* block id: 2 */
        g_52[7] = (safe_div_func_int16_t_s_s((func_9((l_6 && 1L), g_3[6], g_2) < l_6), 65531UL));
    }
    else
    { /* block id: 27 */
        int16_t l_64 = 0x248FL;
        int32_t l_66[10] = {0xEDA29731L,0xEDA29731L,(-10L),0xEDA29731L,0xEDA29731L,(-10L),0xEDA29731L,0xEDA29731L,(-10L),0xEDA29731L};
        int i;
        if ((safe_rshift_func_int16_t_s_u((g_2 , g_18), 3)))
        { /* block id: 28 */
            g_55 = 1L;
        }
        else
        { /* block id: 30 */
            const uint64_t l_65 = 1UL;
            l_66[6] &= (safe_rshift_func_int16_t_s_u((safe_mul_func_int16_t_s_s((((safe_div_func_uint16_t_u_u(((((safe_lshift_func_int16_t_s_s(((((g_20 > 0x811E3584L) & l_6) | g_3[7]) > g_51), l_6)) , l_64) & l_65) , 1UL), l_65)) , g_3[7]) < l_65), l_64)), 12));
            g_67 = 1L;
        }
        g_72--;
        l_66[6] |= (g_70 <= 0xA6L);
    }
    return g_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_18 g_20 g_28 g_31 g_33 g_32
 * writes: g_18 g_20 g_28 g_31 g_33 g_51
 */
static int8_t  func_9(uint32_t  p_10, int8_t  p_11, uint16_t  p_12)
{ /* block id: 3 */
    uint32_t l_19[2];
    int32_t l_37[5] = {1L,1L,1L,1L,1L};
    int32_t l_46 = (-1L);
    int i;
    for (i = 0; i < 2; i++)
        l_19[i] = 0x91D0B6BDL;
lbl_36:
    for (p_11 = 7; (p_11 >= 3); p_11 -= 1)
    { /* block id: 6 */
        uint64_t l_17 = 1UL;
        int32_t l_27 = (-1L);
        int i;
        g_18 = (safe_mul_func_int16_t_s_s((safe_add_func_int32_t_s_s(g_3[(p_11 + 1)], g_2)), l_17));
        g_20 = (l_19[0] || g_2);
        if (p_11)
            goto lbl_36;
        l_27 = (((safe_mod_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((g_18 == l_19[0]), g_20)), l_19[0])) , 0x7EL), 0xC1L)) || 0L) , g_3[(p_11 + 1)]);
        for (g_18 = 1; (g_18 <= 8); g_18 += 1)
        { /* block id: 12 */
            --g_28;
            g_31 ^= p_12;
            if (p_11)
                goto lbl_36;
            g_33++;
        }
    }
    l_37[3] = g_3[3];
    l_46 |= (safe_mod_func_int16_t_s_s(func_40(((+l_37[1]) , g_32), l_37[1], p_12, l_19[0]), l_37[2]));
    g_51 = (safe_add_func_uint8_t_u_u((((((safe_mul_func_int16_t_s_s(l_19[1], 1L)) <= p_11) , p_10) , (-1L)) ^ g_3[7]), 0x6FL));
    return g_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_33
 * writes:
 */
static int16_t  func_40(uint64_t  p_41, uint32_t  p_42, int16_t  p_43, uint32_t  p_44)
{ /* block id: 21 */
    return g_33;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_52[i], "g_52[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 26
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 49
XXX times a non-volatile is write: 17
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 23
XXX percentage of non-volatile access: 94.3

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 25
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 9
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 36.6
XXX percentage an existing variable is used: 63.4
********************* end of statistics **********************/

