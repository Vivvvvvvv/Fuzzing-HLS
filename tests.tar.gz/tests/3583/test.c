/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6132241962725582634
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_8[4] = {0UL,0UL,0UL,0UL};
static uint32_t g_9 = 0x87A7525DL;
static volatile uint32_t g_10 = 4294967288UL;/* VOLATILE GLOBAL g_10 */
static uint32_t g_14 = 0x64F6CBCBL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_4(uint64_t  p_5);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_9 g_14
 * writes: g_9 g_10 g_14
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_6 = 0xF98AL;
    int32_t l_11[6];
    int i;
    for (i = 0; i < 6; i++)
        l_11[i] = 0x92758E92L;
    l_11[0] ^= (safe_mul_func_int8_t_s_s(func_4(l_6), 0xB0L));
    g_14 ^= (safe_mod_func_uint16_t_u_u(g_8[2], 0xCEFDL));
    return g_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_9
 * writes: g_9 g_10
 */
static int8_t  func_4(uint64_t  p_5)
{ /* block id: 1 */
    int8_t l_7 = 0x22L;
    g_9 |= (((((l_7 || 4L) >= l_7) < p_5) > g_8[2]) == l_7);
    g_10 = (-1L);
    return l_7;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 7
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 3
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 92.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 6
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 6

XXX percentage a fresh-made variable is used: 53.8
XXX percentage an existing variable is used: 46.2
********************* end of statistics **********************/

