/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1802434162176325485
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_3 = 0x836B16B471DFD947LL;/* VOLATILE GLOBAL g_3 */
static int8_t g_17 = 1L;
static uint64_t g_18[4] = {0xEF23E469209A488DLL,0xEF23E469209A488DLL,0xEF23E469209A488DLL,0xEF23E469209A488DLL};
static volatile uint8_t g_19 = 0UL;/* VOLATILE GLOBAL g_19 */
static int64_t g_25 = 8L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_8(int64_t  p_9, int32_t  p_10);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_17 g_19
 * writes: g_18 g_19 g_17 g_25
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    const uint32_t l_2[9] = {0x8EF6B8F3L,0x8EF6B8F3L,0x0E164CAFL,0x8EF6B8F3L,0x8EF6B8F3L,0x0E164CAFL,0x8EF6B8F3L,0x8EF6B8F3L,0x0E164CAFL};
    uint32_t l_4 = 0x3D188047L;
    int i;
lbl_7:
    l_4 = (((((((2L ^ 18446744073709551615UL) != l_2[0]) & g_3) && 8UL) , 1UL) , 0xE864L) , l_2[2]);
    for (l_4 = 17; (l_4 == 5); l_4 = safe_sub_func_int32_t_s_s(l_4, 9))
    { /* block id: 4 */
        const int16_t l_11 = 0x5561L;
        const int16_t l_16 = 1L;
        if (l_4)
            goto lbl_7;
        g_18[3] = ((func_8((((255UL < l_11) , l_11) == l_11), g_3) > l_16) != g_17);
        g_19 ^= ((3L == l_16) , 1L);
        for (g_17 = 0; (g_17 < 21); ++g_17)
        { /* block id: 13 */
            g_25 = ((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_int8_t_s(g_3)), 1UL)) < 7UL);
        }
    }
    return l_2[8];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint16_t  func_8(int64_t  p_9, int32_t  p_10)
{ /* block id: 6 */
    int32_t l_14[9] = {0x196E6C8CL,0x196E6C8CL,0x196E6C8CL,0x196E6C8CL,0x196E6C8CL,0x196E6C8CL,0x196E6C8CL,0x196E6C8CL,0x196E6C8CL};
    int32_t l_15 = 0x3CA4D9A5L;
    int i;
    l_15 ^= (safe_div_func_uint64_t_u_u(g_3, l_14[4]));
    return p_9;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 8, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 6
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 79.2

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 10
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 4
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 55
XXX percentage an existing variable is used: 45
********************* end of statistics **********************/

