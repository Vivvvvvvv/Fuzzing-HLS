/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8682960632341712734
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-3L);/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = (-1L);
static int32_t g_18 = 0x2A4B15D3L;
static volatile int64_t g_19 = 0x63D62A04F77722ABLL;/* VOLATILE GLOBAL g_19 */
static volatile int16_t g_20 = 0xC7BAL;/* VOLATILE GLOBAL g_20 */
static uint64_t g_21 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static const int8_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_21 g_19
 * writes: g_3 g_2 g_21
 */
static const int8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_10 = 0L;
    volatile int32_t l_13[1];
    int32_t l_24[3][9] = {{1L,0xACDD711AL,0xACDD711AL,1L,0L,(-2L),0L,1L,0xACDD711AL},{0L,0L,1L,(-2L),0xE7504ED0L,(-2L),1L,0L,0L},{0xACDD711AL,1L,0L,(-2L),0L,1L,0xACDD711AL,0xACDD711AL,1L}};
    int i, j;
    for (i = 0; i < 1; i++)
        l_13[i] = 0L;
    for (g_3 = 0; (g_3 != 6); g_3++)
    { /* block id: 3 */
        int8_t l_6 = (-8L);
        uint32_t l_7[1][6] = {{1UL,1UL,1UL,1UL,1UL,1UL}};
        int i, j;
        l_7[0][1] ^= (((0x38ABL || l_6) != 6L) > g_2);
        g_2 = ((safe_div_func_uint64_t_u_u((l_10 && l_10), 0xC17C7747BB7AB61BLL)) & l_6);
        if (g_2)
            break;
    }
    for (l_10 = 0; (l_10 >= 3); ++l_10)
    { /* block id: 10 */
        return g_3;
    }
    l_13[0] = g_2;
    for (l_10 = 0; (l_10 > 5); l_10++)
    { /* block id: 16 */
        int32_t l_16[4] = {(-1L),(-1L),(-1L),(-1L)};
        int32_t l_17 = 0xE8B01213L;
        int i;
        ++g_21;
        if (l_24[0][2])
            continue;
        l_13[0] = (safe_add_func_int64_t_s_s((-1L), 0x0A2E71CC545E2138LL));
    }
    return g_19;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 4
   depth: 4, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 5
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 66.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 7

XXX percentage a fresh-made variable is used: 42.3
XXX percentage an existing variable is used: 57.7
********************* end of statistics **********************/

