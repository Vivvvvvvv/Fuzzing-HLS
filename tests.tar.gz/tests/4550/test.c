/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2226815679683392267
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   int32_t  f1;
   int16_t  f2;
   int32_t  f3;
   volatile int64_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 1L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0x351F2000L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4[4] = {(-6L),(-6L),(-6L),(-6L)};
static volatile int32_t g_5 = 1L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = (-7L);/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7 = 0x358BD4DFL;/* VOLATILE GLOBAL g_7 */
static int32_t g_8 = 0xC3F0BC50L;
static volatile struct S0 g_25[6] = {{0x764CE34AL,0xFBEBF0A0L,0xD95FL,-1L,0xACD4A7974498B94BLL},{0x764CE34AL,0xFBEBF0A0L,0xD95FL,-1L,0xACD4A7974498B94BLL},{0x764CE34AL,0xFBEBF0A0L,0xD95FL,-1L,0xACD4A7974498B94BLL},{0x764CE34AL,0xFBEBF0A0L,0xD95FL,-1L,0xACD4A7974498B94BLL},{0x764CE34AL,0xFBEBF0A0L,0xD95FL,-1L,0xACD4A7974498B94BLL},{0x764CE34AL,0xFBEBF0A0L,0xD95FL,-1L,0xACD4A7974498B94BLL}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_16(uint32_t  p_17, int16_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_6 g_2 g_25 g_4
 * writes: g_8 g_6 g_4 g_7
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_11 = 1UL;
    int32_t l_27 = (-2L);
    int32_t l_28 = (-1L);
    int32_t l_29[1];
    uint64_t l_30 = 4UL;
    int i;
    for (i = 0; i < 1; i++)
        l_29[i] = 0x492A4153L;
lbl_38:
    for (g_8 = 27; (g_8 >= 6); --g_8)
    { /* block id: 3 */
        uint32_t l_26 = 0xABFD090DL;
        if (l_11)
            break;
        g_6 = (g_6 , 0xDF7CD95DL);
        for (l_11 = 0; (l_11 != 56); l_11++)
        { /* block id: 8 */
            int16_t l_19 = (-10L);
            int32_t l_20 = 0L;
            l_20 = ((safe_mod_func_uint32_t_u_u((func_16(g_6, g_8) , l_19), g_8)) || 0x1AE9L);
            g_4[3] = (safe_add_func_int8_t_s_s((((safe_div_func_uint32_t_u_u(((g_25[4] , g_25[4].f3) , l_19), l_26)) >= 0x8FL) , g_4[3]), l_11));
            if (l_11)
                goto lbl_33;
            return l_11;
        }
    }
lbl_33:
    --l_30;
    for (l_28 = 7; (l_28 >= (-10)); l_28--)
    { /* block id: 20 */
        uint64_t l_36 = 0x83BE7680DD333F0DLL;
        l_29[0] = (g_25[4].f4 != 0x6DBD8D46L);
        l_36 &= ((((func_16(g_4[0], l_29[0]) < g_8) > 9UL) >= g_8) , 0xC518F82EL);
        g_7 = (safe_unary_minus_func_uint32_t_u(l_36));
        if (l_30)
            goto lbl_38;
    }
    return l_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int32_t  func_16(uint32_t  p_17, int16_t  p_18)
{ /* block id: 9 */
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_25[i].f0, "g_25[i].f0", print_hash_value);
        transparent_crc(g_25[i].f1, "g_25[i].f1", print_hash_value);
        transparent_crc(g_25[i].f2, "g_25[i].f2", print_hash_value);
        transparent_crc(g_25[i].f3, "g_25[i].f3", print_hash_value);
        transparent_crc(g_25[i].f4, "g_25[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 5
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 16
XXX times a non-volatile is write: 7
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 67.6

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 7
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 29.4
XXX percentage an existing variable is used: 70.6
********************* end of statistics **********************/

