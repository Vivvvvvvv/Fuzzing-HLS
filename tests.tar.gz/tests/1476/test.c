/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6153796787505845185
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_2[10] = {0xD06CL,0xD06CL,0xD06CL,0xD06CL,0xD06CL,0xD06CL,0xD06CL,0xD06CL,0xD06CL,0xD06CL};
static uint8_t g_3[4] = {0x25L,0x25L,0x25L,0x25L};
static uint8_t g_21 = 249UL;
static uint32_t g_27 = 0x437F1BD5L;
static uint32_t g_34 = 18446744073709551615UL;
static uint16_t g_52 = 0xF493L;
static int64_t g_60 = 2L;
static uint64_t g_70 = 18446744073709551607UL;
static uint16_t g_85[4] = {1UL,1UL,1UL,1UL};
static uint32_t g_94 = 0x0066BE38L;
static volatile int16_t g_100 = 0xB1B7L;/* VOLATILE GLOBAL g_100 */
static int32_t g_106 = (-1L);


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static uint16_t  func_6(int32_t  p_7, uint16_t  p_8);
static int64_t  func_37(uint32_t  p_38, const int64_t  p_39, uint32_t  p_40, int16_t  p_41);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_21 g_27 g_34 g_52 g_60 g_85 g_106
 * writes: g_3 g_21 g_27 g_34 g_52 g_60 g_70 g_85 g_94 g_100 g_106
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_9[8];
    int8_t l_72[5];
    int32_t l_73 = 0L;
    int16_t l_105 = 0xA7D1L;
    const int8_t l_107 = 1L;
    int i;
    for (i = 0; i < 8; i++)
        l_9[i] = 0xAAL;
    for (i = 0; i < 5; i++)
        l_72[i] = (-1L);
    g_3[1] = g_2[1];
    if ((safe_rshift_func_uint16_t_u_s(func_6(l_9[5], g_2[3]), l_9[5])))
    { /* block id: 7 */
        uint32_t l_24 = 4294967295UL;
        uint16_t l_29 = 0x6BAEL;
        int8_t l_33 = 0x3BL;
        int32_t l_71 = 0xF56C0C90L;
        if (((safe_div_func_int16_t_s_s((-1L), l_24)) && (-1L)))
        { /* block id: 8 */
            g_27 |= ((safe_sub_func_int16_t_s_s(g_3[1], 1UL)) < (-1L));
        }
        else
        { /* block id: 10 */
            int32_t l_28[3];
            int i;
            for (i = 0; i < 3; i++)
                l_28[i] = 1L;
            l_29 &= l_28[0];
            g_34 = (safe_div_func_uint8_t_u_u(func_6((((!g_3[3]) , 0x592404E5L) < g_2[1]), l_33), g_27));
            l_71 |= (safe_mod_func_int64_t_s_s((func_37((safe_sub_func_uint32_t_u_u((safe_mod_func_int16_t_s_s((((((safe_rshift_func_int16_t_s_s(((l_28[0] || 4294967295UL) , g_3[2]), 3)) , g_2[1]) || (-7L)) == 0L) <= 0x4764FE605A420697LL), g_2[1])), g_34)), l_9[5], l_29, g_27) >= 0x02D5285618A3212ELL), l_28[0]));
            l_28[0] = (l_9[5] >= g_3[1]);
        }
        l_73 ^= l_72[1];
    }
    else
    { /* block id: 27 */
        uint32_t l_83 = 4294967295UL;
        if (((safe_mod_func_int8_t_s_s((safe_div_func_uint32_t_u_u(((((safe_rshift_func_uint8_t_u_u(((~((g_2[1] == 0L) > l_83)) , 255UL), 0)) | 0x652FB00147550418LL) != l_83) < g_2[1]), l_72[3])), 0x0EL)) | l_9[7]))
        { /* block id: 28 */
            int64_t l_84 = 0x720137108D8AE6FBLL;
            --g_85[1];
        }
        else
        { /* block id: 30 */
            uint16_t l_93 = 65526UL;
            g_94 = ((((safe_div_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((safe_unary_minus_func_int16_t_s((0x3287B7884FD301F6LL | g_3[0]))), g_3[2])), l_93)) >= g_52) , 0x4AL) | g_2[4]);
            l_73 = (safe_mul_func_uint8_t_u_u((!((((safe_add_func_uint16_t_u_u((l_93 || l_83), l_93)) , l_93) & 0xEB1B18FD6B89D5A4LL) ^ (-1L))), l_93));
            g_100 = 0xEE7960B9L;
        }
    }
    l_73 |= (safe_mul_func_uint8_t_u_u((safe_mul_func_uint16_t_u_u(((g_27 <= 0x8499L) , 0x0643L), l_105)), g_2[2]));
    g_106 |= (0x81L >= 0x80L);
    return l_107;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_21
 * writes: g_21
 */
static uint16_t  func_6(int32_t  p_7, uint16_t  p_8)
{ /* block id: 2 */
    uint32_t l_14 = 0xC03809D0L;
    int32_t l_18 = 0xAA2D34CAL;
    l_14 = (safe_mod_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(65535UL, g_3[1])), g_3[1]));
    l_18 = (((+((((safe_rshift_func_int8_t_s_u(0x95L, g_2[1])) , p_8) , p_7) != l_14)) != l_14) & p_8);
    g_21 |= (safe_mul_func_uint16_t_u_u(((l_14 | g_2[1]) != g_3[2]), g_3[1]));
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_52 g_2 g_21 g_60 g_3
 * writes: g_34 g_52 g_60 g_70
 */
static int64_t  func_37(uint32_t  p_38, const int64_t  p_39, uint32_t  p_40, int16_t  p_41)
{ /* block id: 13 */
    int8_t l_62 = 0xC6L;
    int32_t l_63 = 8L;
    int32_t l_64[6] = {4L,4L,4L,4L,4L,4L};
    uint64_t l_65 = 0xD7E7D1C2B13F3B72LL;
    int i;
    for (g_34 = 0; (g_34 < 46); g_34 = safe_add_func_uint16_t_u_u(g_34, 6))
    { /* block id: 16 */
        uint64_t l_59 = 18446744073709551609UL;
        int32_t l_61 = 0x6546D79CL;
        g_52 &= (p_39 != 0x5A5481F0L);
        g_60 |= ((safe_rshift_func_int16_t_s_u((((safe_rshift_func_uint8_t_u_s((safe_mod_func_int8_t_s_s(p_41, 0x67L)), l_59)) != g_2[7]) <= p_40), g_21)) && p_39);
        ++l_65;
        g_70 = ((((((((safe_div_func_int32_t_s_s(p_41, p_41)) || 0L) < 0x53F01E83513FE74CLL) > 0xFD8DL) || g_2[8]) && 0UL) && p_41) || 4UL);
    }
    return g_3[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_85[i], "g_85[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 29
   depth: 2, occurrence: 4
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 4
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 69
XXX times a non-volatile is write: 20
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 98.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 27
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 7
   depth: 2, occurrence: 9

XXX percentage a fresh-made variable is used: 35.1
XXX percentage an existing variable is used: 64.9
********************* end of statistics **********************/

