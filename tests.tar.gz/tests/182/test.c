/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14614579672131625478
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile uint32_t g_4 = 1UL;/* VOLATILE GLOBAL g_4 */
static uint32_t g_6[3][5][4] = {{{4294967294UL,0x8C08872FL,4294967294UL,4294967294UL},{0x8C08872FL,0x8C08872FL,3UL,0x8C08872FL},{0x8C08872FL,4294967294UL,4294967294UL,0x8C08872FL},{4294967294UL,0x8C08872FL,4294967294UL,4294967294UL},{0x8C08872FL,0x8C08872FL,3UL,0x8C08872FL}},{{0x8C08872FL,4294967294UL,4294967294UL,0x8C08872FL},{4294967294UL,0x8C08872FL,4294967294UL,4294967294UL},{0x8C08872FL,0x8C08872FL,3UL,0x8C08872FL},{0x8C08872FL,4294967294UL,4294967294UL,0x8C08872FL},{4294967294UL,0x8C08872FL,4294967294UL,4294967294UL}},{{0x8C08872FL,0x8C08872FL,3UL,0x8C08872FL},{0x8C08872FL,4294967294UL,3UL,4294967294UL},{3UL,4294967294UL,3UL,3UL},{4294967294UL,4294967294UL,0x8C08872FL,4294967294UL},{4294967294UL,3UL,3UL,4294967294UL}}};
static volatile int16_t g_8 = 0xF8B8L;/* VOLATILE GLOBAL g_8 */
static uint32_t g_12[10][4][6] = {{{0xFBDE283BL,0x11B55E97L,1UL,0x4A6E8F59L,0UL,0x5AB06C0EL},{1UL,0x09A164E6L,1UL,18446744073709551607UL,18446744073709551606UL,1UL},{1UL,0UL,18446744073709551607UL,0x4A6E8F59L,0x74489B46L,0x4A6E8F59L},{0xFBDE283BL,0UL,0xFBDE283BL,1UL,18446744073709551606UL,18446744073709551607UL}},{{0x5AB06C0EL,0x09A164E6L,0xFBDE283BL,0x5AB06C0EL,0UL,0x4A6E8F59L},{0x4A6E8F59L,0x11B55E97L,18446744073709551607UL,0x5AB06C0EL,0xCF04B064L,1UL},{0x5AB06C0EL,0xCF04B064L,1UL,1UL,0xCF04B064L,0x5AB06C0EL},{0xFBDE283BL,0x11B55E97L,1UL,0x4A6E8F59L,0UL,0x5AB06C0EL}},{{1UL,0x09A164E6L,1UL,18446744073709551607UL,18446744073709551606UL,1UL},{1UL,0UL,18446744073709551607UL,0x4A6E8F59L,0x74489B46L,0x4A6E8F59L},{0xFBDE283BL,0UL,0xFBDE283BL,1UL,18446744073709551606UL,18446744073709551607UL},{0x5AB06C0EL,0x09A164E6L,0xFBDE283BL,0x5AB06C0EL,0UL,0x4A6E8F59L}},{{0x4A6E8F59L,0x11B55E97L,18446744073709551607UL,0x5AB06C0EL,0xCF04B064L,1UL},{0x5AB06C0EL,0xCF04B064L,1UL,1UL,0xCF04B064L,0x5AB06C0EL},{0xFBDE283BL,0x11B55E97L,1UL,0x4A6E8F59L,0UL,0x5AB06C0EL},{1UL,0x09A164E6L,1UL,18446744073709551607UL,18446744073709551606UL,1UL}},{{1UL,0UL,18446744073709551607UL,0x4A6E8F59L,0x74489B46L,0x4A6E8F59L},{0xFBDE283BL,0UL,0xFBDE283BL,1UL,18446744073709551606UL,18446744073709551607UL},{0x5AB06C0EL,0x09A164E6L,0xFBDE283BL,0x5AB06C0EL,0UL,0x4A6E8F59L},{0x4A6E8F59L,0x11B55E97L,18446744073709551607UL,0x5AB06C0EL,0xCF04B064L,1UL}},{{0x5AB06C0EL,0xCF04B064L,1UL,1UL,0xCF04B064L,0x5AB06C0EL},{0xFBDE283BL,0x11B55E97L,1UL,0x4A6E8F59L,0UL,0x5AB06C0EL},{1UL,0x09A164E6L,1UL,18446744073709551607UL,18446744073709551606UL,1UL},{1UL,0UL,18446744073709551607UL,0x4A6E8F59L,0x74489B46L,0x4A6E8F59L}},{{0xFBDE283BL,0UL,0xFBDE283BL,1UL,18446744073709551606UL,18446744073709551607UL},{0x5AB06C0EL,0x09A164E6L,0xFBDE283BL,0x5AB06C0EL,0UL,0x4A6E8F59L},{0x4A6E8F59L,0x11B55E97L,18446744073709551607UL,0x5AB06C0EL,0xCF04B064L,1UL},{0x5AB06C0EL,0xCF04B064L,1UL,1UL,0xCF04B064L,0x5AB06C0EL}},{{0xFBDE283BL,0x11B55E97L,1UL,0x4A6E8F59L,0UL,0x5AB06C0EL},{1UL,0x09A164E6L,1UL,0xC5B641B4L,1UL,1UL},{8UL,5UL,0xC5B641B4L,0x3C3AE507L,0x5AB06C0EL,0x3C3AE507L},{0xB3AE5D5EL,5UL,0xB3AE5D5EL,1UL,1UL,0xC5B641B4L}},{{18446744073709551615UL,0x4A6E8F59L,0xB3AE5D5EL,18446744073709551615UL,5UL,0x3C3AE507L},{0x3C3AE507L,0xFBDE283BL,0xC5B641B4L,18446744073709551615UL,1UL,1UL},{18446744073709551615UL,1UL,1UL,1UL,1UL,18446744073709551615UL},{0xB3AE5D5EL,0xFBDE283BL,8UL,0x3C3AE507L,5UL,18446744073709551615UL}},{{8UL,0x4A6E8F59L,1UL,0xC5B641B4L,1UL,1UL},{8UL,5UL,0xC5B641B4L,0x3C3AE507L,0x5AB06C0EL,0x3C3AE507L},{0xB3AE5D5EL,5UL,0xB3AE5D5EL,1UL,1UL,0xC5B641B4L},{18446744073709551615UL,0x4A6E8F59L,0xB3AE5D5EL,18446744073709551615UL,5UL,0x3C3AE507L}}};
static int16_t g_22 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_12 g_22
 * writes: g_6 g_12 g_22
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    const uint32_t l_5 = 0UL;
    int32_t l_7 = 5L;
    int32_t l_9 = 9L;
    int32_t l_10 = 0xEFA5F9C7L;
    int32_t l_11 = 8L;
    g_6[0][3][0] = (safe_add_func_int8_t_s_s((g_4 , g_4), l_5));
    g_12[5][2][5]--;
    g_22 = (safe_mul_func_uint32_t_u_u((((safe_lshift_func_uint16_t_u_s(((safe_unary_minus_func_uint64_t_u((safe_rshift_func_int16_t_s_u(g_12[5][2][5], 4)))) >= g_12[8][2][3]), g_4)) | 0UL) > l_10), 0L));
    for (l_9 = 0; (l_9 <= 16); l_9 = safe_add_func_int32_t_s_s(l_9, 4))
    { /* block id: 6 */
        uint32_t l_25 = 0x720F84B0L;
        l_25 ^= (-1L);
        for (l_10 = 3; (l_10 >= 0); l_10 -= 1)
        { /* block id: 10 */
            uint32_t l_26 = 0UL;
            int32_t l_27 = 0x2D63D2C8L;
            if (l_11)
                break;
            if (l_26)
                continue;
            l_27 ^= g_22;
        }
    }
    return g_12[1][0][2];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_12[i][j][k], "g_12[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_22, "g_22", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 13
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 7
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 85

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 2
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 61.9
XXX percentage an existing variable is used: 38.1
********************* end of statistics **********************/

