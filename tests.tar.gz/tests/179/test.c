/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13613428929315701324
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-9L);/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 3L;
static int32_t g_6 = 0x4A53AA9AL;
static volatile int32_t g_27 = (-1L);/* VOLATILE GLOBAL g_27 */
static volatile uint64_t g_38 = 0x9335309F33D48A24LL;/* VOLATILE GLOBAL g_38 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_13(int32_t  p_14);
static int32_t  func_22(uint64_t  p_23, int32_t  p_24, const int64_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_2 g_27 g_38
 * writes: g_3 g_6 g_38 g_2
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9[3][6] = {{0xEDB5CABFL,(-3L),(-3L),0xEDB5CABFL,0xEDB5CABFL,(-3L)},{0xEDB5CABFL,0xEDB5CABFL,(-3L),(-3L),0xEDB5CABFL,0xEDB5CABFL},{0xEDB5CABFL,(-3L),(-3L),0xEDB5CABFL,0xEDB5CABFL,(-3L)}};
    int i, j;
    for (g_3 = 0; (g_3 >= 0); g_3 = safe_add_func_int16_t_s_s(g_3, 5))
    { /* block id: 3 */
        int16_t l_11[1][3][2] = {{{(-9L),0x5DE1L},{0x5DE1L,(-9L)},{0x5DE1L,0x5DE1L}}};
        int32_t l_34 = (-1L);
        int32_t l_35 = 0x3BC6C2DBL;
        int32_t l_36 = 0xCDB5CF63L;
        int i, j, k;
        for (g_6 = 0; (g_6 > 1); g_6 = safe_add_func_uint8_t_u_u(g_6, 9))
        { /* block id: 6 */
            if (g_2)
                break;
        }
        for (g_6 = 2; (g_6 >= 0); g_6 -= 1)
        { /* block id: 11 */
            int i, j;
            if (l_9[g_6][(g_6 + 2)])
                break;
        }
        for (g_6 = 2; (g_6 >= 0); g_6 -= 1)
        { /* block id: 16 */
            int i, j;
            return l_9[g_6][(g_6 + 2)];
        }
        if (l_9[2][0])
        { /* block id: 19 */
            const int64_t l_10 = 0xD9D0890515466BC6LL;
            int64_t l_12[1];
            int i;
            for (i = 0; i < 1; i++)
                l_12[i] = (-4L);
            l_9[2][3] |= (l_10 ^ g_2);
            l_11[0][1][0] = l_10;
            l_12[0] = l_11[0][1][0];
        }
        else
        { /* block id: 23 */
            uint16_t l_33 = 0x756EL;
            int32_t l_37 = 0x85C2C102L;
            uint32_t l_42[10][8][2] = {{{0xF9094207L,0x2FA57A88L},{0xFBBA6F2DL,0x5490A9DAL},{0xA2CA01DCL,0xFBBA6F2DL},{0UL,0x41D66485L},{0UL,0xFBBA6F2DL},{0xA2CA01DCL,0x5490A9DAL},{0xFBBA6F2DL,0x2FA57A88L},{0xF9094207L,0x1BC31B53L}},{{0x88841F9FL,0x7676E3B6L},{0x7676E3B6L,1UL},{0x53ED870BL,0x88841F9FL},{0x5490A9DAL,0x41D66485L},{0x53ED870BL,0x41D66485L},{0x5490A9DAL,1UL},{0xF9094207L,18446744073709551615UL},{0UL,0UL}},{{1UL,0x53ED870BL},{18446744073709551609UL,0x0F96394AL},{0UL,0x7676E3B6L},{0xFBBA6F2DL,0UL},{0x1BC31B53L,0x5490A9DAL},{0x1BC31B53L,0UL},{0xFBBA6F2DL,0x7676E3B6L},{0UL,0x0F96394AL}},{{18446744073709551609UL,0x53ED870BL},{1UL,0UL},{0UL,18446744073709551615UL},{0xF9094207L,1UL},{0x5490A9DAL,0x41D66485L},{0x53ED870BL,0x41D66485L},{0x5490A9DAL,1UL},{0xF9094207L,18446744073709551615UL}},{{0UL,0UL},{1UL,0x53ED870BL},{18446744073709551609UL,0x0F96394AL},{0UL,0x7676E3B6L},{0xFBBA6F2DL,0UL},{0x1BC31B53L,0x5490A9DAL},{0x1BC31B53L,0UL},{0xFBBA6F2DL,0x7676E3B6L}},{{0UL,0x0F96394AL},{18446744073709551609UL,0x53ED870BL},{1UL,0UL},{0UL,18446744073709551615UL},{0xF9094207L,1UL},{0x5490A9DAL,0x41D66485L},{0x53ED870BL,0x41D66485L},{0x5490A9DAL,1UL}},{{0xF9094207L,18446744073709551615UL},{0UL,0UL},{1UL,0x53ED870BL},{18446744073709551609UL,0x0F96394AL},{0UL,0x7676E3B6L},{0xFBBA6F2DL,0UL},{0x1BC31B53L,0x5490A9DAL},{0x1BC31B53L,0UL}},{{0xFBBA6F2DL,0x7676E3B6L},{0UL,0x0F96394AL},{18446744073709551609UL,0x53ED870BL},{1UL,0UL},{0UL,18446744073709551615UL},{0xF9094207L,1UL},{0x5490A9DAL,0x41D66485L},{0x53ED870BL,0x41D66485L}},{{0x5490A9DAL,1UL},{0xF9094207L,18446744073709551615UL},{0UL,0UL},{1UL,0x53ED870BL},{18446744073709551609UL,0x0F96394AL},{0UL,0x7676E3B6L},{0xFBBA6F2DL,0UL},{0x1BC31B53L,0x5490A9DAL}},{{0x1BC31B53L,0UL},{0xFBBA6F2DL,0x7676E3B6L},{0UL,0x0F96394AL},{18446744073709551609UL,0x53ED870BL},{1UL,0UL},{0UL,18446744073709551615UL},{0xF9094207L,1UL},{0x5490A9DAL,0x41D66485L}}};
            int i, j, k;
            l_33 ^= (func_13(((safe_rshift_func_uint8_t_u_u(((0x6A9D9E177C422D5FLL ^ g_3) , g_2), 2)) , 0x9EA5D840L)) , g_27);
            ++g_38;
            l_9[2][3] = (!(l_36 , g_38));
            g_2 = (((l_11[0][1][0] , 0x4792D8C2L) < 0x5E2E4BCBL) , l_42[7][4][0]);
        }
    }
    return l_9[2][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_27 g_3
 * writes:
 */
static int32_t  func_13(int32_t  p_14)
{ /* block id: 24 */
    const int64_t l_26[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
    int32_t l_32 = (-8L);
    int i;
    for (p_14 = (-22); (p_14 == 6); p_14++)
    { /* block id: 27 */
        uint32_t l_19[1][8] = {{8UL,8UL,8UL,8UL,8UL,8UL,8UL,8UL}};
        int i, j;
        l_19[0][3]--;
    }
    l_32 = func_22(p_14, g_6, l_26[5]);
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_27
 * writes:
 */
static int32_t  func_22(uint64_t  p_23, int32_t  p_24, const int64_t  p_25)
{ /* block id: 30 */
    uint64_t l_28[4] = {0xE6B87C2657A772BELL,0xE6B87C2657A772BELL,0xE6B87C2657A772BELL,0xE6B87C2657A772BELL};
    int32_t l_29 = 1L;
    int32_t l_30 = 0xD90538E0L;
    uint8_t l_31 = 0xECL;
    int i;
    l_29 &= (((g_27 , 4294967291UL) > p_24) >= l_28[3]);
    l_30 &= l_29;
    return l_31;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 23
   depth: 2, occurrence: 7
   depth: 4, occurrence: 3
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 24
XXX times a non-volatile is write: 14
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 22
XXX percentage of non-volatile access: 82.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 23
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 5
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 42.9
XXX percentage an existing variable is used: 57.1
********************* end of statistics **********************/

