/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14197338338720422344
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0xD1E1E87DL;
static int32_t g_4 = (-1L);
static int32_t g_5 = 0x1FC3EEE2L;
static volatile int32_t g_7 = 0x999D94B4L;/* VOLATILE GLOBAL g_7 */
static volatile int16_t g_14 = 0x6890L;/* VOLATILE GLOBAL g_14 */
static volatile uint64_t g_16 = 0x70AB227D373EE763LL;/* VOLATILE GLOBAL g_16 */


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_16 g_14
 * writes: g_3 g_16
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2[3];
    int32_t l_6 = 0xEF7D6512L;
    int8_t l_8 = 0L;
    int32_t l_15 = 0x4B28ED4AL;
    int i;
    for (i = 0; i < 3; i++)
        l_2[i] = 1L;
    for (g_3 = 0; (g_3 <= 2); g_3 += 1)
    { /* block id: 3 */
        uint32_t l_9 = 8UL;
        int32_t l_12 = (-1L);
        int32_t l_13 = 1L;
        int i;
        l_9++;
        if (l_2[g_3])
            break;
        ++g_16;
        return g_3;
    }
    return g_14;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 7
   depth: 2, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 3
XXX times a non-volatile is write: 2
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 71.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 6
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 68.8
XXX percentage an existing variable is used: 31.2
********************* end of statistics **********************/

