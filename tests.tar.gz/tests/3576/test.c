/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8296511025475643990
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_5[2] = {7UL,7UL};
static uint32_t g_11 = 18446744073709551615UL;
static int8_t g_12 = 0L;
static int32_t g_13 = 0x4E703026L;
static uint32_t g_16 = 18446744073709551610UL;
static uint32_t g_21 = 18446744073709551613UL;
static volatile uint32_t g_25 = 0UL;/* VOLATILE GLOBAL g_25 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_7(int64_t  p_8, uint16_t  p_9, int32_t  p_10);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_11 g_16 g_13 g_21 g_25
 * writes: g_12 g_16 g_13 g_21 g_11 g_25
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_4 = 0x3DF603FAL;
    int32_t l_6 = 0x491E29EAL;
    l_6 &= ((safe_rshift_func_int8_t_s_s(l_4, 5)) || g_5[0]);
    g_13 ^= func_7(g_5[0], l_4, g_11);
    g_21 |= ((1UL == g_11) , l_4);
    for (g_11 = 2; (g_11 <= 40); ++g_11)
    { /* block id: 12 */
        int32_t l_24 = 0x07D19FA5L;
        ++g_25;
    }
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_16
 * writes: g_12 g_16
 */
static int32_t  func_7(int64_t  p_8, uint16_t  p_9, int32_t  p_10)
{ /* block id: 2 */
    int16_t l_14 = 0x0377L;
    int32_t l_15 = 0xF98CAFA3L;
    g_12 = (p_9 >= g_5[0]);
    --g_16;
    p_10 &= (safe_rshift_func_uint8_t_u_u(0x64L, 0));
    p_10 = 0x874BE76DL;
    return l_14;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 8
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 8
XXX percentage of non-volatile access: 81

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 46.2
XXX percentage an existing variable is used: 53.8
********************* end of statistics **********************/

