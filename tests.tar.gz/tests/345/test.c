/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4364691864521939196
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_2 = 0xFEL;
static uint32_t g_3 = 9UL;
static int64_t g_8 = 0L;
static int32_t g_9[9] = {0x55CC25BFL,0x55CC25BFL,0x55CC25BFL,0x55CC25BFL,0x55CC25BFL,0x55CC25BFL,0x55CC25BFL,0x55CC25BFL,0x55CC25BFL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int64_t  func_4(int16_t  p_5);
static int32_t  func_10(int8_t  p_11, uint64_t  p_12);
static uint32_t  func_13(uint32_t  p_14, uint64_t  p_15);
static uint32_t  func_16(uint64_t  p_17, const int64_t  p_18, uint8_t  p_19, const uint32_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_8 g_9 g_3
 * writes: g_3 g_8 g_2 g_9
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_181[10][3][6] = {{{0x90ACFBF7L,0x90ACFBF7L,(-6L),8L,0x0B1D2C0FL,8L},{0xA49CB159L,0x90ACFBF7L,0xA49CB159L,(-7L),(-6L),(-6L)},{0x54F1852EL,0xA49CB159L,0xA49CB159L,0x54F1852EL,0x90ACFBF7L,8L}},{{8L,0x54F1852EL,(-6L),0x54F1852EL,8L,(-7L)},{0x54F1852EL,8L,(-7L),(-7L),8L,0x54F1852EL},{0xA49CB159L,0x54F1852EL,0x90ACFBF7L,8L,0x90ACFBF7L,0x54F1852EL}},{{0x90ACFBF7L,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L,(-6L)},{0x0B1D2C0FL,0x0B1D2C0FL,0x90ACFBF7L,(-7L),0x54F1852EL,(-7L)},{8L,0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L}},{{0xA49CB159L,8L,8L,0xA49CB159L,0x0B1D2C0FL,(-7L)},{(-7L),0xA49CB159L,0x90ACFBF7L,0xA49CB159L,(-7L),(-6L)},{0xA49CB159L,(-7L),(-6L),(-6L),(-7L),0xA49CB159L}},{{8L,0xA49CB159L,0x0B1D2C0FL,(-7L),0x0B1D2C0FL,0xA49CB159L},{0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L,(-6L)},{0x0B1D2C0FL,0x0B1D2C0FL,0x90ACFBF7L,(-7L),0x54F1852EL,(-7L)}},{{8L,0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L},{0xA49CB159L,8L,8L,0xA49CB159L,0x0B1D2C0FL,(-7L)},{(-7L),0xA49CB159L,0x90ACFBF7L,0xA49CB159L,(-7L),(-6L)}},{{0xA49CB159L,(-7L),(-6L),(-6L),(-7L),0xA49CB159L},{8L,0xA49CB159L,0x0B1D2C0FL,(-7L),0x0B1D2C0FL,0xA49CB159L},{0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L,(-6L)}},{{0x0B1D2C0FL,0x0B1D2C0FL,0x90ACFBF7L,(-7L),0x54F1852EL,(-7L)},{8L,0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L},{0xA49CB159L,8L,8L,0xA49CB159L,0x0B1D2C0FL,(-7L)}},{{(-7L),0xA49CB159L,0x90ACFBF7L,0xA49CB159L,(-7L),(-6L)},{0xA49CB159L,(-7L),(-6L),(-6L),(-7L),0xA49CB159L},{8L,0xA49CB159L,0x0B1D2C0FL,(-7L),0x0B1D2C0FL,0xA49CB159L}},{{0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L,(-6L)},{0x0B1D2C0FL,0x0B1D2C0FL,0x90ACFBF7L,(-7L),0x54F1852EL,(-7L)},{8L,0x0B1D2C0FL,8L,(-6L),0x90ACFBF7L,0x90ACFBF7L}}};
    int32_t l_182 = 1L;
    int i, j, k;
    g_3 = g_2;
    l_181[4][1][4] = ((func_4(((safe_add_func_uint8_t_u_u(0x78L, g_2)) ^ g_2)) > l_181[4][1][4]) != l_181[4][1][4]);
    for (g_8 = 0; (g_8 <= 8); g_8 += 1)
    { /* block id: 112 */
        uint64_t l_183 = 0UL;
        for (g_2 = 0; (g_2 <= 8); g_2 += 1)
        { /* block id: 115 */
            ++l_183;
        }
    }
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_2 g_9 g_3
 * writes: g_8 g_2 g_9 g_3
 */
static int64_t  func_4(int16_t  p_5)
{ /* block id: 2 */
    const uint64_t l_21 = 1UL;
    int32_t l_180[8][9] = {{0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL,0xC12B63EBL,0xF12D646EL},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
    int i, j;
    g_8 |= 0L;
    for (g_2 = 0; (g_2 <= 8); g_2 += 1)
    { /* block id: 6 */
        int32_t l_82 = (-10L);
        int i;
        if (g_9[g_2])
            break;
        g_9[0] = func_10((func_13(func_16((p_5 <= g_9[g_2]), l_21, g_8, g_3), l_82) & g_2), g_2);
    }
    l_180[1][5] = (((safe_add_func_uint32_t_u_u(0xA3AFCE4FL, l_21)) >= l_21) , (-2L));
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_10(int8_t  p_11, uint64_t  p_12)
{ /* block id: 103 */
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_8 g_2 g_9
 * writes: g_9 g_8 g_3
 */
static uint32_t  func_13(uint32_t  p_14, uint64_t  p_15)
{ /* block id: 40 */
    int16_t l_89 = 0x10E3L;
    int32_t l_104[8][10][2] = {{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}},{{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)},{0L,(-3L)},{0x8FA652D3L,(-3L)}}};
    uint8_t l_126 = 0xC7L;
    int i, j, k;
lbl_97:
    g_9[6] = (((((4UL == 0x5F25790E88B3BFF7LL) > 0xBFF4CCE4L) , (-10L)) < 4294967295UL) == 0x9475L);
    if (((safe_sub_func_uint8_t_u_u((safe_add_func_int64_t_s_s(((safe_sub_func_uint64_t_u_u(p_14, (-1L))) , l_89), 1UL)), (-1L))) & l_89))
    { /* block id: 42 */
        int16_t l_90 = 1L;
        int32_t l_102 = 0x289B7103L;
        int32_t l_123 = 0xD9C254B3L;
        int32_t l_124 = 0x9D8590BCL;
        int32_t l_125 = 0xA83D060DL;
        l_90 = g_3;
        if ((safe_mod_func_uint64_t_u_u(((((safe_lshift_func_uint8_t_u_u((((((safe_mod_func_uint16_t_u_u(l_90, g_8)) > 0L) == 0x0DL) ^ p_14) , 0x5BL), l_89)) | g_2) < (-6L)) & 0x0B04AA5BL), 0x7B03FFABF64895FDLL)))
        { /* block id: 44 */
            if (l_90)
                goto lbl_97;
            l_102 ^= (safe_lshift_func_uint16_t_u_u((safe_add_func_int32_t_s_s(((-1L) | p_14), (-1L))), g_8));
        }
        else
        { /* block id: 47 */
            int8_t l_103 = 0L;
            l_103 ^= (l_89 , l_89);
            return l_89;
        }
        l_104[7][2][1] = (p_14 & 0x03L);
        for (g_8 = 0; (g_8 <= 1); g_8 += 1)
        { /* block id: 54 */
            int64_t l_109[5];
            int32_t l_110[9][1][3];
            int i, j, k;
            for (i = 0; i < 5; i++)
                l_109[i] = 0x5626D82A544FF936LL;
            for (i = 0; i < 9; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 3; k++)
                        l_110[i][j][k] = 0x1BE5FB79L;
                }
            }
            l_110[7][0][0] = (((safe_mul_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((0UL >= 0xD8BC617FL), 0xB3L)), p_15)) ^ p_15) , l_109[1]);
            g_9[4] = (safe_div_func_int32_t_s_s((~(safe_mul_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((safe_add_func_int8_t_s_s(((((((!(((((safe_lshift_func_int8_t_s_u(0L, 0)) == l_90) | 0x6546BCCE8995D892LL) | 0UL) == l_110[7][0][0])) <= p_14) || p_15) , g_9[4]) == 8UL) < 0xD4L), p_15)) & p_14), p_15)), 0x8DF4L))), l_110[5][0][1]));
            if (l_102)
                continue;
            l_126++;
        }
    }
    else
    { /* block id: 60 */
        uint8_t l_131 = 0xA1L;
        int32_t l_141 = (-1L);
        if (((((g_9[0] != (-3L)) & (-7L)) , l_126) , (-8L)))
        { /* block id: 61 */
            uint8_t l_129 = 0UL;
            l_129 = p_15;
        }
        else
        { /* block id: 63 */
            int16_t l_130 = 0x9404L;
            l_104[5][3][1] = l_130;
            l_131 = ((p_14 >= p_15) <= p_15);
        }
        for (g_3 = 0; (g_3 > 15); g_3++)
        { /* block id: 69 */
            g_9[0] = p_14;
        }
        for (l_126 = (-1); (l_126 >= 44); l_126 = safe_add_func_uint32_t_u_u(l_126, 3))
        { /* block id: 74 */
            uint32_t l_140 = 1UL;
            g_9[5] &= ((safe_rshift_func_int8_t_s_s(0xB5L, g_2)) , g_3);
            l_141 ^= ((safe_lshift_func_int16_t_s_u(l_140, 14)) == g_8);
        }
        for (p_14 = 0; (p_14 <= 8); p_14 += 1)
        { /* block id: 80 */
            int8_t l_162 = 0xC1L;
            int i;
            g_9[p_14] = (safe_mod_func_uint16_t_u_u((safe_mod_func_int16_t_s_s((safe_rshift_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u(((safe_add_func_int32_t_s_s(3L, 0xEAFE2984L)) && g_9[p_14]), 253UL)) >= 0x96761978L), p_14)) < (-1L)), g_2)), 0xDBFFL)), 0xCF1AL));
            l_162 = (safe_div_func_uint64_t_u_u(((safe_sub_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s((safe_lshift_func_int16_t_s_s(g_9[3], g_2)), 1)), 0L)) != l_89), g_2));
        }
    }
    for (p_14 = 0; (p_14 <= 1); p_14 += 1)
    { /* block id: 87 */
        int16_t l_163 = 0x7C05L;
        int32_t l_170 = 1L;
        uint16_t l_175 = 6UL;
        if ((0UL | g_9[2]))
        { /* block id: 88 */
            uint64_t l_164 = 0x9E635219DD48334ALL;
            --l_164;
            return l_163;
        }
        else
        { /* block id: 91 */
            g_9[4] = (((0x723FDEEFCC7DE1C9LL >= p_14) >= 0L) != l_89);
        }
        for (g_8 = 1; (g_8 >= 0); g_8 -= 1)
        { /* block id: 96 */
            int32_t l_177[6] = {(-5L),(-5L),0xB7763822L,(-5L),(-5L),0xB7763822L};
            int i;
            l_170 = ((!(((safe_sub_func_uint32_t_u_u(1UL, 0UL)) | 0xE93BA542B8B1C4E8LL) , 0x02CD46ABL)) , (-1L));
            l_104[7][7][0] &= (safe_lshift_func_int16_t_s_u(((((safe_mod_func_uint32_t_u_u(g_8, g_2)) >= g_3) , l_175) >= g_2), l_170));
            l_177[0] = (~p_15);
        }
    }
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_9 g_3 g_2
 * writes: g_8 g_9
 */
static uint32_t  func_16(uint64_t  p_17, const int64_t  p_18, uint8_t  p_19, const uint32_t  p_20)
{ /* block id: 8 */
    const int16_t l_27 = 0x0DCEL;
    int32_t l_35 = (-2L);
    int32_t l_36 = 0L;
    int32_t l_38 = 0xFB6F8A3EL;
    int32_t l_39 = 5L;
    int16_t l_66 = 0L;
    int16_t l_81 = 1L;
    for (g_8 = 7; (g_8 >= 0); g_8 -= 1)
    { /* block id: 11 */
        uint32_t l_26 = 0x94951162L;
        int32_t l_32[1][4] = {{0x398EF544L,0x398EF544L,0x398EF544L,0x398EF544L}};
        int32_t l_37 = 0x53E8AF80L;
        uint32_t l_40 = 0xAC6AA04DL;
        uint8_t l_45[9][2][9] = {{{4UL,1UL,0x93L,0xDBL,9UL,0xDBL,0x93L,1UL,4UL},{0xEAL,0xB9L,255UL,0x37L,255UL,250UL,255UL,1UL,1UL}},{{0xD1L,253UL,0xA5L,0x09L,0xA5L,253UL,0xD1L,0x73L,0x00L},{0xEAL,255UL,255UL,0xB9L,0x37L,1UL,0x5EL,255UL,0xCCL}},{{4UL,0x39L,0xA8L,0x39L,4UL,0x09L,0x2AL,0x73L,4UL},{255UL,4UL,0xB9L,1UL,1UL,255UL,255UL,1UL,1UL}},{{0x93L,0x73L,0x93L,1UL,0x00L,0x09L,0xD1L,1UL,0xA5L},{1UL,255UL,0xD5L,255UL,0xCCL,1UL,4UL,250UL,255UL}},{{9UL,0xDBL,0x93L,1UL,4UL,253UL,0x93L,0xA7L,9UL},{0xCCL,0xB9L,250UL,1UL,1UL,250UL,0xB9L,0xCCL,0xEAL}},{{0xD1L,0xDBL,0x93L,0x39L,0xA5L,0xDBL,0x00L,255UL,0x00L},{1UL,255UL,255UL,0xB9L,255UL,0xCCL,250UL,255UL,0xEAL}},{{9UL,0x73L,0xA8L,0x09L,9UL,0x39L,0x2AL,0x39L,9UL},{0x37L,4UL,4UL,0x37L,0xEAL,255UL,250UL,0xCCL,255UL}},{{0x93L,0x39L,0xA5L,0xDBL,0x00L,255UL,0x00L,0xDBL,0xA5L},{255UL,255UL,0x5EL,255UL,0xEAL,0xCCL,0xB9L,250UL,1UL}},{{4UL,253UL,0x93L,0xA7L,9UL,0xA7L,0x93L,253UL,4UL},{1UL,0xB9L,0x5EL,0x37L,255UL,250UL,4UL,1UL,0xCCL}}};
        uint8_t l_73 = 0UL;
        int i, j, k;
        for (p_17 = 0; (p_17 <= 8); p_17 += 1)
        { /* block id: 14 */
            uint16_t l_34[1];
            int i;
            for (i = 0; i < 1; i++)
                l_34[i] = 0xAC16L;
            g_9[g_8] = ((safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint16_t_u_u((((g_9[p_17] && p_19) || p_17) == (-1L)), g_8)) && l_26), l_27)) != p_18);
            l_32[0][1] = (((((safe_add_func_uint8_t_u_u((((safe_rshift_func_uint16_t_u_u(((-1L) != g_9[g_8]), g_9[5])) , p_19) | g_3), p_20)) || 0x3A64L) < p_17) , 0xFE10EF7DL) && 0x4484F75DL);
            l_32[0][1] = ((p_20 | l_32[0][1]) && g_9[4]);
            l_34[0] &= (~l_32[0][1]);
        }
        --l_40;
        if ((p_20 || g_9[2]))
        { /* block id: 21 */
            int8_t l_52[5][5][5] = {{{0xCCL,0L,0x68L,(-10L),0xA4L},{0xECL,(-1L),0xBBL,1L,1L},{0xD7L,(-10L),0xCCL,8L,8L},{1L,0xB7L,1L,0x99L,9L},{0xAAL,0x6FL,0L,0xCCL,0xD7L}},{{(-1L),(-6L),1L,0x99L,7L},{0x06L,0x68L,0x6FL,(-10L),(-1L)},{1L,(-9L),0x6CL,0x6CL,(-9L)},{0x40L,0x11L,0xA4L,(-1L),0xC9L},{0x75L,(-1L),0x9CL,(-1L),1L}},{{0x6FL,(-10L),0xD7L,0x06L,(-7L)},{0x75L,9L,0x99L,1L,0xB7L},{0x40L,0x79L,0x79L,0x40L,0xA4L},{1L,0x99L,9L,0x75L,(-6L)},{0x06L,0xD7L,(-10L),0x6FL,0xCCL}},{{(-1L),0x9CL,(-1L),0x75L,0x71L},{(-1L),0xA4L,0x11L,0x40L,0x11L},{0x6CL,0x6CL,(-9L),1L,0x9CL},{(-10L),0x6FL,0x68L,0x06L,0x40L},{0x99L,1L,(-6L),(-1L),0xECL}},{{0xA4L,0x6FL,2L,(-1L),(-10L)},{0xB8L,0x6CL,(-1L),0x6CL,0xB8L},{0L,0xA4L,8L,(-10L),0xA1L},{0xB7L,0x9CL,0x75L,0x99L,(-1L)},{8L,0xD7L,(-1L),0xA4L,0xA1L}}};
            int32_t l_53[3];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_53[i] = 2L;
            g_9[8] = 6L;
            l_45[6][1][6] &= (safe_rshift_func_int16_t_s_u(g_2, p_18));
            l_53[0] |= (((((safe_lshift_func_int8_t_s_u((safe_rshift_func_int8_t_s_u(((safe_add_func_uint32_t_u_u(((p_18 || 3L) >= p_17), 0xBED3A9A7L)) | p_18), l_39)), l_38)) && 0x03L) == p_18) || l_52[0][4][0]) < g_2);
            g_9[0] = (+(safe_mul_func_int8_t_s_s(((((safe_sub_func_int32_t_s_s((!(1UL < l_36)), g_3)) && l_32[0][1]) == g_2) != 1UL), l_53[0])));
        }
        else
        { /* block id: 26 */
            uint32_t l_60[9][8][3] = {{{0x1997BD6DL,2UL,1UL},{0x3C07AF8EL,2UL,4294967292UL},{0xC41F2E98L,0x1997BD6DL,4294967290UL},{0x49152248L,2UL,0x2EB7B5DCL},{0x4D29090FL,0x4D29090FL,0x2EB7B5DCL},{2UL,0x49152248L,4294967290UL},{0x1997BD6DL,0xC41F2E98L,4294967292UL},{2UL,0x3C07AF8EL,1UL}},{{2UL,0x1997BD6DL,4294967292UL},{1UL,0UL,4294967290UL},{7UL,0x3C07AF8EL,0x2EB7B5DCL},{0xC41F2E98L,1UL,0x2EB7B5DCL},{0x042C8AC7L,8UL,4294967290UL},{2UL,0x4D29090FL,4294967292UL},{0UL,0x042C8AC7L,1UL},{0x042C8AC7L,0UL,4294967292UL}},{{0x4D29090FL,2UL,4294967290UL},{8UL,0x042C8AC7L,0x2EB7B5DCL},{1UL,0xC41F2E98L,0x2EB7B5DCL},{0x3C07AF8EL,7UL,4294967290UL},{0UL,1UL,4294967292UL},{0x1997BD6DL,2UL,1UL},{0x3C07AF8EL,2UL,4294967292UL},{0xC41F2E98L,0x1997BD6DL,4294967290UL}},{{0x49152248L,2UL,0x2EB7B5DCL},{0x4D29090FL,0x4D29090FL,0x2EB7B5DCL},{2UL,0x49152248L,4294967290UL},{0x1997BD6DL,0xC41F2E98L,4294967292UL},{2UL,0x3C07AF8EL,1UL},{2UL,0x1997BD6DL,4294967292UL},{1UL,0xE95A6083L,0x39625A9BL},{0x9F7DC92BL,0UL,0x4D29090FL}},{{0x9A7EFCC6L,0xF98D3219L,0x4D29090FL},{0x99145A4FL,0x31468BD1L,0x39625A9BL},{0x69343887L,1UL,7UL},{0xE95A6083L,0x99145A4FL,0UL},{0x99145A4FL,0xE95A6083L,7UL},{1UL,0x69343887L,0x39625A9BL},{0x31468BD1L,0x99145A4FL,0x4D29090FL},{0xF98D3219L,0x9A7EFCC6L,0x4D29090FL}},{{0UL,0x9F7DC92BL,0x39625A9BL},{0xE95A6083L,0xF98D3219L,7UL},{0x26D9AC2FL,0x93E2C01BL,0UL},{0UL,0x69343887L,7UL},{0x9A7EFCC6L,0x26D9AC2FL,0x39625A9BL},{4294967295UL,0x93E2C01BL,0x4D29090FL},{1UL,1UL,0x4D29090FL},{0x93E2C01BL,4294967295UL,0x39625A9BL}},{{0x26D9AC2FL,0x9A7EFCC6L,7UL},{0x69343887L,0UL,0UL},{0x93E2C01BL,0x26D9AC2FL,7UL},{0xF98D3219L,0xE95A6083L,0x39625A9BL},{0x9F7DC92BL,0UL,0x4D29090FL},{0x9A7EFCC6L,0xF98D3219L,0x4D29090FL},{0x99145A4FL,0x31468BD1L,0x39625A9BL},{0x69343887L,1UL,7UL}},{{0xE95A6083L,0x99145A4FL,0UL},{0x99145A4FL,0xE95A6083L,7UL},{1UL,0x69343887L,0x39625A9BL},{0x31468BD1L,0x99145A4FL,0x4D29090FL},{0xF98D3219L,0x9A7EFCC6L,0x4D29090FL},{0UL,0x9F7DC92BL,0x39625A9BL},{0xE95A6083L,0xF98D3219L,7UL},{0x26D9AC2FL,0x93E2C01BL,0UL}},{{0UL,0x69343887L,7UL},{0x9A7EFCC6L,0x26D9AC2FL,0x39625A9BL},{4294967295UL,0x93E2C01BL,0x4D29090FL},{1UL,1UL,0x4D29090FL},{0x93E2C01BL,4294967295UL,0x39625A9BL},{0x26D9AC2FL,0x9A7EFCC6L,7UL},{0x69343887L,0UL,0UL},{0x93E2C01BL,0x26D9AC2FL,7UL}}};
            int32_t l_63 = 0xCF37D808L;
            int i, j, k;
            l_60[4][3][2]--;
            l_63 = l_38;
            g_9[3] = ((((((safe_add_func_int8_t_s_s(((((p_18 <= 0x2C05F70B01AA1EC4LL) > l_36) <= 0x14BB34BBF6D4BD0DLL) >= l_35), p_20)) | l_45[6][1][6]) , g_9[4]) || g_8) , l_66) > p_17);
        }
        if ((safe_mul_func_int16_t_s_s((+18446744073709551615UL), l_45[6][1][6])))
        { /* block id: 31 */
            int16_t l_70 = 0x59F1L;
            return l_70;
        }
        else
        { /* block id: 33 */
            int32_t l_71 = 5L;
            int32_t l_72[2];
            int i;
            for (i = 0; i < 2; i++)
                l_72[i] = (-1L);
            if (p_17)
                break;
            l_73++;
            l_81 = (safe_lshift_func_uint16_t_u_u((safe_unary_minus_func_uint64_t_u(((safe_rshift_func_uint16_t_u_s(p_18, 6)) , g_2))), 11));
        }
    }
    return g_8;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 52
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 69
   depth: 2, occurrence: 17
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 2
   depth: 6, occurrence: 6
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 4
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 139
XXX times a non-volatile is write: 52
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 70
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 17
   depth: 2, occurrence: 38

XXX percentage a fresh-made variable is used: 20.7
XXX percentage an existing variable is used: 79.3
********************* end of statistics **********************/

