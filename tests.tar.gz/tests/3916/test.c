/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16179196623232738244
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x52061F66L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int32_t g_4 = (-1L);
static int32_t g_16 = 6L;


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);
static int32_t  func_22(int32_t  p_23, uint16_t  p_24);
static uint8_t  func_46(int16_t  p_47, uint64_t  p_48, uint64_t  p_49);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_16 g_2
 * writes: g_4 g_2 g_3
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_9 = 0x31L;
    int32_t l_12 = 0x13AF72B5L;
    int32_t l_13 = 0x694D2B5FL;
    int32_t l_14 = 0L;
    int32_t l_15[10] = {0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L,0x32E3CA36L};
    int64_t l_18[6] = {(-9L),(-9L),(-9L),(-9L),(-9L),(-9L)};
    uint32_t l_19[8] = {0x2A53EBFFL,4UL,0x2A53EBFFL,0x2A53EBFFL,4UL,0x2A53EBFFL,0x2A53EBFFL,4UL};
    int8_t l_40[4];
    uint32_t l_41[3];
    int16_t l_65 = (-1L);
    int i;
    for (i = 0; i < 4; i++)
        l_40[i] = 0x73L;
    for (i = 0; i < 3; i++)
        l_41[i] = 0x3DC1765DL;
    for (g_4 = (-6); (g_4 > 8); g_4++)
    { /* block id: 3 */
        const int64_t l_7 = (-10L);
        int32_t l_8 = 0x5FAC1226L;
        int32_t l_10 = 0L;
        int32_t l_11[7] = {0x35EDADE0L,0x35EDADE0L,0x35EDADE0L,0x35EDADE0L,0x35EDADE0L,0x35EDADE0L,0x35EDADE0L};
        int8_t l_17 = 0L;
        int i;
        g_2 = (((g_3[5] , 0xA9A97186L) , l_7) & g_4);
        if (g_3[5])
            continue;
        --l_19[7];
        l_12 &= func_22(l_10, g_3[5]);
    }
    l_41[0]--;
    l_65 &= (safe_add_func_uint8_t_u_u(func_46((safe_sub_func_uint64_t_u_u((safe_add_func_uint64_t_u_u((((g_16 != 0x68L) < 0x95D68046L) , g_4), g_4)), 0x1DE06325DDBF1A1BLL)), l_13, l_40[3]), l_9));
    return l_18[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static int32_t  func_22(int32_t  p_23, uint16_t  p_24)
{ /* block id: 7 */
    int64_t l_25[6];
    int32_t l_26 = 0xE0AEE481L;
    int32_t l_27[4];
    uint32_t l_28 = 18446744073709551615UL;
    uint64_t l_37 = 0xE6AC9C4BD7DA5A1DLL;
    int i;
    for (i = 0; i < 6; i++)
        l_25[i] = (-1L);
    for (i = 0; i < 4; i++)
        l_27[i] = (-1L);
    ++l_28;
    for (p_23 = (-17); (p_23 != (-7)); p_23 = safe_add_func_int64_t_s_s(p_23, 2))
    { /* block id: 11 */
        int32_t l_33 = 0x0A5FF0F9L;
        int32_t l_34 = (-1L);
        int32_t l_35 = (-5L);
        int32_t l_36[1];
        int i;
        for (i = 0; i < 1; i++)
            l_36[i] = 2L;
        l_37++;
        return l_36[0];
    }
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_2
 * writes: g_3
 */
static uint8_t  func_46(int16_t  p_47, uint64_t  p_48, uint64_t  p_49)
{ /* block id: 19 */
    int64_t l_54 = 0x689573D52B7690A4LL;
    int32_t l_64 = 0L;
    if (((l_54 == l_54) < l_54))
    { /* block id: 20 */
        int16_t l_55 = 0x97D0L;
        l_55 = ((p_49 > p_47) , 0xCDF1940CL);
    }
    else
    { /* block id: 22 */
        uint32_t l_56[4];
        int64_t l_63 = 0x5F0DE8C290DB8D7FLL;
        int i;
        for (i = 0; i < 4; i++)
            l_56[i] = 0xE52087D5L;
        g_3[6] &= 0L;
        l_56[0]--;
        l_64 |= (((((((safe_rshift_func_int8_t_s_u((safe_sub_func_uint16_t_u_u(p_49, g_3[5])), g_4)) != p_48) != p_48) ^ l_63) >= 0x1400L) && p_47) , g_3[4]);
    }
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 30
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 2
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 11
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 175
XXX percentage of non-volatile access: 81.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 19
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 10

XXX percentage a fresh-made variable is used: 8.13
XXX percentage an existing variable is used: 91.9
********************* end of statistics **********************/

