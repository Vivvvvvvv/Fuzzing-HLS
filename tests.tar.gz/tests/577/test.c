/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      354563919115037816
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_4 = (-1L);/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0xFA5C62E0L;/* VOLATILE GLOBAL g_5 */
static volatile uint64_t g_6[6][6][3] = {{{1UL,0x8F0D0714AD38DC53LL,1UL},{0x8F0D0714AD38DC53LL,0x97963BA20B95AE64LL,0x97963BA20B95AE64LL},{18446744073709551608UL,1UL,1UL},{0UL,1UL,1UL},{0UL,18446744073709551615UL,0x8F0D0714AD38DC53LL},{18446744073709551608UL,0x4A0D461E3FF14EB4LL,18446744073709551608UL}},{{0x8F0D0714AD38DC53LL,18446744073709551615UL,0UL},{1UL,1UL,0UL},{1UL,1UL,18446744073709551608UL},{0x97963BA20B95AE64LL,0x97963BA20B95AE64LL,0x8F0D0714AD38DC53LL},{1UL,0x8F0D0714AD38DC53LL,1UL},{1UL,0x8F0D0714AD38DC53LL,1UL}},{{0x8F0D0714AD38DC53LL,0x97963BA20B95AE64LL,0x97963BA20B95AE64LL},{18446744073709551608UL,1UL,1UL},{0UL,1UL,1UL},{0UL,0x8F0D0714AD38DC53LL,0x97963BA20B95AE64LL},{18446744073709551615UL,1UL,18446744073709551615UL},{0x97963BA20B95AE64LL,0x8F0D0714AD38DC53LL,18446744073709551608UL}},{{0x4A0D461E3FF14EB4LL,1UL,18446744073709551608UL},{0UL,0x4A0D461E3FF14EB4LL,18446744073709551615UL},{0x924C00011151C3C3LL,0x924C00011151C3C3LL,0x97963BA20B95AE64LL},{0UL,0x97963BA20B95AE64LL,0x4A0D461E3FF14EB4LL},{0x4A0D461E3FF14EB4LL,0x97963BA20B95AE64LL,0UL},{0x97963BA20B95AE64LL,0x924C00011151C3C3LL,0x924C00011151C3C3LL}},{{18446744073709551615UL,0x4A0D461E3FF14EB4LL,0UL},{18446744073709551608UL,1UL,0x4A0D461E3FF14EB4LL},{18446744073709551608UL,0x8F0D0714AD38DC53LL,0x97963BA20B95AE64LL},{18446744073709551615UL,1UL,18446744073709551615UL},{0x97963BA20B95AE64LL,0x8F0D0714AD38DC53LL,18446744073709551608UL},{0x4A0D461E3FF14EB4LL,1UL,18446744073709551608UL}},{{0UL,0x4A0D461E3FF14EB4LL,18446744073709551615UL},{0x924C00011151C3C3LL,0x924C00011151C3C3LL,0x97963BA20B95AE64LL},{0UL,0x97963BA20B95AE64LL,0x4A0D461E3FF14EB4LL},{0x4A0D461E3FF14EB4LL,0x97963BA20B95AE64LL,0UL},{0x97963BA20B95AE64LL,0x924C00011151C3C3LL,0x924C00011151C3C3LL},{18446744073709551615UL,0x4A0D461E3FF14EB4LL,0UL}}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_4
 * writes: g_6
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0xD41E5596L;
    int32_t l_3 = 0L;
    --g_6[3][4][1];
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_6[i][j][k], "g_6[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 5
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 1
breakdown:
   depth: 1, occurrence: 3

XXX total number of pointers: 0

XXX times a non-volatile is read: 0
XXX times a non-volatile is write: 0
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 0

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 83.3
XXX percentage an existing variable is used: 16.7
********************* end of statistics **********************/

