/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12209582440201559170
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int32_t  f0;
   uint32_t  f1;
   int32_t  f2;
   int32_t  f3;
   uint16_t  f4;
   volatile uint16_t  f5;
   uint8_t  f6;
   uint32_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static uint8_t g_4 = 0xE8L;
static int32_t g_20 = (-1L);
static uint32_t g_32 = 0x062CF9E8L;
static int64_t g_35 = 0x2B5D06DE21E52503LL;
static volatile uint32_t g_36[9] = {0x7092FF82L,0x7092FF82L,0x7092FF82L,0x7092FF82L,0x7092FF82L,0x7092FF82L,0x7092FF82L,0x7092FF82L,0x7092FF82L};
static struct S0 g_39 = {7L,0xD5DF5B04L,-1L,0x0615A034L,1UL,0UL,8UL,0UL};/* VOLATILE GLOBAL g_39 */


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static int32_t  func_6(uint32_t  p_7);
static int8_t  func_9(uint32_t  p_10, int16_t  p_11, uint64_t  p_12, int16_t  p_13, int8_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_20 g_32 g_36 g_39
 * writes: g_20 g_32 g_36
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = 0xE780L;
    int32_t l_3 = 0xD19C9214L;
lbl_29:
    l_3 = l_2;
    if (g_4)
    { /* block id: 2 */
        uint16_t l_5 = 65535UL;
        l_5 = g_4;
    }
    else
    { /* block id: 4 */
        int16_t l_8 = 0x008BL;
        l_3 = func_6(l_8);
        for (l_2 = (-26); (l_2 > 2); l_2 = safe_add_func_uint8_t_u_u(l_2, 5))
        { /* block id: 15 */
            uint16_t l_28 = 65533UL;
            if (l_28)
                break;
            if (l_28)
                break;
            if (g_4)
                break;
            g_20 = 0x97CBB402L;
        }
        if (l_2)
            goto lbl_29;
        g_32 |= (safe_add_func_uint64_t_u_u((0x56FE18BD2E84CBF7LL == g_20), l_8));
    }
    l_3 = (safe_mod_func_uint8_t_u_u(l_3, g_20));
    ++g_36[8];
    return g_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_20
 * writes: g_20
 */
static int32_t  func_6(uint32_t  p_7)
{ /* block id: 5 */
    uint8_t l_19[10] = {0UL,0x40L,0UL,0UL,0x40L,0UL,0UL,0x40L,0UL,0UL};
    uint64_t l_24[7];
    int32_t l_25 = (-8L);
    int i;
    for (i = 0; i < 7; i++)
        l_24[i] = 0UL;
    l_25 = ((func_9((safe_sub_func_int32_t_s_s((safe_mod_func_uint64_t_u_u((l_19[2] && g_4), p_7)), p_7)), l_19[7], p_7, p_7, p_7) == l_24[6]) && g_4);
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_20
 * writes: g_20
 */
static int8_t  func_9(uint32_t  p_10, int16_t  p_11, uint64_t  p_12, int16_t  p_13, int8_t  p_14)
{ /* block id: 6 */
    uint8_t l_21 = 0xC5L;
    l_21--;
    g_20 = ((g_20 , p_10) || p_13);
    return l_21;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_36[i], "g_36[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_39.f0, "g_39.f0", print_hash_value);
    transparent_crc(g_39.f1, "g_39.f1", print_hash_value);
    transparent_crc(g_39.f2, "g_39.f2", print_hash_value);
    transparent_crc(g_39.f3, "g_39.f3", print_hash_value);
    transparent_crc(g_39.f4, "g_39.f4", print_hash_value);
    transparent_crc(g_39.f5, "g_39.f5", print_hash_value);
    transparent_crc(g_39.f6, "g_39.f6", print_hash_value);
    transparent_crc(g_39.f7, "g_39.f7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 23
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 28
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 97.4

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 19
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 5
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 36.6
XXX percentage an existing variable is used: 63.4
********************* end of statistics **********************/

