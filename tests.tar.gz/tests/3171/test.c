/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10203144378903982682
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_2 = (-4L);
static int32_t g_14[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static uint32_t  func_4(uint32_t  p_5, uint64_t  p_6, uint64_t  p_7, int8_t  p_8, const int8_t  p_9);
static uint16_t  func_17(uint64_t  p_18, int8_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_14
 * writes: g_14
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_3 = 18446744073709551615UL;
    int8_t l_12 = (-5L);
    int32_t l_25 = 1L;
    l_3 = (0xBEAA32B1L >= g_2);
    l_25 = (func_4(((safe_div_func_int64_t_s_s(((((g_2 , g_2) >= (-1L)) >= 0x6576L) < l_3), l_12)) <= g_2), l_12, g_2, l_3, l_12) | l_12);
    return l_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_14
 * writes: g_14
 */
static uint32_t  func_4(uint32_t  p_5, uint64_t  p_6, uint64_t  p_7, int8_t  p_8, const int8_t  p_9)
{ /* block id: 2 */
    const uint32_t l_13[1] = {1UL};
    int32_t l_20 = 0x290CE96FL;
    int i;
    g_14[6] = l_13[0];
    l_20 &= (safe_mod_func_uint16_t_u_u(func_17(l_13[0], g_2), l_13[0]));
    l_20 = (safe_rshift_func_uint16_t_u_u(((safe_mod_func_uint16_t_u_u(0x49BCL, p_5)) != l_13[0]), 12));
    l_20 = g_14[6];
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes:
 */
static uint16_t  func_17(uint64_t  p_18, int8_t  p_19)
{ /* block id: 4 */
    return g_14[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 1
   depth: 4, occurrence: 2
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 9
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 9

XXX percentage a fresh-made variable is used: 25.9
XXX percentage an existing variable is used: 74.1
********************* end of statistics **********************/

