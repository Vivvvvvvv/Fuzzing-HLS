/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6279165232499241101
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0xE0A8EAC8L;
static int64_t g_12 = 2L;
static int16_t g_24 = 0x9F19L;
static int8_t g_25 = (-6L);


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_13(uint64_t  p_14, int64_t  p_15, uint16_t  p_16, int32_t  p_17, uint8_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_12 g_25
 * writes: g_2 g_12 g_24 g_25
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_6 = (-1L);
lbl_11:
    for (g_2 = 0; (g_2 >= 27); ++g_2)
    { /* block id: 3 */
        const int64_t l_5 = 0x0F951FE77DD68876LL;
        l_6 = l_5;
    }
    for (g_2 = 28; (g_2 < 1); g_2 = safe_sub_func_int16_t_s_s(g_2, 3))
    { /* block id: 8 */
        int16_t l_19 = 0xE797L;
        for (l_6 = 16; (l_6 <= (-27)); l_6 = safe_sub_func_int32_t_s_s(l_6, 8))
        { /* block id: 11 */
            if (l_6)
                goto lbl_11;
            g_12 &= l_6;
        }
        l_6 ^= (g_2 , g_2);
        g_25 &= ((func_13((l_19 , l_19), l_6, g_12, l_19, g_12) | g_2) , l_6);
    }
    return g_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_12
 * writes: g_24
 */
static int32_t  func_13(uint64_t  p_14, int64_t  p_15, uint16_t  p_16, int32_t  p_17, uint8_t  p_18)
{ /* block id: 16 */
    uint8_t l_23 = 1UL;
    g_24 = ((safe_add_func_int8_t_s_s(((((~g_12) < 0UL) , g_12) <= 1UL), l_23)) != 0x83D1F0DFL);
    return p_15;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 4
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 11
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 4
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 31.8
XXX percentage an existing variable is used: 68.2
********************* end of statistics **********************/

