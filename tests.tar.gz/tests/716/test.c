/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5433454735146055719
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_15[9] = {0xC2A8L,0xC2A8L,0xC2A8L,0xC2A8L,0xC2A8L,0xC2A8L,0xC2A8L,0xC2A8L,0xC2A8L};
static const uint32_t g_16 = 4294967295UL;
static volatile int32_t g_35[7] = {0x35DD7582L,0x35DD7582L,0x35DD7582L,0x35DD7582L,0x35DD7582L,0x35DD7582L,0x35DD7582L};
static int16_t g_84 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint16_t  func_5(uint32_t  p_6, int32_t  p_7, uint64_t  p_8, int16_t  p_9);
static uint8_t  func_22(int64_t  p_23, int8_t  p_24, int8_t  p_25);
static int64_t  func_26(uint8_t  p_27, int32_t  p_28, int32_t  p_29);
static const int32_t  func_46(uint16_t  p_47);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_35 g_84
 * writes: g_35 g_15 g_84
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_14[3];
    int32_t l_42[3][8][7] = {{{(-1L),(-7L),0x20C5ABFEL,6L,(-4L),0x6DB3533BL,(-1L)},{0L,0x52276C1FL,0x69945C66L,(-7L),0L,0x6DB3533BL,(-1L)},{2L,(-4L),(-2L),0x851CC0D6L,0L,1L,1L},{0x4572090FL,0x69945C66L,9L,0x69945C66L,0x4572090FL,0xAA2DF500L,0x52276C1FL},{0L,(-1L),0x076B8492L,(-1L),1L,(-2L),0L},{(-7L),6L,(-1L),0L,2L,0x47684A57L,1L},{0x4ACDFF90L,(-1L),0L,0x3087C3CBL,0xCF50E4B4L,0x7429123EL,0x6DB3533BL},{0x114AC9FDL,1L,(-1L),0xCEBB36E9L,0x4ACDFF90L,0x20C5ABFEL,0x4572090FL}},{{0xCB1BEBA4L,7L,1L,0x20C5ABFEL,(-1L),2L,0x114AC9FDL},{1L,0xF5E69144L,1L,(-2L),0x6DB3533BL,(-1L),0xCEBB36E9L},{2L,1L,(-1L),(-8L),1L,(-8L),(-1L)},{0x330E0E3CL,0x330E0E3CL,0L,1L,(-4L),0L,6L},{0x076B8492L,0xDB4DBDF9L,(-1L),0xCB1BEBA4L,1L,0x69945C66L,0x47FCE3BAL},{0x20C5ABFEL,0x114AC9FDL,0x076B8492L,1L,(-4L),0xDB4DBDF9L,0L},{(-7L),0xAA2DF500L,(-8L),0x4572090FL,1L,(-1L),0xE048FFD5L},{1L,1L,1L,1L,0x6DB3533BL,0x4572090FL,0x4ACDFF90L}},{{(-1L),0x3087C3CBL,0L,0L,(-1L),0xE70E9EE1L,0x4ACDFF90L},{0x6DB3533BL,0L,0x69945C66L,2L,0x4ACDFF90L,1L,0xE048FFD5L},{0xEA6DE452L,0xCF50E4B4L,0x47FCE3BAL,0x47FCE3BAL,0xCF50E4B4L,0xEA6DE452L,0L},{0x851CC0D6L,0xCB1BEBA4L,1L,0xE048FFD5L,2L,7L,0x47FCE3BAL},{0x47FCE3BAL,0L,1L,0x69945C66L,1L,(-1L),6L},{0xAA2DF500L,0xCB1BEBA4L,0L,0x47684A57L,0x114AC9FDL,1L,(-1L)},{0x3087C3CBL,0xCF50E4B4L,0x7429123EL,0x6DB3533BL,0xF5E69144L,0L,0xCEBB36E9L},{(-8L),0L,0L,0x330E0E3CL,0xAA2DF500L,0x0B182BC9L,0x114AC9FDL}}};
    int16_t l_127 = 5L;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_14[i] = 0x1ABE8F21L;
lbl_158:
    if ((safe_lshift_func_uint16_t_u_s((+(func_5(((safe_rshift_func_uint8_t_u_u((safe_div_func_uint8_t_u_u((l_14[0] || g_15[0]), l_14[0])), 4)) < g_16), l_14[1], l_14[0], g_16) & l_14[1])), 7)))
    { /* block id: 23 */
        uint64_t l_43 = 18446744073709551606UL;
        g_35[0] = (func_5(g_35[0], l_14[1], g_16, g_16) == l_14[0]);
        --l_43;
        for (l_43 = 1; (l_43 <= 8); l_43 += 1)
        { /* block id: 28 */
            int i;
            return g_15[l_43];
        }
        for (l_43 = 2; (l_43 <= 6); l_43 += 1)
        { /* block id: 33 */
            int i;
            g_35[l_43] = func_46(g_35[l_43]);
            g_35[l_43] = (((safe_sub_func_uint64_t_u_u(((((safe_lshift_func_uint16_t_u_s(g_15[0], l_43)) , g_35[l_43]) ^ 0L) & l_43), l_42[1][6][2])) ^ l_127) == l_43);
            if (g_16)
                continue;
        }
    }
    else
    { /* block id: 75 */
        uint64_t l_128 = 1UL;
        int32_t l_129 = 0L;
        int32_t l_130 = 0x973355EAL;
        int32_t l_131[10][7][3] = {{{(-8L),(-8L),0L},{0x1EB29961L,(-1L),0L},{0L,(-8L),0L},{0x8E4492BDL,0x1EB29961L,(-2L)},{0xA7D1503DL,0L,0L},{(-2L),0x8E4492BDL,0L},{(-8L),0xA7D1503DL,0L}},{{(-2L),(-2L),7L},{0xA7D1503DL,(-8L),(-1L)},{0x8E4492BDL,(-2L),0x8E4492BDL},{0L,0xA7D1503DL,(-8L)},{0x1EB29961L,0x8E4492BDL,0x8E4492BDL},{(-8L),0L,(-1L)},{(-1L),0x1EB29961L,7L}},{{(-8L),(-8L),0L},{0x1EB29961L,(-1L),0L},{0L,(-8L),0L},{0x8E4492BDL,0x1EB29961L,0xE83F1017L},{0L,(-8L),(-8L)},{0xE83F1017L,(-1L),7L},{(-1L),0L,(-8L)}},{{0xE83F1017L,0xE83F1017L,(-2L)},{0L,(-1L),0L},{(-1L),0xE83F1017L,(-1L)},{(-8L),0L,(-10L)},{0x8E4492BDL,(-1L),(-1L)},{(-10L),(-8L),0L},{0L,0x8E4492BDL,(-2L)}},{{(-10L),(-10L),(-8L)},{0x8E4492BDL,0L,7L},{(-8L),(-10L),(-8L)},{(-1L),0x8E4492BDL,0xE83F1017L},{0L,(-8L),(-8L)},{0xE83F1017L,(-1L),7L},{(-1L),0L,(-8L)}},{{0xE83F1017L,0xE83F1017L,(-2L)},{0L,(-1L),0L},{(-1L),0xE83F1017L,(-1L)},{(-8L),0L,(-10L)},{0x8E4492BDL,(-1L),(-1L)},{(-10L),(-8L),0L},{0L,0x8E4492BDL,(-2L)}},{{(-10L),(-10L),(-8L)},{0x8E4492BDL,0L,7L},{(-8L),(-10L),(-8L)},{(-1L),0x8E4492BDL,0xE83F1017L},{0L,(-8L),(-8L)},{0xE83F1017L,(-1L),7L},{(-1L),0L,(-8L)}},{{0xE83F1017L,0xE83F1017L,(-2L)},{0L,(-1L),0L},{(-1L),0xE83F1017L,(-1L)},{(-8L),0L,(-10L)},{0x8E4492BDL,(-1L),(-1L)},{(-10L),(-8L),0L},{0L,0x8E4492BDL,(-2L)}},{{(-10L),(-10L),(-8L)},{0x8E4492BDL,0L,7L},{(-8L),(-10L),(-8L)},{(-1L),0x8E4492BDL,0xE83F1017L},{0L,(-8L),(-8L)},{0xE83F1017L,(-1L),7L},{(-1L),0L,(-8L)}},{{0xE83F1017L,0xE83F1017L,(-2L)},{0L,(-1L),0L},{(-1L),0xE83F1017L,(-1L)},{(-8L),0L,(-10L)},{0x8E4492BDL,(-1L),(-1L)},{(-10L),(-8L),0L},{0L,0x8E4492BDL,(-2L)}}};
        uint32_t l_132[10] = {0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L,0x727989E9L};
        int i, j, k;
        l_42[1][6][2] = (l_128 != l_128);
        l_132[5]--;
        for (l_128 = 0; (l_128 != 25); ++l_128)
        { /* block id: 80 */
            g_35[0] = ((((((!((g_35[0] == g_16) ^ l_128)) ^ l_129) ^ l_42[1][6][2]) >= l_132[5]) & 1UL) > 1UL);
            return g_84;
        }
        l_131[4][3][1] = ((safe_mul_func_int16_t_s_s(((l_131[4][3][1] , g_15[6]) && l_131[4][3][1]), g_84)) > 0xA37D6F5CED9F99F9LL);
    }
    if ((safe_mul_func_uint8_t_u_u(g_16, 0x35L)))
    { /* block id: 86 */
        int16_t l_147[5];
        int32_t l_153 = 1L;
        int i;
        for (i = 0; i < 5; i++)
            l_147[i] = (-3L);
        for (g_84 = 0; (g_84 > (-19)); g_84 = safe_sub_func_uint64_t_u_u(g_84, 7))
        { /* block id: 89 */
            int64_t l_146 = 0xF27C866F7BE154AALL;
            g_35[0] = (safe_add_func_int8_t_s_s(l_146, g_16));
            g_35[0] = ((((g_35[0] && l_147[4]) , 0x2CL) || l_147[4]) , g_15[2]);
        }
        for (l_127 = (-14); (l_127 < 6); l_127 = safe_add_func_uint8_t_u_u(l_127, 8))
        { /* block id: 95 */
            uint32_t l_154 = 18446744073709551613UL;
            int32_t l_155 = (-7L);
            g_35[1] = (((safe_mod_func_uint16_t_u_u((((+(g_35[2] && g_15[4])) != l_127) ^ 0xDFB7L), 0x672EL)) && g_15[0]) > l_153);
            l_155 = (l_154 == g_35[0]);
            l_153 |= ((+(safe_unary_minus_func_uint16_t_u((((g_35[0] && l_154) && g_15[5]) || 4294967290UL)))) , g_35[1]);
        }
        if (g_84)
            goto lbl_158;
    }
    else
    { /* block id: 101 */
        uint32_t l_172[3];
        int32_t l_175[6][7] = {{6L,(-1L),1L,0x72D96CCFL,0xA08BE86FL,0xEFE984A7L,0xA08BE86FL},{0x64D1AD4BL,0L,0L,0x64D1AD4BL,1L,0xC2882C14L,0x074757F8L},{0x64D1AD4BL,0xEFE984A7L,7L,(-1L),0x86BBE6D2L,0xF789EDA7L,0x67E5A97EL},{6L,1L,0xDBDCA493L,7L,6L,7L,0xDBDCA493L},{6L,6L,0x86BBE6D2L,0L,1L,7L,0x67E5A97EL},{0xA08BE86FL,0x86BBE6D2L,0x67E5A97EL,1L,0L,1L,(-1L)}};
        int i, j;
        for (i = 0; i < 3; i++)
            l_172[i] = 18446744073709551611UL;
        g_35[0] = (safe_unary_minus_func_int8_t_s((((safe_add_func_uint32_t_u_u((((safe_lshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s((+((~((safe_mul_func_uint8_t_u_u(((safe_sub_func_int16_t_s_s(0L, l_14[0])) < 255UL), l_172[0])) <= 4UL)) ^ 0x5A8AL)), g_15[0])), g_84)) , 0UL) && l_127), g_16)) == g_84) >= l_172[0])));
        for (g_84 = 8; (g_84 < 9); ++g_84)
        { /* block id: 105 */
            l_175[0][6] = (0xF20DE4EAL != 4294967294UL);
        }
    }
    for (l_127 = 0; (l_127 < 5); l_127 = safe_add_func_int8_t_s_s(l_127, 7))
    { /* block id: 111 */
        uint8_t l_181 = 3UL;
        int32_t l_184 = 1L;
        int32_t l_185 = 7L;
        int32_t l_187 = 0x27BEDC86L;
        int32_t l_188 = 0xCE2D081CL;
        int32_t l_189 = 0x833FD889L;
        int32_t l_190[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
        uint8_t l_191 = 4UL;
        int i;
        for (g_84 = (-1); (g_84 < (-1)); ++g_84)
        { /* block id: 114 */
            uint32_t l_180 = 0x327B0E3EL;
            int32_t l_186[7];
            int i;
            for (i = 0; i < 7; i++)
                l_186[i] = (-6L);
            l_180 = 0x1B115D80L;
            l_181++;
            --l_191;
            return g_84;
        }
    }
    return l_42[2][4][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_35
 * writes: g_35 g_15
 */
static uint16_t  func_5(uint32_t  p_6, int32_t  p_7, uint64_t  p_8, int16_t  p_9)
{ /* block id: 1 */
    int8_t l_32 = 8L;
    int32_t l_39 = (-9L);
    l_39 |= ((safe_mod_func_int8_t_s_s((safe_div_func_int8_t_s_s((safe_unary_minus_func_uint8_t_u(func_22(func_26((safe_div_func_int16_t_s_s(p_7, l_32)), p_8, p_6), g_16, l_32))), g_16)), (-8L))) , p_8);
    l_39 ^= ((safe_lshift_func_int16_t_s_s((g_15[0] <= p_9), g_16)) , g_35[0]);
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_35 g_16
 * writes: g_35 g_15
 */
static uint8_t  func_22(int64_t  p_23, int8_t  p_24, int8_t  p_25)
{ /* block id: 4 */
    uint32_t l_36 = 0x0B91300DL;
    for (p_25 = (-9); (p_25 > 24); p_25++)
    { /* block id: 7 */
        g_35[0] = g_15[8];
        for (p_24 = 4; (p_24 >= 2); p_24 -= 1)
        { /* block id: 11 */
            int i;
            if (g_35[p_24])
                break;
            g_35[p_24] = ((g_16 ^ g_16) , g_15[1]);
            g_35[p_24] = func_26((p_24 , g_35[2]), p_23, p_25);
        }
    }
    l_36++;
    for (p_24 = 0; p_24 < 9; p_24 += 1)
    {
        g_15[p_24] = 0x481DL;
    }
    return l_36;
}


/* ------------------------------------------ */
/* 
 * reads : g_15
 * writes:
 */
static int64_t  func_26(uint8_t  p_27, int32_t  p_28, int32_t  p_29)
{ /* block id: 2 */
    return g_15[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_35 g_84
 * writes: g_35
 */
static const int32_t  func_46(uint16_t  p_47)
{ /* block id: 34 */
    int32_t l_56[6][7];
    uint64_t l_70[2];
    int8_t l_82 = 0x60L;
    int32_t l_83 = 4L;
    int8_t l_85 = 0xF5L;
    uint32_t l_86 = 18446744073709551606UL;
    uint32_t l_99 = 18446744073709551609UL;
    int i, j;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
            l_56[i][j] = 0xC00EEBEBL;
    }
    for (i = 0; i < 2; i++)
        l_70[i] = 0x7C2A8B70F5D9662ALL;
    l_56[5][5] = (safe_mod_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((safe_div_func_int8_t_s_s((safe_add_func_uint64_t_u_u((p_47 <= g_15[0]), g_16)), g_16)), p_47)), g_16));
    if (((((safe_mod_func_uint8_t_u_u(((safe_add_func_int32_t_s_s(((((l_56[5][5] , p_47) , g_15[0]) <= g_16) ^ p_47), 0xEF4C8A73L)) ^ g_16), g_16)) >= 0x2FC9DABCL) || g_16) < g_16))
    { /* block id: 36 */
        uint32_t l_63 = 0x45EA776AL;
        int32_t l_67 = 0x97E00C18L;
        int32_t l_68 = 0xA74E9983L;
        int32_t l_69 = 0x0B0F3EF2L;
        uint32_t l_75[6] = {0x38F51712L,0x38F51712L,0xCEB8AB48L,0x38F51712L,0x38F51712L,0xCEB8AB48L};
        int16_t l_78[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
        int32_t l_79 = (-1L);
        int32_t l_80 = 0x9D6528A1L;
        int32_t l_81[7][8][4] = {{{2L,2L,1L,0x8BB49DA0L},{7L,0L,0x7136C1A4L,0x835E00E1L},{0x8BB49DA0L,0L,0xB40075A6L,0x7136C1A4L},{1L,0L,0x38CF3A2AL,0x835E00E1L},{0L,0L,0L,0x8BB49DA0L},{0xDB3BF0D0L,2L,0x6F33C057L,(-7L)},{0xB40075A6L,0L,(-10L),8L},{0x6F33C057L,(-7L),0x3BFA5964L,(-7L)}},{{0x7136C1A4L,0x8BB49DA0L,8L,0L},{0x608F1A9DL,8L,0x012C46B2L,0x1C3794E4L},{(-7L),0x38CF3A2AL,1L,2L},{(-7L),(-10L),0x012C46B2L,1L},{0x608F1A9DL,2L,8L,0L},{0x7136C1A4L,7L,0x3BFA5964L,(-10L)},{0x6F33C057L,0x012C46B2L,(-10L),0xB9A30548L},{0xB40075A6L,0x6F33C057L,0x6F33C057L,0xB40075A6L}},{{0xDB3BF0D0L,0x835E00E1L,0L,0x9DB6AB31L},{0L,(-8L),0x38CF3A2AL,(-5L)},{1L,(-10L),0xB40075A6L,(-5L)},{0x8BB49DA0L,(-8L),0x7136C1A4L,0x9DB6AB31L},{7L,0x835E00E1L,1L,0xB40075A6L},{2L,0x6F33C057L,(-7L),0xB9A30548L},{2L,0x012C46B2L,0x835E00E1L,(-10L)},{0x3E4B84AAL,7L,0x3E4B84AAL,0L}},{{0x3BFA5964L,2L,7L,1L},{0x1C3794E4L,(-10L),0xB9A30548L,2L},{0L,0x38CF3A2AL,0xB9A30548L,0x1C3794E4L},{0x1C3794E4L,8L,7L,0L},{0x3BFA5964L,0x8BB49DA0L,0x3E4B84AAL,(-7L)},{0x3E4B84AAL,(-7L),0x835E00E1L,8L},{2L,0L,(-7L),(-7L)},{2L,2L,1L,0x8BB49DA0L}},{{7L,0L,0x7136C1A4L,0x835E00E1L},{0x8BB49DA0L,0L,0xB40075A6L,0x7136C1A4L},{1L,0L,0x38CF3A2AL,0x835E00E1L},{0L,0L,0L,0x8BB49DA0L},{0xDB3BF0D0L,2L,0x6F33C057L,(-7L)},{0xB40075A6L,0L,(-10L),8L},{0x6F33C057L,0L,0x012C46B2L,0L},{(-7L),0x608F1A9DL,(-5L),(-10L)}},{{1L,(-5L),0L,0x9DB6AB31L},{0L,7L,0x8BB49DA0L,(-7L)},{0L,0L,0L,2L},{1L,(-7L),(-5L),0x38CF3A2AL},{(-7L),0xB40075A6L,0x012C46B2L,0xB9A30548L},{(-8L),0L,0xB9A30548L,1L},{0x6F33C057L,(-8L),(-8L),0x6F33C057L},{8L,0xDB3BF0D0L,(-7L),2L}},{{(-10L),0x3BFA5964L,7L,0x7136C1A4L},{2L,0xB9A30548L,0x6F33C057L,0x7136C1A4L},{0x608F1A9DL,0x3BFA5964L,(-7L),2L},{0xB40075A6L,0xDB3BF0D0L,2L,0x6F33C057L},{0L,(-8L),0x835E00E1L,1L},{(-7L),0L,0xDB3BF0D0L,0xB9A30548L},{0x1C3794E4L,0xB40075A6L,0x1C3794E4L,0x38CF3A2AL},{0x012C46B2L,(-7L),0xB40075A6L,2L}}};
        int i, j, k;
        l_63 &= (safe_mul_func_int16_t_s_s((p_47 != p_47), g_15[4]));
        l_56[5][4] = g_35[1];
        for (p_47 = (-23); (p_47 <= 1); p_47++)
        { /* block id: 41 */
            int16_t l_66 = 9L;
            int32_t l_73 = (-3L);
            int32_t l_74[6][10] = {{9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL,9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL},{9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL,9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL},{9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL,9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL},{9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL,9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL},{9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL,9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL},{9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL,9L,9L,0xC6E3A6DCL,0xBC2A5DE2L,0xC6E3A6DCL}};
            int i, j;
            ++l_70[0];
            l_75[1]++;
            l_86--;
            l_74[4][4] = (safe_add_func_int32_t_s_s(((safe_div_func_uint64_t_u_u(((safe_add_func_int64_t_s_s((safe_add_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u(((0x5DE960EC7AF4A409LL || l_99) ^ g_35[1]), p_47)), 4294967287UL)), p_47)) <= 0x9DA6L), 18446744073709551608UL)) < p_47), g_84));
        }
        g_35[0] = (safe_rshift_func_uint8_t_u_u(((((l_81[4][6][1] > 18446744073709551610UL) , p_47) & 0x7DAF6EE45795A903LL) < 0x06L), g_16));
    }
    else
    { /* block id: 48 */
        uint32_t l_106[2];
        int32_t l_107 = 0xA5DFAD9AL;
        int32_t l_108[7] = {2L,2L,2L,2L,2L,2L,2L};
        int i;
        for (i = 0; i < 2; i++)
            l_106[i] = 7UL;
        if (((safe_mod_func_int8_t_s_s(p_47, g_15[3])) > p_47))
        { /* block id: 49 */
            l_83 ^= (((((safe_div_func_uint64_t_u_u(((3UL <= 18446744073709551615UL) | g_15[6]), l_106[1])) & 0x20EFL) && p_47) > p_47) && 0x3FL);
            return g_16;
        }
        else
        { /* block id: 52 */
            uint16_t l_109[9];
            int i;
            for (i = 0; i < 9; i++)
                l_109[i] = 0x6B7EL;
            l_109[3]--;
            return l_83;
        }
    }
    for (p_47 = 2; (p_47 <= 8); p_47 += 1)
    { /* block id: 59 */
        uint32_t l_112 = 0xB6D27D1EL;
        int32_t l_122 = 0x6940D3DBL;
        l_112++;
        for (l_82 = 0; (l_82 <= 8); l_82 += 1)
        { /* block id: 63 */
            const int32_t l_119 = (-1L);
            int i;
            l_56[5][5] = ((safe_sub_func_int8_t_s_s((((safe_div_func_int8_t_s_s((1L >= g_15[p_47]), g_16)) ^ 0x0DC5A684D056A74CLL) != l_119), p_47)) > l_119);
            l_122 = ((((safe_sub_func_uint8_t_u_u(l_119, l_85)) | g_35[0]) , l_119) == p_47);
            g_35[0] = p_47;
            return g_16;
        }
    }
    return p_47;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_15[i], "g_15[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_35[i], "g_35[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_84, "g_84", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 59
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 67
   depth: 2, occurrence: 19
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 5
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 3
   depth: 10, occurrence: 1
   depth: 11, occurrence: 3
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 117
XXX times a non-volatile is write: 38
XXX times a volatile is read: 34
XXX    times read thru a pointer: 0
XXX times a volatile is write: 13
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 161
XXX percentage of non-volatile access: 76.7

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 70
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 23
   depth: 2, occurrence: 31

XXX percentage a fresh-made variable is used: 14
XXX percentage an existing variable is used: 86
********************* end of statistics **********************/

