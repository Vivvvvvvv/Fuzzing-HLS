/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      999122164372497821
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x82062403L;
static int32_t g_25 = 2L;
static int32_t g_26[10] = {1L,(-9L),0x667F5AEEL,0x667F5AEEL,(-9L),1L,(-9L),0x667F5AEEL,0x667F5AEEL,(-9L)};
static int32_t g_30 = 0x2DC6D0F0L;
static volatile uint32_t g_31 = 1UL;/* VOLATILE GLOBAL g_31 */
static volatile uint32_t g_51 = 18446744073709551615UL;/* VOLATILE GLOBAL g_51 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_9(uint8_t  p_10, const int32_t  p_11, int32_t  p_12);
static int32_t  func_17(int8_t  p_18, uint8_t  p_19);
static int32_t  func_34(const int32_t  p_35, int16_t  p_36, int16_t  p_37, const uint16_t  p_38);
static int32_t  func_54(int32_t  p_55, int32_t  p_56, int64_t  p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_31 g_26 g_25 g_51 g_30
 * writes: g_2 g_31 g_30 g_26 g_51
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_5 = 18446744073709551615UL;
    int32_t l_67 = 0xF85A0455L;
    for (g_2 = 29; (g_2 > (-8)); g_2 = safe_sub_func_int64_t_s_s(g_2, 4))
    { /* block id: 3 */
        uint64_t l_15 = 1UL;
        uint32_t l_16[2];
        int i;
        for (i = 0; i < 2; i++)
            l_16[i] = 1UL;
        if ((l_5 >= 0xE0L))
        { /* block id: 4 */
            uint32_t l_6 = 18446744073709551615UL;
            l_6++;
        }
        else
        { /* block id: 6 */
            l_15 = func_9((safe_mod_func_int8_t_s_s(0xE3L, g_2)), g_2, l_5);
            if (l_16[0])
                break;
            if (l_5)
                break;
        }
        if (func_17((g_2 , 0x6FL), g_2))
        { /* block id: 31 */
            g_30 = (g_2 <= 6L);
            if (g_26[2])
                break;
        }
        else
        { /* block id: 34 */
            int32_t l_49 = 0x6A6D983AL;
            int32_t l_50 = 0xEB8A064FL;
            g_51--;
        }
    }
    l_67 = func_54(((safe_mod_func_uint32_t_u_u((safe_sub_func_int64_t_s_s((((safe_mod_func_int32_t_s_s((g_25 || 0xFFL), l_5)) || 0x32111C1BL) && 1UL), l_5)), g_30)) <= g_26[0]), g_2, l_5);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_9(uint8_t  p_10, const int32_t  p_11, int32_t  p_12)
{ /* block id: 7 */
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_26 g_2 g_25
 * writes: g_31 g_30 g_26
 */
static int32_t  func_17(int8_t  p_18, uint8_t  p_19)
{ /* block id: 13 */
    int32_t l_22 = 0xB9193C1DL;
    int32_t l_24 = 0L;
    int32_t l_28 = 0x41791E6EL;
    int32_t l_29 = 4L;
    int64_t l_39 = 5L;
    for (p_19 = 25; (p_19 < 5); p_19 = safe_sub_func_int64_t_s_s(p_19, 3))
    { /* block id: 16 */
        int32_t l_23[6][6];
        int32_t l_27 = 0L;
        int i, j;
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 6; j++)
                l_23[i][j] = 0x8B922806L;
        }
        ++g_31;
        if (func_34((((func_9(l_39, g_26[1], g_26[0]) , 18446744073709551615UL) , g_2) != g_26[5]), p_19, l_24, p_18))
        { /* block id: 21 */
            l_27 = (safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_s(func_9(g_26[3], g_25, g_31), 7)), 1));
            l_27 = p_18;
        }
        else
        { /* block id: 24 */
            return p_18;
        }
        if (g_26[0])
            continue;
    }
    l_28 = func_9((safe_div_func_int16_t_s_s((safe_sub_func_uint64_t_u_u(l_28, p_19)), (-1L))), g_26[0], l_29);
    return g_31;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_30 g_26
 */
static int32_t  func_34(const int32_t  p_35, int16_t  p_36, int16_t  p_37, const uint16_t  p_38)
{ /* block id: 18 */
    uint8_t l_40 = 255UL;
    for (g_30 = 0; g_30 < 10; g_30 += 1)
    {
        g_26[g_30] = 0xA9E1A0E1L;
    }
    return l_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_30 g_25 g_2
 * writes: g_2
 */
static int32_t  func_54(int32_t  p_55, int32_t  p_56, int64_t  p_57)
{ /* block id: 38 */
    uint32_t l_66 = 1UL;
    g_2 &= (safe_lshift_func_uint8_t_u_u(((g_30 , p_57) == g_25), l_66));
    return g_25;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_26[i], "g_26[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 21
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 11, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 44
XXX times a non-volatile is write: 10
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 93.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 5
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 30.9
XXX percentage an existing variable is used: 69.1
********************* end of statistics **********************/

