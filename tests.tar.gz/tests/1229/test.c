/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      442952211592847187
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 1L;
static uint16_t g_18 = 0x7136L;
static int16_t g_56 = 0L;
static volatile uint64_t g_61[6][4] = {{18446744073709551615UL,0x26829A6E4C1C17FALL,18446744073709551615UL,18446744073709551615UL},{0x26829A6E4C1C17FALL,0x26829A6E4C1C17FALL,18446744073709551608UL,0x26829A6E4C1C17FALL},{0x26829A6E4C1C17FALL,18446744073709551615UL,18446744073709551615UL,0x26829A6E4C1C17FALL},{18446744073709551615UL,0x26829A6E4C1C17FALL,18446744073709551615UL,18446744073709551615UL},{0x26829A6E4C1C17FALL,0x26829A6E4C1C17FALL,18446744073709551608UL,0x26829A6E4C1C17FALL},{0x26829A6E4C1C17FALL,18446744073709551615UL,18446744073709551615UL,0x26829A6E4C1C17FALL}};
static int32_t g_65 = 0L;
static int32_t g_81 = 0xC6F70768L;
static int64_t g_88[5][8] = {{9L,9L,0x9E8DF01DDAC0D4F8LL,1L,0x9E8DF01DDAC0D4F8LL,9L,9L,0x9E8DF01DDAC0D4F8LL},{(-1L),0x9E8DF01DDAC0D4F8LL,0x9E8DF01DDAC0D4F8LL,(-1L),(-2L),(-1L),0x9E8DF01DDAC0D4F8LL,0x9E8DF01DDAC0D4F8LL},{0x9E8DF01DDAC0D4F8LL,(-2L),1L,1L,(-2L),0x9E8DF01DDAC0D4F8LL,9L,(-2L)},{1L,9L,1L,(-1L),(-1L),1L,9L,1L},{0x9E8DF01DDAC0D4F8LL,(-1L),(-2L),(-1L),0x9E8DF01DDAC0D4F8LL,0x9E8DF01DDAC0D4F8LL,(-1L),(-2L)}};
static uint16_t g_94 = 65528UL;
static int32_t g_102[6][8] = {{0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L},{0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L},{0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L},{0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L},{0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L},{0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L,0xD9459313L}};
static volatile int16_t g_103 = 5L;/* VOLATILE GLOBAL g_103 */
static uint64_t g_104 = 18446744073709551606UL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_8(int64_t  p_9, int32_t  p_10, int16_t  p_11, int32_t  p_12);
static int32_t  func_26(int8_t  p_27);
static int16_t  func_35(int64_t  p_36);
static int64_t  func_37(int32_t  p_38, int8_t  p_39, int64_t  p_40, uint32_t  p_41);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_18 g_56 g_61 g_65 g_94 g_88 g_81 g_104
 * writes: g_3 g_18 g_56 g_61 g_65 g_94 g_81 g_104
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2[2][1];
    int32_t l_101 = 0xFB111D03L;
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
            l_2[i][j] = (-1L);
    }
    for (g_3 = 0; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        int64_t l_6 = (-4L);
        int32_t l_7 = (-1L);
        int32_t l_98[1][10] = {{0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L,0x5F2429B4L}};
        int i, j;
        l_7 &= (safe_add_func_int32_t_s_s(0xA485BF25L, l_6));
        for (l_7 = 0; (l_7 >= 0); l_7 -= 1)
        { /* block id: 7 */
            int32_t l_25 = 4L;
            int i, j;
            l_25 = func_8(l_2[(g_3 + 1)][l_7], g_3, g_3, l_2[0][0]);
            if (l_6)
                continue;
            if (g_3)
                break;
            l_98[0][8] = func_26(g_18);
        }
        if (g_3)
            break;
        for (g_81 = 0; (g_81 <= 0); g_81 += 1)
        { /* block id: 78 */
            int i, j;
            g_65 &= ((safe_div_func_int16_t_s_s(0x80D1L, l_2[(g_3 + 1)][g_3])) == l_2[(g_3 + 1)][g_3]);
            g_104--;
        }
    }
    return l_101;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_18
 * writes: g_18
 */
static int32_t  func_8(int64_t  p_9, int32_t  p_10, int16_t  p_11, int32_t  p_12)
{ /* block id: 8 */
    uint32_t l_23 = 0x017F215AL;
    int32_t l_24[2][1][9];
    int i, j, k;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 9; k++)
                l_24[i][j][k] = 1L;
        }
    }
    for (p_10 = 0; (p_10 < 1); p_10++)
    { /* block id: 11 */
        uint32_t l_16 = 1UL;
        int32_t l_17 = (-1L);
        if ((~(((p_11 < g_3) != g_3) > p_11)))
        { /* block id: 12 */
            l_16 = p_10;
        }
        else
        { /* block id: 14 */
            ++g_18;
        }
        l_23 &= (safe_sub_func_int8_t_s_s(p_10, p_11));
    }
    l_24[0][0][8] ^= ((p_11 != g_3) > 0x01D933BDL);
    return p_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_18 g_56 g_61 g_65 g_94 g_88
 * writes: g_18 g_56 g_61 g_65 g_94
 */
static int32_t  func_26(int8_t  p_27)
{ /* block id: 24 */
    uint16_t l_30 = 0x8CA0L;
    int32_t l_97 = (-1L);
    for (p_27 = 0; (p_27 != (-11)); --p_27)
    { /* block id: 27 */
        l_30 = (-4L);
    }
    l_97 |= (safe_lshift_func_uint16_t_u_s((safe_mul_func_int16_t_s_s(func_35(p_27), g_88[3][4])), g_88[2][5]));
    return l_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_18 g_56 g_61 g_65 g_94
 * writes: g_18 g_56 g_61 g_65 g_94
 */
static int16_t  func_35(int64_t  p_36)
{ /* block id: 30 */
    uint64_t l_46[10] = {0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL,0x5ABA8D6E8597A0B8LL};
    int32_t l_59 = 0x913DB3B8L;
    int32_t l_82 = (-6L);
    int32_t l_83 = 0L;
    int32_t l_84 = (-1L);
    int32_t l_85 = 1L;
    int32_t l_86 = 0x2ED69965L;
    int32_t l_87 = 0L;
    int32_t l_89 = (-1L);
    int32_t l_90 = 0xF0966AB1L;
    int32_t l_91 = 0x01CA4970L;
    int32_t l_92 = 0L;
    int32_t l_93 = 0L;
    int i;
    if (func_8(func_37(((safe_mod_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(255UL, 6)), l_46[6])) >= p_36), g_3, p_36, l_46[8]), p_36, g_3, l_46[6]))
    { /* block id: 33 */
        uint32_t l_55[5][10] = {{0xE4D7D9C7L,0xF9DEAB2DL,0x474C77A5L,0xB08F18E0L,18446744073709551615UL,0xE37A2E34L,0x5E148CB4L,0x8003DBE6L,4UL,0x8003DBE6L},{0xB08F18E0L,0x8003DBE6L,0x474C77A5L,18446744073709551615UL,0x474C77A5L,0x8003DBE6L,0xB08F18E0L,0UL,0x916C6C9AL,0x0FB9C0D2L},{18446744073709551611UL,0x90B51ECDL,0x916C6C9AL,0xDBCC772AL,0x5E148CB4L,0x474C77A5L,0UL,0xF9DEAB2DL,0xF9DEAB2DL,0UL},{4UL,0x90B51ECDL,0UL,0UL,0x90B51ECDL,4UL,0xB08F18E0L,0x0FB9C0D2L,0UL,0x474C77A5L},{0x0FB9C0D2L,0x8003DBE6L,0xE37A2E34L,4UL,0xDBCC772AL,0xE4D7D9C7L,0x5E148CB4L,0x916C6C9AL,0x5E148CB4L,0xE4D7D9C7L}};
        int32_t l_60 = (-1L);
        uint16_t l_66 = 0xE8BCL;
        uint16_t l_68 = 0xDA77L;
        int i, j;
        g_56 ^= ((((safe_div_func_int16_t_s_s(((safe_sub_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((((safe_mod_func_int64_t_s_s((((0xC3L != l_46[3]) , (-1L)) && 0L), l_55[0][4])) , 0xD067L) <= g_18) | g_3), 2)), p_36)) > p_36), l_46[6])) , 0x1DBC5514L) , g_3) & p_36);
        for (g_56 = 0; (g_56 > (-22)); g_56 = safe_sub_func_uint8_t_u_u(g_56, 8))
        { /* block id: 37 */
            if (p_36)
                break;
            l_59 |= (0xFB828C20713981DCLL && l_55[4][8]);
            if (g_18)
                break;
            l_60 |= p_36;
        }
        if (l_59)
            goto lbl_67;
        for (p_36 = 4; (p_36 >= 0); p_36 -= 1)
        { /* block id: 45 */
            int8_t l_64 = (-5L);
            --g_61[3][2];
            l_64 = (0L >= 0x97L);
            g_65 &= p_36;
        }
        if (g_18)
        { /* block id: 50 */
            l_60 ^= (l_55[0][4] ^ l_66);
            l_60 |= (l_59 & 0x69L);
        }
        else
        { /* block id: 53 */
lbl_67:
            l_60 = 0x80B7F2DBL;
            l_68 ^= p_36;
            g_65 = (safe_div_func_int8_t_s_s((p_36 || l_59), 0x5DL));
        }
    }
    else
    { /* block id: 59 */
        int32_t l_80[2][2] = {{9L,9L},{9L,9L}};
        int i, j;
        for (g_18 = 10; (g_18 >= 5); --g_18)
        { /* block id: 62 */
            const uint16_t l_79 = 3UL;
            g_65 &= ((safe_div_func_int32_t_s_s((safe_div_func_uint16_t_u_u(((safe_sub_func_int64_t_s_s(1L, 0x87144B05ACF7E1B1LL)) , g_18), 0x9BCCL)), p_36)) <= g_61[3][2]);
            l_80[1][1] |= l_79;
            if (g_65)
                break;
        }
    }
    l_59 = (p_36 & g_65);
    --g_94;
    return l_82;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int64_t  func_37(int32_t  p_38, int8_t  p_39, int64_t  p_40, uint32_t  p_41)
{ /* block id: 31 */
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_61[i][j], "g_61[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_88[i][j], "g_88[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_94, "g_94", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_102[i][j], "g_102[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_104, "g_104", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 41
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 50
   depth: 2, occurrence: 16
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 12, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 71
XXX times a non-volatile is write: 33
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 98.1

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 49
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 13
   depth: 2, occurrence: 23

XXX percentage a fresh-made variable is used: 37.3
XXX percentage an existing variable is used: 62.7
********************* end of statistics **********************/

