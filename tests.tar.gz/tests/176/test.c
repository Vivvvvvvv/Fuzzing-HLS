/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11725232428482730454
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int16_t g_15 = 0xA012L;/* VOLATILE GLOBAL g_15 */
static uint16_t g_16 = 0xDF82L;
static int32_t g_32[2][3] = {{0xC0A9C5A7L,0xC0A9C5A7L,0xC0A9C5A7L},{0xB26D8F9CL,0xB26D8F9CL,0xB26D8F9CL}};
static volatile int32_t g_33 = 0x342BB1E5L;/* VOLATILE GLOBAL g_33 */
static uint32_t g_38 = 0x18C6A866L;
static int8_t g_41 = 1L;
static int32_t g_45 = 0x7203FCA5L;
static volatile int32_t g_62 = 0x49ED226FL;/* VOLATILE GLOBAL g_62 */
static volatile uint64_t g_63 = 0xC93506F8A133A5B7LL;/* VOLATILE GLOBAL g_63 */
static int32_t g_75 = 0xC43CAE23L;
static volatile uint16_t g_83 = 0xD4ADL;/* VOLATILE GLOBAL g_83 */
static volatile uint8_t g_87 = 0x25L;/* VOLATILE GLOBAL g_87 */
static volatile uint32_t g_91 = 4UL;/* VOLATILE GLOBAL g_91 */
static uint8_t g_124 = 0UL;
static volatile uint32_t g_133 = 0xBE1421AAL;/* VOLATILE GLOBAL g_133 */
static volatile int8_t g_142 = (-1L);/* VOLATILE GLOBAL g_142 */
static uint64_t g_147 = 18446744073709551615UL;
static int8_t g_161 = (-6L);
static uint64_t g_162 = 0x4804F9BF6F6D5B12LL;
static volatile uint64_t g_193 = 18446744073709551615UL;/* VOLATILE GLOBAL g_193 */
static uint16_t g_254 = 0x2D10L;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint16_t  func_4(int32_t  p_5, int64_t  p_6);
static int32_t  func_22(int16_t  p_23, uint8_t  p_24, int8_t  p_25, uint64_t  p_26);
static int16_t  func_27(int32_t  p_28, uint32_t  p_29, uint32_t  p_30, uint32_t  p_31);
static int32_t  func_49(uint64_t  p_50);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_38 g_45 g_33 g_63 g_83 g_87 g_91 g_41 g_75 g_32 g_124 g_133 g_147 g_162 g_161 g_193 g_62 g_142 g_254
 * writes: g_38 g_41 g_45 g_63 g_62 g_83 g_87 g_91 g_75 g_124 g_133 g_147 g_162 g_193 g_254
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_221[2][6] = {{0xFD0AL,4L,(-1L),4L,0xFD0AL,0xFD0AL},{(-5L),4L,4L,(-5L),0L,(-5L)}};
    int32_t l_222 = (-6L);
    int8_t l_235 = (-1L);
    int32_t l_249 = 0xB25B9800L;
    uint64_t l_263 = 0UL;
    int i, j;
    l_222 = ((((safe_lshift_func_uint16_t_u_s(func_4((safe_div_func_int64_t_s_s((((safe_lshift_func_uint8_t_u_s((safe_rshift_func_uint8_t_u_s((safe_lshift_func_int8_t_s_s(g_15, 1)), g_16)), 0)) > 0x98L) , g_15), g_16)), g_16), 11)) <= l_221[0][1]) > g_16) , l_221[0][1]);
    for (g_75 = 7; (g_75 != (-16)); g_75 = safe_sub_func_uint64_t_u_u(g_75, 1))
    { /* block id: 138 */
        int16_t l_225 = 0xEB74L;
        uint32_t l_231 = 0x98A15B14L;
        int32_t l_232[1];
        int64_t l_248 = 0xD5EE618692B30807LL;
        int i;
        for (i = 0; i < 1; i++)
            l_232[i] = 0x6CBBA219L;
        if (((l_221[0][1] , l_225) , (-1L)))
        { /* block id: 139 */
            uint16_t l_230 = 0x3522L;
            l_232[0] |= ((((safe_rshift_func_int16_t_s_s((safe_div_func_uint32_t_u_u((l_230 , g_38), l_225)), g_147)) < l_231) & l_221[1][3]) != 0x74089B9487569931LL);
            g_62 = l_230;
            g_45 ^= g_162;
        }
        else
        { /* block id: 143 */
            int32_t l_236 = 0x1AEA985DL;
            l_236 = (((safe_lshift_func_int16_t_s_u(l_231, l_235)) | 255UL) ^ 0L);
            g_45 = ((safe_mod_func_uint64_t_u_u(g_142, 0xAA199BFBAFD8273ALL)) && l_235);
            g_62 = g_87;
        }
        l_249 = (safe_div_func_uint32_t_u_u((safe_mod_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((safe_lshift_func_int16_t_s_u(((+l_221[1][4]) == 0x5EL), 3)) ^ 1UL), g_124)), l_231)), l_248));
        if (g_83)
            break;
    }
    for (g_162 = (-20); (g_162 >= 52); g_162++)
    { /* block id: 153 */
        int8_t l_252 = 2L;
        int32_t l_253[4][10] = {{1L,0x0E5491D3L,1L,1L,0x0E5491D3L,1L,1L,0x0E5491D3L,1L,1L},{0x0E5491D3L,0x0E5491D3L,0x4C72F990L,0x0E5491D3L,0x0E5491D3L,0x4C72F990L,0x0E5491D3L,0x0E5491D3L,0x4C72F990L,0x0E5491D3L},{0x0E5491D3L,1L,1L,0x0E5491D3L,1L,1L,0x0E5491D3L,1L,0x4C72F990L,1L},{0x4C72F990L,1L,0x4C72F990L,0x4C72F990L,1L,0x4C72F990L,0x4C72F990L,1L,0x4C72F990L,0x4C72F990L}};
        int i, j;
        l_252 = (g_16 && 0x45770A46L);
        l_253[3][8] = (-1L);
    }
    for (g_124 = 0; (g_124 <= 1); g_124 += 1)
    { /* block id: 159 */
        int32_t l_260 = 0L;
        if (g_142)
        { /* block id: 160 */
            uint8_t l_257 = 1UL;
            g_254--;
            if (l_257)
                continue;
        }
        else
        { /* block id: 163 */
            g_45 = (((((safe_sub_func_int64_t_s_s((((g_162 == 0x013EDC32L) ^ 0xCA0AL) > 0L), l_260)) | 18446744073709551615UL) < g_32[0][1]) > l_235) || g_133);
            if (g_161)
                continue;
            if (g_63)
                break;
        }
        for (l_249 = 1; (l_249 >= 0); l_249 -= 1)
        { /* block id: 170 */
            int i, j;
            g_62 = (safe_lshift_func_int16_t_s_s(((0xCA2A9956A48319FELL >= l_221[l_249][(l_249 + 4)]) == g_161), 5));
        }
    }
    return l_263;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_15 g_38 g_45 g_33 g_63 g_83 g_87 g_91 g_41 g_75 g_32 g_124 g_133 g_147 g_162 g_161 g_193 g_62 g_142
 * writes: g_38 g_41 g_45 g_63 g_62 g_83 g_87 g_91 g_75 g_124 g_133 g_147 g_162 g_193
 */
static uint16_t  func_4(int32_t  p_5, int64_t  p_6)
{ /* block id: 1 */
    int8_t l_20[10][3] = {{0x66L,0x66L,0x66L},{(-3L),0x22L,(-3L)},{0x66L,0x66L,0x66L},{(-3L),0x22L,(-3L)},{0x66L,0x66L,0x66L},{(-3L),0x22L,(-3L)},{0x66L,0x66L,0x66L},{(-3L),0x22L,(-3L)},{0x66L,0x66L,0x66L},{(-3L),0x22L,(-3L)}};
    int32_t l_21[9][5] = {{0L,1L,1L,0L,(-1L)},{(-10L),1L,0xBA4D3EC9L,0x3FC2F92EL,0L},{0x3876A47CL,(-1L),(-10L),0x54292978L,2L},{0xBA4D3EC9L,9L,0xC0B333EEL,0x3FC2F92EL,0x3FC2F92EL},{9L,0x3876A47CL,9L,0L,(-10L)},{9L,(-4L),0x54292978L,0x3876A47CL,0x2E607D19L},{0xBA4D3EC9L,0xC0B333EEL,(-1L),1L,0x356A0B34L},{0x3876A47CL,0x3FC2F92EL,0x54292978L,0x2E607D19L,0x54292978L},{(-10L),(-10L),9L,(-4L),0x54292978L}};
    int i, j;
    for (p_6 = 26; (p_6 >= 20); p_6 = safe_sub_func_int64_t_s_s(p_6, 5))
    { /* block id: 4 */
        int16_t l_19 = 0x98CAL;
        l_19 = 0L;
    }
    l_21[3][2] = l_20[0][1];
    if (func_22(func_27(g_16, g_15, g_16, p_5), p_5, g_16, g_16))
    { /* block id: 114 */
        int16_t l_200 = 0x63B7L;
        l_21[4][2] = (safe_sub_func_int16_t_s_s((safe_mod_func_uint32_t_u_u((((g_147 , l_200) == 0xC92BL) > p_5), (-5L))), 0x0D4CL));
        l_21[7][0] = (safe_sub_func_int32_t_s_s((g_142 & l_200), p_5));
    }
    else
    { /* block id: 117 */
        volatile int8_t l_205 = 4L;/* VOLATILE GLOBAL l_205 */
        uint32_t l_211 = 0x59306392L;
        g_45 = (p_5 | g_133);
        for (p_5 = 16; (p_5 < (-29)); p_5 = safe_sub_func_uint32_t_u_u(p_5, 7))
        { /* block id: 121 */
            if (p_5)
                break;
            l_205 = g_83;
            g_62 = g_75;
        }
        if ((safe_mul_func_uint8_t_u_u(((~((safe_lshift_func_uint8_t_u_s(l_211, 3)) >= p_5)) > g_45), g_32[0][2])))
        { /* block id: 126 */
            uint32_t l_216 = 4294967291UL;
            l_216 = (safe_div_func_uint8_t_u_u(((((safe_div_func_int32_t_s_s((0x793AD1AC59717F0BLL || 0x9119F7A4396262B8LL), g_15)) != 0xE85CDDA5L) >= g_161) >= l_211), 8L));
        }
        else
        { /* block id: 128 */
            g_62 = (((safe_rshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(((g_63 >= 18446744073709551615UL) , g_162), 0xCA71L)), p_5)) == p_5) && p_5);
            return p_5;
        }
        g_62 = (p_6 != p_5);
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_75 g_91 g_45 g_32 g_63 g_124 g_133 g_147 g_162 g_15 g_87 g_161 g_193 g_62 g_33 g_38
 * writes: g_41 g_75 g_62 g_124 g_133 g_147 g_45 g_162 g_193
 */
static int32_t  func_22(int16_t  p_23, uint8_t  p_24, int8_t  p_25, uint64_t  p_26)
{ /* block id: 66 */
    uint32_t l_118[7];
    uint32_t l_129[7][3] = {{0x1ECAE5D5L,1UL,0x1ECAE5D5L},{1UL,1UL,1UL},{0x1ECAE5D5L,1UL,0x1ECAE5D5L},{1UL,1UL,1UL},{0x1ECAE5D5L,1UL,0x1ECAE5D5L},{1UL,1UL,1UL},{0x1ECAE5D5L,1UL,0x1ECAE5D5L}};
    int32_t l_137[1][9] = {{0xA18D89BDL,0xA18D89BDL,4L,0xA18D89BDL,0xA18D89BDL,4L,0xA18D89BDL,0xA18D89BDL,4L}};
    int32_t l_160 = 0L;
    int i, j;
    for (i = 0; i < 7; i++)
        l_118[i] = 0xFEAE78DFL;
    for (g_41 = 17; (g_41 <= 6); --g_41)
    { /* block id: 69 */
        int32_t l_114 = 0xE50A8E06L;
        uint32_t l_116 = 0xB0A97542L;
        int32_t l_117 = (-3L);
        int8_t l_119 = 0x24L;
        int32_t l_140 = (-1L);
        int32_t l_143 = 1L;
        int32_t l_144[2];
        int i;
        for (i = 0; i < 2; i++)
            l_144[i] = 0L;
        for (g_75 = 0; (g_75 == 1); g_75++)
        { /* block id: 72 */
            uint8_t l_115 = 6UL;
            l_117 = ((safe_add_func_int64_t_s_s((((safe_sub_func_int64_t_s_s((safe_div_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((+((((safe_div_func_int64_t_s_s(((!(safe_rshift_func_int8_t_s_u(((((l_114 , g_91) == p_24) <= 1L) <= l_114), 5))) != 0x52390699391FD407LL), l_115)) > 0UL) == 0x9EL) & g_45)), l_115)), g_45)), g_41)) != 0xFAL) < 0UL), l_116)) && (-1L));
            if (l_118[0])
                break;
            g_62 = (0xD2L ^ l_119);
            g_124 &= (((safe_add_func_uint32_t_u_u((safe_div_func_uint64_t_u_u((l_116 != g_32[1][0]), g_63)), p_25)) == g_45) != l_115);
        }
        l_117 = (safe_div_func_uint16_t_u_u(((safe_add_func_int16_t_s_s(p_24, l_129[6][1])) , 0x7F01L), l_119));
        for (g_75 = (-21); (g_75 < 23); g_75 = safe_add_func_uint32_t_u_u(g_75, 2))
        { /* block id: 81 */
            int8_t l_132[1];
            int32_t l_136 = 0xF3C947AAL;
            int32_t l_138 = 0xCE6BA5C8L;
            int32_t l_139 = 0x242FA0D6L;
            int32_t l_141 = 0x2D8A91DCL;
            int32_t l_145 = 0xD3DBF9D0L;
            int32_t l_146[3][5][8] = {{{0x68B8653EL,0x81A8B479L,0x68B8653EL,1L,1L,0x6115DA6AL,0x81A8B479L,(-9L)},{0L,5L,0x1C656C0CL,8L,0x16C32C6DL,(-1L),1L,0x1C656C0CL},{0L,0x16C32C6DL,5L,0xDDF97142L,1L,0xB8EE5A8BL,0xB8EE5A8BL,1L},{0x68B8653EL,(-8L),(-8L),0x68B8653EL,(-1L),(-9L),5L,1L},{1L,(-6L),(-1L),0x1C656C0CL,9L,1L,0x2478149CL,0xDDF97142L}},{{0L,(-6L),0x68B8653EL,5L,8L,(-9L),(-6L),(-9L)},{0x16C32C6DL,(-8L),(-5L),(-8L),0x16C32C6DL,0xB8EE5A8BL,8L,(-5L)},{0x465E51F8L,0x16C32C6DL,1L,(-1L),1L,(-1L),0xB8EE5A8BL,(-8L)},{0xF5FFFD36L,5L,1L,0x68B8653EL,0x2478149CL,0x6115DA6AL,8L,8L},{1L,0x81A8B479L,0x81A8B479L,0x81A8B479L,0x16C32C6DL,0xF5FFFD36L,0L,0x2478149CL}},{{(-1L),0x465E51F8L,0x1C656C0CL,(-9L),0L,1L,0x465E51F8L,0xDDF97142L},{5L,0xF5FFFD36L,0x2478149CL,(-9L),1L,(-8L),0L,0x2478149CL},{1L,1L,0x68B8653EL,0x81A8B479L,0x68B8653EL,1L,1L,0x6115DA6AL},{0xDDF97142L,0x6115DA6AL,0L,0x1C656C0CL,0L,(-5L),(-9L),0x68B8653EL},{0xF5FFFD36L,(-1L),(-1L),0x2478149CL,0L,0xF5FFFD36L,0x16C32C6DL,0x81A8B479L}}};
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_132[i] = 0x82L;
            --g_133;
            g_147--;
            l_160 = (safe_rshift_func_int16_t_s_u((safe_sub_func_uint32_t_u_u((((!(+(safe_div_func_uint64_t_u_u(((safe_mul_func_int16_t_s_s(0x128CL, 65532UL)) , p_25), 0x7D1D32CE05B3D222LL)))) | 0UL) <= 0x04L), g_147)), l_160));
            return g_91;
        }
    }
    g_45 |= l_137[0][5];
lbl_173:
    ++g_162;
    for (p_24 = 0; (p_24 >= 53); ++p_24)
    { /* block id: 92 */
        int16_t l_167 = (-3L);
        uint32_t l_172 = 0x48E4F8FBL;
        int32_t l_174 = 0xAEE4DE7FL;
        int32_t l_183 = 0x2281F5AFL;
        int16_t l_184 = 0x51C6L;
        int32_t l_187 = (-7L);
        int32_t l_188 = (-1L);
        int32_t l_190[1][1];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
                l_190[i][j] = 0xF1C41F14L;
        }
        if (g_75)
        { /* block id: 93 */
            if (l_167)
                break;
            l_137[0][2] ^= (safe_mod_func_int64_t_s_s(p_23, p_25));
            g_62 = (safe_add_func_uint32_t_u_u((1L > 0x3DL), g_15));
        }
        else
        { /* block id: 97 */
            l_172 = (-7L);
            if (l_160)
                goto lbl_173;
            if (g_147)
                break;
        }
        l_174 = (g_87 ^ 0x5D7CC8F446CBE4C4LL);
        if (p_26)
        { /* block id: 103 */
            g_45 = ((((safe_mod_func_int8_t_s_s((safe_add_func_uint16_t_u_u((((((((safe_rshift_func_int16_t_s_u((((g_161 & l_174) > 0x6DL) , l_160), g_147)) || p_23) == g_75) , 0xE296BD5CD4344FC8LL) || 0x38B24C0330D54037LL) >= 4294967295UL) <= l_174), 0xA538L)), g_15)) > 0x4559AEF2L) < 0xA9903D9CL) && l_172);
        }
        else
        { /* block id: 105 */
            int32_t l_181 = 4L;
            int32_t l_182 = 0x77CFBDFDL;
            int32_t l_185 = 7L;
            int32_t l_186 = 0xAE24F212L;
            int32_t l_189 = 0x8F3EDA6DL;
            int32_t l_191 = 6L;
            int32_t l_192[2];
            int i;
            for (i = 0; i < 2; i++)
                l_192[i] = (-1L);
            g_193++;
            g_62 |= 1L;
            if (l_190[0][0])
                break;
            if (g_33)
                continue;
        }
        l_160 |= (-1L);
    }
    return g_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_45 g_15 g_33 g_63 g_83 g_87 g_91
 * writes: g_38 g_41 g_45 g_63 g_62 g_83 g_87 g_91
 */
static int16_t  func_27(int32_t  p_28, uint32_t  p_29, uint32_t  p_30, uint32_t  p_31)
{ /* block id: 8 */
    uint16_t l_40 = 65535UL;
    int32_t l_42 = 0xA870C387L;
    int32_t l_43[4];
    uint16_t l_46 = 0xB48FL;
    int i;
    for (i = 0; i < 4; i++)
        l_43[i] = 0x90031234L;
    for (p_30 = 0; (p_30 <= 1); p_30 += 1)
    { /* block id: 11 */
        int32_t l_37 = (-2L);
        int32_t l_39 = 4L;
        int32_t l_44 = 0xF7FFFF97L;
        int16_t l_80 = 0xAFFFL;
        int32_t l_86 = 0x7C819A80L;
        if ((4UL <= p_29))
        { /* block id: 12 */
            uint8_t l_34[5];
            int i;
            for (i = 0; i < 5; i++)
                l_34[i] = 255UL;
            l_34[0]++;
            return l_34[0];
        }
        else
        { /* block id: 15 */
            g_38 = l_37;
            l_39 = p_30;
        }
        g_41 = (l_40 > p_29);
        l_46++;
        for (g_38 = 0; (g_38 <= 1); g_38 += 1)
        { /* block id: 23 */
            int64_t l_51 = 0x4ADCF8610F121ADFLL;
            int32_t l_79 = 0xCF10AA6FL;
            l_79 ^= func_49(l_51);
        }
        for (g_38 = 0; (g_38 <= 1); g_38 += 1)
        { /* block id: 58 */
            int32_t l_81 = 0xD72E8F98L;
            int32_t l_82 = 0xAD5EAB19L;
            int32_t l_90 = (-8L);
            --g_83;
            g_87++;
            --g_91;
        }
    }
    g_45 = (0xB4E22DD2L || l_43[3]);
    return l_43[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_45 g_15 g_33 g_63
 * writes: g_45 g_63 g_62
 */
static int32_t  func_49(uint64_t  p_50)
{ /* block id: 24 */
    int32_t l_55 = 5L;
    int32_t l_68[6];
    uint16_t l_76 = 0xC63CL;
    int i;
    for (i = 0; i < 6; i++)
        l_68[i] = 0x414E4A47L;
    if ((safe_rshift_func_int8_t_s_u(0xDBL, 7)))
    { /* block id: 25 */
        uint16_t l_56 = 1UL;
        int32_t l_57 = 0xD7AFF79CL;
        for (g_45 = 0; (g_45 <= 1); g_45 += 1)
        { /* block id: 28 */
            int32_t l_54 = 7L;
            l_55 = l_54;
        }
        l_57 |= (l_56 || 0x5BD571E9572AB10ELL);
    }
    else
    { /* block id: 32 */
lbl_72:
        if ((safe_mod_func_uint8_t_u_u((g_15 , g_33), g_45)))
        { /* block id: 33 */
            uint64_t l_60 = 0x8F6F7E707ECB515FLL;
            int32_t l_61 = (-1L);
            g_45 = l_60;
            --g_63;
            return g_15;
        }
        else
        { /* block id: 37 */
            uint32_t l_67 = 18446744073709551606UL;
            l_68[3] = (safe_unary_minus_func_uint8_t_u(l_67));
            g_45 = 0x60280E44L;
            g_62 = ((p_50 > g_15) , 0xDA569FAAL);
            g_45 = (-8L);
        }
        for (g_45 = 1; (g_45 >= 0); g_45 -= 1)
        { /* block id: 45 */
            uint64_t l_69 = 0x8F52837B75AE7BE9LL;
            int i;
            ++l_69;
            if (p_50)
                goto lbl_72;
            l_68[0] = l_68[(g_45 + 1)];
            l_68[3] = (~(~0x866CL));
        }
    }
    ++l_76;
    return p_50;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_32[i][j], "g_32[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_147, "g_147", print_hash_value);
    transparent_crc(g_161, "g_161", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_193, "g_193", print_hash_value);
    transparent_crc(g_254, "g_254", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 101
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 120
   depth: 2, occurrence: 27
   depth: 3, occurrence: 6
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 4
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 13, occurrence: 1
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 133
XXX times a non-volatile is write: 60
XXX times a volatile is read: 25
XXX    times read thru a pointer: 0
XXX times a volatile is write: 17
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 129
XXX percentage of non-volatile access: 82.1

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 107
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 30
   depth: 2, occurrence: 57

XXX percentage a fresh-made variable is used: 33.1
XXX percentage an existing variable is used: 66.9
********************* end of statistics **********************/

