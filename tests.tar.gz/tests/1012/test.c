/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13541733223996118469
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile int16_t g_8[4] = {3L,3L,3L,3L};
static int8_t g_14 = 0xB7L;
static int16_t g_23 = 9L;
static int8_t g_45 = (-9L);
static int8_t g_61 = 1L;
static uint16_t g_66 = 65535UL;
static int32_t g_67 = 0xB48EDA29L;
static int64_t g_68 = (-2L);
static uint16_t g_69 = 0x5B2DL;
static uint32_t g_75[2][8][8] = {{{0x2F72762BL,18446744073709551615UL,2UL,0x676063AEL,1UL,0xA6B6B07CL,0x8302A6F4L,0UL},{0UL,1UL,0x87106FA4L,0UL,0x12691D14L,0x19ED05CEL,0x31D611CFL,0xC47F9ABEL},{0xB94A9589L,0x2F72762BL,18446744073709551609UL,0xE5F641D3L,0xAE1F6371L,0x12691D14L,18446744073709551609UL,0x9925C1F9L},{0x6BAE6AC6L,1UL,0x676063AEL,0x87106FA4L,0x9925C1F9L,0x87106FA4L,0x676063AEL,1UL},{0x2B02D377L,18446744073709551610UL,0xA0476F2AL,0xA6B6B07CL,0x6F66B510L,0xAE1F6371L,0x35EF5641L,18446744073709551608UL},{18446744073709551615UL,0xA0476F2AL,0xFD429592L,0xFC6D38C1L,0UL,0xA6B6B07CL,0x92D0F567L,18446744073709551608UL},{0x19ED05CEL,0xFC6D38C1L,0x52A3E9F7L,0xB98CFE46L,0x20850DA4L,0xC47F9ABEL,18446744073709551608UL,0UL},{0x20850DA4L,0xC47F9ABEL,18446744073709551608UL,0UL,4UL,18446744073709551609UL,18446744073709551611UL,0xACF258FDL}},{{0UL,18446744073709551609UL,0xE175A398L,0x8302A6F4L,18446744073709551615UL,0xAE1F6371L,0xAE1F6371L,18446744073709551615UL},{18446744073709551611UL,0x19ED05CEL,0x19ED05CEL,18446744073709551611UL,0xA6B6B07CL,0x2F72762BL,4UL,0x31D611CFL},{1UL,0xAE1F6371L,0x31D611CFL,0x2B02D377L,0UL,0x6BAE6AC6L,0xACF258FDL,0xB98CFE46L},{0x87106FA4L,0xAE1F6371L,2UL,0x6F66B510L,0x35EF5641L,0x2F72762BL,0x52A3E9F7L,0xC47F9ABEL},{18446744073709551615UL,0x19ED05CEL,18446744073709551615UL,0x9925C1F9L,18446744073709551615UL,0xAE1F6371L,0x676063AEL,18446744073709551611UL},{0x2F72762BL,18446744073709551609UL,0xE5F641D3L,0xAE1F6371L,0x12691D14L,18446744073709551609UL,0x9925C1F9L,0xA6B6B07CL},{18446744073709551615UL,0xC47F9ABEL,1UL,0x12691D14L,1UL,0xC47F9ABEL,18446744073709551615UL,0xE5F641D3L},{0xB98CFE46L,0xFC6D38C1L,0xAE1F6371L,1UL,2UL,0xA6B6B07CL,0xC47F9ABEL,0xE175A398L}}};
static int64_t g_79 = 0L;
static int16_t g_90[1] = {0x3401L};
static volatile uint64_t g_95[9] = {0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL,0x889B5E22BCF927AELL};
static volatile uint8_t g_101[4] = {0x08L,0x08L,0x08L,0x08L};
static int32_t g_115 = 0x67E142B9L;
static volatile uint32_t g_118 = 0xF8CE80C6L;/* VOLATILE GLOBAL g_118 */
static int32_t g_123[2] = {0L,0L};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_10(uint64_t  p_11, uint64_t  p_12, int16_t  p_13);
static int32_t  func_26(int32_t  p_27, int32_t  p_28, int8_t  p_29, uint32_t  p_30);
static uint32_t  func_33(int8_t  p_34, uint32_t  p_35, uint64_t  p_36, int32_t  p_37);
static int32_t  func_53(int32_t  p_54, uint32_t  p_55, uint16_t  p_56, uint32_t  p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_14 g_23 g_61 g_67 g_68 g_69 g_75 g_66 g_95 g_79 g_101 g_118 g_123 g_45 g_90
 * writes: g_23 g_45 g_66 g_67 g_68 g_69 g_79 g_95 g_101 g_118 g_115 g_123
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_7 = 0x96CA2CB51DBA3399LL;
    int32_t l_129[8] = {0xADF4511BL,0xADF4511BL,0xED989C8FL,0xADF4511BL,0xADF4511BL,0xED989C8FL,0xADF4511BL,0xADF4511BL};
    uint16_t l_131 = 0xE6ADL;
    int i;
    if ((safe_rshift_func_uint8_t_u_s((~(safe_div_func_uint8_t_u_u(l_7, g_8[0]))), l_7)))
    { /* block id: 1 */
        int32_t l_136 = (-7L);
        uint32_t l_137 = 0xB8DE4F0EL;
        if (g_8[0])
        { /* block id: 2 */
            int8_t l_9 = 0L;
            l_9 = (-6L);
            g_123[0] &= func_10(l_9, g_8[0], g_14);
        }
        else
        { /* block id: 92 */
            int8_t l_128 = 0xD9L;
            int32_t l_130 = 0xF93586B9L;
            l_129[4] = ((safe_mul_func_uint8_t_u_u((safe_div_func_uint8_t_u_u(0x77L, l_7)), 0xD3L)) | l_128);
            ++l_131;
        }
        l_137 = (safe_lshift_func_uint8_t_u_u(((g_95[5] == l_136) , l_136), g_45));
        g_123[0] ^= ((safe_lshift_func_int8_t_s_s((safe_mod_func_int32_t_s_s(((safe_mod_func_int16_t_s_s((l_7 <= 0xD1DE3320B125740FLL), g_75[0][6][7])) | g_61), l_136)), l_7)) != g_75[0][5][3]);
    }
    else
    { /* block id: 98 */
        uint16_t l_144 = 65534UL;
        uint8_t l_149 = 246UL;
        int32_t l_156 = 1L;
        l_144 = l_129[4];
        for (g_68 = 0; (g_68 <= 1); g_68 += 1)
        { /* block id: 102 */
            int i;
            g_123[g_68] = g_123[0];
            g_123[1] = (safe_sub_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((0xAD06L && g_8[3]), l_149)), l_129[3]));
            g_115 = (safe_sub_func_int32_t_s_s((g_61 ^ (-3L)), 0x690AA636L));
            g_123[0] = ((safe_mod_func_uint16_t_u_u((g_75[0][1][0] ^ g_8[0]), g_45)) < 18446744073709551608UL);
        }
        l_156 = ((safe_rshift_func_uint16_t_u_s(g_23, 12)) && g_95[0]);
        for (l_131 = 0; (l_131 <= 8); l_131 += 1)
        { /* block id: 111 */
            uint32_t l_157 = 0x82948B3EL;
            --l_157;
            g_123[0] &= (safe_div_func_int64_t_s_s(((safe_mul_func_int16_t_s_s((l_157 , g_90[0]), 65535UL)) , 0x5B27661964D51499LL), l_157));
            g_123[1] &= g_23;
            return l_129[4];
        }
    }
    l_129[0] = l_129[4];
    return l_129[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_8 g_23 g_61 g_67 g_68 g_69 g_75 g_66 g_95 g_79 g_101 g_118
 * writes: g_23 g_45 g_66 g_67 g_68 g_69 g_79 g_95 g_101 g_118 g_115
 */
static int32_t  func_10(uint64_t  p_11, uint64_t  p_12, int16_t  p_13)
{ /* block id: 4 */
    int32_t l_15 = 0x2A26F3F1L;
    int32_t l_16 = 0xD44C039EL;
    l_16 = l_15;
    g_23 = (((safe_mul_func_uint16_t_u_u((((((safe_add_func_uint32_t_u_u((safe_mul_func_int16_t_s_s(g_14, 65535UL)), l_16)) <= p_12) > g_8[3]) != g_14) <= l_16), g_14)) > 0xE4F9DBC9L) > g_14);
    if (l_15)
    { /* block id: 7 */
        l_16 = ((safe_add_func_uint8_t_u_u(((((0xABEFA025EC560449LL | g_8[0]) , p_11) <= p_11) ^ 0UL), g_23)) >= p_13);
    }
    else
    { /* block id: 9 */
        l_16 = func_26(((safe_lshift_func_uint8_t_u_u(((func_33(p_13, l_16, g_14, g_14) || g_61) , g_8[0]), 2)) > p_11), g_61, p_13, p_11);
        g_115 = ((safe_rshift_func_int8_t_s_s((-1L), 0)) == 0x22L);
        return g_69;
    }
    return g_101[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_69 g_23 g_68 g_75 g_66 g_61 g_95 g_79 g_101 g_67 g_118
 * writes: g_79 g_68 g_95 g_23 g_101 g_66 g_67 g_118
 */
static int32_t  func_26(int32_t  p_27, int32_t  p_28, int8_t  p_29, uint32_t  p_30)
{ /* block id: 44 */
    int32_t l_72 = 1L;
    uint32_t l_85 = 0xA21089BBL;
    int64_t l_91 = 1L;
    int32_t l_94 = 0xC4CDA38EL;
lbl_80:
    p_27 ^= (g_69 > l_72);
    for (p_28 = 0; (p_28 != (-20)); p_28 = safe_sub_func_int64_t_s_s(p_28, 1))
    { /* block id: 48 */
        for (p_30 = 0; (p_30 <= 1); p_30 += 1)
        { /* block id: 51 */
            const uint64_t l_78 = 0x921C45DBD19AA3B2LL;
            g_79 = ((((((safe_div_func_int16_t_s_s(g_23, 1UL)) | 0x8D28L) , 0xCC60535321785A3FLL) & p_28) & 0x5658C465D2E07F6ALL) , l_78);
            if (g_69)
                goto lbl_80;
        }
    }
    for (g_68 = 0; (g_68 <= 1); g_68 += 1)
    { /* block id: 58 */
        int8_t l_88 = 0x08L;
        int32_t l_92 = 0x9851B6DCL;
        int8_t l_110 = 0x25L;
        int32_t l_117 = 0x62082439L;
        if ((((safe_lshift_func_int16_t_s_u(((safe_add_func_uint64_t_u_u(((g_75[1][0][3] ^ p_27) && g_66), p_28)) != l_85), 4)) , g_75[1][2][2]) & 0x4EE9L))
        { /* block id: 59 */
            uint32_t l_89[7][4][9] = {{{4UL,0UL,0UL,0xFDE158D9L,0x83AED21BL,4294967295UL,4294967293UL,1UL,7UL},{0xCF94CC8AL,0x9694381BL,1UL,0x9D302D72L,0xAC479B9BL,0x383E184CL,0UL,0x7C3A5C4FL,0xF954D451L},{4UL,0x83AED21BL,4294967293UL,0x286226F5L,1UL,4UL,1UL,0x286226F5L,4294967293UL},{0x383E184CL,0x383E184CL,4294967295UL,4294967295UL,0xCF94CC8AL,0xBCCD5419L,0xB59B1E0FL,9UL,4294967293UL}},{{1UL,7UL,0UL,4294967295UL,4294967294UL,0xFDE158D9L,0UL,8UL,0x4488338CL},{0x9D302D72L,0xF954D451L,4294967295UL,0x59F99B68L,0xB9E3EC41L,4294967290UL,0x7C3A5C4FL,4294967290UL,0xB9E3EC41L},{1UL,4294967293UL,4294967293UL,1UL,0xC98A9952L,0UL,4UL,7UL,0xAB6CAC88L},{0xBCCD5419L,4294967293UL,1UL,3UL,4294967295UL,0xBE49ECA5L,0x7173955FL,0x59F99B68L,4294967290UL}},{{4294967295UL,0x4488338CL,0UL,0xAB6CAC88L,0xC98A9952L,7UL,0xE42B7543L,4294967286UL,0xE42B7543L},{0x7C3A5C4FL,0xF954D451L,0xF4FB9E1BL,0xF4FB9E1BL,0xF954D451L,0x7C3A5C4FL,0UL,0x383E184CL,0xAC479B9BL},{4294967293UL,4294967293UL,0UL,1UL,0UL,4UL,1UL,0xF5847AAFL,4294967294UL},{0x9694381BL,0xC3633543L,0x59F99B68L,9UL,0xFAF418CCL,4UL,0UL,3UL,0xBE49ECA5L}},{{4294967295UL,0xF5847AAFL,1UL,0xAB6CAC88L,0xAB6CAC88L,1UL,0xF5847AAFL,4294967295UL,0x4488338CL},{1UL,0xAC479B9BL,0x7C3A5C4FL,0x9D302D72L,4294967295UL,9UL,4UL,0xCF94CC8AL,0x383E184CL},{4294967286UL,4294967294UL,0x81933AC3L,8UL,0xFDE158D9L,0xF5847AAFL,0UL,0x83AED21BL,0x4488338CL},{4294967293UL,0xBE49ECA5L,0xF954D451L,1UL,0x7173955FL,0x7173955FL,1UL,0xF954D451L,0xBE49ECA5L}},{{0UL,0x4488338CL,0x83AED21BL,0UL,0xF5847AAFL,0xFDE158D9L,8UL,0x81933AC3L,4294967294UL},{0xB9E3EC41L,0x383E184CL,0xCF94CC8AL,4UL,9UL,4294967295UL,0x9D302D72L,0x7C3A5C4FL,0xAC479B9BL},{1UL,0x4488338CL,4294967295UL,0xF5847AAFL,1UL,0xAB6CAC88L,0xAB6CAC88L,1UL,0xF5847AAFL},{3UL,0xBE49ECA5L,3UL,0UL,4UL,0xFAF418CCL,9UL,0x59F99B68L,0xC3633543L}},{{7UL,4294967294UL,0xF5847AAFL,1UL,4UL,0UL,1UL,0UL,4294967293UL},{0x9D302D72L,0xAC479B9BL,0x383E184CL,0UL,0x7C3A5C4FL,0xF954D451L,0xF4FB9E1BL,0xF4FB9E1BL,0xF954D451L},{0UL,0xF5847AAFL,0UL,0xF5847AAFL,0UL,0xE42B7543L,4294967293UL,1UL,4294967295UL},{4294967295UL,0xC3633543L,4294967290UL,4UL,0xF4FB9E1BL,0x9694381BL,0xAC479B9BL,0x66A50E26L,0xB9E3EC41L}},{{0xF5847AAFL,4294967293UL,0UL,0UL,0x4488338CL,0xE42B7543L,0x81933AC3L,1UL,1UL},{4294967290UL,0xF954D451L,0xC3633543L,1UL,0xC3633543L,0xF954D451L,4294967290UL,0x9694381BL,0xEA078BFDL},{1UL,4294967295UL,1UL,8UL,4UL,0UL,4294967295UL,0x4488338CL,0UL},{4294967295UL,0xB9E3EC41L,0x7173955FL,0x9D302D72L,0xCF94CC8AL,0xFAF418CCL,4294967293UL,0x9694381BL,0UL}}};
            int32_t l_93[3];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_93[i] = 6L;
            l_89[0][2][7] ^= (safe_rshift_func_int8_t_s_u((l_88 | l_88), g_61));
            g_95[8]--;
        }
        else
        { /* block id: 62 */
            p_27 = ((safe_mod_func_uint64_t_u_u(l_92, g_79)) != 0x61D4L);
        }
        for (g_23 = 1; (g_23 >= 0); g_23 -= 1)
        { /* block id: 67 */
            int8_t l_100[6][2] = {{0xE5L,0xE5L},{0xE5L,0xE5L},{0xE5L,0xE5L},{0xE5L,0xE5L},{0xE5L,0xE5L},{0xE5L,0xE5L}};
            int i, j;
            ++g_101[0];
            l_94 = (safe_sub_func_int8_t_s_s((((1UL > g_101[1]) != 0x92L) > 0L), l_91));
            l_110 = (((safe_mul_func_int8_t_s_s((safe_sub_func_uint8_t_u_u((0x3D9A3968L | l_100[1][1]), g_68)), p_28)) & p_29) >= 0x45343E27L);
            return p_30;
        }
        for (g_66 = 0; (g_66 <= 1); g_66 += 1)
        { /* block id: 75 */
            p_27 = (((safe_add_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_u(l_72, 4)) > l_88), g_95[8])) | 0x129BBF80L) > p_30);
            return l_72;
        }
        for (g_67 = 1; (g_67 >= 0); g_67 -= 1)
        { /* block id: 81 */
            int64_t l_116 = 0x9BFDDA3525E9BBC1LL;
            g_118++;
        }
    }
    return l_85;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_8 g_14 g_61 g_67 g_68 g_69
 * writes: g_23 g_45 g_66 g_67 g_68 g_69
 */
static uint32_t  func_33(int8_t  p_34, uint32_t  p_35, uint64_t  p_36, int32_t  p_37)
{ /* block id: 10 */
    uint32_t l_38 = 0x5C526587L;
    int32_t l_39 = 0x426AE69EL;
    uint8_t l_60 = 0x35L;
    l_39 &= l_38;
    for (g_23 = 2; (g_23 >= (-12)); g_23 = safe_sub_func_int64_t_s_s(g_23, 9))
    { /* block id: 14 */
        uint64_t l_44 = 1UL;
        int32_t l_48 = (-1L);
        g_45 = (safe_div_func_uint32_t_u_u(l_44, g_8[2]));
        l_48 = ((safe_mul_func_int8_t_s_s(p_35, l_39)) || p_34);
        for (p_34 = 0; (p_34 <= (-18)); --p_34)
        { /* block id: 19 */
            uint64_t l_51[4] = {0xD5C0F4FD1A684085LL,0xD5C0F4FD1A684085LL,0xD5C0F4FD1A684085LL,0xD5C0F4FD1A684085LL};
            int32_t l_52[5][9][1] = {{{0x3772679FL},{0x94C655EFL},{0x3DC28BF2L},{0xF1B6398CL},{0x3DC28BF2L},{0xE0BB6923L},{4L},{0xFD6F6066L},{0xC8D21259L}},{{4L},{1L},{0xE0BB6923L},{1L},{4L},{0xC8D21259L},{0xFD6F6066L},{4L},{0xE0BB6923L}},{{0x3DC28BF2L},{0xF1B6398CL},{0xC8D21259L},{0xF1B6398CL},{0x3DC28BF2L},{0xE0BB6923L},{4L},{0xFD6F6066L},{0xC8D21259L}},{{4L},{1L},{0xE0BB6923L},{1L},{4L},{0xC8D21259L},{0xFD6F6066L},{4L},{0xE0BB6923L}},{{0x3DC28BF2L},{0xF1B6398CL},{0xC8D21259L},{0xF1B6398CL},{0x3DC28BF2L},{0xE0BB6923L},{4L},{0xFD6F6066L},{0xC8D21259L}}};
            int i, j, k;
            if (g_14)
                break;
            l_39 = ((l_51[1] < 0xFCL) != g_14);
            l_52[1][4][0] |= 0xF96354D1L;
        }
        if (l_48)
        { /* block id: 24 */
            l_48 = l_44;
        }
        else
        { /* block id: 26 */
            l_48 = (5L || g_14);
            if (p_35)
                continue;
            l_39 &= (0x09L | p_35);
            g_67 |= func_53((safe_div_func_uint16_t_u_u((l_60 , 0xFCD5L), 0x787DL)), p_34, g_8[0], g_61);
        }
    }
    g_68 |= 0xBB970EAEL;
    --g_69;
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_66
 */
static int32_t  func_53(int32_t  p_54, uint32_t  p_55, uint16_t  p_56, uint32_t  p_57)
{ /* block id: 30 */
    uint32_t l_65 = 0x997376B2L;
    for (p_56 = 0; (p_56 <= 28); p_56 = safe_add_func_int64_t_s_s(p_56, 9))
    { /* block id: 33 */
        int16_t l_64 = 1L;
        if (l_64)
            break;
    }
    g_66 = l_65;
    return l_65;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_75[i][j][k], "g_75[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_79, "g_79", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_90[i], "g_90[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_95[i], "g_95[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_101[i], "g_101[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_123[i], "g_123[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 52
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 76
   depth: 2, occurrence: 15
   depth: 3, occurrence: 8
   depth: 4, occurrence: 5
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 4
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 111
XXX times a non-volatile is write: 51
XXX times a volatile is read: 15
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 52
XXX percentage of non-volatile access: 90

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 72
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 21
   depth: 2, occurrence: 32

XXX percentage a fresh-made variable is used: 29.7
XXX percentage an existing variable is used: 70.3
********************* end of statistics **********************/

