/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17159257162755529873
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 0x4E2DB58EL;
static volatile int16_t g_12 = 0L;/* VOLATILE GLOBAL g_12 */
static int32_t g_13 = 0xEA388845L;
static volatile uint64_t g_14 = 0xDFBA22E974A52027LL;/* VOLATILE GLOBAL g_14 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint64_t  func_8(uint64_t  p_9);
static int16_t  func_20(int64_t  p_21, uint64_t  p_22, int32_t  p_23);
static int64_t  func_57(uint8_t  p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_14 g_13 g_12
 * writes: g_3 g_14 g_2 g_13
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int16_t l_27 = (-2L);
    int32_t l_36 = 0L;
    uint8_t l_39[9] = {0xD5L,0xD5L,0xD5L,0xD5L,0xD5L,0xD5L,0xD5L,0xD5L,0xD5L};
    int32_t l_44 = 0xCFF5F9F7L;
    int32_t l_49[10] = {0xE1D77F59L,5L,0xE1D77F59L,0xE1D77F59L,5L,0xE1D77F59L,0xE1D77F59L,5L,0xE1D77F59L,0xE1D77F59L};
    int i;
    for (g_3 = (-4); (g_3 < 3); g_3 = safe_add_func_int16_t_s_s(g_3, 1))
    { /* block id: 3 */
        int32_t l_19 = 7L;
        uint32_t l_26 = 0x6D0811FCL;
        if (g_3)
            break;
        if ((func_8(g_2) == 0UL))
        { /* block id: 8 */
            return g_3;
        }
        else
        { /* block id: 10 */
            uint16_t l_35[10][5][5] = {{{0x384BL,8UL,1UL,0xE2BBL,0xCFF2L},{65531UL,8UL,1UL,0x56D9L,0xED99L},{0xA360L,0x384BL,65535UL,1UL,0x2C8CL},{65531UL,65526UL,0xCFF2L,0x1AFDL,0x2C8CL},{0x384BL,65531UL,0xED99L,0x57C1L,0xED99L}},{{0xD3F0L,0xD3F0L,65535UL,0x970CL,0x5558L},{1UL,1UL,65535UL,0UL,0xAB1FL},{0x7F20L,0xE266L,2UL,0x23FEL,0x76E8L},{0xA0F8L,1UL,0x5558L,0xE12BL,0xD6E5L},{0xA0F8L,0x2C8CL,0xAB1FL,7UL,0xC764L}},{{0x7F20L,0x94D2L,0x76E8L,0x08DDL,0xD6E5L},{1UL,65535UL,0xD6E5L,0x08DDL,0x76E8L},{0x2C8CL,0x88FEL,0xC764L,7UL,0xAB1FL},{0x88FEL,0xCFF2L,0xD6E5L,0xE12BL,0x5558L},{0x94D2L,0xCFF2L,0x76E8L,0x23FEL,2UL}},{{1UL,0x88FEL,0xAB1FL,0UL,65535UL},{0x94D2L,65535UL,0x5558L,0x970CL,65535UL},{0x88FEL,0x94D2L,2UL,0x8E1FL,2UL},{0x2C8CL,0x2C8CL,65535UL,0x970CL,0x5558L},{1UL,1UL,65535UL,0UL,0xAB1FL}},{{0x7F20L,0xE266L,2UL,0x23FEL,0x76E8L},{0xA0F8L,1UL,0x5558L,0xE12BL,0xD6E5L},{0xA0F8L,0x2C8CL,0xAB1FL,7UL,0xC764L},{0x7F20L,0x94D2L,0x76E8L,0x08DDL,0xD6E5L},{1UL,65535UL,0xD6E5L,0x08DDL,0x76E8L}},{{0x2C8CL,0x88FEL,0xC764L,7UL,0xAB1FL},{0x88FEL,0xCFF2L,0xD6E5L,0xE12BL,0x5558L},{0x94D2L,0xCFF2L,0x76E8L,0x23FEL,2UL},{1UL,0x88FEL,0xAB1FL,0UL,65535UL},{0x94D2L,65535UL,0x5558L,0x970CL,65535UL}},{{0x88FEL,0x94D2L,2UL,0x8E1FL,2UL},{0x2C8CL,0x2C8CL,65535UL,0x970CL,0x5558L},{1UL,1UL,65535UL,0UL,0xAB1FL},{0x7F20L,0xE266L,2UL,0x23FEL,0x76E8L},{0xA0F8L,1UL,0x5558L,0xE12BL,0xD6E5L}},{{0xA0F8L,0x2C8CL,0xAB1FL,7UL,0xC764L},{0x7F20L,0x94D2L,0x76E8L,0x08DDL,0xD6E5L},{1UL,65535UL,0xD6E5L,0x08DDL,0x76E8L},{0x2C8CL,0x88FEL,0xC764L,7UL,0xAB1FL},{0x88FEL,0xCFF2L,0xD6E5L,0xE12BL,0x5558L}},{{0x94D2L,0xCFF2L,0x76E8L,0x23FEL,2UL},{1UL,0x88FEL,0xAB1FL,0UL,65535UL},{0x94D2L,65535UL,0x5558L,0x970CL,65535UL},{0x88FEL,0x94D2L,2UL,65531UL,0xE2BBL},{65535UL,65535UL,0x1AFDL,8UL,0x31ECL}},{{0x76E8L,9UL,0x1AFDL,0UL,0x57C1L},{0xC764L,0xAB0BL,0xE2BBL,0x1674L,0x7D23L},{65534UL,9UL,0x31ECL,0x384BL,0UL},{65534UL,65535UL,0x57C1L,0xA360L,1UL},{0xC764L,65535UL,0x7D23L,1UL,0UL}}};
            int i, j, k;
            g_2 = (safe_lshift_func_uint16_t_u_u(g_14, l_19));
            if (g_13)
                continue;
            l_35[7][1][2] = (func_20((safe_add_func_int32_t_s_s(g_2, l_26)), l_27, l_27) < (-1L));
            l_36 = (g_3 < l_35[4][2][0]);
        }
    }
    for (g_3 = (-24); (g_3 <= (-10)); g_3 = safe_add_func_int64_t_s_s(g_3, 6))
    { /* block id: 29 */
        for (l_36 = 0; (l_36 <= 8); l_36 += 1)
        { /* block id: 32 */
            int i;
            return l_39[l_36];
        }
    }
    if (func_20((~(l_36 != l_27)), l_27, l_39[8]))
    { /* block id: 36 */
        for (g_13 = 0; g_13 < 9; g_13 += 1)
        {
            l_39[g_13] = 255UL;
        }
    }
    else
    { /* block id: 38 */
        uint64_t l_45 = 18446744073709551606UL;
        for (l_36 = 29; (l_36 <= 9); l_36 = safe_sub_func_int64_t_s_s(l_36, 9))
        { /* block id: 41 */
            uint32_t l_43 = 0xAEB8EFB6L;
            return l_43;
        }
        l_36 |= func_20(l_44, l_45, g_12);
    }
    if (((safe_div_func_int16_t_s_s(l_44, g_14)) & g_3))
    { /* block id: 46 */
        volatile uint32_t l_48 = 0x551B70F8L;/* VOLATILE GLOBAL l_48 */
        int32_t l_50[8] = {0xDE484183L,0xDE484183L,0xDE484183L,0xDE484183L,0xDE484183L,0xDE484183L,0xDE484183L,0xDE484183L};
        int32_t l_51 = 3L;
        uint32_t l_52 = 0UL;
        int i;
        l_48 = g_2;
        l_52++;
    }
    else
    { /* block id: 49 */
        for (l_27 = (-18); (l_27 >= (-6)); l_27 = safe_add_func_uint32_t_u_u(l_27, 1))
        { /* block id: 52 */
            g_13 = g_3;
            l_49[7] |= (func_57((0x4AL <= 248UL)) , g_3);
        }
    }
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes: g_14
 */
static uint64_t  func_8(uint64_t  p_9)
{ /* block id: 5 */
    int8_t l_10 = (-1L);
    int32_t l_11[6] = {0xCB143E95L,0xCB143E95L,0xAD8530DEL,0xCB143E95L,0xCB143E95L,0xAD8530DEL};
    int i;
    --g_14;
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_14
 * writes: g_14 g_13
 */
static int16_t  func_20(int64_t  p_21, uint64_t  p_22, int32_t  p_23)
{ /* block id: 13 */
    uint8_t l_28[2][7][9] = {{{0x6AL,0x59L,0x20L,1UL,1UL,0x20L,0x59L,0x6AL,3UL},{0x6AL,0UL,3UL,0x20L,0UL,0xD0L,253UL,1UL,0x0BL},{0xDCL,0x77L,1UL,253UL,0x62L,0xF6L,3UL,1UL,3UL},{0x77L,0xABL,5UL,5UL,0xABL,0x77L,0UL,1UL,0x96L},{0xF6L,0x62L,253UL,1UL,0x77L,0xDCL,0x53L,1UL,1UL},{0xD0L,0UL,0x20L,3UL,0UL,0x6AL,0UL,0x6AL,0UL},{0x20L,1UL,1UL,0x20L,0x59L,0x6AL,3UL,0x77L,0x0BL}},{{248UL,3UL,0x96L,0UL,0x62L,0xDCL,253UL,0x96L,1UL},{0x77L,0xF3L,247UL,0x93L,0x59L,0x77L,0x59L,0x93L,247UL},{0x62L,0x62L,0x77L,0x93L,0UL,0xF6L,0x53L,3UL,0x93L},{1UL,254UL,0x20L,0UL,0x77L,0xD0L,254UL,0x6AL,253UL},{0x0BL,253UL,0x77L,0x20L,0xABL,0x20L,0x77L,253UL,0x0BL},{0x53L,253UL,247UL,3UL,0x62L,248UL,1UL,247UL,0x77L},{0x77L,254UL,0x96L,1UL,0UL,0x77L,0xABL,5UL,5UL}}};
    int32_t l_33[2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_33[i] = (-1L);
    --l_28[0][2][1];
lbl_34:
    g_13 = func_8(g_12);
    for (p_21 = 0; (p_21 >= 25); ++p_21)
    { /* block id: 18 */
        l_33[1] |= (l_28[1][3][0] , (-4L));
    }
    if (p_21)
        goto lbl_34;
    return l_28[1][5][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_13
 * writes:
 */
static int64_t  func_57(uint8_t  p_58)
{ /* block id: 54 */
    int8_t l_65[10] = {0xEDL,0xEDL,0x73L,0xFDL,0x73L,0xEDL,0xEDL,0x73L,0xFDL,0x73L};
    int32_t l_66 = (-1L);
    int i;
    l_66 &= (safe_sub_func_int64_t_s_s((safe_mod_func_int8_t_s_s((safe_mod_func_int8_t_s_s((p_58 > 0x2BL), p_58)), l_65[9])), l_65[4]));
    return g_13;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 22
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 29
   depth: 2, occurrence: 10
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 16
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 41
XXX percentage of non-volatile access: 83.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 33
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 10
   depth: 2, occurrence: 9

XXX percentage a fresh-made variable is used: 31.4
XXX percentage an existing variable is used: 68.6
********************* end of statistics **********************/

