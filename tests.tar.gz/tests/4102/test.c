/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14353217847373417468
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_23 = 6UL;
static volatile uint32_t g_24 = 4294967290UL;/* VOLATILE GLOBAL g_24 */
static uint8_t g_27 = 0x51L;
static int64_t g_31 = 0L;
static int32_t g_42 = (-5L);
static uint8_t g_43[1] = {251UL};
static volatile uint32_t g_45 = 18446744073709551612UL;/* VOLATILE GLOBAL g_45 */
static volatile uint64_t g_48 = 18446744073709551615UL;/* VOLATILE GLOBAL g_48 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_3(uint8_t  p_4, uint8_t  p_5, uint32_t  p_6, uint64_t  p_7);
static uint32_t  func_12(uint64_t  p_13, int32_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_23 g_24 g_27 g_31 g_42 g_45
 * writes: g_24 g_27 g_31 g_42 g_43 g_45 g_48
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_22 = 0x158018D9L;
    uint32_t l_32 = 0x7EA1B148L;
    int8_t l_33 = 0x46L;
    int32_t l_44[10] = {(-8L),0xA3E09E13L,0xB817BB5CL,0xA3E09E13L,(-8L),(-8L),0xA3E09E13L,0xB817BB5CL,0xA3E09E13L,(-8L)};
    int i;
    g_43[0] = ((~(func_3(((safe_add_func_int8_t_s_s(((safe_mod_func_int32_t_s_s((func_12(((((safe_mul_func_int16_t_s_s((((+(safe_lshift_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s((0L | l_22), l_22)) && l_22), 6))) != l_22) != g_23), 65529UL)) , l_22) >= 0L) >= g_23), l_22) | l_32), g_23)) && l_32), l_32)) <= l_22), l_32, l_33, g_23) , l_22)) <= l_33);
    --g_45;
    g_48 = g_45;
    return l_44[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_31 g_42 g_27
 * writes: g_42
 */
static int32_t  func_3(uint8_t  p_4, uint8_t  p_5, uint32_t  p_6, uint64_t  p_7)
{ /* block id: 6 */
    uint64_t l_36 = 0xC39B398EF544BD1ALL;
    int32_t l_39[3];
    int i;
    for (i = 0; i < 3; i++)
        l_39[i] = 0L;
    l_36 = (safe_lshift_func_uint8_t_u_s((249UL && 0x63L), 7));
    l_39[2] = ((((safe_mul_func_uint16_t_u_u(0x376EL, g_23)) , g_31) <= 0x6FE54384F3AC16B4LL) , 0x06862EAEL);
    for (p_5 = 29; (p_5 == 30); ++p_5)
    { /* block id: 11 */
        g_42 |= ((-4L) != g_31);
        return g_27;
    }
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_23 g_27 g_31
 * writes: g_24 g_27 g_31
 */
static uint32_t  func_12(uint64_t  p_13, int32_t  p_14)
{ /* block id: 1 */
    --g_24;
    g_27 |= ((g_23 , p_13) > 0x1D7FL);
    g_31 &= (safe_add_func_uint16_t_u_u(((safe_unary_minus_func_uint32_t_u(((p_13 & 0x4951162D50C85761LL) ^ 0x0EC0DCEE05243B9CLL))) , g_24), g_23));
    return p_14;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_43[i], "g_43[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 24
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 2
   depth: 3, occurrence: 2
   depth: 5, occurrence: 2
   depth: 24, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 7
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 13
XXX percentage of non-volatile access: 88.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 34.1
XXX percentage an existing variable is used: 65.9
********************* end of statistics **********************/

