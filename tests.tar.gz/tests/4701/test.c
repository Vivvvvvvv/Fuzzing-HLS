/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12032332585155359813
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0xAC64A684L;
static int64_t g_12 = 3L;
static uint32_t g_23 = 0xC0FAAB39L;
static volatile uint32_t g_32 = 0UL;/* VOLATILE GLOBAL g_32 */
static uint16_t g_43 = 0xFCE4L;
static int16_t g_44 = 0x6E14L;
static volatile int16_t g_48 = (-1L);/* VOLATILE GLOBAL g_48 */
static int16_t g_51 = 0xF623L;
static int32_t g_71 = 0L;
static uint32_t g_72[10] = {4294967295UL,0x032CD4B4L,0x242CFF42L,0x242CFF42L,0x032CD4B4L,4294967295UL,0x032CD4B4L,0x242CFF42L,0x242CFF42L,0x032CD4B4L};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_6(int64_t  p_7, int16_t  p_8, uint8_t  p_9, int32_t  p_10, int64_t  p_11);
static uint8_t  func_13(const uint64_t  p_14, uint32_t  p_15, const uint16_t  p_16, uint32_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_12 g_23 g_43 g_51 g_44 g_72
 * writes: g_2 g_23 g_32 g_43 g_48 g_51 g_71 g_72
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_5 = 0x2CB51DBA33992443LL;
    int32_t l_73 = 0x3254C1C0L;
    for (g_2 = 27; (g_2 < (-11)); g_2--)
    { /* block id: 3 */
        if (g_2)
            break;
        if (l_5)
            break;
        if (g_2)
            continue;
        g_72[9] &= (func_6(g_2, g_2, g_12, g_12, l_5) < l_5);
    }
    return l_73;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_23 g_2 g_43 g_51 g_44
 * writes: g_23 g_32 g_43 g_48 g_51 g_71
 */
static int8_t  func_6(int64_t  p_7, int16_t  p_8, uint8_t  p_9, int32_t  p_10, int64_t  p_11)
{ /* block id: 7 */
    uint8_t l_34 = 255UL;
    int32_t l_38[9] = {5L,5L,0xAE69ED99L,5L,5L,0xAE69ED99L,5L,5L,0xAE69ED99L};
    int64_t l_58 = (-1L);
    int i;
    if ((0x20L || g_12))
    { /* block id: 8 */
        uint64_t l_33 = 0xA885C82F744ED25ELL;
        int32_t l_37[4];
        int i;
        for (i = 0; i < 4; i++)
            l_37[i] = 0xBEFC7127L;
        l_33 = (func_13(p_8, p_8, p_8, p_10) != g_2);
        if (l_34)
        { /* block id: 14 */
            l_37[2] = (safe_mul_func_uint8_t_u_u(((0x7854L && l_33) == g_12), p_9));
            if (g_12)
                goto lbl_61;
            l_38[4] = g_23;
        }
        else
        { /* block id: 17 */
            uint32_t l_45 = 0xCD5C0F4FL;
            l_38[4] &= l_37[2];
            g_43 |= (safe_div_func_int8_t_s_s((safe_sub_func_int64_t_s_s((((1UL && 0xAC89L) && g_2) == 0x5DC32C75278539AELL), g_12)), p_10));
            l_45++;
            g_48 = (-8L);
        }
        g_51 = (safe_add_func_uint16_t_u_u(0x87B3L, 0L));
        l_37[2] &= ((safe_add_func_uint8_t_u_u(((p_10 , p_7) && p_8), g_51)) != p_8);
        if (p_9)
            goto lbl_64;
    }
    else
    { /* block id: 25 */
        int8_t l_59[3];
        int32_t l_60[4] = {1L,1L,1L,1L};
        int i;
        for (i = 0; i < 3; i++)
            l_59[i] = 0xC6L;
        l_60[3] = ((safe_lshift_func_int8_t_s_s((safe_mul_func_int16_t_s_s((l_58 > l_58), 0xE0BBL)), l_59[2])) & g_44);
    }
lbl_61:
    l_38[4] = (g_2 == 4294967294UL);
lbl_64:
    l_38[1] &= (safe_sub_func_uint64_t_u_u(l_34, 0xE61979B9986219E2LL));
    g_71 = (safe_div_func_int32_t_s_s(((safe_add_func_int64_t_s_s((safe_sub_func_int64_t_s_s(g_51, (-6L))), p_8)) , p_8), p_9));
    return g_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_12
 * writes: g_23 g_32
 */
static uint8_t  func_13(const uint64_t  p_14, uint32_t  p_15, const uint16_t  p_16, uint32_t  p_17)
{ /* block id: 9 */
    const uint16_t l_22 = 0x2DEFL;
    g_23 = (safe_sub_func_int16_t_s_s((safe_sub_func_int64_t_s_s(((4L & p_17) || 0x6BL), l_22)), 0UL));
    g_32 = ((safe_add_func_int64_t_s_s((safe_mod_func_uint64_t_u_u(((safe_rshift_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u((l_22 >= p_14), g_23)) | 1UL), 2)) <= l_22), g_12)), p_15)) , 0x35FF5744L);
    return l_22;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_72[i], "g_72[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 29
   depth: 2, occurrence: 5
   depth: 4, occurrence: 1
   depth: 5, occurrence: 4
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 51
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 14
XXX percentage of non-volatile access: 97.1

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 27
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 10
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 29.9
XXX percentage an existing variable is used: 70.1
********************* end of statistics **********************/

