/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12933438043699902090
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_4 = 0x2BL;
static int32_t g_5 = 1L;
static int32_t g_13 = 4L;
static int32_t g_41 = (-4L);


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint16_t  func_16(const int64_t  p_17);
static const int64_t  func_18(const int32_t  p_19, int16_t  p_20, int64_t  p_21, uint64_t  p_22);
static int32_t  func_26(int32_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_13 g_41
 * writes: g_5 g_13 g_4
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_12 = 0UL;
    int32_t l_42 = 0L;
    if ((safe_div_func_uint16_t_u_u(g_4, (-10L))))
    { /* block id: 1 */
        uint32_t l_11 = 0x622A149CL;
        g_5 = g_4;
        g_13 = (safe_sub_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((~(l_11 & g_5)), g_4)), l_12));
        l_42 = (safe_sub_func_uint16_t_u_u(func_16(func_18((!((l_11 <= 0x27L) < l_12)), g_5, l_11, g_4)), g_41));
    }
    else
    { /* block id: 43 */
        return g_4;
    }
    g_13 ^= 0x2A5B4D63L;
    return l_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_13
 * writes: g_13 g_5 g_4
 */
static uint16_t  func_16(const int64_t  p_17)
{ /* block id: 15 */
    int64_t l_31[1][2];
    uint32_t l_35 = 0x3C9E4A04L;
    int32_t l_40 = 0L;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
            l_31[i][j] = 0L;
    }
    g_13 = g_4;
    if (g_4)
        goto lbl_32;
    if (g_5)
    { /* block id: 17 */
        int64_t l_30 = 0x7778E10A3BDF78B1LL;
        l_30 = func_26(g_13, p_17);
    }
    else
    { /* block id: 22 */
lbl_32:
        for (g_4 = 0; (g_4 >= 0); g_4 -= 1)
        { /* block id: 25 */
            return g_4;
        }
        for (g_4 = (-12); (g_4 != 28); g_4 = safe_add_func_int16_t_s_s(g_4, 5))
        { /* block id: 31 */
            if (l_35)
                break;
        }
    }
    for (g_5 = 0; (g_5 >= 22); g_5 = safe_add_func_int8_t_s_s(g_5, 9))
    { /* block id: 37 */
        g_13 ^= p_17;
    }
    l_40 = ((((safe_rshift_func_int8_t_s_s((p_17 & p_17), g_5)) , p_17) == 0x3D2CF3E4C996E158LL) <= g_5);
    return l_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_13
 * writes: g_13
 */
static const int64_t  func_18(const int32_t  p_19, int16_t  p_20, int64_t  p_21, uint64_t  p_22)
{ /* block id: 4 */
    uint32_t l_24[7] = {4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL};
    int i;
    for (p_20 = 1; (p_20 <= 6); p_20 += 1)
    { /* block id: 7 */
        for (g_13 = 0; (g_13 <= 6); g_13 += 1)
        { /* block id: 10 */
            int32_t l_25 = 0L;
            int i;
            l_25 |= l_24[p_20];
        }
    }
    return g_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes: g_5
 */
static int32_t  func_26(int32_t  p_27, uint32_t  p_28)
{ /* block id: 18 */
    int32_t l_29[3];
    int i;
    for (i = 0; i < 3; i++)
        l_29[i] = 0xB56095DBL;
    for (g_5 = 0; g_5 < 3; g_5 += 1)
    {
        l_29[g_5] = (-3L);
    }
    return g_5;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 35
XXX times a non-volatile is write: 14
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 25
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 9
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 28.9
XXX percentage an existing variable is used: 71.1
********************* end of statistics **********************/

