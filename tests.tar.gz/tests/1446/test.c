/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9427133224316250242
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int16_t g_7 = 0xA77CL;/* VOLATILE GLOBAL g_7 */
static int32_t g_8 = 0xA2FAFD11L;
static uint8_t g_9 = 0x9BL;
static int64_t g_14[7] = {1L,1L,1L,1L,1L,1L,1L};
static uint16_t g_27 = 65531UL;
static int32_t g_28 = (-10L);
static volatile int16_t g_30 = 0x0998L;/* VOLATILE GLOBAL g_30 */
static uint32_t g_33 = 0xD2321210L;
static uint64_t g_43 = 0xCE695EF2B5D06DE2LL;


/* --- FORWARD DECLARATIONS --- */
static const uint8_t  func_1(void);
static int32_t  func_15(int32_t  p_16, uint32_t  p_17, uint64_t  p_18, uint32_t  p_19);
static const uint64_t  func_22(uint8_t  p_23, uint8_t  p_24, const int32_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_8 g_14 g_9 g_33 g_28 g_43
 * writes: g_8 g_9 g_14 g_27 g_33 g_28 g_43
 */
static const uint8_t  func_1(void)
{ /* block id: 0 */
    const uint32_t l_6 = 1UL;
    g_8 = ((safe_rshift_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(l_6, 0x8C3AL)), 3)) | g_7);
    if ((l_6 != g_7))
    { /* block id: 2 */
        g_9 = (-1L);
    }
    else
    { /* block id: 4 */
        int32_t l_36 = 0x550E8F7CL;
        g_14[2] = (safe_div_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u(g_7, g_8)) != l_6), l_6));
        g_43 ^= func_15(((((safe_mod_func_uint64_t_u_u(func_22(g_14[3], g_9, g_14[5]), g_28)) >= l_36) & l_6) <= g_8), l_6, l_6, l_6);
    }
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_7
 * writes: g_28
 */
static int32_t  func_15(int32_t  p_16, uint32_t  p_17, uint64_t  p_18, uint32_t  p_19)
{ /* block id: 11 */
    int32_t l_41[7];
    int i;
    for (i = 0; i < 7; i++)
        l_41[i] = 0xF7762406L;
    l_41[4] = ((safe_rshift_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(p_19, l_41[1])), p_16)) , (-1L));
    if (p_19)
        goto lbl_42;
lbl_42:
    g_28 ^= (-4L);
    return g_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_33
 * writes: g_27 g_33
 */
static const uint64_t  func_22(uint8_t  p_23, uint8_t  p_24, const int32_t  p_25)
{ /* block id: 6 */
    int8_t l_26 = (-1L);
    int32_t l_29 = 0L;
    int32_t l_31 = 0L;
    int32_t l_32[4] = {(-7L),(-7L),(-7L),(-7L)};
    int i;
    g_27 = ((g_14[5] || p_23) && l_26);
    --g_33;
    l_31 ^= l_29;
    return p_23;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 24
XXX times a non-volatile is write: 9
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 89.2

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 38.1
XXX percentage an existing variable is used: 61.9
********************* end of statistics **********************/

