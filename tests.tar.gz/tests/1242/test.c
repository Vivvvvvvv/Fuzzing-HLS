/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9971441070459729642
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[7][6] = {{1L,0x622BA394L,0x622BA394L,1L,1L,0x622BA394L},{1L,1L,0x622BA394L,0x622BA394L,1L,1L},{1L,0x622BA394L,0x622BA394L,1L,1L,0x622BA394L},{1L,1L,0x622BA394L,0x622BA394L,1L,1L},{1L,0x622BA394L,0x622BA394L,1L,1L,0x622BA394L},{1L,1L,0x622BA394L,0x622BA394L,1L,1L},{1L,0x622BA394L,0x622BA394L,1L,1L,0x622BA394L}};
static int32_t g_13 = 0L;
static int32_t g_26 = 0x4A0435E4L;
static int32_t g_36 = 0xC7F5175DL;
static volatile uint32_t g_37 = 0xE9D3B05EL;/* VOLATILE GLOBAL g_37 */
static int16_t g_58 = 1L;
static uint16_t g_85[9] = {0xBD42L,0xBD42L,0xBD42L,0xBD42L,0xBD42L,0xBD42L,0xBD42L,0xBD42L,0xBD42L};
static volatile uint8_t g_91 = 7UL;/* VOLATILE GLOBAL g_91 */
static uint32_t g_96 = 4UL;
static volatile uint32_t g_120 = 18446744073709551607UL;/* VOLATILE GLOBAL g_120 */
static uint32_t g_129 = 4294967295UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_7(uint32_t  p_8, int16_t  p_9, int32_t  p_10, uint64_t  p_11);
static uint8_t  func_20(const uint8_t  p_21, const uint8_t  p_22);
static const uint8_t  func_40(int64_t  p_41, int8_t  p_42, const uint64_t  p_43, uint32_t  p_44, uint16_t  p_45);
static uint16_t  func_62(uint8_t  p_63, uint16_t  p_64);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_26 g_37 g_36 g_58 g_85 g_91 g_96 g_120 g_129
 * writes: g_26 g_13 g_37 g_58 g_85 g_36 g_91 g_96 g_120 g_2 g_129
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_4 = 1L;
    int32_t l_124[8][4][1] = {{{0xFEE76F71L},{0x4ECD3A2BL},{3L},{(-10L)}},{{3L},{0x4ECD3A2BL},{0xFEE76F71L},{0x4ECD3A2BL}},{{3L},{(-10L)},{3L},{0x4ECD3A2BL}},{{0xFEE76F71L},{0x4ECD3A2BL},{3L},{(-10L)}},{{3L},{0x4ECD3A2BL},{0xFEE76F71L},{0x4ECD3A2BL}},{{3L},{(-10L)},{3L},{0x4ECD3A2BL}},{{0xFEE76F71L},{0x4ECD3A2BL},{3L},{(-10L)}},{{3L},{0x4ECD3A2BL},{0xFEE76F71L},{0x4ECD3A2BL}}};
    int i, j, k;
    if ((g_2[4][5] | 65535UL))
    { /* block id: 1 */
        uint16_t l_3 = 65535UL;
        l_4 = l_3;
        for (l_4 = 2; (l_4 > (-20)); l_4 = safe_sub_func_int16_t_s_s(l_4, 5))
        { /* block id: 5 */
            int32_t l_12 = 0xA7525D2DL;
            g_58 = func_7(l_12, g_2[4][3], l_12, g_13);
            return l_12;
        }
    }
    else
    { /* block id: 32 */
        int32_t l_65 = (-1L);
        l_124[3][3][0] = (((+((safe_lshift_func_uint16_t_u_u(func_62(l_65, g_37), 2)) && 65533UL)) ^ l_65) >= 0x4DL);
        for (g_13 = 0; g_13 < 7; g_13 += 1)
        {
            for (g_120 = 0; g_120 < 6; g_120 += 1)
            {
                g_2[g_13][g_120] = 0x20081CEEL;
            }
        }
        for (g_36 = (-20); (g_36 != (-13)); g_36++)
        { /* block id: 73 */
            int64_t l_127 = (-1L);
            int32_t l_128 = 0xF86A2F89L;
            l_65 = 0L;
            l_128 = ((l_124[6][2][0] > g_58) , l_127);
        }
    }
    --g_129;
    return l_124[3][3][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_26 g_37 g_36
 * writes: g_26 g_13 g_37
 */
static int32_t  func_7(uint32_t  p_8, int16_t  p_9, int32_t  p_10, uint64_t  p_11)
{ /* block id: 6 */
    uint8_t l_18 = 8UL;
    int32_t l_19 = 0x461E7071L;
    if (p_11)
    { /* block id: 7 */
lbl_35:
        l_19 ^= (safe_rshift_func_int8_t_s_s((((safe_div_func_uint8_t_u_u(0x74L, l_18)) ^ 0x1A7A81A8L) <= g_2[3][1]), l_18));
    }
    else
    { /* block id: 9 */
        int16_t l_29[9][2][3] = {{{0L,0x0EB6L,0xA0B2L},{0L,0xCF3EL,0xA5B4L}},{{0xD219L,2L,0x36F9L},{0x0EB6L,0L,0xA5B4L}},{{0L,0xA2AAL,0xA0B2L},{0x603DL,0L,0x2AD9L}},{{0x6947L,0xD219L,0xD219L},{0x6947L,0x2AD9L,0L}},{{0x603DL,0xA0B2L,0xA2AAL},{0L,0xA5B4L,0L}},{{0x0EB6L,0x36F9L,2L},{0xD219L,0xA5B4L,0xCF3EL}},{{0L,0xA0B2L,0x0EB6L},{0L,0x2AD9L,1L}},{{1L,0xD219L,1L},{0L,0L,0x0EB6L}},{{0x6E15L,0xA2AAL,0xCF3EL},{1L,0L,2L}}};
        int32_t l_30 = 0x9919139FL;
        int32_t l_53 = (-1L);
        int i, j, k;
        l_30 ^= ((func_20(g_13, g_2[4][5]) && 0x16L) ^ l_29[6][0][0]);
        l_30 = (!((safe_unary_minus_func_int32_t_s((safe_div_func_uint64_t_u_u(func_20(l_18, p_9), 0x21F5EB7F464F6128LL)))) >= p_8));
        if ((p_10 <= g_13))
        { /* block id: 16 */
            if (p_8)
                goto lbl_35;
            g_37++;
        }
        else
        { /* block id: 19 */
            uint64_t l_46 = 0x7144DB28543B5794LL;
            int32_t l_47 = 3L;
            int32_t l_54 = 0x51DBD7CCL;
            int64_t l_57[3][7][5] = {{{(-1L),0xE161529ABC0A0867LL,1L,1L,8L},{(-9L),9L,(-1L),1L,1L},{1L,0x10273394210AB9CALL,1L,0xE161529ABC0A0867LL,8L},{(-5L),1L,9L,1L,0x60F2F470B9C45D18LL},{8L,(-2L),0x14114C53FB5D6221LL,0x14114C53FB5D6221LL,(-2L)},{(-1L),0x98A7B986AF205A4ALL,9L,0x60F2F470B9C45D18LL,0xA3B2FE4960898429LL},{0x10273394210AB9CALL,1L,1L,0x1D17401D8B2D29C6LL,(-1L)}},{{(-4L),(-1L),(-1L),(-4L),0x237AEE56C84D1B33LL},{0x10273394210AB9CALL,0x14114C53FB5D6221LL,1L,(-1L),0x1D17401D8B2D29C6LL},{(-1L),(-1L),0L,9L,0L},{8L,8L,0x1D17401D8B2D29C6LL,(-1L),1L},{(-5L),1L,0x237AEE56C84D1B33LL,(-4L),(-1L)},{1L,0x1D17401D8B2D29C6LL,(-1L),0x1D17401D8B2D29C6LL,1L},{(-9L),1L,0xA3B2FE4960898429LL,0x60F2F470B9C45D18LL,9L}},{{(-1L),8L,(-2L),0x14114C53FB5D6221LL,0x14114C53FB5D6221LL},{0x60F2F470B9C45D18LL,(-1L),0x60F2F470B9C45D18LL,1L,9L},{(-9L),0x14114C53FB5D6221LL,8L,0xE161529ABC0A0867LL,1L},{9L,(-1L),1L,1L,(-1L)},{(-2L),1L,8L,1L,1L},{(-1L),0x98A7B986AF205A4ALL,0x60F2F470B9C45D18LL,0x237AEE56C84D1B33LL,0L},{8L,0x17640197F5CE9472LL,0x17640197F5CE9472LL,8L,0x10273394210AB9CALL}}};
            int i, j, k;
            l_53 &= func_20(func_40(l_46, p_9, l_46, l_47, l_30), g_26);
            l_54 = func_20(l_47, l_29[6][0][0]);
            l_57[2][2][1] = func_40((safe_sub_func_uint8_t_u_u(g_2[4][5], 1UL)), g_36, g_26, p_10, l_54);
        }
    }
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_26
 * writes: g_26 g_13
 */
static uint8_t  func_20(const uint8_t  p_21, const uint8_t  p_22)
{ /* block id: 10 */
    uint32_t l_25 = 4294967289UL;
    g_26 |= ((((((safe_sub_func_uint8_t_u_u(((p_21 && 0UL) < g_2[1][4]), 4UL)) > g_13) == p_21) , p_22) == 0xA34071E9L) && l_25);
    g_13 = ((safe_rshift_func_int8_t_s_s((g_2[4][5] , (-1L)), 3)) , p_22);
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13
 * writes:
 */
static const uint8_t  func_40(int64_t  p_41, int8_t  p_42, const uint64_t  p_43, uint32_t  p_44, uint16_t  p_45)
{ /* block id: 20 */
    uint16_t l_51 = 65535UL;
    int32_t l_52 = 0x8AC37448L;
    l_52 = (safe_div_func_uint64_t_u_u(((!g_2[4][5]) ^ l_51), p_41));
    return g_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_26 g_13 g_36 g_58 g_37 g_85 g_91 g_96 g_120
 * writes: g_13 g_85 g_36 g_91 g_96 g_120
 */
static uint16_t  func_62(uint8_t  p_63, uint16_t  p_64)
{ /* block id: 33 */
    int32_t l_66 = 0x6BA1441EL;
    int32_t l_103 = (-6L);
    int32_t l_104 = 0x36831ADEL;
    int32_t l_105[10][1][7] = {{{2L,0x4E49CAF0L,1L,(-1L),1L,0x4E49CAF0L,2L}},{{6L,0x432F2B5FL,0xFCAF600DL,(-1L),0xFCAF600DL,0x432F2B5FL,6L}},{{2L,0x4E49CAF0L,1L,(-1L),1L,0x4E49CAF0L,2L}},{{6L,0x432F2B5FL,0xFCAF600DL,(-1L),0xFCAF600DL,0x432F2B5FL,6L}},{{2L,0x4E49CAF0L,1L,(-1L),1L,0x4E49CAF0L,2L}},{{6L,0x432F2B5FL,0xFCAF600DL,(-1L),0xFCAF600DL,0x432F2B5FL,6L}},{{2L,0x4E49CAF0L,1L,(-1L),1L,0x4E49CAF0L,2L}},{{6L,0x432F2B5FL,0xFCAF600DL,(-1L),0xFCAF600DL,0x432F2B5FL,6L}},{{2L,0x4E49CAF0L,1L,(-1L),1L,0x4E49CAF0L,2L}},{{6L,0x432F2B5FL,0xFCAF600DL,(-1L),0xFCAF600DL,0x432F2B5FL,6L}}};
    uint64_t l_123 = 4UL;
    int i, j, k;
    l_66 = ((p_64 && 0xD62130E9L) >= p_64);
    l_66 = (safe_div_func_int16_t_s_s(((safe_sub_func_uint32_t_u_u((safe_add_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(((~(safe_mod_func_int32_t_s_s(1L, g_2[6][1]))) > p_64), g_26)), 0xBFL)), p_64)) ^ g_13), (-1L)));
    if ((safe_div_func_int16_t_s_s((safe_lshift_func_int16_t_s_s((((g_13 | p_63) ^ g_36) >= 0UL), 1)), 65529UL)))
    { /* block id: 36 */
        const int32_t l_84[9][10][2] = {{{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L},{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L}},{{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L},{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L}},{{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L},{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L}},{{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L},{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L}},{{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L},{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L}},{{3L,0L},{(-4L),(-4L)},{(-4L),0L},{3L,8L},{0L,8L},{3L,0L},{(-4L),(-4L)},{(-4L),3L},{(-2L),(-4L)},{3L,(-4L)}},{{(-2L),3L},{0L,0L},{0L,3L},{(-2L),(-4L)},{3L,(-4L)},{(-2L),3L},{0L,0L},{0L,3L},{(-2L),(-4L)},{3L,(-4L)}},{{(-2L),3L},{0L,0L},{0L,3L},{(-2L),(-4L)},{3L,(-4L)},{(-2L),3L},{0L,0L},{0L,3L},{(-2L),(-4L)},{3L,(-4L)}},{{(-2L),3L},{0L,0L},{0L,3L},{(-2L),(-4L)},{3L,(-4L)},{(-2L),3L},{0L,0L},{0L,3L},{(-2L),(-4L)},{3L,(-4L)}}};
        int32_t l_88 = 0xC2983F5DL;
        int32_t l_89 = 4L;
        int i, j, k;
        for (g_13 = 0; (g_13 <= 5); g_13 += 1)
        { /* block id: 39 */
            g_85[1] |= ((safe_add_func_uint16_t_u_u(((0xCFB035B4L > g_26) && l_84[1][0][0]), g_58)) , g_37);
            return p_64;
        }
        for (g_36 = (-24); (g_36 > (-17)); g_36++)
        { /* block id: 45 */
            int32_t l_90 = 0L;
            ++g_91;
            g_13 ^= g_37;
        }
        if ((safe_mul_func_int8_t_s_s(l_89, 0L)))
        { /* block id: 49 */
            return g_26;
        }
        else
        { /* block id: 51 */
            l_88 = p_64;
            --g_96;
        }
    }
    else
    { /* block id: 55 */
        uint16_t l_99[10] = {65528UL,65528UL,65528UL,65528UL,65528UL,65528UL,65528UL,65528UL,65528UL,65528UL};
        int32_t l_100 = (-1L);
        int32_t l_101 = (-1L);
        int32_t l_102 = 0L;
        uint16_t l_106 = 0x2B12L;
        int i;
        g_13 = (g_13 == l_99[9]);
        l_106++;
        g_13 |= (((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_u(((((((p_63 , 1L) >= 1UL) != 0x37L) <= p_64) ^ p_64) , g_37), g_58)), g_85[0])) == p_64) | (-3L));
        return l_66;
    }
    for (l_66 = 26; (l_66 != (-15)); l_66--)
    { /* block id: 63 */
        int32_t l_117 = 0L;
        int32_t l_118 = 0x390B54F4L;
        int32_t l_119[9] = {0xF8BE070EL,0xF8BE070EL,0xF8BE070EL,0xF8BE070EL,0xF8BE070EL,0xF8BE070EL,0xF8BE070EL,0xF8BE070EL,0xF8BE070EL};
        int i;
        l_117 = (((safe_mod_func_int32_t_s_s(9L, p_63)) , (-2L)) > p_64);
        g_120++;
        l_105[0][0][3] = ((((l_117 && p_63) == p_64) < g_85[1]) , l_104);
    }
    return l_123;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_2[i][j], "g_2[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_58, "g_58", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_85[i], "g_85[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 47
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 51
   depth: 2, occurrence: 9
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 6
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 82
XXX times a non-volatile is write: 31
XXX times a volatile is read: 13
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 46
XXX percentage of non-volatile access: 87.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 50
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 19
   depth: 2, occurrence: 16

XXX percentage a fresh-made variable is used: 31.1
XXX percentage an existing variable is used: 68.9
********************* end of statistics **********************/

