/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1805419977578834679
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_2 = 0xB319L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0xA18885C6L;/* VOLATILE GLOBAL g_3 */
static uint8_t g_10 = 255UL;
static int8_t g_11 = 6L;
static uint32_t g_13 = 4294967295UL;
static volatile uint32_t g_15 = 1UL;/* VOLATILE GLOBAL g_15 */
static int8_t g_21 = 1L;
static uint64_t g_23 = 0xBDBAF9EB11DE2A90LL;


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_10 g_13 g_23
 * writes: g_3 g_11 g_13 g_15 g_23
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_9 = 18446744073709551609UL;
    int32_t l_14 = 0xE348CC38L;
    const int64_t l_17 = 0x70ED99EA7EB8E136LL;
    int32_t l_22 = 0x820B275CL;
    const int16_t l_26 = 0xDAACL;
    if (g_2)
    { /* block id: 1 */
        g_3 = g_2;
    }
    else
    { /* block id: 3 */
        const uint64_t l_12 = 0x4B03E3869393DDA3LL;
        g_11 = ((safe_div_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u((~l_9), g_3)), g_10)) <= l_9);
        g_13 = l_12;
        if (g_10)
            goto lbl_18;
        l_14 = (g_2 , g_13);
        g_15 = 0xB0E82CA9L;
    }
lbl_18:
    l_14 = ((safe_unary_minus_func_uint16_t_u((l_17 > g_10))) || (-1L));
    if (l_17)
    { /* block id: 11 */
        const int8_t l_19[4] = {0x42L,0x42L,0x42L,0x42L};
        int i;
        return l_19[0];
    }
    else
    { /* block id: 13 */
        int32_t l_20 = (-9L);
        l_20 = (g_3 || (-8L));
        g_23++;
    }
    return l_26;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 10
XXX times a non-volatile is write: 6
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 12
XXX percentage of non-volatile access: 69.6

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 9

XXX percentage a fresh-made variable is used: 61.5
XXX percentage an existing variable is used: 38.5
********************* end of statistics **********************/

