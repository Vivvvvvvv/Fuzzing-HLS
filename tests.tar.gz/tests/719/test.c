/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3778452954789730366
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 1L;
static volatile int16_t g_38 = 0x446BL;/* VOLATILE GLOBAL g_38 */
static int64_t g_39[8] = {0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL,0x11A53FDE7504ED09LL};
static int8_t g_101[6][5] = {{0x8BL,0x8BL,0x8BL,0x8BL,0x8BL},{1L,1L,1L,1L,1L},{0x8BL,0x8BL,0x8BL,0x8BL,0x8BL},{1L,1L,1L,1L,1L},{0x8BL,0x8BL,0x8BL,0x8BL,0x8BL},{1L,1L,1L,1L,1L}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint8_t  func_11(int32_t  p_12, uint8_t  p_13, int64_t  p_14, uint64_t  p_15, int8_t  p_16);
static int32_t  func_17(uint64_t  p_18, uint32_t  p_19, int32_t  p_20, int8_t  p_21);
static int32_t  func_42(uint8_t  p_43, int64_t  p_44, int32_t  p_45, int8_t  p_46, int16_t  p_47);
static int32_t  func_70(const int32_t  p_71);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_38 g_39 g_101
 * writes: g_2 g_101
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_6 = (-1L);
    int32_t l_78[9] = {0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L,0x8AA3AE43L};
    int16_t l_103[1][3];
    uint8_t l_120 = 0xD1L;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
            l_103[i][j] = 0xF0D8L;
    }
    for (g_2 = 0; (g_2 != 16); g_2++)
    { /* block id: 3 */
        uint32_t l_5 = 4294967295UL;
        return l_5;
    }
    l_6 &= 0xA473EB90L;
lbl_69:
    for (l_6 = (-3); (l_6 > 5); l_6++)
    { /* block id: 9 */
        uint32_t l_22 = 0xB4746A1CL;
        int32_t l_63[5][4] = {{6L,0x8795192CL,0x8795192CL,6L},{1L,0x8795192CL,0xD6285828L,0x8795192CL},{0x8795192CL,0x7C80C7F4L,0xD6285828L,0xD6285828L},{1L,1L,0x8795192CL,0xD6285828L},{6L,0x7C80C7F4L,6L,0x8795192CL}};
        int i, j;
        l_63[0][2] &= (safe_add_func_uint8_t_u_u(func_11(func_17((0x63L & (-2L)), l_22, g_2, l_22), l_22, g_39[1], g_39[1], l_6), l_22));
        for (g_2 = 0; (g_2 < (-3)); g_2--)
        { /* block id: 52 */
            uint32_t l_66 = 0xA1C1E9ADL;
            l_66--;
            if (l_22)
                goto lbl_69;
        }
    }
    if (func_70(g_39[1]))
    { /* block id: 62 */
        int32_t l_87[2][7][2] = {{{0x3D964400L,0xB5A03F75L},{0xB0C68D18L,0xB0C68D18L},{0xB0C68D18L,0xB5A03F75L},{0x3D964400L,0xEC46B6ABL},{0xB5A03F75L,0xEC46B6ABL},{0x3D964400L,0xB5A03F75L},{0xB0C68D18L,0xB0C68D18L}},{{0xB0C68D18L,0xB5A03F75L},{0x3D964400L,0xEC46B6ABL},{0xB5A03F75L,0xEC46B6ABL},{0x3D964400L,0xB5A03F75L},{0xB0C68D18L,0xB0C68D18L},{0xB0C68D18L,0xB5A03F75L},{0x3D964400L,0xEC46B6ABL}}};
        int32_t l_127 = 0xF25E8128L;
        int i, j, k;
lbl_111:
        if ((g_2 , (-1L)))
        { /* block id: 63 */
            uint16_t l_79 = 65535UL;
            l_79--;
            g_2 = (g_39[1] | l_79);
        }
        else
        { /* block id: 66 */
            int64_t l_86 = 0x3F3F2C75BC6281B6LL;
            int32_t l_102 = 0x253AD3D7L;
            g_2 ^= ((safe_mul_func_int16_t_s_s((((safe_sub_func_uint8_t_u_u((l_86 < 6L), g_39[6])) , l_87[1][1][1]) < g_39[1]), 0xC45FL)) , g_39[1]);
            g_101[5][3] |= ((((safe_mod_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((((safe_unary_minus_func_int64_t_s((safe_div_func_uint8_t_u_u(((safe_lshift_func_uint16_t_u_u(((safe_add_func_int8_t_s_s((safe_lshift_func_int8_t_s_u(l_86, 7)), g_38)) < g_39[7]), l_87[0][0][0])) & g_39[6]), l_87[1][1][1])))) , l_87[1][0][0]) , l_87[1][1][1]), l_87[1][1][1])), g_2)) || g_38) ^ 0x2229B2AB39D48F2ALL) < l_87[1][1][1]);
            g_2 ^= (0xB3F5L > 0L);
            if (l_6)
                goto lbl_128;
            l_102 = ((((0x67D4ADD7L >= l_86) <= g_39[1]) == l_86) < (-6L));
        }
        if (((l_87[0][0][1] | (-1L)) && l_103[0][2]))
        { /* block id: 72 */
            int32_t l_104 = (-1L);
            g_2 ^= l_104;
        }
        else
        { /* block id: 74 */
            int16_t l_109 = 0x9F77L;
            int32_t l_110[3];
            int i;
            for (i = 0; i < 3; i++)
                l_110[i] = (-6L);
            l_110[2] &= (safe_add_func_int64_t_s_s((safe_lshift_func_int16_t_s_s(((l_109 , g_38) , (-8L)), 12)), l_78[2]));
            l_110[2] = (9L != g_2);
            if (l_6)
                goto lbl_111;
        }
        g_2 &= g_39[4];
        if ((safe_div_func_int64_t_s_s((safe_div_func_uint32_t_u_u((safe_div_func_int16_t_s_s((l_87[1][1][1] , l_87[1][4][1]), g_101[5][3])), g_39[1])), g_39[1])))
        { /* block id: 80 */
            int32_t l_125 = 6L;
            g_2 |= (safe_mod_func_int8_t_s_s((g_101[1][0] , (-5L)), 0xE4L));
            ++l_120;
            g_2 = ((((safe_rshift_func_int16_t_s_u(5L, g_101[5][3])) > g_2) < l_125) , l_78[6]);
        }
        else
        { /* block id: 84 */
lbl_128:
            l_127 = (+l_87[1][0][0]);
            return g_39[1];
        }
    }
    else
    { /* block id: 89 */
        const uint8_t l_136[3] = {0UL,0UL,0UL};
        int i;
        g_2 ^= (-9L);
        g_2 = (((safe_sub_func_int64_t_s_s((((((safe_sub_func_int16_t_s_s((!(safe_rshift_func_int8_t_s_u(l_136[2], g_2))), 0xCFCAL)) == l_136[2]) || 0xA20D7CEEL) , l_78[2]) , (-1L)), l_103[0][0])) & l_6) >= g_101[5][3]);
    }
    return g_101[5][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_39 g_38 g_2
 * writes: g_2
 */
static uint8_t  func_11(int32_t  p_12, uint8_t  p_13, int64_t  p_14, uint64_t  p_15, int8_t  p_16)
{ /* block id: 25 */
    int16_t l_48 = 0x9126L;
    int32_t l_49 = 0xECAA7054L;
    int32_t l_50 = (-9L);
    l_50 = func_17(func_17(((safe_sub_func_int32_t_s_s(func_42(l_48, p_13, g_39[6], g_38, l_48), g_39[1])) , l_48), l_49, l_48, l_48), g_39[1], p_14, g_39[1]);
    for (l_49 = (-10); (l_49 > 15); l_49++)
    { /* block id: 31 */
        uint64_t l_53[4][5][5] = {{{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL},{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL},{0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL},{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL},{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL}},{{0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL},{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL},{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL},{0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL},{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL}},{{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL},{0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL},{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL},{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL},{0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL}},{{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL},{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL},{0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL},{1UL,0xBF8C32619C85691FLL,0xBF8C32619C85691FLL,1UL,0xBF8C32619C85691FLL},{1UL,1UL,0xB9622CFB64730E92LL,1UL,1UL}}};
        int32_t l_54[4][6] = {{0xA53AA480L,0L,0xA53AA480L,0xA53AA480L,0L,0xA53AA480L},{0xA53AA480L,0L,0xA53AA480L,0xA53AA480L,0L,0xA53AA480L},{0xA53AA480L,0L,0xA53AA480L,0xA53AA480L,0L,0xA53AA480L},{0xA53AA480L,0L,0xA53AA480L,0xA53AA480L,0L,0xA53AA480L}};
        int i, j, k;
        g_2 |= ((g_38 <= 0L) < 18446744073709551615UL);
        l_54[3][1] = l_53[3][2][3];
    }
    for (p_13 = 0; (p_13 == 28); p_13++)
    { /* block id: 37 */
        int32_t l_62 = 0x28D2166AL;
        for (p_15 = 0; (p_15 >= 42); ++p_15)
        { /* block id: 40 */
            int32_t l_59 = 2L;
            if (g_39[1])
                break;
            l_59 = ((9L | p_15) , p_13);
            g_2 = (safe_mod_func_uint64_t_u_u(p_16, p_12));
            l_62 = ((65534UL & l_59) || 6L);
        }
    }
    l_50 = p_16;
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_38
 * writes: g_2
 */
static int32_t  func_17(uint64_t  p_18, uint32_t  p_19, int32_t  p_20, int8_t  p_21)
{ /* block id: 10 */
    uint8_t l_28 = 0UL;
    int64_t l_31[4];
    int i;
    for (i = 0; i < 4; i++)
        l_31[i] = (-1L);
    for (p_19 = 0; (p_19 <= 32); p_19 = safe_add_func_int64_t_s_s(p_19, 9))
    { /* block id: 13 */
        uint8_t l_25[3];
        int i;
        for (i = 0; i < 3; i++)
            l_25[i] = 0xA9L;
        --l_25[1];
        p_20 = (p_18 ^ (-7L));
        l_28++;
    }
    l_31[2] = p_19;
    for (p_19 = 0; (p_19 > 46); p_19++)
    { /* block id: 21 */
        g_2 = ((safe_rshift_func_int8_t_s_u((safe_rshift_func_uint8_t_u_u(((l_31[2] >= g_2) >= p_20), l_31[2])), 2)) , g_38);
    }
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_38
 * writes:
 */
static int32_t  func_42(uint8_t  p_43, int64_t  p_44, int32_t  p_45, int8_t  p_46, int16_t  p_47)
{ /* block id: 26 */
    return g_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static int32_t  func_70(const int32_t  p_71)
{ /* block id: 57 */
    uint32_t l_72 = 0x60A97593L;
    int32_t l_77 = 1L;
    l_72--;
    g_2 = ((safe_sub_func_int8_t_s_s(0x96L, 0L)) , 0xE2BF2DCFL);
    l_77 = (g_2 < l_72);
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_101[i][j], "g_101[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 59
   depth: 2, occurrence: 16
   depth: 3, occurrence: 6
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 97
XXX times a non-volatile is write: 42
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 48
XXX percentage of non-volatile access: 95.2

XXX forward jumps: 2
XXX backward jumps: 1

XXX stmts: 57
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 16
   depth: 2, occurrence: 22

XXX percentage a fresh-made variable is used: 24.6
XXX percentage an existing variable is used: 75.4
********************* end of statistics **********************/

