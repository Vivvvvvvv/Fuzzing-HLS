/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11355502588733351472
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_4 = 0UL;
static int8_t g_16 = 0x90L;


/* --- FORWARD DECLARATIONS --- */
static const int32_t  func_1(void);
static int32_t  func_2(int16_t  p_3);
static uint64_t  func_21(const int32_t  p_22, uint8_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_16
 * writes: g_16
 */
static const int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_28 = (-1L);
    const int8_t l_29 = 0x20L;
    l_28 = func_2(g_4);
    return l_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_16
 * writes: g_16
 */
static int32_t  func_2(int16_t  p_3)
{ /* block id: 1 */
    uint32_t l_15 = 18446744073709551615UL;
    uint32_t l_17[3];
    int32_t l_18 = (-1L);
    int i;
    for (i = 0; i < 3; i++)
        l_17[i] = 18446744073709551615UL;
    g_16 |= (safe_lshift_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_s((safe_rshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s((g_4 , l_15), g_4)), 2)), 7)), 6)) && g_4), g_4));
    l_18 = (l_17[1] , l_17[1]);
    if (g_4)
        goto lbl_25;
lbl_25:
    for (l_15 = 0; (l_15 < 15); l_15 = safe_add_func_uint64_t_u_u(l_15, 4))
    { /* block id: 6 */
        l_18 &= (func_21((p_3 && 0x7E80D68FL), g_16) , p_3);
    }
    for (l_15 = 11; (l_15 > 56); ++l_15)
    { /* block id: 15 */
        return p_3;
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_16
 * writes:
 */
static uint64_t  func_21(const int32_t  p_22, uint8_t  p_23)
{ /* block id: 7 */
    int64_t l_24 = 0xC7AB89BDD7770B16LL;
    l_24 |= p_23;
    return g_16;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 4
   depth: 5, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 18
XXX times a non-volatile is write: 7
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 38.1
XXX percentage an existing variable is used: 61.9
********************* end of statistics **********************/

