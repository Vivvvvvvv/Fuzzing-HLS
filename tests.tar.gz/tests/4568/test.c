/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10251540055513282484
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_5 = 2UL;/* VOLATILE GLOBAL g_5 */
static uint32_t g_6 = 0x248C66F5L;
static int32_t g_32 = 0L;
static uint16_t g_33 = 65528UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_16(const int64_t  p_17, int32_t  p_18, int64_t  p_19, uint8_t  p_20, int16_t  p_21);
static uint16_t  func_25(const uint8_t  p_26, int32_t  p_27);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_33 g_32
 * writes: g_32 g_33
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    const int8_t l_2 = 0xBAL;
    int32_t l_7 = 0x8D3C891CL;
    int8_t l_48 = 0L;
    if (l_2)
    { /* block id: 1 */
        uint8_t l_14 = 252UL;
        int32_t l_15 = 0x1943C6FEL;
        const int32_t l_22 = 2L;
        l_7 = (safe_div_func_int32_t_s_s(g_5, g_6));
        l_15 = (safe_mod_func_uint32_t_u_u((safe_sub_func_uint32_t_u_u((safe_div_func_uint64_t_u_u((1UL | l_2), g_5)), l_14)), g_6));
        g_33 = func_16(l_22, l_2, l_22, l_15, g_6);
        l_15 = (safe_mul_func_int16_t_s_s(0x4FA7L, 0x8FADL));
    }
    else
    { /* block id: 13 */
        int64_t l_42 = 0xB319BD12F8BA7967LL;
        for (g_33 = 0; (g_33 != 30); g_33++)
        { /* block id: 16 */
            g_32 = (safe_sub_func_int8_t_s_s((((safe_lshift_func_int8_t_s_u(((g_33 ^ g_32) > 0x3418L), l_42)) , g_33) > l_2), 4L));
        }
    }
    g_32 &= (safe_add_func_int8_t_s_s((~(safe_sub_func_uint8_t_u_u(((l_7 < g_33) > l_7), g_6))), l_48));
    l_7 = 0xAE202455L;
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_6
 * writes: g_32
 */
static int32_t  func_16(const int64_t  p_17, int32_t  p_18, int64_t  p_19, uint8_t  p_20, int16_t  p_21)
{ /* block id: 4 */
    const uint8_t l_28[3] = {5UL,5UL,5UL};
    int i;
    g_32 = (safe_lshift_func_int16_t_s_u((func_25(l_28[0], g_5) == (-1L)), 13));
    return p_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint16_t  func_25(const uint8_t  p_26, int32_t  p_27)
{ /* block id: 5 */
    int8_t l_29 = 0x65L;
    l_29 |= 0xB42BE197L;
    p_27 = (((safe_lshift_func_int16_t_s_u(((l_29 >= p_27) == 0xE6966EF3L), 0)) || p_26) >= g_6);
    return l_29;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 13
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 29
XXX times a non-volatile is write: 11
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 16
XXX percentage of non-volatile access: 93

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 5
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 31
XXX percentage an existing variable is used: 69
********************* end of statistics **********************/

