/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12150748284561596895
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_4 = 0x8EL;/* VOLATILE GLOBAL g_4 */
static volatile uint64_t g_6 = 0x44AD72D76715F0EDLL;/* VOLATILE GLOBAL g_6 */
static volatile int8_t g_9[10] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
static volatile uint32_t g_10[6][6] = {{0xF4727CADL,0xF4727CADL,0UL,0xF4727CADL,0xF4727CADL,0UL},{0xF4727CADL,0xF4727CADL,0UL,0xF4727CADL,0xF4727CADL,0UL},{0xF4727CADL,0xF4727CADL,0UL,0xF4727CADL,0xF4727CADL,0UL},{0xF4727CADL,0xF4727CADL,0UL,0xF4727CADL,0xF4727CADL,0UL},{0xF4727CADL,0xF4727CADL,0UL,0xF4727CADL,0xF4727CADL,0UL},{0xF4727CADL,0xF4727CADL,0UL,0xF4727CADL,0xF4727CADL,0UL}};
static uint8_t g_17 = 255UL;
static uint32_t g_36 = 0x16FFA942L;
static uint16_t g_37[8][10] = {{0xF7CDL,0x979BL,1UL,0x979BL,0xF7CDL,0xCEC8L,0x2550L,1UL,0UL,0x2550L},{65535UL,8UL,65535UL,65535UL,8UL,0UL,65534UL,65534UL,9UL,0x2550L},{1UL,65535UL,9UL,0xD7A7L,0xF7CDL,65535UL,1UL,65534UL,0x67BAL,0x67BAL},{0x979BL,0x28DBL,65528UL,0x0E06L,0x0E06L,65528UL,0x28DBL,0x979BL,0xCEC8L,65534UL},{65535UL,0x67BAL,1UL,1UL,1UL,8UL,0x979BL,0x67BAL,0UL,0x0E06L},{9UL,65535UL,1UL,1UL,0x28DBL,0x67BAL,1UL,0x979BL,65535UL,9UL},{65535UL,1UL,65528UL,65534UL,0x2550L,5UL,0x2550L,65534UL,65528UL,1UL},{0x0E06L,1UL,9UL,1UL,65534UL,0xD7A7L,1UL,65534UL,8UL,0xF7CDL}};
static int64_t g_41 = (-8L);
static volatile int32_t g_50 = (-3L);/* VOLATILE GLOBAL g_50 */
static volatile uint16_t g_51 = 65528UL;/* VOLATILE GLOBAL g_51 */
static int32_t g_93 = 0xA040150FL;
static uint64_t g_102 = 0x97F7B61520CAD133LL;
static int16_t g_108 = 0xF0F1L;
static volatile int32_t g_109[7][6] = {{0x9488234BL,7L,0x9488234BL,0x46FD8114L,7L,0x8CD9E3A4L},{0x9488234BL,0L,0x46FD8114L,0x46FD8114L,0L,0x9488234BL},{0x9488234BL,(-8L),0x8CD9E3A4L,0x46FD8114L,(-8L),0x46FD8114L},{0x9488234BL,7L,0x9488234BL,0x46FD8114L,7L,0x8CD9E3A4L},{0x9488234BL,0L,0x46FD8114L,0x46FD8114L,0L,0x9488234BL},{0x9488234BL,(-8L),0x8CD9E3A4L,0x46FD8114L,(-8L),0x46FD8114L},{0x9488234BL,7L,0x9488234BL,0x46FD8114L,7L,0x8CD9E3A4L}};
static volatile int64_t g_124[10] = {1L,(-2L),1L,0x20253400617AC7FELL,0x20253400617AC7FELL,1L,(-2L),1L,0x20253400617AC7FELL,0x20253400617AC7FELL};
static uint16_t g_140 = 0x0E64L;
static uint32_t g_168 = 4UL;
static int16_t g_207 = 0x1A52L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_13(const uint32_t  p_14, uint8_t  p_15);
static int32_t  func_28(uint32_t  p_29, uint32_t  p_30, uint32_t  p_31);
static uint64_t  func_61(int32_t  p_62, int16_t  p_63, int32_t  p_64, uint8_t  p_65);
static const uint8_t  func_67(uint16_t  p_68, uint8_t  p_69, uint64_t  p_70, int32_t  p_71);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_17 g_9 g_6 g_36 g_41 g_51 g_37 g_93 g_102 g_140 g_168 g_108 g_50 g_207 g_124 g_109
 * writes: g_6 g_10 g_17 g_36 g_37 g_41 g_51 g_93 g_102 g_140 g_109 g_168 g_207
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_5 = 0xA3L;
    uint32_t l_252[8][9][3] = {{{1UL,0UL,0x7872CC1CL},{0UL,4294967293UL,0UL},{4294967295UL,4294967295UL,0x32A7CD9CL},{0UL,0x64BFC915L,1UL},{1UL,1UL,4294967295UL},{5UL,1UL,9UL},{0xB717930CL,4294967289UL,1UL},{4UL,0xE6FE1DB3L,0x3334BC5BL},{0x4B25155DL,0xB717930CL,1UL}},{{0x31092662L,9UL,9UL},{0xC321AE1DL,4294967295UL,4294967295UL},{0UL,4294967291UL,1UL},{0x1DFFF884L,4294967287UL,0x32A7CD9CL},{1UL,4UL,0UL},{0x9AFFD46FL,4294967287UL,0x7872CC1CL},{4294967293UL,4294967291UL,4294967293UL},{4294967287UL,4294967295UL,0xB717930CL},{1UL,9UL,0UL}},{{0x7872CC1CL,0xB717930CL,0UL},{0xD076DFE5L,0xE6FE1DB3L,5UL},{0xB717930CL,1UL,4294967295UL},{1UL,1UL,0xE6FE1DB3L},{0UL,0x4B25155DL,0UL},{4294967295UL,1UL,1UL},{4294967289UL,0x9AFFD46FL,0x7872CC1CL},{0xD076DFE5L,4294967295UL,1UL},{0xC321AE1DL,0UL,0UL}},{{0xADA582EAL,0x31092662L,0xE6FE1DB3L},{0x32A7CD9CL,4294967295UL,4294967295UL},{0UL,9UL,5UL},{4294967295UL,4294967289UL,0x6671C60AL},{0x64BFC915L,9UL,4294967293UL},{0x0B68F89FL,4294967295UL,0x0B68F89FL},{9UL,0x31092662L,4294967295UL},{0x4B25155DL,0UL,0xB717930CL},{4294967293UL,4294967295UL,0x3334BC5BL}},{{0x1DFFF884L,0x9AFFD46FL,4294967287UL},{4294967293UL,1UL,0xD076DFE5L},{0x4B25155DL,0x4B25155DL,4294967295UL},{9UL,1UL,0UL},{0x0B68F89FL,1UL,0x4B25155DL},{0x64BFC915L,4UL,0UL},{4294967295UL,0x0B68F89FL,0x4B25155DL},{0UL,0UL,0UL},{0x32A7CD9CL,0x1DFFF884L,4294967295UL}},{{0xADA582EAL,0xE6FE1DB3L,0xD076DFE5L},{0xC321AE1DL,0UL,4294967287UL},{0xD076DFE5L,0x64BFC915L,0x3334BC5BL},{4294967289UL,0UL,0xB717930CL},{4294967295UL,0xE6FE1DB3L,4294967295UL},{0UL,0x1DFFF884L,0x0B68F89FL},{1UL,0UL,4294967293UL},{0xB717930CL,0x0B68F89FL,0x6671C60AL},{0x31092662L,4UL,5UL}},{{0xB717930CL,1UL,4294967295UL},{1UL,1UL,0xE6FE1DB3L},{0UL,0x4B25155DL,0UL},{4294967295UL,1UL,1UL},{4294967289UL,0x9AFFD46FL,0x7872CC1CL},{0xD076DFE5L,4294967295UL,1UL},{0xC321AE1DL,0UL,0UL},{0xADA582EAL,0x31092662L,0xE6FE1DB3L},{0x32A7CD9CL,4294967295UL,4294967295UL}},{{0UL,9UL,5UL},{4294967295UL,4294967289UL,0x6671C60AL},{0x64BFC915L,9UL,4294967293UL},{0x0B68F89FL,4294967295UL,0x0B68F89FL},{9UL,0x31092662L,4294967295UL},{0x4B25155DL,0UL,0xB717930CL},{4294967293UL,4294967295UL,0x3334BC5BL},{0x1DFFF884L,0x9AFFD46FL,4294967287UL},{4294967293UL,1UL,0xD076DFE5L}}};
    int i, j, k;
    l_5 ^= ((safe_add_func_int64_t_s_s(g_4, 0xC90A35F394A2A4F4LL)) ^ 0L);
    g_6 = g_4;
    for (l_5 = 0; (l_5 < (-27)); l_5 = safe_sub_func_int8_t_s_s(l_5, 3))
    { /* block id: 5 */
        uint32_t l_16 = 0x54E3F157L;
        g_10[0][1]++;
        g_109[5][1] = func_13((g_10[4][0] ^ l_16), g_17);
        l_252[6][8][0] = ((safe_lshift_func_uint8_t_u_u(((safe_lshift_func_int16_t_s_u(((safe_add_func_uint16_t_u_u(l_16, l_5)) ^ g_102), l_5)) != 0xD415A4D1L), 7)) , l_16);
        g_109[4][3] = (safe_rshift_func_uint16_t_u_u(65530UL, l_252[6][8][0]));
    }
    return g_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_17 g_6 g_10 g_36 g_41 g_51 g_37 g_93 g_102 g_140 g_168 g_108 g_50 g_207 g_124 g_109
 * writes: g_17 g_36 g_37 g_41 g_51 g_93 g_102 g_140 g_109 g_168 g_207
 */
static int32_t  func_13(const uint32_t  p_14, uint8_t  p_15)
{ /* block id: 7 */
    uint8_t l_27 = 0UL;
    int32_t l_210 = 0xDD8A53DBL;
    int32_t l_224[9][9][3] = {{{1L,0L,6L},{0x982563B7L,0x1644C7A8L,0xBC5952B6L},{0xEC9BFAB4L,0xBCC898E3L,7L},{0xBC5952B6L,(-10L),0x38D6969EL},{0xB31E182CL,3L,0x639DAFC3L},{(-1L),0L,0L},{0L,0x2BD49051L,(-5L)},{(-1L),(-1L),0L},{0x73B8AE9CL,(-7L),0xE5CB46C4L}},{{(-7L),0xC66B9BC0L,3L},{0xE8D05733L,(-7L),0xEC9BFAB4L},{(-1L),0x38D6969EL,0x4277A29EL},{7L,0xEC9BFAB4L,0x2BD49051L},{(-8L),0x8A4DB214L,(-6L)},{0xE5CB46C4L,0x08048B8DL,0x29AC428BL},{0xCFB84F57L,4L,3L},{0x9669FE5EL,0x2BD49051L,0x3FB24719L},{(-1L),7L,0x2F6D1966L}},{{0xC9CA45F4L,0x5288B184L,0xB31E182CL},{(-1L),(-1L),0x8605FCFFL},{0x639DAFC3L,0L,0x08048B8DL},{0x8A4DB214L,2L,0x7C35278CL},{(-1L),0x73B8AE9CL,0x6D061A8BL},{(-1L),5L,(-1L)},{0L,(-1L),0xC9CA45F4L},{5L,(-1L),0x1653AFABL},{7L,0x7C9BD7B2L,0x21F283B0L}},{{0xF8FE37CAL,0L,0L},{7L,0xE5CB46C4L,0xFFB94452L},{5L,6L,0x29D3D43AL},{0L,(-8L),0xD03DD026L},{(-1L),0x982563B7L,0L},{(-1L),0xDB78D823L,(-8L)},{0x8A4DB214L,0L,(-1L)},{0x639DAFC3L,0L,0xDDA6B179L},{(-1L),0xC66B9BC0L,0x982563B7L}},{{0xC9CA45F4L,0xE209C98DL,0xE5CB46C4L},{(-1L),0L,(-1L)},{0x9669FE5EL,7L,0L},{0xCFB84F57L,0x4B084057L,0x38D6969EL},{0xE5CB46C4L,1L,0x9669FE5EL},{(-8L),(-8L),6L},{7L,0x639DAFC3L,0xBCC898E3L},{(-1L),0xD85BD37DL,0xF8FE37CAL},{(-1L),0x0BE43CD9L,(-5L)}},{{(-6L),(-1L),0xF8FE37CAL},{0xFFB94452L,0xE8D05733L,0xBCC898E3L},{0x313B4598L,0xBC5952B6L,6L},{(-8L),0L,0x9669FE5EL},{0xC66B9BC0L,0L,0x38D6969EL},{(-5L),0x21F283B0L,0L},{(-7L),(-9L),(-1L)},{0L,6L,0xE5CB46C4L},{0xDD194C20L,(-1L),0x982563B7L}},{{0L,0xB4A01BD5L,0xDDA6B179L},{0x1653AFABL,(-1L),(-1L)},{0xDDA6B179L,0xBCC898E3L,(-8L)},{(-1L),3L,0L},{0xE209C98DL,0xD03DD026L,0xD03DD026L},{9L,0x313B4598L,0x29D3D43AL},{0xEC9BFAB4L,(-1L),0xFFB94452L},{(-10L),(-8L),0L},{0x6D061A8BL,(-9L),0x21F283B0L}},{{0x38D6969EL,(-8L),0x1653AFABL},{0x7C9BD7B2L,(-1L),0xC9CA45F4L},{0L,0x313B4598L,(-1L)},{(-8L),0xD03DD026L,0x6D061A8BL},{0xD85BD37DL,3L,0x7C35278CL},{0x689637CCL,0xBCC898E3L,0x08048B8DL},{1L,(-1L),0x8605FCFFL},{1L,0xB4A01BD5L,0xB31E182CL},{0x4277A29EL,(-1L),0x2F6D1966L}},{{0xE8D05733L,6L,0x3FB24719L},{6L,(-9L),3L},{0xD03DD026L,0x21F283B0L,0xE8D05733L},{0xCFB84F57L,(-10L),0x4B084057L},{0xEC9BFAB4L,(-8L),0xEC9BFAB4L},{(-10L),(-7L),0x8605FCFFL},{(-8L),(-1L),0x36127827L},{(-1L),5L,0x1644C7A8L},{7L,0xB31E182CL,0xD03DD026L}}};
    uint16_t l_245 = 0xED8FL;
    int i, j, k;
    if (g_9[4])
    { /* block id: 8 */
        for (g_17 = 2; (g_17 != 38); g_17++)
        { /* block id: 11 */
            int8_t l_26 = 1L;
            l_27 &= (safe_div_func_uint32_t_u_u(((safe_mod_func_uint8_t_u_u((safe_div_func_int16_t_s_s(g_6, p_15)), l_26)) && 7UL), p_14));
            if (p_14)
                continue;
            if (g_10[3][1])
                break;
        }
        l_210 = func_28((g_9[8] > g_17), p_14, l_27);
    }
    else
    { /* block id: 126 */
        uint32_t l_220 = 18446744073709551607UL;
        int32_t l_221 = 0x81F13F59L;
        int32_t l_222[7] = {0x66F28A5CL,0x66F28A5CL,0x66F28A5CL,0x66F28A5CL,0x66F28A5CL,0x66F28A5CL,0x66F28A5CL};
        int i;
        l_221 = (safe_add_func_uint64_t_u_u(((safe_div_func_int64_t_s_s((safe_rshift_func_uint8_t_u_u(((!(safe_rshift_func_uint16_t_u_s((g_36 > g_51), p_14))) < l_220), 1)), 0x0FD523495DE3CFF6LL)) || 0xFEFA7DB8L), 6L));
        if (p_15)
        { /* block id: 128 */
            return p_14;
        }
        else
        { /* block id: 130 */
            int64_t l_223 = (-8L);
            int32_t l_225 = 0xAA5A505EL;
            uint64_t l_226 = 0x5410983F195CB6CCLL;
            int32_t l_238 = 0xE6016839L;
            int32_t l_239 = 0L;
            int32_t l_240 = 0xB3608916L;
            int32_t l_241[1];
            uint16_t l_242 = 0x1E99L;
            int i;
            for (i = 0; i < 1; i++)
                l_241[i] = 1L;
            g_109[0][4] = (g_51 , l_221);
            l_226++;
            l_225 ^= (safe_add_func_int16_t_s_s((((safe_rshift_func_uint16_t_u_s((~(safe_sub_func_uint8_t_u_u(((((safe_add_func_uint16_t_u_u(p_14, g_37[7][6])) == 4294967295UL) >= g_36) <= p_15), g_124[4]))), 8)) ^ 3UL) > p_15), 0x6DF5L));
            --l_242;
        }
        return l_222[3];
    }
    l_224[0][4][2] = l_245;
    return l_245;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_6 g_36 g_10 g_41 g_51 g_37 g_93 g_102 g_140 g_168 g_108 g_50 g_207 g_124 g_109
 * writes: g_36 g_37 g_41 g_51 g_93 g_102 g_140 g_109 g_168 g_207
 */
static int32_t  func_28(uint32_t  p_29, uint32_t  p_30, uint32_t  p_31)
{ /* block id: 16 */
    uint32_t l_32[4] = {4294967295UL,4294967295UL,4294967295UL,4294967295UL};
    int32_t l_49 = 0xEDF97EF3L;
    int8_t l_186 = (-10L);
    int i;
    if (((((g_9[8] || l_32[2]) || p_29) >= p_31) , p_29))
    { /* block id: 17 */
        int32_t l_35 = 0x818EBCCEL;
        g_36 &= ((safe_lshift_func_uint8_t_u_u(g_6, 7)) || l_35);
        g_37[7][8] = ((g_9[0] == p_30) && p_29);
    }
    else
    { /* block id: 20 */
        int16_t l_46 = 1L;
        int32_t l_47[5];
        int i;
        for (i = 0; i < 5; i++)
            l_47[i] = 0xF3923BFAL;
        for (p_29 = (-24); (p_29 != 32); p_29 = safe_add_func_uint8_t_u_u(p_29, 7))
        { /* block id: 23 */
            uint16_t l_40 = 0xD764L;
            g_41 |= ((((g_10[1][5] | 0xC7F34FA6L) & l_40) || 1UL) ^ 0x5D00L);
        }
        for (p_31 = (-13); (p_31 != 7); p_31 = safe_add_func_uint8_t_u_u(p_31, 5))
        { /* block id: 28 */
            if (p_31)
                break;
        }
        for (p_31 = 0; (p_31 > 47); p_31++)
        { /* block id: 33 */
            int32_t l_48 = 0x365D5A10L;
            l_46 ^= (p_29 || p_29);
            l_47[0] = p_29;
            if (p_31)
                continue;
            l_48 |= (-1L);
        }
        l_49 = 0xD5671665L;
    }
    if (((p_29 , p_31) || 1UL))
    { /* block id: 41 */
lbl_54:
        g_51++;
    }
    else
    { /* block id: 43 */
        if (p_29)
            goto lbl_54;
    }
    for (p_29 = 0; (p_29 == 9); p_29 = safe_add_func_uint8_t_u_u(p_29, 7))
    { /* block id: 48 */
        uint32_t l_66 = 0x56DD1A65L;
        int32_t l_185 = 0x5664DA32L;
        if (l_49)
        { /* block id: 49 */
            uint16_t l_184 = 0xE384L;
            l_49 &= (-2L);
            if (g_36)
                continue;
            l_184 = ((safe_mul_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u(func_61(l_66, l_66, g_37[6][7], l_49), 0x055C058660D6635FLL)) , p_30), l_49)) <= p_30);
            return p_29;
        }
        else
        { /* block id: 109 */
            uint64_t l_187 = 1UL;
            --l_187;
            g_109[0][4] = 0x88D9D7E8L;
            g_109[0][4] = (safe_lshift_func_uint8_t_u_u(((((safe_div_func_int16_t_s_s(0xFC36L, p_30)) != l_32[2]) & (-1L)) || 0UL), g_10[5][3]));
            g_207 &= (safe_sub_func_int8_t_s_s((safe_div_func_int8_t_s_s((safe_add_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(((+(safe_add_func_int64_t_s_s((safe_add_func_uint16_t_u_u(((0x8AL & l_66) , 0x7043L), g_9[8])), 0UL))) , p_29), p_30)), p_30)), p_30)), p_30));
        }
        if (g_50)
            break;
        for (g_140 = (-29); (g_140 != 3); g_140 = safe_add_func_int16_t_s_s(g_140, 8))
        { /* block id: 118 */
            if (g_124[4])
                break;
            if (g_36)
                continue;
        }
        l_185 |= g_109[0][4];
    }
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_51 g_37 g_41 g_10 g_9 g_93 g_102 g_140 g_168 g_108 g_50
 * writes: g_93 g_102 g_140 g_109 g_168
 */
static uint64_t  func_61(int32_t  p_62, int16_t  p_63, int32_t  p_64, uint8_t  p_65)
{ /* block id: 52 */
    uint8_t l_80[8] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
    int32_t l_171 = 4L;
    uint16_t l_172 = 0x36F1L;
    int i;
    l_171 = (((((((func_67(((safe_rshift_func_int16_t_s_s(((safe_sub_func_uint32_t_u_u((safe_div_func_uint32_t_u_u((safe_lshift_func_uint8_t_u_s((p_65 , l_80[4]), 7)), l_80[4])), g_51)) >= 0x2A96L), 0)) & l_80[4]), g_37[7][8], p_65, g_41) == p_64) | 8UL) == l_80[4]) , p_64) == g_108) | 0x85L) <= p_62);
    l_172 = ((p_65 || l_80[3]) <= 1UL);
    for (g_168 = 0; (g_168 != 42); g_168 = safe_add_func_uint8_t_u_u(g_168, 6))
    { /* block id: 96 */
        uint32_t l_175 = 0x7FBA01AEL;
        for (p_62 = 0; (p_62 <= 9); p_62 += 1)
        { /* block id: 99 */
            int i;
            l_175--;
            if (g_9[p_62])
                continue;
            return g_9[p_62];
        }
    }
    g_109[0][4] = (((safe_sub_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u((((((safe_sub_func_uint32_t_u_u(p_64, p_65)) > p_65) , 0x69L) > 1L) > l_171), g_50)) < l_171), p_65)) , p_65) , (-1L));
    return p_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_9 g_41 g_51 g_93 g_102 g_140 g_37 g_168
 * writes: g_93 g_102 g_140 g_109 g_168
 */
static const uint8_t  func_67(uint16_t  p_68, uint8_t  p_69, uint64_t  p_70, int32_t  p_71)
{ /* block id: 53 */
    uint32_t l_85 = 0x73138B78L;
    int32_t l_89 = (-3L);
    int32_t l_113 = (-1L);
    int32_t l_115 = (-8L);
    int32_t l_116 = 1L;
    int32_t l_117 = 0xD533FF6DL;
    int32_t l_122 = 0xEFBA41DAL;
    int32_t l_123 = (-2L);
    int32_t l_125 = 0xF6EF7E69L;
    int32_t l_127 = 1L;
    int32_t l_131 = 1L;
    int32_t l_132 = (-1L);
    int32_t l_133 = (-1L);
    int32_t l_135[10][4][1];
    uint16_t l_136 = 0x3751L;
    int64_t l_148 = 0xF1DAB3D17502D142LL;
    int i, j, k;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 1; k++)
                l_135[i][j][k] = 0xA0135165L;
        }
    }
    for (p_70 = 0; (p_70 > 5); p_70 = safe_add_func_int8_t_s_s(p_70, 3))
    { /* block id: 56 */
        uint32_t l_86 = 0xFA9ADBF8L;
        int32_t l_88 = 0L;
        int32_t l_107 = 1L;
        int32_t l_114 = (-8L);
        int32_t l_118[7][6][3] = {{{0L,(-8L),0L},{0x1BF5FED8L,1L,0x590F8A91L},{0xEDF0E170L,0xEDF0E170L,(-1L)},{(-8L),(-8L),0x59B86C8BL},{0xEDF0E170L,0x1F6C300DL,(-8L)},{0x1BF5FED8L,0x6FD10EC6L,(-5L)}},{{0L,0xEDF0E170L,(-8L)},{0x59B86C8BL,0x16F03433L,0x59B86C8BL},{0xAB8F1B91L,(-8L),(-1L)},{0x1BF5FED8L,0x16F03433L,0x590F8A91L},{0xF04658BAL,0xEDF0E170L,0L},{(-8L),0x6FD10EC6L,0x59B86C8BL}},{{0xF04658BAL,0x1F6C300DL,0x1F6C300DL},{0x1BF5FED8L,(-8L),(-5L)},{0xAB8F1B91L,0xEDF0E170L,0x1F6C300DL},{0x59B86C8BL,1L,0x59B86C8BL},{0L,(-8L),0L},{0x1BF5FED8L,1L,0x590F8A91L}},{{0xEDF0E170L,0xEDF0E170L,(-1L)},{(-8L),(-8L),0x59B86C8BL},{0xEDF0E170L,0x1F6C300DL,(-8L)},{0x1BF5FED8L,0x6FD10EC6L,(-5L)},{0L,0xEDF0E170L,(-8L)},{0x59B86C8BL,0x16F03433L,0x59B86C8BL}},{{0xAB8F1B91L,(-8L),(-1L)},{0x1BF5FED8L,0x16F03433L,0x590F8A91L},{0xF04658BAL,0xEDF0E170L,0L},{(-8L),0x6FD10EC6L,0x59B86C8BL},{0xF04658BAL,0x1F6C300DL,0x1F6C300DL},{0x1BF5FED8L,(-8L),(-5L)}},{{0xAB8F1B91L,0xEDF0E170L,0x1F6C300DL},{0x59B86C8BL,1L,0x59B86C8BL},{0L,(-8L),0L},{0x1BF5FED8L,1L,0x590F8A91L},{0xEDF0E170L,0xEDF0E170L,(-1L)},{(-8L),(-8L),0x59B86C8BL}},{{0xEDF0E170L,0x1F6C300DL,(-8L)},{0x1BF5FED8L,0x6FD10EC6L,(-5L)},{0L,0xEDF0E170L,(-8L)},{0x59B86C8BL,0x16F03433L,0x59B86C8BL},{0xAB8F1B91L,(-8L),(-1L)},{0x1BF5FED8L,0x16F03433L,0x590F8A91L}}};
        int i, j, k;
        l_86 |= (safe_mul_func_int8_t_s_s(g_10[0][4], l_85));
        if (g_9[8])
        { /* block id: 58 */
            uint64_t l_87 = 0x8A52A621C2DF4B1DLL;
            uint32_t l_90[1][4][2] = {{{0x38427463L,0x38427463L},{0x38427463L,0x38427463L},{0x38427463L,0x38427463L},{0x38427463L,0x38427463L}}};
            int i, j, k;
            l_88 = (l_85 < l_87);
            l_90[0][3][1]--;
            g_93 = (g_10[0][1] <= g_41);
        }
        else
        { /* block id: 62 */
            p_71 = (((((safe_unary_minus_func_int32_t_s(p_69)) || p_69) ^ g_51) < g_41) || 0x81L);
        }
        l_89 = g_93;
        if (g_9[8])
        { /* block id: 66 */
            uint64_t l_97 = 0xE3E596A42263F48BLL;
            l_97 = (safe_lshift_func_int8_t_s_u(p_68, 1));
            if (l_85)
                continue;
            if (l_97)
                continue;
        }
        else
        { /* block id: 70 */
            int32_t l_110 = (-1L);
            int32_t l_111 = (-1L);
            int32_t l_112 = 1L;
            int64_t l_119 = 1L;
            int32_t l_120 = 0L;
            int32_t l_121 = 8L;
            int32_t l_126 = (-1L);
            int16_t l_128 = 0xB982L;
            int32_t l_129 = 1L;
            int32_t l_130 = 0xDA59623BL;
            int32_t l_134 = 0xB59DC4BFL;
            l_88 = ((safe_mul_func_int8_t_s_s(((safe_rshift_func_uint8_t_u_s(((8L == 0x4066L) ^ p_69), 7)) == p_68), g_10[4][5])) == p_70);
            g_102++;
            l_89 = (safe_div_func_uint32_t_u_u((0UL < l_107), p_69));
            l_136--;
        }
    }
    g_140 ^= (((!g_10[5][2]) == 0x97DFE4B33A2C9E81LL) <= p_71);
    if ((65535UL | 1UL))
    { /* block id: 78 */
        int8_t l_146 = 0x60L;
        int32_t l_147 = (-2L);
        uint32_t l_149 = 0x170729E3L;
        for (p_69 = 8; (p_69 == 21); ++p_69)
        { /* block id: 81 */
            int8_t l_145 = (-1L);
            g_109[0][4] = ((safe_mul_func_uint8_t_u_u(l_145, l_146)) == 0xDD67387AFFF8E303LL);
        }
        l_147 = p_70;
        --l_149;
    }
    else
    { /* block id: 86 */
        uint16_t l_158 = 0x2409L;
        int32_t l_159 = 0x0FF72A52L;
        int32_t l_160 = 0x06CA934EL;
        int32_t l_161 = 1L;
        int32_t l_162 = 0xD86C3250L;
        int32_t l_163 = 0x32144ED8L;
        int32_t l_164 = 0x84A157F9L;
        int32_t l_165 = (-1L);
        int32_t l_166 = 0L;
        int32_t l_167[2];
        int i;
        for (i = 0; i < 2; i++)
            l_167[i] = 0L;
        l_158 = (safe_mod_func_int64_t_s_s((safe_mod_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((0x7E6CEEB8BFCC7844LL == g_10[0][0]), l_131)), g_37[5][0])), 1UL));
        l_159 = ((l_158 || 0xAFL) > p_71);
        --g_168;
    }
    return p_69;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_10[i][j], "g_10[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_37[i][j], "g_37[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_109[i][j], "g_109[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_124[i], "g_124[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_168, "g_168", print_hash_value);
    transparent_crc(g_207, "g_207", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 102
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 98
   depth: 2, occurrence: 19
   depth: 3, occurrence: 9
   depth: 4, occurrence: 1
   depth: 5, occurrence: 6
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 123
XXX times a non-volatile is write: 52
XXX times a volatile is read: 31
XXX    times read thru a pointer: 0
XXX times a volatile is write: 10
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 130
XXX percentage of non-volatile access: 81

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 91
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 32
   depth: 2, occurrence: 39

XXX percentage a fresh-made variable is used: 28
XXX percentage an existing variable is used: 72
********************* end of statistics **********************/

