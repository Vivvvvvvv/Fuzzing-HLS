/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18000417194165322958
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint8_t  f0;
   int32_t  f1;
   int16_t  f2;
   int16_t  f3;
   volatile uint64_t  f4;
   volatile int16_t  f5;
};

struct S1 {
   const uint8_t  f0;
   const int32_t  f1;
   volatile uint16_t  f2;
   int64_t  f3;
   uint8_t  f4;
   int64_t  f5;
   const uint16_t  f6;
   volatile uint16_t  f7;
   int32_t  f8;
};

/* --- GLOBAL VARIABLES --- */
static const uint8_t g_14[5] = {3UL,3UL,3UL,3UL,3UL};
static int64_t g_20[7][1] = {{0x5F88E10E5E53494ALL},{0x5F88E10E5E53494ALL},{0x5F88E10E5E53494ALL},{0x5F88E10E5E53494ALL},{0x5F88E10E5E53494ALL},{0x5F88E10E5E53494ALL},{0x5F88E10E5E53494ALL}};
static volatile uint8_t g_26 = 252UL;/* VOLATILE GLOBAL g_26 */
static uint8_t g_30 = 0x55L;
static struct S0 g_31 = {1UL,-8L,0x8642L,0x5F0EL,0x7DA19AE86A67606ELL,0L};/* VOLATILE GLOBAL g_31 */
static struct S0 g_37[2][6] = {{{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L}},{{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L},{255UL,0xE197B2C3L,-1L,0L,8UL,0xB1F0L}}};
static uint8_t g_58 = 0UL;
static volatile uint32_t g_61[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static volatile uint32_t g_64[2][6] = {{0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L},{0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L,0x4FD34EA0L}};
static uint32_t g_70[6][1] = {{0x90C34EF3L},{0x90C34EF3L},{0xA4A205A5L},{0xA4A205A5L},{0xA4A205A5L},{4294967295UL}};
static const volatile struct S0 g_73 = {249UL,0xC2DE0B6AL,-10L,0xCFC8L,0xC047C65310EE7DBBLL,0xCB25L};/* VOLATILE GLOBAL g_73 */
static volatile struct S0 g_74[8][3] = {{{0x89L,0x50AD34F8L,0xFC5DL,0L,18446744073709551612UL,0x6A19L},{7UL,0xCA868CE9L,0x7CFDL,1L,18446744073709551608UL,1L},{0x89L,0x50AD34F8L,0xFC5DL,0L,18446744073709551612UL,0x6A19L}},{{0x92L,0x73BCDA42L,0L,0x563FL,0xC15673F556C05CDALL,8L},{0x6CL,0x3996C8B9L,-1L,0x26B9L,0xDBBE02B323EC0817LL,0xF2A7L},{0x6CL,0x3996C8B9L,-1L,0x26B9L,0xDBBE02B323EC0817LL,0xF2A7L}},{{0x6CL,1L,0x7618L,0x417FL,6UL,0xEE0EL},{7UL,0xCA868CE9L,0x7CFDL,1L,18446744073709551608UL,1L},{0x6CL,1L,0x7618L,0x417FL,6UL,0xEE0EL}},{{0x92L,0x73BCDA42L,0L,0x563FL,0xC15673F556C05CDALL,8L},{0x92L,0x73BCDA42L,0L,0x563FL,0xC15673F556C05CDALL,8L},{0x6CL,0x3996C8B9L,-1L,0x26B9L,0xDBBE02B323EC0817LL,0xF2A7L}},{{0x89L,0x50AD34F8L,0xFC5DL,0L,18446744073709551612UL,0x6A19L},{7UL,0xCA868CE9L,0x7CFDL,1L,18446744073709551608UL,1L},{0x89L,0x50AD34F8L,0xFC5DL,0L,18446744073709551612UL,0x6A19L}},{{0x92L,0x73BCDA42L,0L,0x563FL,0xC15673F556C05CDALL,8L},{0x6CL,0x3996C8B9L,-1L,0x26B9L,0xDBBE02B323EC0817LL,0xF2A7L},{0x6CL,0x3996C8B9L,-1L,0x26B9L,0xDBBE02B323EC0817LL,0xF2A7L}},{{0x6CL,1L,0x7618L,0x417FL,6UL,0xEE0EL},{7UL,0xCA868CE9L,0x7CFDL,1L,18446744073709551608UL,1L},{0x6CL,1L,0x7618L,0x417FL,6UL,0xEE0EL}},{{0x92L,0x73BCDA42L,0L,0x563FL,0xC15673F556C05CDALL,8L},{0x92L,0x73BCDA42L,0L,0x563FL,0xC15673F556C05CDALL,8L},{0x6CL,0x3996C8B9L,-1L,0x26B9L,0xDBBE02B323EC0817LL,0xF2A7L}}};
static volatile uint32_t g_83 = 0UL;/* VOLATILE GLOBAL g_83 */
static uint32_t g_96[9][8] = {{0x8FE829D6L,18446744073709551607UL,0x1A46AFD1L,18446744073709551607UL,0x8FE829D6L,0x0A5FE3C0L,0x8FE829D6L,18446744073709551607UL},{18446744073709551608UL,18446744073709551607UL,18446744073709551608UL,0x1E0ADED1L,0x8FE829D6L,0x1E0ADED1L,18446744073709551608UL,18446744073709551607UL},{0x8FE829D6L,0x1E0ADED1L,18446744073709551608UL,18446744073709551607UL,18446744073709551608UL,0x1E0ADED1L,0x8FE829D6L,0x1E0ADED1L},{0x8FE829D6L,18446744073709551607UL,0x1A46AFD1L,18446744073709551607UL,0x8FE829D6L,0x0A5FE3C0L,0x8FE829D6L,18446744073709551607UL},{18446744073709551608UL,18446744073709551607UL,18446744073709551608UL,0x1E0ADED1L,0x8FE829D6L,0x1E0ADED1L,18446744073709551608UL,18446744073709551607UL},{0x8FE829D6L,0x1E0ADED1L,18446744073709551608UL,18446744073709551607UL,18446744073709551608UL,0x1E0ADED1L,0x8FE829D6L,0x1E0ADED1L},{0x8FE829D6L,18446744073709551607UL,0x1A46AFD1L,18446744073709551607UL,0x8FE829D6L,0x0A5FE3C0L,0x8FE829D6L,18446744073709551607UL},{18446744073709551608UL,18446744073709551607UL,18446744073709551608UL,0x1E0ADED1L,0x8FE829D6L,0x1E0ADED1L,18446744073709551608UL,18446744073709551607UL},{0x8FE829D6L,0x1E0ADED1L,18446744073709551608UL,18446744073709551607UL,18446744073709551608UL,0x1E0ADED1L,0x8FE829D6L,0x1E0ADED1L}};
static uint16_t g_121 = 65535UL;
static uint64_t g_124[8] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static uint32_t g_132[9] = {0x7B70EE5EL,1UL,0x7B70EE5EL,0x7B70EE5EL,1UL,0x7B70EE5EL,0x7B70EE5EL,1UL,0x7B70EE5EL};
static uint64_t g_138 = 3UL;
static struct S0 g_146[10] = {{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L},{249UL,0x8399E06EL,0xFA80L,1L,0UL,0x3699L}};
static struct S0 g_147[6][4] = {{{0x71L,0L,0x826BL,0L,0x9AE0601FEE91F21FLL,1L},{2UL,1L,0x74B8L,0xA730L,0x5CEBA1A22EDFD8EELL,0x61C6L},{0xCEL,0x062863D5L,0xA883L,-9L,0UL,0xF0D6L},{0x5FL,0L,0x38DCL,0xF510L,9UL,-1L}},{{0xAEL,-1L,0x40DFL,0x3A39L,0x6D4906CFE17A9C68LL,-1L},{0x71L,0L,0x826BL,0L,0x9AE0601FEE91F21FLL,1L},{0x9CL,3L,0x7455L,0xD828L,18446744073709551615UL,0xBF86L},{0x71L,0xE4816DB7L,0xB35FL,0x9D68L,0x53D3BC77A5DD5B36LL,0xF52EL}},{{255UL,0xA5ACE6E7L,-4L,0x4189L,0x61142FEC1ED602CCLL,0L},{0xEEL,0xF412CFCAL,9L,0x43ABL,18446744073709551613UL,8L},{255UL,0xA5ACE6E7L,-4L,0x4189L,0x61142FEC1ED602CCLL,0L},{0x71L,0xE4816DB7L,0xB35FL,0x9D68L,0x53D3BC77A5DD5B36LL,0xF52EL}},{{0x9CL,3L,0x7455L,0xD828L,18446744073709551615UL,0xBF86L},{0x71L,0L,0x826BL,0L,0x9AE0601FEE91F21FLL,1L},{0xAEL,-1L,0x40DFL,0x3A39L,0x6D4906CFE17A9C68LL,-1L},{0x5FL,0L,0x38DCL,0xF510L,9UL,-1L}},{{0xCEL,0x062863D5L,0xA883L,-9L,0UL,0xF0D6L},{2UL,1L,0x74B8L,0xA730L,0x5CEBA1A22EDFD8EELL,0x61C6L},{0x71L,0L,0x826BL,0L,0x9AE0601FEE91F21FLL,1L},{0x71L,0L,0x826BL,0L,0x9AE0601FEE91F21FLL,1L}},{{0x9FL,-5L,0x4947L,0xA416L,0xBCE5CCE37DA2B038LL,0x2427L},{0x9FL,-5L,0x4947L,0xA416L,0xBCE5CCE37DA2B038LL,0x2427L},{0x71L,0L,0x826BL,0L,0x9AE0601FEE91F21FLL,1L},{255UL,0xA5ACE6E7L,-4L,0x4189L,0x61142FEC1ED602CCLL,0L}}};
static volatile struct S1 g_148 = {2UL,-1L,0xF6C0L,0x2D7C546D17D0ED01LL,0x52L,1L,0xC457L,65535UL,0L};/* VOLATILE GLOBAL g_148 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint8_t  func_4(const uint32_t  p_5, const int32_t  p_6);
static int32_t  func_15(int16_t  p_16, int8_t  p_17, const int64_t  p_18);
static struct S0  func_23(const uint16_t  p_24, int16_t  p_25);
static int32_t  func_40(int8_t  p_41);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_20 g_26 g_31 g_37 g_61 g_30 g_64 g_70 g_73 g_83 g_96 g_121 g_74.f5 g_74.f3 g_146 g_148
 * writes: g_26 g_30 g_31.f1 g_58 g_61 g_64 g_70 g_74 g_83 g_96 g_121 g_124 g_132 g_138 g_147 g_31.f3 g_148.f8
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_13 = 0xE2L;
    int32_t l_131 = 0L;
    int32_t l_139[4] = {6L,6L,6L,6L};
    uint32_t l_167 = 0x29E6F036L;
    int i;
    l_131 = ((safe_sub_func_uint32_t_u_u((func_4((safe_lshift_func_int16_t_s_u((safe_add_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u(l_13, (-7L))) <= l_13), g_14[0])), 15)), l_13) , l_13), (-1L))) == 1UL);
    for (l_131 = 2; (l_131 >= 0); l_131 -= 1)
    { /* block id: 77 */
        volatile uint16_t l_133 = 0x2E1CL;/* VOLATILE GLOBAL l_133 */
        for (l_13 = 0; (l_13 <= 0); l_13 += 1)
        { /* block id: 80 */
            int i, j;
            g_132[4] = (g_20[(l_13 + 6)][l_13] > g_74[3][1].f3);
            if (g_31.f0)
                break;
            l_133 = g_64[0][4];
            g_138 = (((((safe_sub_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(((((g_74[3][1].f5 >= g_20[(l_13 + 6)][l_13]) , (-1L)) , l_133) , 0UL), 1L)), 5UL)) <= 1L) > 0x26L) | g_96[6][7]) && g_20[(l_13 + 6)][l_13]);
        }
        l_139[0] ^= ((l_13 >= g_73.f2) , l_133);
        g_147[4][3] = ((((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(l_133, 6)), 0x6FB1L)), g_96[6][7])) || g_31.f3) <= g_96[5][3]) , g_146[3]);
        for (g_31.f3 = 0; (g_31.f3 <= 0); g_31.f3 += 1)
        { /* block id: 90 */
            uint8_t l_155 = 0xFBL;
            g_148.f8 = (g_148 , l_133);
            g_148.f8 = (safe_mul_func_int8_t_s_s((safe_div_func_uint8_t_u_u((((g_148 , l_13) & 0xA654L) , 5UL), (-7L))), (-1L)));
            g_148.f8 = ((func_23((safe_div_func_int64_t_s_s(l_13, l_155)), l_133) , 0x6AC2A144L) && 6L);
        }
    }
    for (g_31.f1 = 0; (g_31.f1 > 21); g_31.f1 = safe_add_func_uint64_t_u_u(g_31.f1, 4))
    { /* block id: 98 */
        uint32_t l_166[9] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
        int i;
        g_148.f8 = (l_131 | g_148.f6);
        g_148.f8 = (-6L);
        l_167 = (safe_sub_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u((safe_div_func_uint64_t_u_u((safe_lshift_func_int8_t_s_u((-1L), 7)), l_13)), l_13)) >= l_166[3]), l_166[3]));
    }
    return l_139[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_20 g_26 g_31 g_37 g_61 g_30 g_64 g_70 g_73 g_83 g_96 g_121 g_74.f5
 * writes: g_26 g_30 g_31.f1 g_58 g_61 g_64 g_70 g_74 g_83 g_96 g_121 g_124
 */
static uint8_t  func_4(const uint32_t  p_5, const int32_t  p_6)
{ /* block id: 1 */
    int8_t l_19 = 1L;
    int32_t l_116 = 0L;
lbl_129:
    if (func_15(g_14[0], l_19, g_14[4]))
    { /* block id: 52 */
        uint64_t l_122 = 0UL;
        int32_t l_123 = 0x884B0028L;
        for (g_31.f1 = (-1); (g_31.f1 <= 17); g_31.f1++)
        { /* block id: 55 */
            uint32_t l_115 = 4294967290UL;
            l_115 = g_96[6][7];
            l_116 = 0x40F3B8A4L;
            g_121 ^= (((((safe_rshift_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s(l_19, 13)), 9)) , l_116) | l_115) || l_115) > l_115);
        }
        l_123 = l_122;
        g_124[4] = (g_37[0][4].f3 > g_73.f2);
        l_123 = (((safe_lshift_func_int16_t_s_u(((-5L) != 1UL), l_123)) ^ 65532UL) | 2L);
    }
    else
    { /* block id: 63 */
        l_116 |= p_5;
    }
    for (l_19 = 0; (l_19 > 15); l_19 = safe_add_func_uint32_t_u_u(l_19, 9))
    { /* block id: 68 */
        uint64_t l_130 = 0xF47E08CFFC910CF3LL;
        if (g_31.f3)
            goto lbl_129;
        l_130 = ((g_74[3][1].f5 , p_6) && g_37[0][4].f5);
        if (l_116)
            goto lbl_129;
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_20 g_26 g_31 g_14 g_37 g_61 g_30 g_64 g_70 g_73 g_83 g_96
 * writes: g_26 g_30 g_31.f1 g_58 g_61 g_64 g_70 g_74 g_83 g_96
 */
static int32_t  func_15(int16_t  p_16, int8_t  p_17, const int64_t  p_18)
{ /* block id: 2 */
    const uint16_t l_77 = 0UL;
    int32_t l_78 = 0xB59C6DFEL;
    int32_t l_101 = (-9L);
    int8_t l_112 = 9L;
    for (p_17 = 0; (p_17 >= 0); p_17 -= 1)
    { /* block id: 5 */
        int8_t l_38 = (-3L);
        int32_t l_39 = 0xA513E67DL;
        for (p_16 = 0; (p_16 <= 0); p_16 += 1)
        { /* block id: 8 */
            int32_t l_32 = 0x9BB643C8L;
            l_32 = (((safe_mod_func_int8_t_s_s((((func_23(p_16, g_20[1][0]) , 0x70E74BB9CEC02DFCLL) ^ p_16) >= g_31.f3), g_14[0])) | g_31.f1) || g_31.f4);
        }
        for (g_31.f1 = 0; (g_31.f1 >= 0); g_31.f1 -= 1)
        { /* block id: 17 */
            int8_t l_46[10][8] = {{0L,0xDFL,1L,6L,1L,0xDFL,0L,1L},{2L,0x61L,0x43L,2L,0x37L,0x39L,0x61L,0x61L},{1L,0x37L,0xB5L,0xB5L,0x37L,1L,0xE2L,6L},{2L,0xE2L,(-1L),0x61L,0x39L,0xA9L,0xDFL,0xA9L},{1L,(-1L),0x37L,(-1L),1L,0x61L,(-1L),0xE2L},{0x43L,1L,0x39L,0xB4L,(-1L),0x43L,0x43L,(-1L)},{0xB5L,0x39L,0x39L,0xB5L,6L,0xA9L,(-1L),0x39L},{(-1L),0xDFL,0x37L,0xE2L,0xDFL,2L,0xDFL,0xE2L},{0xA9L,0xDFL,0xA9L,0x39L,(-1L),0xA9L,6L,0xB5L},{1L,0x39L,0xB4L,(-1L),0x43L,0x43L,(-1L),0xB4L}};
            int i, j;
            l_39 = (safe_rshift_func_int16_t_s_s((safe_div_func_int16_t_s_s((((g_31.f3 , p_17) , g_37[0][4]) , g_37[0][4].f5), l_38)), g_14[0]));
            l_39 = func_40(((((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((((l_46[1][7] && g_37[0][4].f4) & p_18) , p_16) == 18446744073709551615UL), g_31.f1)), 0x37BAL)) ^ l_46[8][4]) > l_38) <= p_17));
            g_74[3][1] = g_73;
        }
    }
    l_78 = (safe_mod_func_uint8_t_u_u(l_77, p_17));
    for (p_16 = 9; (p_16 > 24); p_16 = safe_add_func_uint16_t_u_u(p_16, 2))
    { /* block id: 40 */
        uint64_t l_111 = 0UL;
        if ((safe_mul_func_uint8_t_u_u(g_37[0][4].f1, p_18)))
        { /* block id: 41 */
            uint32_t l_95 = 0x10488480L;
            --g_83;
            l_95 = (safe_div_func_uint16_t_u_u((+(safe_div_func_int32_t_s_s((safe_mul_func_int16_t_s_s((safe_sub_func_uint32_t_u_u((p_18 , 0x4279E96FL), p_18)), 1UL)), 0xD647035FL))), p_18));
            g_96[6][7] |= (p_18 > 4294967295UL);
        }
        else
        { /* block id: 45 */
            uint8_t l_102 = 0x80L;
            l_102 = ((safe_mul_func_int16_t_s_s(((safe_mod_func_int16_t_s_s((p_16 == 3UL), l_101)) | 0x996EL), 0x553DL)) >= g_31.f0);
        }
        l_78 |= (safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(((g_30 , p_16) <= 0L), 0x08E988613543D046LL)), 3)), 0UL));
        l_112 = (safe_mul_func_int16_t_s_s(l_111, p_17));
    }
    return l_101;
}


/* ------------------------------------------ */
/* 
 * reads : g_26 g_31
 * writes: g_26 g_30
 */
static struct S0  func_23(const uint16_t  p_24, int16_t  p_25)
{ /* block id: 9 */
    uint8_t l_29 = 247UL;
    g_26--;
    g_30 = ((l_29 & (-1L)) & p_24);
    return g_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_31.f5 g_20 g_31.f2 g_61 g_30 g_64 g_70
 * writes: g_58 g_61 g_30 g_64 g_70
 */
static int32_t  func_40(int8_t  p_41)
{ /* block id: 19 */
    uint32_t l_47 = 0x66072949L;
    int32_t l_48 = 7L;
    int32_t l_59 = 0xC80F86AEL;
    l_48 = l_47;
    if ((safe_add_func_int64_t_s_s(0x42739A3A415DBE4BLL, 0xE44E821FD1B63E3BLL)))
    { /* block id: 21 */
        int16_t l_57 = 0xD624L;
        int32_t l_60 = 0x9FE4D3D8L;
        g_58 = (safe_mod_func_int16_t_s_s((~((safe_mod_func_int8_t_s_s(((safe_unary_minus_func_uint32_t_u(((l_57 & g_31.f5) <= 18446744073709551615UL))) , g_20[1][0]), l_57)) & l_57)), g_31.f2));
        g_61[1]++;
        for (g_30 = 0; (g_30 <= 0); g_30 += 1)
        { /* block id: 26 */
            --g_64[1][5];
        }
    }
    else
    { /* block id: 29 */
        int64_t l_67 = 0x691A67D55137C5FDLL;
        int32_t l_68 = 0x9C78C3D2L;
        int32_t l_69[3][7][9] = {{{0x78261C1CL,(-1L),4L,0x3C44AE9DL,0L,0xA13A23B1L,0xA13A23B1L,0L,0x3C44AE9DL},{1L,(-1L),1L,2L,1L,(-3L),0x10498C5DL,1L,(-6L)},{0x10498C5DL,0L,2L,(-6L),7L,0L,0x0F45F4D9L,1L,0xBAC11434L},{7L,0x10498C5DL,5L,2L,0x8E1FC50AL,0L,(-1L),1L,(-1L)},{1L,(-1L),2L,0x3C44AE9DL,0xDF11712DL,0x4CAA1C64L,0xD73FCFB2L,0L,0L},{0x3C44AE9DL,7L,0L,0xBAC11434L,8L,0x766912E2L,0L,(-3L),2L},{(-3L),1L,0L,0x34167AD2L,0xA06A03D0L,(-2L),0xDF11712DL,(-1L),0x78261C1CL}},{{(-1L),0L,2L,(-1L),0x36320CFAL,0x36320CFAL,(-1L),2L,0L},{4L,(-6L),5L,(-6L),0L,2L,0L,0xA13A23B1L,2L},{0xA06A03D0L,0L,2L,0x120E7A9FL,(-2L),0L,0x6E384D56L,1L,0x5FDE22B7L},{(-8L),(-6L),1L,0L,(-6L),0L,5L,0xD73FCFB2L,1L},{2L,0L,4L,1L,0L,0x5C0EDEAEL,0x78261C1CL,(-1L),(-1L)},{0xBAC11434L,1L,0xD9658AA4L,(-1L),(-1L),0L,0L,(-1L),1L},{0xBAC11434L,7L,0L,0L,1L,(-6L),0L,0xA06A03D0L,0x5C0EDEAEL}},{{2L,(-1L),0L,0L,0L,0L,(-1L),2L,0xCE3E23DEL},{(-8L),0x10498C5DL,0L,0x4CAA1C64L,(-1L),0x36320CFAL,1L,4L,2L},{0xBAC11434L,0x5FDE22B7L,(-6L),2L,(-8L),0x0F45F4D9L,8L,0x8E1FC50AL,7L},{0x0F45F4D9L,(-9L),0x10498C5DL,0x6E384D56L,(-3L),0L,0L,(-1L),(-8L)},{0x5C0EDEAEL,0x6E384D56L,0xA06A03D0L,(-6L),0L,0xF0D9F09FL,1L,0xA13A23B1L,1L},{(-1L),0x120E7A9FL,(-1L),(-1L),8L,0x6E384D56L,0xD9658AA4L,0xA13A23B1L,0x5C0EDEAEL},{1L,0xBAC11434L,(-2L),8L,0x120E7A9FL,0L,(-6L),(-1L),(-6L)}}};
        int i, j, k;
        --g_70[2][0];
    }
    return p_41;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_20[i][j], "g_20[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31.f0, "g_31.f0", print_hash_value);
    transparent_crc(g_31.f1, "g_31.f1", print_hash_value);
    transparent_crc(g_31.f2, "g_31.f2", print_hash_value);
    transparent_crc(g_31.f3, "g_31.f3", print_hash_value);
    transparent_crc(g_31.f4, "g_31.f4", print_hash_value);
    transparent_crc(g_31.f5, "g_31.f5", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_37[i][j].f0, "g_37[i][j].f0", print_hash_value);
            transparent_crc(g_37[i][j].f1, "g_37[i][j].f1", print_hash_value);
            transparent_crc(g_37[i][j].f2, "g_37[i][j].f2", print_hash_value);
            transparent_crc(g_37[i][j].f3, "g_37[i][j].f3", print_hash_value);
            transparent_crc(g_37[i][j].f4, "g_37[i][j].f4", print_hash_value);
            transparent_crc(g_37[i][j].f5, "g_37[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_58, "g_58", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_61[i], "g_61[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_64[i][j], "g_64[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_70[i][j], "g_70[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_73.f0, "g_73.f0", print_hash_value);
    transparent_crc(g_73.f1, "g_73.f1", print_hash_value);
    transparent_crc(g_73.f2, "g_73.f2", print_hash_value);
    transparent_crc(g_73.f3, "g_73.f3", print_hash_value);
    transparent_crc(g_73.f4, "g_73.f4", print_hash_value);
    transparent_crc(g_73.f5, "g_73.f5", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_74[i][j].f0, "g_74[i][j].f0", print_hash_value);
            transparent_crc(g_74[i][j].f1, "g_74[i][j].f1", print_hash_value);
            transparent_crc(g_74[i][j].f2, "g_74[i][j].f2", print_hash_value);
            transparent_crc(g_74[i][j].f3, "g_74[i][j].f3", print_hash_value);
            transparent_crc(g_74[i][j].f4, "g_74[i][j].f4", print_hash_value);
            transparent_crc(g_74[i][j].f5, "g_74[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_83, "g_83", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_96[i][j], "g_96[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_121, "g_121", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_124[i], "g_124[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_132[i], "g_132[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_138, "g_138", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_146[i].f0, "g_146[i].f0", print_hash_value);
        transparent_crc(g_146[i].f1, "g_146[i].f1", print_hash_value);
        transparent_crc(g_146[i].f2, "g_146[i].f2", print_hash_value);
        transparent_crc(g_146[i].f3, "g_146[i].f3", print_hash_value);
        transparent_crc(g_146[i].f4, "g_146[i].f4", print_hash_value);
        transparent_crc(g_146[i].f5, "g_146[i].f5", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_147[i][j].f0, "g_147[i][j].f0", print_hash_value);
            transparent_crc(g_147[i][j].f1, "g_147[i][j].f1", print_hash_value);
            transparent_crc(g_147[i][j].f2, "g_147[i][j].f2", print_hash_value);
            transparent_crc(g_147[i][j].f3, "g_147[i][j].f3", print_hash_value);
            transparent_crc(g_147[i][j].f4, "g_147[i][j].f4", print_hash_value);
            transparent_crc(g_147[i][j].f5, "g_147[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_148.f0, "g_148.f0", print_hash_value);
    transparent_crc(g_148.f1, "g_148.f1", print_hash_value);
    transparent_crc(g_148.f2, "g_148.f2", print_hash_value);
    transparent_crc(g_148.f3, "g_148.f3", print_hash_value);
    transparent_crc(g_148.f4, "g_148.f4", print_hash_value);
    transparent_crc(g_148.f5, "g_148.f5", print_hash_value);
    transparent_crc(g_148.f6, "g_148.f6", print_hash_value);
    transparent_crc(g_148.f7, "g_148.f7", print_hash_value);
    transparent_crc(g_148.f8, "g_148.f8", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 46
   depth: 1, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 59
   depth: 2, occurrence: 20
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 7
   depth: 7, occurrence: 3
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 92
XXX times a non-volatile is write: 38
XXX times a volatile is read: 22
XXX    times read thru a pointer: 0
XXX times a volatile is write: 11
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 55
XXX percentage of non-volatile access: 79.8

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 60
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 24
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 36.1
XXX percentage an existing variable is used: 63.9
********************* end of statistics **********************/

