/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14869943701375674898
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_6 = 0L;
static int64_t g_17 = (-1L);
static uint8_t g_18 = 2UL;
static volatile uint32_t g_19 = 0UL;/* VOLATILE GLOBAL g_19 */
static int64_t g_23 = 0xA445A8CCEDB7758BLL;
static int8_t g_25 = 0L;
static uint32_t g_28 = 18446744073709551609UL;
static uint32_t g_29 = 1UL;
static uint16_t g_30 = 0xE67EL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static const int32_t  func_2(uint8_t  p_3, const uint16_t  p_4, int64_t  p_5);
static uint16_t  func_7(uint16_t  p_8);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_17 g_18 g_19
 * writes: g_6 g_17 g_18 g_19 g_23 g_25 g_28 g_29 g_30
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_24[7];
    int i;
    for (i = 0; i < 7; i++)
        l_24[i] = 65526UL;
    if (func_2(g_6, g_6, g_6))
    { /* block id: 17 */
        return g_17;
    }
    else
    { /* block id: 19 */
        int32_t l_22 = 0x2F1E5C8AL;
        g_23 = (l_22 >= 0x4BL);
        for (g_18 = 0; (g_18 <= 6); g_18 += 1)
        { /* block id: 23 */
            int i;
            g_25 = l_24[g_18];
            g_28 = (safe_add_func_uint8_t_u_u(l_24[g_18], l_24[g_18]));
            g_29 = l_24[g_18];
            g_30 = ((l_22 < l_24[3]) >= 252UL);
        }
        return g_6;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_17 g_18 g_19
 * writes: g_6 g_17 g_18 g_19
 */
static const int32_t  func_2(uint8_t  p_3, const uint16_t  p_4, int64_t  p_5)
{ /* block id: 1 */
    int8_t l_11 = 5L;
    int32_t l_12 = 0L;
    l_12 &= ((func_7((safe_mod_func_int64_t_s_s((7L && 0x020BD2ABL), g_6))) , 18446744073709551615UL) <= l_11);
    for (g_6 = 7; (g_6 > 21); g_6++)
    { /* block id: 7 */
        for (p_5 = (-13); (p_5 == (-12)); p_5 = safe_add_func_int32_t_s_s(p_5, 3))
        { /* block id: 10 */
            g_17 &= 0x0357257EL;
            g_18 |= ((p_5 < p_5) & g_17);
        }
        ++g_19;
    }
    return l_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint16_t  func_7(uint16_t  p_8)
{ /* block id: 2 */
    return g_6;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 11
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 97.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 6
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

