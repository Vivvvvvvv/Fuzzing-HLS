/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5610524971330339572
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_2 = 0x7C7CE53DL;
static uint16_t g_24 = 0x653BL;
static uint16_t g_27[6] = {1UL,1UL,1UL,1UL,1UL,1UL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_3(uint32_t  p_4, uint8_t  p_5, int8_t  p_6);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_24
 * writes: g_2 g_24 g_27
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_7 = 0xC8D3C891C5534BF8LL;
    int32_t l_26[3];
    int i;
    for (i = 0; i < 3; i++)
        l_26[i] = 0x051DD2E9L;
    g_2 ^= 0xEA5D6C05L;
    l_26[2] = func_3(g_2, g_2, l_7);
    g_27[3] = g_2;
    return l_26[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_24
 * writes: g_24
 */
static int32_t  func_3(uint32_t  p_4, uint8_t  p_5, int8_t  p_6)
{ /* block id: 2 */
    int32_t l_8 = 0xBF2121F9L;
    int32_t l_9 = 1L;
    int32_t l_10 = (-7L);
    int32_t l_11 = 0x54320E32L;
    int32_t l_12 = (-8L);
    int32_t l_13 = 1L;
    int32_t l_14 = (-4L);
    int32_t l_15[3];
    uint64_t l_16 = 0UL;
    int i;
    for (i = 0; i < 3; i++)
        l_15[i] = 0x3C6FE23AL;
lbl_25:
    l_16++;
    for (l_12 = 0; (l_12 >= 9); l_12 = safe_add_func_int16_t_s_s(l_12, 1))
    { /* block id: 6 */
        for (l_10 = 2; (l_10 >= 0); l_10 -= 1)
        { /* block id: 9 */
            int i;
            l_15[l_10] = ((safe_lshift_func_int16_t_s_u((~l_15[l_10]), 10)) , l_11);
            if (p_5)
                break;
            g_24 |= (0x39EE491BA6B42BE1LL == 1L);
        }
    }
    if (l_12)
        goto lbl_25;
    l_9 = ((p_5 > p_4) < 0x193FE6966EF3B063LL);
    return p_6;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_27[i], "g_27[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 1
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 56
XXX percentage an existing variable is used: 44
********************* end of statistics **********************/

