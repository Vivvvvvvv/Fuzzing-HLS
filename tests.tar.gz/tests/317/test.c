/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1944572777842484263
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_2[8] = {0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL};
static volatile int32_t g_3 = (-3L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = 0xD8E6E838L;
static volatile int32_t g_46[9] = {4L,(-1L),(-1L),4L,(-1L),(-1L),4L,(-1L),(-1L)};
static int16_t g_59 = 9L;
static int32_t g_81[3] = {0xA213425BL,0xA213425BL,0xA213425BL};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_6(int64_t  p_7, int32_t  p_8, uint8_t  p_9);
static uint64_t  func_10(uint32_t  p_11, int64_t  p_12, int32_t  p_13, int32_t  p_14, int32_t  p_15);
static int32_t  func_19(int16_t  p_20, uint32_t  p_21, int8_t  p_22);
static int32_t  func_25(const uint32_t  p_26, int16_t  p_27);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_2 g_3 g_46 g_59 g_81
 * writes: g_4 g_3 g_46 g_59 g_81
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_16 = 0UL;
    int32_t l_112[8][7] = {{0L,(-3L),1L,0xCB7726CCL,0L,(-8L),0xD3DFD4C6L},{(-9L),(-8L),(-1L),(-3L),(-3L),(-1L),(-8L)},{0xD3DFD4C6L,0x9AA81E76L,1L,(-9L),(-3L),(-1L),0L},{1L,0L,0x9AA81E76L,0x13F38231L,0L,1L,0x9AA81E76L},{0x27C866F7L,0L,(-1L),(-1L),0L,0x27C866F7L,(-1L)},{0L,0x9AA81E76L,(-1L),0x13F38231L,(-8L),0xE154AAB1L,0L},{0xE154AAB1L,1L,0L,0x27C866F7L,(-9L),0L,(-9L)},{(-8L),0x9AA81E76L,0x9AA81E76L,(-8L),0x09C40381L,0x13F38231L,1L}};
    int64_t l_132 = 1L;
    int32_t l_133 = 0xA7359817L;
    uint8_t l_143 = 255UL;
    int i, j;
    for (g_4 = 0; (g_4 <= 7); g_4 += 1)
    { /* block id: 3 */
        int32_t l_5[6][9] = {{0x2B74C38BL,6L,0xE1ABE8F2L,(-5L),(-5L),0xE1ABE8F2L,6L,0x2B74C38BL,0xE1ABE8F2L},{0x2B74C38BL,6L,0xE1ABE8F2L,(-5L),(-5L),0xE1ABE8F2L,6L,0x2B74C38BL,0xE1ABE8F2L},{0x2B74C38BL,6L,0xE1ABE8F2L,(-5L),(-5L),0xE1ABE8F2L,6L,0x2B74C38BL,0xE1ABE8F2L},{0x2B74C38BL,6L,0xE1ABE8F2L,(-5L),(-5L),0xE1ABE8F2L,6L,0x2B74C38BL,0xE1ABE8F2L},{0x2B74C38BL,6L,0xE1ABE8F2L,(-5L),(-5L),0xE1ABE8F2L,6L,0x2B74C38BL,0xE1ABE8F2L},{0x2B74C38BL,6L,0xE1ABE8F2L,(-5L),(-5L),0xE1ABE8F2L,6L,0x2B74C38BL,0xE1ABE8F2L}};
        int i, j;
        l_5[0][2] = g_2[g_4];
        g_81[0] = (func_6((func_10(l_16, l_5[0][2], l_16, l_5[5][4], g_3) , g_59), g_2[6], l_5[3][2]) ^ 1UL);
        for (l_16 = 0; (l_16 <= 7); l_16 += 1)
        { /* block id: 84 */
            int16_t l_107[2][3][5] = {{{1L,0L,(-1L),(-1L),0L},{0L,0xC7B2L,0x72F0L,0x72F0L,0xC7B2L},{1L,0L,(-1L),(-1L),0L}},{{0L,0xC7B2L,0x72F0L,0x72F0L,0xC7B2L},{1L,0L,(-1L),(-1L),0L},{0L,0xC7B2L,0x72F0L,0x72F0L,0xC7B2L}}};
            int i, j, k;
            return l_107[0][2][2];
        }
        if (g_81[2])
            continue;
    }
    for (g_4 = 2; (g_4 >= 0); g_4 -= 1)
    { /* block id: 91 */
        int16_t l_108 = (-2L);
        uint8_t l_119 = 0UL;
        if (l_108)
        { /* block id: 92 */
            int i;
            if (g_3)
                break;
            g_81[g_4] = (safe_unary_minus_func_int64_t_s((safe_mod_func_uint64_t_u_u(g_59, l_16))));
            g_46[(g_4 + 6)] = ((g_4 == l_112[1][5]) , g_81[0]);
        }
        else
        { /* block id: 96 */
            uint64_t l_116 = 0x3DB9FBB92E1E2695LL;
            int i;
            g_46[g_4] = (safe_div_func_uint32_t_u_u((~((7UL != g_2[2]) , l_116)), l_116));
            g_46[(g_4 + 5)] = (l_116 > g_4);
            l_119 = (safe_div_func_uint8_t_u_u((g_81[0] | l_108), g_46[2]));
        }
    }
    if (((+(safe_add_func_uint32_t_u_u(((~(safe_add_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((safe_div_func_int32_t_s_s(((safe_rshift_func_uint16_t_u_s((g_46[7] , 0x8739L), 10)) && 1L), l_112[7][1])), 0xF96F6E79L)), l_132))) > 0x971FE1FCL), g_2[6]))) < l_133))
    { /* block id: 102 */
        uint64_t l_134 = 0x2AAD255A8A431967LL;
        int32_t l_138 = (-9L);
        int32_t l_145 = 0x7B0E3E12L;
        uint64_t l_146 = 0UL;
        uint32_t l_149 = 0x5AF43916L;
        if (((g_4 != g_4) != g_81[0]))
        { /* block id: 103 */
            int16_t l_137 = (-7L);
            l_112[1][5] = (((1L ^ l_134) >= g_3) || 1L);
            l_112[2][1] = (!(((~((l_137 && l_132) , 0UL)) ^ 0xD12CL) , l_137));
            l_112[1][5] = (-1L);
            l_138 = ((l_112[1][5] , (-1L)) , 0L);
        }
        else
        { /* block id: 108 */
            l_112[3][0] = g_4;
        }
        for (l_138 = 27; (l_138 >= 21); --l_138)
        { /* block id: 113 */
            int16_t l_144[3][9] = {{0xB9DCL,(-1L),1L,1L,(-1L),0xB9DCL,(-1L),1L,1L},{(-1L),(-1L),0xB9DCL,1L,0xB9DCL,(-1L),(-1L),0xB9DCL,1L},{0xC3DCL,(-1L),0xC3DCL,0xB9DCL,0xB9DCL,0xC3DCL,(-1L),0xC3DCL,0xB9DCL}};
            int i, j;
            l_143 = ((safe_div_func_uint64_t_u_u(g_81[1], g_46[4])) , 0L);
            ++l_146;
            l_149++;
        }
    }
    else
    { /* block id: 118 */
        int16_t l_154[8];
        int i;
        for (i = 0; i < 8; i++)
            l_154[i] = 1L;
        for (g_4 = 24; (g_4 > (-29)); --g_4)
        { /* block id: 121 */
            uint16_t l_155 = 0x9BF0L;
            l_155 |= l_154[1];
            if (g_81[0])
                continue;
            g_3 ^= (safe_mod_func_uint8_t_u_u((+((1L ^ 0xD2F0B0CE8927BEDCLL) == l_155)), l_112[7][5]));
        }
        l_112[1][5] = (safe_rshift_func_int8_t_s_s((safe_add_func_int32_t_s_s((safe_mod_func_uint64_t_u_u((0x4956L == g_81[0]), 4UL)), 0x6BD49ADAL)), g_59));
        return l_132;
    }
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_81
 * writes:
 */
static int8_t  func_6(int64_t  p_7, int32_t  p_8, uint8_t  p_9)
{ /* block id: 78 */
    uint16_t l_106[6][9][4] = {{{0UL,2UL,65533UL,0UL},{0x32FEL,0x552DL,1UL,0UL},{5UL,2UL,4UL,0x8589L},{65526UL,6UL,65535UL,0UL},{0UL,0UL,0x8589L,65526UL},{5UL,0UL,5UL,4UL},{2UL,65528UL,65533UL,0UL},{65528UL,0UL,0x552DL,65528UL},{0xB1B1L,65526UL,0x552DL,0x8589L}},{{65528UL,0UL,65533UL,2UL},{2UL,0x552DL,5UL,0x32FEL},{5UL,0x32FEL,0x8589L,0x8589L},{0UL,0UL,65526UL,0UL},{0xB1B1L,1UL,0xF3C2L,5UL},{0x4872L,0UL,1UL,0xF3C2L},{0x5475L,0UL,6UL,5UL},{0UL,1UL,65535UL,0UL},{65535UL,1UL,1UL,0x6906L}},{{0xEE11L,0x5475L,6UL,0x5475L},{0x8589L,65533UL,65535UL,4UL},{0x4872L,0x8589L,0xA0BBL,0x6906L},{5UL,0xB1B1L,65526UL,0x552DL},{5UL,1UL,0xA0BBL,1UL},{0x4872L,0x552DL,65535UL,0xF3C2L},{0x8589L,0xEE11L,6UL,0xB1B1L},{0xEE11L,1UL,1UL,0xEE11L},{65535UL,5UL,65535UL,0x6906L}},{{0UL,4UL,6UL,0x8589L},{0x5475L,65533UL,1UL,0x8589L},{0x4872L,4UL,0xF3C2L,0x6906L},{0xB1B1L,5UL,65526UL,0xEE11L},{1UL,1UL,0x6906L,0xB1B1L},{0x4872L,0xEE11L,0x4872L,0xF3C2L},{4UL,0x552DL,6UL,1UL},{0x552DL,1UL,65533UL,0x552DL},{65535UL,0xB1B1L,65533UL,0x6906L}},{{0x552DL,0x8589L,6UL,4UL},{4UL,65533UL,0x4872L,0x5475L},{0x4872L,0x5475L,0x6906L,0x6906L},{1UL,1UL,65526UL,0UL},{0xB1B1L,1UL,0xF3C2L,5UL},{0x4872L,0UL,1UL,0xF3C2L},{0x5475L,0UL,6UL,5UL},{0UL,1UL,65535UL,0UL},{65535UL,1UL,1UL,0x6906L}},{{0xEE11L,0x5475L,6UL,0x5475L},{0x8589L,65533UL,65535UL,4UL},{0x4872L,0x8589L,0xA0BBL,0x6906L},{5UL,0xB1B1L,65526UL,0x552DL},{5UL,1UL,0xA0BBL,1UL},{0x4872L,0x552DL,65535UL,0xF3C2L},{0x8589L,0xEE11L,6UL,0xB1B1L},{0xEE11L,1UL,1UL,0xEE11L},{65535UL,5UL,65535UL,0x6906L}}};
    int i, j, k;
    l_106[5][6][0] = (-8L);
    return g_81[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_4 g_46 g_59 g_81
 * writes: g_3 g_46 g_59 g_81
 */
static uint64_t  func_10(uint32_t  p_11, int64_t  p_12, int32_t  p_13, int32_t  p_14, int32_t  p_15)
{ /* block id: 5 */
    uint32_t l_23[3];
    uint16_t l_24 = 0x0859L;
    int i;
    for (i = 0; i < 3; i++)
        l_23[i] = 8UL;
    p_14 = (safe_mod_func_int32_t_s_s(1L, 4294967287UL));
    p_14 = func_19(l_23[0], l_24, p_11);
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_4 g_46 g_59 g_81
 * writes: g_3 g_46 g_59 g_81
 */
static int32_t  func_19(int16_t  p_20, uint32_t  p_21, int8_t  p_22)
{ /* block id: 7 */
    int16_t l_32[9][5] = {{0x3765L,2L,0x3765L,2L,0x3765L},{(-1L),(-1L),(-1L),(-1L),(-1L)},{0x3765L,2L,0x3765L,2L,0x3765L},{(-1L),(-1L),(-1L),(-1L),(-1L)},{0x3765L,2L,0x3765L,2L,0x3765L},{(-1L),(-1L),(-1L),(-1L),(-1L)},{0x3765L,2L,0x3765L,2L,0x3765L},{(-1L),(-1L),(-1L),(-1L),(-1L)},{0x3765L,2L,0x3765L,2L,0x3765L}};
    int32_t l_89 = 0x64697844L;
    int32_t l_94 = 0xED5DE960L;
    int32_t l_95 = 0xF7E15FDCL;
    int32_t l_97 = 0x6282F370L;
    int32_t l_99 = 0L;
    int32_t l_100 = 5L;
    uint64_t l_102[8][9][2] = {{{1UL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{0xCF5B4EFAD5DA70D9LL,6UL},{0xCF5B4EFAD5DA70D9LL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{1UL,8UL},{0x51C69C4B1219C124LL,1UL},{0xC78FC4A0ED782E0DLL,0x51C69C4B1219C124LL},{0x51C69C4B1219C124LL,6UL}},{{1UL,0xCF5B4EFAD5DA70D9LL},{0xC78FC4A0ED782E0DLL,18446744073709551609UL},{0xCF5B4EFAD5DA70D9LL,8UL},{0xCF5B4EFAD5DA70D9LL,18446744073709551609UL},{0xC78FC4A0ED782E0DLL,0xCF5B4EFAD5DA70D9LL},{1UL,6UL},{0x51C69C4B1219C124LL,0x51C69C4B1219C124LL},{0xC78FC4A0ED782E0DLL,1UL},{0x51C69C4B1219C124LL,8UL}},{{1UL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{0xCF5B4EFAD5DA70D9LL,6UL},{0xCF5B4EFAD5DA70D9LL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{1UL,8UL},{0x51C69C4B1219C124LL,1UL},{0xC78FC4A0ED782E0DLL,0x51C69C4B1219C124LL},{0x51C69C4B1219C124LL,6UL}},{{1UL,0xCF5B4EFAD5DA70D9LL},{0xC78FC4A0ED782E0DLL,18446744073709551609UL},{0xCF5B4EFAD5DA70D9LL,8UL},{0xCF5B4EFAD5DA70D9LL,18446744073709551609UL},{0xC78FC4A0ED782E0DLL,0xCF5B4EFAD5DA70D9LL},{1UL,6UL},{0x51C69C4B1219C124LL,0x51C69C4B1219C124LL},{0xC78FC4A0ED782E0DLL,1UL},{0x51C69C4B1219C124LL,8UL}},{{1UL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{0xCF5B4EFAD5DA70D9LL,6UL},{0xCF5B4EFAD5DA70D9LL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{1UL,8UL},{0x51C69C4B1219C124LL,1UL},{0xC78FC4A0ED782E0DLL,0x51C69C4B1219C124LL},{0x51C69C4B1219C124LL,6UL}},{{1UL,0xCF5B4EFAD5DA70D9LL},{0xC78FC4A0ED782E0DLL,18446744073709551609UL},{0xCF5B4EFAD5DA70D9LL,8UL},{0xCF5B4EFAD5DA70D9LL,18446744073709551609UL},{0xC78FC4A0ED782E0DLL,0xCF5B4EFAD5DA70D9LL},{1UL,6UL},{0x51C69C4B1219C124LL,0x51C69C4B1219C124LL},{0xC78FC4A0ED782E0DLL,1UL},{0x51C69C4B1219C124LL,8UL}},{{1UL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{0xCF5B4EFAD5DA70D9LL,6UL},{0xCF5B4EFAD5DA70D9LL,1UL},{0xC78FC4A0ED782E0DLL,1UL},{1UL,8UL},{0x51C69C4B1219C124LL,1UL},{0xC78FC4A0ED782E0DLL,0x51C69C4B1219C124LL},{0x51C69C4B1219C124LL,6UL}},{{1UL,0xCF5B4EFAD5DA70D9LL},{0xC78FC4A0ED782E0DLL,18446744073709551609UL},{0xCF5B4EFAD5DA70D9LL,8UL},{0xCF5B4EFAD5DA70D9LL,18446744073709551609UL},{0xC78FC4A0ED782E0DLL,0xCF5B4EFAD5DA70D9LL},{1UL,6UL},{0x51C69C4B1219C124LL,0x51C69C4B1219C124LL},{0xC78FC4A0ED782E0DLL,1UL},{0x51C69C4B1219C124LL,8UL}}};
    int i, j, k;
    if (func_25((safe_add_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((0xAAL < 255UL), 0xFD47030FL)), l_32[2][1])), l_32[1][3]))
    { /* block id: 62 */
        for (p_21 = 0; (p_21 != 6); p_21 = safe_add_func_int8_t_s_s(p_21, 6))
        { /* block id: 65 */
            uint8_t l_90 = 9UL;
            int32_t l_93 = 0xD3A23B2AL;
            int64_t l_96 = 8L;
            int32_t l_98 = 0L;
            int32_t l_101 = (-1L);
            ++l_90;
            if (l_90)
                continue;
            ++l_102[4][1][0];
        }
        g_81[1] = 0xB8E4492BL;
        l_94 = (g_3 <= p_20);
    }
    else
    { /* block id: 72 */
        int64_t l_105 = 0x03A4C91E03B00BEALL;
        return l_105;
    }
    return g_46[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_4 g_46 g_59 g_81
 * writes: g_3 g_46 g_59 g_81
 */
static int32_t  func_25(const uint32_t  p_26, int16_t  p_27)
{ /* block id: 8 */
    uint32_t l_39[6][7][6] = {{{0UL,4294967286UL,4294967295UL,4294967289UL,0UL,0xD242EC21L},{0x8243C00EL,2UL,0x00669673L,4294967295UL,0xAEA4CC78L,0UL},{0x4F583EF4L,0x6684E8D7L,0x68D37D67L,0UL,1UL,1UL},{0xF5132FC9L,0x66B31915L,0x66B31915L,0xF5132FC9L,4294967293UL,4294967295UL},{1UL,0UL,1UL,0x50227CDBL,4294967295UL,0xD5269945L},{4294967290UL,1UL,0x5A46E494L,0UL,4294967295UL,0x114AC9FDL},{0xF9020C5AL,0x84A57988L,3UL,4294967287UL,8UL,4294967292UL}},{{0x6ABB57DDL,0x52276C1FL,0xEA6DE452L,0UL,0xCEBB36E9L,0xDE3FC80CL},{0x3DF49156L,4294967290UL,1UL,0x37E2CA82L,0x50227CDBL,0x2C22A665L},{0xFEDE048FL,4294967287UL,0xE2D0B182L,0x99C015C4L,1UL,0xE9EE1947L},{0UL,0x37E2CA82L,0xAEA4CC78L,0x8243C00EL,0UL,0x4F583EF4L},{0xCEBB36E9L,1UL,0x84A57988L,0x2C22A665L,0x9E541960L,4294967295UL},{4294967288UL,4294967292UL,0x50227CDBL,0xCC0D6813L,0xC19AB5AAL,4294967292UL},{0x3E8E036BL,1UL,0xF5132FC9L,0xDDFA37A4L,0xC3345720L,4294967295UL}},{{4294967287UL,4294967292UL,4294967292UL,0UL,0x66B31915L,4294967288UL},{0x827CF573L,0xE9EE1947L,0x1FD29CC0L,0x923552E2L,4294967295UL,0x939845F0L},{0x2C22A665L,0xDDFA37A4L,0xA59A115EL,1UL,1UL,1UL},{1UL,1UL,0x3E8E036BL,0x6ABB57DDL,0x923552E2L,0xF9020C5AL},{1UL,0xAA2DF500L,0xA424ACDFL,0x114AC9FDL,0x63FCCFB4L,1UL},{4294967295UL,0x923552E2L,0x0F9CF50EL,1UL,4294967292UL,0xF5132FC9L},{0xABC5D6BBL,0xC3345720L,0x8243C00EL,5UL,0x2C22A665L,1UL}},{{0xC3345720L,0xCC0D6813L,1UL,0x66B31915L,1UL,0x66B31915L},{1UL,1UL,1UL,0x0F9CF50EL,4294967295UL,4294967295UL},{0x1FD29CC0L,6UL,1UL,4294967289UL,0xEA6DE452L,0xA59A115EL},{0x3B016FEFL,0x6684E8D7L,2UL,4294967289UL,4294967292UL,0x0F9CF50EL},{0x1FD29CC0L,0xA424ACDFL,0x20F54F73L,0x0F9CF50EL,0xDDFA37A4L,4294967287UL},{1UL,0xFEDE048FL,0xCE3BADF3L,0x66B31915L,0xA59A115EL,1UL},{0xC3345720L,4294967287UL,4294967295UL,5UL,0UL,0UL}},{{0xABC5D6BBL,1UL,0xDE3FC80CL,1UL,0UL,0x3E8E036BL},{4294967295UL,4294967289UL,6UL,0x114AC9FDL,0x9052196DL,6UL},{1UL,1UL,6UL,0x6ABB57DDL,4294967290UL,1UL},{1UL,0x3E8E036BL,4294967294UL,1UL,1UL,1UL},{0x2C22A665L,0xE61A645CL,5UL,0x923552E2L,0x7682C5A4L,4294967295UL},{0x827CF573L,0x20F54F73L,0xD5269945L,0UL,0xA424ACDFL,0x63FCCFB4L},{4294967287UL,0xA59A115EL,6UL,0xDDFA37A4L,0xABC5D6BBL,0x47EC8A5EL}},{{0x3E8E036BL,0x63FCCFB4L,0x9E541960L,0xCC0D6813L,0x00669673L,1UL},{4294967288UL,4294967286UL,4294967293UL,0x114AC9FDL,3UL,0xE61A645CL},{1UL,1UL,0xEA6DE452L,1UL,0x00669673L,4294967295UL},{1UL,1UL,1UL,6UL,0UL,1UL},{4294967295UL,0x0F9CF50EL,0x37E2CA82L,4294967290UL,4UL,4294967292UL},{4294967295UL,0x9E541960L,0UL,4294967286UL,4294967286UL,0UL},{4294967295UL,4294967295UL,4294967295UL,4294967295UL,0xD5269945L,4294967287UL}}};
    int32_t l_58 = 1L;
    int32_t l_83 = 0L;
    int i, j, k;
    if (((((safe_mul_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s(((((safe_mod_func_int8_t_s_s((((-7L) & p_26) | g_2[4]), g_2[5])) | g_3) != l_39[4][2][0]) | g_4), 6)) >= g_4), p_26)) < 0xB13CFF85525C537FLL) & 252UL) || 65535UL))
    { /* block id: 9 */
        uint64_t l_42[1];
        int32_t l_45 = (-1L);
        int i;
        for (i = 0; i < 1; i++)
            l_42[i] = 0x0A01C1786B757CFBLL;
        if ((g_4 & 0x34L))
        { /* block id: 10 */
            uint32_t l_40 = 18446744073709551615UL;
            int32_t l_41[7][1];
            int i, j;
            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 1; j++)
                    l_41[i][j] = 0x62A5332CL;
            }
            g_3 = ((l_39[4][2][0] <= l_40) , 0x6F110B0FL);
            l_41[1][0] = (p_26 > p_26);
        }
        else
        { /* block id: 13 */
            return l_42[0];
        }
        l_45 = ((safe_sub_func_int16_t_s_s(((l_39[4][2][0] , p_27) >= g_2[6]), g_3)) <= 0x17126B21CEB8AB48LL);
    }
    else
    { /* block id: 17 */
        uint64_t l_47[6];
        int i;
        for (i = 0; i < 6; i++)
            l_47[i] = 18446744073709551615UL;
        l_47[1]--;
    }
    for (p_27 = (-27); (p_27 < (-10)); p_27 = safe_add_func_uint16_t_u_u(p_27, 6))
    { /* block id: 22 */
        uint8_t l_55[3][9][1] = {{{255UL},{1UL},{0x9DL},{1UL},{255UL},{0xA2L},{255UL},{1UL},{0x9DL}},{{1UL},{255UL},{0xA2L},{255UL},{1UL},{0x9DL},{1UL},{255UL},{0xA2L}},{{255UL},{1UL},{0x9DL},{1UL},{255UL},{0xA2L},{255UL},{1UL},{0x9DL}}};
        int32_t l_56 = 0x7136C1A4L;
        const int32_t l_57 = 0x23711835L;
        int i, j, k;
        if ((g_3 & 0xA0L))
        { /* block id: 23 */
            int16_t l_54[10] = {(-8L),(-8L),0x3148L,(-8L),(-8L),0x3148L,(-8L),(-8L),0x3148L,(-8L)};
            int i;
            l_54[7] = (((safe_mul_func_uint8_t_u_u((p_27 ^ 0xA189L), g_46[8])) == p_26) < 0xB27AL);
            l_56 = l_55[0][4][0];
            l_58 = l_57;
        }
        else
        { /* block id: 27 */
            g_46[8] |= (l_55[0][4][0] > 0xA6L);
            g_59 ^= (((p_26 | 0x77BEL) && p_27) , g_3);
            return g_59;
        }
        for (l_56 = 0; (l_56 > (-22)); --l_56)
        { /* block id: 34 */
            uint32_t l_62[2];
            int i;
            for (i = 0; i < 2; i++)
                l_62[i] = 0x7DF68D34L;
            if (l_62[0])
                break;
            l_58 = ((safe_mod_func_int8_t_s_s(g_59, g_2[2])) > p_26);
            if (g_2[3])
                continue;
            return g_2[2];
        }
        l_58 |= (safe_div_func_uint64_t_u_u((safe_mod_func_int64_t_s_s(((((safe_lshift_func_int16_t_s_u(0x63B6L, l_56)) > 1UL) != g_2[7]) & g_46[8]), g_2[4])), 1UL));
        for (l_58 = 0; (l_58 == (-22)); l_58--)
        { /* block id: 43 */
            uint32_t l_73[2];
            int i;
            for (i = 0; i < 2; i++)
                l_73[i] = 0xBB5DFEAAL;
            --l_73[0];
            g_3 = (p_26 & 18446744073709551613UL);
        }
    }
    for (g_59 = (-1); (g_59 >= (-29)); g_59 = safe_sub_func_int8_t_s_s(g_59, 8))
    { /* block id: 50 */
        uint32_t l_78 = 1UL;
        int32_t l_82[2];
        uint32_t l_84 = 18446744073709551615UL;
        int i;
        for (i = 0; i < 2; i++)
            l_82[i] = 1L;
        for (p_27 = 0; (p_27 <= 5); p_27 += 1)
        { /* block id: 53 */
            int i;
            --l_78;
            l_58 = (g_46[(p_27 + 1)] , g_46[(p_27 + 1)]);
            g_81[0] |= (g_3 >= 65533UL);
        }
        l_84--;
        return g_2[4];
    }
    return p_27;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_46[i], "g_46[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_59, "g_59", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_81[i], "g_81[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 56
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 77
   depth: 2, occurrence: 22
   depth: 3, occurrence: 7
   depth: 4, occurrence: 5
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 101
XXX times a non-volatile is write: 46
XXX times a volatile is read: 18
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 96
XXX percentage of non-volatile access: 85.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 78
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 24
   depth: 2, occurrence: 39

XXX percentage a fresh-made variable is used: 28.4
XXX percentage an existing variable is used: 71.6
********************* end of statistics **********************/

