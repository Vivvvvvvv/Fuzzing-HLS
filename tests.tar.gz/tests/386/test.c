/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      362286121398815796
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint16_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static int8_t g_6 = 0L;
static volatile struct S0 g_33[5][5][4] = {{{{0UL},{0x8C98L},{0UL},{0UL}},{{0x8C98L},{0x8C98L},{0xD50FL},{0x8C98L}},{{0x8C98L},{0UL},{0UL},{0x8C98L}},{{0UL},{0x8C98L},{0UL},{0UL}},{{0x8C98L},{0x8C98L},{0xD50FL},{0x8C98L}}},{{{0x8C98L},{0UL},{0UL},{0x8C98L}},{{0UL},{0x8C98L},{0UL},{0UL}},{{0x8C98L},{0x8C98L},{0xD50FL},{0x8C98L}},{{0x8C98L},{0UL},{0UL},{0x8C98L}},{{0UL},{0x8C98L},{0UL},{0UL}}},{{{0x8C98L},{0x8C98L},{0xD50FL},{0x8C98L}},{{0x8C98L},{0UL},{0xD50FL},{0UL}},{{0xD50FL},{0UL},{0xD50FL},{0xD50FL}},{{0UL},{0UL},{0x8C98L},{0UL}},{{0UL},{0xD50FL},{0xD50FL},{0UL}}},{{{0xD50FL},{0UL},{0xD50FL},{0xD50FL}},{{0UL},{0UL},{0x8C98L},{0UL}},{{0UL},{0xD50FL},{0xD50FL},{0UL}},{{0xD50FL},{0UL},{0xD50FL},{0xD50FL}},{{0UL},{0UL},{0x8C98L},{0UL}}},{{{0UL},{0xD50FL},{0xD50FL},{0UL}},{{0xD50FL},{0UL},{0xD50FL},{0xD50FL}},{{0UL},{0UL},{0x8C98L},{0UL}},{{0UL},{0xD50FL},{0xD50FL},{0UL}},{{0xD50FL},{0UL},{0xD50FL},{0xD50FL}}}};
static volatile struct S0 g_34[2] = {{65535UL},{65535UL}};
static uint32_t g_38 = 0xB3915004L;
static uint64_t g_46 = 0xC8A2DB6377F0A061LL;
static volatile struct S0 g_61[5] = {{0UL},{0UL},{0UL},{0UL},{0UL}};
static uint16_t g_66[8] = {0x6DC3L,0x6DC3L,0x6DC3L,0x6DC3L,0x6DC3L,0x6DC3L,0x6DC3L,0x6DC3L};
static volatile struct S0 g_71 = {0x7402L};/* VOLATILE GLOBAL g_71 */
static uint32_t g_75[2] = {0UL,0UL};
static int32_t g_76 = 0L;
static int32_t g_78[3] = {1L,1L,1L};
static uint32_t g_80 = 0UL;
static struct S0 g_85[5][5][9] = {{{{65535UL},{0xF52EL},{9UL},{6UL},{0xB233L},{8UL},{5UL},{65535UL},{0x18A5L}},{{0x5CABL},{0x2971L},{65535UL},{7UL},{0xB33DL},{0UL},{1UL},{0x016CL},{1UL}},{{0x90B8L},{0xD77EL},{5UL},{5UL},{0xD77EL},{0x90B8L},{8UL},{0x46A1L},{0xD77EL}},{{65535UL},{0x2971L},{0x479DL},{1UL},{65527UL},{3UL},{65527UL},{1UL},{0x479DL}},{{0x18A5L},{0xF52EL},{8UL},{0xD77EL},{65527UL},{0x767FL},{8UL},{0x18A5L},{0x18A5L}}},{{{1UL},{1UL},{0x5CABL},{3UL},{0x5CABL},{1UL},{1UL},{0x2971L},{65528UL}},{{0xD77EL},{0x90B8L},{8UL},{0x46A1L},{0xD77EL},{6UL},{5UL},{0x767FL},{0x90B8L}},{{0x479DL},{0x016CL},{0x479DL},{0UL},{0x01ABL},{7UL},{0x16EDL},{0x2971L},{65527UL}},{{0x18A5L},{9UL},{5UL},{0xB233L},{0xB233L},{5UL},{9UL},{0x18A5L},{65535UL}},{{65528UL},{3UL},{65535UL},{0UL},{0UL},{1UL},{0xB33DL},{1UL},{0UL}}},{{{0x90B8L},{65535UL},{9UL},{0x46A1L},{0x18A5L},{0xD77EL},{0xF52EL},{0x46A1L},{65535UL}},{{65527UL},{0x016CL},{0x01ABL},{3UL},{0x8CE2L},{3UL},{0x01ABL},{0x016CL},{65527UL}},{{65535UL},{0x46A1L},{0xF52EL},{0xD77EL},{0x18A5L},{0x46A1L},{9UL},{65535UL},{0x90B8L}},{{65535UL},{0x2971L},{0x5CABL},{0x2971L},{65535UL},{7UL},{0xB33DL},{0UL},{1UL}},{{0xD77EL},{65527UL},{0x767FL},{8UL},{0x18A5L},{0x18A5L},{8UL},{0x767FL},{65527UL}}},{{{0x8CE2L},{3UL},{0x01ABL},{0x016CL},{65527UL},{7UL},{0x43C0L},{0x6180L},{0x43C0L}},{{65535UL},{5UL},{8UL},{0xB233L},{6UL},{9UL},{0xF52EL},{65535UL},{6UL}},{{1UL},{3UL},{0UL},{0x2971L},{65535UL},{0UL},{65535UL},{0x2971L},{0UL}},{{65527UL},{65527UL},{0xF52EL},{5UL},{0x90B8L},{6UL},{0xF52EL},{1UL},{65527UL}},{{0x43C0L},{0x2971L},{0x8CE2L},{0UL},{0x8CE2L},{0x2971L},{0x43C0L},{3UL},{0x479DL}}},{{{6UL},{9UL},{0xF52EL},{65535UL},{6UL},{8UL},{8UL},{6UL},{65535UL}},{{0UL},{0x6180L},{0UL},{7UL},{0x5CABL},{0x016CL},{0xB33DL},{3UL},{65535UL}},{{65527UL},{0xD77EL},{8UL},{0xF52EL},{0x18A5L},{0xB233L},{0x767FL},{1UL},{0xD77EL}},{{0x479DL},{0UL},{0x01ABL},{7UL},{0x16EDL},{0x2971L},{65527UL},{0x2971L},{0x16EDL}},{{65535UL},{0x767FL},{0x767FL},{65535UL},{65527UL},{5UL},{1UL},{65535UL},{0xD77EL}}}};
static int16_t g_94 = 0x907DL;
static int16_t g_97[6][10] = {{(-1L),(-1L),(-9L),0xE625L,0L,0xE625L,(-9L),(-1L),(-1L),(-9L)},{0xFF1EL,0xE625L,0x621EL,0x621EL,0xE625L,0xFF1EL,(-9L),0xFF1EL,0xE625L,0x621EL},{(-3L),(-1L),(-3L),0x621EL,(-9L),(-9L),0x621EL,(-3L),(-1L),(-3L)},{(-3L),0xFF1EL,(-1L),0xE625L,(-1L),0xFF1EL,(-3L),(-3L),0xFF1EL,(-1L)},{0xFF1EL,(-3L),(-3L),0xFF1EL,(-1L),0xE625L,(-1L),0xFF1EL,(-3L),(-3L)},{(-1L),(-3L),0x621EL,(-9L),(-9L),0x621EL,(-3L),(-1L),(-3L),0x621EL}};
static int16_t g_104[1] = {0x6FF1L};
static uint32_t g_108 = 1UL;
static volatile uint16_t g_113[3][2] = {{65531UL,65531UL},{65531UL,65531UL},{65531UL,65531UL}};
static uint32_t g_120 = 0x197F755CL;
static volatile uint8_t g_128 = 0x04L;/* VOLATILE GLOBAL g_128 */
static volatile uint32_t g_133[3] = {0x6DD0C68CL,0x6DD0C68CL,0x6DD0C68CL};
static int64_t g_136 = 1L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_2(uint16_t  p_3, uint32_t  p_4);
static uint64_t  func_9(uint32_t  p_10, int32_t  p_11, int32_t  p_12, uint32_t  p_13);
static struct S0  func_19(uint16_t  p_20, int32_t  p_21, int32_t  p_22, uint8_t  p_23);
static int32_t  func_26(uint64_t  p_27, int64_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_33 g_34.f0 g_38 g_46 g_34 g_71 g_66 g_76 g_75 g_80 g_85 g_61.f0 g_104 g_97 g_94 g_113 g_128 g_133 g_78
 * writes: g_34 g_6 g_38 g_46 g_61 g_66 g_75 g_80 g_94 g_97 g_104 g_108 g_113 g_120 g_128 g_71.f0 g_133 g_136
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5[1][6] = {{(-2L),(-2L),6L,(-2L),(-2L),6L}};
    int8_t l_119 = (-5L);
    int i, j;
    if (func_2(l_5[0][0], g_6))
    { /* block id: 55 */
        int32_t l_98[10] = {1L,1L,0x5A862B89L,1L,1L,0x5A862B89L,0x40D4900EL,0x40D4900EL,1L,0x40D4900EL};
        int32_t l_112 = (-1L);
        int i;
        for (g_38 = (-27); (g_38 > 35); ++g_38)
        { /* block id: 58 */
            g_97[1][4] = (-5L);
            if (g_46)
                goto lbl_109;
        }
lbl_109:
        if (((l_98[7] | l_5[0][3]) == l_98[7]))
        { /* block id: 61 */
            int32_t l_103 = 0L;
            g_104[0] |= (safe_mul_func_int8_t_s_s((((safe_add_func_uint64_t_u_u(l_103, g_61[4].f0)) < g_6) | l_5[0][0]), l_5[0][0]));
            l_98[7] = (-1L);
            l_5[0][2] = (((((safe_add_func_uint8_t_u_u(0UL, 4UL)) > 0xC828L) <= g_97[1][4]) != 0xCB638BEBE6BB7537LL) >= g_97[3][2]);
        }
        else
        { /* block id: 65 */
            int64_t l_107[8];
            int i;
            for (i = 0; i < 8; i++)
                l_107[i] = 0x678477E6E7EB6903LL;
            g_108 = ((l_98[7] ^ l_5[0][3]) , l_107[6]);
            return g_94;
        }
        for (g_80 = 0; (g_80 != 14); g_80++)
        { /* block id: 72 */
            int32_t l_116 = 0x6AD958E1L;
            ++g_113[1][0];
            if (g_6)
                continue;
            l_116 |= l_112;
            g_120 = (((safe_mul_func_int8_t_s_s(l_119, l_5[0][0])) == 0L) < g_6);
        }
        l_98[7] = g_46;
    }
    else
    { /* block id: 79 */
        int32_t l_123[4][3] = {{0x6F71F75EL,(-3L),(-3L)},{(-9L),(-1L),(-1L)},{0x6F71F75EL,(-3L),(-3L)},{(-9L),(-1L),(-1L)}};
        int32_t l_124 = (-7L);
        int i, j;
        if ((safe_rshift_func_uint8_t_u_s(((((l_119 | g_113[1][0]) ^ l_119) < 0x253AL) || 0x723AL), 0)))
        { /* block id: 80 */
            l_124 |= l_123[2][0];
        }
        else
        { /* block id: 82 */
            uint16_t l_125 = 0x2B8AL;
            l_125++;
            g_128--;
        }
    }
    for (g_46 = 22; (g_46 != 2); --g_46)
    { /* block id: 89 */
        for (g_108 = 0; g_108 < 1; g_108 += 1)
        {
            for (g_71.f0 = 0; g_71.f0 < 6; g_71.f0 += 1)
            {
                l_5[g_108][g_71.f0] = 1L;
            }
        }
        --g_133[0];
        l_5[0][1] = g_61[4].f0;
        g_136 = (((g_75[0] , (-8L)) >= g_78[2]) , g_76);
    }
    return l_5[0][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_33 g_34.f0 g_38 g_46 g_34 g_71 g_66 g_76 g_75 g_80 g_85
 * writes: g_34 g_6 g_38 g_46 g_61 g_66 g_75 g_80 g_94
 */
static int32_t  func_2(uint16_t  p_3, uint32_t  p_4)
{ /* block id: 1 */
    uint16_t l_14 = 1UL;
    g_94 = (safe_sub_func_uint64_t_u_u(func_9(g_6, g_6, g_6, l_14), l_14));
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_33 g_34.f0 g_38 g_46 g_34 g_71 g_66 g_76 g_75 g_80 g_85
 * writes: g_34 g_6 g_38 g_46 g_61 g_66 g_75 g_80
 */
static uint64_t  func_9(uint32_t  p_10, int32_t  p_11, int32_t  p_12, uint32_t  p_13)
{ /* block id: 2 */
    uint8_t l_32 = 0x93L;
    int32_t l_86 = 0L;
    int32_t l_88[7][4][8] = {{{8L,0xD0C3B02FL,0x480CDD54L,0x928101EFL,(-9L),0xA8DCBE86L,0x5BDED785L,1L},{1L,0xC57D7CE4L,0xFB12407CL,0x5BDED785L,0x480CDD54L,0x35CA447FL,(-6L),1L},{0xC57D7CE4L,0x3B08BCBAL,0xD0C3B02FL,0xF7132E54L,0x741F5D68L,0L,0L,0L},{0xDB8D8D30L,2L,0x35CA447FL,0x35CA447FL,2L,0xDB8D8D30L,0x480CDD54L,0L}},{{0x7E307078L,0L,0x5BDED785L,(-7L),0xA8DCBE86L,(-6L),0x988067FCL,0x928101EFL},{0xEA79CFC9L,0xF607BB08L,0L,(-7L),0xF728D9C3L,0L,8L,0L},{0x997ADCAFL,0xF728D9C3L,(-7L),0x35CA447FL,0x5BDED785L,0x5D8015DFL,(-9L),0L},{0xD0C3B02FL,8L,0xF5DD30C4L,0xF7132E54L,(-9L),2L,0x1B697508L,1L}},{{1L,0x2C646EC4L,(-9L),0x5BDED785L,0xEAC9F24DL,0x130811D2L,0xC57D7CE4L,1L},{0x2C646EC4L,0xEA79CFC9L,0xD0C3B02FL,0x928101EFL,0xD0C3B02FL,0xEA79CFC9L,0x2C646EC4L,0xF607BB08L},{0x3B08BCBAL,2L,(-6L),0x130811D2L,0L,(-7L),0xF5DD30C4L,0x459F139CL},{0x7E307078L,0xC5510416L,0x1B697508L,0xDB8D8D30L,0L,0xFB12407CL,0x130811D2L,0x928101EFL}},{{0x3B08BCBAL,0L,(-6L),0x459F139CL,0xD0C3B02FL,0x7E307078L,8L,0xC5510416L},{0x2C646EC4L,0x741F5D68L,0xF607BB08L,(-9L),0xEAC9F24DL,0x5D8015DFL,0xFB12407CL,0x997ADCAFL},{1L,8L,7L,0L,(-9L),0L,0x5D8015DFL,0xF728D9C3L},{0xD0C3B02FL,0x997ADCAFL,0x3D1C57EAL,0x5BDED785L,0x5BDED785L,0x3D1C57EAL,0x997ADCAFL,0xD0C3B02FL}},{{0x997ADCAFL,(-7L),0xD0C3B02FL,0xA8DCBE86L,0xF728D9C3L,0x459F139CL,(-7L),(-6L)},{0xEA79CFC9L,2L,0x130811D2L,0x3D1C57EAL,0xA8DCBE86L,0x459F139CL,7L,0xDB8D8D30L},{0x7E307078L,(-7L),0x5D8015DFL,0xC5510416L,2L,0x3D1C57EAL,(-6L),0x928101EFL},{0xDB8D8D30L,0x997ADCAFL,0xC57D7CE4L,0xEA79CFC9L,0x741F5D68L,0L,8L,(-7L)}},{{0xC57D7CE4L,8L,0x997ADCAFL,0x988067FCL,0x480CDD54L,0x5D8015DFL,0x35CA447FL,0x2C646EC4L},{1L,0x741F5D68L,0xEAC9F24DL,0x7E307078L,(-9L),0x7E307078L,0xEAC9F24DL,0x8ECEC350L},{0x8B1D6983L,0L,0x5BDED785L,1L,0xD0C3B02FL,0xF5DD30C4L,0L,0x8B1D6983L},{0L,0x997ADCAFL,0xEEE8C1B3L,(-6L),0x8B1D6983L,(-6L),0L,0xF7132E54L}},{{(-6L),(-6L),0x5BDED785L,0xF5DD30C4L,0x988067FCL,0x2C646EC4L,0x741F5D68L,0xF607BB08L},{0x988067FCL,0x2C646EC4L,0x741F5D68L,0xF607BB08L,(-9L),0xEAC9F24DL,0x5D8015DFL,0xFB12407CL},{0L,2L,0x928101EFL,(-7L),(-9L),(-6L),7L,0x2C646EC4L},{0xF7132E54L,0x8B1D6983L,0x7E307078L,0x480CDD54L,1L,1L,0x480CDD54L,0x7E307078L}}};
    int i, j, k;
    p_12 = ((safe_mod_func_uint64_t_u_u(((0xE2L > g_6) & g_6), g_6)) | 0x03BD6525L);
    for (p_10 = (-21); (p_10 <= 34); ++p_10)
    { /* block id: 6 */
        int8_t l_31[3];
        int i;
        for (i = 0; i < 3; i++)
            l_31[i] = 9L;
        l_86 = (func_19(((((safe_mod_func_int16_t_s_s((func_26(((safe_sub_func_uint8_t_u_u(p_12, l_31[1])) == p_11), l_32) == l_32), l_31[1])) <= 1L) < p_11) != p_12), g_76, p_10, g_76) , 9L);
        if (l_32)
            continue;
        l_86 ^= (((~((0xF394C470L & g_34[1].f0) && p_11)) < p_12) >= p_10);
    }
    p_12 = l_88[5][1][6];
    for (p_13 = 1; (p_13 <= 7); p_13 += 1)
    { /* block id: 44 */
        uint16_t l_93[5][6];
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 6; j++)
                l_93[i][j] = 65530UL;
        }
        l_93[1][1] &= (safe_mul_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s((g_66[p_13] <= 1L), 0x1A4FL)) , 7UL), l_32));
        for (g_38 = 0; (g_38 <= 7); g_38 += 1)
        { /* block id: 48 */
            p_12 = g_66[7];
        }
    }
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_71.f0 g_75 g_80 g_85
 * writes: g_80
 */
static struct S0  func_19(uint16_t  p_20, int32_t  p_21, int32_t  p_22, uint8_t  p_23)
{ /* block id: 32 */
    int8_t l_77 = (-9L);
    int32_t l_79[9] = {(-1L),(-1L),1L,(-1L),(-1L),1L,(-1L),(-1L),1L};
    int i;
    p_21 |= (((l_77 ^ g_71.f0) | l_77) <= g_75[1]);
    g_80++;
    p_21 ^= ((((((safe_mul_func_uint8_t_u_u(0x84L, p_20)) ^ l_77) > p_20) | 0xDFL) ^ 0xE5C5L) && 0x2EA737198010E05DLL);
    return g_85[3][2][5];
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_6 g_34.f0 g_38 g_46 g_34 g_71 g_66
 * writes: g_34 g_6 g_38 g_46 g_61 g_66 g_75
 */
static int32_t  func_26(uint64_t  p_27, int64_t  p_28)
{ /* block id: 7 */
    uint8_t l_59 = 255UL;
    int32_t l_60 = 0xF520F09DL;
    if ((0x39E6A4137D6C5051LL != p_27))
    { /* block id: 8 */
        uint64_t l_45 = 0x497C242EA6AE2024LL;
        g_34[1] = g_33[1][0][1];
        for (g_6 = 0; (g_6 >= (-5)); g_6--)
        { /* block id: 12 */
            int16_t l_37 = (-1L);
            if (g_34[1].f0)
                break;
            g_38 = l_37;
            g_46 = (safe_rshift_func_uint16_t_u_s((((safe_sub_func_uint32_t_u_u(((safe_mod_func_int64_t_s_s((g_34[1].f0 , 0xBEBB6F2BA10F40BFLL), l_45)) & g_38), l_45)) <= 0x8564L) != 65535UL), g_6));
            l_60 = (safe_div_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((((safe_add_func_int32_t_s_s((safe_sub_func_int64_t_s_s(((((safe_div_func_int32_t_s_s(((safe_sub_func_int32_t_s_s(l_59, (-3L))) & l_37), p_28)) || g_46) | l_37) >= l_37), l_45)), g_6)) && g_46) == l_59), g_33[1][0][1].f0)), 0x86L));
        }
        g_61[4] = g_34[1];
    }
    else
    { /* block id: 19 */
        int64_t l_62[8][7] = {{0x2D77871239B75972LL,0xAA8C97D735F31A33LL,1L,0xAA8C97D735F31A33LL,0x2D77871239B75972LL,0x2D77871239B75972LL,0xAA8C97D735F31A33LL},{0xCE086565EA9D2C4CLL,0L,0xCE086565EA9D2C4CLL,0xCB4F50F898D4ED1ELL,0x9F656345D18A9382LL,0L,(-2L)},{0xAA8C97D735F31A33LL,(-6L),1L,1L,(-6L),0xAA8C97D735F31A33LL,(-6L)},{0xCE086565EA9D2C4CLL,0xCB4F50F898D4ED1ELL,0x9F656345D18A9382LL,0L,(-2L),0L,0x9F656345D18A9382LL},{0x2D77871239B75972LL,0x2D77871239B75972LL,0xAA8C97D735F31A33LL,1L,0xAA8C97D735F31A33LL,0x2D77871239B75972LL,0x2D77871239B75972LL},{0x855F075F97E6E185LL,0xCB4F50F898D4ED1ELL,0x7922C1E9780CE5FALL,0xCB4F50F898D4ED1ELL,0x855F075F97E6E185LL,1L,0x9F656345D18A9382LL},{0x14D19633EF28F0E4LL,(-6L),0x14D19633EF28F0E4LL,0xAA8C97D735F31A33LL,0xAA8C97D735F31A33LL,0x14D19633EF28F0E4LL,(-6L)},{0x9F656345D18A9382LL,0L,0x7922C1E9780CE5FALL,0x8E2DC6606A86E60ELL,(-2L),0xCB4F50F898D4ED1ELL,(-2L)}};
        int32_t l_63 = (-7L);
        int i, j;
        l_63 = l_62[0][4];
        l_63 = l_60;
    }
    for (g_38 = 0; (g_38 <= 37); g_38 = safe_add_func_uint16_t_u_u(g_38, 4))
    { /* block id: 25 */
        if (p_28)
            break;
        g_66[0] = 0x0DE0B5DAL;
    }
    l_60 |= (safe_div_func_int32_t_s_s((safe_mod_func_uint32_t_u_u((g_71 , 0x996E2414L), 0x52D29589L)), g_66[0]));
    g_75[1] = (safe_div_func_uint8_t_u_u((!((4294967294UL == p_27) != p_27)), p_28));
    return l_59;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_33[i][j][k].f0, "g_33[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_34[i].f0, "g_34[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_61[i].f0, "g_61[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_66[i], "g_66[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_71.f0, "g_71.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_75[i], "g_75[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_76, "g_76", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_78[i], "g_78[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_80, "g_80", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_85[i][j][k].f0, "g_85[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_94, "g_94", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_97[i][j], "g_97[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_104[i], "g_104[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_108, "g_108", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_113[i][j], "g_113[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_133[i], "g_133[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_136, "g_136", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 41
   depth: 1, occurrence: 5
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 66
   depth: 2, occurrence: 9
   depth: 3, occurrence: 3
   depth: 4, occurrence: 5
   depth: 5, occurrence: 4
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 13, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 96
XXX times a non-volatile is write: 38
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 43
XXX percentage of non-volatile access: 89.3

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 59
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 21
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 31.9
XXX percentage an existing variable is used: 68.1
********************* end of statistics **********************/

