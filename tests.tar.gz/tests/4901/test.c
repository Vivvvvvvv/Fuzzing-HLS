/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10063029973619682645
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_8 = (-9L);
static uint16_t g_13[6] = {0x2AE7L,0x2AE7L,0x2AE7L,0x2AE7L,0x2AE7L,0x2AE7L};
static volatile int32_t g_24 = 5L;/* VOLATILE GLOBAL g_24 */
static uint64_t g_33[1] = {18446744073709551612UL};
static int64_t g_42 = 0x0C80D6736FA7ABE3LL;
static int32_t g_43 = 0xC9FC22F7L;
static int64_t g_45 = 0x0CB25BB54A037A76LL;
static volatile int16_t g_46 = 0xD8D7L;/* VOLATILE GLOBAL g_46 */
static volatile int64_t g_47 = 0x75E7E8EE72C95C8FLL;/* VOLATILE GLOBAL g_47 */
static volatile int8_t g_48 = (-5L);/* VOLATILE GLOBAL g_48 */
static volatile uint16_t g_52 = 65535UL;/* VOLATILE GLOBAL g_52 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint32_t  func_4(int32_t  p_5, int32_t  p_6);
static int32_t  func_16(int16_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_24 g_33 g_42 g_52
 * writes: g_13 g_24 g_33 g_42 g_52
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    const uint64_t l_7 = 1UL;
    int32_t l_44 = 0xA6906E71L;
    int8_t l_49 = 0xD1L;
    int32_t l_50 = (-1L);
    int32_t l_51[1];
    int i;
    for (i = 0; i < 1; i++)
        l_51[i] = 1L;
    g_42 ^= (safe_add_func_uint32_t_u_u(func_4((l_7 , g_8), g_8), 0x845D487CL));
    g_52++;
    return l_51[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_24 g_33
 * writes: g_13 g_24 g_33
 */
static uint32_t  func_4(int32_t  p_5, int32_t  p_6)
{ /* block id: 1 */
    int32_t l_9 = 0x6DB6D037L;
    if ((((g_8 , p_5) != 0x80L) <= l_9))
    { /* block id: 2 */
        uint8_t l_10 = 0x51L;
        l_10++;
    }
    else
    { /* block id: 4 */
        int8_t l_40 = (-1L);
        g_13[5] = (g_8 < l_9);
        for (p_5 = 0; (p_5 == 2); p_5 = safe_add_func_int8_t_s_s(p_5, 3))
        { /* block id: 8 */
            int8_t l_41 = 0L;
            g_33[0] |= func_16(p_5);
            g_24 = ((safe_div_func_int8_t_s_s((((safe_div_func_uint32_t_u_u((safe_mod_func_int32_t_s_s((0x0BL > 0x45L), g_13[5])), l_40)) != p_6) < l_40), l_41)) <= 0L);
        }
    }
    for (p_6 = 0; p_6 < 6; p_6 += 1)
    {
        g_13[p_6] = 0x9C17L;
    }
    return g_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_24
 * writes: g_24
 */
static int32_t  func_16(int16_t  p_17)
{ /* block id: 9 */
    uint32_t l_23[9] = {4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL};
    int64_t l_31 = 0x0DC4B6369DDA3143LL;
    int32_t l_32 = 0x22CBD4DAL;
    int i;
    g_24 = (((!((((safe_sub_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_s((-9L), l_23[8])) || 0x16AAC8953526C715LL) <= 1L), p_17)) | g_13[5]) , g_24) , 18446744073709551606UL)) , 0xC7EB236728AD64DELL) > 0x3585CA2589D38951LL);
    l_32 = (safe_rshift_func_uint8_t_u_u((((((safe_mul_func_int16_t_s_s((safe_sub_func_int8_t_s_s(0x4BL, p_17)), 0L)) > p_17) <= g_13[5]) <= l_31) < p_17), 7));
    return l_23[7];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_24, "g_24", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_33[i], "g_33[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 8, occurrence: 2
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 6
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 13
XXX percentage of non-volatile access: 86.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 3
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 48.9
XXX percentage an existing variable is used: 51.1
********************* end of statistics **********************/

