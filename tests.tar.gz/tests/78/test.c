/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11651293001283722703
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x57FD5464L;
static volatile int8_t g_23 = (-1L);/* VOLATILE GLOBAL g_23 */
static uint32_t g_24[4] = {0x3817D1DCL,0x3817D1DCL,0x3817D1DCL,0x3817D1DCL};
static volatile uint32_t g_27 = 8UL;/* VOLATILE GLOBAL g_27 */
static int32_t g_53 = 1L;
static volatile uint64_t g_54 = 18446744073709551615UL;/* VOLATILE GLOBAL g_54 */
static volatile uint64_t g_65 = 0xB06ECFB4391DAA6ELL;/* VOLATILE GLOBAL g_65 */
static volatile uint32_t g_71 = 18446744073709551615UL;/* VOLATILE GLOBAL g_71 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint64_t  func_6(uint8_t  p_7, int32_t  p_8, uint8_t  p_9, int16_t  p_10);
static uint8_t  func_15(int64_t  p_16, const uint32_t  p_17, int32_t  p_18, const int64_t  p_19);
static uint64_t  func_37(int16_t  p_38);
static uint16_t  func_46(uint32_t  p_47, int64_t  p_48, uint32_t  p_49, int32_t  p_50, int16_t  p_51);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_23 g_24 g_27 g_54 g_53 g_65 g_71
 * writes: g_2 g_27 g_54 g_65 g_53 g_71
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    const uint8_t l_20 = 0UL;
    const int16_t l_21 = 2L;
    int32_t l_95 = 0L;
    int32_t l_96 = 1L;
    int8_t l_103 = 0x4BL;
    for (g_2 = (-1); (g_2 >= (-11)); g_2--)
    { /* block id: 3 */
        int32_t l_5[5];
        int i;
        for (i = 0; i < 5; i++)
            l_5[i] = 0L;
        if (l_5[0])
            break;
    }
    if ((func_6((safe_add_func_int32_t_s_s((safe_sub_func_uint8_t_u_u(func_15((((g_2 || 1UL) , (-8L)) < g_2), l_20, l_20, l_21), g_23)), g_24[1])), l_20, l_20, l_20) , 0x76915C51L))
    { /* block id: 64 */
        uint8_t l_97 = 0xE6L;
        l_97--;
        for (g_2 = (-28); (g_2 > 27); g_2++)
        { /* block id: 68 */
            if (g_24[1])
                break;
        }
    }
    else
    { /* block id: 71 */
        int8_t l_102 = 0x77L;
        return l_102;
    }
    l_103 = g_2;
    return g_53;
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_2 g_24 g_23 g_54 g_53 g_65 g_71
 * writes: g_27 g_2 g_54 g_65 g_53 g_71
 */
static uint64_t  func_6(uint8_t  p_7, int32_t  p_8, uint8_t  p_9, int16_t  p_10)
{ /* block id: 9 */
    uint32_t l_25[7];
    int32_t l_26 = 1L;
    int32_t l_57 = 0L;
    int64_t l_74 = 1L;
    uint32_t l_92 = 0x95DB7A71L;
    int i;
    for (i = 0; i < 7; i++)
        l_25[i] = 0xB8CEFFB9L;
    if ((p_10 == l_25[2]))
    { /* block id: 10 */
        uint32_t l_30[2];
        int64_t l_34 = 0xB947E29AC92D14B4LL;
        uint32_t l_41 = 0UL;
        const int64_t l_52 = 0L;
        int i;
        for (i = 0; i < 2; i++)
            l_30[i] = 0xEC1B16EBL;
        g_27--;
        if (p_10)
            goto lbl_33;
        if (l_30[0])
        { /* block id: 12 */
            g_2 ^= p_8;
            g_2 &= (safe_rshift_func_int8_t_s_s((0x4307976B5A7DD9AELL ^ 0x1AD7BA966896E60BLL), 6));
        }
        else
        { /* block id: 15 */
lbl_33:
            g_2 = 0xF49DCB7BL;
            l_34 = (((l_30[0] != p_8) ^ 0x4C25L) , g_24[1]);
            l_26 = (safe_lshift_func_uint8_t_u_s((func_37(g_24[3]) < 0L), l_41));
        }
        if (func_15((func_15((safe_add_func_uint32_t_u_u(((safe_rshift_func_uint16_t_u_s(func_46(p_7, p_7, p_10, g_27, g_2), 4)) | g_2), 0L)), l_25[2], p_7, l_25[0]) , p_10), p_8, g_24[2], l_52))
        { /* block id: 27 */
            --g_54;
            l_26 ^= l_57;
        }
        else
        { /* block id: 30 */
            uint64_t l_58[9][3][6] = {{{18446744073709551612UL,0xEA8900E2E800BCFDLL,0x8F8A558E0D3184BALL,1UL,0x8F8A558E0D3184BALL,0xEA8900E2E800BCFDLL},{0x8F8A558E0D3184BALL,8UL,0x26DAC17B1AB372C2LL,0x983969C113E7BE80LL,0UL,0x38D59A4365C17A62LL},{0xE44AADAB70C68704LL,0x8F8A558E0D3184BALL,0x983969C113E7BE80LL,0x2D7FAEFF9B11162BLL,0x52566A56D104A743LL,0x2C1B334FE9DE5592LL}},{{18446744073709551615UL,0x8F8A558E0D3184BALL,0xD994868B20CE92B6LL,18446744073709551613UL,0UL,0UL},{0x3983B7C1F666C839LL,8UL,18446744073709551615UL,5UL,0x8F8A558E0D3184BALL,0x52AB26C3A74F5703LL},{0x2C1B334FE9DE5592LL,0xEA8900E2E800BCFDLL,0x22F2FDD0459084C0LL,0x8CA73003F8612730LL,0x2D7FAEFF9B11162BLL,0x6206571F67B260ECLL}},{{5UL,0x7AFAE861E80F9606LL,0x26DAC17B1AB372C2LL,0x26DAC17B1AB372C2LL,0x7AFAE861E80F9606LL,5UL},{0x2D7FAEFF9B11162BLL,18446744073709551615UL,0x4096A604C9466B01LL,18446744073709551613UL,2UL,0xD994868B20CE92B6LL},{0x72380CEB71DEE155LL,0x52AB26C3A74F5703LL,0UL,0x2985DA4005DEF9EELL,0xE44AADAB70C68704LL,0x983969C113E7BE80LL}},{{0x72380CEB71DEE155LL,0x52566A56D104A743LL,0x2985DA4005DEF9EELL,18446744073709551613UL,0x3983B7C1F666C839LL,0x26DAC17B1AB372C2LL},{0x2D7FAEFF9B11162BLL,2UL,0x52AB26C3A74F5703LL,0UL,1UL,0x8F8A558E0D3184BALL},{18446744073709551615UL,0x2C1B334FE9DE5592LL,0x7AFAE861E80F9606LL,8UL,0x52566A56D104A743LL,18446744073709551613UL}},{{0x38D59A4365C17A62LL,18446744073709551615UL,18446744073709551611UL,18446744073709551615UL,0x38D59A4365C17A62LL,0x22F2FDD0459084C0LL},{18446744073709551607UL,18446744073709551613UL,0UL,0x983969C113E7BE80LL,0x6206571F67B260ECLL,18446744073709551607UL},{1UL,18446744073709551612UL,0x72380CEB71DEE155LL,18446744073709551613UL,3UL,18446744073709551607UL}},{{2UL,0x2D7FAEFF9B11162BLL,0UL,18446744073709551611UL,1UL,0x22F2FDD0459084C0LL},{3UL,0x52566A56D104A743LL,18446744073709551611UL,0UL,0xEA8900E2E800BCFDLL,18446744073709551613UL},{0x2D7FAEFF9B11162BLL,3UL,0x7AFAE861E80F9606LL,0UL,0x8F8A558E0D3184BALL,0x8F8A558E0D3184BALL}},{{18446744073709551607UL,0x52AB26C3A74F5703LL,0x52AB26C3A74F5703LL,18446744073709551607UL,0x52566A56D104A743LL,0x26DAC17B1AB372C2LL},{0x26DAC17B1AB372C2LL,18446744073709551612UL,0x2985DA4005DEF9EELL,18446744073709551615UL,18446744073709551613UL,0x983969C113E7BE80LL},{0xD994868B20CE92B6LL,0x38D59A4365C17A62LL,0UL,0UL,18446744073709551613UL,0xD994868B20CE92B6LL}},{{0x52AB26C3A74F5703LL,18446744073709551612UL,0x4096A604C9466B01LL,0UL,0x52566A56D104A743LL,18446744073709551615UL},{2UL,0x52AB26C3A74F5703LL,0UL,1UL,0x8F8A558E0D3184BALL,0x22F2FDD0459084C0LL},{0x72380CEB71DEE155LL,3UL,1UL,0x26DAC17B1AB372C2LL,0xEA8900E2E800BCFDLL,0x26DAC17B1AB372C2LL}},{{1UL,0x52566A56D104A743LL,1UL,0UL,1UL,0x2985DA4005DEF9EELL},{0xD994868B20CE92B6LL,0x2D7FAEFF9B11162BLL,0x52AB26C3A74F5703LL,8UL,3UL,0x38D59A4365C17A62LL},{18446744073709551613UL,18446744073709551612UL,18446744073709551611UL,8UL,0x6206571F67B260ECLL,0UL}}};
            int i, j, k;
            --l_58[0][2][3];
            g_2 ^= p_9;
            return g_53;
        }
    }
    else
    { /* block id: 35 */
        int8_t l_63 = 0L;
        int32_t l_64 = (-3L);
        int64_t l_68[10][3][4] = {{{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)}},{{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)}},{{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)}},{{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)}},{{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)}},{{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)}},{{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)}},{{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)}},{{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)}},{{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)},{0x6BFFE0AB02DA2EA9LL,0x6BFFE0AB02DA2EA9LL,0x6AF6502FCEF8C34FLL,(-3L)},{8L,0x6BFFE0AB02DA2EA9LL,(-3L),(-3L)}}};
        int32_t l_69 = 0L;
        int i, j, k;
        for (p_10 = (-3); (p_10 <= 14); p_10 = safe_add_func_uint16_t_u_u(p_10, 8))
        { /* block id: 38 */
            int32_t l_70 = 1L;
            g_65++;
            g_53 &= (g_65 <= l_68[1][1][1]);
            g_71--;
            g_2 &= g_24[1];
        }
        p_8 ^= (g_24[1] | l_74);
    }
    if ((safe_div_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(g_65, 0xEFL)), g_53)))
    { /* block id: 46 */
        uint16_t l_88[7] = {65535UL,65535UL,0xFC0AL,65535UL,65535UL,0xFC0AL,65535UL};
        int i;
        for (l_26 = 0; (l_26 > 1); ++l_26)
        { /* block id: 49 */
            l_88[6] |= (safe_unary_minus_func_int32_t_s(((safe_add_func_uint32_t_u_u(((safe_mod_func_int64_t_s_s(((safe_sub_func_uint32_t_u_u(l_74, p_10)) < g_54), p_8)) >= 0L), 0xAF67B55CL)) || 0x44252728FC8EE3FDLL)));
        }
        l_26 &= g_2;
        for (l_74 = 5; (l_74 >= 0); l_74 -= 1)
        { /* block id: 55 */
            int32_t l_89 = 0x9B496B13L;
            int i;
            l_89 = (0x07L <= l_25[l_74]);
            l_26 &= 0x91A53EA2L;
            g_53 = (safe_mul_func_int8_t_s_s((((g_23 || g_24[1]) > l_25[2]) , 1L), l_88[3]));
        }
    }
    else
    { /* block id: 60 */
        l_92++;
    }
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_2
 */
static uint8_t  func_15(int64_t  p_16, const uint32_t  p_17, int32_t  p_18, const int64_t  p_19)
{ /* block id: 6 */
    int16_t l_22 = 0x8A90L;
    g_2 = l_22;
    return l_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static uint64_t  func_37(int16_t  p_38)
{ /* block id: 19 */
    g_2 = (((safe_mul_func_int16_t_s_s((0x0046L || 0x609EL), g_2)) <= 1L) , 8L);
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_23
 * writes:
 */
static uint16_t  func_46(uint32_t  p_47, int64_t  p_48, uint32_t  p_49, int32_t  p_50, int16_t  p_51)
{ /* block id: 24 */
    p_50 = (0L < p_47);
    return g_23;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_24[i], "g_24[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 33
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 53
   depth: 2, occurrence: 10
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 7, occurrence: 1
   depth: 15, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 62
XXX times a non-volatile is write: 27
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 42
XXX percentage of non-volatile access: 89

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 46
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 14
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 29.2
XXX percentage an existing variable is used: 70.8
********************* end of statistics **********************/

