/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1177988410605498030
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_8 = 5UL;
static int32_t g_19[4][6][4] = {{{(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),0xFFAA2324L,0L},{(-1L),0xFFAA2324L,(-1L),0xA6F944DCL},{(-1L),0L,0xA6F944DCL,0xA6F944DCL},{0xFFAA2324L,0xFFAA2324L,0xB756FD8CL,0L},{0L,(-1L),0xB756FD8CL,(-1L)}},{{0xFFAA2324L,(-1L),0xA6F944DCL,0xB756FD8CL},{(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),0xFFAA2324L,0L},{(-1L),0xFFAA2324L,(-1L),0xA6F944DCL},{(-1L),0L,0xA6F944DCL,0xA6F944DCL},{0xFFAA2324L,0xFFAA2324L,0xFFAA2324L,0xA6F944DCL}},{{0xA6F944DCL,(-1L),0xFFAA2324L,(-1L)},{0x8642E5F0L,0L,0xB756FD8CL,0xFFAA2324L},{(-1L),0L,0L,(-1L)},{0L,(-1L),0x8642E5F0L,0xA6F944DCL},{0L,0x8642E5F0L,0L,0xB756FD8CL},{(-1L),0xA6F944DCL,0xB756FD8CL,0xB756FD8CL}},{{0x8642E5F0L,0x8642E5F0L,0xFFAA2324L,0xA6F944DCL},{0xA6F944DCL,(-1L),0xFFAA2324L,(-1L)},{0x8642E5F0L,0L,0xB756FD8CL,0xFFAA2324L},{(-1L),0L,0L,(-1L)},{0L,(-1L),0x8642E5F0L,0xA6F944DCL},{0L,0x8642E5F0L,0L,0xB756FD8CL}}};
static int32_t g_29 = 0x830386B9L;
static volatile uint16_t g_34 = 0x1BA0L;/* VOLATILE GLOBAL g_34 */


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, uint8_t  p_4, const int32_t  p_5, uint8_t  p_6, int32_t  p_7);
static int8_t  func_24(int16_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_19 g_29 g_34
 * writes: g_19 g_8 g_29 g_34
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_9 = 0xE8E1L;
    const int64_t l_10 = 0xACC5D9B4E94F934FLL;
    int32_t l_21 = 0x866B3883L;
    if (func_2(g_8, l_9, l_10, g_8, l_10))
    { /* block id: 22 */
        uint16_t l_20 = 9UL;
        l_20 = g_19[2][1][0];
        l_21 = l_10;
    }
    else
    { /* block id: 25 */
        int16_t l_27[10] = {0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L,0xEAA4L};
        int i;
        for (g_8 = (-24); (g_8 >= 10); ++g_8)
        { /* block id: 28 */
            uint32_t l_28[6][4] = {{0x7CF2842CL,0x7CF2842CL,0UL,0x7CF2842CL},{0x7CF2842CL,0x0698B42DL,0x0698B42DL,0x7CF2842CL},{0x0698B42DL,0x7CF2842CL,0x0698B42DL,0x0698B42DL},{0x7CF2842CL,0x7CF2842CL,0UL,0x7CF2842CL},{0x7CF2842CL,0x0698B42DL,0x0698B42DL,0x7CF2842CL},{0x0698B42DL,0x7CF2842CL,0x0698B42DL,0x0698B42DL}};
            int i, j;
            g_29 = func_2((func_24(g_8) && l_27[0]), l_27[0], g_8, l_10, l_28[0][0]);
        }
        l_21 = (l_9 < g_19[2][5][1]);
        for (g_29 = 12; (g_29 > (-11)); --g_29)
        { /* block id: 37 */
            int32_t l_32 = (-1L);
            uint32_t l_33 = 4UL;
            if (g_19[2][4][2])
                break;
            l_33 = (l_32 && l_32);
        }
        ++g_34;
    }
    for (l_9 = 20; (l_9 == (-14)); l_9 = safe_sub_func_int8_t_s_s(l_9, 3))
    { /* block id: 45 */
        if (((safe_lshift_func_int8_t_s_s(0xFFL, 1)) & g_19[3][3][1]))
        { /* block id: 46 */
            uint32_t l_41 = 0UL;
            if (l_9)
                break;
            l_21 = 0x1D91A4ACL;
            return l_41;
        }
        else
        { /* block id: 50 */
            return g_19[2][4][2];
        }
    }
    return l_10;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_19
 */
static int32_t  func_2(uint64_t  p_3, uint8_t  p_4, const int32_t  p_5, uint8_t  p_6, int32_t  p_7)
{ /* block id: 1 */
    uint8_t l_13 = 0xD0L;
    uint16_t l_14[6] = {0x5256L,0x5256L,65535UL,0x5256L,0x5256L,65535UL};
    int i;
    p_7 = (safe_rshift_func_uint8_t_u_s(0xE2L, l_13));
    for (l_13 = 0; (l_13 <= 5); l_13 += 1)
    { /* block id: 5 */
        uint16_t l_15 = 0x7609L;
        for (p_7 = 0; (p_7 <= 5); p_7 += 1)
        { /* block id: 8 */
            int i;
            if (l_14[p_7])
                break;
            if (l_15)
                break;
            if (p_3)
                break;
            return l_13;
        }
    }
    for (p_4 = 7; (p_4 != 7); ++p_4)
    { /* block id: 17 */
        uint32_t l_18 = 7UL;
        l_18 ^= ((1L == 0x8FA48A2BL) > p_7);
    }
    g_19[2][4][2] = l_13;
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_19
 * writes:
 */
static int8_t  func_24(int16_t  p_25)
{ /* block id: 29 */
    int32_t l_26 = (-1L);
    l_26 = g_19[2][2][0];
    return l_26;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_19[i][j][k], "g_19[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 9
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 39
XXX times a non-volatile is write: 16
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 98.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 30
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 9
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 39.5
XXX percentage an existing variable is used: 60.5
********************* end of statistics **********************/

