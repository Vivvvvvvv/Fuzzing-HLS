/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3971273959734742497
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_5 = 253UL;/* VOLATILE GLOBAL g_5 */
static int32_t g_6[8] = {0x93EE3274L,0x93EE3274L,0x93EE3274L,0x93EE3274L,0x93EE3274L,0x93EE3274L,0x93EE3274L,0x93EE3274L};
static uint8_t g_8[1] = {0x2BL};
static uint32_t g_15 = 0xA8F1EDD1L;
static volatile int8_t g_19 = 0xC4L;/* VOLATILE GLOBAL g_19 */
static volatile int16_t g_21 = 8L;/* VOLATILE GLOBAL g_21 */
static int16_t g_27 = 0x9284L;
static uint32_t g_30[3] = {18446744073709551613UL,18446744073709551613UL,18446744073709551613UL};
static uint8_t g_34 = 0x69L;
static uint32_t g_40 = 0xA10B913AL;
static uint8_t g_42[3] = {0x96L,0x96L,0x96L};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_2(int32_t  p_3, int8_t  p_4);
static int16_t  func_9(int32_t  p_10, uint32_t  p_11, uint32_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_8 g_30 g_27 g_15 g_34 g_42
 * writes: g_8 g_15 g_30 g_34 g_40 g_42
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_13 = 8UL;
    int64_t l_52 = 0L;
    g_8[0] ^= (func_2(((g_5 & g_6[3]) != g_6[3]), g_6[3]) || (-1L));
    if ((func_9(((((g_6[7] > 5L) > 0xE6L) , g_5) , l_13), l_13, l_13) > g_8[0]))
    { /* block id: 13 */
        uint32_t l_41 = 0x283D3454L;
        int32_t l_49[6] = {(-10L),0x7D512630L,(-10L),(-10L),0x7D512630L,(-10L)};
        int i;
        for (g_15 = 0; (g_15 <= 7); g_15 += 1)
        { /* block id: 16 */
            g_34--;
            if (l_13)
                break;
            g_40 = ((safe_lshift_func_int8_t_s_s((((safe_unary_minus_func_int8_t_s(0x50L)) , g_30[0]) , g_30[0]), l_13)) != 0xA5481F04FECCDF49LL);
            g_42[0] = (l_41 != 0x02L);
        }
        l_49[3] = ((safe_mod_func_uint16_t_u_u((((safe_sub_func_int8_t_s_s((safe_mod_func_int16_t_s_s(1L, g_42[2])), g_8[0])) && l_41) >= l_13), 0x1310L)) < 0x1C2B13F3B720FAE2LL);
    }
    else
    { /* block id: 23 */
        uint64_t l_53[7];
        int32_t l_54 = (-1L);
        int i;
        for (i = 0; i < 7; i++)
            l_53[i] = 9UL;
        l_54 = ((((safe_sub_func_uint32_t_u_u(0UL, l_52)) , l_53[6]) || g_5) == 0x55L);
    }
    return l_52;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_2(int32_t  p_3, int8_t  p_4)
{ /* block id: 1 */
    uint32_t l_7[3];
    int i;
    for (i = 0; i < 3; i++)
        l_7[i] = 0xE9FB1C03L;
    return l_7[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_30 g_27 g_8
 * writes: g_15 g_30
 */
static int16_t  func_9(int32_t  p_10, uint32_t  p_11, uint32_t  p_12)
{ /* block id: 4 */
    uint32_t l_16 = 7UL;
    int32_t l_17 = 0L;
    int32_t l_20[9] = {(-1L),1L,(-1L),(-1L),1L,(-1L),(-1L),1L,(-1L)};
    int i;
    if (g_6[3])
    { /* block id: 5 */
        uint32_t l_14[6];
        int i;
        for (i = 0; i < 6; i++)
            l_14[i] = 0x26F39384L;
        g_15 = ((((l_14[3] <= l_14[3]) == 0xE2E4ED38L) > (-2L)) <= (-2L));
        l_17 = ((l_16 == p_10) , 0xF3E141B6L);
    }
    else
    { /* block id: 8 */
        int32_t l_18 = 0x1BD53D2AL;
        int32_t l_22 = 9L;
        int32_t l_23 = 0x04E5477AL;
        int32_t l_24 = 1L;
        int32_t l_25 = 0x0B1C5ADFL;
        int32_t l_26 = 0xA1BAB0C3L;
        int32_t l_28 = 0x32397BDEL;
        int32_t l_29[3];
        int i;
        for (i = 0; i < 3; i++)
            l_29[i] = (-1L);
        ++g_30[0];
        l_20[5] = (+g_27);
    }
    return g_8[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_30[i], "g_30[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_42[i], "g_42[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 30
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 29
XXX times a non-volatile is write: 11
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 19
XXX percentage of non-volatile access: 93

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 17
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 7
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 44.8
XXX percentage an existing variable is used: 55.2
********************* end of statistics **********************/

