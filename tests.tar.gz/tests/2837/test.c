/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7644045622614690329
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_18 = 0xC2E7CCC8L;/* VOLATILE GLOBAL g_18 */
static uint8_t g_21 = 0x3DL;
static uint32_t g_22 = 4294967289UL;
static uint16_t g_23[3] = {65526UL,65526UL,65526UL};
static uint16_t g_39 = 0x7575L;
static uint32_t g_47 = 18446744073709551615UL;
static uint8_t g_49 = 0x16L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_3(int64_t  p_4, int16_t  p_5, uint8_t  p_6, uint64_t  p_7);
static int64_t  func_8(int64_t  p_9, uint8_t  p_10, uint8_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_18 g_21 g_23 g_39 g_22 g_49
 * writes: g_22 g_21 g_39 g_47 g_49
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_2[8] = {7UL,0xE1L,7UL,7UL,0xE1L,7UL,7UL,0xE1L};
    uint32_t l_19 = 0x3FE662DBL;
    const uint32_t l_20[4] = {1UL,1UL,1UL,1UL};
    int32_t l_46 = 1L;
    int8_t l_48 = (-1L);
    int i;
    l_2[2] |= 0x4E064826L;
    l_46 &= func_3(func_8((((safe_lshift_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s((safe_div_func_uint16_t_u_u(((g_18 > l_19) , 0x646BL), l_2[2])), l_20[1])) > 0UL), g_21)) > g_21) & 0L), g_21, l_2[4]), l_2[2], l_19, g_23[2]);
    g_47 = (0UL < l_19);
    --g_49;
    return g_49;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_21
 * writes:
 */
static int32_t  func_3(int64_t  p_4, int16_t  p_5, uint8_t  p_6, uint64_t  p_7)
{ /* block id: 11 */
    int16_t l_44 = 0x320BL;
    int32_t l_45 = 0xB883EB99L;
    l_45 = (safe_mod_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u(255UL, l_44)) < g_22), g_21));
    return g_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_23 g_18 g_39
 * writes: g_22 g_21 g_39
 */
static int64_t  func_8(int64_t  p_9, uint8_t  p_10, uint8_t  p_11)
{ /* block id: 2 */
    int32_t l_24 = 0x5E3D1AA1L;
    g_22 = p_10;
    for (g_21 = 0; (g_21 <= 2); g_21 += 1)
    { /* block id: 6 */
        int i;
        l_24 = (g_23[g_21] , (-9L));
    }
    g_39 ^= (((safe_lshift_func_int16_t_s_s((!(((((safe_div_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s((safe_sub_func_int32_t_s_s(((((+(safe_mod_func_uint16_t_u_u(((p_11 , 0xF0E4F20077FEFB65LL) & 0L), 0x15E0L))) <= g_18) ^ p_11) >= l_24), 1UL)), p_11)), 1)) || g_21), p_10)) ^ 0x1BL) ^ 0x07B364FEF5379A1DLL) | g_21) <= 1L)), 11)) , p_10) < 4294967295UL);
    return l_24;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_23[i], "g_23[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 3
   depth: 4, occurrence: 1
   depth: 16, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 28
XXX times a non-volatile is write: 9
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 94.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 37.8
XXX percentage an existing variable is used: 62.2
********************* end of statistics **********************/

