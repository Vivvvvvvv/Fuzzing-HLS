/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16224353958819812830
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_2[6] = {0x556834504CD45360LL,0x556834504CD45360LL,0x556834504CD45360LL,0x556834504CD45360LL,0x556834504CD45360LL,0x556834504CD45360LL};
static volatile int32_t g_4[8] = {0x8D526D2EL,0x8D526D2EL,0x8D526D2EL,0x8D526D2EL,0x8D526D2EL,0x8D526D2EL,0x8D526D2EL,0x8D526D2EL};
static uint64_t g_28 = 0x9A2A67F6A191A83ALL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int8_t  func_7(int8_t  p_8, const int64_t  p_9, uint32_t  p_10, uint32_t  p_11, int8_t  p_12);
static int8_t  func_13(int32_t  p_14, int32_t  p_15, uint64_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_28
 * writes: g_4 g_28
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_3[3];
    const int32_t l_29 = 7L;
    int32_t l_57 = 4L;
    int i;
    for (i = 0; i < 3; i++)
        l_3[i] = 0xB905D09EA9831117LL;
    l_3[2] ^= g_2[5];
    for (g_4[0] = 0; g_4[0] < 3; g_4[0] += 1)
    {
        l_3[g_4[0]] = 5UL;
    }
    l_57 &= (safe_rshift_func_int8_t_s_s(func_7(func_13((l_3[0] && l_3[2]), g_4[0], l_3[2]), l_29, l_3[2], l_3[2], g_2[5]), 6));
    g_4[1] = (safe_div_func_int32_t_s_s(((safe_mul_func_int16_t_s_s(((((safe_sub_func_int64_t_s_s((g_4[7] < g_2[5]), 0xFB9E2BF2DCFCB68BLL)) || g_4[0]) && g_4[5]) < (-2L)), 0x8198L)) & l_3[0]), g_28));
    return g_4[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_28 g_2
 * writes: g_4
 */
static int8_t  func_7(int8_t  p_8, const int64_t  p_9, uint32_t  p_10, uint32_t  p_11, int8_t  p_12)
{ /* block id: 19 */
    const uint32_t l_30 = 0x138B36CEL;
    int32_t l_31 = 0x59CDE30EL;
    l_31 = l_30;
    g_4[0] = (safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s((-8L), g_4[0])), 1UL));
    if ((((safe_div_func_int32_t_s_s((p_8 & g_28), l_30)) <= g_4[4]) > g_2[5]))
    { /* block id: 22 */
        uint64_t l_43 = 0UL;
        uint32_t l_44 = 0x32619C85L;
        l_44 = ((((((~(safe_add_func_int16_t_s_s((safe_rshift_func_int16_t_s_s(g_2[3], 6)), p_12))) <= l_43) <= l_30) & l_43) && p_12) , p_10);
    }
    else
    { /* block id: 24 */
        int32_t l_52 = 1L;
        if ((safe_add_func_int8_t_s_s(0x41L, 255UL)))
        { /* block id: 25 */
            g_4[0] = ((+(safe_lshift_func_uint16_t_u_u((((g_2[4] >= g_28) & g_28) < 0x48B7552F0C8C580BLL), g_2[5]))) >= p_11);
            g_4[0] = p_11;
        }
        else
        { /* block id: 28 */
            g_4[6] = (((safe_sub_func_int8_t_s_s(p_10, p_12)) >= 0x3D0AL) != 0xF9L);
            l_52 |= g_4[0];
        }
        l_31 = ((safe_lshift_func_int8_t_s_u(((((safe_mul_func_uint8_t_u_u((((p_12 <= 18446744073709551615UL) < g_2[5]) && 7UL), p_11)) <= l_30) <= 0xBF325E6BL) , p_8), 2)) && g_28);
        g_4[0] = g_2[5];
    }
    return l_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_28
 * writes: g_4 g_28
 */
static int8_t  func_13(int32_t  p_14, int32_t  p_15, uint64_t  p_16)
{ /* block id: 3 */
    uint64_t l_19 = 18446744073709551609UL;
    int32_t l_20 = (-1L);
lbl_23:
    g_4[0] = (safe_rshift_func_uint16_t_u_u(p_15, 10));
    l_20 = l_19;
    for (l_20 = 0; (l_20 > 1); l_20++)
    { /* block id: 8 */
        int32_t l_26 = (-1L);
        int32_t l_27[5];
        int i;
        for (i = 0; i < 5; i++)
            l_27[i] = 0x2C02A306L;
        if (l_19)
            goto lbl_23;
        l_27[4] = (((safe_mod_func_int16_t_s_s(p_15, p_14)) ^ l_26) || l_20);
        for (p_14 = 7; (p_14 >= 0); p_14 -= 1)
        { /* block id: 13 */
            int i;
            g_28 ^= ((g_4[p_14] < p_14) < p_16);
            return g_4[7];
        }
    }
    return g_4[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 49
XXX times a non-volatile is write: 11
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 26
XXX percentage of non-volatile access: 76.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 7
   depth: 2, occurrence: 6

XXX percentage a fresh-made variable is used: 19.2
XXX percentage an existing variable is used: 80.8
********************* end of statistics **********************/

