/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6347188675471443828
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0L;
static int32_t g_5[5][6][8] = {{{0L,(-7L),0x121F90EFL,(-7L),0L,0xEDE0B407L,0x6E6F7FBFL,1L},{0xEDE0B407L,1L,0L,1L,9L,(-6L),(-7L),(-7L)},{0xDD03248CL,(-6L),0L,0L,(-6L),0xDD03248CL,0x6E6F7FBFL,9L},{9L,(-1L),0x121F90EFL,1L,(-7L),1L,0xDD03248CL,0xEDE0B407L},{0x121F90EFL,0xA9C4C8D3L,0xEDE0B407L,1L,0xEDE0B407L,0xA9C4C8D3L,0x121F90EFL,9L},{(-6L),0xEDE0B407L,1L,0L,1L,9L,(-1L),0xEDE0B407L}},{{0x6E6F7FBFL,0xDD03248CL,(-6L),0L,0L,(-6L),0xDD03248CL,0x6E6F7FBFL},{1L,0x6E6F7FBFL,(-6L),0xEDE0B407L,0x121F90EFL,0xDD03248CL,0xB844A754L,(-2L)},{1L,(-7L),1L,0xDD03248CL,0xEDE0B407L,0xDD03248CL,1L,(-7L)},{0x34BF8F0AL,0x6E6F7FBFL,(-2L),9L,1L,(-6L),0x121F90EFL,1L},{(-7L),0xDD03248CL,0L,0x121F90EFL,0x34BF8F0AL,0x34BF8F0AL,0x121F90EFL,0L},{0x121F90EFL,0x121F90EFL,(-2L),(-6L),0xA9C4C8D3L,(-6L),1L,1L}},{{0xA9C4C8D3L,(-6L),1L,1L,0xB844A754L,0L,0xB844A754L,1L},{(-6L),(-2L),(-6L),(-6L),(-1L),(-7L),0xDD03248CL,0L},{9L,1L,(-6L),0x121F90EFL,1L,(-1L),(-1L),1L},{9L,0xB844A754L,0xB844A754L,9L,(-1L),0x121F90EFL,1L,(-7L)},{(-6L),0xEDE0B407L,0x121F90EFL,0xDD03248CL,0xB844A754L,(-2L),(-7L),(-2L)},{0xA9C4C8D3L,0xEDE0B407L,1L,0xEDE0B407L,0xA9C4C8D3L,0x121F90EFL,9L,0x6E6F7FBFL}},{{0x121F90EFL,0xB844A754L,0xA9C4C8D3L,0L,0x34BF8F0AL,(-1L),0xEDE0B407L,0xEDE0B407L},{(-7L),1L,0xA9C4C8D3L,0xA9C4C8D3L,1L,(-7L),9L,0x34BF8F0AL},{0x34BF8F0AL,(-2L),1L,0x6E6F7FBFL,0xEDE0B407L,0L,(-7L),0x121F90EFL},{1L,(-6L),0x121F90EFL,0x6E6F7FBFL,0x121F90EFL,(-6L),1L,0x34BF8F0AL},{1L,0x121F90EFL,0xB844A754L,0xA9C4C8D3L,0L,0x34BF8F0AL,(-1L),0xEDE0B407L},{0x6E6F7FBFL,0xDD03248CL,(-6L),0L,0L,(-6L),0xDD03248CL,0x6E6F7FBFL}},{{1L,0x6E6F7FBFL,(-6L),0xEDE0B407L,0x121F90EFL,0xDD03248CL,0xB844A754L,(-2L)},{1L,(-7L),1L,0xDD03248CL,0xEDE0B407L,0xDD03248CL,1L,(-7L)},{0x34BF8F0AL,0x6E6F7FBFL,(-2L),9L,1L,(-6L),0x121F90EFL,1L},{(-7L),0xDD03248CL,0L,0x121F90EFL,0x34BF8F0AL,0x34BF8F0AL,0x121F90EFL,0L},{0x121F90EFL,0x121F90EFL,(-2L),(-6L),0xA9C4C8D3L,(-6L),1L,1L},{0xA9C4C8D3L,(-6L),1L,1L,0xB844A754L,0xA9C4C8D3L,1L,0x6E6F7FBFL}}};
static int32_t g_54 = 6L;
static int32_t g_57 = (-5L);
static uint32_t g_107[4][6][7] = {{{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL}},{{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL}},{{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL}},{{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL},{0xA1D3BC2FL,0xA1D3BC2FL,18446744073709551608UL,8UL,0UL,8UL,18446744073709551608UL}}};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint8_t  func_12(int16_t  p_13, uint64_t  p_14, uint16_t  p_15, uint16_t  p_16);
static const int32_t  func_17(int16_t  p_18, int16_t  p_19);
static uint32_t  func_30(int32_t  p_31, int64_t  p_32, int16_t  p_33, int8_t  p_34);
static int8_t  func_36(uint32_t  p_37, uint32_t  p_38, uint32_t  p_39);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_54 g_107
 * writes: g_2 g_5 g_54 g_107
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int64_t l_9 = 0L;
    int32_t l_83[8];
    int32_t l_84[6];
    int64_t l_101[6] = {0xB8D8D308ECB2A787LL,0xB03130811D2751B8LL,0xB8D8D308ECB2A787LL,0xB8D8D308ECB2A787LL,0xB03130811D2751B8LL,0xB8D8D308ECB2A787LL};
    uint64_t l_115 = 0xDCAF14A35B98692FLL;
    int i;
    for (i = 0; i < 8; i++)
        l_83[i] = 7L;
    for (i = 0; i < 6; i++)
        l_84[i] = 0x198010E0L;
lbl_108:
    for (g_2 = 0; (g_2 > 27); g_2 = safe_add_func_int64_t_s_s(g_2, 1))
    { /* block id: 3 */
        int64_t l_8 = 0xC6FE23A266D210ECLL;
        int8_t l_79 = 0xF8L;
        int32_t l_85 = 0xB19369D4L;
        int32_t l_86[9];
        uint16_t l_87[9][1][9] = {{{0x7E09L,0x68EBL,0x3792L,5UL,2UL,5UL,0x3792L,0x68EBL,0x7E09L}},{{0x2E29L,0x21D5L,0x6180L,1UL,65535UL,0x6180L,65527UL,0x6180L,65535UL}},{{0xA361L,0x7CF1L,0x7CF1L,0xA361L,0x7E09L,0x68EBL,0x3792L,5UL,2UL}},{{0x21D5L,65535UL,65527UL,0x3E9DL,0x3E9DL,65527UL,65535UL,0x21D5L,0xE29FL}},{{0xCE11L,0xCC5FL,2UL,1UL,0x7E09L,5UL,5UL,0x7E09L,1UL}},{{0xB33DL,0x2E29L,0xB33DL,65535UL,65535UL,0x3E9DL,1UL,0xE29FL,0xE29FL}},{{0x7CF1L,0xCE11L,1UL,5UL,1UL,0xCE11L,0x7CF1L,0x3792L,2UL}},{{1UL,0x3E9DL,65535UL,65535UL,0xB33DL,0x2E29L,0xB33DL,65535UL,65535UL}},{{5UL,5UL,0x7E09L,1UL,2UL,0xCC5FL,0xCE11L,0x3792L,0xCE11L}}};
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_86[i] = 0x60B5C0E8L;
        for (g_5[0][5][2] = (-23); (g_5[0][5][2] <= (-30)); g_5[0][5][2]--)
        { /* block id: 6 */
            int8_t l_10 = 0x7FL;
            l_8 = 7L;
            l_10 |= (g_2 != l_9);
        }
        if (((!func_12(g_2, g_2, l_8, l_8)) == l_79))
        { /* block id: 61 */
            g_5[0][5][2] ^= (-1L);
            if (l_9)
                goto lbl_108;
        }
        else
        { /* block id: 63 */
            uint32_t l_82 = 1UL;
            l_83[2] = (safe_lshift_func_uint8_t_u_s(l_82, 4));
        }
        ++l_87[4][0][2];
        if ((safe_sub_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u((safe_mod_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_u(g_2, 3)) ^ l_83[4]), (-4L))), 0x1E6BC952145F4387LL)) , 4294967294UL), l_79)))
        { /* block id: 67 */
            uint16_t l_100 = 0x7CD6L;
            l_101[0] ^= (((safe_div_func_int8_t_s_s(g_2, l_100)) <= 0x446BL) , 1L);
            return l_83[2];
        }
        else
        { /* block id: 70 */
            uint64_t l_102 = 8UL;
            --l_102;
            g_107[0][5][2] |= (safe_add_func_uint8_t_u_u(g_5[4][5][5], g_54));
            l_84[0] = ((l_102 ^ l_102) , g_107[0][2][0]);
            if (l_102)
                break;
        }
    }
    for (g_54 = 0; (g_54 <= 5); g_54 += 1)
    { /* block id: 80 */
        uint16_t l_116 = 0xA8DCL;
        int i;
        l_116 = (safe_mul_func_int16_t_s_s(((((((safe_lshift_func_int16_t_s_s((safe_add_func_int16_t_s_s(((l_101[g_54] == 0UL) != 18446744073709551614UL), g_5[4][5][7])), 7)) == l_101[0]) > g_107[0][5][2]) || l_115) ^ l_101[g_54]) && l_101[g_54]), g_5[0][5][2]));
    }
    l_84[0] = 0xA1952B13L;
    return g_107[2][4][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_54
 * writes: g_5 g_54
 */
static uint8_t  func_12(int16_t  p_13, uint64_t  p_14, uint16_t  p_15, uint16_t  p_16)
{ /* block id: 10 */
    uint32_t l_78 = 4294967295UL;
    l_78 = func_17(g_5[0][5][2], g_5[0][3][3]);
    return l_78;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_54
 * writes: g_5 g_54
 */
static const int32_t  func_17(int16_t  p_18, int16_t  p_19)
{ /* block id: 11 */
    uint32_t l_28 = 0x6D7D0454L;
    int32_t l_29 = 0L;
    int32_t l_60[6] = {0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL,0x759721CBL};
    int32_t l_76[2];
    int i;
    for (i = 0; i < 2; i++)
        l_76[i] = 0xF3B42422L;
    for (p_19 = 1; (p_19 != 13); p_19 = safe_add_func_int8_t_s_s(p_19, 3))
    { /* block id: 14 */
        for (p_18 = 0; (p_18 != (-6)); p_18 = safe_sub_func_int32_t_s_s(p_18, 6))
        { /* block id: 17 */
            g_5[0][5][2] = (safe_rshift_func_int16_t_s_u((p_19 < p_18), g_5[0][5][2]));
            return p_18;
        }
    }
    l_29 = (safe_lshift_func_int8_t_s_s(((0x674FA72D50FA8FADLL | p_18) <= l_28), 4));
    if (p_18)
        goto lbl_55;
lbl_55:
    g_54 |= (((func_30((!(func_36(g_5[0][5][2], g_5[3][5][1], g_5[0][5][2]) >= g_5[0][5][2])), l_28, p_19, l_29) ^ l_29) <= g_2) , 0x2E963E9BL);
    for (l_29 = 0; (l_29 <= 4); l_29 += 1)
    { /* block id: 42 */
        int32_t l_56 = 1L;
        int32_t l_61 = 0x8D4ED1E2L;
        int32_t l_62 = 0xA5B821BFL;
        int32_t l_63 = 0x091E6DCFL;
        int32_t l_64 = 1L;
        int32_t l_65 = 0x5961936EL;
        int32_t l_66 = 0x930A8756L;
        int32_t l_67[2];
        int i;
        for (i = 0; i < 2; i++)
            l_67[i] = (-1L);
        for (g_54 = 4; (g_54 >= 0); g_54 -= 1)
        { /* block id: 45 */
            int64_t l_58 = 0x75F97E6E1851AA8CLL;
            int32_t l_59[2];
            uint8_t l_68 = 0x0DL;
            int i;
            for (i = 0; i < 2; i++)
                l_59[i] = 1L;
            l_56 = l_28;
            l_68--;
        }
        if (g_5[0][5][2])
            break;
        for (p_18 = 4; (p_18 >= 1); p_18 -= 1)
        { /* block id: 52 */
            uint16_t l_73 = 65529UL;
            int32_t l_77 = 0xB6057BADL;
            l_56 = (safe_mul_func_uint8_t_u_u(1UL, l_73));
            g_5[0][5][2] = (p_19 < g_5[0][5][2]);
            l_77 = (((safe_rshift_func_int8_t_s_u(((((0xDA12577EDFD6319DLL | 9UL) || l_60[2]) > 0x1BL) , l_60[4]), 6)) || (-9L)) <= l_76[0]);
        }
    }
    return p_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5
 * writes: g_5
 */
static uint32_t  func_30(int32_t  p_31, int64_t  p_32, int16_t  p_33, int8_t  p_34)
{ /* block id: 27 */
    int32_t l_51 = 0xAFFF74B7L;
    for (p_34 = (-10); (p_34 > 3); p_34 = safe_add_func_int16_t_s_s(p_34, 1))
    { /* block id: 30 */
        int32_t l_48[2];
        int i;
        for (i = 0; i < 2; i++)
            l_48[i] = 5L;
        l_48[1] = g_2;
        l_51 ^= (safe_sub_func_int8_t_s_s(g_5[0][5][2], 1UL));
        g_5[1][2][7] = (-4L);
        g_5[1][1][5] |= p_34;
    }
    g_5[0][5][2] = (safe_lshift_func_int8_t_s_u((p_32 == l_51), 2));
    return p_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5
 * writes:
 */
static int8_t  func_36(uint32_t  p_37, uint32_t  p_38, uint32_t  p_39)
{ /* block id: 23 */
    uint16_t l_40 = 0xF3F0L;
    int32_t l_45 = 0x377F0A06L;
    --l_40;
    l_45 = ((safe_mul_func_uint16_t_u_u((((((g_2 != g_5[0][5][2]) == l_40) , 0xDF66L) , g_5[0][5][2]) < 0xBB9A2F72L), l_40)) > l_40);
    return g_5[0][5][2];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_5[i][j][k], "g_5[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_54, "g_54", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_107[i][j][k], "g_107[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 40
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 49
   depth: 2, occurrence: 15
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 78
XXX times a non-volatile is write: 36
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 49
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 13
   depth: 2, occurrence: 18

XXX percentage a fresh-made variable is used: 23.7
XXX percentage an existing variable is used: 76.3
********************* end of statistics **********************/

