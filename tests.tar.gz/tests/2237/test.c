/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5908642902713024165
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile uint16_t g_2[1] = {0xA860L};
static volatile uint64_t g_3 = 18446744073709551615UL;/* VOLATILE GLOBAL g_3 */
static uint8_t g_29 = 4UL;
static uint32_t g_30 = 3UL;
static uint32_t g_31 = 0x7440E708L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_4(int32_t  p_5, int32_t  p_6);
static uint64_t  func_10(uint8_t  p_11, uint32_t  p_12, uint32_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_29 g_30 g_31
 * writes: g_3 g_30 g_31
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9 = 0xAD2086BDL;
    g_3 = (g_2[0] , g_2[0]);
    l_9 = func_4((safe_add_func_int8_t_s_s(0x4AL, 0x74L)), l_9);
    return l_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_29 g_30 g_31
 * writes: g_30 g_31
 */
static int32_t  func_4(int32_t  p_5, int32_t  p_6)
{ /* block id: 2 */
    uint32_t l_14 = 0x21A35CA4L;
    int32_t l_32 = 0xF34EA885L;
    l_32 = (func_10(p_5, l_14, l_14) == 8L);
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_29 g_30 g_31
 * writes: g_30 g_31
 */
static uint64_t  func_10(uint8_t  p_11, uint32_t  p_12, uint32_t  p_13)
{ /* block id: 3 */
    uint64_t l_28 = 0xC9B780F885BD52A2LL;
    g_30 = (((((safe_lshift_func_uint16_t_u_s((((safe_add_func_int32_t_s_s(((((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_s((+((safe_rshift_func_int16_t_s_s((safe_sub_func_uint16_t_u_u(0x906DL, 1L)), g_2[0])) <= 0x40L)), 5)), l_28)) , g_3) , p_12) , (-1L)), p_13)) , p_12) >= l_28), p_11)) > g_29) <= l_28) || g_2[0]) | p_11);
    g_31 ^= g_30;
    return p_11;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 17
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 17, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 4
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 77.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 8

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

