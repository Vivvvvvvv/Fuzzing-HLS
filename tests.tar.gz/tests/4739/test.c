/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17354042542388087175
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   const uint16_t  f1;
   uint64_t  f2;
   const uint16_t  f3;
   int64_t  f4;
   uint64_t  f5;
   uint64_t  f6;
   volatile uint64_t  f7;
   int64_t  f8;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_2 = 1UL;/* VOLATILE GLOBAL g_2 */
static int32_t g_5 = 0x7E55059BL;
static uint32_t g_36 = 4294967295UL;
static int64_t g_48 = 0x0C5ABFEDE048FFD5LL;
static volatile struct S0 g_49 = {0xF1F3E168L,0UL,18446744073709551615UL,7UL,0xF8C547FCE3BADF38LL,0x70E9EE1947684A57LL,6UL,0UL,0x783EA6DE45221BA8LL};/* VOLATILE GLOBAL g_49 */
static int8_t g_53 = 0x0CL;
static int32_t g_57 = (-1L);
static int16_t g_63 = 0x3458L;
static uint8_t g_74 = 0x3CL;
static int16_t g_84 = 0x4845L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const int32_t  func_15(uint16_t  p_16, int16_t  p_17, const uint64_t  p_18, int32_t  p_19);
static int32_t  func_22(int16_t  p_23, uint16_t  p_24, int32_t  p_25, int32_t  p_26, uint64_t  p_27);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_36 g_48 g_49 g_57 g_63 g_53 g_74
 * writes: g_2 g_5 g_36 g_48 g_53 g_57 g_63 g_74 g_84
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_14 = 6L;
    int32_t l_69 = (-3L);
    uint64_t l_85[3];
    int i;
    for (i = 0; i < 3; i++)
        l_85[i] = 18446744073709551614UL;
    ++g_2;
    for (g_5 = (-11); (g_5 != 25); g_5 = safe_add_func_uint32_t_u_u(g_5, 2))
    { /* block id: 4 */
        uint64_t l_20[10] = {0x51162F63069BE541LL,18446744073709551607UL,0x51162F63069BE541LL,0x51162F63069BE541LL,18446744073709551607UL,0x51162F63069BE541LL,0x51162F63069BE541LL,18446744073709551607UL,0x51162F63069BE541LL,0x51162F63069BE541LL};
        int32_t l_83 = 0x4EAFE12CL;
        int i;
        l_14 = (((safe_div_func_int8_t_s_s(((safe_add_func_int8_t_s_s((safe_add_func_uint32_t_u_u(1UL, 0xBF33880EL)), 0x55L)) < 4294967295UL), g_2)) || 0x044BL) | g_5);
        g_63 &= func_15(g_2, l_20[1], l_14, l_14);
        for (g_57 = 0; (g_57 == 21); g_57++)
        { /* block id: 52 */
            int32_t l_66 = 0xEF28B5E6L;
            l_66 |= (0x0C1829B6EDA74E99LL ^ g_5);
            l_69 = (safe_add_func_uint8_t_u_u(g_2, g_53));
        }
        for (g_53 = 0; (g_53 == (-14)); g_53--)
        { /* block id: 58 */
            g_74 = (safe_rshift_func_int16_t_s_u(l_20[1], l_20[5]));
            g_84 = ((safe_add_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u((safe_add_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_u((g_49.f2 , g_49.f6), g_74)) ^ l_83), g_74)), 5L)) || g_53), (-8L))) < (-2L));
        }
    }
    for (g_63 = 2; (g_63 >= 0); g_63 -= 1)
    { /* block id: 65 */
        int32_t l_92 = (-1L);
        int i;
        g_5 = (((safe_sub_func_int32_t_s_s((safe_rshift_func_int16_t_s_s(l_85[g_63], 4)), l_14)) || l_85[2]) , g_63);
        for (g_84 = 0; g_84 < 3; g_84 += 1)
        {
            l_85[g_84] = 5UL;
        }
        l_92 |= ((((safe_mul_func_uint16_t_u_u(g_2, g_48)) > 0L) | l_85[1]) > 1UL);
        l_69 = ((safe_mod_func_int64_t_s_s((safe_unary_minus_func_int32_t_s(l_14)), g_63)) == l_85[g_63]);
    }
    return g_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_36 g_48 g_49 g_57
 * writes: g_36 g_48 g_53 g_57
 */
static const int32_t  func_15(uint16_t  p_16, int16_t  p_17, const uint64_t  p_18, int32_t  p_19)
{ /* block id: 6 */
    uint16_t l_21 = 0x5C22L;
    uint32_t l_60 = 18446744073709551615UL;
    int32_t l_61 = 0xD6BB23DFL;
    l_21 &= 0x748ABB75L;
    p_19 = func_22((~(0L > 0L)), g_2, g_5, p_16, g_5);
    if (p_16)
        goto lbl_62;
lbl_62:
    l_61 = ((((((safe_mul_func_int16_t_s_s(g_49.f4, 0xF738L)) == g_36) , p_16) > 0x73D9L) | p_17) < l_60);
    p_19 = (0x8F630B13CFF85525LL >= 0x776A221E1226129DLL);
    return l_61;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_36 g_48 g_49 g_5 g_57
 * writes: g_36 g_48 g_53 g_57
 */
static int32_t  func_22(int16_t  p_23, uint16_t  p_24, int32_t  p_25, int32_t  p_26, uint64_t  p_27)
{ /* block id: 8 */
    uint32_t l_35 = 4294967295UL;
    int32_t l_42 = 0xCB1BEBA4L;
    for (p_23 = (-23); (p_23 <= (-8)); p_23++)
    { /* block id: 11 */
        int32_t l_39 = 0x2F002739L;
        uint16_t l_43[1];
        int32_t l_50 = 0x37D67F3EL;
        int i;
        for (i = 0; i < 1; i++)
            l_43[i] = 65530UL;
        for (p_25 = 0; (p_25 >= (-12)); p_25--)
        { /* block id: 14 */
            g_36 = (((l_35 >= p_23) , 1UL) <= l_35);
            l_39 = (((safe_mod_func_uint8_t_u_u((p_24 , 248UL), g_2)) ^ p_26) != (-1L));
            l_42 |= (safe_sub_func_uint8_t_u_u((0x7BAB6EA1325A46E4LL & 0xC1A1FD29CC027682LL), g_36));
        }
        for (l_35 = 0; (l_35 <= 0); l_35 += 1)
        { /* block id: 21 */
            int i;
            g_48 |= (safe_sub_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((l_43[l_35] >= (-3L)), 0xE903ADFEL)), p_27));
            l_50 = ((((g_49 , p_24) , 0xFDL) == 1UL) < l_43[l_35]);
        }
    }
    for (l_42 = 0; (l_42 > (-8)); l_42 = safe_sub_func_uint8_t_u_u(l_42, 5))
    { /* block id: 28 */
        return p_23;
    }
lbl_56:
    g_53 = g_48;
    for (g_36 = (-7); (g_36 == 18); g_36 = safe_add_func_uint32_t_u_u(g_36, 9))
    { /* block id: 34 */
        if (g_48)
            break;
        if ((((((((g_49.f3 & g_5) <= l_35) | 0L) , (-8L)) >= p_24) > 0xEBEB99C0L) < (-1L)))
        { /* block id: 36 */
            if (l_35)
                goto lbl_56;
        }
        else
        { /* block id: 38 */
            g_57 &= (p_25 < p_25);
            if (g_49.f2)
                break;
        }
    }
    return l_35;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49.f0, "g_49.f0", print_hash_value);
    transparent_crc(g_49.f1, "g_49.f1", print_hash_value);
    transparent_crc(g_49.f2, "g_49.f2", print_hash_value);
    transparent_crc(g_49.f3, "g_49.f3", print_hash_value);
    transparent_crc(g_49.f4, "g_49.f4", print_hash_value);
    transparent_crc(g_49.f5, "g_49.f5", print_hash_value);
    transparent_crc(g_49.f6, "g_49.f6", print_hash_value);
    transparent_crc(g_49.f7, "g_49.f7", print_hash_value);
    transparent_crc(g_49.f8, "g_49.f8", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 33
   depth: 2, occurrence: 14
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 5
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 58
XXX times a non-volatile is write: 29
XXX times a volatile is read: 12
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 45
XXX percentage of non-volatile access: 87

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 40
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 13
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 27.5
XXX percentage an existing variable is used: 72.5
********************* end of statistics **********************/

