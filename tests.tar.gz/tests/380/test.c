/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10504001000108141712
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 1L;/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = (-1L);/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 2L;
static int32_t g_12 = 0xB17B722BL;
static int32_t g_18[10] = {0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L,0x2C4DF8E3L};
static int32_t g_26 = 0x5EBAE88BL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_8(int32_t  p_9);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3 g_12 g_4 g_18 g_26
 * writes: g_5 g_3 g_12 g_18 g_26 g_4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[2];
    int32_t l_6 = 0xB2906C90L;
    int i;
    for (i = 0; i < 2; i++)
        l_2[i] = 0x638ECF54L;
    if (((l_2[0] || 0x182EL) || l_2[0]))
    { /* block id: 1 */
        uint32_t l_7 = 0xD0A7084BL;
        for (g_5 = 1; (g_5 >= 0); g_5 -= 1)
        { /* block id: 4 */
            int i;
            g_3 = l_2[g_5];
            l_7 = l_6;
            g_26 &= (func_8(g_3) || g_3);
            return g_3;
        }
        return l_6;
    }
    else
    { /* block id: 29 */
        g_4 = l_2[0];
    }
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_4 g_5 g_18 g_3
 * writes: g_12 g_18 g_3
 */
static int8_t  func_8(int32_t  p_9)
{ /* block id: 7 */
    int8_t l_17 = 0x09L;
    int32_t l_19 = 0x66C4779DL;
    for (p_9 = 0; (p_9 > 1); p_9++)
    { /* block id: 10 */
        uint16_t l_20 = 65527UL;
        for (g_12 = 0; (g_12 >= 5); g_12 = safe_add_func_int16_t_s_s(g_12, 2))
        { /* block id: 13 */
            g_18[9] &= (((((safe_rshift_func_uint16_t_u_u((g_4 & p_9), g_12)) >= 0L) | g_5) >= l_17) , l_17);
        }
        l_20--;
        if (g_3)
        { /* block id: 17 */
            uint64_t l_23[4][10] = {{0xC630DE2FD17BA7DALL,0xFE96F77D900D2964LL,0xC4B79A97A8D1D9D6LL,0xC4B79A97A8D1D9D6LL,0xFE96F77D900D2964LL,0xC630DE2FD17BA7DALL,0UL,0UL,0xC1E183A0997736EALL,0x71C19CD890F6DAE1LL},{0UL,0x0CE7AEBB1BB30B13LL,0x4EDB553A81F6ED73LL,0xC630DE2FD17BA7DALL,0xBF7C295A52772010LL,0x11771B705618D7C5LL,0x8EAF6082F4E55B65LL,0xD3709E8E548E01AFLL,0x8EAF6082F4E55B65LL,0x11771B705618D7C5LL},{0UL,0UL,18446744073709551609UL,0UL,0UL,0xC630DE2FD17BA7DALL,0x11771B705618D7C5LL,0UL,0x258D0336D065835ALL,1UL},{0xC630DE2FD17BA7DALL,0x11771B705618D7C5LL,0UL,0x258D0336D065835ALL,1UL,0x71C19CD890F6DAE1LL,0xBF7C295A52772010LL,0xBF7C295A52772010LL,0UL,0xA7221EBC5F93BE41LL}};
            int i, j;
            ++l_23[0][2];
        }
        else
        { /* block id: 19 */
            g_3 ^= g_18[9];
        }
        return p_9;
    }
    return g_18[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_26, "g_26", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 8
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 73.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 18
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 4
   depth: 1, occurrence: 7
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 28.1
XXX percentage an existing variable is used: 71.9
********************* end of statistics **********************/

