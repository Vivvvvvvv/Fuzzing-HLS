/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13105700289959688733
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_6 = 65526UL;
static int8_t g_34 = 1L;
static uint32_t g_37 = 0UL;
static volatile uint32_t g_48 = 18446744073709551610UL;/* VOLATILE GLOBAL g_48 */
static uint16_t g_52 = 1UL;
static int64_t g_55 = (-6L);
static volatile int32_t g_60 = 0x51060F33L;/* VOLATILE GLOBAL g_60 */
static volatile int8_t g_62[1][9][10] = {{{0xF8L,0xF2L,0x8AL,0xF8L,0x64L,(-2L),9L,0L,0x8AL,0x8AL},{0x64L,0xF2L,0L,0x42L,0x42L,0L,0xF2L,0x64L,0xACL,0x55L},{0L,0xF8L,0x04L,0L,(-2L),0x48L,0x55L,(-2L),0xF8L,0x42L},{9L,0x64L,0x04L,(-2L),(-1L),(-2L),0x04L,0x64L,9L,0x04L},{0L,0L,0L,0x55L,0L,1L,9L,0x8AL,0x55L,0x04L},{(-2L),0x53L,0x9FL,0x04L,1L,1L,0x04L,0x9FL,0x53L,(-2L)},{0x9FL,0x8AL,0x53L,0L,0xD9L,0xACL,0x9FL,(-2L),0xACL,0x53L},{0x8AL,(-2L),0L,0x8AL,0xD9L,0x55L,0xD9L,0x8AL,0L,(-2L)},{0xD9L,0x9FL,(-1L),9L,1L,(-1L),(-2L),0x53L,0x9FL,0x04L}}};
static volatile int16_t g_63 = (-1L);/* VOLATILE GLOBAL g_63 */
static int16_t g_65[10][4][6] = {{{0x22FFL,(-1L),1L,1L,(-1L),0x22FFL},{0xF469L,0x22FFL,1L,0x22FFL,0xF469L,0xF469L},{(-4L),0x22FFL,0x22FFL,(-4L),(-1L),(-4L)},{(-4L),(-1L),(-4L),0x22FFL,0x22FFL,(-4L)}},{{0xF469L,0xF469L,0x22FFL,1L,0x22FFL,0xF469L},{0x22FFL,(-1L),1L,1L,(-1L),0x22FFL},{0xF469L,0x22FFL,1L,0x22FFL,0xF469L,0xF469L},{(-4L),0x22FFL,0x22FFL,(-4L),(-1L),(-4L)}},{{(-4L),(-1L),(-4L),0x22FFL,0x22FFL,(-4L)},{0xF469L,0xF469L,0x22FFL,1L,0x22FFL,0xF469L},{0x22FFL,(-1L),1L,1L,(-1L),0x22FFL},{0xF469L,0x22FFL,1L,0x22FFL,0xF469L,0xF469L}},{{(-4L),0x22FFL,0x22FFL,(-4L),(-1L),(-4L)},{(-4L),(-1L),(-4L),0x22FFL,0x22FFL,(-4L)},{0xF469L,0xF469L,0x22FFL,1L,0x22FFL,0xF469L},{0x22FFL,(-1L),1L,1L,(-1L),0x22FFL}},{{0xF469L,0x22FFL,1L,0x22FFL,0xF469L,0xF469L},{(-4L),0x22FFL,0x22FFL,(-4L),(-1L),(-4L)},{(-4L),(-1L),(-4L),0x22FFL,0x22FFL,(-4L)},{0xF469L,0xF469L,0x22FFL,1L,0x22FFL,0xF469L}},{{0x22FFL,(-1L),1L,1L,(-1L),0x22FFL},{0xF469L,0x22FFL,1L,0x22FFL,0xF469L,0xF469L},{(-4L),0x22FFL,0x22FFL,(-4L),(-1L),(-4L)},{(-4L),(-1L),(-4L),0x22FFL,0x22FFL,(-4L)}},{{0xF469L,0xF469L,0x22FFL,(-1L),(-4L),0x22FFL},{(-4L),0xF469L,(-1L),(-1L),0xF469L,(-4L)},{0x22FFL,(-4L),(-1L),(-4L),0x22FFL,0x22FFL},{1L,(-4L),(-4L),1L,0xF469L,1L}},{{1L,0xF469L,1L,(-4L),(-4L),1L},{0x22FFL,0x22FFL,(-4L),(-1L),(-4L),0x22FFL},{(-4L),0xF469L,(-1L),(-1L),0xF469L,(-4L)},{0x22FFL,(-4L),(-1L),(-4L),0x22FFL,0x22FFL}},{{1L,(-4L),(-4L),1L,0xF469L,1L},{1L,0xF469L,1L,(-4L),(-4L),1L},{0x22FFL,0x22FFL,(-4L),(-1L),(-4L),0x22FFL},{(-4L),0xF469L,(-1L),(-1L),0xF469L,(-4L)}},{{0x22FFL,(-4L),(-1L),(-4L),0x22FFL,0x22FFL},{1L,(-4L),(-4L),1L,0xF469L,1L},{1L,0xF469L,1L,(-4L),(-4L),1L},{0x22FFL,0x22FFL,(-4L),(-1L),(-4L),0x22FFL}}};
static volatile int16_t g_66 = 5L;/* VOLATILE GLOBAL g_66 */
static volatile int8_t g_67 = 7L;/* VOLATILE GLOBAL g_67 */
static volatile uint16_t g_68 = 65535UL;/* VOLATILE GLOBAL g_68 */
static volatile uint16_t g_86 = 65535UL;/* VOLATILE GLOBAL g_86 */
static int64_t g_90[4][10] = {{(-1L),0L,(-6L),(-6L),0L,(-1L),(-1L),0L,(-1L),(-1L)},{0xE6AD316F54511143LL,0L,(-6L),0L,0xE6AD316F54511143LL,(-6L),(-10L),(-10L),(-6L),0xE6AD316F54511143LL},{0xE6AD316F54511143LL,(-1L),(-1L),0xE6AD316F54511143LL,(-6L),(-1L),0xE6AD316F54511143LL,(-1L),(-6L),0xE6AD316F54511143LL},{(-1L),0xE6AD316F54511143LL,(-1L),(-6L),0xE6AD316F54511143LL,(-1L),(-1L),0xE6AD316F54511143LL,(-6L),(-1L)}};
static volatile int32_t g_93 = 0x6EF8CBCAL;/* VOLATILE GLOBAL g_93 */
static volatile int32_t g_95 = 0xEF93BB08L;/* VOLATILE GLOBAL g_95 */
static volatile uint64_t g_97 = 0x8C8CF6E8DA2FB924LL;/* VOLATILE GLOBAL g_97 */
static volatile int8_t g_106 = 0x12L;/* VOLATILE GLOBAL g_106 */
static uint32_t g_130[5] = {4294967293UL,4294967293UL,4294967293UL,4294967293UL,4294967293UL};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_19(int8_t  p_20, int8_t  p_21, const uint32_t  p_22, int8_t  p_23);
static uint16_t  func_24(int32_t  p_25);
static int8_t  func_71(int32_t  p_72, uint16_t  p_73, const int32_t  p_74, uint8_t  p_75, uint32_t  p_76);
static int32_t  func_79(uint16_t  p_80);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_34 g_37 g_48 g_68 g_52 g_60 g_86 g_97 g_106 g_66 g_62 g_90 g_130
 * writes: g_6 g_34 g_37 g_48 g_52 g_55 g_68 g_60 g_86 g_97 g_130
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5 = (-8L);
    int32_t l_10 = 0x1E6E2BFBL;
    uint64_t l_15 = 0UL;
lbl_16:
    g_6 |= ((!((safe_mul_func_int8_t_s_s(0x74L, l_5)) , l_5)) , l_5);
    if ((safe_mul_func_int8_t_s_s(g_6, 3L)))
    { /* block id: 2 */
        int32_t l_9[9] = {0L,0x39E3CF95L,0L,0x39E3CF95L,0L,0x39E3CF95L,0L,0x39E3CF95L,0L};
        int i;
        l_10 &= (l_9[7] , g_6);
    }
    else
    { /* block id: 4 */
        int32_t l_26 = (-9L);
        int16_t l_36 = 5L;
        int32_t l_43 = 0x5925F8A4L;
lbl_56:
        if ((safe_mod_func_int64_t_s_s(((((((safe_mod_func_uint8_t_u_u((l_10 | g_6), 0x80L)) || l_5) < 1L) && l_15) > 0L) & g_6), 1UL)))
        { /* block id: 5 */
            int32_t l_33 = 6L;
            if (l_10)
                goto lbl_16;
            g_37 |= (safe_mul_func_int16_t_s_s(((func_19((func_24(l_26) >= l_33), g_6, g_6, g_6) , l_36) , g_34), g_6));
            return l_33;
        }
        else
        { /* block id: 17 */
            uint64_t l_40 = 0x1CE094BF7D69FDB8LL;
            l_40 |= (safe_mod_func_uint16_t_u_u(func_24(g_34), l_36));
            l_43 = (safe_mod_func_uint16_t_u_u((g_37 != g_6), g_6));
        }
        if ((safe_rshift_func_uint8_t_u_u((safe_mod_func_int16_t_s_s(func_24(l_26), (-2L))), g_34)))
        { /* block id: 21 */
            int32_t l_51 = 0xEBEF2777L;
            ++g_48;
            g_52 = l_51;
            g_55 = ((safe_lshift_func_uint16_t_u_u(l_26, l_5)) != l_51);
            if (l_26)
                goto lbl_56;
        }
        else
        { /* block id: 26 */
            uint32_t l_57 = 0UL;
            int32_t l_61 = 1L;
            int32_t l_64 = 0xBB8911F7L;
            --l_57;
            --g_68;
            g_130[4] |= func_19(func_71(l_43, g_52, l_57, g_60, g_34), l_15, g_90[3][4], g_52);
            return g_130[4];
        }
    }
    return g_90[2][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_34
 * writes: g_34
 */
static int32_t  func_19(int8_t  p_20, int8_t  p_21, const uint32_t  p_22, int8_t  p_23)
{ /* block id: 11 */
    int64_t l_35 = 1L;
    g_34 ^= (-5L);
    l_35 = (g_34 > 2UL);
    return l_35;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_24(int32_t  p_25)
{ /* block id: 7 */
    uint32_t l_27 = 0xA812C005L;
    int32_t l_28 = 0L;
    l_28 |= (p_25 || l_27);
    l_28 &= (safe_rshift_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s(p_25, 11)), p_25));
    return p_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_68 g_34 g_6 g_60 g_86 g_97 g_106 g_37 g_66 g_62
 * writes: g_34 g_6 g_60 g_86 g_97 g_37
 */
static int8_t  func_71(int32_t  p_72, uint16_t  p_73, const int32_t  p_74, uint8_t  p_75, uint32_t  p_76)
{ /* block id: 29 */
    int64_t l_77 = 0L;
    int32_t l_78[3][9] = {{0x69ABC45AL,(-9L),0x69ABC45AL,0x69ABC45AL,(-9L),0x69ABC45AL,0x69ABC45AL,(-9L),0x69ABC45AL},{0x9C70A111L,0x2D206F84L,0x9C70A111L,9L,(-1L),9L,0x9C70A111L,0x2D206F84L,0x9C70A111L},{0x69ABC45AL,(-9L),0x69ABC45AL,0x69ABC45AL,(-9L),0x69ABC45AL,0x69ABC45AL,(-9L),0x69ABC45AL}};
    int i, j;
    l_78[2][6] |= (func_19(l_77, p_75, l_77, g_68) >= g_6);
    p_72 = func_79(l_78[1][3]);
    return l_77;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_60 g_86 g_97 g_106 g_37 g_66 g_62
 * writes: g_6 g_60 g_86 g_97 g_37
 */
static int32_t  func_79(uint16_t  p_80)
{ /* block id: 31 */
    int64_t l_83 = 0x7CE9F33C75065145LL;
    uint16_t l_107 = 65532UL;
    uint8_t l_111 = 0xEDL;
    int8_t l_129 = 0x93L;
    for (g_6 = (-25); (g_6 > 39); g_6++)
    { /* block id: 34 */
        uint16_t l_84 = 9UL;
        int32_t l_92[8] = {0xE18DB56EL,0xE18DB56EL,0xE18DB56EL,0xE18DB56EL,0xE18DB56EL,0xE18DB56EL,0xE18DB56EL,0xE18DB56EL};
        int i;
        if (l_83)
        { /* block id: 35 */
            uint64_t l_85[5][7];
            int i, j;
            for (i = 0; i < 5; i++)
            {
                for (j = 0; j < 7; j++)
                    l_85[i][j] = 0x44599546ADB2F3DDLL;
            }
            g_60 ^= l_83;
            l_85[0][6] = (l_84 | l_83);
            --g_86;
        }
        else
        { /* block id: 39 */
            int32_t l_89 = 0xA9C18A2FL;
            int32_t l_91 = 1L;
            int32_t l_94 = 1L;
            int32_t l_96 = 0x1D57AD53L;
            g_97++;
            if (l_83)
                break;
            if (p_80)
                continue;
            l_92[4] = (safe_mul_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(((safe_rshift_func_uint16_t_u_s((g_106 , 0x0219L), 10)) , p_80), l_107)), 0x19L));
        }
        return p_80;
    }
    for (g_37 = 0; (g_37 <= 3); g_37 += 1)
    { /* block id: 49 */
        uint64_t l_108 = 0x4A1B41FDD29F2DB0LL;
        int32_t l_120 = (-1L);
        g_60 = (l_108 || l_83);
        l_111 |= (((safe_mul_func_uint8_t_u_u(1UL, p_80)) != 65531UL) | g_97);
        l_120 = (safe_mul_func_int32_t_s_s(((((((safe_lshift_func_int16_t_s_s(((safe_add_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(g_37, l_108)), 65533UL)) != 0x4D5FF68FL), g_66)) , 0xE9L) != p_80) == 0x157DL) < l_108) , 0x3E15B557L), 0L));
        return l_83;
    }
    g_60 = (((safe_add_func_uint64_t_u_u(((safe_add_func_int64_t_s_s((safe_rshift_func_uint16_t_u_u(((safe_sub_func_int16_t_s_s(p_80, 7L)) > (-1L)), 12)), l_111)) < l_129), 0x347DC9BE96803575LL)) || p_80) == 0xDE3BL);
    return g_62[0][0][7];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_62[i][j][k], "g_62[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_63, "g_63", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_65[i][j][k], "g_65[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_90[i][j], "g_90[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_130[i], "g_130[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 51
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 9
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 6, occurrence: 2
   depth: 9, occurrence: 2
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 76
XXX times a non-volatile is write: 21
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 31
XXX percentage of non-volatile access: 88.2

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 45
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 9
   depth: 2, occurrence: 20

XXX percentage a fresh-made variable is used: 40.2
XXX percentage an existing variable is used: 59.8
********************* end of statistics **********************/

