/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18267020785581702387
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3[4][7] = {{0xC619A80BL,0xB01D91E6L,0xB01D91E6L,0xC619A80BL,0x673292C5L,0x41E4F1F1L,0x673292C5L},{0xC619A80BL,0xB01D91E6L,0xB01D91E6L,0xC619A80BL,0x673292C5L,0x41E4F1F1L,0x673292C5L},{0xC619A80BL,0xB01D91E6L,0xB01D91E6L,0xC619A80BL,0x673292C5L,0x41E4F1F1L,0x673292C5L},{0xC619A80BL,0xB01D91E6L,0xB01D91E6L,0xC619A80BL,0x673292C5L,0x41E4F1F1L,0x673292C5L}};
static volatile int32_t g_4[7][4] = {{0xF1E0C863L,0xA21E1D82L,1L,(-1L)},{0xA21E1D82L,0x96CE028FL,0x1B713623L,0xF1E0C863L},{6L,0xAB9737E0L,0xAB9737E0L,6L},{6L,(-1L),0x1B713623L,(-9L)},{0xA21E1D82L,6L,0x1B713623L,0xA21E1D82L},{(-1L),(-9L),(-1L),0xA21E1D82L},{0x1B713623L,0xAB9737E0L,0x5E2DE4BFL,0x96CE028FL}};
static int32_t g_5[8] = {(-2L),0x7806AA1CL,0x7806AA1CL,(-2L),0x7806AA1CL,0x7806AA1CL,(-2L),0x7806AA1CL};
static int8_t g_41 = 0x82L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_19(uint32_t  p_20, uint16_t  p_21);
static int8_t  func_25(int16_t  p_26, uint64_t  p_27, const uint64_t  p_28, uint64_t  p_29, int32_t  p_30);
static const int16_t  func_82(int32_t  p_83);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_3 g_41
 * writes: g_5 g_41 g_4 g_3
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[1][5][4] = {{{0x543BEB71L,0x734F0946L,0x543BEB71L,6L},{0x1AB6EC79L,0xBF25CBD9L,6L,6L},{0x734F0946L,0x734F0946L,1L,0xBF25CBD9L},{0xBF25CBD9L,0x1AB6EC79L,1L,0x1AB6EC79L},{0x734F0946L,0x543BEB71L,6L,1L}}};
    int8_t l_6 = 0xDBL;
    int16_t l_11 = (-1L);
    uint8_t l_22 = 1UL;
    int16_t l_56[9][9][3] = {{{0x2B7AL,(-10L),(-10L)},{0xC5FBL,0x0FE7L,1L},{(-5L),0xAF09L,(-10L)},{(-1L),0x47B3L,(-1L)},{7L,1L,(-1L)},{0xC5FBL,0x47B3L,0x5C8AL},{0xAF09L,0xAF09L,1L},{(-1L),0x0FE7L,(-1L)},{0xAF09L,(-10L),1L}},{{0xC5FBL,(-4L),1L},{7L,0xAF09L,1L},{(-1L),0L,(-1L)},{(-5L),1L,1L},{0xC5FBL,0L,0x5C8AL},{0x2B7AL,0xAF09L,(-1L)},{(-1L),(-4L),(-1L)},{0x2B7AL,(-10L),(-10L)},{0xC5FBL,0x0FE7L,1L}},{{(-5L),0xAF09L,(-10L)},{(-1L),0x47B3L,(-1L)},{7L,1L,(-1L)},{0xC5FBL,0x47B3L,0x5C8AL},{0xAF09L,0xAF09L,1L},{(-1L),0x0FE7L,(-1L)},{0xAF09L,(-10L),1L},{0xC5FBL,(-4L),1L},{7L,0xAF09L,1L}},{{(-1L),0L,(-1L)},{(-5L),1L,1L},{0xC5FBL,0L,0x5C8AL},{0x2B7AL,0xAF09L,(-1L)},{(-1L),(-4L),(-1L)},{0x2B7AL,(-10L),(-10L)},{0xC5FBL,0x0FE7L,1L},{(-5L),0xAF09L,(-10L)},{(-1L),0x47B3L,(-1L)}},{{7L,1L,(-1L)},{0xC5FBL,0x47B3L,0x5C8AL},{0xAF09L,0xAF09L,1L},{(-1L),0x0FE7L,(-1L)},{0xAF09L,(-10L),1L},{0xC5FBL,(-4L),1L},{7L,0xAF09L,1L},{(-1L),0L,(-1L)},{(-5L),1L,1L}},{{0xC5FBL,0L,0x5C8AL},{0x2B7AL,0xAF09L,(-1L)},{(-1L),(-4L),(-1L)},{0x2B7AL,(-10L),(-10L)},{0xC5FBL,0x0FE7L,1L},{(-5L),0xAF09L,(-10L)},{(-1L),0x47B3L,(-1L)},{7L,1L,(-1L)},{0xC5FBL,0x47B3L,0x5C8AL}},{{0xAF09L,0xAF09L,1L},{(-1L),0x0FE7L,(-1L)},{0xAF09L,(-10L),1L},{0xC5FBL,(-4L),1L},{7L,0xAF09L,1L},{(-1L),0L,(-1L)},{(-5L),1L,1L},{0xC5FBL,0L,0x5C8AL},{0x2B7AL,0xAF09L,(-1L)}},{{(-1L),(-4L),(-1L)},{0x2B7AL,(-10L),(-10L)},{0xC5FBL,0x0FE7L,1L},{(-5L),0xAF09L,(-10L)},{(-1L),0x47B3L,(-1L)},{7L,1L,(-1L)},{0xC5FBL,0x47B3L,0x5C8AL},{0xAF09L,0xAF09L,1L},{(-1L),0x0FE7L,(-1L)}},{{0xAF09L,(-10L),1L},{0xC5FBL,(-4L),1L},{7L,0xAF09L,1L},{(-1L),0L,(-1L)},{(-5L),1L,1L},{0xC5FBL,0L,0x5C8AL},{0x2B7AL,0xAF09L,(-1L)},{(-1L),(-4L),(-1L)},{0x2B7AL,(-10L),(-10L)}}};
    int i, j, k;
    for (g_5[0] = 0; (g_5[0] >= 0); g_5[0] -= 1)
    { /* block id: 3 */
        int64_t l_7 = 1L;
        int32_t l_8 = 0x5C380A38L;
        int32_t l_9[7][2] = {{(-1L),3L},{(-1L),1L},{0x3783312EL,0x3783312EL},{1L,(-1L)},{3L,(-1L)},{1L,0x3783312EL},{0x3783312EL,1L}};
        int64_t l_10 = 0xB4E52275DD3610CBLL;
        uint16_t l_12 = 0x80D4L;
        int i, j;
        --l_12;
        return l_6;
    }
    g_3[1][2] = (safe_sub_func_int8_t_s_s((safe_rshift_func_int16_t_s_s(((func_19(l_22, g_4[4][0]) == g_5[7]) | l_2[0][0][2]), g_5[0])), 0x35L));
    if ((safe_mul_func_uint8_t_u_u((safe_mod_func_int16_t_s_s((safe_lshift_func_int8_t_s_u(((safe_add_func_int32_t_s_s((((-1L) >= g_5[0]) | g_41), l_11)) , l_22), l_56[4][6][1])), l_11)), 0x40L)))
    { /* block id: 29 */
        uint8_t l_59 = 251UL;
        int32_t l_61 = 0x80D17016L;
        int32_t l_62 = 0x8C0B7B9EL;
        int32_t l_66 = 0x48ED3424L;
        int32_t l_70 = 0x4D21BD33L;
        int32_t l_71 = (-1L);
        int32_t l_72 = 0x286A5854L;
        int32_t l_74[9] = {0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L,0x4CA3D7B8L};
        int32_t l_75 = 0xBA8A213CL;
        int i;
        if (g_5[0])
        { /* block id: 30 */
            uint16_t l_60 = 0x7FE1L;
            int32_t l_63 = 0x7D7ACB2EL;
            int32_t l_64 = 0x73DEB0DBL;
            int32_t l_65[2];
            uint64_t l_67 = 0x988D8264474F4469LL;
            int i;
            for (i = 0; i < 2; i++)
                l_65[i] = 0x6EBEA24DL;
            l_61 = (safe_lshift_func_uint16_t_u_s(((7UL & l_59) && l_60), g_4[4][0]));
            l_67++;
        }
        else
        { /* block id: 33 */
            int64_t l_73[6][8] = {{0x69B834A4F5E2A8B9LL,0xC1B54BBB47CE4AD8LL,0xBCF00ED8B3FE5387LL,0x73882F6EF7C0E051LL,0xC1B54BBB47CE4AD8LL,0xC1B54BBB47CE4AD8LL,0x73882F6EF7C0E051LL,0xBCF00ED8B3FE5387LL},{0x69B834A4F5E2A8B9LL,0x69B834A4F5E2A8B9LL,9L,0x73882F6EF7C0E051LL,0x69B834A4F5E2A8B9LL,(-5L),0x73882F6EF7C0E051LL,0x73882F6EF7C0E051LL},{0xC1B54BBB47CE4AD8LL,0x69B834A4F5E2A8B9LL,0xBCF00ED8B3FE5387LL,0xBCF00ED8B3FE5387LL,0x69B834A4F5E2A8B9LL,0xC1B54BBB47CE4AD8LL,0xBCF00ED8B3FE5387LL,0x73882F6EF7C0E051LL},{0x69B834A4F5E2A8B9LL,0xC1B54BBB47CE4AD8LL,0xBCF00ED8B3FE5387LL,0x73882F6EF7C0E051LL,0xC1B54BBB47CE4AD8LL,0xC1B54BBB47CE4AD8LL,0x73882F6EF7C0E051LL,0xBCF00ED8B3FE5387LL},{0x69B834A4F5E2A8B9LL,0x69B834A4F5E2A8B9LL,9L,0x73882F6EF7C0E051LL,0x69B834A4F5E2A8B9LL,(-5L),0x73882F6EF7C0E051LL,0x73882F6EF7C0E051LL},{0xC1B54BBB47CE4AD8LL,0x69B834A4F5E2A8B9LL,0xBCF00ED8B3FE5387LL,0xBCF00ED8B3FE5387LL,0x69B834A4F5E2A8B9LL,0xC1B54BBB47CE4AD8LL,0xBCF00ED8B3FE5387LL,0x73882F6EF7C0E051LL}};
            int32_t l_76 = 8L;
            int32_t l_77 = (-2L);
            int32_t l_78[10] = {0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L,0x7A860806L};
            uint16_t l_79[7];
            int i, j;
            for (i = 0; i < 7; i++)
                l_79[i] = 0x8370L;
            g_5[0] = 1L;
            ++l_79[1];
            l_76 = (func_82(l_6) == 2L);
        }
        return l_75;
    }
    else
    { /* block id: 55 */
        uint16_t l_97 = 0UL;
        int32_t l_98[3];
        int i;
        for (i = 0; i < 3; i++)
            l_98[i] = 0xFAD3D248L;
        l_98[1] = (l_97 < g_3[2][1]);
        for (l_22 = 0; (l_22 <= 3); l_22 += 1)
        { /* block id: 59 */
            return g_5[3];
        }
        return g_5[5];
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_5 g_4 g_41
 * writes: g_41 g_4 g_3
 */
static int32_t  func_19(uint32_t  p_20, uint16_t  p_21)
{ /* block id: 7 */
    int32_t l_35 = 0x0FB9C0D2L;
    int32_t l_46 = 2L;
    int16_t l_47 = 0xD3DAL;
    g_41 &= (safe_mod_func_int32_t_s_s((func_25((safe_lshift_func_uint8_t_u_s((safe_rshift_func_int16_t_s_u((1L && 0L), g_3[0][1])), p_20)), p_21, g_5[5], l_35, p_21) , 3L), 1UL));
    for (g_41 = 3; (g_41 >= 0); g_41 -= 1)
    { /* block id: 17 */
        int64_t l_42[3][9][7] = {{{0x008F4F80CF873A64LL,0x008F4F80CF873A64LL,0x233419813DA773CELL,0x31C0487CC540EDC1LL,(-8L),0x31C0487CC540EDC1LL,0x233419813DA773CELL},{6L,6L,0xE5A9921A3E708952LL,1L,(-1L),1L,0xE5A9921A3E708952LL},{0x008F4F80CF873A64LL,0x008F4F80CF873A64LL,0x233419813DA773CELL,0x31C0487CC540EDC1LL,(-8L),0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL}},{{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L}},{{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL},{(-1L),(-1L),6L,(-1L),1L,(-1L),6L},{(-8L),(-8L),0x008F4F80CF873A64LL,0x8BCD06DB25596398LL,2L,0x8BCD06DB25596398LL,0x008F4F80CF873A64LL}}};
        uint16_t l_45[1][8][6] = {{{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L},{0xA56EL,0x4C00L,0xA56EL,0x4C00L,0xA56EL,0x4C00L}}};
        int i, j, k;
        g_4[0][2] |= p_20;
        for (l_35 = 0; (l_35 <= 3); l_35 += 1)
        { /* block id: 21 */
            int i, j;
            g_4[(g_41 + 1)][l_35] = (((g_3[l_35][(l_35 + 1)] & p_21) || p_21) >= l_42[1][7][0]);
            l_46 ^= (((safe_div_func_int32_t_s_s(g_5[6], g_3[3][3])) || l_35) > l_45[0][0][1]);
        }
    }
    g_3[0][2] &= l_47;
    return g_41;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static int8_t  func_25(int16_t  p_26, uint64_t  p_27, const uint64_t  p_28, uint64_t  p_29, int32_t  p_30)
{ /* block id: 8 */
    uint32_t l_38 = 0xA536CA9AL;
    uint32_t l_39 = 0x416A781BL;
    if (((safe_mul_func_int16_t_s_s(g_4[0][1], l_38)) > l_39))
    { /* block id: 9 */
        return l_39;
    }
    else
    { /* block id: 11 */
        uint32_t l_40[5][3][3] = {{{0x077743AFL,18446744073709551615UL,0x414028B0L},{0xF1140913L,18446744073709551615UL,0xF1140913L},{0x49D2A59AL,0UL,0x414028B0L}},{{0x49D2A59AL,0UL,0x077743AFL},{0xF1140913L,0UL,0x077743AFL},{0x077743AFL,18446744073709551615UL,0x414028B0L}},{{0xF1140913L,18446744073709551615UL,0xF1140913L},{0x49D2A59AL,0UL,0x414028B0L},{0x49D2A59AL,0UL,0x077743AFL}},{{0xF1140913L,0UL,0x077743AFL},{0x077743AFL,18446744073709551615UL,0x414028B0L},{0xF1140913L,18446744073709551615UL,0xF1140913L}},{{0x49D2A59AL,0UL,0x414028B0L},{0x49D2A59AL,0UL,0x077743AFL},{0xF1140913L,0UL,0x077743AFL}}};
        int i, j, k;
        return l_40[0][2][2];
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_3 g_41
 * writes: g_41 g_4 g_3 g_5
 */
static const int16_t  func_82(int32_t  p_83)
{ /* block id: 36 */
    int32_t l_86 = 0L;
    int32_t l_87 = 0xF71B9F5DL;
    int32_t l_90 = 0x304E23EBL;
    int32_t l_91 = 0x6DA70A41L;
    uint16_t l_92 = 0xA199L;
lbl_96:
    l_87 &= func_19((func_19((safe_rshift_func_uint8_t_u_u(func_25(g_5[5], l_86, l_86, l_86, g_5[4]), 0)), g_5[0]) , 0x98744AF5L), g_5[0]);
    for (l_87 = (-17); (l_87 > (-29)); l_87--)
    { /* block id: 40 */
        if (p_83)
            break;
        if ((9L == g_3[1][1]))
        { /* block id: 42 */
            uint64_t l_95 = 18446744073709551615UL;
            l_92--;
            g_5[3] = func_25(l_87, p_83, p_83, l_95, p_83);
        }
        else
        { /* block id: 45 */
            g_5[7] = (0xBBL | g_4[3][0]);
            if (l_87)
                goto lbl_96;
            if (g_41)
                break;
        }
    }
    return p_83;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_4[i][j], "g_4[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_41, "g_41", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 45
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 36
   depth: 2, occurrence: 8
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 57
XXX times a non-volatile is write: 18
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 103
XXX percentage of non-volatile access: 85.2

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 37
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 13
   depth: 2, occurrence: 13

XXX percentage a fresh-made variable is used: 20.2
XXX percentage an existing variable is used: 79.8
********************* end of statistics **********************/

