/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11711801216075085230
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_8 = 8UL;
static int16_t g_13 = (-3L);
static int64_t g_15 = 0x8EB5EA28C7FFFAA2LL;
static int32_t g_19 = 0x5A12A2EFL;
static int32_t g_24 = 0x6A9B03BEL;
static volatile int32_t g_26[4][3] = {{0L,0L,0L},{0xAE86A676L,0xAE86A676L,0xAE86A676L},{0L,0L,0L},{0xAE86A676L,0xAE86A676L,0xAE86A676L}};
static volatile int16_t g_35[10][3] = {{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L},{2L,0L,2L}};
static uint8_t g_71 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(int64_t  p_3, int32_t  p_4, uint32_t  p_5, int32_t  p_6, int16_t  p_7);
static int32_t  func_51(int8_t  p_52, uint32_t  p_53, int32_t  p_54, uint8_t  p_55, const int64_t  p_56);
static int32_t  func_74(int8_t  p_75, uint8_t  p_76, uint8_t  p_77);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_15 g_19 g_71 g_26 g_24
 * writes: g_13 g_8 g_15 g_19 g_26 g_71
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_9[10][4] = {{0UL,0x5DL,0xB9L,0xB9L},{0x5DL,0x5DL,0x85L,0xB9L},{0UL,0x5DL,0xB9L,0xB9L},{0x5DL,0x5DL,0x85L,0xB9L},{0UL,0x5DL,0xB9L,0xB9L},{0x5DL,0x5DL,0x85L,0xB9L},{0UL,0x5DL,0xB9L,0xB9L},{0x5DL,0x5DL,0x85L,0xB9L},{0UL,0x5DL,0xB9L,0xB9L},{0x5DL,0x5DL,0x85L,0xB9L}};
    int32_t l_72 = 0x94CAA1C6L;
    int i, j;
    g_71 ^= func_2(g_8, g_8, l_9[4][2], l_9[4][0], g_8);
    if (g_71)
        goto lbl_73;
    if (g_13)
        goto lbl_73;
lbl_73:
    l_72 &= g_26[1][1];
    l_72 = func_74(((safe_unary_minus_func_uint64_t_u((((safe_rshift_func_uint8_t_u_u(l_9[0][1], 7)) , 0xE41CD949914032C2LL) != 0x0B6AD74ACFC83C04LL))) > 0x5310EE7DL), l_9[4][2], l_9[4][2]);
    for (g_8 = (-21); (g_8 == 50); g_8 = safe_add_func_uint16_t_u_u(g_8, 7))
    { /* block id: 42 */
        int8_t l_86 = 8L;
        l_86 = (1L <= (-6L));
    }
    return l_72;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_15 g_19
 * writes: g_13 g_8 g_15 g_19 g_26
 */
static int32_t  func_2(int64_t  p_3, int32_t  p_4, uint32_t  p_5, int32_t  p_6, int16_t  p_7)
{ /* block id: 1 */
    uint32_t l_10[6][4] = {{1UL,1UL,0x4F545EE2L,1UL},{1UL,18446744073709551609UL,18446744073709551609UL,1UL},{18446744073709551609UL,1UL,18446744073709551609UL,18446744073709551609UL},{1UL,1UL,0x4F545EE2L,1UL},{1UL,18446744073709551609UL,18446744073709551609UL,1UL},{18446744073709551609UL,1UL,18446744073709551609UL,18446744073709551609UL}};
    int32_t l_12 = (-4L);
    int32_t l_20 = 0xF992DB75L;
    int32_t l_21 = (-6L);
    int32_t l_22 = 0x707E294BL;
    int32_t l_23 = 0xE5A82A6FL;
    int32_t l_25 = 0xED1456B8L;
    int32_t l_27 = 0x3B5B0D69L;
    int32_t l_28 = (-1L);
    int32_t l_29 = 0L;
    int32_t l_30 = (-8L);
    int32_t l_31 = 0xB9CEC02DL;
    int32_t l_32 = 0x66B3883FL;
    int32_t l_33[7][6][6] = {{{3L,8L,0x11F31773L,(-1L),1L,8L},{8L,(-1L),(-5L),0L,1L,0x2F88B317L},{1L,8L,(-3L),0x11F31773L,3L,0x0576189EL},{8L,0x13C444C9L,(-1L),0L,8L,0L},{0x0576189EL,1L,(-1L),(-1L),1L,0x0576189EL},{8L,(-1L),(-3L),1L,8L,0x2F88B317L}},{{0L,1L,(-5L),0x11F31773L,0x0576189EL,8L},{0L,0x13C444C9L,0x11F31773L,1L,8L,0L},{8L,8L,0x13C444C9L,(-1L),0L,8L},{0x0576189EL,(-1L),0x2F88B317L,0L,0L,0x2F88B317L},{8L,8L,0L,0x11F31773L,8L,0x0576189EL},{1L,0x13C444C9L,0xC63704BAL,0L,0x0576189EL,0L}},{{8L,1L,0xC63704BAL,(-1L),8L,0x0576189EL},{3L,(-1L),0L,1L,1L,0x2F88B317L},{1L,1L,0x2F88B317L,0x11F31773L,8L,8L},{1L,0x13C444C9L,0x13C444C9L,1L,3L,0L},{3L,8L,0x11F31773L,(-1L),1L,8L},{8L,(-1L),(-5L),0L,1L,0x2F88B317L}},{{1L,8L,(-3L),0x11F31773L,3L,0x0576189EL},{8L,0x13C444C9L,(-1L),0L,8L,0L},{0x0576189EL,1L,(-1L),(-1L),1L,0x0576189EL},{8L,(-1L),(-3L),1L,8L,0x2F88B317L},{0L,1L,(-5L),0x11F31773L,0x0576189EL,8L},{0L,0x13C444C9L,0x11F31773L,1L,8L,0L}},{{8L,8L,0x13C444C9L,(-1L),0L,8L},{0x0576189EL,(-1L),0x2F88B317L,0L,0L,0x2F88B317L},{8L,8L,0L,0x11F31773L,8L,0x0576189EL},{1L,0x13C444C9L,0xC63704BAL,0L,0x0576189EL,0L},{8L,1L,0xC63704BAL,(-1L),8L,0x0576189EL},{3L,(-1L),0L,1L,1L,0x2F88B317L}},{{1L,1L,0x2F88B317L,0x11F31773L,8L,8L},{1L,0x13C444C9L,0x13C444C9L,1L,3L,0L},{3L,8L,0x11F31773L,(-1L),1L,8L},{8L,(-1L),(-5L),0L,1L,0x2F88B317L},{1L,8L,(-3L),0x11F31773L,3L,0x0576189EL},{8L,0x13C444C9L,(-1L),0L,8L,0L}},{{0x0576189EL,1L,(-1L),(-1L),1L,0x0576189EL},{8L,(-1L),(-3L),1L,8L,0x2F88B317L},{0L,1L,(-5L),0x11F31773L,0x0576189EL,8L},{0L,0x13C444C9L,0x11F31773L,1L,8L,0L},{8L,8L,0x13C444C9L,(-1L),0L,8L},{0x0576189EL,(-1L),0x2F88B317L,0L,0L,0x2F88B317L}}};
    int32_t l_34 = (-1L);
    uint64_t l_36 = 0UL;
    int i, j, k;
    for (p_4 = 3; (p_4 >= 0); p_4 -= 1)
    { /* block id: 4 */
        int16_t l_11 = 0x2034L;
        l_12 = (((g_8 != 3L) | g_8) , l_11);
        g_13 = (0x42L >= 0x76L);
        for (g_8 = 0; (g_8 <= 3); g_8 += 1)
        { /* block id: 9 */
            int16_t l_14 = (-1L);
            l_14 = 0x891023F1L;
            g_15 = (l_10[4][3] >= l_14);
        }
    }
    g_19 = (safe_mod_func_int64_t_s_s((~1L), g_8));
    l_36++;
    for (l_31 = 0; (l_31 >= 10); ++l_31)
    { /* block id: 18 */
        int64_t l_47 = 0xB7B7A4FD34EA093ELL;
        int32_t l_70[4];
        int i;
        for (i = 0; i < 4; i++)
            l_70[i] = 0x3B3C44AEL;
        p_4 = ((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s(((l_47 ^ 18446744073709551610UL) == p_7), l_47)), l_20)), l_10[3][0])) || 0x28B7L);
        g_26[0][2] = (safe_add_func_int64_t_s_s((+(func_51(g_13, g_8, l_22, g_13, g_15) & 0xA23B15C0L)), l_29));
        if (l_47)
            break;
        return l_70[1];
    }
    return g_19;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_51(int8_t  p_52, uint32_t  p_53, int32_t  p_54, uint8_t  p_55, const int64_t  p_56)
{ /* block id: 20 */
    uint8_t l_63 = 0xA0L;
    uint16_t l_67[2];
    int i;
    for (i = 0; i < 2; i++)
        l_67[i] = 0x9228L;
    if ((safe_add_func_int64_t_s_s(p_53, 0x8DF11712D94B84B6LL)))
    { /* block id: 21 */
        int16_t l_59 = 0x2349L;
        int32_t l_60 = 0xCC05FD73L;
        int32_t l_61 = 9L;
        int32_t l_62 = 0x0BAF9C35L;
        --l_63;
    }
    else
    { /* block id: 23 */
        int32_t l_66 = 0x4349BA41L;
        --l_67[0];
    }
    return p_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_24 g_26
 * writes: g_26
 */
static int32_t  func_74(int8_t  p_75, uint8_t  p_76, uint8_t  p_77)
{ /* block id: 36 */
    int64_t l_83 = 0xA7570BAEA4427A07LL;
    g_26[2][0] &= ((safe_add_func_int64_t_s_s(((((g_24 | g_24) > l_83) == p_77) != l_83), 0x60F7E9ACA868CE92LL)) || 0xFDA2L);
    return p_77;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_26[i][j], "g_26[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_35[i][j], "g_35[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_71, "g_71", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 38
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 9
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 41
XXX times a non-volatile is write: 17
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 24
XXX percentage of non-volatile access: 95.1

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 10
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 30.9
XXX percentage an existing variable is used: 69.1
********************* end of statistics **********************/

