/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7137399554596613351
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3[5] = {0xB18D4081L,0xB18D4081L,0xB18D4081L,0xB18D4081L,0xB18D4081L};
static const uint64_t g_23 = 18446744073709551606UL;
static int32_t g_25[4] = {(-1L),(-1L),(-1L),(-1L)};


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static uint32_t  func_6(int64_t  p_7, uint8_t  p_8, int64_t  p_9);
static int32_t  func_12(int32_t  p_13, int32_t  p_14, int8_t  p_15, int32_t  p_16, uint8_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_23
 * writes: g_3 g_25
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2 = (-1L);
    int32_t l_24 = 1L;
    g_3[1] &= l_2;
    l_24 = (safe_mul_func_int8_t_s_s(((func_6(g_3[1], l_2, g_3[1]) , 0xA84CL) != g_23), g_23));
    g_25[1] = ((l_2 , g_3[4]) , 0xF35DD758L);
    return g_3[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_3
 */
static uint32_t  func_6(int64_t  p_7, uint8_t  p_8, int64_t  p_9)
{ /* block id: 2 */
    uint16_t l_19 = 0UL;
    int32_t l_22 = (-1L);
    for (p_7 = 27; (p_7 < (-10)); --p_7)
    { /* block id: 5 */
        int64_t l_18 = 0x3923CCDE6BC044B0LL;
        l_22 &= func_12((g_3[3] == 18446744073709551615UL), g_3[1], l_18, l_19, g_3[0]);
    }
    return g_3[1];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_3
 */
static int32_t  func_12(int32_t  p_13, int32_t  p_14, int8_t  p_15, int32_t  p_16, uint8_t  p_17)
{ /* block id: 6 */
    int8_t l_21[3];
    int i;
    for (i = 0; i < 3; i++)
        l_21[i] = 0x0CL;
lbl_20:
    p_13 = ((-1L) ^ p_15);
    for (p_13 = 0; p_13 < 5; p_13 += 1)
    {
        g_3[p_13] = 0x39D98273L;
    }
    if (p_15)
        goto lbl_20;
    return l_21[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_23, "g_23", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 18
XXX times a non-volatile is write: 6
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 11
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 40.9
XXX percentage an existing variable is used: 59.1
********************* end of statistics **********************/

