/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16394057865382941217
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_13[2] = {255UL,255UL};
static uint16_t g_20 = 0UL;
static volatile int32_t g_21 = 0xD72A67F8L;/* VOLATILE GLOBAL g_21 */
static volatile uint32_t g_22 = 0xBE92E3F9L;/* VOLATILE GLOBAL g_22 */
static uint16_t g_28 = 0x383DL;
static int32_t g_29 = 0x254981C5L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int8_t  func_7(uint64_t  p_8, uint32_t  p_9);
static int32_t  func_16(const int64_t  p_17, int16_t  p_18, uint64_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_20 g_22 g_21 g_28
 * writes: g_13 g_20 g_22 g_28 g_29
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_10 = 65526UL;
    uint32_t l_11[2];
    int32_t l_14 = 0x5405732AL;
    int64_t l_15 = 5L;
    int i;
    for (i = 0; i < 2; i++)
        l_11[i] = 1UL;
    l_15 = (safe_rshift_func_int16_t_s_u(((safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_int8_t_s(func_7(l_10, l_11[1]))), 2)) & l_14), 6));
    for (l_15 = 1; (l_15 >= 0); l_15 -= 1)
    { /* block id: 12 */
        int i;
        g_20 ^= func_16(g_13[l_15], g_13[l_15], l_11[1]);
        ++g_22;
        return g_21;
    }
    for (g_20 = 0; (g_20 <= 1); g_20 += 1)
    { /* block id: 21 */
        int8_t l_27 = (-4L);
        int i;
        g_28 &= (safe_div_func_uint32_t_u_u(g_13[g_20], l_27));
        return g_13[g_20];
    }
    g_29 = (0xEDB6L ^ 8UL);
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_13
 */
static int8_t  func_7(uint64_t  p_8, uint32_t  p_9)
{ /* block id: 1 */
    uint16_t l_12[10] = {65532UL,9UL,9UL,65532UL,9UL,9UL,65532UL,9UL,9UL,65532UL};
    int i;
    g_13[1] = l_12[0];
    for (p_8 = 0; (p_8 <= 9); p_8 += 1)
    { /* block id: 5 */
        return p_9;
    }
    return l_12[9];
}


/* ------------------------------------------ */
/* 
 * reads : g_13
 * writes:
 */
static int32_t  func_16(const int64_t  p_17, int16_t  p_18, uint64_t  p_19)
{ /* block id: 13 */
    return g_13[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 5
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 8
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 92.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 6

XXX percentage a fresh-made variable is used: 60
XXX percentage an existing variable is used: 40
********************* end of statistics **********************/

