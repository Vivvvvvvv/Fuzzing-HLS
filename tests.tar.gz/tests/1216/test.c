/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5516305907359132599
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_10 = (-2L);/* VOLATILE GLOBAL g_10 */
static const int32_t g_11 = (-1L);
static uint32_t g_16[5] = {0xC0233FD5L,0xC0233FD5L,0xC0233FD5L,0xC0233FD5L,0xC0233FD5L};
static int16_t g_23 = 0x13E4L;
static int64_t g_25 = 0x0B275CF8B874BDBALL;
static uint32_t g_44 = 0xAFE497D6L;
static uint64_t g_48 = 0xDAE11CD4EE3B919DLL;
static uint32_t g_51[1][8] = {{4294967295UL,4294967291UL,4294967291UL,4294967295UL,4294967291UL,4294967291UL,4294967295UL,4294967291UL}};
static volatile int32_t g_74[10][3] = {{0x54F8DAE6L,0x4EE0C605L,0xDAD05572L},{0x48866363L,0x48866363L,0x92ECD442L},{0x54F8DAE6L,0x4EE0C605L,0xDAD05572L},{0x48866363L,0x48866363L,0x92ECD442L},{0x54F8DAE6L,0x4EE0C605L,0xDAD05572L},{0x48866363L,0x48866363L,0x92ECD442L},{0x54F8DAE6L,0x4EE0C605L,0xDAD05572L},{0x48866363L,0x48866363L,0x92ECD442L},{0x54F8DAE6L,0x4EE0C605L,0xDAD05572L},{0x48866363L,0x48866363L,0x92ECD442L}};
static uint64_t g_80 = 0xE33AB57C19DE87A9LL;
static uint32_t g_83 = 4294967295UL;
static uint32_t g_89 = 18446744073709551615UL;
static volatile uint16_t g_94 = 0x155BL;/* VOLATILE GLOBAL g_94 */
static uint16_t g_123 = 0x02A6L;
static int8_t g_133 = (-1L);
static volatile uint32_t g_134 = 3UL;/* VOLATILE GLOBAL g_134 */
static int32_t g_140[3] = {(-1L),(-1L),(-1L)};
static uint64_t g_141 = 0x5455D931822BFEBDLL;
static int8_t g_153[5] = {1L,1L,1L,1L,1L};
static uint8_t g_156 = 254UL;
static uint8_t g_159 = 0x42L;
static uint64_t g_164 = 8UL;
static uint32_t g_170[8] = {0xC85B538FL,0xC85B538FL,0xC85B538FL,0xC85B538FL,0xC85B538FL,0xC85B538FL,0xC85B538FL,0xC85B538FL};
static uint32_t g_176 = 0x3FB3AA2FL;
static int32_t g_177 = 0x0471CC74L;
static volatile uint8_t g_185 = 0xC4L;/* VOLATILE GLOBAL g_185 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, const int32_t  p_4, uint8_t  p_5, uint32_t  p_6);
static int32_t  func_32(int8_t  p_33);
static int32_t  func_34(int8_t  p_35);
static uint16_t  func_56(uint32_t  p_57, int16_t  p_58, int16_t  p_59, uint32_t  p_60, uint64_t  p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_11 g_16 g_23 g_44 g_51 g_80 g_83 g_89 g_94 g_48 g_25 g_134 g_156 g_123 g_159 g_164 g_133 g_141 g_176 g_153 g_185
 * writes: g_16 g_44 g_23 g_48 g_51 g_80 g_83 g_89 g_94 g_123 g_134 g_140 g_141 g_153 g_156 g_159 g_170 g_176 g_177 g_185
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_9[8] = {0x923607A9L,0x923607A9L,0x923607A9L,0x923607A9L,0x923607A9L,0x923607A9L,0x923607A9L,0x923607A9L};
    int64_t l_12 = 0xF989B1AB4456E348LL;
    int32_t l_184 = 1L;
    int i;
    g_156 |= func_2((((safe_add_func_uint32_t_u_u(((0x034DL > l_9[0]) ^ l_9[0]), l_9[2])) ^ l_9[6]) & g_10), g_11, l_12, l_12);
    g_159 &= ((((((safe_mul_func_uint8_t_u_u(((((l_9[1] < 4UL) == g_10) == l_12) != 65535UL), 1L)) >= l_12) | (-4L)) != 0L) , g_23) >= g_123);
    if ((((((safe_mul_func_int64_t_s_s((((safe_rshift_func_int8_t_s_u((((l_9[1] , g_164) && (-10L)) >= l_9[4]), 1)) , g_89) >= g_25), 0L)) & 4UL) == g_16[2]) ^ g_94) != l_9[0]))
    { /* block id: 81 */
        int32_t l_169 = 0xD3504CD9L;
        if (((safe_mul_func_int8_t_s_s(((safe_add_func_int32_t_s_s((g_94 ^ l_169), g_133)) & 9UL), g_141)) || l_9[0]))
        { /* block id: 82 */
            return l_169;
        }
        else
        { /* block id: 84 */
            uint32_t l_171 = 0xC406D13BL;
            g_170[0] = g_44;
            return l_171;
        }
    }
    else
    { /* block id: 88 */
        int32_t l_174 = (-1L);
        const uint32_t l_183 = 0UL;
        if (((safe_rshift_func_int16_t_s_u((l_9[1] <= 0xADDF9D14L), g_11)) || l_174))
        { /* block id: 89 */
            const int16_t l_175 = 0x725DL;
            g_176 |= l_175;
            g_177 = (((l_175 , l_175) || g_23) , 1L);
            g_177 = (~(safe_div_func_uint16_t_u_u((((safe_mul_func_int8_t_s_s(l_174, l_12)) <= g_153[4]) ^ l_183), 65529UL)));
        }
        else
        { /* block id: 93 */
            --g_185;
            g_177 = (safe_add_func_uint64_t_u_u(0xF78ABD9249688583LL, l_12));
        }
        g_177 = ((safe_rshift_func_uint8_t_u_s((safe_unary_minus_func_uint32_t_u((9UL <= (-10L)))), 0)) , 1L);
    }
    return l_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_10 g_23 g_44 g_51 g_80 g_83 g_89 g_94 g_48 g_11 g_25 g_134
 * writes: g_16 g_44 g_23 g_48 g_51 g_80 g_83 g_89 g_94 g_123 g_134 g_140 g_141 g_153
 */
static int32_t  func_2(uint64_t  p_3, const int32_t  p_4, uint8_t  p_5, uint32_t  p_6)
{ /* block id: 1 */
    int32_t l_13[7][1][2] = {{{0x37C5B151L,0x37C5B151L}},{{8L,0x37C5B151L}},{{0x37C5B151L,8L}},{{0x37C5B151L,0x37C5B151L}},{{8L,0x37C5B151L}},{{0x37C5B151L,8L}},{{0x37C5B151L,0x37C5B151L}}};
    int32_t l_14 = 0L;
    int32_t l_15[8] = {0L,1L,0L,0L,1L,0L,0L,1L};
    int i, j, k;
lbl_152:
    --g_16[4];
    for (p_6 = 0; (p_6 == 47); p_6 = safe_add_func_uint32_t_u_u(p_6, 1))
    { /* block id: 5 */
        uint32_t l_26[3][2];
        int32_t l_31 = 7L;
        uint64_t l_151 = 0xE4BE9B3F527E66CDLL;
        int i, j;
        for (i = 0; i < 3; i++)
        {
            for (j = 0; j < 2; j++)
                l_26[i][j] = 0xE2A90786L;
        }
        for (l_14 = 0; (l_14 != 9); l_14 = safe_add_func_uint16_t_u_u(l_14, 9))
        { /* block id: 8 */
            int32_t l_24 = 0L;
            ++l_26[0][0];
            l_15[1] = ((safe_add_func_int16_t_s_s((g_10 , 5L), l_13[5][0][1])) || g_10);
            l_31 = ((p_4 < (-1L)) , 0x7C4177FDL);
            l_31 &= func_32(l_26[0][0]);
        }
        if (((safe_lshift_func_int16_t_s_u(p_4, g_11)) < p_6))
        { /* block id: 66 */
            uint64_t l_139 = 0x27877F70597A7083LL;
            --g_134;
            g_140[2] = (safe_lshift_func_int16_t_s_u((p_3 < l_139), l_13[5][0][1]));
        }
        else
        { /* block id: 69 */
            int8_t l_150[8];
            int i;
            for (i = 0; i < 8; i++)
                l_150[i] = 0x71L;
            g_141 = 0xAB3A25EAL;
            l_151 &= ((safe_mul_func_int8_t_s_s(((((safe_unary_minus_func_uint32_t_u((safe_mul_func_int8_t_s_s(((+(safe_lshift_func_uint16_t_u_u(65527UL, g_83))) , 0x03L), 0x26L)))) >= 0x2713L) != 0L) >= l_26[0][0]), l_26[2][0])) , l_150[0]);
            if (g_11)
                goto lbl_152;
        }
        if (l_15[6])
            continue;
    }
    g_153[4] = (248UL || g_80);
    l_14 = (safe_sub_func_uint64_t_u_u((7UL & 0UL), 0L));
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_23 g_44 g_51 g_80 g_83 g_89 g_94 g_48 g_11 g_25
 * writes: g_44 g_23 g_48 g_51 g_80 g_83 g_89 g_94 g_123
 */
static int32_t  func_32(int8_t  p_33)
{ /* block id: 12 */
    int32_t l_97 = 0x62ED8E9BL;
    int32_t l_100 = (-2L);
    int32_t l_104[6][5] = {{0xFA15260EL,1L,1L,(-9L),0x4639A721L},{0x48DF9F9BL,0x23B9C033L,0x23B9C033L,0x48DF9F9BL,(-9L)},{0xFA15260EL,0xCB56AE7BL,0x2353B378L,0xC623687EL,(-9L)},{0x23B9C033L,0xFA15260EL,0x4639A721L,0x15289768L,0x4639A721L},{0x15289768L,0x15289768L,(-9L),0xC623687EL,0x2353B378L},{0x8094BF1CL,0x2FB047B2L,(-9L),0x48DF9F9BL,0x23B9C033L}};
    int32_t l_119 = 0x60329EC2L;
    int64_t l_120 = 0x7668EA8FD6C63221LL;
    uint32_t l_121 = 0xBEB5A7EBL;
    int8_t l_122 = 0x29L;
    uint16_t l_125 = 65535UL;
    int32_t l_126 = (-1L);
    int32_t l_127 = 1L;
    int i, j;
    l_97 = func_34((safe_mul_func_int8_t_s_s((safe_div_func_uint32_t_u_u(0UL, g_16[3])), g_23)));
    if (g_44)
        goto lbl_101;
    if ((((((safe_div_func_uint64_t_u_u(g_48, l_97)) == l_100) < g_51[0][0]) != g_16[2]) , 0x49941B8EL))
    { /* block id: 43 */
lbl_101:
        l_100 = l_100;
        if (((p_33 & 2L) != l_97))
        { /* block id: 46 */
            l_97 ^= (safe_rshift_func_uint8_t_u_s(l_104[4][3], 4));
            l_97 = (safe_mul_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s((safe_sub_func_int16_t_s_s((((((safe_add_func_int16_t_s_s((safe_div_func_int64_t_s_s((safe_lshift_func_int8_t_s_s(((((safe_lshift_func_int16_t_s_u((((g_11 ^ g_51[0][0]) | l_97) <= g_25), l_119)) || l_120) | l_97) , l_121), 6)), g_23)), g_25)) == l_122) != p_33) ^ 0xD7L) != g_80), g_25)), 7)), 0UL));
        }
        else
        { /* block id: 49 */
            g_123 = g_16[4];
            l_100 = (((((-1L) < 0L) || 0x04F9F07892551584LL) , p_33) >= 18446744073709551615UL);
            l_126 &= (+l_125);
        }
        l_100 = ((l_127 >= g_94) == l_119);
    }
    else
    { /* block id: 55 */
        int8_t l_130 = 0x84L;
        for (g_44 = (-19); (g_44 < 25); g_44 = safe_add_func_uint16_t_u_u(g_44, 9))
        { /* block id: 58 */
            return l_130;
        }
        return p_33;
    }
    return g_94;
}


/* ------------------------------------------ */
/* 
 * reads : g_44 g_23 g_16 g_51 g_80 g_83 g_89 g_94
 * writes: g_44 g_23 g_48 g_51 g_80 g_83 g_89 g_94
 */
static int32_t  func_34(int8_t  p_35)
{ /* block id: 13 */
    uint32_t l_43 = 0xDBB389E7L;
    int32_t l_91 = (-6L);
    int32_t l_93 = 1L;
    g_44 |= (safe_add_func_uint32_t_u_u((!(p_35 >= p_35)), l_43));
    for (g_23 = 8; (g_23 == (-15)); g_23--)
    { /* block id: 17 */
        int32_t l_47 = 1L;
        int32_t l_52 = (-4L);
        int32_t l_90[10] = {0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL,0x8387B67AL};
        int i;
        g_48 = (l_47 | g_23);
        if (l_43)
        { /* block id: 19 */
            int32_t l_53 = 1L;
            g_51[0][0] = (safe_mod_func_uint64_t_u_u(0x9E0D94485E09B704LL, 5UL));
            if (l_52)
                break;
            if (l_53)
                break;
            return g_16[4];
        }
        else
        { /* block id: 24 */
            uint64_t l_86 = 18446744073709551615UL;
            int32_t l_92 = 0x03F87D51L;
            l_86 = ((safe_div_func_uint16_t_u_u(func_56(g_51[0][1], p_35, p_35, g_51[0][0], l_47), p_35)) <= l_43);
            g_89 ^= (((safe_mul_func_int64_t_s_s(l_43, 0UL)) >= 3UL) || l_52);
            g_94--;
            l_93 = ((((p_35 || l_43) , 0x6B2EL) || 65535UL) , 0x121825F2L);
        }
    }
    return l_91;
}


/* ------------------------------------------ */
/* 
 * reads : g_51 g_80 g_83
 * writes: g_80 g_83
 */
static uint16_t  func_56(uint32_t  p_57, int16_t  p_58, int16_t  p_59, uint32_t  p_60, uint64_t  p_61)
{ /* block id: 25 */
    const int64_t l_65 = (-1L);
    int32_t l_66 = 0x64A9B53AL;
    int32_t l_67 = 4L;
    int32_t l_70 = 0xA56B7408L;
    int32_t l_71 = (-10L);
    int32_t l_72 = 1L;
    int32_t l_73 = 1L;
    int32_t l_75 = (-4L);
    int32_t l_76 = 0x7FB053AAL;
    int32_t l_77 = 0xB67C402FL;
    for (p_59 = 22; (p_59 < (-19)); p_59--)
    { /* block id: 28 */
        int32_t l_64 = 1L;
        int32_t l_68 = (-3L);
        int32_t l_69 = 1L;
        int32_t l_78 = (-5L);
        int32_t l_79 = (-1L);
        l_64 &= g_51[0][0];
        l_66 = (((l_64 != l_64) && l_64) , l_65);
        g_80--;
    }
    g_83++;
    return l_75;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_16[i], "g_16[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_51[i][j], "g_51[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_74[i][j], "g_74[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_123, "g_123", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_140[i], "g_140[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_141, "g_141", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_153[i], "g_153[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_156, "g_156", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_170[i], "g_170[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_176, "g_176", print_hash_value);
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_185, "g_185", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 78
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 69
   depth: 2, occurrence: 11
   depth: 3, occurrence: 7
   depth: 4, occurrence: 7
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 119
XXX times a non-volatile is write: 41
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 64
XXX percentage of non-volatile access: 93.6

XXX forward jumps: 1
XXX backward jumps: 1

XXX stmts: 66
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 16
   depth: 2, occurrence: 31

XXX percentage a fresh-made variable is used: 40.2
XXX percentage an existing variable is used: 59.8
********************* end of statistics **********************/

