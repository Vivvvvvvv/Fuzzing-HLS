/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3520350843451642922
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3[1] = {0x2BA39464L};
static uint16_t g_52 = 65529UL;
static volatile uint8_t g_73 = 0x76L;/* VOLATILE GLOBAL g_73 */


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint8_t  func_9(uint32_t  p_10, int64_t  p_11, uint64_t  p_12);
static uint16_t  func_19(int64_t  p_20, int64_t  p_21);
static int32_t  func_22(uint32_t  p_23, int8_t  p_24);
static int16_t  func_45(uint64_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_52 g_73
 * writes: g_3 g_73 g_52
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2[2];
    const uint32_t l_95 = 0xD6886700L;
    int32_t l_101[3][4][3] = {{{0x7F9B13E4L,0L,0L},{0x380C2164L,(-1L),0x0F39A984L},{0x380C2164L,0x0F39A984L,0x80B9C827L},{0x7F9B13E4L,0xE6A661FAL,0xC4D3C6A4L}},{{0x80B9C827L,(-1L),0x4A0BDBF6L},{(-1L),0xE6A661FAL,1L},{0x0A5A07D0L,0x0F39A984L,0x0A5A07D0L},{0xE6A661FAL,(-1L),0x0A5A07D0L}},{{0x61C9B082L,0L,1L},{1L,0x0A5A07D0L,0x4A0BDBF6L},{(-1L),0x8FD6DDE4L,0xC4D3C6A4L},{1L,0x285FCF45L,0x80B9C827L}}};
    uint32_t l_123 = 4UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2[i] = 1UL;
lbl_105:
    for (g_3[0] = 1; (g_3[0] >= 0); g_3[0] -= 1)
    { /* block id: 3 */
        int i;
        return l_2[g_3[0]];
    }
    if (((safe_lshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_s(g_3[0], g_3[0])), l_2[0])) > g_3[0]))
    { /* block id: 6 */
        const uint64_t l_8 = 1UL;
        int32_t l_92 = 0xC98C3E2EL;
        g_3[0] |= l_8;
        l_92 = ((((func_9(((safe_sub_func_uint32_t_u_u((safe_rshift_func_int8_t_s_s((safe_mul_func_int8_t_s_s(((func_19(g_3[0], g_3[0]) , 0L) && 0x1B3FE78DL), l_8)), 4)), 0xFF9B0371L)) , l_2[1]), l_8, g_52) | 7UL) >= 0x2EBAL) , l_8) != g_52);
        g_3[0] |= ((safe_lshift_func_uint8_t_u_s((((l_95 || l_95) & l_8) , l_8), l_2[0])) | l_95);
    }
    else
    { /* block id: 53 */
        uint32_t l_102[4][4][5] = {{{18446744073709551606UL,18446744073709551606UL,18446744073709551615UL,1UL,0UL},{18446744073709551606UL,9UL,0UL,0x0B4B7F8BL,1UL},{6UL,0x80FC2DDDL,0x0B4B7F8BL,18446744073709551608UL,18446744073709551606UL},{0UL,0xE035C9A6L,0xE035C9A6L,0UL,18446744073709551615UL}},{{9UL,0xC85B7FF5L,0xE035C9A6L,0x390B54F4L,0UL},{0x390B54F4L,0xCE5CF1A0L,0x0B4B7F8BL,6UL,0xE035C9A6L},{0x80FC2DDDL,9UL,0x390B54F4L,0x390B54F4L,9UL},{1UL,1UL,0xE5F053F6L,0UL,9UL}},{{0xCE5CF1A0L,18446744073709551606UL,0xC85B7FF5L,18446744073709551608UL,0xE035C9A6L},{1UL,18446744073709551608UL,0UL,0UL,0UL},{0xCE5CF1A0L,0xE5F053F6L,0xCE5CF1A0L,0UL,18446744073709551615UL},{1UL,0xE5F053F6L,6UL,1UL,18446744073709551606UL}},{{0x80FC2DDDL,18446744073709551608UL,0UL,0xC85B7FF5L,1UL},{0x390B54F4L,18446744073709551606UL,6UL,18446744073709551606UL,0x390B54F4L},{9UL,1UL,0xCE5CF1A0L,18446744073709551606UL,0xC85B7FF5L},{0UL,9UL,0UL,0xC85B7FF5L,0x0B4B7F8BL}}};
        int32_t l_121 = 0x1995C1D1L;
        int32_t l_122[8][10] = {{(-7L),0xAA69B510L,(-7L),0L,0x2C6A0115L,0L,(-7L),0xAA69B510L,(-7L),0L},{0x2C6A0115L,0xAA69B510L,0x0B60EEEBL,0xAA69B510L,0x2C6A0115L,0xDC6EB251L,0x2C6A0115L,0xAA69B510L,0x0B60EEEBL,0xAA69B510L},{0x2C6A0115L,0L,(-7L),0xAA69B510L,(-7L),0L,0x2C6A0115L,0L,(-7L),0xAA69B510L},{(-7L),0xAA69B510L,(-7L),0L,0x2C6A0115L,0L,(-7L),0xAA69B510L,(-7L),0L},{0x2C6A0115L,0xAA69B510L,0x0B60EEEBL,0xAA69B510L,0x2C6A0115L,0xDC6EB251L,0x2C6A0115L,0xAA69B510L,0x0B60EEEBL,0xAA69B510L},{0x2C6A0115L,0L,(-7L),0xAA69B510L,(-7L),0L,0x2C6A0115L,0L,(-7L),0xAA69B510L},{(-7L),0xAA69B510L,(-7L),0L,0x2C6A0115L,0L,(-7L),0xAA69B510L,(-7L),0L},{0x2C6A0115L,0xAA69B510L,0x0B60EEEBL,0xAA69B510L,0x2C6A0115L,0xDC6EB251L,0x2C6A0115L,0xAA69B510L,0x0B60EEEBL,0xAA69B510L}};
        int i, j, k;
        for (g_52 = 0; (g_52 < 49); g_52 = safe_add_func_int8_t_s_s(g_52, 4))
        { /* block id: 56 */
            int32_t l_98 = (-10L);
            l_98 ^= g_73;
            l_101[2][2][2] &= (((safe_div_func_int32_t_s_s(3L, 4294967291UL)) != 0x72L) , g_73);
            l_102[3][0][2]--;
            if (l_95)
                goto lbl_105;
        }
        for (g_52 = 0; (g_52 != 32); g_52 = safe_add_func_int16_t_s_s(g_52, 8))
        { /* block id: 64 */
            uint32_t l_108 = 0xECA65C32L;
            if (l_102[3][0][2])
                break;
            if (g_73)
                break;
            if (l_101[0][0][1])
                break;
            l_108++;
        }
        l_101[2][2][2] = (((safe_sub_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((((safe_rshift_func_int16_t_s_u(((safe_div_func_uint8_t_u_u((g_3[0] < g_3[0]), 0x22L)) | g_52), g_3[0])) >= g_3[0]) >= g_3[0]), g_73)), l_2[0])), 65533UL)) != g_3[0]) , l_95);
        ++l_123;
    }
    return l_101[1][3][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_3 g_73
 * writes: g_73 g_3
 */
static uint8_t  func_9(uint32_t  p_10, int64_t  p_11, uint64_t  p_12)
{ /* block id: 28 */
    int32_t l_53 = 0x79B6842AL;
    int32_t l_67 = 0x7CBC1764L;
    int32_t l_72 = (-9L);
    l_53 = (-4L);
    if (((((((((g_52 || l_53) ^ g_52) , g_3[0]) & 1UL) , p_12) <= (-5L)) , 9L) == 65535UL))
    { /* block id: 30 */
        int32_t l_66 = 1L;
        l_66 = (safe_sub_func_int16_t_s_s(((((safe_sub_func_int16_t_s_s((((safe_sub_func_uint32_t_u_u((safe_add_func_int32_t_s_s((((safe_mod_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u((0x45D1882859701027LL <= 0x94210AB9CA2468F5LL), 7)), 253UL)) , p_11) || 1L), g_52)), (-3L))) || l_66) , 0x6626L), g_52)) || 65527UL) | 4294967295UL) | l_53), l_67));
        if (((safe_div_func_uint32_t_u_u((l_53 , l_66), g_3[0])) <= 0xB9BE056EFF5237AELL))
        { /* block id: 32 */
            int8_t l_70 = (-1L);
            int32_t l_71[3][6][2] = {{{0L,7L},{7L,0L},{7L,0L},{7L,0L},{7L,7L},{0L,7L}},{{0L,7L},{0L,7L},{7L,0L},{7L,0L},{7L,0L},{7L,7L}},{{0L,7L},{0L,7L},{0L,7L},{7L,0L},{7L,0L},{7L,0L}}};
            int i, j, k;
            --g_73;
            g_3[0] = ((((((safe_mod_func_int8_t_s_s((l_66 != 0UL), p_12)) , (-1L)) >= p_12) , p_11) | g_3[0]) < 0xC0BDL);
        }
        else
        { /* block id: 35 */
            uint32_t l_78 = 0xFBB161CAL;
            g_3[0] = (p_12 == (-1L));
            g_3[0] = l_78;
        }
    }
    else
    { /* block id: 39 */
        int32_t l_79[1][1][10] = {{{0xA1A718AFL,0x90C290A7L,0x90C290A7L,0xA1A718AFL,0xC3C0C886L,0xC3C0C886L,0x90C290A7L,0xC3C0C886L,0xC3C0C886L,0x90C290A7L}}};
        const int16_t l_83 = 0x5E7EL;
        int i, j, k;
        g_3[0] = (0x9706L <= l_79[0][0][7]);
        if (((0x88L != 0x24L) != l_72))
        { /* block id: 41 */
            uint64_t l_80 = 0x1537C3E802F2280FLL;
            l_80 |= (g_73 & p_12);
            g_3[0] = (0x35237E92L ^ l_72);
            l_79[0][0][7] = (0x339FE21AC514D69ELL == p_12);
        }
        else
        { /* block id: 45 */
            g_3[0] = (safe_mul_func_int16_t_s_s((((g_3[0] > 4294967295UL) && l_53) ^ l_83), g_3[0]));
        }
    }
    l_67 = (safe_div_func_int64_t_s_s(((((((safe_mod_func_int16_t_s_s(((((((safe_add_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(l_67, 5)), p_12)) & 0UL) >= g_52) <= l_53) < l_67) != p_12), 0x2F25L)) != l_53) | g_52) , l_72) | l_53) && 0x40FFFF0E5992B028LL), g_3[0]));
    return l_53;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_3
 */
static uint16_t  func_19(int64_t  p_20, int64_t  p_21)
{ /* block id: 8 */
    uint32_t l_50[8] = {5UL,2UL,5UL,2UL,5UL,2UL,5UL,2UL};
    int32_t l_51[2][8][4] = {{{(-8L),(-1L),(-1L),(-8L)},{0x2EEDA7DAL,0x212AEAFDL,(-1L),0xB3002E9DL},{(-8L),(-1L),0L,(-1L)},{(-1L),(-1L),0x2EEDA7DAL,(-1L)},{0x2EEDA7DAL,(-1L),0xB3002E9DL,0xB3002E9DL},{0x212AEAFDL,0x212AEAFDL,0L,(-8L)},{0x212AEAFDL,(-1L),0xB3002E9DL,0x212AEAFDL},{0x2EEDA7DAL,(-8L),0x2EEDA7DAL,0xB3002E9DL}},{{(-1L),(-8L),0L,0x212AEAFDL},{(-8L),(-1L),(-1L),(-8L)},{0x2EEDA7DAL,0x212AEAFDL,(-1L),0xB3002E9DL},{(-8L),(-1L),0L,(-1L)},{(-1L),(-1L),0x2EEDA7DAL,(-1L)},{0x2EEDA7DAL,(-1L),0xB3002E9DL,0xB3002E9DL},{0x212AEAFDL,0x212AEAFDL,0L,(-8L)},{0x212AEAFDL,(-1L),0xB3002E9DL,0x212AEAFDL}}};
    int i, j, k;
    g_3[0] = g_3[0];
    l_50[0] = func_22(g_3[0], g_3[0]);
    l_51[0][2][3] = p_21;
    return l_50[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int32_t  func_22(uint32_t  p_23, int8_t  p_24)
{ /* block id: 10 */
    uint16_t l_29 = 65531UL;
    int32_t l_30 = 0x7656540FL;
    int32_t l_49 = 0xA5B4D633L;
    l_30 = ((((+((((!(safe_add_func_int16_t_s_s((g_3[0] , 0x6095L), l_29))) > p_24) | p_24) & g_3[0])) < (-7L)) > l_29) ^ g_3[0]);
    if ((safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s(l_29, 0x42L)), 0x03L)))
    { /* block id: 12 */
        uint8_t l_40 = 0x4AL;
        for (l_29 = 0; (l_29 >= 45); ++l_29)
        { /* block id: 15 */
            l_40 = (safe_add_func_int16_t_s_s((+((l_29 < p_23) , p_23)), 1L));
            l_49 = (((safe_mod_func_int32_t_s_s((!(!func_45((safe_sub_func_int64_t_s_s(l_40, p_23))))), (-1L))) != g_3[0]) , p_23);
        }
    }
    else
    { /* block id: 21 */
        return l_30;
    }
    return g_3[0];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int16_t  func_45(uint64_t  p_46)
{ /* block id: 17 */
    return p_46;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 28
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 48
   depth: 2, occurrence: 9
   depth: 3, occurrence: 3
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 12, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 101
XXX times a non-volatile is write: 30
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 36
XXX percentage of non-volatile access: 95.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 47
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 14
   depth: 2, occurrence: 18

XXX percentage a fresh-made variable is used: 17.9
XXX percentage an existing variable is used: 82.1
********************* end of statistics **********************/

