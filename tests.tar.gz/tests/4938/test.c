/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14735935553322902541
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int8_t  f0;
   int64_t  f1;
   int32_t  f2;
   volatile uint64_t  f3;
   volatile int32_t  f4;
   int32_t  f5;
   uint64_t  f6;
   uint16_t  f7;
   int64_t  f8;
   int16_t  f9;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_6 = 0UL;
static int32_t g_20 = (-1L);
static uint32_t g_34[10] = {0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L,0x7F5E1753L};
static int32_t g_37 = 1L;
static struct S0 g_38[9] = {{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L},{-1L,-2L,0x4C923F2BL,0x367AFFF16CE65C5BLL,0L,0x785B8EEBL,0x03A67D625C2A3DA7LL,0x815CL,-4L,0x7710L}};


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static int32_t  func_2(uint64_t  p_3, uint64_t  p_4, int16_t  p_5);
static int8_t  func_10(int16_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_20 g_34 g_38
 * writes: g_20 g_6 g_34 g_37
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    uint32_t l_7 = 18446744073709551609UL;
    g_34[6] &= func_2(g_6, l_7, g_6);
    for (g_20 = 0; (g_20 <= 9); g_20 += 1)
    { /* block id: 22 */
        int i;
        g_37 = ((safe_mod_func_uint32_t_u_u((g_34[g_20] & g_34[g_20]), 0xB2D4AD44L)) | 0xC5A258D3L);
    }
    return g_38[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_20
 * writes: g_20 g_6
 */
static int32_t  func_2(uint64_t  p_3, uint64_t  p_4, int16_t  p_5)
{ /* block id: 1 */
    int16_t l_33 = 0xB437L;
    l_33 ^= (safe_mul_func_int8_t_s_s(func_10(g_6), 0x8EL));
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_20
 * writes: g_20 g_6
 */
static int8_t  func_10(int16_t  p_11)
{ /* block id: 2 */
    int8_t l_25 = 0x28L;
    int32_t l_32 = 0L;
    if ((safe_mul_func_uint16_t_u_u(p_11, 65535UL)))
    { /* block id: 3 */
        uint32_t l_21 = 0UL;
        g_20 = (safe_div_func_int64_t_s_s(((safe_add_func_int64_t_s_s((((safe_lshift_func_uint16_t_u_s(((p_11 && 0x7D26L) || 18446744073709551615UL), 3)) || g_6) < p_11), 0L)) < 4L), p_11));
        return l_21;
    }
    else
    { /* block id: 6 */
        for (g_6 = (-26); (g_6 >= 52); ++g_6)
        { /* block id: 9 */
            int32_t l_24 = 0x514FAF14L;
            l_24 = g_6;
            l_25 &= (((g_6 == 0x1EFEL) >= g_6) != 0L);
            l_32 = (safe_mul_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u((253UL >= g_6), g_20)) >= 0x30B56BF5EE879096LL), g_6)), p_11));
            return p_11;
        }
        return p_11;
    }
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_37, "g_37", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_38[i].f0, "g_38[i].f0", print_hash_value);
        transparent_crc(g_38[i].f1, "g_38[i].f1", print_hash_value);
        transparent_crc(g_38[i].f2, "g_38[i].f2", print_hash_value);
        transparent_crc(g_38[i].f3, "g_38[i].f3", print_hash_value);
        transparent_crc(g_38[i].f4, "g_38[i].f4", print_hash_value);
        transparent_crc(g_38[i].f5, "g_38[i].f5", print_hash_value);
        transparent_crc(g_38[i].f6, "g_38[i].f6", print_hash_value);
        transparent_crc(g_38[i].f7, "g_38[i].f7", print_hash_value);
        transparent_crc(g_38[i].f8, "g_38[i].f8", print_hash_value);
        transparent_crc(g_38[i].f9, "g_38[i].f9", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 5
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 37.9
XXX percentage an existing variable is used: 62.1
********************* end of statistics **********************/

