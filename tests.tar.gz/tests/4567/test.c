/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4327416476336160015
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 9L;
static int16_t g_4 = (-1L);
static uint16_t g_16[9] = {65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL,65535UL};
static int32_t g_22[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_5(uint32_t  p_6, uint32_t  p_7, uint8_t  p_8);
static uint32_t  func_9(uint32_t  p_10, int32_t  p_11, int64_t  p_12, uint32_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_22
 * writes: g_4 g_16 g_22
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_3 = 65535UL;
    uint64_t l_18 = 0UL;
    uint16_t l_19 = 0UL;
    g_4 = (g_2 >= l_3);
    g_22[6] = func_5(func_9((safe_add_func_uint8_t_u_u((((l_3 , 0x37L) < g_2) , l_3), g_4)), g_4, g_2, g_2), l_18, l_19);
    return g_22[6];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_5(uint32_t  p_6, uint32_t  p_7, uint8_t  p_8)
{ /* block id: 5 */
    uint32_t l_20 = 4294967292UL;
    int32_t l_21 = (-1L);
    l_21 = (l_20 || 0xFDD8FB8CEFFB91E6LL);
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_16
 */
static uint32_t  func_9(uint32_t  p_10, int32_t  p_11, int64_t  p_12, uint32_t  p_13)
{ /* block id: 2 */
    int32_t l_17[3];
    int i;
    for (i = 0; i < 3; i++)
        l_17[i] = 0x95ED7C6AL;
    for (p_12 = 0; p_12 < 9; p_12 += 1)
    {
        g_16[p_12] = 0x6524L;
    }
    return l_17[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_16[i], "g_16[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 7
   depth: 2, occurrence: 2
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 15
XXX times a non-volatile is write: 3
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 7

XXX percentage a fresh-made variable is used: 50
XXX percentage an existing variable is used: 50
********************* end of statistics **********************/

