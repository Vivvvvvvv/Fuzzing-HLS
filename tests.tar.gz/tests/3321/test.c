/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17741430269464747611
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int64_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = (-1L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = (-4L);
static int32_t g_7 = 0x88ADAE8CL;
static volatile int32_t g_24[3] = {0x51C6076FL,0x51C6076FL,0x51C6076FL};
static int16_t g_30 = 0x6CD5L;
static volatile struct S0 g_36 = {0x470D16AAEF404622LL};/* VOLATILE GLOBAL g_36 */
static volatile struct S0 g_37 = {0xCA20838156AC6DEALL};/* VOLATILE GLOBAL g_37 */
static uint8_t g_40 = 0x19L;
static int64_t g_52[2] = {0x1E9D644770C58F83LL,0x1E9D644770C58F83LL};


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int32_t  func_10(uint32_t  p_11, const uint8_t  p_12, int16_t  p_13, uint32_t  p_14);
static int16_t  func_20(uint64_t  p_21);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_7 g_2 g_36 g_40 g_52 g_24
 * writes: g_4 g_7 g_37 g_52 g_24
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_38 = 0xA5L;
    int32_t l_58 = 0x54A5A862L;
    int32_t l_59[4] = {0x45122417L,0x45122417L,0x45122417L,0x45122417L};
    int i;
    for (g_4 = 0; (g_4 > 5); g_4 = safe_add_func_uint16_t_u_u(g_4, 3))
    { /* block id: 3 */
        const int16_t l_39[8] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
        int32_t l_45 = 3L;
        int i;
        for (g_7 = 0; (g_7 != (-7)); g_7--)
        { /* block id: 6 */
            int16_t l_22 = 0x51D5L;
            uint32_t l_51 = 0UL;
            l_45 = func_10(((safe_mul_func_uint8_t_u_u((+(safe_div_func_int16_t_s_s(func_20(l_22), l_22))), l_38)) || g_4), l_39[5], l_38, g_40);
            if (l_39[7])
                continue;
            l_45 ^= ((safe_sub_func_int8_t_s_s((((safe_unary_minus_func_int16_t_s((safe_add_func_int64_t_s_s((g_36.f0 , 0x1AD519FD4AADDA39LL), 0xAEBACB588F49E03BLL)))) >= g_7) | l_22), l_51)) | 0x59A1FF380447D5CELL);
            g_52[0] |= (g_2 & l_51);
        }
        g_24[1] = (l_45 ^ l_38);
        if (g_24[2])
            continue;
        l_45 = (safe_rshift_func_uint16_t_u_u(l_45, 3));
    }
    if (((safe_mul_func_uint8_t_u_u((0UL ^ l_38), l_38)) ^ 0xBCDBL))
    { /* block id: 26 */
        uint32_t l_57 = 1UL;
        l_58 &= l_57;
        l_59[2] = l_38;
    }
    else
    { /* block id: 29 */
        l_59[2] = g_52[0];
    }
    return l_59[2];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_10(uint32_t  p_11, const uint8_t  p_12, int16_t  p_13, uint32_t  p_14)
{ /* block id: 12 */
    uint16_t l_41 = 0UL;
    int32_t l_44 = 0x571EBB70L;
    l_41 = 0x78C37F2EL;
    l_44 = (((safe_div_func_uint32_t_u_u(0xDF3C4FB3L, 4294967295UL)) != l_41) >= p_14);
    l_44 |= 0xA75048CBL;
    return l_41;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_36
 * writes: g_37
 */
static int16_t  func_20(uint64_t  p_21)
{ /* block id: 7 */
    volatile uint32_t l_23[2];
    int32_t l_25 = 0x5062D7BCL;
    int32_t l_26 = 0L;
    int32_t l_27 = (-9L);
    int32_t l_28 = 3L;
    int32_t l_29[3];
    int16_t l_31[4] = {0x12D2L,0x12D2L,0x12D2L,0x12D2L};
    int16_t l_32 = 0x2755L;
    uint32_t l_33 = 4294967295UL;
    int i;
    for (i = 0; i < 2; i++)
        l_23[i] = 4294967295UL;
    for (i = 0; i < 3; i++)
        l_29[i] = 0xF3B8C105L;
    l_23[1] = g_2;
    l_33--;
    g_37 = g_36;
    return l_23[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_24[i], "g_24[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_36.f0, "g_36.f0", print_hash_value);
    transparent_crc(g_37.f0, "g_37.f0", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_52[i], "g_52[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 23
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 27
   depth: 2, occurrence: 5
   depth: 4, occurrence: 2
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 13
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 206
XXX percentage of non-volatile access: 81.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 22
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 7
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 10.4
XXX percentage an existing variable is used: 89.6
********************* end of statistics **********************/

