/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12498155577701200254
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_8 = 0x9EA98311L;
static int8_t g_10 = 0x66L;
static volatile uint32_t g_32 = 0x60A2FC53L;/* VOLATILE GLOBAL g_32 */
static uint64_t g_35 = 0x3046AA1DD5C0AECALL;
static uint16_t g_36 = 65527UL;
static uint32_t g_46[3] = {1UL,1UL,1UL};
static int64_t g_56 = 0xA3C8FCBD0D794A3CLL;
static int8_t g_61 = 0xB7L;
static uint8_t g_64 = 0UL;
static volatile uint16_t g_69 = 0xCC60L;/* VOLATILE GLOBAL g_69 */
static volatile uint8_t g_72 = 3UL;/* VOLATILE GLOBAL g_72 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int16_t  func_17(uint16_t  p_18, uint64_t  p_19);
static uint16_t  func_29(int64_t  p_30, const int64_t  p_31);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_10 g_32 g_35 g_36 g_46 g_56 g_61 g_69
 * writes: g_10 g_8 g_32 g_35 g_36 g_46 g_56 g_61 g_64 g_69 g_72
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_9 = 0xD3L;
    int32_t l_14 = 1L;
    uint64_t l_55 = 0x28DFE901672C6516LL;
    if ((safe_mul_func_int16_t_s_s((safe_sub_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((g_8 < 1L), l_9)), l_9)), g_8)))
    { /* block id: 1 */
        int64_t l_13 = (-1L);
        g_10 = (g_8 > g_8);
        l_14 ^= ((((((safe_rshift_func_uint16_t_u_s(g_10, l_13)) != l_13) > 0x8BC07C2076ACB8F2LL) < g_8) | l_9) > g_8);
        g_46[0] = (safe_lshift_func_int16_t_s_u(func_17((g_8 , l_14), l_9), 1));
    }
    else
    { /* block id: 32 */
        uint32_t l_51 = 0UL;
        int32_t l_68 = 0x2C9D536CL;
        if ((safe_mod_func_uint64_t_u_u((((safe_mod_func_uint8_t_u_u(l_51, g_36)) | l_14) || 4294967286UL), g_8)))
        { /* block id: 33 */
            uint64_t l_52 = 0x571BE33BD0D8167ELL;
            l_14 = (l_14 , l_51);
            l_52 = (g_10 , g_35);
            g_56 = (((safe_rshift_func_int16_t_s_s(l_51, 7)) < l_55) <= 0xEC28L);
        }
        else
        { /* block id: 37 */
            uint32_t l_65 = 0x9AD3EE77L;
            g_61 |= (safe_div_func_int16_t_s_s((safe_lshift_func_int16_t_s_u((g_36 && g_46[2]), 8)), g_56));
            g_64 = (safe_mul_func_uint8_t_u_u((g_8 , 3UL), 0xCEL));
            ++l_65;
        }
        --g_69;
    }
    g_72 = g_69;
    l_14 = ((!((g_32 <= 1L) || 0xA08C8198303F43C5LL)) || g_61);
    l_14 = (safe_mod_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((safe_div_func_uint16_t_u_u(((g_61 > 0x70L) , 0UL), 0x76C5L)) && g_32), 0)), 1L));
    return l_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_10 g_32 g_35
 * writes: g_8 g_32 g_35 g_36
 */
static int16_t  func_17(uint16_t  p_18, uint64_t  p_19)
{ /* block id: 4 */
    int8_t l_40 = 0x2CL;
    uint32_t l_42 = 0UL;
    int32_t l_45 = (-1L);
    for (p_19 = (-29); (p_19 != 46); p_19 = safe_add_func_int16_t_s_s(p_19, 5))
    { /* block id: 7 */
        for (g_8 = (-19); (g_8 >= 4); g_8++)
        { /* block id: 10 */
            int64_t l_26 = (-6L);
            int32_t l_37 = 1L;
            if (p_18)
                break;
            l_26 &= ((((safe_mod_func_int32_t_s_s((g_8 , g_10), p_18)) != p_18) <= p_19) ^ p_19);
            l_37 = (safe_rshift_func_uint16_t_u_s((func_29((g_10 < l_26), g_8) ^ l_26), 1));
            l_37 |= 0xBC50133EL;
        }
        for (g_35 = 21; (g_35 <= 55); g_35 = safe_add_func_uint64_t_u_u(g_35, 1))
        { /* block id: 23 */
            int32_t l_41 = 0x0E92F9E8L;
            l_41 = (g_10 > l_40);
        }
        l_42--;
    }
    l_45 = l_42;
    l_45 = p_18;
    return p_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_35
 * writes: g_32 g_35 g_36
 */
static uint16_t  func_29(int64_t  p_30, const int64_t  p_31)
{ /* block id: 13 */
    ++g_32;
    g_35 = p_30;
    g_36 = ((g_35 , p_31) && 1UL);
    return p_30;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_46[i], "g_46[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 25
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 36
   depth: 2, occurrence: 7
   depth: 3, occurrence: 2
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 55
XXX times a non-volatile is write: 23
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 24
XXX percentage of non-volatile access: 92.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 32
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 8
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 31.6
XXX percentage an existing variable is used: 68.4
********************* end of statistics **********************/

