/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5379652363025558466
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_2[1] = {0x5F70AD6FL};
static uint8_t g_12 = 253UL;
static int32_t g_22[9] = {1L,0L,1L,0L,1L,0L,1L,0L,1L};
static int64_t g_28 = 0x42E11914CC5C6A3FLL;
static volatile uint8_t g_29 = 1UL;/* VOLATILE GLOBAL g_29 */
static uint16_t g_32[7] = {1UL,1UL,0xD743L,1UL,1UL,0xD743L,1UL};


/* --- FORWARD DECLARATIONS --- */
static const int32_t  func_1(void);
static int32_t  func_5(int64_t  p_6, int32_t  p_7, uint16_t  p_8, int16_t  p_9, int32_t  p_10);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_12 g_29 g_32
 * writes: g_2 g_29 g_32
 */
static const int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_11[1];
    int i;
    for (i = 0; i < 1; i++)
        l_11[i] = 0L;
    ++g_2[0];
    g_32[1] &= func_5(((g_2[0] , (-1L)) || l_11[0]), g_12, g_12, g_12, l_11[0]);
    return l_11[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_29
 * writes: g_29
 */
static int32_t  func_5(int64_t  p_6, int32_t  p_7, uint16_t  p_8, int16_t  p_9, int32_t  p_10)
{ /* block id: 2 */
    uint32_t l_13 = 0x9F8D19C9L;
    int32_t l_14 = 0xBACDE9E8L;
    int64_t l_15 = 7L;
    int32_t l_16 = 0x2858905BL;
    int32_t l_17 = (-6L);
    int32_t l_18 = 5L;
    int32_t l_19 = 7L;
    int32_t l_20 = 0x90C6D21CL;
    int32_t l_21 = 4L;
    int32_t l_23 = 0L;
    int32_t l_24 = 0xE11A796DL;
    int32_t l_25 = 9L;
    int32_t l_26 = (-6L);
    int32_t l_27[2];
    int i;
    for (i = 0; i < 2; i++)
        l_27[i] = (-3L);
    l_14 &= l_13;
    --g_29;
    return p_6;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_32[i], "g_32[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 21
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 9
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 8
XXX times a non-volatile is write: 2
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 76.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 6
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 6

XXX percentage a fresh-made variable is used: 70
XXX percentage an existing variable is used: 30
********************* end of statistics **********************/

