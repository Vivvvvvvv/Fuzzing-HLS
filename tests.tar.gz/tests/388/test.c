/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1265108531120359228
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_3[6] = {0xB8L,0xB8L,0xB8L,0xB8L,0xB8L,0xB8L};
static int32_t g_4 = 0x70CD5099L;
static int32_t g_17 = (-1L);
static uint32_t g_64 = 18446744073709551615UL;
static uint64_t g_105 = 0x31468BD1E8AE57A5LL;
static volatile uint16_t g_121[2] = {0UL,0UL};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_7(int32_t  p_8, uint32_t  p_9);
static int64_t  func_18(int32_t  p_19, uint8_t  p_20, int32_t  p_21, const int32_t  p_22, int32_t  p_23);
static int32_t  func_34(uint32_t  p_35);
static uint32_t  func_36(uint8_t  p_37, uint64_t  p_38, uint32_t  p_39, uint16_t  p_40);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_17 g_64 g_105 g_121
 * writes: g_17 g_4 g_64 g_105 g_121
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5 = 0xB3F36565L;
    int64_t l_16 = (-6L);
    int32_t l_104 = 0x8D32190EL;
    uint8_t l_112 = 0xC2L;
lbl_113:
    if (((((!(g_3[5] || 9UL)) & g_4) , l_5) < l_5))
    { /* block id: 1 */
        int32_t l_6 = 0xB9876427L;
        l_6 = 1L;
    }
    else
    { /* block id: 3 */
        uint16_t l_26[4];
        uint32_t l_27 = 2UL;
        int i;
        for (i = 0; i < 4; i++)
            l_26[i] = 0x0D58L;
        g_17 = ((func_7(g_4, g_3[3]) < l_16) , g_4);
        if (((func_18((((safe_div_func_uint64_t_u_u(l_26[2], 0x4898D08F49235799LL)) == 18446744073709551614UL) , 7L), l_26[1], l_27, g_17, l_5) , l_27) , l_16))
        { /* block id: 64 */
            int8_t l_94 = 0xA6L;
            int32_t l_95 = 0x090F62EBL;
            l_95 = (safe_mod_func_int16_t_s_s((l_94 & l_16), 1UL));
        }
        else
        { /* block id: 66 */
            uint16_t l_103 = 0x5EF5L;
            g_17 = (safe_sub_func_int32_t_s_s((safe_add_func_int32_t_s_s((+((safe_sub_func_int16_t_s_s(g_64, 0xCBE7L)) | l_103)), 1UL)), 2UL));
            return l_27;
        }
        for (l_5 = 5; (l_5 >= 0); l_5 -= 1)
        { /* block id: 72 */
            int i;
            l_104 = (g_3[l_5] | g_4);
            g_105++;
        }
    }
    if ((safe_lshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((((l_16 == g_4) , l_16) == g_64), l_112)), 6)))
    { /* block id: 77 */
        if (g_4)
            goto lbl_113;
        return g_105;
    }
    else
    { /* block id: 80 */
        int32_t l_116[1][3];
        int32_t l_119 = 0x4BB34BBFL;
        int32_t l_120[1][9][9] = {{{(-1L),0x62987D0CL,0xA208FD8EL,0x5516B95FL,(-10L),0L,0xD1FC1C17L,0x991E517FL,0x991E517FL},{0x773D59F1L,1L,0x1C45913EL,4L,0x1C45913EL,1L,0x773D59F1L,4L,0x773D59F1L},{(-1L),(-10L),0xD1FC1C17L,0x62987D0CL,0x5516B95FL,0x991E517FL,0xA208FD8EL,0xA208FD8EL,0x991E517FL},{0xC97493B5L,0xF51ADC77L,0L,0xF51ADC77L,0xC97493B5L,4L,0L,4L,0xC97493B5L},{(-10L),0xD1FC1C17L,0x62987D0CL,0x5516B95FL,0x991E517FL,0xA208FD8EL,0xA208FD8EL,0x991E517FL,0x5516B95FL},{0x1C45913EL,4L,0x1C45913EL,1L,0x773D59F1L,4L,0x773D59F1L,1L,0x1C45913EL},{0x5516B95FL,(-10L),0L,0xD1FC1C17L,0x991E517FL,0x991E517FL,0xD1FC1C17L,0L,(-10L)},{0xC97493B5L,0L,0x0DFAB60AL,1L,0xC97493B5L,1L,0x0DFAB60AL,0L,0xC97493B5L},{0x991E517FL,0x62987D0CL,0L,0x5516B95FL,0x5516B95FL,0L,0x62987D0CL,0x991E517FL,(-1L)}}};
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_116[i][j] = 6L;
        }
        g_17 = l_5;
        if (((safe_mul_func_int8_t_s_s((((l_5 == g_64) > g_3[3]) == 0x87CB90AFL), 0xB8L)) > l_116[0][1]))
        { /* block id: 82 */
            uint16_t l_117 = 0x2870L;
            int32_t l_118[7] = {0x39117408L,0x39117408L,0x39117408L,0x39117408L,0x39117408L,0x39117408L,0x39117408L};
            int i;
            l_5 = l_117;
            --g_121[0];
            l_119 ^= g_3[2];
        }
        else
        { /* block id: 86 */
            int16_t l_129[4][9] = {{2L,2L,2L,2L,2L,2L,2L,2L,2L},{0x5431L,(-1L),0x5431L,(-1L),0x5431L,(-1L),0x5431L,(-1L),0x5431L},{2L,2L,2L,2L,2L,2L,2L,2L,2L},{0x5431L,(-1L),0x5431L,(-1L),0x5431L,(-1L),0x5431L,(-1L),0x5431L}};
            int i, j;
            g_17 = (((safe_mod_func_int64_t_s_s(((~g_4) ^ g_105), 0x88B3BFF73A4BFF4CLL)) < 3UL) , 0L);
            l_120[0][3][7] = (safe_sub_func_uint16_t_u_u(l_129[0][0], g_3[5]));
            g_17 = l_120[0][6][3];
            l_5 = (((safe_lshift_func_int8_t_s_s((g_64 , l_116[0][2]), 4)) < l_120[0][3][7]) | l_129[3][2]);
        }
        for (g_105 = 0; (g_105 <= 0); g_105 += 1)
        { /* block id: 94 */
            g_17 &= (18446744073709551611UL >= 0x0B5A963199CE3922LL);
        }
    }
    for (l_104 = 11; (l_104 == 18); l_104 = safe_add_func_int32_t_s_s(l_104, 7))
    { /* block id: 100 */
        g_17 = 0x95485A9BL;
    }
    return l_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4
 * writes:
 */
static int32_t  func_7(int32_t  p_8, uint32_t  p_9)
{ /* block id: 4 */
    uint32_t l_14[1][6];
    int32_t l_15 = 8L;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
            l_14[i][j] = 5UL;
    }
    l_14[0][3] |= ((safe_div_func_uint32_t_u_u(((safe_mul_func_int16_t_s_s((1L <= g_3[5]), g_4)) || p_8), g_4)) <= g_4);
    l_15 = (g_3[3] , l_14[0][0]);
    l_15 = ((((l_14[0][3] <= 0xE215L) , l_15) > l_15) > 0UL);
    return g_3[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_17 g_64
 * writes: g_4 g_17 g_64
 */
static int64_t  func_18(int32_t  p_19, uint8_t  p_20, int32_t  p_21, const int32_t  p_22, int32_t  p_23)
{ /* block id: 10 */
    uint32_t l_32 = 0UL;
    int32_t l_33 = (-1L);
    for (p_23 = 0; (p_23 == 21); p_23 = safe_add_func_uint8_t_u_u(p_23, 8))
    { /* block id: 13 */
        int8_t l_30 = 0x3CL;
        int32_t l_31 = 0xB6AC39B3L;
        l_31 ^= l_30;
    }
    l_33 = func_7(l_32, p_19);
    l_33 = func_7(g_17, p_21);
    if (func_34(func_36(((!p_23) , 0x1FL), p_21, g_17, g_3[0])))
    { /* block id: 58 */
        return g_3[5];
    }
    else
    { /* block id: 60 */
        int32_t l_91[6][6] = {{0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L},{0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L},{0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L},{0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L},{0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L},{0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L,0x8FA0B358L}};
        int i, j;
        l_91[5][1] |= (safe_div_func_int32_t_s_s(((9UL ^ g_3[5]) & p_19), 2UL));
    }
    return g_17;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_34(uint32_t  p_35)
{ /* block id: 56 */
    return p_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_17 g_64
 * writes: g_4 g_17 g_64
 */
static uint32_t  func_36(uint8_t  p_37, uint64_t  p_38, uint32_t  p_39, uint16_t  p_40)
{ /* block id: 18 */
    int64_t l_52 = 0x3B8FBA323A35E06CLL;
    int32_t l_55 = 1L;
    int16_t l_79 = 1L;
    if ((((safe_mul_func_int8_t_s_s((((safe_rshift_func_int16_t_s_u((safe_sub_func_int64_t_s_s((((safe_div_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(g_4, g_3[3])), l_52)) == l_52) & g_4), 18446744073709551615UL)), 1)) & l_52) && l_52), 0xD6L)) | 0x9EL) < l_52))
    { /* block id: 19 */
        volatile uint16_t l_57 = 0x10AAL;/* VOLATILE GLOBAL l_57 */
        l_55 = ((safe_mul_func_int16_t_s_s(g_4, p_39)) | 1L);
        for (g_4 = 0; (g_4 <= 5); g_4 += 1)
        { /* block id: 23 */
            int i;
            l_57 = (((safe_unary_minus_func_int64_t_s(g_3[g_4])) ^ 0xC3L) , g_3[g_4]);
            g_17 = ((safe_sub_func_int8_t_s_s((-10L), 0x17L)) , l_55);
        }
        return p_38;
    }
    else
    { /* block id: 28 */
lbl_78:
        for (g_4 = 4; (g_4 >= 0); g_4 -= 1)
        { /* block id: 31 */
            int32_t l_69 = 0xB330CFEFL;
            int i;
            if (g_3[g_4])
                break;
            g_64 |= (safe_mul_func_int8_t_s_s((safe_div_func_uint64_t_u_u((g_3[(g_4 + 1)] & g_17), 0x26695BD66052DBC4LL)), p_40));
            l_55 ^= ((safe_rshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u((p_39 & g_64), g_3[2])), l_69)) , p_40);
            if (l_69)
                continue;
        }
    }
    l_55 = g_4;
    if (((g_3[3] != g_17) ^ (-1L)))
    { /* block id: 39 */
        for (p_40 = (-14); (p_40 <= 41); p_40 = safe_add_func_uint32_t_u_u(p_40, 3))
        { /* block id: 42 */
            if (g_3[0])
                break;
        }
    }
    else
    { /* block id: 45 */
        int32_t l_75 = 0xAA229768L;
        l_75 ^= ((((safe_mod_func_uint8_t_u_u((safe_unary_minus_func_int16_t_s(0L)), g_17)) || p_39) < g_17) == 3UL);
        g_17 = (safe_div_func_int32_t_s_s((0x84L < g_17), g_3[5]));
        if (g_4)
        { /* block id: 48 */
            if (l_75)
                goto lbl_78;
        }
        else
        { /* block id: 50 */
            return l_79;
        }
    }
    l_55 = (safe_mod_func_uint8_t_u_u(((safe_mod_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((+(safe_lshift_func_uint16_t_u_u(p_38, 9))) > p_38), g_4)), g_4)) ^ p_39), l_55));
    return p_39;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_121[i], "g_121[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 35
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 58
   depth: 2, occurrence: 11
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
   depth: 5, occurrence: 8
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 98
XXX times a non-volatile is write: 37
XXX times a volatile is read: 21
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 54
XXX percentage of non-volatile access: 85.4

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 62
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 21
   depth: 2, occurrence: 22

XXX percentage a fresh-made variable is used: 24
XXX percentage an existing variable is used: 76
********************* end of statistics **********************/

