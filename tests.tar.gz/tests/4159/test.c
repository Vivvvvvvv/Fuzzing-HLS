/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      191449511617956521
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_4 = 0x56L;
static volatile uint32_t g_5 = 4UL;/* VOLATILE GLOBAL g_5 */
static uint8_t g_10 = 0x54L;
static volatile uint64_t g_16 = 0xD9CD4431FADACD7DLL;/* VOLATILE GLOBAL g_16 */
static uint32_t g_17[9] = {9UL,9UL,9UL,9UL,9UL,9UL,9UL,9UL,9UL};
static uint16_t g_38 = 0x98BBL;
static int16_t g_39 = 0x050BL;
static int32_t g_43 = 0x0B8F3BECL;
static volatile uint64_t g_44 = 0UL;/* VOLATILE GLOBAL g_44 */
static int64_t g_48 = 1L;
static volatile uint32_t g_49 = 0x06946CB4L;/* VOLATILE GLOBAL g_49 */
static volatile uint8_t g_52 = 0UL;/* VOLATILE GLOBAL g_52 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(int8_t  p_3);
static uint64_t  func_20(int64_t  p_21, uint8_t  p_22, uint64_t  p_23, uint32_t  p_24, uint64_t  p_25);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_17 g_10 g_16 g_44 g_49 g_52
 * writes: g_5 g_4 g_10 g_16 g_17 g_38 g_44 g_49 g_52
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_40[6] = {0x3C95L,0x3C95L,0x3C95L,0x3C95L,0x3C95L,0x3C95L};
    int32_t l_41 = 0L;
    int32_t l_42 = 1L;
    int i;
    g_38 = func_2(g_4);
    if (g_4)
        goto lbl_47;
lbl_47:
    g_44--;
    g_49--;
    --g_52;
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_4 g_17 g_10 g_16
 * writes: g_5 g_4 g_10 g_16 g_17
 */
static int32_t  func_2(int8_t  p_3)
{ /* block id: 1 */
    int8_t l_14 = 0xFCL;
    int32_t l_37 = 0xC7E12FD8L;
    --g_5;
    for (g_4 = 0; (g_4 > 9); g_4++)
    { /* block id: 5 */
        uint32_t l_15[9] = {7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL};
        int i;
        g_10 = (g_5 , p_3);
        for (p_3 = 21; (p_3 < 20); p_3 = safe_sub_func_uint16_t_u_u(p_3, 2))
        { /* block id: 9 */
            l_14 = (safe_unary_minus_func_uint64_t_u(p_3));
            if (l_15[6])
                break;
            g_16 = (((1UL != 0L) , p_3) , 0x1ECE3051L);
            if (p_3)
                break;
        }
        g_17[4]--;
        l_37 ^= ((func_20((((safe_lshift_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(249UL, 5)), 3)) || g_10) <= 0x243E5EC3L), p_3, p_3, p_3, g_10) , g_16) != g_10);
    }
    return g_17[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_17
 * writes:
 */
static uint64_t  func_20(int64_t  p_21, uint8_t  p_22, uint64_t  p_23, uint32_t  p_24, uint64_t  p_25)
{ /* block id: 16 */
    uint32_t l_30 = 1UL;
    int32_t l_33[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
    int i;
    l_30 = p_23;
    if (p_23)
        goto lbl_34;
    if (p_23)
        goto lbl_34;
lbl_34:
    l_33[6] = (safe_add_func_int64_t_s_s(0x85FAFE44FA3FDA37LL, l_30));
    for (p_22 = 0; (p_22 == 27); p_22 = safe_add_func_int64_t_s_s(p_22, 7))
    { /* block id: 23 */
        if (g_16)
            break;
    }
    return g_17[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_17[i], "g_17[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 6
   depth: 4, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 10
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 22
XXX percentage of non-volatile access: 78.9

XXX forward jumps: 3
XXX backward jumps: 0

XXX stmts: 24
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 5
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 52.6
XXX percentage an existing variable is used: 47.4
********************* end of statistics **********************/

