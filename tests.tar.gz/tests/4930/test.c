/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1201482191746828727
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_2[7] = {0xB319L,0xB319L,0xB319L,0xB319L,0xB319L,0xB319L,0xB319L};
static volatile int32_t g_5 = 6L;/* VOLATILE GLOBAL g_5 */
static volatile int8_t g_8 = 0x4DL;/* VOLATILE GLOBAL g_8 */
static int32_t g_11 = 0xCBCEF054L;
static volatile int32_t g_12[5] = {0x822CB3A3L,0x822CB3A3L,0x822CB3A3L,0x822CB3A3L,0x822CB3A3L};
static uint64_t g_13[2] = {18446744073709551607UL,18446744073709551607UL};
static volatile int32_t g_17 = 0L;/* VOLATILE GLOBAL g_17 */
static volatile int32_t g_18 = 0x37ACED45L;/* VOLATILE GLOBAL g_18 */
static volatile uint16_t g_19 = 0x9683L;/* VOLATILE GLOBAL g_19 */
static int16_t g_64 = 0xFE30L;
static volatile uint8_t g_65 = 0x05L;/* VOLATILE GLOBAL g_65 */
static int16_t g_95 = 2L;
static const uint32_t g_96 = 18446744073709551615UL;


/* --- FORWARD DECLARATIONS --- */
static const uint16_t  func_1(void);
static int32_t  func_22(uint64_t  p_23, const uint32_t  p_24, int32_t  p_25, int64_t  p_26, int64_t  p_27);
static int32_t  func_28(uint8_t  p_29, uint32_t  p_30, int64_t  p_31, int32_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_19 g_12 g_2 g_17 g_18 g_8 g_65 g_64 g_5 g_11 g_95 g_96
 * writes: g_13 g_19 g_65 g_5 g_95
 */
static const uint16_t  func_1(void)
{ /* block id: 0 */
    int64_t l_3 = 0L;
    int32_t l_4 = 7L;
    int32_t l_6 = 8L;
    int32_t l_7 = (-1L);
    int32_t l_9 = 8L;
    int32_t l_10 = 0xD6923607L;
    int8_t l_16 = 0xF9L;
    int8_t l_45 = 0xFBL;
    g_13[0]--;
    ++g_19;
    g_95 |= (func_22((func_28((+((~((((safe_div_func_int8_t_s_s((safe_sub_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((safe_mul_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(l_10, l_6)), g_12[4])), 0x27L)), (-9L))), g_13[1])) && 0xE2L) >= l_6) ^ g_13[0])) <= l_16)), g_2[6], g_13[0], l_45) , l_3), g_64, l_10, g_64, l_45) | g_11);
    return g_96;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_2
 * writes: g_5
 */
static int32_t  func_22(uint64_t  p_23, const uint32_t  p_24, int32_t  p_25, int64_t  p_26, int64_t  p_27)
{ /* block id: 25 */
    p_25 = (safe_div_func_uint32_t_u_u((safe_mod_func_int64_t_s_s(((g_18 ^ 0L) ^ 65535UL), 0xF461E62ED8E9B07DLL)), 4294967288UL));
    g_5 = ((2L | 0x9F7867F40E302F92LL) , (-1L));
    return g_2[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_17 g_2 g_19 g_12 g_18 g_8 g_65 g_64 g_5 g_11
 * writes: g_65 g_5
 */
static int32_t  func_28(uint8_t  p_29, uint32_t  p_30, int64_t  p_31, int32_t  p_32)
{ /* block id: 3 */
    uint64_t l_49 = 0xB1CAD2BB650EBF08LL;
    int32_t l_50 = 0L;
    if (((g_13[0] == g_17) | g_13[0]))
    { /* block id: 4 */
        uint8_t l_48 = 0xA9L;
        int32_t l_61 = 4L;
        int32_t l_63[5] = {0L,0L,0L,0L,0L};
        int i;
        l_50 = (((((safe_sub_func_int16_t_s_s((g_2[4] , 0xD615L), l_48)) ^ g_19) , l_49) & 0xFF32L) < g_2[4]);
        l_61 = ((safe_add_func_uint64_t_u_u((safe_add_func_int8_t_s_s((((safe_rshift_func_uint16_t_u_s((safe_mod_func_int16_t_s_s(((safe_div_func_uint32_t_u_u(0xDAAFE497L, p_31)) == 7L), l_48)), 4)) , p_31) > g_12[4]), g_2[4])), 0x718A84D2376568C0LL)) & g_2[0]);
        for (l_50 = 0; (l_50 <= 1); l_50 += 1)
        { /* block id: 9 */
            int i;
            p_32 &= ((((+(g_13[l_50] , g_13[l_50])) <= l_50) || g_18) == p_29);
        }
        if ((((((g_8 || p_30) == 1UL) > l_50) || (-4L)) , l_61))
        { /* block id: 12 */
            g_65--;
        }
        else
        { /* block id: 14 */
            p_32 = (safe_rshift_func_uint8_t_u_u(((safe_lshift_func_int8_t_s_u((safe_mul_func_int16_t_s_s((!(g_18 , 0L)), 1UL)), 3)) , g_2[2]), g_64));
            g_5 ^= (safe_add_func_uint16_t_u_u((((safe_add_func_uint8_t_u_u(((((safe_add_func_int32_t_s_s(p_31, 0xEFB40ACBL)) , 252UL) , p_29) == 2L), 2UL)) < p_31) , 1UL), 5L));
        }
    }
    else
    { /* block id: 18 */
        p_32 = (((safe_rshift_func_uint8_t_u_u(((((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((p_31 == p_32), g_19)), 2UL)) , 0x2599L) == 0x4152L) == p_30), p_30)) | p_29) ^ (-2L));
        g_5 = (((safe_add_func_int32_t_s_s((((safe_mod_func_int16_t_s_s(g_11, p_29)) , 0x87L) | g_65), 0xBF4B2487L)) || p_30) ^ g_13[0]);
    }
    p_32 = (((g_19 , p_31) && l_49) < p_31);
    g_5 = g_65;
    return l_50;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_12[i], "g_12[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 26
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 21
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 21, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 54
XXX times a non-volatile is write: 10
XXX times a volatile is read: 12
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 33
XXX percentage of non-volatile access: 78

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 6
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 25.5
XXX percentage an existing variable is used: 74.5
********************* end of statistics **********************/

