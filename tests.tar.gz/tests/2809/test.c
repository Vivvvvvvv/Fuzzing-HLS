/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15729449747608416322
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int16_t  f0;
   uint8_t  f1;
   int16_t  f2;
   const volatile uint16_t  f3;
   int16_t  f4;
   uint16_t  f5;
   const int8_t  f6;
   volatile int32_t  f7;
   int64_t  f8;
   const uint64_t  f9;
};

struct S1 {
   volatile int64_t  f0;
   volatile struct S0  f1;
   int32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_3[7] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static volatile int32_t g_4 = 0x3E86F8C7L;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_5 = 0L;/* VOLATILE GLOBAL g_5 */
static volatile int32_t g_6 = 1L;/* VOLATILE GLOBAL g_6 */
static volatile int32_t g_7[5] = {0xE780CA9FL,0xE780CA9FL,0xE780CA9FL,0xE780CA9FL,0xE780CA9FL};
static volatile int32_t g_8[5] = {0xC9214A9BL,0xC9214A9BL,0xC9214A9BL,0xC9214A9BL,0xC9214A9BL};
static int32_t g_9 = (-9L);
static struct S1 g_37 = {0xE66B6C7E7C0CE695LL,{1L,0x5DL,-1L,0x21E5L,0x5036L,0UL,0x17L,0L,-10L,1UL},0xF8A3D355L};/* VOLATILE GLOBAL g_37 */
static volatile struct S1 g_58 = {0xFF73186757AC12ABLL,{-1L,255UL,0x5F68L,0x4519L,-3L,0xE42CL,0xC5L,0x07C8A85FL,2L,7UL},0L};/* VOLATILE GLOBAL g_58 */
static int32_t g_80 = 0x737D6854L;
static uint32_t g_98[3] = {0UL,0UL,0UL};


/* --- FORWARD DECLARATIONS --- */
static const uint64_t  func_1(void);
static uint64_t  func_22(uint64_t  p_23, uint8_t  p_24);
static int8_t  func_33(int32_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_9 g_5 g_8 g_37 g_58 g_6 g_80 g_98 g_7
 * writes: g_3 g_9 g_4 g_37.f2 g_7 g_58.f2 g_8 g_6 g_5
 */
static const uint64_t  func_1(void)
{ /* block id: 0 */
    const uint16_t l_2 = 0xFA2FL;
    int32_t l_10 = 0x8905B8B7L;
    uint64_t l_17 = 0UL;
    int32_t l_128[6] = {1L,1L,1L,1L,1L,1L};
    int i;
    g_3[2] |= l_2;
    for (g_9 = 6; (g_9 >= 2); g_9 -= 1)
    { /* block id: 4 */
        int i;
        l_10 |= g_3[g_9];
        if (((safe_lshift_func_int16_t_s_s(((((safe_mul_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s(7L, g_3[g_9])) <= g_3[2]), g_5)) <= 0xE11AL) < g_9) , g_3[2]), l_10)) > g_9))
        { /* block id: 6 */
            int8_t l_127 = 0xCCL;
            ++l_17;
            l_127 ^= (safe_mod_func_uint64_t_u_u(func_22(g_8[2], l_17), g_80));
        }
        else
        { /* block id: 58 */
            return g_3[g_9];
        }
        g_5 = 1L;
        g_37.f2 = g_58.f1.f2;
    }
    l_128[4] |= (l_10 , g_37.f1.f0);
    return g_37.f1.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_37 g_3 g_58 g_6 g_9 g_80 g_98 g_7 g_5
 * writes: g_4 g_37.f2 g_7 g_58.f2 g_8 g_6
 */
static uint64_t  func_22(uint64_t  p_23, uint8_t  p_24)
{ /* block id: 8 */
    uint64_t l_30 = 0x0197CBB40284818ALL;
    uint8_t l_90[2];
    int32_t l_99 = 0L;
    uint32_t l_103 = 0xEA743E71L;
    const int16_t l_118 = (-4L);
    int8_t l_120 = 0xADL;
    int i;
    for (i = 0; i < 2; i++)
        l_90[i] = 0xA6L;
    for (p_23 = (-27); (p_23 > 57); ++p_23)
    { /* block id: 11 */
        int32_t l_29 = 0x550E8F7CL;
        for (p_24 = (-7); (p_24 != 58); p_24++)
        { /* block id: 14 */
            int16_t l_91 = 0xB164L;
            g_4 = g_8[4];
            l_30 &= ((1L | l_29) | g_8[4]);
            l_91 = ((safe_mul_func_uint16_t_u_u(((func_33(l_29) & 0xF7L) <= p_24), l_30)) == l_90[0]);
        }
    }
    g_58.f2 = ((g_6 ^ g_3[2]) , 8L);
    if (((safe_add_func_uint8_t_u_u(g_8[0], g_9)) , g_80))
    { /* block id: 38 */
        for (g_37.f2 = 11; (g_37.f2 == (-12)); g_37.f2--)
        { /* block id: 41 */
            const uint16_t l_96 = 0xE0C0L;
            int32_t l_97[1];
            int i;
            for (i = 0; i < 1; i++)
                l_97[i] = 3L;
            l_97[0] |= (((g_58.f1.f8 == g_3[2]) <= l_96) && g_37.f1.f1);
            l_99 = g_98[0];
        }
        g_8[0] = (((safe_rshift_func_uint8_t_u_s(0xF5L, 0)) ^ p_24) && l_30);
    }
    else
    { /* block id: 46 */
        int32_t l_102 = 0xB99B8081L;
        ++l_103;
        g_6 = (g_58.f1.f9 > p_23);
        for (p_24 = 0; (p_24 == 43); ++p_24)
        { /* block id: 51 */
            uint32_t l_119 = 0UL;
            g_58.f2 = ((safe_sub_func_uint64_t_u_u(((!((safe_rshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u((safe_rshift_func_uint16_t_u_s((~(((((l_118 || g_7[2]) >= l_119) & g_80) | 0L) | l_102)), 15)), l_120)), 13)) | p_24)) >= p_24), g_37.f2)) , 0x4293352AL);
            l_99 = ((safe_rshift_func_uint8_t_u_u(((((safe_mul_func_uint8_t_u_u(((((safe_mul_func_uint16_t_u_u(p_24, g_5)) , g_8[0]) != p_24) , g_58.f1.f3), 0UL)) & 5L) & l_90[0]) , 255UL), l_103)) & p_23);
        }
    }
    return g_37.f1.f7;
}


/* ------------------------------------------ */
/* 
 * reads : g_37 g_8 g_3 g_58
 * writes: g_37.f2 g_7
 */
static int8_t  func_33(int32_t  p_34)
{ /* block id: 17 */
    uint8_t l_38[2];
    int32_t l_47 = 0xC96AAE11L;
    int64_t l_60 = 0xEA71B313CF365AEDLL;
    int32_t l_61 = 8L;
    int32_t l_62 = 0x9F159E9DL;
    int32_t l_63 = (-1L);
    int32_t l_66 = (-2L);
    int32_t l_67 = (-6L);
    int32_t l_68 = 0xB7621CC8L;
    int32_t l_70 = 1L;
    int32_t l_71 = 5L;
    int32_t l_73[5];
    uint64_t l_81 = 3UL;
    int i;
    for (i = 0; i < 2; i++)
        l_38[i] = 0xFAL;
    for (i = 0; i < 5; i++)
        l_73[i] = 0xEE4CBE06L;
    if ((((safe_mul_func_int8_t_s_s((g_37 , p_34), p_34)) | l_38[1]) != 0L))
    { /* block id: 18 */
        int16_t l_41[2];
        int32_t l_42 = 0xBD42F903L;
        int i;
        for (i = 0; i < 2; i++)
            l_41[i] = 0L;
        l_41[1] |= (safe_div_func_int64_t_s_s(p_34, l_38[1]));
        l_42 = ((g_8[0] & 0xB80555F25AD92EDCLL) & g_3[2]);
    }
    else
    { /* block id: 21 */
        int32_t l_59[3];
        int32_t l_64 = 0x7628F8C8L;
        int32_t l_65 = 0x63D46B2EL;
        int32_t l_69 = 0x094FC7A5L;
        int32_t l_72 = (-1L);
        int32_t l_74 = 0xF1EF3A5EL;
        int32_t l_75 = 5L;
        int32_t l_76 = (-1L);
        int32_t l_77 = 3L;
        int32_t l_78[7] = {(-7L),(-7L),(-7L),(-7L),(-7L),(-7L),(-7L)};
        int32_t l_79 = 0xA1103C6CL;
        int i;
        for (i = 0; i < 3; i++)
            l_59[i] = 0x2614AC9AL;
        l_47 = ((safe_mod_func_int64_t_s_s((+((((+0xB9DBL) && 255UL) , p_34) , 0xBF33464EL)), 0x42724202D95C7885LL)) == g_37.f1.f8);
        for (g_37.f2 = 24; (g_37.f2 <= 4); g_37.f2 = safe_sub_func_int8_t_s_s(g_37.f2, 6))
        { /* block id: 25 */
            uint8_t l_56 = 0x2CL;
            int32_t l_57 = 0x8D320CD5L;
            l_56 = ((((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((((+((~p_34) ^ 0xCD947E9EL)) >= p_34) || l_38[1]), l_38[1])), p_34)) <= 0xD1E5L) | 0x6C42L) | 255UL);
            l_57 = l_56;
            g_7[1] = (((g_58 , p_34) , l_59[2]) || l_60);
        }
        ++l_81;
    }
    l_73[4] |= (((((safe_add_func_uint8_t_u_u(((safe_mod_func_int32_t_s_s(((safe_div_func_uint32_t_u_u(p_34, p_34)) & 0xF826083B57DFA0F4LL), l_70)) >= 0L), l_63)) != p_34) > 0x2906C797L) & 0xEA2622DBL) >= 18446744073709551615UL);
    return l_73[4];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_8[i], "g_8[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_37.f0, "g_37.f0", print_hash_value);
    transparent_crc(g_37.f1.f0, "g_37.f1.f0", print_hash_value);
    transparent_crc(g_37.f1.f1, "g_37.f1.f1", print_hash_value);
    transparent_crc(g_37.f1.f2, "g_37.f1.f2", print_hash_value);
    transparent_crc(g_37.f1.f3, "g_37.f1.f3", print_hash_value);
    transparent_crc(g_37.f1.f4, "g_37.f1.f4", print_hash_value);
    transparent_crc(g_37.f1.f5, "g_37.f1.f5", print_hash_value);
    transparent_crc(g_37.f1.f6, "g_37.f1.f6", print_hash_value);
    transparent_crc(g_37.f1.f7, "g_37.f1.f7", print_hash_value);
    transparent_crc(g_37.f1.f8, "g_37.f1.f8", print_hash_value);
    transparent_crc(g_37.f1.f9, "g_37.f1.f9", print_hash_value);
    transparent_crc(g_37.f2, "g_37.f2", print_hash_value);
    transparent_crc(g_58.f0, "g_58.f0", print_hash_value);
    transparent_crc(g_58.f1.f0, "g_58.f1.f0", print_hash_value);
    transparent_crc(g_58.f1.f1, "g_58.f1.f1", print_hash_value);
    transparent_crc(g_58.f1.f2, "g_58.f1.f2", print_hash_value);
    transparent_crc(g_58.f1.f3, "g_58.f1.f3", print_hash_value);
    transparent_crc(g_58.f1.f4, "g_58.f1.f4", print_hash_value);
    transparent_crc(g_58.f1.f5, "g_58.f1.f5", print_hash_value);
    transparent_crc(g_58.f1.f6, "g_58.f1.f6", print_hash_value);
    transparent_crc(g_58.f1.f7, "g_58.f1.f7", print_hash_value);
    transparent_crc(g_58.f1.f8, "g_58.f1.f8", print_hash_value);
    transparent_crc(g_58.f1.f9, "g_58.f1.f9", print_hash_value);
    transparent_crc(g_58.f2, "g_58.f2", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_98[i], "g_98[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 48
   depth: 1, occurrence: 0
   depth: 2, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 40
   depth: 2, occurrence: 9
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 68
XXX times a non-volatile is write: 25
XXX times a volatile is read: 20
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 101
XXX percentage of non-volatile access: 77.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 39
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 15
   depth: 2, occurrence: 13

XXX percentage a fresh-made variable is used: 19.6
XXX percentage an existing variable is used: 80.4
********************* end of statistics **********************/

