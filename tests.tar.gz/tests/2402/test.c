/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5021116658560647811
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const volatile uint64_t  f0;
   const volatile uint16_t  f1;
   uint8_t  f2;
   volatile uint32_t  f3;
   int16_t  f4;
};

struct S1 {
   int16_t  f0;
   const int8_t  f1;
   int16_t  f2;
   const int32_t  f3;
   volatile struct S0  f4;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0L;
static int16_t g_19 = 0L;
static uint32_t g_21 = 0x0549EC71L;
static uint8_t g_33 = 0xE5L;
static int32_t g_47 = 0x514FC6BFL;
static struct S1 g_50[8] = {{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}},{0x03D7L,0x6DL,0x11D6L,0xC043CA38L,{18446744073709551611UL,0x6852L,0xB5L,0x65344FFAL,-10L}}};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_6(const int32_t  p_7, const int64_t  p_8, int16_t  p_9);
static int32_t  func_11(uint8_t  p_12, int8_t  p_13, int8_t  p_14, int16_t  p_15, int32_t  p_16);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_21 g_33 g_19 g_47 g_50
 * writes: g_2 g_19 g_21 g_33 g_47
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    const int32_t l_10 = 1L;
    int32_t l_42 = 1L;
    int8_t l_51 = 0x03L;
    for (g_2 = 3; (g_2 <= (-26)); --g_2)
    { /* block id: 3 */
        uint32_t l_5 = 0x909B7928L;
        l_5 = g_2;
        if ((func_6(g_2, l_10, g_2) , g_2))
        { /* block id: 14 */
            uint8_t l_39 = 0x4EL;
            l_39 = (g_33 <= g_19);
        }
        else
        { /* block id: 16 */
            l_42 = ((safe_rshift_func_uint8_t_u_s((g_2 && 6UL), 4)) >= g_2);
        }
        for (g_33 = (-8); (g_33 >= 58); ++g_33)
        { /* block id: 21 */
            if (l_5)
                break;
            g_47 &= ((((safe_mod_func_uint64_t_u_u(g_2, l_42)) , l_5) ^ l_42) >= 0x52129E5EL);
        }
        return g_33;
    }
    l_51 = (((safe_mul_func_int8_t_s_s((g_50[1] , 1L), g_47)) ^ 0L) <= 65526UL);
    g_2 |= (l_51 & (-5L));
    return g_50[1].f4.f1;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_21 g_33
 * writes: g_19 g_21 g_33
 */
static int32_t  func_6(const int32_t  p_7, const int64_t  p_8, int16_t  p_9)
{ /* block id: 5 */
    int64_t l_17 = (-5L);
    uint64_t l_37 = 0x56D4C01E07AD46D2LL;
    int32_t l_38 = (-2L);
    g_21 ^= func_11(g_2, l_17, g_2, p_8, g_2);
    g_33 &= (safe_add_func_int8_t_s_s(((safe_unary_minus_func_uint32_t_u((((safe_div_func_uint32_t_u_u((safe_div_func_uint32_t_u_u((safe_div_func_uint64_t_u_u(((safe_add_func_int16_t_s_s(0x0547L, g_2)) , 0x8F08877E06985BA5LL), g_2)), 0xB1857497L)), 0xFED6C34FL)) >= 4294967290UL) | g_2))) != p_7), p_7));
    l_38 = (((safe_add_func_int16_t_s_s(((((~g_21) ^ g_21) <= g_21) , l_17), l_37)) || g_2) , p_8);
    return l_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_19
 */
static int32_t  func_11(uint8_t  p_12, int8_t  p_13, int8_t  p_14, int16_t  p_15, int32_t  p_16)
{ /* block id: 6 */
    uint8_t l_18 = 0xC6L;
    int32_t l_20 = 0x9BEAB1D6L;
    g_19 = (l_18 != g_2);
    l_20 = (l_18 , 0L);
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_47, "g_47", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_50[i].f0, "g_50[i].f0", print_hash_value);
        transparent_crc(g_50[i].f1, "g_50[i].f1", print_hash_value);
        transparent_crc(g_50[i].f2, "g_50[i].f2", print_hash_value);
        transparent_crc(g_50[i].f3, "g_50[i].f3", print_hash_value);
        transparent_crc(g_50[i].f4.f0, "g_50[i].f4.f0", print_hash_value);
        transparent_crc(g_50[i].f4.f1, "g_50[i].f4.f1", print_hash_value);
        transparent_crc(g_50[i].f4.f2, "g_50[i].f4.f2", print_hash_value);
        transparent_crc(g_50[i].f4.f3, "g_50[i].f4.f3", print_hash_value);
        transparent_crc(g_50[i].f4.f4, "g_50[i].f4.f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 0
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 6
   depth: 4, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 42
XXX times a non-volatile is write: 13
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 98.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 19
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 28.8
XXX percentage an existing variable is used: 71.2
********************* end of statistics **********************/

