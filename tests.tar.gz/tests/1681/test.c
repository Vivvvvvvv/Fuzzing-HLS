/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8764306100201303977
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x68EC0AE9L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[4] = {0xA0256915L,0xA0256915L,0xA0256915L,0xA0256915L};
static volatile int32_t g_4 = 0x7BF5CD53L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 1L;
static int32_t g_16 = 0L;
static uint8_t g_38 = 253UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_28(const int32_t  p_29, uint8_t  p_30, uint64_t  p_31, const uint16_t  p_32, uint8_t  p_33);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_4 g_16 g_3 g_38
 * writes: g_5 g_38
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_8[9] = {5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL};
    int32_t l_10 = (-1L);
    int32_t l_11 = 1L;
    int32_t l_12 = 0x3061ECE3L;
    int32_t l_13 = 0x9CD4431FL;
    int32_t l_14 = 9L;
    int32_t l_15 = 0x9A7B445AL;
    int32_t l_17 = 1L;
    int32_t l_18 = 0xB3CF8132L;
    int32_t l_19 = 0x73D5943EL;
    int32_t l_20 = 5L;
    int32_t l_21 = 0L;
    int32_t l_22 = (-7L);
    uint8_t l_23 = 0xB2L;
    int i;
    for (g_5 = 29; (g_5 == 24); g_5--)
    { /* block id: 3 */
        return g_2;
    }
    if (g_5)
        goto lbl_9;
lbl_9:
    l_8[8] = 0xF6C74AA0L;
    ++l_23;
    g_38 |= (safe_rshift_func_uint16_t_u_u((func_28(g_4, g_5, g_16, l_8[2], l_18) == (-3L)), l_23));
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint32_t  func_28(const int32_t  p_29, uint8_t  p_30, uint64_t  p_31, const uint16_t  p_32, uint8_t  p_33)
{ /* block id: 9 */
    int32_t l_34[1];
    uint32_t l_35 = 0x8400B8F3L;
    int i;
    for (i = 0; i < 1; i++)
        l_34[i] = 0xAA50887CL;
    l_34[0] |= (-1L);
    l_34[0] = l_34[0];
    l_34[0] = 0x786C7A88L;
    l_35++;
    return g_3[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 8
XXX times a non-volatile is write: 8
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 84.2

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 29
XXX percentage an existing variable is used: 71
********************* end of statistics **********************/

