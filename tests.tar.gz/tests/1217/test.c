/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12660286863157594070
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0L;
static volatile uint32_t g_13[3][4][1] = {{{0x22DB785BL},{0x38E486AEL},{0x8EC32687L},{0x8EC32687L}},{{0x38E486AEL},{0x22DB785BL},{0x38E486AEL},{0x8EC32687L}},{{0x8EC32687L},{0x38E486AEL},{0x22DB785BL},{0x38E486AEL}}};
static volatile uint32_t g_52 = 0xADF561F6L;/* VOLATILE GLOBAL g_52 */
static uint32_t g_62 = 1UL;
static uint32_t g_66 = 0x5E8E0599L;
static int8_t g_67 = 0x28L;
static uint64_t g_82[3][1] = {{1UL},{1UL},{1UL}};
static uint32_t g_83 = 0x0950C43CL;
static int64_t g_84 = 0L;
static volatile int8_t g_85 = (-1L);/* VOLATILE GLOBAL g_85 */
static volatile uint64_t g_86 = 0x0CF10AA6F331A9D0LL;/* VOLATILE GLOBAL g_86 */
static uint16_t g_100 = 4UL;
static uint32_t g_114 = 18446744073709551613UL;
static volatile uint16_t g_118[4][1][4] = {{{0xC8C9L,0UL,0xC8C9L,0xC8C9L}},{{0UL,0UL,0x46A6L,0UL}},{{0UL,0xC8C9L,0xC8C9L,0UL}},{{0xC8C9L,0UL,0xC8C9L,0xC8C9L}}};
static int32_t g_135[5][6] = {{6L,6L,0L,6L,6L,0L},{6L,6L,0L,6L,6L,0L},{6L,6L,0L,0L,0L,6L},{0L,0L,6L,0L,0L,6L},{0L,0L,6L,0L,0L,6L}};
static uint64_t g_177 = 0xC92BCF4DB291124ALL;
static volatile int32_t g_190 = 0x9C81770CL;/* VOLATILE GLOBAL g_190 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static const int64_t  func_5(uint32_t  p_6);
static int32_t  func_21(const int16_t  p_22, const int64_t  p_23, const int64_t  p_24, uint16_t  p_25);
static const int8_t  func_45(int16_t  p_46, uint8_t  p_47);
static int8_t  func_70(uint64_t  p_71, int8_t  p_72, int32_t  p_73, int8_t  p_74);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_52 g_66 g_62 g_86 g_84 g_85 g_118 g_83 g_114 g_135 g_177 g_67
 * writes: g_2 g_13 g_52 g_62 g_67 g_82 g_83 g_86 g_100 g_114 g_118 g_135 g_177
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_195 = 0UL;
    int16_t l_198 = 0L;
    for (g_2 = (-1); (g_2 < 0); g_2 = safe_add_func_int16_t_s_s(g_2, 4))
    { /* block id: 3 */
        int8_t l_194 = (-2L);
        g_135[4][1] = (func_5(g_2) || 0xFD8273AD263BBA08LL);
        l_195--;
        if (g_66)
            continue;
        return l_198;
    }
    if (g_67)
    { /* block id: 133 */
        int32_t l_203[1];
        int32_t l_204 = 0xA18239A9L;
        int i;
        for (i = 0; i < 1; i++)
            l_203[i] = 8L;
        l_204 |= ((((safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_s(g_66, l_198)), 8)) < 0x41L) > 0xBD5EE618692B3080LL) , l_203[0]);
    }
    else
    { /* block id: 135 */
        for (g_114 = 0; (g_114 <= 0); g_114 += 1)
        { /* block id: 138 */
            int64_t l_207[8][4] = {{0x9D19914BD559E113LL,0x334A1C847789590ALL,0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL},{0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL,0x9D19914BD559E113LL,0x334A1C847789590ALL},{0x9D19914BD559E113LL,0x334A1C847789590ALL,0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL},{0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL,0x9D19914BD559E113LL,0x334A1C847789590ALL},{0x9D19914BD559E113LL,0x334A1C847789590ALL,0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL},{0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL,0x9D19914BD559E113LL,0x334A1C847789590ALL},{0x9D19914BD559E113LL,0x334A1C847789590ALL,0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL},{0x9D19914BD559E113LL,0xC6ABA3EDC0E5944CLL,0x9D19914BD559E113LL,0x334A1C847789590ALL}};
            int i, j;
            g_2 = ((((safe_sub_func_int64_t_s_s(l_207[0][0], 0x41AA105A60EC3E43LL)) >= 7L) , g_2) > g_52);
        }
    }
    return l_195;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_52 g_66 g_62 g_86 g_84 g_85 g_118 g_83 g_114 g_135 g_177 g_67
 * writes: g_13 g_52 g_62 g_67 g_82 g_83 g_86 g_100 g_114 g_118 g_135 g_177
 */
static const int64_t  func_5(uint32_t  p_6)
{ /* block id: 4 */
    uint8_t l_10 = 0x26L;
    int32_t l_18 = (-9L);
    int32_t l_185 = 0xCF36308BL;
    int32_t l_186 = (-9L);
    int32_t l_187[3][7][6] = {{{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL},{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL},{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL},{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL},{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL},{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL},{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL}},{{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL},{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL},{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL},{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL},{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL},{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL},{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL}},{{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL},{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL},{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL},{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL},{0x86BA87EFL,0x1EF3CA3EL,0x1841307EL,0x653626FDL,0x0290027BL,0x653626FDL},{0x86BA87EFL,0xA4600C22L,0x86BA87EFL,0x653626FDL,0xF4C53DE2L,0x47C9686BL},{0x86BA87EFL,0x82263856L,0x07395427L,0x653626FDL,0x0AC63A17L,0x2A2B83AEL}}};
    int i, j, k;
lbl_11:
    for (p_6 = 0; (p_6 != 40); p_6 = safe_add_func_int32_t_s_s(p_6, 2))
    { /* block id: 7 */
        uint64_t l_9 = 0x4800FA72C25FCC58LL;
        l_9 ^= (g_2 != p_6);
    }
    if (((0x3D783989L ^ g_2) == l_10))
    { /* block id: 10 */
        uint16_t l_12[8];
        int i;
        for (i = 0; i < 8; i++)
            l_12[i] = 3UL;
        if (g_2)
            goto lbl_11;
        for (p_6 = 0; (p_6 <= 7); p_6 += 1)
        { /* block id: 14 */
            int i;
            ++g_13[0][2][0];
            l_18 ^= (safe_sub_func_uint16_t_u_u(l_12[p_6], p_6));
        }
    }
    else
    { /* block id: 18 */
        const int32_t l_33 = 0x1E5DE2CAL;
        int32_t l_178 = 0xB990560AL;
        int8_t l_179 = 0L;
        int32_t l_180 = 0xCAD433C7L;
        int32_t l_188 = 1L;
        int32_t l_189[3];
        int i;
        for (i = 0; i < 3; i++)
            l_189[i] = 0xDE8190F3L;
        for (p_6 = 0; (p_6 <= 0); p_6 += 1)
        { /* block id: 21 */
            uint16_t l_32 = 0xF47FL;
            g_135[2][4] = (safe_mod_func_int32_t_s_s(func_21(((((safe_mul_func_uint8_t_u_u(((((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_s((p_6 >= p_6), p_6)), g_13[0][3][0])) || g_13[0][2][0]) <= g_2) || l_32), g_2)) , p_6) != p_6) == g_2), p_6, l_33, l_32), 4294967286UL));
        }
        for (g_83 = 0; (g_83 <= 0); g_83 += 1)
        { /* block id: 115 */
            uint32_t l_181 = 0x722C89E7L;
            int32_t l_184[10][2] = {{0xB3623E6BL,0x392A3779L},{0x392A3779L,0xB3623E6BL},{0x392A3779L,0x392A3779L},{0xB3623E6BL,0x392A3779L},{0x392A3779L,0xB3623E6BL},{0x392A3779L,0x392A3779L},{0xB3623E6BL,0x392A3779L},{0x392A3779L,0xB3623E6BL},{0x392A3779L,0x392A3779L},{0x4B7FDB35L,0xB3623E6BL}};
            uint16_t l_191 = 0x0D29L;
            int i, j;
            l_181++;
            l_178 = ((-7L) == g_52);
            ++l_191;
            g_135[1][3] = 0x730238BEL;
        }
        for (g_177 = 0; (g_177 <= 2); g_177 += 1)
        { /* block id: 123 */
            int i;
            l_189[g_177] = l_189[g_177];
        }
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13 g_52 g_66 g_62 g_86 g_84 g_85 g_118 g_83 g_114 g_135 g_177 g_67
 * writes: g_52 g_62 g_67 g_82 g_83 g_86 g_100 g_114 g_118 g_135 g_177
 */
static int32_t  func_21(const int16_t  p_22, const int64_t  p_23, const int64_t  p_24, uint16_t  p_25)
{ /* block id: 22 */
    uint32_t l_34 = 0xDF890BA5L;
    uint8_t l_35 = 0x99L;
    int32_t l_105 = 0x5644FE3DL;
    int32_t l_148[1];
    int32_t l_149[1];
    int32_t l_154 = 0xFA8D4CD4L;
    int32_t l_157[4][4];
    int32_t l_158[1][2][10] = {{{0x6633CC6EL,0x251B0083L,0x251B0083L,0x6633CC6EL,0x251B0083L,0x251B0083L,0x6633CC6EL,0x251B0083L,0x251B0083L,0x6633CC6EL},{0x251B0083L,0x6633CC6EL,0x251B0083L,0x251B0083L,0x6633CC6EL,0x251B0083L,0x251B0083L,0x6633CC6EL,0x251B0083L,0x251B0083L}}};
    uint16_t l_165[10] = {65526UL,65526UL,1UL,0xFDE9L,1UL,65526UL,65526UL,1UL,0xFDE9L,1UL};
    uint32_t l_166 = 0x51C66ACBL;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_148[i] = 1L;
    for (i = 0; i < 1; i++)
        l_149[i] = 8L;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 4; j++)
            l_157[i][j] = 8L;
    }
lbl_144:
    l_35 = (g_2 , l_34);
    for (l_34 = 18; (l_34 < 3); l_34 = safe_sub_func_int8_t_s_s(l_34, 4))
    { /* block id: 26 */
        const int32_t l_104 = 0L;
        int32_t l_116 = 0x389381DCL;
        int32_t l_117[4][7][5] = {{{1L,3L,4L,0x785E6FA9L,4L},{0x1FF20F69L,0x1FF20F69L,(-6L),0xD4078237L,(-7L)},{(-6L),0x62652390L,4L,0xD8DD5847L,0x1F69F932L},{0x1FF20F69L,0xB2277CB2L,(-4L),0xD4078237L,(-4L)},{1L,0x62652390L,9L,0x785E6FA9L,0x1F69F932L},{0xB2277CB2L,0x1FF20F69L,(-4L),7L,(-7L)},{1L,3L,4L,0x785E6FA9L,4L}},{{0x1FF20F69L,0x1FF20F69L,(-6L),0xD4078237L,(-7L)},{(-6L),0x62652390L,4L,0xD8DD5847L,0x1F69F932L},{0x1FF20F69L,0xB2277CB2L,(-4L),0xD4078237L,(-4L)},{1L,0x62652390L,9L,0x785E6FA9L,0x1F69F932L},{0xB2277CB2L,0x1FF20F69L,(-4L),7L,(-7L)},{1L,3L,4L,0x785E6FA9L,4L},{0x1FF20F69L,0x1FF20F69L,(-6L),0xD4078237L,(-7L)}},{{(-6L),0x62652390L,4L,0xD8DD5847L,0x1F69F932L},{0x1FF20F69L,0xB2277CB2L,(-4L),0xD4078237L,(-4L)},{1L,0x62652390L,9L,0x785E6FA9L,0x1F69F932L},{0xB2277CB2L,0x1FF20F69L,(-4L),7L,(-7L)},{1L,3L,4L,0x785E6FA9L,4L},{0x1FF20F69L,0x1FF20F69L,(-6L),0xD4078237L,(-7L)},{(-6L),0x62652390L,4L,0xD8DD5847L,0x1F69F932L}},{{0x1FF20F69L,0xB2277CB2L,(-4L),0xD4078237L,(-4L)},{1L,0x62652390L,9L,0x785E6FA9L,0x1F69F932L},{0xB2277CB2L,0x1FF20F69L,(-4L),7L,(-7L)},{1L,3L,4L,0x785E6FA9L,4L},{0x1FF20F69L,0x1FF20F69L,(-6L),0xD4078237L,(-7L)},{(-6L),0x62652390L,4L,0xD8DD5847L,0x1F69F932L},{0x1FF20F69L,0xB2277CB2L,(-4L),0xD4078237L,(-4L)}}};
        int8_t l_139[7][1] = {{0L},{0L},{0x29L},{0L},{0L},{0x29L},{0L}};
        int i, j, k;
        l_105 &= ((((safe_mod_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u((+((safe_mul_func_int8_t_s_s(func_45((l_35 | g_13[0][2][0]), p_25), p_24)) ^ g_84)), g_84)), 6L)) == l_104) , 0xB7L) <= (-10L));
        if ((safe_add_func_int32_t_s_s(0x6E4AE471L, l_35)))
        { /* block id: 78 */
            g_114 = (safe_div_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s(((safe_mul_func_int16_t_s_s(0x4BE6L, p_25)) & 9L), 6UL)) && g_85), p_25));
        }
        else
        { /* block id: 80 */
            int32_t l_115 = (-1L);
            int8_t l_123[7][2] = {{(-2L),0x6EL},{0L,0x9EL},{0x6EL,0x9EL},{0L,0x6EL},{(-2L),(-2L)},{(-2L),0L},{(-1L),(-2L)}};
            int i, j;
            l_105 |= l_115;
            g_118[0][0][0]++;
            l_105 &= (safe_add_func_int32_t_s_s(((l_123[4][1] & p_23) && (-1L)), p_23));
            return g_52;
        }
        if ((safe_mul_func_int16_t_s_s((((((safe_rshift_func_int16_t_s_s(l_116, 0)) , 1L) <= 0UL) < 1L) > p_25), g_2)))
        { /* block id: 86 */
            int32_t l_134 = 0x9AC8AADDL;
            l_105 = (!(safe_mod_func_int64_t_s_s((safe_lshift_func_int8_t_s_s((p_22 < g_118[0][0][0]), p_25)), 4L)));
            l_134 = (safe_unary_minus_func_int8_t_s((-8L)));
        }
        else
        { /* block id: 89 */
            uint64_t l_136 = 7UL;
            ++l_136;
            return g_83;
        }
        g_135[1][0] = l_139[5][0];
    }
    if (g_66)
    { /* block id: 95 */
        const uint32_t l_142 = 0UL;
        int32_t l_145 = (-9L);
        int32_t l_146 = 0x6FF316C3L;
        int32_t l_147 = (-1L);
        int32_t l_150 = (-1L);
        int32_t l_151 = 0x84F5D4ABL;
        int32_t l_152 = 0x73B92431L;
        int32_t l_153 = 0L;
        int32_t l_155[3][9] = {{1L,1L,0x0C3003DDL,1L,1L,0x0C3003DDL,1L,1L,0x0C3003DDL},{1L,1L,0x0C3003DDL,1L,1L,0x0C3003DDL,1L,1L,0x0C3003DDL},{1L,1L,0x0C3003DDL,1L,1L,0x0C3003DDL,1L,1L,0x0C3003DDL}};
        int64_t l_156 = 0x924758F72B244983LL;
        int16_t l_159 = 3L;
        int16_t l_160[5][5] = {{0xC8F3L,0xC8F3L,0xB38BL,(-1L),1L},{1L,0x6BD5L,0x6BD5L,1L,0xC8F3L},{1L,(-1L),0x4C03L,0x4C03L,(-1L)},{0xC8F3L,0x6BD5L,0x4C03L,0xB38BL,0xB38BL},{0x6BD5L,0xC8F3L,0x6BD5L,0x4C03L,0xB38BL}};
        uint32_t l_161[2][3];
        int i, j;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 3; j++)
                l_161[i][j] = 0x91195645L;
        }
        for (g_114 = 0; (g_114 == 42); g_114++)
        { /* block id: 98 */
            int16_t l_143 = 0x39DCL;
            if (l_142)
                break;
            l_143 ^= p_25;
            if (p_22)
                goto lbl_144;
        }
        ++l_161[1][1];
    }
    else
    { /* block id: 104 */
        int32_t l_164 = (-1L);
        l_164 = l_164;
        l_165[3] = g_62;
        --l_166;
        g_177 |= (((safe_mod_func_int8_t_s_s(((safe_add_func_int8_t_s_s(((((safe_mul_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s((((p_23 & p_25) >= g_66) < g_135[1][3]), g_118[3][0][2])) , l_164), p_23)) && l_148[0]) && l_164) != g_83), p_24)) ^ l_164), (-10L))) < g_135[4][3]) <= l_149[0]);
    }
    return g_67;
}


/* ------------------------------------------ */
/* 
 * reads : g_52 g_13 g_2 g_66 g_62 g_86
 * writes: g_52 g_62 g_67 g_82 g_83 g_86 g_100
 */
static const int8_t  func_45(int16_t  p_46, uint8_t  p_47)
{ /* block id: 27 */
    uint32_t l_48 = 0xE8B7203FL;
    int32_t l_60[1];
    int16_t l_99 = 0x1B04L;
    int i;
    for (i = 0; i < 1; i++)
        l_60[i] = 0xD571E957L;
    if (l_48)
    { /* block id: 28 */
        const int32_t l_51 = 0x5DBF6070L;
        for (l_48 = 13; (l_48 == 18); l_48 = safe_add_func_int32_t_s_s(l_48, 8))
        { /* block id: 31 */
            return l_51;
        }
    }
    else
    { /* block id: 34 */
        for (p_47 = 0; (p_47 <= 0); p_47 += 1)
        { /* block id: 37 */
            uint16_t l_55 = 65526UL;
            g_52++;
            if (g_52)
                break;
            if (l_55)
                break;
        }
    }
    for (p_47 = 0; (p_47 <= 0); p_47 += 1)
    { /* block id: 45 */
        uint32_t l_61 = 1UL;
        l_60[0] &= ((safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s(g_13[0][2][0], p_47)), l_48)) & g_2);
        if (p_47)
        { /* block id: 47 */
            l_61 = (p_46 <= 0L);
            g_62 = (-9L);
        }
        else
        { /* block id: 50 */
            uint8_t l_65[2];
            int i;
            for (i = 0; i < 2; i++)
                l_65[i] = 0x5BL;
            g_67 = ((((((safe_rshift_func_uint8_t_u_s(g_2, 3)) <= l_65[1]) ^ g_13[1][2][0]) == g_66) ^ g_2) < (-1L));
        }
        l_60[0] = (safe_mul_func_int8_t_s_s(func_70(p_47, l_61, p_46, g_52), l_60[0]));
        if (p_46)
            break;
        for (g_62 = 0; (g_62 <= 0); g_62 += 1)
        { /* block id: 64 */
            g_83 = p_46;
            return p_46;
        }
    }
    ++g_86;
    if ((safe_mul_func_int8_t_s_s((safe_mod_func_uint64_t_u_u((((safe_mul_func_uint16_t_u_u((safe_mod_func_uint64_t_u_u(18446744073709551613UL, g_52)), p_47)) , 0x9319L) | g_2), g_62)), p_46)))
    { /* block id: 70 */
        return l_60[0];
    }
    else
    { /* block id: 72 */
        int8_t l_103 = 0xD6L;
        g_100 = (safe_sub_func_uint32_t_u_u((0x7C819A8027267125LL < l_99), 0x3A5642BEL));
        l_60[0] &= (safe_lshift_func_int8_t_s_u(p_46, l_103));
    }
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_13
 * writes: g_82
 */
static int8_t  func_70(uint64_t  p_71, int8_t  p_72, int32_t  p_73, int8_t  p_74)
{ /* block id: 53 */
    int8_t l_77 = 0L;
    int32_t l_78 = 0x2837B75AL;
    l_77 = (safe_rshift_func_int16_t_s_u((0x8F68L & p_73), 6));
    if (p_73)
        goto lbl_79;
lbl_79:
    l_78 = g_2;
    p_73 = l_78;
    g_82[1][0] = (safe_mod_func_int64_t_s_s(1L, l_77));
    return g_13[0][2][0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_13[i][j][k], "g_13[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_52, "g_52", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_82[i][j], "g_82[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_114, "g_114", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_118[i][j][k], "g_118[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_135[i][j], "g_135[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_190, "g_190", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 81
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 88
   depth: 2, occurrence: 21
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
   depth: 6, occurrence: 3
   depth: 7, occurrence: 3
   depth: 11, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 116
XXX times a non-volatile is write: 52
XXX times a volatile is read: 15
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 122
XXX percentage of non-volatile access: 89.8

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 83
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 32
   depth: 2, occurrence: 30

XXX percentage a fresh-made variable is used: 22.9
XXX percentage an existing variable is used: 77.1
********************* end of statistics **********************/

