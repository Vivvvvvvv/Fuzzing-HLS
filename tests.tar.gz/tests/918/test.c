/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1838951661342503941
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_8 = 1UL;
static uint8_t g_9[3][8][8] = {{{1UL,0UL,0xBEL,246UL,9UL,0x9CL,0UL,255UL},{0UL,0UL,252UL,250UL,250UL,252UL,0UL,0UL},{0x39L,1UL,0xBEL,250UL,0x03L,9UL,1UL,255UL},{0x39L,0x8FL,0x9CL,246UL,250UL,9UL,0x8FL,1UL},{0UL,1UL,0x9CL,255UL,9UL,252UL,1UL,1UL},{1UL,0UL,0xBEL,246UL,9UL,0x9CL,0x8FL,248UL},{255UL,0x8FL,0xBEL,255UL,255UL,0xBEL,0x8FL,255UL},{1UL,3UL,0UL,255UL,250UL,0x9CL,3UL,248UL}},{{1UL,1UL,252UL,9UL,255UL,0x9CL,1UL,0UL},{255UL,3UL,252UL,246UL,0x03L,0xBEL,3UL,0UL},{0UL,0x8FL,0UL,9UL,0x03L,252UL,0x8FL,248UL},{255UL,0x8FL,0xBEL,255UL,255UL,0xBEL,0x8FL,255UL},{1UL,3UL,0UL,255UL,250UL,0x9CL,3UL,248UL},{1UL,1UL,252UL,9UL,255UL,0x9CL,1UL,0UL},{255UL,3UL,252UL,246UL,0x03L,0xBEL,3UL,0UL},{0UL,0x8FL,0UL,9UL,0x03L,252UL,0x8FL,248UL}},{{255UL,0x8FL,0xBEL,255UL,255UL,0xBEL,0x8FL,255UL},{1UL,3UL,0UL,255UL,250UL,0x9CL,3UL,248UL},{1UL,1UL,252UL,9UL,255UL,0x9CL,1UL,0UL},{255UL,3UL,252UL,246UL,0x03L,0xBEL,3UL,0UL},{0UL,0x8FL,0UL,9UL,0x03L,252UL,0x8FL,248UL},{255UL,0x8FL,0xBEL,255UL,255UL,0xBEL,0x8FL,255UL},{1UL,3UL,0UL,255UL,250UL,0x9CL,3UL,248UL},{1UL,1UL,252UL,9UL,255UL,0x9CL,1UL,0UL}}};
static uint32_t g_16 = 0x2B9CBADBL;
static int32_t g_25 = 0L;
static volatile uint8_t g_50 = 3UL;/* VOLATILE GLOBAL g_50 */
static uint8_t g_74[9][2] = {{0xA8L,0xF4L},{0x73L,0UL},{0x73L,0xF4L},{0xA8L,0xA8L},{0xF4L,0x73L},{0UL,0x73L},{0xF4L,0xA8L},{0xA8L,0xF4L},{0x73L,0UL}};
static volatile uint8_t g_77 = 253UL;/* VOLATILE GLOBAL g_77 */
static uint32_t g_93 = 0xFE41880DL;
static uint64_t g_143 = 0x4E5EF4969E89804BLL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint16_t  func_2(uint32_t  p_3);
static int32_t  func_10(uint8_t  p_11, int32_t  p_12);
static int16_t  func_37(uint32_t  p_38, const int64_t  p_39);
static int32_t  func_53(uint8_t  p_54, uint64_t  p_55, uint8_t  p_56, int8_t  p_57, int16_t  p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_9 g_16 g_25 g_50 g_74 g_77 g_93 g_143
 * writes: g_8 g_16 g_25 g_50 g_74 g_77 g_93 g_143
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int64_t l_6 = 0x086BD085C9E53E58LL;
    uint16_t l_7 = 0UL;
    g_143 ^= ((((func_2((((safe_mul_func_uint8_t_u_u(l_6, l_7)) || 4UL) == g_8)) > g_9[1][1][5]) >= g_9[2][5][2]) > 0x21655C08L) < l_7);
    return g_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_9 g_16 g_25 g_50 g_74 g_77 g_93
 * writes: g_8 g_16 g_25 g_50 g_74 g_77 g_93
 */
static uint16_t  func_2(uint32_t  p_3)
{ /* block id: 1 */
    int8_t l_22 = 6L;
    int32_t l_24 = 0x93CE85DCL;
    uint8_t l_119[8][9][3] = {{{0x01L,0xBCL,6UL},{1UL,0UL,1UL},{0x23L,0x6DL,248UL},{0x41L,1UL,2UL},{0UL,6UL,0x98L},{0x8BL,0x98L,246UL},{0x3EL,0x2EL,3UL},{0x3EL,0x45L,0UL},{0x8BL,255UL,1UL}},{{1UL,0UL,0UL},{0x5CL,2UL,255UL},{6UL,0x6AL,1UL},{0x6AL,3UL,0x2EL},{0UL,0xBCL,0x23L},{0x23L,3UL,0x98L},{0x5CL,0x6AL,0x0AL},{0x48L,2UL,0xBCL},{248UL,0UL,6UL}},{{0x0CL,0x11L,0x45L},{0x15L,255UL,246UL},{1UL,0x0AL,246UL},{255UL,0x48L,0x45L},{2UL,1UL,6UL},{0xBCL,0x98L,0xBCL},{0x6DL,0xDBL,0x0AL},{246UL,1UL,0x98L},{0x64L,0x5CL,0x23L}},{{0x11L,250UL,0x2EL},{0x64L,255UL,1UL},{246UL,0x3EL,255UL},{0x6DL,248UL,0UL},{0xBCL,255UL,1UL},{2UL,1UL,1UL},{255UL,0x45L,0xB2L},{1UL,0x45L,0x6DL},{0x15L,1UL,0x48L}},{{0x0CL,255UL,0xAEL},{248UL,248UL,0x15L},{0x48L,0x3EL,248UL},{0x5CL,255UL,1UL},{0x23L,250UL,0xDBL},{0UL,0x5CL,1UL},{0x6AL,1UL,248UL},{6UL,0xDBL,0x15L},{0x5CL,0x98L,0xAEL}},{{1UL,1UL,0x48L},{0x84L,0x48L,0x6DL},{0xB2L,0x0AL,0xB2L},{0xB2L,255UL,1UL},{0x84L,0x11L,1UL},{1UL,0UL,0UL},{0x5CL,2UL,255UL},{6UL,0x6AL,1UL},{0x6AL,3UL,0x2EL}},{{0UL,0xBCL,0x23L},{0x23L,3UL,0x98L},{0x5CL,0x6AL,0x0AL},{0x48L,2UL,0xBCL},{248UL,0UL,6UL},{0x0CL,0x11L,0x45L},{0x15L,255UL,246UL},{1UL,0x0AL,246UL},{255UL,0x48L,0x45L}},{{2UL,1UL,6UL},{0xBCL,0x98L,0xBCL},{0x6DL,0xDBL,0x0AL},{246UL,1UL,0x98L},{0x64L,0x5CL,0x23L},{0x11L,250UL,0x2EL},{0x64L,255UL,1UL},{246UL,0x3EL,255UL},{0x6DL,248UL,0UL}}};
    int i, j, k;
    for (g_8 = 0; (g_8 <= 2); g_8 += 1)
    { /* block id: 4 */
        uint64_t l_21 = 0x24D8F3B1AD31FC53LL;
        if (func_10(g_8, g_9[1][3][2]))
        { /* block id: 8 */
            l_22 = (safe_lshift_func_uint16_t_u_u((((safe_rshift_func_int16_t_s_s(g_16, 13)) <= 0L) , l_21), p_3));
        }
        else
        { /* block id: 10 */
            const int32_t l_23 = 0x2E7C525AL;
            l_24 = l_23;
            if (l_21)
                continue;
            g_25 = l_24;
        }
        return p_3;
    }
    l_24 &= (safe_div_func_int8_t_s_s(((1L >= p_3) >= l_22), g_16));
lbl_32:
    g_25 = (((safe_mul_func_int16_t_s_s(l_22, 0xB341L)) < 18446744073709551615UL) , 1L);
    if ((func_10(g_9[1][5][1], p_3) , g_9[0][3][5]))
    { /* block id: 19 */
        int64_t l_30 = (-1L);
        l_30 = (g_8 || 1L);
    }
    else
    { /* block id: 21 */
        int16_t l_31 = 0x679FL;
        int32_t l_142 = 0x7EC82828L;
        for (l_24 = 2; (l_24 >= 0); l_24 -= 1)
        { /* block id: 24 */
            l_31 = g_8;
            if (l_24)
                goto lbl_32;
        }
        if ((safe_lshift_func_uint16_t_u_s((safe_mod_func_int16_t_s_s((func_37(((func_10(l_22, p_3) < l_22) != p_3), p_3) == p_3), l_119[5][1][2])), l_31)))
        { /* block id: 81 */
            uint8_t l_122 = 0UL;
            g_25 = g_50;
            if (l_24)
                goto lbl_123;
lbl_123:
            g_25 = (((((safe_add_func_uint64_t_u_u((((-6L) & 0L) < l_122), 0x9388203293BDCD76LL)) , g_50) == 0L) > p_3) | 0xD51499A7L);
            g_25 = (safe_sub_func_int8_t_s_s((((safe_mod_func_uint64_t_u_u((safe_div_func_int8_t_s_s(((safe_add_func_uint64_t_u_u(((+(safe_mod_func_uint8_t_u_u(g_8, g_16))) & p_3), 0xADBE4ED98820683FLL)) < l_22), l_119[6][4][0])), p_3)) < g_25) == l_31), l_31));
        }
        else
        { /* block id: 86 */
            uint64_t l_135[7] = {1UL,1UL,0UL,0UL,1UL,0UL,0UL};
            int i;
            --l_135[6];
            return g_50;
        }
        for (g_25 = 0; (g_25 >= 27); g_25 = safe_add_func_int32_t_s_s(g_25, 7))
        { /* block id: 92 */
            l_142 &= (((safe_lshift_func_int16_t_s_s(((p_3 < g_93) , 0xCE0AL), 14)) | 0xCCFC83ECL) == p_3);
            return p_3;
        }
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_16
 * writes: g_16
 */
static int32_t  func_10(uint8_t  p_11, int32_t  p_12)
{ /* block id: 5 */
    uint32_t l_15 = 0UL;
    g_16 |= (((safe_add_func_uint8_t_u_u((0xF908L > 6UL), l_15)) ^ g_9[2][1][7]) != p_12);
    return l_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_25 g_16 g_50 g_74 g_77 g_93 g_8
 * writes: g_16 g_50 g_25 g_74 g_77 g_93
 */
static int16_t  func_37(uint32_t  p_38, const int64_t  p_39)
{ /* block id: 28 */
    uint32_t l_40 = 4294967295UL;
    int32_t l_42 = (-1L);
    uint16_t l_45 = 65535UL;
    int32_t l_91[10][8][3] = {{{0x5FE406C9L,0xB0400E0BL,1L},{0xE47C4C41L,0x50E26406L,0xF5847AAFL},{0x16697889L,(-1L),(-8L)},{0x5E71FFC7L,(-1L),0x47B8CDD7L},{(-8L),0xBE49ECA5L,0xA6927BAFL},{(-6L),2L,1L},{0x2C8C0895L,1L,0xA6927BAFL},{1L,0xE47C4C41L,0x47B8CDD7L}},{{0L,4L,(-8L)},{0L,0x156936D6L,0xF5847AAFL},{1L,0xF4FB9E1BL,1L},{0x79B9B320L,(-7L),0x51B6DC08L},{1L,(-1L),0xC8DCDBDFL},{0xC4CDA38EL,0L,(-1L)},{(-8L),0x601C06A4L,0xC34014C2L},{0xC4CDA38EL,0x17292063L,1L}},{{1L,0x390277B5L,(-1L)},{0x79B9B320L,0xE47C4C41L,0x50E26406L},{1L,0x431FA81EL,0x66805FA1L},{0L,(-7L),0x381BEE42L},{0L,1L,1L},{1L,0x47B8CDD7L,0x11996AC1L},{0x2C8C0895L,(-1L),(-1L)},{(-6L),0x47B8CDD7L,(-7L)}},{{(-8L),1L,0x2127F58FL},{0x5E71FFC7L,(-7L),1L},{0x16697889L,0x431FA81EL,1L},{0xE47C4C41L,0xE47C4C41L,0L},{0x5FE406C9L,0x390277B5L,(-1L)},{0L,0x17292063L,0xBCDE28A8L},{(-1L),0x601C06A4L,1L},{0x1DEC27F6L,0L,0xBCDE28A8L}},{{0x6E869CBCL,(-1L),(-1L)},{(-1L),(-7L),0L},{(-8L),0xF4FB9E1BL,1L},{1L,0x156936D6L,1L},{(-1L),4L,0x2127F58FL},{(-3L),0xE47C4C41L,(-7L)},{1L,1L,(-1L)},{0L,2L,0x11996AC1L}},{{1L,0xBE49ECA5L,1L},{(-3L),(-1L),0x381BEE42L},{(-1L),(-1L),0x66805FA1L},{1L,0x50E26406L,0x50E26406L},{(-8L),0xB0400E0BL,(-1L)},{(-1L),(-1L),1L},{0x6E869CBCL,(-8L),0xC34014C2L},{0x1DEC27F6L,0xE47C4C41L,(-1L)}},{{(-1L),(-8L),0xC8DCDBDFL},{0L,(-1L),0x51B6DC08L},{0x5FE406C9L,0xB0400E0BL,1L},{0xE47C4C41L,0x50E26406L,0xF5847AAFL},{0x16697889L,(-1L),(-8L)},{0x5E71FFC7L,(-1L),0x47B8CDD7L},{(-8L),0xBE49ECA5L,0xA6927BAFL},{(-6L),2L,1L}},{{0x2C8C0895L,1L,0xA6927BAFL},{1L,0xE47C4C41L,0x47B8CDD7L},{0L,4L,(-8L)},{0L,0x156936D6L,0xF5847AAFL},{1L,0xF4FB9E1BL,1L},{0x79B9B320L,(-7L),2L},{0x66805FA1L,1L,0x5FE406C9L},{0xF5847AAFL,(-6L),(-1L)}},{{(-1L),1L,0x10DF2DACL},{0xF5847AAFL,1L,0x11996AC1L},{0x66805FA1L,0x19F28622L,0xC46DEB76L},{(-7L),0L,1L},{0xC34014C2L,(-5L),1L},{(-6L),0x79B9B320L,0x17292063L},{0xA6927BAFL,0x5B974B4EL,0xC34014C2L},{(-1L),0xC4CDA38EL,(-7L)}},{{(-1L),1L,0L},{0x381BEE42L,0xC4CDA38EL,0x5E71FFC7L},{(-1L),0x5B974B4EL,0L},{0x51B6DC08L,0x79B9B320L,0x11996AC1L},{(-8L),(-5L),1L},{0L,0L,(-6L)},{0x2127F58FL,0x19F28622L,1L},{(-6L),1L,(-1L)}}};
    int32_t l_92[1][9][2];
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 2; k++)
                l_92[i][j][k] = (-3L);
        }
    }
    if ((g_9[1][1][1] != p_39))
    { /* block id: 29 */
        uint32_t l_41 = 7UL;
        int32_t l_46[1][9][6] = {{{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL},{1L,1L,0x339AA88DL,1L,1L,0x339AA88DL}}};
        int i, j, k;
        l_42 ^= (((((g_25 , g_16) >= l_40) & l_41) < l_41) , l_41);
        if (((safe_sub_func_uint8_t_u_u(func_10(((g_16 || 1L) | l_41), g_16), 0x25L)) | l_45))
        { /* block id: 31 */
            int64_t l_48 = (-1L);
            l_46[0][8][4] = l_42;
            l_42 &= ((+func_10(g_16, l_48)) <= 0x6063AEBCL);
            l_42 = l_48;
            l_42 = 0x5C15DC1CL;
        }
        else
        { /* block id: 36 */
            int32_t l_49 = 0x07C152A3L;
            --g_50;
            l_46[0][0][2] = func_53((safe_lshift_func_uint8_t_u_s((g_25 | 0xB22FL), 4)), l_46[0][8][4], l_42, p_39, l_49);
        }
        g_25 |= ((((p_39 ^ 65534UL) == l_40) , 1UL) <= 0x8955L);
    }
    else
    { /* block id: 43 */
        uint32_t l_72 = 18446744073709551606UL;
        int32_t l_73 = 8L;
        l_42 ^= p_38;
        if ((safe_add_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((((safe_lshift_func_int16_t_s_u((((safe_mod_func_int8_t_s_s((safe_mod_func_uint8_t_u_u(0x0EL, 1L)), p_38)) == l_40) != 18446744073709551609UL), 12)) & (-1L)) & 0UL), 0x97FD74DCC0C03A2CLL)), p_39)))
        { /* block id: 45 */
            l_42 = ((((0xCED7161A1E5F5605LL < 0L) ^ l_72) && (-1L)) & g_9[1][2][2]);
            return g_9[1][0][7];
        }
        else
        { /* block id: 48 */
            uint16_t l_82 = 0x7FDBL;
            ++g_74[8][1];
            ++g_77;
            l_82 = (safe_div_func_uint32_t_u_u(g_77, p_39));
        }
        l_42 = (l_73 < l_42);
        if ((!(-9L)))
        { /* block id: 54 */
            int16_t l_85 = (-9L);
            l_73 = (~(l_85 | l_73));
            return g_16;
        }
        else
        { /* block id: 57 */
            uint8_t l_90[10] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
            int i;
            l_42 = ((safe_mul_func_int8_t_s_s(((safe_mod_func_int32_t_s_s((0xB1E0FC07259F99B6LL == l_90[2]), 0xC8AA1209L)) == 3UL), l_73)) ^ p_38);
        }
    }
    ++g_93;
lbl_109:
    g_25 = (safe_sub_func_int64_t_s_s(l_92[0][8][1], g_74[8][0]));
    if ((safe_mul_func_uint16_t_u_u(l_91[7][0][1], l_92[0][3][0])))
    { /* block id: 63 */
        uint64_t l_100 = 1UL;
        int32_t l_107 = 1L;
        uint32_t l_108 = 0xD3DCD3D2L;
        g_25 = (l_100 , p_38);
        g_25 = (safe_div_func_int32_t_s_s((safe_div_func_int64_t_s_s((((((safe_lshift_func_int8_t_s_s(((l_40 < l_107) <= l_45), g_74[8][1])) | l_42) , p_38) , l_42) | g_77), g_16)), p_38));
        l_91[9][5][2] = ((((p_39 >= l_108) < 1L) ^ l_108) && l_92[0][6][1]);
        if (p_38)
            goto lbl_109;
    }
    else
    { /* block id: 68 */
        uint8_t l_115[2][9][3] = {{{255UL,1UL,0xAAL},{1UL,254UL,254UL},{246UL,255UL,0xAAL},{0xFBL,1UL,255UL},{0xFBL,0x66L,1UL},{246UL,1UL,246UL},{1UL,0x66L,0xFBL},{255UL,1UL,0xFBL},{0xAAL,255UL,246UL}},{{254UL,254UL,1UL},{0xAAL,1UL,255UL},{255UL,1UL,0xAAL},{1UL,254UL,254UL},{246UL,255UL,0xAAL},{0xFBL,1UL,255UL},{0xFBL,0x66L,1UL},{246UL,1UL,246UL},{1UL,0x66L,0xFBL}}};
        int32_t l_118 = 0x123D7B41L;
        int i, j, k;
        for (l_42 = 0; (l_42 <= 2); l_42 += 1)
        { /* block id: 71 */
            int16_t l_114 = 5L;
            l_91[7][4][1] = (safe_sub_func_int64_t_s_s((safe_lshift_func_int16_t_s_u(l_114, 4)), p_39));
            if (l_114)
                break;
            if (g_8)
                break;
        }
        g_25 = ((((g_74[8][1] >= l_92[0][3][1]) > (-10L)) | l_91[7][4][1]) <= l_91[9][1][1]);
        l_115[0][5][1] ^= 0xE75A53A4L;
        l_118 = (safe_add_func_uint32_t_u_u(((g_9[1][6][7] && 247UL) != p_39), 4294967289UL));
    }
    return g_8;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_53(uint8_t  p_54, uint64_t  p_55, uint8_t  p_56, int8_t  p_57, int16_t  p_58)
{ /* block id: 38 */
    int8_t l_61 = 0L;
    return l_61;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_9[i][j][k], "g_9[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_74[i][j], "g_74[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_93, "g_93", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 42
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 70
   depth: 2, occurrence: 12
   depth: 3, occurrence: 2
   depth: 4, occurrence: 5
   depth: 5, occurrence: 6
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 4

XXX total number of pointers: 0

XXX times a non-volatile is read: 126
XXX times a non-volatile is write: 41
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 36
XXX percentage of non-volatile access: 95.4

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 67
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 21
   depth: 2, occurrence: 31

XXX percentage a fresh-made variable is used: 23
XXX percentage an existing variable is used: 77
********************* end of statistics **********************/

