/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18052458698422783829
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_3[5][10][5] = {{{247UL,9UL,0x23L,1UL,0xC2L},{254UL,0x26L,255UL,0x24L,0UL},{0x5CL,9UL,7UL,7UL,9UL},{1UL,0x72L,0UL,7UL,0xC0L},{252UL,0xC0L,9UL,0x24L,0x26L},{0UL,0x0DL,255UL,1UL,254UL},{252UL,1UL,1UL,0x07L,250UL},{1UL,3UL,1UL,255UL,0x72L},{0x5CL,250UL,255UL,0UL,0x72L},{254UL,0x3AL,3UL,0x0DL,0UL}},{{0x8EL,0x5DL,0x72L,250UL,0x3AL},{0x25L,0x5DL,254UL,246UL,0xADL},{252UL,0x3AL,0x72L,250UL,0UL},{0x7DL,0x3BL,0UL,246UL,0x35L},{0x7CL,248UL,0xC2L,250UL,0x0FL},{0x7CL,253UL,250UL,0x0DL,0xBBL},{0x7DL,1UL,1UL,0x72L,0x38L},{252UL,0x35L,250UL,0x25L,0x71L},{0x25L,0UL,0xC2L,0xBFL,0x71L},{0x8EL,0x0FL,0UL,255UL,0x38L}},{{1UL,0UL,0x72L,0UL,0xBBL},{0x33L,0x0FL,254UL,254UL,0x0FL},{0UL,0UL,0x72L,254UL,0x35L},{250UL,0x35L,3UL,0UL,0UL},{0xC8L,1UL,0x25L,255UL,0xADL},{250UL,253UL,250UL,0xBFL,0x3AL},{0UL,248UL,250UL,0x25L,0UL},{0x33L,0x3BL,0x25L,0x72L,1UL},{1UL,0x3AL,3UL,0x0DL,0UL},{0x8EL,0x5DL,0x72L,250UL,0x3AL}},{{0x25L,0x5DL,254UL,246UL,0xADL},{252UL,0x3AL,0x72L,250UL,0UL},{0x7DL,0x3BL,0UL,246UL,0x35L},{0x7CL,248UL,0xC2L,250UL,0x0FL},{0x7CL,253UL,250UL,0x0DL,0xBBL},{0x7DL,1UL,1UL,0x72L,0x38L},{252UL,0x35L,250UL,0x25L,0x71L},{0x25L,0UL,0xC2L,0xBFL,0x71L},{0x8EL,0x0FL,0UL,255UL,0x38L},{1UL,0UL,0x72L,0UL,0xBBL}},{{0x33L,0x0FL,254UL,254UL,0x0FL},{0UL,0UL,0x72L,254UL,0x35L},{250UL,0x35L,3UL,0UL,0UL},{0xC8L,1UL,0x25L,255UL,0xADL},{250UL,253UL,250UL,0xBFL,0x3AL},{0UL,248UL,250UL,0x25L,0UL},{0x33L,0x3BL,0x25L,0x72L,1UL},{1UL,0x3AL,248UL,1UL,255UL},{0UL,254UL,0UL,0x3BL,249UL},{0x79L,254UL,0xADL,0x71L,1UL}}};
static uint32_t g_4 = 18446744073709551615UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2[5][7] = {{0x7AF5AF8B5131D8B9LL,0x7AF5AF8B5131D8B9LL,0xE52D8CB4C23AFC37LL,0xE52D8CB4C23AFC37LL,0x7AF5AF8B5131D8B9LL,0x7AF5AF8B5131D8B9LL,0xE52D8CB4C23AFC37LL},{1UL,7UL,1UL,7UL,1UL,7UL,1UL},{0x7AF5AF8B5131D8B9LL,0xE52D8CB4C23AFC37LL,0xE52D8CB4C23AFC37LL,0x7AF5AF8B5131D8B9LL,0x7AF5AF8B5131D8B9LL,0xE52D8CB4C23AFC37LL,0xE52D8CB4C23AFC37LL},{1UL,7UL,1UL,7UL,1UL,7UL,1UL},{0x7AF5AF8B5131D8B9LL,0x7AF5AF8B5131D8B9LL,0xE52D8CB4C23AFC37LL,0xE52D8CB4C23AFC37LL,0x7AF5AF8B5131D8B9LL,0x7AF5AF8B5131D8B9LL,0xE52D8CB4C23AFC37LL}};
    volatile int32_t l_5 = 0x705BE734L;/* VOLATILE GLOBAL l_5 */
    int i, j;
    g_4 = ((0x730F94F37831E42ALL || l_2[4][4]) < g_3[1][5][1]);
    l_5 = g_3[2][1][0];
    return g_3[1][5][1];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_3[i][j][k], "g_3[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 4
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 3
breakdown:
   depth: 1, occurrence: 4
   depth: 3, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 1
XXX times a non-volatile is write: 1
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 33.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 3
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 3

XXX percentage a fresh-made variable is used: 66.7
XXX percentage an existing variable is used: 33.3
********************* end of statistics **********************/

