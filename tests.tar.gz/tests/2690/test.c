/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10250852916463645258
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_14 = 0xD658L;/* VOLATILE GLOBAL g_14 */
static int64_t g_15 = 0xF13E13A6C9CD49FCLL;
static int64_t g_25 = 1L;
static uint32_t g_26 = 0xA41B8700L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_6(uint32_t  p_7, int64_t  p_8, int64_t  p_9, const int16_t  p_10);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_15 g_25 g_26
 * writes: g_26
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_13 = 1UL;
    int32_t l_22[5];
    int32_t l_31 = (-3L);
    int i;
    for (i = 0; i < 5; i++)
        l_22[i] = 0L;
    l_22[2] = ((safe_rshift_func_int16_t_s_u((safe_mul_func_uint16_t_u_u(func_6(((safe_mod_func_uint8_t_u_u(((((l_13 & 0x247ADF1ADB2BC40ELL) & g_14) & 0xE012D2C8L) | l_13), g_15)) >= g_15), l_13, l_13, l_13), 0xF842L)), 5)) ^ 0x61E70716L);
    if ((safe_mod_func_int16_t_s_s((l_22[2] , (-1L)), g_15)))
    { /* block id: 5 */
        g_26 = (0UL >= g_25);
    }
    else
    { /* block id: 7 */
        int32_t l_32 = (-1L);
        l_22[0] = (func_6((((safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_s(l_13, g_14)), 6UL)) , g_25) , l_31), l_32, g_26, l_13) != g_25);
    }
    return l_22[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_15
 * writes:
 */
static uint16_t  func_6(uint32_t  p_7, int64_t  p_8, int64_t  p_9, const int16_t  p_10)
{ /* block id: 1 */
    uint8_t l_20 = 1UL;
    int32_t l_21 = 0x7A81A82EL;
    l_21 ^= (safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(g_14, l_20)), g_15));
    return l_20;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 6
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 10, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 4
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 89.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 35.7
XXX percentage an existing variable is used: 64.3
********************* end of statistics **********************/

