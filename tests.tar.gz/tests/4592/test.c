/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17520428319936074172
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xB02971C1L;/* VOLATILE GLOBAL g_2 */
static int32_t g_4 = 0xD080C170L;
static volatile int64_t g_5 = 0x78F3C34EEA2A3B3FLL;/* VOLATILE GLOBAL g_5 */
static int8_t g_6[2] = {0xD4L,0xD4L};
static uint64_t g_8 = 1UL;
static int64_t g_40 = (-6L);
static volatile int32_t g_42[4] = {(-4L),(-4L),(-4L),(-4L)};
static int8_t g_52 = 0L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint16_t  func_11(uint8_t  p_12, int32_t  p_13, int32_t  p_14, int32_t  p_15);
static int64_t  func_18(uint32_t  p_19, int32_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_8 g_6 g_4 g_5 g_52
 * writes: g_8 g_4 g_52
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_3 = 0x84L;
    int32_t l_7 = 8L;
    l_3 = (g_2 < (-1L));
    ++g_8;
    g_52 &= (func_11((safe_div_func_int64_t_s_s(func_18(g_8, g_2), 1UL)), g_6[1], g_6[0], g_6[0]) || l_7);
    return l_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_4 g_2 g_5 g_6
 * writes: g_8 g_4
 */
static uint16_t  func_11(uint8_t  p_12, int32_t  p_13, int32_t  p_14, int32_t  p_15)
{ /* block id: 10 */
    uint16_t l_32[3];
    int32_t l_37 = (-5L);
    int32_t l_41[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
    int32_t l_43 = 0x1FA7BB34L;
    int64_t l_44 = 0x3B8FBA323A35E06CLL;
    uint64_t l_45[6] = {0UL,0UL,0UL,0UL,0UL,0UL};
    int32_t l_51[7] = {0x0AA4AECAL,0x0AA4AECAL,0x0AA4AECAL,0x0AA4AECAL,0x0AA4AECAL,0x0AA4AECAL,0x0AA4AECAL};
    int i;
    for (i = 0; i < 3; i++)
        l_32[i] = 0x5D73L;
    for (g_8 = 0; (g_8 > 21); g_8 = safe_add_func_int32_t_s_s(g_8, 7))
    { /* block id: 13 */
        uint32_t l_28 = 18446744073709551615UL;
        for (g_4 = 0; (g_4 > (-23)); g_4 = safe_sub_func_uint32_t_u_u(g_4, 3))
        { /* block id: 16 */
            l_28++;
            l_32[1] = ((safe_unary_minus_func_uint16_t_u(65535UL)) != g_2);
            l_37 = (safe_div_func_uint32_t_u_u((((safe_sub_func_uint8_t_u_u(0x61L, p_14)) > 0xDCEEL) ^ g_5), g_6[0]));
            l_37 = (safe_lshift_func_int16_t_s_s(((((g_6[0] || g_6[1]) | 65527UL) < p_13) ^ g_8), g_5));
        }
        if (p_14)
            break;
        if (l_32[1])
            break;
    }
    l_45[0]--;
    p_13 ^= (!(((safe_sub_func_uint16_t_u_u(l_51[5], 0L)) >= l_44) <= l_32[1]));
    l_41[2] ^= g_6[0];
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_6
 * writes: g_8
 */
static int64_t  func_18(uint32_t  p_19, int32_t  p_20)
{ /* block id: 3 */
    uint32_t l_23[10] = {7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL};
    int i;
    for (g_8 = 0; (g_8 <= 38); g_8 = safe_add_func_int8_t_s_s(g_8, 2))
    { /* block id: 6 */
        return g_6[0];
    }
    return l_23[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_42[i], "g_42[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 19
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 5
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 13
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 48
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 19
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 16.2
XXX percentage an existing variable is used: 83.8
********************* end of statistics **********************/

