/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6631906048153806308
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3 = 0xF30CC2FDL;
static uint64_t g_29 = 18446744073709551610UL;
static uint32_t g_30 = 0x20725FC1L;
static int32_t g_33 = 0x8325423BL;
static int16_t g_35 = 0xA376L;
static int64_t g_43 = 0x7E7E5FF1FC5BFF90LL;
static uint32_t g_51 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static int64_t  func_5(uint8_t  p_6, uint8_t  p_7, uint16_t  p_8, uint32_t  p_9);
static uint8_t  func_10(const int32_t  p_11, uint16_t  p_12, int64_t  p_13, uint32_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_30 g_35 g_33 g_43
 * writes: g_3 g_29 g_30 g_33 g_35 g_51
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2 = 0L;
    int32_t l_4[3];
    uint32_t l_15 = 0xF72B5725L;
    int i;
    for (i = 0; i < 3; i++)
        l_4[i] = 0x9D5FAC12L;
    l_4[2] = ((((((0xE7L | l_2) , 1L) >= 0x822E6E7F737A9A97LL) == l_2) <= g_3) == 0L);
    l_4[2] = (func_5(func_10(g_3, g_3, l_15, l_4[2]), l_15, g_43, g_43) & g_43);
    l_4[1] = (safe_sub_func_int64_t_s_s((((+(l_4[2] == l_15)) || l_2) > (-2L)), (-9L)));
    return g_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_33 g_29 g_35
 * writes: g_51
 */
static int64_t  func_5(uint8_t  p_6, uint8_t  p_7, uint16_t  p_8, uint32_t  p_9)
{ /* block id: 27 */
    int32_t l_44 = 7L;
    uint16_t l_54 = 6UL;
    l_44 ^= (p_8 > 0L);
    g_51 = (safe_add_func_uint64_t_u_u(((safe_add_func_uint16_t_u_u(((((safe_add_func_uint8_t_u_u(g_33, l_44)) || l_44) & 0x7815L) , 0xE432L), 0x72DAL)) < g_33), l_44));
    l_44 |= (((safe_sub_func_int16_t_s_s((g_33 >= g_29), p_8)) , g_35) || 0x4440L);
    return l_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_29 g_30 g_35 g_33
 * writes: g_3 g_29 g_30 g_33 g_35
 */
static uint8_t  func_10(const int32_t  p_11, uint16_t  p_12, int64_t  p_13, uint32_t  p_14)
{ /* block id: 2 */
    uint8_t l_18[8];
    int32_t l_19 = 0x7C8B166CL;
    int16_t l_42 = 0x1418L;
    int i;
    for (i = 0; i < 8; i++)
        l_18[i] = 7UL;
    for (g_3 = 4; (g_3 >= 48); ++g_3)
    { /* block id: 5 */
        uint8_t l_20 = 5UL;
        if (l_18[6])
            break;
        ++l_20;
        l_19 = ((safe_rshift_func_uint16_t_u_s((((safe_div_func_uint32_t_u_u((l_20 & l_18[6]), l_20)) , l_19) >= 1UL), 15)) , l_20);
    }
    for (p_13 = 3; (p_13 == (-27)); p_13--)
    { /* block id: 12 */
        uint8_t l_38 = 0UL;
        g_29 |= g_3;
        g_30 ^= 8L;
        if ((((safe_mod_func_uint64_t_u_u(((g_30 | 0UL) , p_12), g_30)) ^ g_29) > 248UL))
        { /* block id: 15 */
            uint32_t l_34 = 0x59A7032FL;
            int32_t l_36 = 0x213633E7L;
            g_33 = l_18[6];
            g_35 ^= (l_34 , 0xDF7DC239L);
            l_36 &= ((p_14 >= 1UL) | 4294967295UL);
            l_38 = (((+g_30) & g_33) , 1L);
        }
        else
        { /* block id: 20 */
            uint64_t l_39 = 0xA7FAD540778D402ALL;
            if (g_35)
                break;
            l_39 = p_13;
            l_19 |= (safe_div_func_int32_t_s_s(0x972CE3C4L, l_39));
        }
    }
    return l_42;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 26
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 48
XXX times a non-volatile is write: 18
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 24
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 6
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 31.7
XXX percentage an existing variable is used: 68.3
********************* end of statistics **********************/

