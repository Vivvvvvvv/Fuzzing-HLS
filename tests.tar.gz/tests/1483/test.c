/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9598938113100145940
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xF43B7C7CL;/* VOLATILE GLOBAL g_2 */
static volatile int64_t g_3[4] = {(-6L),(-6L),(-6L),(-6L)};
static volatile int32_t g_4[3] = {0x74DD0324L,0x74DD0324L,0x74DD0324L};
static int32_t g_5 = 0x9C4C8D3CL;
static int8_t g_38 = 0xACL;
static uint64_t g_41 = 0x0A3418EB0BADCAB3LL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_11(int32_t  p_12, int32_t  p_13);
static uint8_t  func_16(uint64_t  p_17, uint32_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_3 g_4 g_41 g_38
 * writes: g_3 g_5 g_38 g_41 g_4
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_14 = 0x2CF415D7L;
    int32_t l_68 = 0xD3C4855FL;
    const int32_t l_73 = 0x1E225179L;
lbl_8:
    g_3[2] = g_2;
    for (g_5 = (-9); (g_5 > (-1)); ++g_5)
    { /* block id: 4 */
        int32_t l_15[7];
        int i;
        for (i = 0; i < 7; i++)
            l_15[i] = 4L;
        if (g_5)
            goto lbl_8;
        l_68 = ((safe_div_func_int8_t_s_s(func_11(l_14, l_15[6]), 0x0EL)) >= l_15[3]);
        g_4[0] = l_14;
    }
    l_68 |= (safe_lshift_func_uint16_t_u_s((safe_mod_func_uint64_t_u_u(g_38, 6UL)), l_73));
    return g_41;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_5 g_4 g_41 g_2
 * writes: g_38 g_41 g_4
 */
static int8_t  func_11(int32_t  p_12, int32_t  p_13)
{ /* block id: 6 */
    int16_t l_25 = 0xB5CFL;
    uint64_t l_59 = 0xAC5ADF6F6D77974DLL;
    int32_t l_60 = 0x8266C095L;
    g_38 = (func_16(((safe_sub_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint16_t_u_u((g_3[2] == g_5), g_5)) | l_25), 12)) == l_25), g_5)) & l_25), l_25) == l_25);
    if (p_13)
    { /* block id: 11 */
        int32_t l_39 = 0xD50FA8FAL;
        p_12 = l_39;
        g_41 &= ((((((!0x50E3L) , g_4[2]) ^ l_25) < p_12) && l_39) > l_39);
        p_13 = l_39;
        p_13 ^= (safe_mul_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u(65533UL, g_4[0])), 0L)) < l_25), 0xEBB6L));
    }
    else
    { /* block id: 16 */
        uint16_t l_48 = 65535UL;
        l_48++;
        if (l_25)
            goto lbl_61;
        if (l_48)
            goto lbl_61;
lbl_61:
        l_60 &= (((safe_rshift_func_uint16_t_u_s(((safe_lshift_func_uint16_t_u_u((safe_div_func_uint16_t_u_u((safe_add_func_uint32_t_u_u(1UL, 4294967295UL)), p_13)), g_3[0])) < p_12), 4)) & l_59) || p_13);
        if (((safe_mul_func_int8_t_s_s(0xF3L, l_59)) >= 0x88EDL))
        { /* block id: 21 */
            return g_5;
        }
        else
        { /* block id: 23 */
            g_4[0] = (((safe_mul_func_int16_t_s_s(g_2, 0xBF52L)) != 1L) <= 0xA6L);
            return p_13;
        }
    }
    p_12 = ((((safe_add_func_int16_t_s_s(0xCC51L, l_25)) , p_12) || p_12) ^ 4L);
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint8_t  func_16(uint64_t  p_17, uint32_t  p_18)
{ /* block id: 7 */
    int32_t l_37[1];
    int i;
    for (i = 0; i < 1; i++)
        l_37[i] = (-3L);
    l_37[0] = (safe_lshift_func_int8_t_s_u((safe_sub_func_int64_t_s_s((safe_add_func_uint16_t_u_u((!((safe_mod_func_int16_t_s_s((safe_rshift_func_int16_t_s_u((0x61L && p_18), 6)), l_37[0])) || g_3[1])), l_37[0])), p_18)), 6));
    return l_37[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 8, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 39
XXX times a non-volatile is write: 12
XXX times a volatile is read: 8
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 82.3

XXX forward jumps: 2
XXX backward jumps: 1

XXX stmts: 25
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 12
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 22.6
XXX percentage an existing variable is used: 77.4
********************* end of statistics **********************/

