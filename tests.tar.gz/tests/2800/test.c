/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3300012162389698914
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint64_t g_2 = 0UL;/* VOLATILE GLOBAL g_2 */
static volatile int8_t g_3 = 0x31L;/* VOLATILE GLOBAL g_3 */
static uint32_t g_10 = 0x58BDFADFL;
static int32_t g_11 = 0xB78ACC4BL;
static volatile int32_t g_13 = 0L;/* VOLATILE GLOBAL g_13 */
static uint16_t g_14[5] = {0x0964L,0x0964L,0x0964L,0x0964L,0x0964L};
static uint16_t g_35[7] = {0xA88AL,0xA88AL,0xA88AL,0xA88AL,0xA88AL,0xA88AL,0xA88AL};
static int32_t g_44 = 0L;
static int32_t g_47[1] = {0L};
static uint16_t g_48 = 0xCEAAL;
static int32_t g_52 = 0x83B1D319L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint32_t  func_26(int16_t  p_27, uint16_t  p_28);
static uint8_t  func_31(uint32_t  p_32, int64_t  p_33, uint32_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_10 g_14 g_13 g_35 g_48 g_52
 * writes: g_3 g_10 g_14 g_35 g_44 g_48 g_52
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    const uint32_t l_8 = 18446744073709551614UL;
    int32_t l_9 = (-6L);
    int32_t l_23[4] = {(-1L),(-1L),(-1L),(-1L)};
    int64_t l_51 = (-8L);
    int i;
    g_3 = g_2;
    if (((safe_sub_func_uint64_t_u_u((safe_rshift_func_uint16_t_u_u(((((g_2 && g_2) || (-5L)) , l_8) , g_3), 8)), l_9)) , g_2))
    { /* block id: 2 */
        g_10 |= 0L;
    }
    else
    { /* block id: 4 */
        int64_t l_12 = 0L;
        uint32_t l_36 = 0xE84CBF77L;
        ++g_14[2];
        l_23[1] |= (((safe_add_func_int32_t_s_s(((safe_mod_func_uint32_t_u_u((((safe_div_func_uint8_t_u_u((0L && 0x04L), g_14[2])) >= g_13) <= l_12), 0x40EE1D45L)) | 0L), l_12)) & 0x60L) , 0xC0998433L);
        g_52 &= (safe_mod_func_uint32_t_u_u(func_26((((safe_lshift_func_uint8_t_u_s(func_31(l_23[0], l_8, g_13), l_12)) || g_35[5]) , l_36), l_8), l_51));
    }
    return g_52;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_48
 * writes: g_44 g_48
 */
static uint32_t  func_26(int16_t  p_27, uint16_t  p_28)
{ /* block id: 10 */
    int16_t l_43 = 0x695EL;
    int32_t l_45 = (-1L);
    int32_t l_46[10] = {0xEDE6A6B9L,(-1L),(-1L),0xEDE6A6B9L,(-1L),(-1L),0xEDE6A6B9L,(-1L),(-1L),0xEDE6A6B9L};
    int i;
    g_44 = (((safe_mul_func_int8_t_s_s(((safe_div_func_uint16_t_u_u((((safe_mod_func_int32_t_s_s(l_43, g_14[2])) , l_43) < l_43), 0x8A3DL)) < 0x55D5DF5BL), p_28)) , g_14[4]) , (-10L));
    ++g_48;
    return l_46[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_35
 * writes: g_35
 */
static uint8_t  func_31(uint32_t  p_32, int64_t  p_33, uint32_t  p_34)
{ /* block id: 7 */
    g_35[5] |= p_34;
    return p_34;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_35[i], "g_35[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_44, "g_44", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_47[i], "g_47[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 16
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 7
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 78.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 46.5
XXX percentage an existing variable is used: 53.5
********************* end of statistics **********************/

