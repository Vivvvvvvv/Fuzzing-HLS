/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9714636516405194031
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2[2] = {0xB57FD546L,0xB57FD546L};
static volatile int32_t g_3[9] = {1L,(-5L),(-5L),1L,(-5L),(-5L),1L,(-5L),(-5L)};
static volatile int32_t g_4 = 5L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 5L;
static volatile int32_t g_9 = 0L;/* VOLATILE GLOBAL g_9 */
static int32_t g_10[3] = {(-1L),(-1L),(-1L)};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_6(uint16_t  p_7, const int32_t  p_8);
static uint8_t  func_15(const uint32_t  p_16, const int8_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_4 g_10 g_9 g_3
 * writes: g_5 g_2 g_10
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_18 = 0x68A9017CL;
    int32_t l_25 = 0x1AD7BA96L;
    int32_t l_26 = 0x0BE6286CL;
    int8_t l_27[6] = {0x17L,0x17L,0x17L,0x17L,0x17L,0x17L};
    int32_t l_28 = (-4L);
    int32_t l_29 = 1L;
    int32_t l_30 = 0xC124380DL;
    int32_t l_31[7] = {0xE29AC92DL,0xE29AC92DL,0xE29AC92DL,0xE29AC92DL,0xE29AC92DL,0xE29AC92DL,0xE29AC92DL};
    int16_t l_32 = 1L;
    uint64_t l_33 = 0xE9BDCCB4F7BC72EALL;
    uint64_t l_36[2];
    int i;
    for (i = 0; i < 2; i++)
        l_36[i] = 0xD5889E59FA6B86D5LL;
    for (g_5 = 0; (g_5 <= 1); g_5 += 1)
    { /* block id: 3 */
        int32_t l_24 = 0x07976B5AL;
        int i;
        g_2[g_5] = func_6(g_2[1], g_4);
        for (g_10[0] = (-8); (g_10[0] > (-1)); g_10[0] = safe_add_func_uint8_t_u_u(g_10[0], 8))
        { /* block id: 9 */
            g_2[0] &= ((safe_lshift_func_uint8_t_u_u(func_15(((l_18 != 0x86524F20L) || g_9), g_10[1]), l_18)) | g_5);
        }
        g_2[1] &= (safe_mul_func_uint8_t_u_u(l_18, g_3[3]));
        l_24 |= (safe_lshift_func_int8_t_s_s((((g_2[1] >= l_18) > l_18) , 0xE3L), 0));
    }
    l_33++;
    l_36[1] |= 0x5FEC6B03L;
    return g_10[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_5
 * writes:
 */
static int32_t  func_6(uint16_t  p_7, const int32_t  p_8)
{ /* block id: 4 */
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes:
 */
static uint8_t  func_15(const uint32_t  p_16, const int8_t  p_17)
{ /* block id: 10 */
    int16_t l_19[9];
    int i;
    for (i = 0; i < 9; i++)
        l_19[i] = 0L;
    l_19[3] = ((0x9DF9481FL && g_4) , 0x955A63A7L);
    return l_19[6];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 13
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 12
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 14
XXX times a non-volatile is write: 9
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 46
XXX percentage of non-volatile access: 85.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 4
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 15.1
XXX percentage an existing variable is used: 84.9
********************* end of statistics **********************/

