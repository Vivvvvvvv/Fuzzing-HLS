/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17351416574484427721
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_12 = 1UL;
static volatile uint32_t g_18 = 0xD9CD4431L;/* VOLATILE GLOBAL g_18 */
static int32_t g_23 = (-1L);
static volatile int32_t g_24 = 0x75FF4442L;/* VOLATILE GLOBAL g_24 */
static volatile int32_t g_25 = 0x7128ABF8L;/* VOLATILE GLOBAL g_25 */
static int16_t g_26 = 5L;
static volatile int64_t g_27 = (-1L);/* VOLATILE GLOBAL g_27 */
static int16_t g_29 = 0x6337L;
static int32_t g_30[3] = {(-1L),(-1L),(-1L)};
static volatile int64_t g_31 = (-5L);/* VOLATILE GLOBAL g_31 */
static volatile int64_t g_32[2] = {0x0887C5C6A81D68C2LL,0x0887C5C6A81D68C2LL};
static volatile int64_t g_33 = 0xFC786C7A88FF7673LL;/* VOLATILE GLOBAL g_33 */
static volatile uint64_t g_34[4] = {0x848298BBEB927EEDLL,0x848298BBEB927EEDLL,0x848298BBEB927EEDLL,0x848298BBEB927EEDLL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_4(uint8_t  p_5, const uint8_t  p_6, int32_t  p_7, uint64_t  p_8, uint16_t  p_9);
static int64_t  func_37(uint8_t  p_38, uint8_t  p_39);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_18 g_34 g_27 g_26
 * writes: g_18 g_23 g_34 g_25
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_10 = 6L;
    const uint32_t l_11[4] = {2UL,2UL,2UL,2UL};
    int32_t l_28[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};
    int i;
    g_23 = (safe_mod_func_uint32_t_u_u(func_4((((l_10 || (-1L)) , l_10) && 0x76B8L), l_11[1], g_12, g_12, l_10), 1L));
    ++g_34[0];
    l_28[1] ^= (func_37(g_34[0], l_10) || g_34[0]);
    g_25 = l_11[1];
    return g_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_12
 * writes: g_18
 */
static uint32_t  func_4(uint8_t  p_5, const uint8_t  p_6, int32_t  p_7, uint64_t  p_8, uint16_t  p_9)
{ /* block id: 1 */
    int32_t l_16 = (-4L);
    int32_t l_17 = 3L;
    for (p_9 = 0; (p_9 != 37); p_9++)
    { /* block id: 4 */
        int8_t l_15 = 1L;
        g_18--;
        if (p_9)
            continue;
        l_16 = (0x7779A7B4L & g_12);
        for (l_16 = (-30); (l_16 <= 18); l_16 = safe_add_func_uint64_t_u_u(l_16, 1))
        { /* block id: 10 */
            p_7 = (1L >= p_8);
        }
    }
    return g_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_27
 * writes:
 */
static int64_t  func_37(uint8_t  p_38, uint8_t  p_39)
{ /* block id: 17 */
    return g_27;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_30[i], "g_30[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_31, "g_31", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_32[i], "g_32[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 19
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 4
   depth: 4, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 15
XXX times a non-volatile is write: 6
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 19
XXX percentage of non-volatile access: 77.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 4
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 46.3
XXX percentage an existing variable is used: 53.7
********************* end of statistics **********************/

