/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16483429744010816567
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const volatile int8_t g_4 = 1L;/* VOLATILE GLOBAL g_4 */
static volatile uint32_t g_5 = 0x506E60B0L;/* VOLATILE GLOBAL g_5 */
static int16_t g_10 = 1L;
static uint16_t g_37 = 65535UL;
static int16_t g_38 = (-7L);


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint8_t  func_23(int16_t  p_24);
static int32_t  func_28(int32_t  p_29, int32_t  p_30);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_10 g_5 g_37
 * writes: g_5 g_37 g_38
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_11 = 0xCEF054A2L;
    uint16_t l_12 = 65535UL;
    int32_t l_46[9] = {2L,2L,2L,2L,2L,2L,2L,2L,2L};
    int i;
    g_5 = ((g_4 || 0L) , g_4);
    if ((((safe_sub_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(g_4, g_10)), g_10)) ^ l_11) , l_12))
    { /* block id: 2 */
        uint32_t l_13 = 0x37BB0086L;
        int32_t l_14 = (-1L);
        l_14 = l_13;
    }
    else
    { /* block id: 4 */
        int16_t l_40 = 1L;
        int64_t l_41 = 0xAFE0A4D2C643D439LL;
        int32_t l_42 = 7L;
        uint64_t l_43 = 0x9E7675DAAFE497D6LL;
        l_42 = (safe_lshift_func_uint8_t_u_u(((safe_div_func_uint32_t_u_u((safe_rshift_func_int8_t_s_u((((((safe_mod_func_uint16_t_u_u((((((func_23((((~(safe_rshift_func_uint16_t_u_u(g_10, 1))) & g_10) < 1L)) && g_4) , 0x87C4177FD8B26DE0LL) && g_10) , 0x62B0L) > 0xFE87L), g_10)) , 0xB1CAD2BBL) & l_11) , l_40) | g_10), g_10)), (-1L))) | l_41), l_12));
        ++l_43;
    }
    l_46[4] = ((((l_12 , g_10) == 1UL) <= 0xCDL) > g_37);
    return l_46[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_10
 * writes: g_37 g_38
 */
static uint8_t  func_23(int16_t  p_24)
{ /* block id: 5 */
    uint64_t l_31[7];
    int32_t l_39 = 4L;
    int i;
    for (i = 0; i < 7; i++)
        l_31[i] = 18446744073709551607UL;
    l_39 = func_28(g_5, l_31[4]);
    return l_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_5
 * writes: g_37 g_38
 */
static int32_t  func_28(int32_t  p_29, int32_t  p_30)
{ /* block id: 6 */
    int16_t l_34[2];
    int i;
    for (i = 0; i < 2; i++)
        l_34[i] = 0xAF9EL;
    if (g_10)
    { /* block id: 7 */
        for (p_29 = 4; (p_29 <= 15); ++p_29)
        { /* block id: 10 */
            return l_34[1];
        }
        return p_29;
    }
    else
    { /* block id: 14 */
        g_37 = ((safe_rshift_func_int8_t_s_u((0x8D10L != p_30), 3)) ^ g_5);
        g_38 = p_29;
    }
    return l_34[1];
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_37, "g_37", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 28
XXX times a non-volatile is write: 8
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 14
XXX percentage of non-volatile access: 83.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 7
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 41.5
XXX percentage an existing variable is used: 58.5
********************* end of statistics **********************/

