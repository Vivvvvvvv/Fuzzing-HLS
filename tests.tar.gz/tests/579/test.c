/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4164102905916541500
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2[2] = {0L,0L};
static int32_t g_9 = 0x0A3267E6L;
static uint32_t g_136 = 0x5BA149CDL;
static uint32_t g_143[6][10] = {{0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL,0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL},{0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL,0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL},{0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL,0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL},{0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL,0UL,0x2F0B7091L,0x2F0B7091L,0UL,4294967290UL},{0UL,0x2F0B7091L,0x2F0B7091L,0UL,0xDDD7475DL,1UL,0UL,0UL,1UL,0xDDD7475DL},{1UL,0UL,0UL,1UL,0xDDD7475DL,1UL,0UL,0UL,1UL,0xDDD7475DL}};
static int64_t g_175 = (-1L);
static volatile int8_t g_210 = 0L;/* VOLATILE GLOBAL g_210 */


/* --- FORWARD DECLARATIONS --- */
static const uint64_t  func_1(void);
static uint16_t  func_28(int32_t  p_29);
static uint32_t  func_37(const int16_t  p_38, const uint32_t  p_39);
static const int16_t  func_40(uint16_t  p_41, int16_t  p_42, uint8_t  p_43, const uint32_t  p_44, int8_t  p_45);
static uint64_t  func_47(int8_t  p_48, uint8_t  p_49);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_9 g_136 g_143 g_175 g_210
 * writes: g_2 g_9 g_143 g_136 g_175
 */
static const uint64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_12 = 0xEDL;
    int32_t l_18 = 0xAAB56411L;
    uint8_t l_19 = 1UL;
    int8_t l_24 = 0L;
    for (g_2[0] = (-13); (g_2[0] > 13); g_2[0] = safe_add_func_uint32_t_u_u(g_2[0], 1))
    { /* block id: 3 */
        uint16_t l_5 = 0x768CL;
        uint32_t l_6[10] = {0xF3C34EEAL,1UL,1UL,0xF3C34EEAL,0UL,0xF3C34EEAL,1UL,1UL,0xF3C34EEAL,0UL};
        int32_t l_8 = 0xE21AFA9BL;
        int i;
        l_5 = 0x2DB22124L;
        for (l_5 = 3; (l_5 <= 9); l_5 += 1)
        { /* block id: 7 */
            uint8_t l_7 = 255UL;
            l_8 &= (g_2[0] < l_7);
        }
    }
    if (g_2[1])
    { /* block id: 11 */
        uint32_t l_13 = 0UL;
        for (g_9 = 20; (g_9 > 19); --g_9)
        { /* block id: 14 */
            l_12 = (g_9 || g_2[1]);
            g_2[0] = g_2[1];
        }
        l_13 = l_12;
        g_2[0] = g_2[0];
    }
    else
    { /* block id: 20 */
        int32_t l_16 = 0x8EFA97F5L;
        int32_t l_17 = 1L;
        for (g_9 = 0; (g_9 == (-17)); g_9--)
        { /* block id: 23 */
            return g_9;
        }
        l_19--;
        if ((safe_mul_func_uint16_t_u_u(l_19, l_24)))
        { /* block id: 27 */
            int16_t l_27 = (-2L);
            g_2[0] = (((safe_div_func_int64_t_s_s(g_9, l_27)) & g_9) & 0x31DDA87BL);
        }
        else
        { /* block id: 29 */
            uint16_t l_30[3][7][10] = {{{0xCC21L,65535UL,0x910CL,8UL,9UL,3UL,0x5E06L,65535UL,8UL,0x3A3AL},{3UL,0UL,6UL,0x384FL,0x81FFL,0x75DFL,65531UL,65535UL,0x75DFL,0xFBA3L},{1UL,0x5E06L,0x910CL,1UL,9UL,8UL,65531UL,0x910CL,3UL,0x81FFL},{0xCC21L,0UL,0x5E06L,8UL,0xFBA3L,8UL,0x5E06L,0UL,0xCC21L,0x3A3AL},{1UL,65535UL,6UL,3UL,0xFBA3L,0x75DFL,65535UL,65531UL,0x75DFL,0x81FFL},{3UL,0x5E06L,0xAC39L,3UL,9UL,3UL,0UL,0x910CL,0xCC21L,0xFBA3L},{0xCC21L,65531UL,0xAC39L,8UL,0x81FFL,0xCC21L,0x5E06L,65531UL,3UL,0x3A3AL}},{{0x384FL,65531UL,6UL,1UL,9UL,0x75DFL,0UL,0UL,0x75DFL,9UL},{0x384FL,0x5E06L,0x5E06L,0x384FL,9UL,0xCC21L,65535UL,0x910CL,8UL,9UL},{0xCC21L,65535UL,0x910CL,8UL,9UL,3UL,0x5E06L,65535UL,8UL,0x3A3AL},{3UL,0UL,6UL,0x384FL,0x81FFL,0x75DFL,65531UL,65535UL,0x75DFL,0xFBA3L},{1UL,0x5E06L,0x910CL,1UL,9UL,8UL,65531UL,0x910CL,3UL,0x81FFL},{0xCC21L,0UL,0x5E06L,8UL,0xFBA3L,8UL,0x5E06L,0UL,0xCC21L,0x3A3AL},{1UL,65535UL,6UL,3UL,0xFBA3L,0x75DFL,65535UL,65531UL,0x75DFL,0x81FFL}},{{3UL,0x5E06L,0xAC39L,3UL,9UL,3UL,0UL,0x910CL,0xCC21L,0xFBA3L},{0xCC21L,65531UL,0xAC39L,8UL,0x81FFL,0xCC21L,0x5E06L,65531UL,3UL,0x3A3AL},{0x384FL,65531UL,6UL,1UL,9UL,65528UL,0xCC21L,0xCC21L,65528UL,0x4689L},{0xD0D4L,0x75DFL,0x75DFL,0xD0D4L,0x97FBL,0UL,3UL,3UL,1UL,0x4689L},{0UL,3UL,3UL,1UL,0x4689L,0x0CE6L,0x75DFL,3UL,1UL,0x96A4L},{0xF4AEL,0xCC21L,3UL,0xD0D4L,1UL,65528UL,8UL,3UL,65528UL,0xF7D5L},{1UL,0x75DFL,3UL,1UL,0x97FBL,1UL,8UL,3UL,0x0CE6L,1UL}}};
            int32_t l_259[3];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_259[i] = 0xD167041CL;
            g_2[0] = (func_28(l_30[1][5][4]) > 0x103FL);
            l_259[1] = (l_16 & l_17);
        }
        return l_24;
    }
    g_9 = (safe_lshift_func_uint16_t_u_u((g_210 && l_18), l_24));
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_9 g_136 g_143 g_175 g_210
 * writes: g_2 g_9 g_143 g_136 g_175
 */
static uint16_t  func_28(int32_t  p_29)
{ /* block id: 30 */
    int64_t l_33[4];
    uint16_t l_138 = 65535UL;
    uint8_t l_182 = 0x1DL;
    uint64_t l_187[4][6][6] = {{{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL}},{{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL}},{{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL}},{{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL},{1UL,1UL,1UL,1UL,1UL,1UL}}};
    int32_t l_189 = 0xF9145320L;
    int32_t l_190 = (-6L);
    int32_t l_223 = (-5L);
    int8_t l_237 = 0xEAL;
    int8_t l_251[1][9][10] = {{{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L},{0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L,0x07L}}};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_33[i] = 0L;
lbl_213:
    if ((safe_mul_func_int16_t_s_s(p_29, 1L)))
    { /* block id: 31 */
        int64_t l_137 = 3L;
        int32_t l_177 = 0x258FFC12L;
        if ((l_33[0] & 3UL))
        { /* block id: 32 */
            uint64_t l_34 = 1UL;
            l_34 = 0xD21FD009L;
            g_175 &= (safe_mod_func_uint32_t_u_u(func_37(func_40(((!((func_47(p_29, g_2[1]) || g_2[0]) , 3L)) ^ g_136), l_137, g_136, g_136, l_138), p_29), l_34));
            return g_143[1][8];
        }
        else
        { /* block id: 117 */
            int8_t l_176 = 0x84L;
            l_177 = (((l_176 , p_29) , l_138) > 0xBFEC47B7L);
        }
        if ((safe_lshift_func_int16_t_s_u(0xF12DL, 4)))
        { /* block id: 120 */
            int16_t l_188 = 0xF44CL;
            g_9 &= ((!(~((((g_143[5][5] == 4294967290UL) , 0xB7L) || l_177) < p_29))) , p_29);
            l_182 |= (g_175 != p_29);
            l_188 = (((safe_lshift_func_int8_t_s_s((((((safe_rshift_func_uint16_t_u_s((l_177 | g_136), 6)) | l_177) & p_29) && g_9) != g_9), 1)) > l_187[2][1][1]) && 0x26B5L);
        }
        else
        { /* block id: 124 */
            uint64_t l_191 = 1UL;
            --l_191;
            g_2[0] = (safe_lshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_s(((safe_lshift_func_uint16_t_u_s(p_29, g_143[0][5])) ^ p_29), g_136)), 11));
            return p_29;
        }
    }
    else
    { /* block id: 129 */
        uint8_t l_200 = 0x15L;
        int32_t l_205 = 0x8C6A7EAEL;
        l_200--;
lbl_206:
        if (g_2[0])
        { /* block id: 131 */
            int64_t l_204 = (-1L);
            l_204 ^= ((!p_29) || g_175);
            if (g_9)
                goto lbl_206;
            l_205 = ((1UL && 0x005DB3240AD27CE3LL) | 1UL);
        }
        else
        { /* block id: 134 */
            return g_143[5][8];
        }
        g_2[0] = ((~(safe_lshift_func_int8_t_s_s(l_205, 5))) <= g_210);
    }
    for (g_136 = 0; (g_136 == 60); ++g_136)
    { /* block id: 142 */
        if (g_9)
            goto lbl_213;
        l_189 = p_29;
    }
    for (l_182 = 0; (l_182 < 3); l_182++)
    { /* block id: 148 */
        int64_t l_217 = 0xFBB3F4301ED44951LL;
        int32_t l_219 = (-4L);
        int32_t l_221 = 0x076AB362L;
        int32_t l_222 = 1L;
        int32_t l_224 = (-1L);
        uint32_t l_250 = 18446744073709551614UL;
        int16_t l_254 = 0xFE57L;
        if (p_29)
        { /* block id: 149 */
            const uint16_t l_216[3] = {0xAFA4L,0xAFA4L,0xAFA4L};
            int32_t l_218 = 0x32D29E3FL;
            int32_t l_220[5] = {(-3L),(-3L),(-3L),(-3L),(-3L)};
            uint32_t l_225 = 0UL;
            int i;
            g_2[1] = (((l_216[0] | 1L) | l_217) && p_29);
            ++l_225;
        }
        else
        { /* block id: 152 */
            int32_t l_232[2];
            int32_t l_233[4];
            int i;
            for (i = 0; i < 2; i++)
                l_232[i] = (-5L);
            for (i = 0; i < 4; i++)
                l_233[i] = 0x62E3C097L;
            g_2[1] = (safe_mod_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(p_29, 255UL)), l_232[0]));
            if (p_29)
                continue;
            l_233[1] = (0x09L ^ (-1L));
            l_221 ^= (((+(((((((safe_mod_func_uint16_t_u_u(0UL, l_187[2][1][1])) && 0x2AL) == 1UL) ^ p_29) & l_237) < g_143[1][8]) & g_143[5][9])) < p_29) , 5L);
        }
        if (((safe_mul_func_int16_t_s_s(((((g_2[0] > (-1L)) ^ (-10L)) | 0UL) > g_175), g_2[0])) | p_29))
        { /* block id: 158 */
            g_2[0] = (9UL == p_29);
            return l_223;
        }
        else
        { /* block id: 161 */
            uint64_t l_240 = 0xFD3435ECC137F106LL;
            int32_t l_243 = 0xF33EA313L;
            l_222 = ((l_240 == l_217) , p_29);
            l_243 = ((safe_rshift_func_uint16_t_u_s((g_143[1][8] | p_29), 7)) ^ p_29);
            l_219 = (safe_div_func_uint32_t_u_u(((safe_lshift_func_uint16_t_u_s((safe_div_func_int8_t_s_s((g_9 >= 0x094950BB044F218FLL), l_250)), l_251[0][2][2])) != 4294967289UL), g_175));
            l_224 = (((safe_sub_func_int16_t_s_s((5L || 0xF5FCC094L), l_243)) && g_2[0]) > l_254);
        }
        l_221 = ((g_143[1][8] > 0L) , g_210);
        l_189 = (((safe_rshift_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u(((-1L) ^ p_29), 0xEDL)) > g_143[1][8]), l_250)) ^ p_29) != g_143[1][8]);
    }
    return p_29;
}


/* ------------------------------------------ */
/* 
 * reads : g_136 g_9 g_2 g_143
 * writes: g_136 g_9 g_2
 */
static uint32_t  func_37(const int16_t  p_38, const uint32_t  p_39)
{ /* block id: 99 */
    int8_t l_165 = 0xD7L;
    int32_t l_174 = 0x11478435L;
    l_165 = (((p_38 ^ 8UL) || p_39) == 0xC243L);
    for (g_136 = 0; (g_136 <= 5); g_136 += 1)
    { /* block id: 103 */
        uint64_t l_166[10] = {0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL,0xB1D02B38FC1FC836LL};
        int32_t l_167 = 9L;
        int i;
        l_167 = (p_39 ^ l_166[4]);
        for (g_9 = 0; (g_9 <= 1); g_9 += 1)
        { /* block id: 107 */
            int i, j;
            g_2[g_9] = (safe_lshift_func_uint16_t_u_s((safe_div_func_uint64_t_u_u(0UL, g_2[g_9])), 4));
            g_2[0] = (((-2L) > (-3L)) != g_143[g_136][(g_9 + 1)]);
            l_174 = (safe_rshift_func_uint16_t_u_u(0x2F78L, g_2[g_9]));
        }
    }
    g_2[0] |= (-9L);
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_136 g_2 g_9 g_143
 * writes: g_143 g_9
 */
static const int16_t  func_40(uint16_t  p_41, int16_t  p_42, uint8_t  p_43, const uint32_t  p_44, int8_t  p_45)
{ /* block id: 77 */
    int64_t l_147 = 0x2F9674B01682E6EALL;
    int32_t l_155 = (-4L);
lbl_164:
    if (((((safe_lshift_func_int8_t_s_u((0x80D3783E0E501278LL < 0x117D6C01FFE24739LL), p_41)) == 255UL) , p_42) & g_136))
    { /* block id: 78 */
lbl_146:
        g_143[1][8] |= (safe_mul_func_uint16_t_u_u((((p_42 < g_2[0]) < (-9L)) || (-1L)), g_9));
        for (p_41 = 0; (p_41 <= 1); p_41 += 1)
        { /* block id: 82 */
            int i;
            g_9 = ((safe_add_func_uint8_t_u_u(((g_2[p_41] , 0x9725L) == 0x0BE2L), g_2[p_41])) , g_2[p_41]);
        }
        if (p_42)
            goto lbl_146;
        return p_42;
    }
    else
    { /* block id: 87 */
        l_147 |= (18446744073709551615UL && g_2[0]);
    }
    if (((((safe_add_func_int16_t_s_s((safe_sub_func_int32_t_s_s((p_41 >= g_9), 0x7E6DEFB2L)), l_147)) & l_147) & g_143[1][8]) && p_45))
    { /* block id: 90 */
        return p_42;
    }
    else
    { /* block id: 92 */
        uint32_t l_154 = 0xCDC079ADL;
        uint32_t l_163 = 0x635219DDL;
        l_155 = (((safe_mod_func_uint32_t_u_u((((p_43 > l_154) <= l_154) <= g_136), 0x2B4722CCL)) > l_147) < p_44);
        g_9 ^= ((~((0x33DD79A8L | 0x376D4884L) == l_154)) & g_2[0]);
        l_155 = (safe_sub_func_uint32_t_u_u((((safe_rshift_func_uint16_t_u_s((safe_mod_func_int16_t_s_s(0xDB02L, g_9)), g_143[1][8])) == 0UL) && l_163), g_9));
        if (p_44)
            goto lbl_164;
    }
    return p_43;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_9
 * writes: g_2 g_9
 */
static uint64_t  func_47(int8_t  p_48, uint8_t  p_49)
{ /* block id: 34 */
    uint32_t l_50[6][1][6] = {{{7UL,7UL,0UL,0x9DB650F8L,0UL,7UL}},{{0UL,0xC1821526L,0x9DB650F8L,0x9DB650F8L,0xC1821526L,0UL}},{{7UL,0UL,0x9DB650F8L,0UL,7UL,7UL}},{{4294967287UL,0UL,0UL,4294967287UL,0xC1821526L,4294967287UL}},{{4294967287UL,0xC1821526L,4294967287UL,0UL,0UL,4294967287UL}},{{7UL,7UL,0UL,0x9DB650F8L,0UL,7UL}}};
    int32_t l_56 = 0x939616D9L;
    int32_t l_67 = 0xF64BAD57L;
    int32_t l_69 = 0x6D91310EL;
    int32_t l_70 = 0x90F62EB7L;
    int32_t l_71 = 0x48422EE8L;
    int32_t l_72 = 0xD1849914L;
    int32_t l_73[3];
    int32_t l_75 = (-1L);
    uint32_t l_83 = 3UL;
    int32_t l_115[8];
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_73[i] = 0xA216BAB3L;
    for (i = 0; i < 8; i++)
        l_115[i] = 0L;
    ++l_50[4][0][1];
    g_2[0] = 0L;
    if ((safe_mul_func_int16_t_s_s(((g_2[1] <= g_2[0]) < 0x2A103ABEL), 0x9A78L)))
    { /* block id: 37 */
        int32_t l_55[8][8] = {{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L},{(-1L),1L,0x66F2FC99L,0x66F2FC99L,1L,(-1L),0x253A1071L,0x253A1071L}};
        int32_t l_57 = (-10L);
        int i, j;
        l_56 = (l_55[3][1] <= p_48);
        l_57 = l_50[2][0][4];
    }
    else
    { /* block id: 40 */
        uint8_t l_58 = 0x5FL;
        int32_t l_64[1];
        int16_t l_68 = 0x1C9DL;
        int i;
        for (i = 0; i < 1; i++)
            l_64[i] = 0x104DD428L;
        g_9 = l_58;
        for (g_9 = 0; (g_9 != (-22)); g_9--)
        { /* block id: 44 */
            return l_58;
        }
        for (l_58 = 0; (l_58 > 3); l_58 = safe_add_func_int16_t_s_s(l_58, 2))
        { /* block id: 49 */
            int32_t l_63 = 0x7D65D205L;
            int32_t l_65 = 0L;
            int32_t l_66[3];
            int8_t l_74 = (-1L);
            uint64_t l_76 = 0x63B3A31468BD1E8ALL;
            int i;
            for (i = 0; i < 3; i++)
                l_66[i] = 0L;
            l_63 = (((g_9 && g_2[0]) , 0xBEL) , p_48);
            l_64[0] = (((1L | l_63) | 1L) , g_9);
            l_65 = (((0xD4L <= l_63) >= (-6L)) <= g_2[0]);
            l_76++;
        }
    }
    if ((safe_mul_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(p_48, g_2[0])), p_49)))
    { /* block id: 56 */
        int64_t l_92[3];
        int32_t l_93 = 8L;
        int32_t l_98 = 1L;
        int32_t l_99 = 0xBCF51ADCL;
        int32_t l_100 = 0x773D59F1L;
        int8_t l_101 = 1L;
        int32_t l_103 = 0xC38EFF28L;
        int32_t l_104 = 0x46339393L;
        int32_t l_105 = 0xE19E2ED9L;
        uint16_t l_108 = 0x8E79L;
        int16_t l_116 = 0x69ABL;
        int32_t l_119 = (-10L);
        int32_t l_120 = (-1L);
        int32_t l_121 = 0L;
        int i;
        for (i = 0; i < 3; i++)
            l_92[i] = 0L;
        if (l_83)
        { /* block id: 57 */
            uint32_t l_94 = 4294967295UL;
            int16_t l_97 = 0x74C5L;
            int32_t l_102 = 0L;
            int32_t l_106[6][6][7] = {{{(-1L),0xAC484671L,(-5L),(-6L),0x4B4BCE18L,0x1C45913EL,(-8L)},{(-5L),0x90175C14L,0xFF73A4BFL,0x4B4BCE18L,0x1342B15AL,(-1L),(-1L)},{(-3L),1L,0xFF73A4BFL,1L,(-3L),(-8L),0x1C45913EL},{0x90175C14L,0x88BD6C54L,(-5L),0L,(-6L),5L,0xFF73A4BFL},{(-1L),(-8L),0x2EBD030DL,0xDCC4AB30L,0x5F9F679CL,0x88BD6C54L,0xAC484671L},{0x90175C14L,0L,0x20794590L,0x63A0E5F2L,(-1L),0x4B4BCE18L,0x05431493L}},{{(-3L),(-1L),0x4B4BCE18L,0x2EBD030DL,0x2EBD030DL,0x4B4BCE18L,(-1L)},{(-5L),(-1L),0x05431493L,0x357D0D88L,(-6L),0x88BD6C54L,0x2EBD030DL},{(-1L),0x357D0D88L,0x63A0E5F2L,(-5L),1L,5L,(-3L)},{0xDCC4AB30L,0x05431493L,0x90175C14L,0x357D0D88L,5L,(-8L),(-6L)},{0x063A1A89L,(-3L),0x2198C401L,0x2EBD030DL,3L,(-1L),3L},{0x63A0E5F2L,(-3L),(-3L),0x63A0E5F2L,(-8L),0x1C45913EL,0x5F9F679CL}},{{5L,0x05431493L,(-1L),0xDCC4AB30L,(-5L),0xFF73A4BFL,0x20794590L},{0x20794590L,0x357D0D88L,(-8L),0L,0x063A1A89L,0xAC484671L,0x5F9F679CL},{0xFF73A4BFL,(-1L),(-8L),1L,0L,0x05431493L,3L},{(-6L),(-1L),0L,0x4B4BCE18L,0L,(-1L),(-6L)},{0x5F9F679CL,0L,(-1L),(-6L),0x063A1A89L,0x2EBD030DL,(-3L)},{1L,(-8L),0x1342B15AL,(-6L),(-5L),(-3L),0x2EBD030DL}},{{0x357D0D88L,0x88BD6C54L,(-1L),(-1L),(-8L),(-6L),(-1L)},{(-8L),1L,0L,0x05431493L,3L,3L,0x05431493L},{(-8L),0x90175C14L,(-8L),0x88BD6C54L,5L,0x5F9F679CL,0xAC484671L},{0x357D0D88L,0xAC484671L,(-8L),3L,1L,0x20794590L,0xFF73A4BFL},{1L,0x4CCE49B2L,(-1L),0x20794590L,(-6L),0x5F9F679CL,0x1C45913EL},{0x5F9F679CL,0x063A1A89L,(-3L),0x2198C401L,0x2EBD030DL,3L,(-1L)}},{{(-6L),(-1L),0x2198C401L,0x2198C401L,(-1L),(-6L),(-8L)},{(-1L),1L,0x63A0E5F2L,0x063A1A89L,0x05431493L,0xAC484671L,0x20794590L},{0x063A1A89L,0x2EBD030DL,(-3L),(-5L),(-6L),0x1342B15AL,(-8L)},{0x20794590L,1L,3L,(-8L),0xAC484671L,0x357D0D88L,0x2EBD030DL},{(-3L),0x2198C401L,0x2EBD030DL,3L,(-1L),3L,0x2EBD030DL},{0x989475B2L,0x989475B2L,0x063A1A89L,5L,0x2EBD030DL,0xFF73A4BFL,(-8L)}},{{(-6L),0x88BD6C54L,0x1342B15AL,1L,0x4CCE49B2L,(-1L),0x20794590L},{5L,0xFF73A4BFL,0x1C45913EL,(-6L),0x2EBD030DL,0x4CCE49B2L,0xDCC4AB30L},{0x1C45913EL,0x63A0E5F2L,(-1L),0x2EBD030DL,(-1L),5L,5L},{0xAC484671L,(-1L),(-1L),(-1L),0xAC484671L,0xDCC4AB30L,0x4CCE49B2L},{0x63A0E5F2L,(-8L),0x1C45913EL,0x5F9F679CL,(-6L),0x20794590L,(-1L)},{0x2198C401L,0x90175C14L,0x1342B15AL,(-6L),0x05431493L,(-8L),0xFF73A4BFL}}};
            int64_t l_107 = 0L;
            int i, j, k;
            l_67 = (safe_add_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u(((g_9 , g_2[0]) | p_48), p_48)), 0xC6L));
            l_93 = ((safe_mod_func_int8_t_s_s((((((safe_rshift_func_uint8_t_u_u((p_48 > 0L), 3)) || 0UL) <= g_2[1]) == p_48) , g_9), l_92[0])) > 0x0B01AA1EC4391174LL);
            l_94++;
            l_108++;
        }
        else
        { /* block id: 62 */
            l_105 ^= p_48;
        }
        for (l_72 = 24; (l_72 >= (-29)); l_72 = safe_sub_func_int8_t_s_s(l_72, 6))
        { /* block id: 67 */
            int8_t l_113 = 0x45L;
            int32_t l_114[8][4][7] = {{{8L,0x845578D7L,(-1L),0x28A493C9L,0x82C1C9F6L,(-1L),0x82C1C9F6L},{0x6AF959E5L,0xE0995485L,0xE0995485L,0x6AF959E5L,0x845578D7L,0x9B4FB0B0L,1L},{0x3E800ADBL,0x6AF959E5L,(-1L),0xB4968E5EL,6L,8L,0xAAFBA0E2L},{0xE0995485L,0x9B4FB0B0L,(-9L),8L,0xFD560464L,0xB7D3352EL,1L}},{{(-1L),(-2L),0xFF2A67DBL,0x5E83B3B4L,0xB0D5B00EL,0xFA652D37L,0x82C1C9F6L},{(-2L),8L,0x6AF959E5L,0x82C1C9F6L,0xE47A8F7DL,0xAAFBA0E2L,(-1L)},{0xAAFBA0E2L,1L,0x6AF959E5L,0xB7D3352EL,0xD627FB32L,0xD627FB32L,0xB7D3352EL},{0xFF2A67DBL,(-1L),0xFF2A67DBL,0x03ACD4B1L,0xB4968E5EL,0x73CF6326L,0L}},{{0x9B4FB0B0L,0xB4968E5EL,(-9L),0x03FFABF6L,(-1L),0x64D15AFFL,0xD627FB32L},{1L,0x28A493C9L,(-1L),(-9L),0L,0x73CF6326L,(-1L)},{(-1L),0xFD560464L,0xE0995485L,0xAA5B5247L,(-1L),0xD627FB32L,(-9L)},{0x73CF6326L,(-1L),(-1L),(-2L),1L,0xAAFBA0E2L,0x9B4FB0B0L}},{{0xB4968E5EL,(-1L),0x845578D7L,0xFA652D37L,0x6AF959E5L,0xFA652D37L,0x845578D7L},{0xFD560464L,0xFD560464L,0x64D15AFFL,0x73CF6326L,(-1L),0xB7D3352EL,1L},{0x69A2289BL,0x28A493C9L,0xFA652D37L,6L,(-1L),8L,0xB4968E5EL},{0L,0xB4968E5EL,0L,(-1L),(-1L),0x9B4FB0B0L,0x03FFABF6L}},{{6L,(-1L),0L,0xB4968E5EL,0L,0x5E83B3B4L,0xE47A8F7DL},{0xE47A8F7DL,0xFF2A67DBL,(-1L),(-1L),0xAA5B5247L,0xFD560464L,0xAAFBA0E2L},{0xE47A8F7DL,0xB0D5B00EL,0x03ACD4B1L,(-1L),(-1L),0x03ACD4B1L,0xB0D5B00EL},{(-1L),0x82C1C9F6L,0x28A493C9L,(-1L),0x845578D7L,8L,(-9L)}},{{0x845578D7L,6L,0xAA5B5247L,0x03FFABF6L,(-1L),0x73CF6326L,0x6AF959E5L},{(-2L),0L,0x64D15AFFL,(-1L),1L,0x6AF959E5L,(-1L)},{0x64D15AFFL,0x6AF959E5L,(-9L),(-1L),0xB7D3352EL,0x69A2289BL,0xFD560464L},{1L,1L,0xB7D3352EL,(-1L),0x73CF6326L,0x64D15AFFL,0xFD560464L}},{{(-1L),1L,0xFD560464L,0xB4968E5EL,0xFD560464L,1L,(-1L)},{8L,0xFA652D37L,(-1L),0x03ACD4B1L,0x64D15AFFL,(-1L),0x6AF959E5L},{0xAA5B5247L,0x5E83B3B4L,0xFA652D37L,0xAAFBA0E2L,(-1L),(-1L),(-9L)},{6L,(-2L),(-1L),(-1L),1L,0x82C1C9F6L,0xB0D5B00EL}},{{0x9B4FB0B0L,0x28A493C9L,0xFD560464L,1L,0L,0xAA5B5247L,0xAAFBA0E2L},{0xB4968E5EL,(-1L),0xB7D3352EL,0x82C1C9F6L,(-1L),0xAA5B5247L,0xE47A8F7DL},{0x82C1C9F6L,0x69A2289BL,(-9L),(-9L),0x69A2289BL,0x82C1C9F6L,0x3E800ADBL},{0x03ACD4B1L,0xAAFBA0E2L,0x64D15AFFL,0x69A2289BL,0xD627FB32L,(-1L),1L}}};
            int32_t l_117 = 5L;
            int64_t l_118 = 1L;
            uint64_t l_122[9] = {18446744073709551615UL,6UL,18446744073709551615UL,18446744073709551615UL,6UL,18446744073709551615UL,18446744073709551615UL,6UL,18446744073709551615UL};
            int i, j, k;
            g_2[1] = (1UL <= l_100);
            --l_122[6];
        }
    }
    else
    { /* block id: 71 */
        int8_t l_126[1][8];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 8; j++)
                l_126[i][j] = 0x92L;
        }
        l_126[0][2] |= (+p_48);
        g_2[1] = g_9;
        l_115[2] = (((safe_mul_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u((+(safe_mul_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((((g_2[0] | p_48) & 9UL) <= p_48), 10)), 0xDC4AL))), g_9)) && l_126[0][6]), p_48)) , 0x315FCE81A1E77F11LL) | g_2[0]);
    }
    return l_73[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_136, "g_136", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_143[i][j], "g_143[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_175, "g_175", print_hash_value);
    transparent_crc(g_210, "g_210", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 104
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 112
   depth: 2, occurrence: 28
   depth: 3, occurrence: 10
   depth: 4, occurrence: 10
   depth: 5, occurrence: 5
   depth: 6, occurrence: 4
   depth: 7, occurrence: 4
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 190
XXX times a non-volatile is write: 79
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 27
XXX percentage of non-volatile access: 98.9

XXX forward jumps: 1
XXX backward jumps: 3

XXX stmts: 111
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 42
   depth: 2, occurrence: 49

XXX percentage a fresh-made variable is used: 26.4
XXX percentage an existing variable is used: 73.6
********************* end of statistics **********************/

