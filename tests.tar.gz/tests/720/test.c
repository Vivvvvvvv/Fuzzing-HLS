/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10567888743218079879
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_3 = 0x9000D4E7L;
static int8_t g_6 = (-3L);
static volatile int8_t g_10 = 0x3CL;/* VOLATILE GLOBAL g_10 */
static uint64_t g_12 = 0UL;
static uint32_t g_22 = 0x522452A2L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);
static int64_t  func_19(const uint32_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_6 g_12 g_10
 * writes: g_3 g_6 g_10 g_12 g_22
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2[6];
    int32_t l_11[4] = {(-6L),(-6L),(-6L),(-6L)};
    int i;
    for (i = 0; i < 6; i++)
        l_2[i] = 1L;
    g_3 = l_2[5];
    g_6 = ((safe_rshift_func_int16_t_s_s(g_3, 13)) , l_2[5]);
    for (g_6 = 0; (g_6 > (-30)); g_6 = safe_sub_func_int16_t_s_s(g_6, 7))
    { /* block id: 5 */
        int32_t l_9[4] = {0x4C38B6B0L,0x4C38B6B0L,0x4C38B6B0L,0x4C38B6B0L};
        int i;
        l_9[0] = (254UL ^ g_3);
        g_10 = 0xC2251554L;
        for (g_3 = 0; (g_3 <= 3); g_3 += 1)
        { /* block id: 10 */
            int i;
            ++g_12;
            g_22 = (((safe_mul_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((func_19(l_9[g_3]) < 0x9F21C9B6CD04CD02LL), 1UL)) == g_10), 0L)) || l_9[g_3]) <= g_6);
        }
        if (g_12)
            continue;
    }
    return g_10;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes: g_12
 */
static int64_t  func_19(const uint32_t  p_20)
{ /* block id: 12 */
    int32_t l_21[4] = {1L,1L,1L,1L};
    int i;
    for (g_12 = 0; g_12 < 4; g_12 += 1)
    {
        l_21[g_12] = 0x82BA8D7DL;
    }
    return p_20;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 11
XXX times a non-volatile is write: 7
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 4
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 47.1
XXX percentage an existing variable is used: 52.9
********************* end of statistics **********************/

