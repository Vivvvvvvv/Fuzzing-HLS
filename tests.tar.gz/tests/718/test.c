/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8163947366272027374
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const volatile uint8_t  f0;
   volatile int8_t  f1;
   volatile int64_t  f2;
   const int32_t  f3;
   volatile uint32_t  f4;
   int64_t  f5;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_14 = 65532UL;
static int16_t g_30 = 0x8A2BL;
static int32_t g_42 = 1L;
static volatile uint64_t g_43 = 18446744073709551611UL;/* VOLATILE GLOBAL g_43 */
static struct S0 g_59 = {0xC5L,-10L,-1L,0xF3177355L,0x2C03FDDAL,0x8404D083830386B9LL};/* VOLATILE GLOBAL g_59 */
static struct S0 g_60 = {1UL,0L,-5L,5L,0xDDF936BBL,0x58509EF6E88F3C25LL};/* VOLATILE GLOBAL g_60 */
static uint32_t g_81 = 0x261C1CA3L;
static int8_t g_86[10][9] = {{7L,0L,0L,7L,0xB6L,0x35L,1L,6L,0L},{1L,0xB6L,0xC0L,0x35L,1L,0x35L,0xC0L,0xB6L,1L},{0L,6L,1L,0x35L,0xB6L,7L,0L,0L,7L},{0x35L,6L,0xC0L,7L,0x7AL,0x09L,0x09L,0x7AL,7L},{0L,0xB6L,0L,0x09L,5L,0xC0L,0x09L,0L,1L},{1L,0x35L,1L,0x36L,1L,1L,0x3FL,0x2AL,0x3FL},{0xB2L,0x09L,1L,1L,0x09L,0xB2L,0x36L,0L,(-1L)},{0xB2L,0x35L,0x3FL,0xB2L,0x2AL,(-1L),6L,0L,0x3FL},{6L,0x2AL,0x36L,(-1L),7L,(-1L),0x36L,0x2AL,6L},{0x3FL,0L,6L,(-1L),0x2AL,0xB2L,0x3FL,0x35L,0xB2L}};
static uint64_t g_87 = 6UL;
static volatile uint64_t g_101 = 0UL;/* VOLATILE GLOBAL g_101 */
static volatile uint16_t g_121 = 65535UL;/* VOLATILE GLOBAL g_121 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_2(uint8_t  p_3, uint32_t  p_4, uint8_t  p_5, const uint32_t  p_6, uint8_t  p_7);
static uint8_t  func_8(uint64_t  p_9, uint32_t  p_10, int64_t  p_11, uint16_t  p_12, int32_t  p_13);
static struct S0  func_21(uint32_t  p_22);
static int32_t  func_24(uint32_t  p_25, uint32_t  p_26, int32_t  p_27, uint32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_30 g_43 g_42 g_59 g_60 g_81 g_87 g_101 g_121
 * writes: g_30 g_42 g_43 g_81 g_59.f5 g_87 g_60.f5 g_101 g_121 g_60.f1 g_86
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_15 = 3L;
    int32_t l_124 = 0xABE801A4L;
    int32_t l_130 = 5L;
    uint8_t l_133 = 0x5AL;
    l_124 = func_2(func_8(g_14, g_14, l_15, l_15, g_14), l_15, l_15, l_15, g_59.f5);
    if ((~l_15))
    { /* block id: 102 */
        uint64_t l_128 = 0x623539A05EB5DA64LL;
        for (g_60.f5 = 0; (g_60.f5 > 16); g_60.f5++)
        { /* block id: 105 */
            int32_t l_129 = 1L;
            l_129 &= ((((g_60.f4 <= l_128) | g_59.f5) , 0x6BL) == g_42);
        }
        g_42 |= 0x7F04C0B5L;
        l_130 &= ((l_124 , l_15) >= (-1L));
    }
    else
    { /* block id: 110 */
        for (g_60.f1 = 0; g_60.f1 < 10; g_60.f1 += 1)
        {
            for (g_101 = 0; g_101 < 9; g_101 += 1)
            {
                g_86[g_60.f1][g_101] = (-6L);
            }
        }
    }
    if (((65529UL & (-4L)) , g_59.f5))
    { /* block id: 113 */
        int16_t l_131 = 0x304AL;
        int32_t l_132 = (-1L);
        for (l_124 = 8; (l_124 >= 2); l_124 -= 1)
        { /* block id: 116 */
            const uint32_t l_138 = 0x6559E358L;
            l_133--;
            g_42 = ((((((safe_div_func_int8_t_s_s(0x7CL, g_101)) >= l_138) ^ 0xB39CDCE6L) == 255UL) <= g_81) < g_42);
        }
    }
    else
    { /* block id: 120 */
        uint32_t l_139 = 18446744073709551615UL;
        g_42 &= l_139;
        l_130 |= l_133;
        return g_59.f4;
    }
    return l_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_59.f5 g_87 g_60.f0 g_42 g_60.f5 g_101 g_14 g_60.f2 g_30 g_60.f4 g_121
 * writes: g_59.f5 g_87 g_42 g_60.f5 g_101 g_30 g_121
 */
static int32_t  func_2(uint8_t  p_3, uint32_t  p_4, uint8_t  p_5, const uint32_t  p_6, uint8_t  p_7)
{ /* block id: 62 */
    int8_t l_98 = (-10L);
    int32_t l_99 = (-10L);
    int32_t l_100[2];
    int i;
    for (i = 0; i < 2; i++)
        l_100[i] = 1L;
    for (g_59.f5 = 0; (g_59.f5 == 19); g_59.f5 = safe_add_func_int64_t_s_s(g_59.f5, 7))
    { /* block id: 65 */
        for (p_4 = 1; (p_4 <= 8); p_4 += 1)
        { /* block id: 68 */
            --g_87;
        }
        g_42 |= (safe_mul_func_uint8_t_u_u(4UL, g_60.f0));
    }
    for (g_60.f5 = 23; (g_60.f5 < (-10)); g_60.f5 = safe_sub_func_int8_t_s_s(g_60.f5, 6))
    { /* block id: 75 */
        int32_t l_94[8][7][4] = {{{8L,0x4CAA1C64L,5L,5L},{0x2DE0B6ADL,0x2DE0B6ADL,0L,5L},{0x3EF0B8C2L,0x4CAA1C64L,(-6L),1L},{0x9D2B5444L,0x2B323EC0L,0L,(-6L)},{3L,0x2B323EC0L,5L,1L},{0x2B323EC0L,0x4CAA1C64L,0xE2876691L,5L},{3L,0x2DE0B6ADL,1L,5L}},{{0x9D2B5444L,0x4CAA1C64L,0xED6609A1L,1L},{0x3EF0B8C2L,0x2B323EC0L,1L,(-6L)},{0x2DE0B6ADL,0x2B323EC0L,0xE2876691L,1L},{8L,0x4CAA1C64L,5L,5L},{0x2DE0B6ADL,0x2DE0B6ADL,0L,5L},{0x3EF0B8C2L,0x4CAA1C64L,(-6L),1L},{0x9D2B5444L,0x2B323EC0L,0L,(-6L)}},{{3L,0x2B323EC0L,5L,1L},{0x2B323EC0L,0x4CAA1C64L,0xE2876691L,5L},{3L,0x2DE0B6ADL,1L,5L},{0x9D2B5444L,0x4CAA1C64L,0xED6609A1L,1L},{0x3EF0B8C2L,0x2B323EC0L,1L,(-6L)},{0x2DE0B6ADL,0x2B323EC0L,0xE2876691L,1L},{8L,0x4CAA1C64L,5L,5L}},{{0x2DE0B6ADL,0x2DE0B6ADL,0L,5L},{0x3EF0B8C2L,0x4CAA1C64L,(-6L),1L},{0x9D2B5444L,0x2B323EC0L,0L,(-6L)},{3L,0x2B323EC0L,5L,1L},{0x2B323EC0L,0x4CAA1C64L,0xE2876691L,5L},{3L,0x2DE0B6ADL,1L,5L},{0x9D2B5444L,0x4CAA1C64L,0xED6609A1L,1L}},{{0x3EF0B8C2L,0x2B323EC0L,1L,(-6L)},{0x2DE0B6ADL,0x2B323EC0L,0xE2876691L,1L},{8L,0x4CAA1C64L,5L,5L},{0x2DE0B6ADL,0x2DE0B6ADL,0L,5L},{0x3EF0B8C2L,0x4CAA1C64L,(-6L),1L},{0x9D2B5444L,0x2B323EC0L,0L,(-6L)},{3L,0x2B323EC0L,5L,1L}},{{0x2B323EC0L,0x4CAA1C64L,0xE2876691L,5L},{3L,0x2DE0B6ADL,1L,0x563F1C15L},{2L,0x2DE0B6ADL,0xE2876691L,(-6L)},{0L,0x9D2B5444L,(-6L),5L},{0x2B323EC0L,0x9D2B5444L,0xBBECB259L,(-6L)},{0x3EF0B8C2L,0x2DE0B6ADL,0x563F1C15L,0x563F1C15L},{0x2B323EC0L,0x2B323EC0L,0xED6609A1L,0x563F1C15L}},{{0L,0x2DE0B6ADL,5L,(-6L)},{2L,0x9D2B5444L,0xED6609A1L,5L},{8L,0x9D2B5444L,0x563F1C15L,(-6L)},{0x9D2B5444L,0x2DE0B6ADL,0xBBECB259L,0x563F1C15L},{8L,0x2B323EC0L,(-6L),0x563F1C15L},{2L,0x2DE0B6ADL,0xE2876691L,(-6L)},{0L,0x9D2B5444L,(-6L),5L}},{{0x2B323EC0L,0x9D2B5444L,0xBBECB259L,(-6L)},{0x3EF0B8C2L,0x2DE0B6ADL,0x563F1C15L,0x563F1C15L},{0x2B323EC0L,0x2B323EC0L,0xED6609A1L,0x563F1C15L},{0L,0x2DE0B6ADL,5L,(-6L)},{2L,0x9D2B5444L,0xED6609A1L,5L},{8L,0x9D2B5444L,0x563F1C15L,(-6L)},{0x9D2B5444L,0x2DE0B6ADL,0xBBECB259L,0x563F1C15L}}};
        int32_t l_95 = 0x9A04A83BL;
        int i, j, k;
        l_94[2][2][1] = p_3;
        l_95 = (((p_5 & 1L) , p_5) & 0x2F55L);
    }
    for (p_4 = (-12); (p_4 != 12); p_4 = safe_add_func_int8_t_s_s(p_4, 4))
    { /* block id: 81 */
        const uint32_t l_112 = 0x25B6AC95L;
        ++g_101;
        for (g_59.f5 = (-19); (g_59.f5 == 0); g_59.f5 = safe_add_func_uint16_t_u_u(g_59.f5, 1))
        { /* block id: 85 */
            uint64_t l_113 = 0xDD196261E54E034DLL;
            l_100[0] = (safe_div_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_s(((safe_rshift_func_int8_t_s_s((l_99 > l_112), 2)) , p_7), g_14)) != 0x47L), 18446744073709551608UL));
            l_113 = (g_60.f2 , p_3);
            g_42 = (l_112 == l_98);
        }
        l_99 ^= g_59.f5;
        for (g_30 = 0; (g_30 >= (-5)); --g_30)
        { /* block id: 93 */
            int16_t l_116 = (-9L);
            int32_t l_117 = 0x01541C76L;
            int32_t l_118 = 0x2B4E2EDBL;
            int32_t l_119 = 0xE0FD2558L;
            int32_t l_120[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i;
            g_42 |= (l_116 , g_60.f4);
            l_117 &= (0UL || 0x7DB561CB1BBB9F26LL);
            g_42 |= (p_3 | l_112);
            g_121++;
        }
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_30 g_43 g_42 g_59 g_60 g_81
 * writes: g_30 g_42 g_43 g_81
 */
static uint8_t  func_8(uint64_t  p_9, uint32_t  p_10, int64_t  p_11, uint16_t  p_12, int32_t  p_13)
{ /* block id: 1 */
    uint8_t l_23 = 0UL;
    int32_t l_72 = 0L;
    for (p_13 = (-8); (p_13 > (-1)); ++p_13)
    { /* block id: 4 */
        int16_t l_61 = 0x9EFAL;
        int32_t l_62[1][4] = {{(-9L),(-9L),(-9L),(-9L)}};
        int i, j;
        l_62[0][3] = ((safe_unary_minus_func_int32_t_s((safe_mul_func_uint8_t_u_u(((func_21(l_23) , 1UL) == l_61), 0xA0L)))) || l_23);
        if ((p_11 > l_23))
        { /* block id: 40 */
            l_62[0][2] = ((0x037BAD6EL <= p_9) || 0xF408L);
        }
        else
        { /* block id: 42 */
            g_42 = l_61;
        }
        if (l_23)
            continue;
    }
    for (g_42 = 0; (g_42 < (-19)); --g_42)
    { /* block id: 49 */
        int8_t l_75 = 0xBBL;
        l_72 = (((safe_sub_func_uint8_t_u_u((((safe_lshift_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((((safe_unary_minus_func_int32_t_s((-1L))) < 3UL) >= 0x91L), l_23)) > l_23), l_23)) < p_9) , p_12), g_60.f2)) ^ 0xBDD559FEL) | g_42);
        if (((safe_div_func_uint32_t_u_u(4294967295UL, l_75)) >= 0x92579B7BL))
        { /* block id: 51 */
            int8_t l_76 = 0xB5L;
            uint8_t l_79 = 0xE1L;
            if (g_60.f5)
                break;
            if (l_76)
                break;
            l_79 = ((((p_10 , l_75) ^ 0x9BL) == 0UL) >= (-2L));
            if (l_76)
                continue;
        }
        else
        { /* block id: 56 */
            uint16_t l_80 = 1UL;
            l_72 |= l_80;
            g_81++;
        }
    }
    return g_60.f1;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_30 g_43 g_42 g_59 g_60
 * writes: g_30 g_42 g_43
 */
static struct S0  func_21(uint32_t  p_22)
{ /* block id: 5 */
    int16_t l_29 = (-4L);
    int32_t l_58 = 0L;
    if (func_24(g_14, l_29, l_29, l_29))
    { /* block id: 26 */
        uint8_t l_54[2][8] = {{0xEAL,0xBBL,0xEAL,0xBBL,0xEAL,0xBBL,0xEAL,0xBBL},{0xEAL,0xBBL,0xEAL,0xBBL,0xEAL,0xBBL,0xEAL,0xBBL}};
        int32_t l_55 = 6L;
        int i, j;
        if ((((safe_div_func_uint8_t_u_u(1UL, p_22)) <= 0xEC02DFCEL) != l_29))
        { /* block id: 27 */
            uint16_t l_51 = 9UL;
            l_51 = (safe_add_func_uint8_t_u_u(g_42, 0x89L));
            l_55 &= (((safe_div_func_uint16_t_u_u(l_54[0][4], p_22)) , p_22) && l_51);
        }
        else
        { /* block id: 30 */
            l_55 = (safe_sub_func_int64_t_s_s(g_43, g_42));
        }
        l_55 &= 0xB42DCBDEL;
        l_58 ^= 0xB22C08F4L;
    }
    else
    { /* block id: 35 */
        return g_59;
    }
    return g_60;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_30 g_43 g_42
 * writes: g_30 g_42 g_43
 */
static int32_t  func_24(uint32_t  p_25, uint32_t  p_26, int32_t  p_27, uint32_t  p_28)
{ /* block id: 6 */
    int32_t l_46[4][6][1] = {{{(-1L)},{0x4DB503B5L},{1L},{0x4DB503B5L},{(-1L)},{0L}},{{(-1L)},{0x4DB503B5L},{1L},{0x4DB503B5L},{(-1L)},{0L}},{{(-1L)},{0x4DB503B5L},{1L},{0x4DB503B5L},{(-1L)},{0L}},{{(-1L)},{0x4DB503B5L},{1L},{0x4DB503B5L},{(-1L)},{0L}}};
    int i, j, k;
    g_30 = p_26;
    for (p_27 = 0; (p_27 == 20); p_27++)
    { /* block id: 10 */
        return p_28;
    }
    if (p_27)
    { /* block id: 13 */
        const uint32_t l_41 = 0xB58FE4DEL;
        for (p_26 = 0; (p_26 >= 16); p_26++)
        { /* block id: 16 */
            p_27 &= g_14;
            g_42 = (safe_lshift_func_int16_t_s_s((safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s(p_27, 0x2455L)), g_30)), l_41));
            g_43--;
            return p_26;
        }
    }
    else
    { /* block id: 22 */
        g_42 &= l_46[2][1][0];
    }
    return g_43;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_59.f0, "g_59.f0", print_hash_value);
    transparent_crc(g_59.f1, "g_59.f1", print_hash_value);
    transparent_crc(g_59.f2, "g_59.f2", print_hash_value);
    transparent_crc(g_59.f3, "g_59.f3", print_hash_value);
    transparent_crc(g_59.f4, "g_59.f4", print_hash_value);
    transparent_crc(g_59.f5, "g_59.f5", print_hash_value);
    transparent_crc(g_60.f0, "g_60.f0", print_hash_value);
    transparent_crc(g_60.f1, "g_60.f1", print_hash_value);
    transparent_crc(g_60.f2, "g_60.f2", print_hash_value);
    transparent_crc(g_60.f3, "g_60.f3", print_hash_value);
    transparent_crc(g_60.f4, "g_60.f4", print_hash_value);
    transparent_crc(g_60.f5, "g_60.f5", print_hash_value);
    transparent_crc(g_81, "g_81", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_86[i][j], "g_86[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_121, "g_121", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 45
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 72
   depth: 2, occurrence: 21
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 11, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 93
XXX times a non-volatile is write: 47
XXX times a volatile is read: 10
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 46
XXX percentage of non-volatile access: 91.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 71
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 28
   depth: 2, occurrence: 26

XXX percentage a fresh-made variable is used: 30.1
XXX percentage an existing variable is used: 69.9
********************* end of statistics **********************/

