/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      18196896793090447339
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const int32_t g_8 = 1L;
static int16_t g_13 = 0x609BL;
static uint32_t g_36[9] = {0x90D790F9L,5UL,0x90D790F9L,0x90D790F9L,5UL,0x90D790F9L,0x90D790F9L,5UL,0x90D790F9L};
static volatile int32_t g_41 = (-9L);/* VOLATILE GLOBAL g_41 */
static uint32_t g_60 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const int32_t  func_2(int32_t  p_3, uint16_t  p_4, uint64_t  p_5, const uint8_t  p_6);
static uint8_t  func_21(const uint32_t  p_22, const int64_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_36 g_41
 * writes: g_36 g_41 g_13 g_60
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int64_t l_7[5];
    uint16_t l_61 = 5UL;
    int i;
    for (i = 0; i < 5; i++)
        l_7[i] = 1L;
    g_60 = (func_2(l_7[2], l_7[2], l_7[4], g_8) , g_13);
    return l_61;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_13 g_36 g_41
 * writes: g_36 g_41 g_13
 */
static const int32_t  func_2(int32_t  p_3, uint16_t  p_4, uint64_t  p_5, const uint8_t  p_6)
{ /* block id: 1 */
    int8_t l_9 = 0L;
    int32_t l_12[10] = {0x5DA2282DL,(-5L),0x5DA2282DL,0x5DA2282DL,(-5L),0x5DA2282DL,0x5DA2282DL,(-5L),0x5DA2282DL,0x5DA2282DL};
    uint32_t l_24[1];
    int32_t l_55 = 0x3F0D2296L;
    int i;
    for (i = 0; i < 1; i++)
        l_24[i] = 0x162C5D17L;
    l_9 = (2L == g_8);
    for (p_3 = (-22); (p_3 <= 10); p_3 = safe_add_func_int16_t_s_s(p_3, 1))
    { /* block id: 5 */
        uint64_t l_14 = 0x6F885EA6EDAD94E8LL;
        --l_14;
        return l_12[5];
    }
    l_55 |= (safe_rshift_func_int16_t_s_s((safe_sub_func_uint8_t_u_u(func_21((((((0L == (-3L)) , p_5) < l_24[0]) == g_13) , p_3), g_8), l_12[4])), p_3));
    p_3 |= ((safe_rshift_func_int16_t_s_s(((safe_div_func_int64_t_s_s((g_8 != g_36[3]), 0x083361826471B2A1LL)) < 18446744073709551615UL), g_36[3])) , 0xC4BD4AC9L);
    return g_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_36 g_41 g_8
 * writes: g_36 g_41 g_13
 */
static uint8_t  func_21(const uint32_t  p_22, const int64_t  p_23)
{ /* block id: 9 */
    int32_t l_35 = 0x6CAE8EF3L;
    int32_t l_54 = 0xA4AEFC51L;
    if (((safe_sub_func_uint64_t_u_u((safe_mod_func_int32_t_s_s(((safe_lshift_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((safe_add_func_uint64_t_u_u(((0xF5C9L & g_13) || p_22), 1UL)), p_23)), 12)) || l_35), 1UL)), g_13)) == l_35))
    { /* block id: 10 */
        int8_t l_44 = 0x88L;
        --g_36[3];
        if (p_23)
            goto lbl_42;
lbl_42:
        g_41 = (safe_add_func_int64_t_s_s(g_36[3], g_41));
        for (g_13 = 0; (g_13 <= 8); g_13 += 1)
        { /* block id: 16 */
            int32_t l_45[3];
            int i;
            for (i = 0; i < 3; i++)
                l_45[i] = 0L;
            l_45[0] = (+((1L <= g_36[g_13]) , l_44));
            if (g_13)
                continue;
        }
    }
    else
    { /* block id: 20 */
        return g_8;
    }
    l_35 = (safe_unary_minus_func_uint32_t_u(((safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s((safe_unary_minus_func_int16_t_s(((safe_mul_func_uint8_t_u_u(l_35, p_23)) && p_23))), p_22)), 5)) <= p_23)));
    l_54 |= l_35;
    return l_35;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_36[i], "g_36[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 16
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 6, occurrence: 3
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 39
XXX times a non-volatile is write: 11
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 11
XXX percentage of non-volatile access: 96.2

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 7
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 31.4
XXX percentage an existing variable is used: 68.6
********************* end of statistics **********************/

