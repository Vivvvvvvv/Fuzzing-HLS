/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17075010177478634911
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = (-9L);/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[10] = {0L,0xDCEC3D7DL,0L,0L,0xDCEC3D7DL,0L,0L,0xDCEC3D7DL,0L,0L};
static volatile int32_t g_4 = 0L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5[9] = {0x4F402E31L,0x4F402E31L,0x4F402E31L,0x4F402E31L,0x4F402E31L,0x4F402E31L,0x4F402E31L,0x4F402E31L,0x4F402E31L};
static volatile int32_t g_31 = 0x8B421DD2L;/* VOLATILE GLOBAL g_31 */
static volatile int16_t g_40 = 0L;/* VOLATILE GLOBAL g_40 */
static int32_t g_60 = (-1L);
static int16_t g_95 = 1L;


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static uint16_t  func_8(uint32_t  p_9, int8_t  p_10, int8_t  p_11);
static uint32_t  func_12(int8_t  p_13, uint64_t  p_14, uint32_t  p_15, int8_t  p_16, int32_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_31 g_3 g_4 g_60
 * writes: g_5 g_4 g_3 g_60
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_32 = 9UL;
    uint8_t l_49 = 0xD4L;
    int32_t l_56 = 0x8B78E619L;
    int32_t l_65[9];
    int32_t l_81 = (-1L);
    uint16_t l_87[3];
    uint32_t l_90 = 0x5CB1E557L;
    int i;
    for (i = 0; i < 9; i++)
        l_65[i] = 0x770596CDL;
    for (i = 0; i < 3; i++)
        l_87[i] = 65529UL;
    for (g_5[4] = (-21); (g_5[4] > 17); ++g_5[4])
    { /* block id: 3 */
        int8_t l_30 = 0xF1L;
        int16_t l_47 = 0x8BB4L;
        int32_t l_61 = 0x896C2AECL;
        int32_t l_62 = 0xC5A51199L;
        int32_t l_63 = 0xE46D4517L;
        int32_t l_64 = 0xF4C81FA0L;
        int32_t l_66 = 8L;
        int32_t l_69 = 1L;
        int32_t l_79 = 0xE8CD9E3AL;
        int32_t l_82 = 0x79AB5F6EL;
        int64_t l_83 = 0x19BA6681F6C300DCLL;
        int64_t l_84 = (-1L);
        int32_t l_85 = 2L;
        int32_t l_86[7] = {0L,0L,(-1L),0L,0L,(-1L),0L};
        int i;
        if (((func_8((func_12((((safe_rshift_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint8_t_u_s((safe_rshift_func_int8_t_s_u((safe_mul_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u(l_30, g_31)) < g_5[0]), l_30)), g_5[4])), 0)), 0x96E86FF18EE85EC4LL)), 5)) != g_5[8]) , l_30), l_32, g_5[8], g_5[2], l_30) , l_30), l_32, l_32) != l_30) > 1UL))
        { /* block id: 12 */
            uint8_t l_48 = 255UL;
            l_47 = ((l_30 > 0x23L) && l_30);
            g_3[3] = (l_48 ^ 0xDE59L);
            g_4 = ((g_4 <= g_5[8]) > l_49);
            g_3[3] = (safe_unary_minus_func_int8_t_s(((safe_sub_func_int64_t_s_s((~((safe_mod_func_uint8_t_u_u(255UL, l_49)) == g_31)), l_48)) , 0xB4L)));
        }
        else
        { /* block id: 17 */
            uint32_t l_59 = 0x6704BC7FL;
            l_56 = l_30;
            g_60 &= (safe_rshift_func_int8_t_s_u((((((l_47 >= 0x621C2DF4L) ^ g_5[4]) < l_59) > g_3[3]) , g_4), 2));
            if (l_32)
                continue;
            g_3[6] = 0xADE8EBF9L;
        }
        for (l_32 = 3; (l_32 <= 9); l_32 += 1)
        { /* block id: 25 */
            int32_t l_67 = 3L;
            int32_t l_68 = (-1L);
            int32_t l_70 = (-7L);
            int32_t l_71 = (-10L);
            int32_t l_72 = 0xC104D70CL;
            int32_t l_73 = 1L;
            int32_t l_74 = (-1L);
            int32_t l_75 = 0xA05350A1L;
            int32_t l_76 = 0x92DB62A3L;
            int32_t l_77 = 0x44948823L;
            int32_t l_78 = 0L;
            int32_t l_80[9] = {0x6646FD81L,0x6646FD81L,0x6646FD81L,0x6646FD81L,0x6646FD81L,0x6646FD81L,0x6646FD81L,0x6646FD81L,0x6646FD81L};
            int i;
            l_87[0]++;
            l_90++;
            l_86[2] = ((safe_sub_func_int8_t_s_s((0xA8L > g_3[l_32]), g_5[6])) && l_87[1]);
        }
    }
    g_5[4] |= (l_87[2] == g_4);
    l_56 = (((((g_31 > g_5[3]) && l_65[5]) > l_56) & 0xB3AD1B98L) == l_81);
    if (((g_4 <= l_32) <= l_49))
    { /* block id: 33 */
        uint32_t l_96 = 0UL;
        l_96--;
    }
    else
    { /* block id: 35 */
        uint8_t l_99[4];
        int i;
        for (i = 0; i < 4; i++)
            l_99[i] = 0xF7L;
        l_65[5] = l_99[3];
    }
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_31 g_3
 * writes: g_4
 */
static uint16_t  func_8(uint32_t  p_9, int8_t  p_10, int8_t  p_11)
{ /* block id: 6 */
    const int32_t l_34[3] = {0x6E836EA0L,0x6E836EA0L,0x6E836EA0L};
    int32_t l_35 = 0x43F36FC7L;
    int32_t l_38 = 0xD4E785E8L;
    int32_t l_39[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int32_t l_41 = 0x7405EF11L;
    int32_t l_42[4];
    int16_t l_43 = (-10L);
    uint32_t l_44[8] = {0xFAB08463L,0xFAB08463L,0xFAB08463L,0xFAB08463L,0xFAB08463L,0xFAB08463L,0xFAB08463L,0xFAB08463L};
    int i;
    for (i = 0; i < 4; i++)
        l_42[i] = (-1L);
    l_35 = ((g_5[4] != l_34[2]) ^ p_10);
    l_35 &= (((p_9 != l_34[2]) , g_31) > 0x085BL);
    g_4 = ((((((((((safe_sub_func_int32_t_s_s(8L, p_11)) | g_3[3]) < 5L) <= p_10) , 0x187DL) != g_5[7]) , 0xB5L) & l_35) == g_5[8]) , p_11);
    l_44[7]++;
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_12(int8_t  p_13, uint64_t  p_14, uint32_t  p_15, int8_t  p_16, int32_t  p_17)
{ /* block id: 4 */
    int32_t l_33 = 3L;
    return l_33;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 50
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 21
breakdown:
   depth: 1, occurrence: 29
   depth: 2, occurrence: 4
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 11, occurrence: 1
   depth: 21, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 52
XXX times a non-volatile is write: 15
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 5
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 146
XXX percentage of non-volatile access: 80.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 26
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 4
   depth: 2, occurrence: 11

XXX percentage a fresh-made variable is used: 15.7
XXX percentage an existing variable is used: 84.3
********************* end of statistics **********************/

