/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8421142979737491430
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-6L);/* VOLATILE GLOBAL g_3 */
static uint64_t g_12 = 0x34B64B5C6F8B8AE5LL;
static volatile uint32_t g_26 = 18446744073709551608UL;/* VOLATILE GLOBAL g_26 */
static int64_t g_27 = 0x5E97312B948214D2LL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_12 g_26 g_27
 * writes: g_27
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int8_t l_4 = 5L;
    int32_t l_5 = (-6L);
    int32_t l_13 = 0xBA75A592L;
    uint64_t l_21 = 0x574B6046E74A6E8FLL;
    l_5 &= ((~g_3) & l_4);
    l_5 = (((safe_mod_func_int32_t_s_s((safe_sub_func_int64_t_s_s(((safe_mod_func_uint16_t_u_u((g_3 < 0x6881L), 0xA50BL)) || g_3), g_12)), 0xB8BFFBEFL)) == l_13) ^ g_12);
    l_5 ^= (safe_mul_func_int8_t_s_s(((safe_sub_func_int32_t_s_s((+(safe_mul_func_int8_t_s_s(g_3, g_12))), 0x1A1F0506L)) >= g_12), l_21));
    g_27 ^= (((safe_mod_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((l_21 || g_3), g_12)), g_12)) | (-1L)) && g_26);
    return l_5;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 5
   depth: 2, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 11
XXX times a non-volatile is write: 4
XXX times a volatile is read: 6
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 71.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 5
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 5

XXX percentage a fresh-made variable is used: 38.1
XXX percentage an existing variable is used: 61.9
********************* end of statistics **********************/

