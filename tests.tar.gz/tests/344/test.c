/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      8119101816779395583
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x7D490C4DL;
static int32_t g_4[1] = {(-1L)};
static uint16_t g_45[9] = {0x7F4BL,0x7F4BL,0xD3BCL,0x7F4BL,0x7F4BL,0xD3BCL,0x7F4BL,0x7F4BL,0xD3BCL};
static volatile uint32_t g_69 = 1UL;/* VOLATILE GLOBAL g_69 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint16_t  func_12(uint32_t  p_13, int32_t  p_14, uint32_t  p_15, int64_t  p_16, int16_t  p_17);
static int32_t  func_21(int32_t  p_22, uint64_t  p_23, const int32_t  p_24, int8_t  p_25, uint8_t  p_26);
static uint64_t  func_30(int16_t  p_31, int16_t  p_32, uint8_t  p_33, int32_t  p_34);
static int32_t  func_41(const int16_t  p_42, int8_t  p_43, uint32_t  p_44);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_45 g_69
 * writes: g_3 g_4 g_69
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[2];
    uint64_t l_200[10][3][3] = {{{1UL,1UL,0x8137182850D09B6BLL},{0UL,0UL,0UL},{0x2AF56C28166E1F47LL,0UL,1UL}},{{0UL,1UL,0x40EEDF8BB0FE6DB1LL},{0UL,0xC4F8BCC3EDE10461LL,18446744073709551607UL},{0x89E88DAE93E954DDLL,0x40EEDF8BB0FE6DB1LL,0x8AACF54AA532D318LL}},{{0UL,0x0857287BE3B7B518LL,7UL},{0UL,18446744073709551615UL,18446744073709551615UL},{0x2AF56C28166E1F47LL,18446744073709551607UL,0UL}},{{0UL,0x89E88DAE93E954DDLL,2UL},{1UL,18446744073709551614UL,0xBE8A3830032A9964LL},{0xAB01BE67839AE79DLL,9UL,0x1111A74DA8DAF7D2LL}},{{1UL,0x2AF56C28166E1F47LL,1UL},{0x89E88DAE93E954DDLL,18446744073709551615UL,0UL},{18446744073709551606UL,18446744073709551606UL,0x2AF56C28166E1F47LL}},{{0xAB01BE67839AE79DLL,0x1111A74DA8DAF7D2LL,0UL},{0xD3D24E7D5FC095F3LL,7UL,0UL},{0UL,1UL,0x89E88DAE93E954DDLL}},{{0x066AA7E0E8EB7F1ELL,0xD3D24E7D5FC095F3LL,0UL},{0x8AACF54AA532D318LL,9UL,0UL},{0x2AF56C28166E1F47LL,0x75CB11263A5290B0LL,0x2AF56C28166E1F47LL}},{{0x71D8DB5BBBAEF6CCLL,0x40EEDF8BB0FE6DB1LL,0UL},{18446744073709551614UL,18446744073709551606UL,1UL},{0x40EEDF8BB0FE6DB1LL,0x89E88DAE93E954DDLL,0xAB01BE67839AE79DLL}},{{0UL,1UL,0x8137182850D09B6BLL},{0x40EEDF8BB0FE6DB1LL,2UL,0xE4480C90BAB00908LL},{18446744073709551614UL,18446744073709551607UL,18446744073709551607UL}},{{0x71D8DB5BBBAEF6CCLL,0xAB01BE67839AE79DLL,0x1111A74DA8DAF7D2LL},{0x2AF56C28166E1F47LL,0UL,0xC4F8BCC3EDE10461LL},{0x8AACF54AA532D318LL,0x937EDC5DE54D68BALL,9UL}}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2[i] = 0L;
    for (g_3 = 1; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        const uint16_t l_7[3][5] = {{3UL,3UL,3UL,3UL,3UL},{0xF7E7L,65535UL,0xF7E7L,65535UL,0xF7E7L},{3UL,3UL,3UL,3UL,3UL}};
        uint8_t l_8 = 2UL;
        int i, j;
        for (g_4[0] = 1; (g_4[0] >= 0); g_4[0] -= 1)
        { /* block id: 6 */
            int i;
            l_2[g_3] = l_2[g_4[0]];
            if (g_3)
                continue;
        }
        g_4[0] = ((safe_rshift_func_int16_t_s_s((l_7[1][0] && g_4[0]), l_8)) | 0xF8EE1D11023DCDF5LL);
    }
    for (g_3 = 1; (g_3 >= 0); g_3 -= 1)
    { /* block id: 14 */
        int64_t l_9[9][8][3] = {{{0xCAA7A7558CD180C4LL,0L,0x03CFCB8F1FE3D2F5LL},{(-1L),0x38976CC22523F84ELL,(-10L)},{(-2L),0xCAA7A7558CD180C4LL,(-9L)},{0xF71D691704D9FABALL,1L,(-1L)},{0L,0xEB2FC257A10DD664LL,(-1L)},{0x54E3F1571C097BC8LL,(-10L),0x1372625AA9C4AD15LL},{0x99B6F36082240A49LL,0x54E3F1571C097BC8LL,0x54E3F1571C097BC8LL},{0xCA5AAD5032406135LL,0L,0xC1ED5297F1FF7CD2LL}},{{0x883475F5401BC10BLL,4L,(-1L)},{0x0E03A8461A3ECB10LL,0xF11EAE5249F3923BLL,0x187D7A760E0689BBLL},{5L,0x337672A6DFE1602ALL,0L},{(-1L),0xF11EAE5249F3923BLL,(-1L)},{0x59C3CBAA6F4ED832LL,4L,1L},{(-10L),0L,0xFB84C81E2E8C41CELL},{0xF11EAE5249F3923BLL,0x54E3F1571C097BC8LL,0x2095D7C1543F36FCLL},{3L,(-10L),(-9L)}},{{0x0E03A8461A3ECB10LL,0xEB2FC257A10DD664LL,(-7L)},{0x3F4B1A25D0016D17LL,1L,0x7FD5D1AFC438F874LL},{0x54E3F1571C097BC8LL,0xCAA7A7558CD180C4LL,0xCA0702DD0685B90CLL},{0x86FF18EE85EC4150LL,0x38976CC22523F84ELL,0xCA5AAD5032406135LL},{0x38976CC22523F84ELL,0L,(-1L)},{0xCCE3F50E16FFA942LL,(-1L),0xC1ED5297F1FF7CD2LL},{6L,1L,0x187D7A760E0689BBLL},{(-2L),0x59E0EA8EDF97EF3ALL,(-1L)}},{{1L,(-1L),0x7FD5D1AFC438F874LL},{0x59C3CBAA6F4ED832LL,6L,0L},{0x59C3CBAA6F4ED832LL,0x8D6DB9E588CE324ELL,(-2L)},{1L,0x54E3F1571C097BC8LL,(-1L)},{(-2L),0x59C3CBAA6F4ED832LL,0x03CFCB8F1FE3D2F5LL},{6L,1L,(-7L)},{0xCCE3F50E16FFA942LL,0xEB2FC257A10DD664LL,0xEFA766E9B1CC8FFCLL},{0x38976CC22523F84ELL,0xAB91EE328DB1AE9CLL,0L}},{{0x86FF18EE85EC4150LL,0xCA5AAD5032406135LL,0x54E3F1571C097BC8LL},{0x54E3F1571C097BC8LL,0x8D6DB9E588CE324ELL,0xF11EAE5249F3923BLL},{0x3F4B1A25D0016D17LL,(-1L),(-1L)},{0x0E03A8461A3ECB10LL,(-1L),0x9ACB085BB31CF6A1LL},{3L,0x1ACAE7BF199314E7LL,(-1L)},{0xF11EAE5249F3923BLL,0xF11EAE5249F3923BLL,0xEFA766E9B1CC8FFCLL},{(-10L),0xE755073046773196LL,(-1L)},{0x59C3CBAA6F4ED832LL,0x9C089CED66E5DC64LL,0xFB84C81E2E8C41CELL}},{{(-1L),0x38976CC22523F84ELL,(-9L)},{(-1L),6L,0xE755073046773196LL},{0x925F321EE01E6E83LL,0L,(-1L)},{0x03CFCB8F1FE3D2F5LL,0L,0xCAA7A7558CD180C4LL},{8L,0x4939E63A5BED8572LL,0xCCE3F50E16FFA942LL},{(-1L),1L,0L},{1L,4L,0x337672A6DFE1602ALL},{3L,0x54E3F1571C097BC8LL,0xBBC76156DD1A6511LL}},{{0xD4E785E8A77F2A5CLL,0x337672A6DFE1602ALL,1L},{0L,0xAB91EE328DB1AE9CLL,(-2L)},{0x7FD5D1AFC438F874LL,(-1L),0xCAA7A7558CD180C4LL},{0x4939E63A5BED8572LL,(-9L),0x1372625AA9C4AD15LL},{1L,(-1L),(-10L)},{0x337672A6DFE1602ALL,8L,1L},{0xE755073046773196LL,1L,0L},{0xD4E785E8A77F2A5CLL,0L,(-5L)}},{{0x48103B8AF769BF4ALL,0L,0xA4ACF27260E96087LL},{1L,1L,0xCCE3F50E16FFA942LL},{(-1L),8L,(-1L)},{0x86FF18EE85EC4150LL,(-1L),0xEFA766E9B1CC8FFCLL},{3L,(-9L),0x337672A6DFE1602ALL},{1L,(-1L),8L},{(-1L),0xAB91EE328DB1AE9CLL,0x883475F5401BC10BLL},{0xBBC76156DD1A6511LL,0x337672A6DFE1602ALL,0xA4ACF27260E96087LL}},{{0xCAF8A8FF013EC5CBLL,0x54E3F1571C097BC8LL,0x1372625AA9C4AD15LL},{0x4939E63A5BED8572LL,4L,6L},{(-1L),1L,0x187D7A760E0689BBLL},{0xE755073046773196LL,0x4939E63A5BED8572LL,0xE755073046773196LL},{1L,0L,1L},{0xFB84C81E2E8C41CELL,0L,0xAB91EE328DB1AE9CLL},{8L,6L,(-2L)},{0xC1ED5297F1FF7CD2LL,0x86FF18EE85EC4150LL,(-1L)}}};
        int i, j, k;
        if ((l_9[0][3][0] & l_2[0]))
        { /* block id: 15 */
            uint8_t l_18 = 0xA2L;
            int i;
            l_2[g_3] = ((safe_add_func_uint16_t_u_u(func_12(g_4[0], g_4[0], l_18, l_9[2][5][0], g_3), l_18)) < l_18);
        }
        else
        { /* block id: 154 */
            int32_t l_199 = 0xB0659AA5L;
            return l_199;
        }
    }
    --l_200[5][2][0];
    return g_45[7];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_45 g_3 g_69
 * writes: g_4 g_69
 */
static uint16_t  func_12(uint32_t  p_13, int32_t  p_14, uint32_t  p_15, int64_t  p_16, int16_t  p_17)
{ /* block id: 16 */
    int16_t l_27 = 0x53ACL;
    int16_t l_198 = (-2L);
    for (p_14 = 0; (p_14 >= 9); ++p_14)
    { /* block id: 19 */
        uint16_t l_28 = 1UL;
        g_4[0] = func_21(p_14, l_27, l_27, g_4[0], l_28);
        for (p_16 = 0; (p_16 >= (-1)); --p_16)
        { /* block id: 145 */
            uint16_t l_193 = 0x3EA1L;
            --l_193;
            if (l_28)
                continue;
        }
        if (p_16)
            break;
    }
    l_198 = ((((((((safe_div_func_int64_t_s_s(8L, p_17)) || l_27) ^ p_14) , g_4[0]) & p_14) < l_27) <= 0x2CE60B54L) , g_45[7]);
    return g_45[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_45 g_3 g_69
 * writes: g_4 g_69
 */
static int32_t  func_21(int32_t  p_22, uint64_t  p_23, const int32_t  p_24, int8_t  p_25, uint8_t  p_26)
{ /* block id: 20 */
    int32_t l_37 = (-1L);
    int32_t l_159 = 0xC192606FL;
    int32_t l_160 = 0x5C1137C9L;
    int32_t l_167 = 0L;
    int32_t l_168 = 0x533BD15AL;
    int32_t l_169 = 0xDB31E990L;
    int32_t l_170 = 0x62E7AD90L;
    int32_t l_171 = 1L;
    int32_t l_172 = 0x7D022C06L;
    int8_t l_173 = 1L;
    int32_t l_174 = (-1L);
    int32_t l_175 = 0xBAF6A023L;
    int32_t l_176 = 1L;
    int32_t l_177 = 6L;
    int32_t l_178 = (-1L);
    uint16_t l_179 = 0xFD16L;
    l_159 &= (safe_unary_minus_func_uint64_t_u(func_30((safe_lshift_func_int16_t_s_u(((l_37 >= 0UL) ^ p_25), 14)), l_37, p_25, l_37)));
    if ((l_160 | 0x8DL))
    { /* block id: 123 */
        int16_t l_163 = 0x7D4FL;
        int32_t l_164 = 0x2081EC9BL;
        int32_t l_165 = 1L;
        int32_t l_166[4][10][5] = {{{(-6L),(-1L),0x529AC428L,0x6689637CL,0xCA45F45CL},{0x7CF0FDF5L,(-1L),0x41AB9D19L,2L,(-4L)},{0xFFD0D496L,0L,0x5A4DF937L,(-1L),0x2983A2AAL},{0x7CF0FDF5L,0xAEDB5F2BL,(-1L),0L,0x2983A2AAL},{(-6L),0x5952B64FL,0x15410983L,0L,(-4L)},{5L,0L,(-1L),0L,0xCA45F45CL},{(-1L),(-10L),(-1L),(-1L),(-6L)},{0x67BA3AC3L,2L,0x15410983L,2L,0x67BA3AC3L},{0x0E0DADD7L,(-10L),(-1L),0x6689637CL,5L},{0x0E0DADD7L,0L,0x5A4DF937L,0xAEDB5F2BL,0x9B31E182L}},{{0x67BA3AC3L,0x5952B64FL,0x41AB9D19L,(-10L),5L},{(-1L),0xAEDB5F2BL,0x529AC428L,(-10L),0x67BA3AC3L},{5L,0L,0L,0xAEDB5F2BL,(-6L)},{(-6L),(-1L),0x529AC428L,0x6689637CL,0xCA45F45CL},{0x7CF0FDF5L,(-1L),0x41AB9D19L,2L,(-4L)},{0xFFD0D496L,0L,0x5A4DF937L,(-1L),0x2983A2AAL},{0x7CF0FDF5L,0xAEDB5F2BL,(-1L),0L,0x2983A2AAL},{(-6L),0x5952B64FL,0x15410983L,0L,(-4L)},{5L,0L,(-1L),0L,0xCA45F45CL},{(-1L),0x5E2F4CB5L,0x2817E8D0L,0L,(-1L)}},{{0xAEDB5F2BL,0x1B4E1750L,1L,0x1B4E1750L,0xAEDB5F2BL},{(-10L),0x5E2F4CB5L,1L,4L,2L},{(-10L),0x0840576BL,0L,0x31644C7AL,0L},{0xAEDB5F2BL,0xA892371FL,(-8L),0x5E2F4CB5L,2L},{0x6689637CL,0x31644C7AL,0x277215B5L,0x5E2F4CB5L,0xAEDB5F2BL},{2L,(-1L),0xED9B6530L,0x31644C7AL,(-1L)},{(-1L),1L,0x277215B5L,4L,0x58CB6D31L},{0L,1L,(-8L),0x1B4E1750L,1L},{0L,(-1L),0L,0L,0x5952B64FL},{0L,0x31644C7AL,1L,0x7EB90BE4L,0x5952B64FL}},{{(-1L),0xA892371FL,1L,0x0840576BL,1L},{2L,0x0840576BL,0x2817E8D0L,0x7EB90BE4L,0x58CB6D31L},{0x6689637CL,0x5E2F4CB5L,0x2817E8D0L,0L,(-1L)},{0xAEDB5F2BL,0x1B4E1750L,1L,0x1B4E1750L,0xAEDB5F2BL},{(-10L),0x5E2F4CB5L,1L,4L,2L},{(-10L),0x0840576BL,0L,0x31644C7AL,0L},{0xAEDB5F2BL,0xA892371FL,(-8L),0x5E2F4CB5L,2L},{0x6689637CL,0x31644C7AL,0x277215B5L,0x5E2F4CB5L,0xAEDB5F2BL},{2L,(-1L),0xED9B6530L,0x31644C7AL,(-1L)},{(-1L),1L,0x277215B5L,4L,0x58CB6D31L}}};
        int i, j, k;
        l_163 = (safe_add_func_int8_t_s_s((g_4[0] >= p_24), 1UL));
        l_179--;
        for (l_177 = 9; (l_177 < (-13)); l_177--)
        { /* block id: 128 */
            l_37 = (0x63L < p_25);
        }
    }
    else
    { /* block id: 131 */
        g_4[0] |= (safe_unary_minus_func_int32_t_s(l_177));
    }
    l_169 = (safe_div_func_int32_t_s_s(0x55DE64BFL, p_26));
    for (l_176 = (-9); (l_176 == 29); l_176++)
    { /* block id: 137 */
        g_4[0] ^= ((safe_sub_func_int64_t_s_s((p_25 > 1UL), g_45[7])) < l_174);
        if (p_26)
            break;
    }
    return p_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_45 g_3 g_69
 * writes: g_4 g_69
 */
static uint64_t  func_30(int16_t  p_31, int16_t  p_32, uint8_t  p_33, int32_t  p_34)
{ /* block id: 21 */
    int16_t l_46 = 0xF3B0L;
    int64_t l_139 = 0x3495DE3CFF6BEFEFLL;
    p_34 = (+((safe_mul_func_uint8_t_u_u((func_41(g_4[0], g_45[7], l_46) , 0x95L), l_46)) , 0x651CL));
    for (p_31 = 0; (p_31 <= (-6)); p_31--)
    { /* block id: 80 */
        uint16_t l_125 = 0x9528L;
        int64_t l_132 = (-9L);
        int32_t l_135 = 0L;
        int8_t l_136 = (-1L);
        if (g_45[7])
            break;
        p_34 = l_125;
        if (((g_45[4] < p_33) <= g_69))
        { /* block id: 83 */
            g_4[0] = (((-1L) | 0xD1L) ^ p_31);
            if (g_69)
                break;
            p_34 = ((((safe_mul_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((l_125 > l_46), g_45[6])), g_4[0])) || 0x53L) ^ 18446744073709551613UL) || p_33);
        }
        else
        { /* block id: 87 */
            return l_125;
        }
        if ((safe_mul_func_int16_t_s_s(((g_45[2] == p_33) ^ g_3), l_125)))
        { /* block id: 90 */
            l_132 = (-1L);
            l_135 = ((safe_sub_func_uint16_t_u_u(1UL, p_33)) & p_32);
            l_136 |= 6L;
        }
        else
        { /* block id: 94 */
            l_135 = ((safe_div_func_int8_t_s_s(((1UL && g_45[7]) > 0x5DL), g_45[4])) ^ g_45[1]);
            return l_139;
        }
    }
    if ((safe_mul_func_int8_t_s_s(((safe_div_func_int16_t_s_s((safe_rshift_func_int8_t_s_s(((0L == l_139) && 4294967295UL), 5)), p_33)) < l_46), 0x6FL)))
    { /* block id: 99 */
        int16_t l_150 = 0x345AL;
        int32_t l_158[7] = {0x718FD21FL,0L,0x718FD21FL,0x718FD21FL,0L,0x718FD21FL,0x718FD21FL};
        int i;
        for (p_33 = 0; (p_33 <= 0); p_33 += 1)
        { /* block id: 102 */
            int i;
            g_4[p_33] = 1L;
            return p_34;
        }
        if ((g_45[7] , l_139))
        { /* block id: 106 */
            uint16_t l_146 = 65535UL;
            return l_146;
        }
        else
        { /* block id: 108 */
            int16_t l_147 = 0xAFC3L;
            l_147 &= p_31;
        }
        for (l_46 = 0; (l_46 <= (-3)); --l_46)
        { /* block id: 113 */
            int32_t l_153 = 8L;
            l_150 ^= p_32;
            g_4[0] = (safe_lshift_func_uint8_t_u_u(l_153, 1));
            l_158[1] = ((((((safe_rshift_func_int8_t_s_u((((safe_add_func_uint64_t_u_u(p_33, 18446744073709551615UL)) || 249UL) | l_46), 5)) ^ g_4[0]) || p_32) & l_46) == g_69) || p_32);
        }
    }
    else
    { /* block id: 118 */
        return g_3;
    }
    return g_45[8];
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_69 g_45
 * writes: g_4 g_69
 */
static int32_t  func_41(const int16_t  p_42, int8_t  p_43, uint32_t  p_44)
{ /* block id: 22 */
    uint64_t l_49 = 18446744073709551608UL;
    int32_t l_52 = 3L;
    uint32_t l_54 = 0xB6559726L;
    int32_t l_57[1][8][5] = {{{3L,3L,0xC104D70CL,1L,0xDD4F1ACCL},{0xDAFA0740L,0xDE8027EFL,0xC104D70CL,(-1L),0x8C13D3DFL},{(-3L),0xC104D70CL,1L,0xC104D70CL,(-3L)},{1L,0xDE8027EFL,0xDD4F1ACCL,(-3L),3L},{1L,3L,0x8C13D3DFL,0L,0L},{(-3L),0x0A67ACB2L,(-3L),0xDE8027EFL,3L},{0xDAFA0740L,0L,3L,0xDE8027EFL,(-3L)},{3L,0x8C13D3DFL,0L,0L,0x8C13D3DFL}}};
    uint16_t l_63 = 1UL;
    uint16_t l_110[10][5] = {{7UL,0x3EBCL,0UL,0x0B7EL,0xEA6CL},{1UL,0x3EBCL,0x0B7EL,0x98F1L,0xBBACL},{1UL,7UL,7UL,1UL,0x98F1L},{1UL,65532UL,0xEA6CL,0xC7B4L,0x98F1L},{7UL,1UL,0xBBACL,0UL,0xBBACL},{0UL,0UL,0x98F1L,0xC7B4L,0xEA6CL},{0xCAB3L,1UL,0x98F1L,1UL,7UL},{0x0B7EL,0x98F1L,0xBBACL,0x98F1L,0x0B7EL},{1UL,0x3EBCL,0xBBACL,65532UL,0x98F1L},{1UL,0x98F1L,1UL,7UL,7UL}};
    int i, j, k;
    if ((safe_mul_func_uint16_t_u_u(0UL, 0x7B8DL)))
    { /* block id: 23 */
        int32_t l_53 = 0x65123592L;
        for (p_43 = 0; (p_43 <= 0); p_43 += 1)
        { /* block id: 26 */
            int i;
            --l_49;
            l_52 ^= g_4[p_43];
            l_53 = 1L;
        }
        l_53 = g_3;
    }
    else
    { /* block id: 32 */
        int64_t l_62[7][8][4] = {{{0x34BCD69959C8172FLL,0x879AB5F6EBE0C2A5LL,(-1L),(-1L)},{0x3B49DBEB4C716920LL,0x2D6ACBD7FBB02A76LL,(-3L),1L},{0x0331C24E8149F6EFLL,0L,(-2L),0L},{0xBC845C4EFE4AB8F1LL,0x0331C24E8149F6EFLL,0x34BCD69959C8172FLL,0x16F03433D00A1141LL},{0L,0x159DA389B2D0C04BLL,0x2F72018FE19D4D99LL,(-3L)},{0L,0xDA2C71B4AC46EA07LL,0L,(-1L)},{0L,0L,0x2F72018FE19D4D99LL,(-2L)},{0L,(-1L),0x34BCD69959C8172FLL,(-6L)}},{{0xBC845C4EFE4AB8F1LL,0x0DCE920F6FD10EC6LL,(-2L),0x6B2362835DF1A5E6LL},{0x0331C24E8149F6EFLL,0L,(-3L),0xFBA41DA8E33F4106LL},{0x3B49DBEB4C716920LL,0xBC845C4EFE4AB8F1LL,(-1L),1L},{0x34BCD69959C8172FLL,1L,(-6L),0L},{(-3L),0L,0xFBA41DA8E33F4106LL,0x13A919A52CA836B0LL},{(-1L),0x3B49DBEB4C716920LL,8L,0L},{0x2D6ACBD7FBB02A76LL,0x16F03433D00A1141LL,0x16F03433D00A1141LL,0x2D6ACBD7FBB02A76LL},{8L,0xE692E2E775698991LL,0x159DA389B2D0C04BLL,0L}},{{0x53400617AC7FE344LL,2L,0xBC845C4EFE4AB8F1LL,0x9AE76D89E43F1B08LL},{0x0DCE920F6FD10EC6LL,(-1L),0L,0x9AE76D89E43F1B08LL},{(-6L),2L,0xDA2C71B4AC46EA07LL,0L},{0L,0xE692E2E775698991LL,(-3L),0x2D6ACBD7FBB02A76LL},{(-3L),0x16F03433D00A1141LL,0x53400617AC7FE344LL,0L},{2L,0x3B49DBEB4C716920LL,0L,0x13A919A52CA836B0LL},{(-5L),0L,0L,0L},{1L,1L,0L,1L}},{{0x16F03433D00A1141LL,0xBC845C4EFE4AB8F1LL,0x879AB5F6EBE0C2A5LL,0xFBA41DA8E33F4106LL},{(-1L),0L,0x533FF6D77719BA66LL,0x6B2362835DF1A5E6LL},{0x6B2362835DF1A5E6LL,0x0DCE920F6FD10EC6LL,0x6B2362835DF1A5E6LL,(-6L)},{0x13A919A52CA836B0LL,(-1L),1L,(-2L)},{0x15CB1E5577DD4330LL,0L,0x0DCE920F6FD10EC6LL,(-1L)},{(-2L),0xDA2C71B4AC46EA07LL,0x0DCE920F6FD10EC6LL,(-3L)},{0x15CB1E5577DD4330LL,0x159DA389B2D0C04BLL,1L,0x16F03433D00A1141LL},{0x13A919A52CA836B0LL,0x0331C24E8149F6EFLL,0x6B2362835DF1A5E6LL,0L}},{{0x6B2362835DF1A5E6LL,0L,0x533FF6D77719BA66LL,1L},{(-1L),0x2D6ACBD7FBB02A76LL,0x879AB5F6EBE0C2A5LL,(-1L)},{0x16F03433D00A1141LL,0x879AB5F6EBE0C2A5LL,0L,8L},{1L,0L,0L,0x159DA389B2D0C04BLL},{(-5L),0x15CB1E5577DD4330LL,0L,1L},{2L,0xFBA41DA8E33F4106LL,0x53400617AC7FE344LL,0x53400617AC7FE344LL},{(-3L),(-3L),(-3L),0x879AB5F6EBE0C2A5LL},{0L,0x9B0DE559458B2590LL,0xDA2C71B4AC46EA07LL,0xE692E2E775698991LL}},{{(-6L),0x53400617AC7FE344LL,0L,0xDA2C71B4AC46EA07LL},{0x0DCE920F6FD10EC6LL,0x53400617AC7FE344LL,0xBC845C4EFE4AB8F1LL,0xE692E2E775698991LL},{0x53400617AC7FE344LL,0x9B0DE559458B2590LL,0x159DA389B2D0C04BLL,0x879AB5F6EBE0C2A5LL},{8L,(-3L),0x16F03433D00A1141LL,0x53400617AC7FE344LL},{0x2D6ACBD7FBB02A76LL,0xFBA41DA8E33F4106LL,8L,1L},{(-1L),(-1L),8L,0L},{(-1L),1L,0x34BCD69959C8172FLL,0x879AB5F6EBE0C2A5LL},{0xFB358544ED18BB67LL,0L,0x9AE76D89E43F1B08LL,1L}},{{(-2L),1L,(-1L),0x13A919A52CA836B0LL},{0x2F72018FE19D4D99LL,(-1L),0x533FF6D77719BA66LL,(-1L)},{0L,0x2F72018FE19D4D99LL,0xFB358544ED18BB67LL,0xFBA41DA8E33F4106LL},{0xE17020143C861C60LL,0L,(-3L),0L},{(-6L),(-3L),0L,0x2D6ACBD7FBB02A76LL},{(-6L),0L,(-3L),0x533FF6D77719BA66LL},{0xE17020143C861C60LL,0x2D6ACBD7FBB02A76LL,0xFB358544ED18BB67LL,0x34BCD69959C8172FLL},{0L,0xBC845C4EFE4AB8F1LL,0x533FF6D77719BA66LL,0x0331C24E8149F6EFLL}}};
        int32_t l_64 = 0xBF33FD12L;
        int32_t l_65 = 0x396B2AA0L;
        int32_t l_67 = 0L;
        int32_t l_76 = 7L;
        int32_t l_79 = (-10L);
        int32_t l_81 = 0L;
        int32_t l_83 = 0L;
        int32_t l_84 = 0xEEB8BFCCL;
        int32_t l_85[10][5] = {{0x9CB0568AL,0x219CEA36L,0x6848A1D8L,0x9CB0568AL,0x24FECDA2L},{0xDED58DE0L,0x6848A1D8L,0x6848A1D8L,0xDED58DE0L,0xC9816240L},{0xDED58DE0L,0x219CEA36L,0x061E0673L,0xDED58DE0L,0x24FECDA2L},{0x9CB0568AL,0x219CEA36L,0x6848A1D8L,0x9CB0568AL,0x24FECDA2L},{0xDED58DE0L,0x6848A1D8L,0x6848A1D8L,0xDED58DE0L,0xC9816240L},{0xDED58DE0L,0x219CEA36L,0x061E0673L,0xDED58DE0L,0x24FECDA2L},{0x9CB0568AL,0x219CEA36L,0x6848A1D8L,0x9CB0568AL,0x24FECDA2L},{0xDED58DE0L,0x6848A1D8L,0x6848A1D8L,0xDED58DE0L,0xC9816240L},{0xDED58DE0L,0x219CEA36L,0x061E0673L,0xDED58DE0L,0x24FECDA2L},{0x9CB0568AL,0x219CEA36L,0x6848A1D8L,0x9CB0568AL,0x24FECDA2L}};
        int i, j, k;
        l_54 = (l_49 , p_42);
        for (l_52 = 0; (l_52 == (-26)); l_52--)
        { /* block id: 36 */
            int8_t l_61[7][7][4] = {{{0L,1L,(-3L),8L},{(-5L),0L,(-5L),0x6CL},{(-1L),0xA0L,0xC3L,1L},{0x88L,(-5L),8L,0xA0L},{0x35L,(-7L),8L,0xE8L},{0x88L,0x4DL,0xC3L,0xC3L},{(-1L),(-1L),(-5L),0x35L}},{{(-5L),0x35L,(-3L),0L},{0L,7L,(-1L),(-3L)},{0L,7L,(-1L),0L},{7L,0x35L,0x6CL,0x35L},{0x59L,(-1L),0xA0L,0xC3L},{0x6CL,0x4DL,(-7L),0xE8L},{0xC3L,(-7L),7L,0xA0L}},{{0xC3L,(-5L),(-7L),1L},{0x6CL,0xA0L,0xA0L,0x6CL},{0x59L,0L,0x6CL,8L},{7L,1L,(-1L),0x88L},{0L,0xE8L,(-1L),0x88L},{0L,1L,(-3L),8L},{(-5L),0L,(-5L),0x6CL}},{{(-1L),0xA0L,0xC3L,1L},{0x88L,(-5L),8L,0xA0L},{0x35L,(-7L),8L,0xE8L},{0x88L,0x4DL,0x6CL,0x6CL},{0L,0L,0x59L,0xA0L},{0x59L,0xA0L,7L,(-7L)},{(-7L),0x35L,0L,7L}},{{0xE3L,0x35L,0L,(-7L)},{0x35L,0xA0L,(-5L),0xA0L},{1L,0L,(-1L),0x6CL},{(-5L),0xE8L,0x88L,(-1L)},{0x6CL,0x88L,0x35L,(-1L)},{0x6CL,0x59L,0x88L,(-3L)},{(-5L),(-1L),(-1L),(-5L)}},{{1L,(-7L),(-5L),0xC3L},{0x35L,(-3L),0L,8L},{0xE3L,(-1L),0L,8L},{(-7L),(-3L),7L,0xC3L},{0x59L,(-7L),0x59L,(-5L)},{0L,(-1L),0x6CL,(-3L)},{8L,0x59L,0xC3L,(-1L)}},{{0xA0L,0x88L,0xC3L,(-1L)},{8L,0xE8L,0x6CL,0x6CL},{0L,0L,0x59L,0xA0L},{0x59L,0xA0L,7L,(-7L)},{(-7L),0x35L,0L,7L},{0xE3L,0x35L,0L,(-7L)},{0x35L,0xA0L,(-5L),0xA0L}}};
            int i, j, k;
            l_57[0][3][4] = 0x263F48BFL;
            l_62[5][4][1] &= ((+((safe_mul_func_int16_t_s_s(p_43, l_61[0][1][2])) ^ 0L)) == l_61[0][1][2]);
            g_4[0] = (l_54 && 0x68DCC552L);
        }
        if ((((p_43 , 1UL) <= 0UL) < g_4[0]))
        { /* block id: 41 */
            int32_t l_66 = 7L;
            int32_t l_68 = 0xBBA98850L;
            l_52 = l_63;
            g_69--;
            return p_42;
        }
        else
        { /* block id: 45 */
            int32_t l_74 = 0x5F837D81L;
            int32_t l_75 = 1L;
            int32_t l_77 = 0L;
            int32_t l_78 = 0x2F1DAB3DL;
            int32_t l_80 = 0x170729E3L;
            int8_t l_82 = 0x3CL;
            int32_t l_86 = 0xB806CA93L;
            int32_t l_87 = 0L;
            uint8_t l_88 = 251UL;
            l_67 = (safe_sub_func_uint16_t_u_u(((65535UL <= 1L) <= 0x51L), g_45[0]));
            l_75 &= (l_74 | l_52);
            l_88--;
        }
    }
    for (l_49 = 0; (l_49 > 57); l_49 = safe_add_func_int64_t_s_s(l_49, 1))
    { /* block id: 53 */
        int32_t l_93 = 4L;
        int32_t l_107 = 7L;
        int64_t l_108 = 0xEAD6AADDF2FA25C2LL;
        int32_t l_109 = (-1L);
        g_4[0] &= l_93;
        if ((safe_rshift_func_int8_t_s_u(((l_63 & l_93) <= 0x7A423BFD0AF7C67ELL), p_43)))
        { /* block id: 55 */
            l_57[0][3][4] = ((((safe_mul_func_uint8_t_u_u(((safe_mod_func_int8_t_s_s(p_43, l_93)) , g_3), 0UL)) & 0x39L) == 0x3653FF11A6D5F070LL) , l_49);
        }
        else
        { /* block id: 57 */
            uint64_t l_100 = 1UL;
            l_100--;
            g_4[0] = 0x765711E9L;
            l_107 = ((((((safe_mod_func_int64_t_s_s((safe_div_func_uint64_t_u_u(0x0FADE77E2578D85DLL, l_93)), 0x45A537C3C24F611ELL)) > 4UL) && l_100) != g_4[0]) <= 0xBB07CFFEL) == p_43);
        }
        l_110[6][2]--;
        if (p_44)
            break;
    }
    for (l_63 = (-11); (l_63 >= 13); l_63++)
    { /* block id: 67 */
        int32_t l_122 = 0x37AD1066L;
        g_4[0] = ((((safe_sub_func_int16_t_s_s(((safe_rshift_func_int8_t_s_s(((+((safe_lshift_func_int8_t_s_u(g_4[0], l_57[0][3][4])) && l_63)) ^ l_122), g_69)) ^ (-1L)), g_4[0])) == p_43) == 1L) & l_49);
        for (l_122 = 0; l_122 < 1; l_122 += 1)
        {
            for (p_43 = 0; p_43 < 8; p_43 += 1)
            {
                for (l_49 = 0; l_49 < 5; l_49 += 1)
                {
                    l_57[l_122][p_43][l_49] = 0x33E288D9L;
                }
            }
        }
        for (p_44 = 0; (p_44 <= 0); p_44 += 1)
        { /* block id: 72 */
            return p_42;
        }
    }
    return l_110[6][0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_45[i], "g_45[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_69, "g_69", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 78
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 91
   depth: 2, occurrence: 25
   depth: 3, occurrence: 4
   depth: 4, occurrence: 7
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 4
   depth: 8, occurrence: 3
   depth: 9, occurrence: 1
   depth: 10, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 142
XXX times a non-volatile is write: 61
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 103
XXX percentage of non-volatile access: 97.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 92
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 32
   depth: 2, occurrence: 40

XXX percentage a fresh-made variable is used: 26.1
XXX percentage an existing variable is used: 73.9
********************* end of statistics **********************/

