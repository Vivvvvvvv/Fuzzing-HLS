/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2255469105051991647
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_14[3] = {0xD1AD67A4BEDCC590LL,0xD1AD67A4BEDCC590LL,0xD1AD67A4BEDCC590LL};
static uint64_t g_23 = 18446744073709551615UL;
static int32_t g_31 = 0x03CFCB8FL;
static uint64_t g_35[2] = {1UL,1UL};
static volatile int32_t g_42 = 1L;/* VOLATILE GLOBAL g_42 */
static int8_t g_45 = (-1L);
static volatile uint16_t g_46 = 0x91E2L;/* VOLATILE GLOBAL g_46 */
static int32_t g_72[1] = {1L};
static int64_t g_73 = 0x2D6201886A608834LL;
static volatile int8_t g_74[1] = {9L};
static volatile int8_t g_75 = 0x36L;/* VOLATILE GLOBAL g_75 */
static volatile int32_t g_76[8] = {0x3A8461A3L,0xC76156DDL,0x3A8461A3L,0xC76156DDL,0x3A8461A3L,0xC76156DDL,0x3A8461A3L,0xC76156DDL};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, int8_t  p_4);
static uint32_t  func_9(int8_t  p_10, uint32_t  p_11, int8_t  p_12, int8_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_23 g_31 g_35 g_46 g_42 g_73
 * writes: g_23 g_31 g_35 g_46
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_15 = (-1L);
    int32_t l_51 = 0xDFB48103L;
    int32_t l_52 = 8L;
    int32_t l_64 = 5L;
    uint16_t l_71 = 8UL;
    int32_t l_77[6];
    uint64_t l_78 = 0xBB411E181F3B01A6LL;
    int i;
    for (i = 0; i < 6; i++)
        l_77[i] = (-10L);
    if ((func_2(((((safe_mul_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(func_9(g_14[2], g_14[2], g_14[0], l_15), (-1L))), g_14[0])) >= g_14[2]) & 2UL) < g_14[1]), g_14[0]) , 7L))
    { /* block id: 23 */
        uint32_t l_53 = 0UL;
        g_31 = ((safe_sub_func_int8_t_s_s(g_14[1], g_23)) , l_51);
        --l_53;
    }
    else
    { /* block id: 26 */
        int16_t l_58 = 0L;
        int8_t l_59 = (-1L);
        const uint16_t l_70 = 0UL;
lbl_65:
        l_59 |= ((safe_div_func_int32_t_s_s(l_58, g_31)) && g_35[0]);
        l_64 &= ((safe_mod_func_uint64_t_u_u((safe_mod_func_uint32_t_u_u(4294967286UL, g_14[2])), l_51)) , l_52);
        if (l_58)
            goto lbl_65;
        l_71 = ((((((safe_lshift_func_uint8_t_u_s((((safe_rshift_func_uint16_t_u_u(0UL, 3)) && g_35[0]) & l_58), g_35[1])) != g_42) | l_70) , g_14[0]) ^ g_35[0]) ^ g_31);
    }
    g_31 = g_42;
    --l_78;
    return g_73;
}


/* ------------------------------------------ */
/* 
 * reads : g_46
 * writes: g_46
 */
static int32_t  func_2(uint64_t  p_3, int8_t  p_4)
{ /* block id: 20 */
    int8_t l_40[4] = {0x1FL,0x1FL,0x1FL,0x1FL};
    int32_t l_41 = (-1L);
    int32_t l_43 = (-1L);
    int32_t l_44[9] = {0x70979B5CL,0x70979B5CL,0x70979B5CL,0x70979B5CL,0x70979B5CL,0x70979B5CL,0x70979B5CL,0x70979B5CL,0x70979B5CL};
    int i;
    g_46++;
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_23 g_31 g_35
 * writes: g_23 g_31 g_35
 */
static uint32_t  func_9(int8_t  p_10, uint32_t  p_11, int8_t  p_12, int8_t  p_13)
{ /* block id: 1 */
    const uint64_t l_16 = 0xCFF8EE1D11023DCDLL;
    int32_t l_17 = 6L;
    const int64_t l_22[5] = {0x4E3F1571C097BC8BLL,0x4E3F1571C097BC8BLL,0x4E3F1571C097BC8BLL,0x4E3F1571C097BC8BLL,0x4E3F1571C097BC8BLL};
    int32_t l_32 = 0xA0E40209L;
    int32_t l_34 = 6L;
    int i;
    l_17 &= (l_16 ^ g_14[1]);
    for (p_11 = (-19); (p_11 < 28); ++p_11)
    { /* block id: 5 */
        const uint32_t l_30 = 0x5BED8572L;
        g_23 &= ((safe_rshift_func_uint8_t_u_s(0x6CL, l_22[4])) ^ 0xFCL);
        g_31 &= ((((safe_add_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint8_t_u_u(246UL, 6)), p_11)), 1UL)) != l_30) > l_22[0]) != p_12);
        if (l_22[4])
            continue;
    }
    for (p_12 = 2; (p_12 >= 0); p_12 -= 1)
    { /* block id: 12 */
        int32_t l_33 = 9L;
        int i;
        if (g_14[p_12])
            break;
        g_35[0]++;
        g_31 = (g_14[1] & l_34);
        if (g_31)
            break;
    }
    l_17 = (((safe_div_func_uint8_t_u_u((l_16 || 0xBCCE3F50L), 0xA9L)) <= g_31) > p_13);
    return p_12;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_35[i], "g_35[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_46, "g_46", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_72[i], "g_72[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_73, "g_73", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_74[i], "g_74[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_75, "g_75", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_76[i], "g_76[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 34
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 26
   depth: 2, occurrence: 4
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 44
XXX times a non-volatile is write: 15
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 34
XXX percentage of non-volatile access: 95.2

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 24
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 13

XXX percentage a fresh-made variable is used: 34.7
XXX percentage an existing variable is used: 65.3
********************* end of statistics **********************/

