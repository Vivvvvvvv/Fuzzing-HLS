/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9944508175918824736
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_8[8][7] = {{0xB3921DED68044455LL,(-8L),1L,1L,(-8L),0xB3921DED68044455LL,0xE418A52733582F80LL},{0x950707DFE4D9EDBDLL,(-6L),0x1245C8100C4307E4LL,0x950707DFE4D9EDBDLL,(-8L),0xAB3E90A624CDB8FALL,(-6L)},{0x3414B58E17C10977LL,0xD013D0BB94D0F4F2LL,0xB3921DED68044455LL,0L,0xB3921DED68044455LL,0xD013D0BB94D0F4F2LL,0x3414B58E17C10977LL},{0xD013D0BB94D0F4F2LL,(-6L),1L,0xB3921DED68044455LL,0x3414B58E17C10977LL,0xD013D0BB94D0F4F2LL,0xB3921DED68044455LL},{0x950707DFE4D9EDBDLL,(-8L),0xAB3E90A624CDB8FALL,(-6L),(-6L),0xAB3E90A624CDB8FALL,(-8L)},{(-6L),0xE418A52733582F80LL,1L,0L,0xE418A52733582F80LL,0xB3921DED68044455LL,(-8L)},{0x90611BC383C67EE3LL,(-6L),0xB3921DED68044455LL,0x90611BC383C67EE3LL,0xD013D0BB94D0F4F2LL,0x7FE64FD9E2A8D3A1LL,0xAB3E90A624CDB8FALL},{0xB3921DED68044455LL,0xB3921DED68044455LL,0x950707DFE4D9EDBDLL,0xE418A52733582F80LL,0x90611BC383C67EE3LL,(-6L),0xB3921DED68044455LL}};
static volatile uint32_t g_19[7] = {4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL,4294967295UL};
static int32_t g_27 = 0x99FF93F8L;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_2(uint64_t  p_3, uint16_t  p_4, uint32_t  p_5, uint16_t  p_6, int64_t  p_7);
static uint16_t  func_33(int32_t  p_34, uint16_t  p_35, int64_t  p_36, const int16_t  p_37);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_19
 * writes: g_19 g_27
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_9 = 0L;
    int32_t l_39[8] = {0xECF58A41L,8L,0xECF58A41L,0xECF58A41L,8L,0xECF58A41L,0xECF58A41L,8L};
    int i;
    l_39[7] = func_2(g_8[3][1], g_8[3][1], g_8[7][5], g_8[7][3], l_9);
    return g_19[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_19
 * writes: g_19 g_27
 */
static int32_t  func_2(uint64_t  p_3, uint16_t  p_4, uint32_t  p_5, uint16_t  p_6, int64_t  p_7)
{ /* block id: 1 */
    uint64_t l_15 = 4UL;
    volatile int32_t l_20 = 2L;/* VOLATILE GLOBAL l_20 */
    uint32_t l_29 = 4294967287UL;
    int32_t l_32 = (-1L);
    if ((safe_rshift_func_uint16_t_u_u((safe_add_func_int64_t_s_s((0xB1L || g_8[1][3]), (-6L))), 10)))
    { /* block id: 2 */
        int16_t l_14[5];
        uint64_t l_16 = 0xD996497440271DBCLL;
        int i;
        for (i = 0; i < 5; i++)
            l_14[i] = 0x7990L;
        l_15 = l_14[4];
        l_16--;
        g_19[2] = 5L;
    }
    else
    { /* block id: 6 */
        const uint64_t l_26 = 0xB839BF5BF81606DCLL;
        uint8_t l_28 = 0xC0L;
        l_20 = g_19[0];
        g_27 = ((safe_mul_func_uint16_t_u_u((safe_lshift_func_int8_t_s_s(((+(p_7 ^ 0xD71B36C9L)) | l_26), g_8[3][1])), 1UL)) , l_26);
        l_29 = (p_5 != l_28);
        for (p_4 = 0; (p_4 <= 38); p_4++)
        { /* block id: 12 */
            return l_32;
        }
    }
    l_20 = (func_33(g_19[2], p_3, p_6, p_7) > 8UL);
    return l_29;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_33(int32_t  p_34, uint16_t  p_35, int64_t  p_36, const int16_t  p_37)
{ /* block id: 16 */
    int32_t l_38 = 0xAB19F88DL;
    return l_38;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_8[i][j], "g_8[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_27, "g_27", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 14
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 2
   depth: 4, occurrence: 1
   depth: 6, occurrence: 3

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 6
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 8
XXX percentage of non-volatile access: 81.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 7
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 46.7
XXX percentage an existing variable is used: 53.3
********************* end of statistics **********************/

