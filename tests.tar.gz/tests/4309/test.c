/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15698849086115589492
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int32_t  f0;
   int32_t  f1;
   volatile uint16_t  f2;
   uint32_t  f3;
   const uint16_t  f4;
   volatile int32_t  f5;
   const volatile uint64_t  f6;
};

struct S1 {
   const volatile int32_t  f0;
   uint8_t  f1;
   volatile int64_t  f2;
   const uint32_t  f3;
   int8_t  f4;
   struct S0  f5;
   uint32_t  f6;
};

/* --- GLOBAL VARIABLES --- */
static struct S1 g_2 = {0x3D7F1912L,0x30L,0x9BCA7B5CF1C946B4LL,18446744073709551612UL,0x17L,{0x4039EE49L,0xBA6B42BEL,0x97E7L,2UL,0xB653L,0L,18446744073709551607UL},18446744073709551613UL};/* VOLATILE GLOBAL g_2 */


/* --- FORWARD DECLARATIONS --- */
static struct S1  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static struct S1  func_1(void)
{ /* block id: 0 */
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2.f0, "g_2.f0", print_hash_value);
    transparent_crc(g_2.f1, "g_2.f1", print_hash_value);
    transparent_crc(g_2.f2, "g_2.f2", print_hash_value);
    transparent_crc(g_2.f3, "g_2.f3", print_hash_value);
    transparent_crc(g_2.f4, "g_2.f4", print_hash_value);
    transparent_crc(g_2.f5.f0, "g_2.f5.f0", print_hash_value);
    transparent_crc(g_2.f5.f1, "g_2.f5.f1", print_hash_value);
    transparent_crc(g_2.f5.f2, "g_2.f5.f2", print_hash_value);
    transparent_crc(g_2.f5.f3, "g_2.f5.f3", print_hash_value);
    transparent_crc(g_2.f5.f4, "g_2.f5.f4", print_hash_value);
    transparent_crc(g_2.f5.f5, "g_2.f5.f5", print_hash_value);
    transparent_crc(g_2.f5.f6, "g_2.f5.f6", print_hash_value);
    transparent_crc(g_2.f6, "g_2.f6", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 0
   depth: 1, occurrence: 0
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 1
breakdown:
   depth: 1, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 1
XXX times a non-volatile is write: 0
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 1
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 1

XXX percentage a fresh-made variable is used: 100
XXX percentage an existing variable is used: 0
********************* end of statistics **********************/

