/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4543911924579103265
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_4[7] = {0x66C93EE327439CB6LL,0x891F782A1836CCB0LL,0x66C93EE327439CB6LL,0x66C93EE327439CB6LL,0x891F782A1836CCB0LL,0x66C93EE327439CB6LL,0x66C93EE327439CB6LL};
static uint64_t g_9[10] = {18446744073709551611UL,0xDA8AFC1DA7BC9995LL,0xDA8AFC1DA7BC9995LL,18446744073709551611UL,18446744073709551607UL,18446744073709551611UL,0xDA8AFC1DA7BC9995LL,0xDA8AFC1DA7BC9995LL,18446744073709551611UL,18446744073709551607UL};
static uint64_t g_50[10] = {0x05A42069719EFCC7LL,0x6A332E525B78C6AELL,0x6A332E525B78C6AELL,0x05A42069719EFCC7LL,0x6A332E525B78C6AELL,0x6A332E525B78C6AELL,0x05A42069719EFCC7LL,0x6A332E525B78C6AELL,0x6A332E525B78C6AELL,0x05A42069719EFCC7LL};
static uint64_t g_71 = 0x55F80954C1B2F081LL;
static uint64_t g_72 = 0x115E53F01E83513FLL;
static volatile int8_t g_73 = (-1L);/* VOLATILE GLOBAL g_73 */
static volatile int64_t g_75 = 0x9A337B27F9695FF7LL;/* VOLATILE GLOBAL g_75 */
static uint32_t g_76 = 0xA02D5285L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_10(int32_t  p_11, uint32_t  p_12, uint8_t  p_13);
static int32_t  func_24(uint64_t  p_25, int16_t  p_26, uint64_t  p_27, int16_t  p_28, int8_t  p_29);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_50 g_71 g_76
 * writes: g_4 g_9 g_50 g_71 g_72 g_76
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_2 = 0xD16DL;
    int8_t l_3 = 0x8AL;
    int32_t l_74 = 0xA6552259L;
    g_4[2] = (l_2 < l_3);
    g_9[9] = (safe_div_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((g_4[2] < (-2L)), g_4[4])), l_2));
    g_72 = func_10((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(((safe_sub_func_uint64_t_u_u((!(safe_sub_func_int16_t_s_s(g_9[9], g_9[9]))), l_3)) == g_4[0]), 5)), 0x2715L)), l_2, g_9[9]);
    ++g_76;
    return l_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_4 g_50 g_71
 * writes: g_50 g_71
 */
static int32_t  func_10(int32_t  p_11, uint32_t  p_12, uint8_t  p_13)
{ /* block id: 3 */
    uint32_t l_23 = 0x67B47E0FL;
    uint8_t l_30 = 0xB6L;
    l_23 = g_9[3];
    g_50[8] = func_24((g_9[8] , p_12), p_13, p_13, l_30, p_12);
    if (l_23)
    { /* block id: 22 */
        int32_t l_55 = 0xA861D8D4L;
        int32_t l_56 = 1L;
        l_56 = ((safe_sub_func_int16_t_s_s((safe_div_func_uint8_t_u_u(p_11, 2L)), 0xDF49L)) <= l_55);
        return g_50[8];
    }
    else
    { /* block id: 25 */
        uint32_t l_61[5] = {0xD78DB584L,0xD78DB584L,0xD78DB584L,0xD78DB584L,0xD78DB584L};
        int32_t l_62[2];
        int32_t l_65[7] = {0xB720FAE2L,0xB720FAE2L,0xB720FAE2L,0xB720FAE2L,0xB720FAE2L,0xB720FAE2L,0xB720FAE2L};
        int i;
        for (i = 0; i < 2; i++)
            l_62[i] = (-1L);
lbl_66:
        l_62[0] = (safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint8_t_u_s(p_12, 3)), l_61[3]));
        l_65[2] &= (((safe_div_func_int64_t_s_s(0xE7FF2B9ACCE3044BLL, l_62[0])) <= g_4[6]) | p_13);
        if (p_11)
            goto lbl_66;
    }
    g_71 &= ((safe_rshift_func_int8_t_s_u((safe_lshift_func_uint16_t_u_s(p_11, 0)), p_11)) & g_50[8]);
    return g_71;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_4
 * writes:
 */
static int32_t  func_24(uint64_t  p_25, int16_t  p_26, uint64_t  p_27, int16_t  p_28, int8_t  p_29)
{ /* block id: 5 */
    int32_t l_35 = 1L;
    int32_t l_36 = 0x3ADEB945L;
    l_35 = (safe_mod_func_int8_t_s_s((safe_sub_func_uint8_t_u_u(2UL, g_9[0])), 255UL));
    l_36 ^= g_4[2];
    l_36 = ((safe_div_func_int16_t_s_s(0xAA9CL, 1UL)) , l_36);
    for (p_28 = 0; (p_28 <= (-20)); p_28 = safe_sub_func_uint64_t_u_u(p_28, 1))
    { /* block id: 11 */
        int16_t l_48 = 0x4045L;
        int32_t l_49[1];
        int i;
        for (i = 0; i < 1; i++)
            l_49[i] = 0x25B0D6B1L;
        for (p_26 = 0; (p_26 == 4); p_26 = safe_add_func_int64_t_s_s(p_26, 6))
        { /* block id: 14 */
            uint32_t l_45 = 0xB9F5AB17L;
            l_36 = (safe_div_func_int16_t_s_s(g_9[9], l_45));
            l_49[0] |= ((safe_sub_func_uint64_t_u_u((l_48 <= l_36), g_9[1])) , g_4[0]);
            if (g_9[9])
                continue;
        }
    }
    return g_4[2];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_50[i], "g_50[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 25
   depth: 2, occurrence: 4
   depth: 3, occurrence: 3
   depth: 4, occurrence: 5
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 45
XXX times a non-volatile is write: 17
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 24
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 6
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 37.7
XXX percentage an existing variable is used: 62.3
********************* end of statistics **********************/

