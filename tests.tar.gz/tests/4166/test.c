/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13109078937395439232
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 6L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3 = 0xA6318529L;/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = 0xDA439BEBL;
static uint64_t g_20[1] = {0UL};
static volatile int8_t g_25 = 0x39L;/* VOLATILE GLOBAL g_25 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_7(int32_t  p_8, uint32_t  p_9, int16_t  p_10, int32_t  p_11, const int8_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_20 g_25
 * writes: g_4 g_20
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_13 = 0x45559507L;
    uint32_t l_26 = 0xF2C9A130L;
    for (g_4 = 0; (g_4 >= 14); g_4++)
    { /* block id: 3 */
        uint8_t l_14[4] = {4UL,4UL,4UL,4UL};
        int i;
        l_26 = func_7(l_13, l_13, l_13, l_14[2], g_4);
        return g_3;
    }
    return l_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_20 g_25 g_4
 * writes: g_20
 */
static int32_t  func_7(int32_t  p_8, uint32_t  p_9, int16_t  p_10, int32_t  p_11, const int8_t  p_12)
{ /* block id: 4 */
    volatile int16_t l_15 = (-1L);/* VOLATILE GLOBAL l_15 */
    int32_t l_16 = (-1L);
    int32_t l_17 = 0x7A1245C8L;
    int32_t l_18 = 0x07E4A906L;
    int32_t l_19 = 0x3C67EE39L;
    l_15 = g_3;
    ++g_20[0];
    l_17 = (safe_sub_func_uint64_t_u_u(l_17, g_25));
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_20[i], "g_20[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_25, "g_25", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 6
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 2
   depth: 6, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 9
XXX times a non-volatile is write: 4
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 15
XXX percentage of non-volatile access: 76.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 47.6
XXX percentage an existing variable is used: 52.4
********************* end of statistics **********************/

