/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7239942666612159042
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0xB770A77CL;
static volatile uint64_t g_17 = 0x64D64EA33A4D1B40LL;/* VOLATILE GLOBAL g_17 */
static uint32_t g_24[6] = {0x14CC5C6AL,0x14CC5C6AL,0x14CC5C6AL,0x14CC5C6AL,0x14CC5C6AL,0x14CC5C6AL};
static int64_t g_25 = 0x1978E60D743CCC09LL;
static volatile uint16_t g_26 = 1UL;/* VOLATILE GLOBAL g_26 */
static int16_t g_39 = 0x566EL;
static volatile uint64_t g_42 = 0x0D55FAF230988A21LL;/* VOLATILE GLOBAL g_42 */
static uint8_t g_46[10][2][8] = {{{0x42L,0x5FL,0x71L,0xDFL,4UL,0x42L,0xDFL,0x4EL},{4UL,0x42L,0xDFL,0x4EL,0xDFL,0x42L,4UL,0xDFL}},{{255UL,0x5FL,1UL,255UL,0UL,0xDEL,0x5FL,0x5FL},{0xDFL,0UL,0x71L,0x71L,0UL,0xDFL,1UL,0x4EL}},{{255UL,1UL,0x34L,0x5FL,0xDFL,0x34L,0UL,0x34L},{0xDFL,0x34L,0UL,0x34L,0xDFL,0x5FL,0x34L,1UL}},{{1UL,0xDFL,0xDEL,255UL,0x34L,1UL,1UL,0x34L},{0x71L,0xDEL,0xDEL,0x71L,0xDBL,1UL,0x34L,0xDEL}},{{0x34L,0x42L,0UL,1UL,0x42L,255UL,0x42L,1UL},{1UL,0x42L,1UL,0xDEL,0x34L,1UL,0xDBL,0x71L}},{{0xDFL,0xDEL,255UL,0x34L,1UL,1UL,0x34L,255UL},{0xDFL,0xDFL,255UL,1UL,0x34L,0x5FL,0xDFL,0x34L}},{{1UL,0x34L,0xDEL,1UL,0x42L,1UL,0xDEL,0x34L},{0x34L,0xDBL,255UL,1UL,0xDBL,0xDEL,0x42L,255UL}},{{0x71L,0x42L,0x4EL,0x34L,0x34L,0x4EL,0x42L,0x71L},{1UL,0x34L,255UL,0xDEL,0xDFL,1UL,0xDEL,1UL}},{{0xDFL,1UL,0xDEL,1UL,0xDEL,1UL,0xDFL,0xDEL},{0x71L,0x34L,255UL,0x71L,0x42L,0x4EL,0x34L,0x34L}},{{0xDEL,0x42L,255UL,255UL,0x42L,0xDEL,0xDBL,1UL},{0x71L,0xDBL,1UL,0x34L,0xDEL,1UL,0x42L,1UL}}};
static int32_t g_47 = (-4L);
static volatile uint64_t g_51 = 0xE024B17358D0DD08LL;/* VOLATILE GLOBAL g_51 */
static uint32_t g_54[2][3] = {{4294967295UL,4294967295UL,4294967295UL},{4294967286UL,4294967286UL,4294967286UL}};
static volatile uint32_t g_67 = 0UL;/* VOLATILE GLOBAL g_67 */
static int16_t g_70 = 0x894BL;
static uint16_t g_77 = 0x0CA5L;
static int32_t g_115 = 0x9EAB44AFL;
static uint32_t g_129 = 9UL;
static uint64_t g_133 = 1UL;
static int32_t g_143 = 0x9762EA74L;
static volatile int64_t g_146[7][3] = {{0L,0xE9AD55411A662571LL,0xE9AD55411A662571LL},{0L,0xDD16A1DD2CE5EEE5LL,(-1L)},{0L,1L,0L},{0x3F61EF617C72CAAALL,0L,(-1L)},{0xFA604D7DB42F0577LL,0xFA604D7DB42F0577LL,0xE9AD55411A662571LL},{0xCDCBB970F0A5B655LL,0L,0L},{0xE9AD55411A662571LL,1L,0x982A7E1DD48EE826LL}};
static volatile int32_t g_148 = 0L;/* VOLATILE GLOBAL g_148 */
static uint32_t g_149[1] = {0x1C1009BDL};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_4(uint32_t  p_5, int16_t  p_6, uint8_t  p_7);
static uint32_t  func_30(int32_t  p_31, int64_t  p_32);
static int32_t  func_48(int64_t  p_49, int32_t  p_50);
static int32_t  func_78(uint32_t  p_79, int16_t  p_80, int8_t  p_81, int8_t  p_82, const uint8_t  p_83);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_17 g_26 g_24 g_25 g_42 g_39 g_46 g_51 g_54 g_47 g_67 g_70 g_129 g_149 g_77
 * writes: g_3 g_17 g_24 g_26 g_42 g_46 g_47 g_39 g_51 g_54 g_67 g_70 g_77 g_129 g_133 g_149 g_143
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_2[10] = {(-1L),(-1L),8L,(-1L),8L,(-1L),(-1L),8L,(-1L),8L};
    int32_t l_65 = 0x7320B692L;
    uint32_t l_76 = 0x53C2AD41L;
    int i;
    for (g_3 = 0; (g_3 <= 9); g_3 += 1)
    { /* block id: 3 */
        int64_t l_66 = 0L;
        int i;
        if (func_4((safe_mod_func_uint8_t_u_u(l_2[g_3], 1UL)), g_3, l_2[5]))
        { /* block id: 21 */
            uint32_t l_29 = 0x7A68FAB8L;
            if (l_29)
                break;
            g_46[3][0][4] |= (((func_30(((func_4(g_24[3], g_25, l_2[g_3]) , g_26) , 0x284818A8L), g_3) != 1UL) , l_29) <= 1UL);
            g_47 = (g_3 , 0xB3460EE4L);
            l_65 = func_48(g_26, g_25);
        }
        else
        { /* block id: 61 */
            return l_66;
        }
        for (g_39 = 9; (g_39 >= 0); g_39 -= 1)
        { /* block id: 66 */
            g_67++;
        }
        g_70 = l_2[0];
        for (g_70 = 9; (g_70 >= 0); g_70 -= 1)
        { /* block id: 72 */
            uint32_t l_73 = 0xB92311C7L;
            l_73 = (safe_add_func_uint8_t_u_u((l_2[g_3] >= 246UL), g_47));
            g_77 = (safe_add_func_int32_t_s_s(func_30(g_17, l_76), (-2L)));
        }
        for (g_70 = 9; (g_70 >= 0); g_70 -= 1)
        { /* block id: 78 */
            uint32_t l_88 = 0UL;
            int32_t l_152[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i;
            l_65 = 0xEB2EFFCBL;
            l_152[3] = func_4(func_30(func_78((safe_rshift_func_int8_t_s_u((safe_mod_func_int64_t_s_s(g_26, g_70)), 6)), l_2[g_3], l_65, l_88, l_2[g_3]), l_2[g_3]), g_70, l_2[6]);
            return l_152[2];
        }
    }
    g_143 = (((safe_rshift_func_uint16_t_u_u(g_77, l_65)) ^ l_65) & 4294967289UL);
    return g_67;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_17 g_26
 * writes: g_17 g_24 g_26
 */
static int32_t  func_4(uint32_t  p_5, int16_t  p_6, uint8_t  p_7)
{ /* block id: 4 */
    uint64_t l_10 = 1UL;
    int32_t l_13 = 0x9BACDE9EL;
    int32_t l_16 = 0x279A20B2L;
    l_10++;
    l_13 |= g_3;
    if (((l_10 ^ 0x28L) > p_7))
    { /* block id: 7 */
        int64_t l_14 = 0x14A5EA964A90C6D2LL;
        int32_t l_15 = 0x9642E40CL;
        ++g_17;
    }
    else
    { /* block id: 9 */
        for (l_16 = 0; (l_16 != 20); ++l_16)
        { /* block id: 12 */
            uint32_t l_22 = 0UL;
            int32_t l_23 = 5L;
            if (g_3)
                break;
            l_23 = l_22;
            if (p_5)
                break;
        }
        for (l_13 = 0; l_13 < 6; l_13 += 1)
        {
            g_24[l_13] = 0xEE1D4595L;
        }
    }
    --g_26;
    return g_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_39 g_26
 * writes: g_42
 */
static uint32_t  func_30(int32_t  p_31, int64_t  p_32)
{ /* block id: 23 */
    uint32_t l_37 = 0x062CF9E8L;
    int32_t l_40[7][7][3] = {{{0x0349B8AEL,0x3D7FBA34L,(-7L)},{6L,0x0BB1DCEDL,(-1L)},{(-1L),0x61CAE467L,0x0B2DE47EL},{6L,0x965B818EL,0x5EF2B5D0L},{0x0349B8AEL,0x0349B8AEL,0xED4033E2L},{1L,0L,0xDB1A73B0L},{0L,0xDE21E525L,0x0349B8AEL}},{{0L,0L,0xADAD2DA0L},{0x54CEAA96L,0xFE617092L,0x54CEAA96L},{0L,(-1L),(-1L)},{0x0B2DE47EL,(-1L),0x61CAE467L},{0L,0L,0xCE9D0615L},{0x5D5DF5B0L,0x3D7FBA34L,1L},{0xCE9D0615L,0x965B818EL,0xADAD2DA0L}},{{0xDE21E525L,0x3D7FBA34L,0L},{8L,0L,8L},{0x3D7FBA34L,(-1L),0xFE617092L},{0x5EF2B5D0L,(-1L),0x0BB1DCEDL},{0L,0xFE617092L,0x6A6B93DCL},{0xF8F0B53CL,0L,1L},{0L,0x0349B8AEL,(-1L)}},{{0x5EF2B5D0L,0x5EF2B5D0L,0L},{0x3D7FBA34L,0x54CEAA96L,0x244F8A3DL},{8L,0L,0x5EF2B5D0L},{0xDE21E525L,(-6L),(-7L)},{0xCE9D0615L,8L,0x5EF2B5D0L},{0x5D5DF5B0L,0x244F8A3DL,0x244F8A3DL},{0L,0xF8F0B53CL,0L}},{{0x0B2DE47EL,0x61CAE467L,(-1L)},{0L,0xDB1A73B0L,1L},{(-1L),0xDE21E525L,0x6A6B93DCL},{0x965B818EL,0xDB1A73B0L,0x0BB1DCEDL},{0xFE617092L,0x61CAE467L,0xFE617092L},{0xDB1A73B0L,0xF8F0B53CL,8L},{0x54CEAA96L,0x244F8A3DL,0L}},{{0x0BB1DCEDL,8L,0xADAD2DA0L},{(-1L),(-6L),1L},{0x0BB1DCEDL,0L,0xCE9D0615L},{0x54CEAA96L,0x54CEAA96L,0x61CAE467L},{0xDB1A73B0L,0x5EF2B5D0L,(-1L)},{0xFE617092L,0x0349B8AEL,0x54CEAA96L},{0x965B818EL,0L,6L}},{{(-1L),0xFE617092L,0x54CEAA96L},{0L,(-1L),(-1L)},{0x0B2DE47EL,(-1L),0x61CAE467L},{0L,0L,0xCE9D0615L},{0x5D5DF5B0L,0x3D7FBA34L,1L},{0xCE9D0615L,0x965B818EL,0xADAD2DA0L},{0xDE21E525L,0x3D7FBA34L,0L}}};
    int i, j, k;
    for (p_31 = 0; (p_31 <= 3); p_31 = safe_add_func_int64_t_s_s(p_31, 7))
    { /* block id: 26 */
        int64_t l_38 = 1L;
        int32_t l_41 = 0xD0097E41L;
        for (p_32 = 0; (p_32 > 23); p_32 = safe_add_func_uint64_t_u_u(p_32, 5))
        { /* block id: 29 */
            volatile uint8_t l_45 = 1UL;/* VOLATILE GLOBAL l_45 */
            l_37 = 0xC49A7E12L;
            --g_42;
            if (g_39)
                continue;
            l_45 = g_26;
        }
        l_40[1][1][0] = 0xD92EDCDDL;
    }
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_39 g_51 g_24 g_42 g_26 g_54 g_47
 * writes: g_39 g_51 g_42 g_54 g_47
 */
static int32_t  func_48(int64_t  p_49, int32_t  p_50)
{ /* block id: 40 */
    uint32_t l_57 = 0xAA128409L;
    int32_t l_64 = 0x1FF7B51EL;
    for (g_39 = 1; (g_39 >= 0); g_39 -= 1)
    { /* block id: 43 */
        int i;
        g_51--;
        g_54[0][1] &= ((func_30(g_24[(g_39 + 3)], p_49) | 18446744073709551615UL) & p_49);
        for (g_47 = 5; (g_47 >= 1); g_47 -= 1)
        { /* block id: 48 */
            return p_50;
        }
        l_57 = (safe_rshift_func_uint16_t_u_u(p_50, 3));
        for (l_57 = 0; (l_57 <= 1); l_57 += 1)
        { /* block id: 54 */
            p_50 |= ((safe_rshift_func_int8_t_s_s(((safe_add_func_uint16_t_u_u((2L >= 0UL), 0x5946L)) | l_57), 0)) , 0L);
            l_64 = (-1L);
        }
    }
    return l_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_47 g_3 g_46 g_54 g_24 g_129 g_149
 * writes: g_129 g_133 g_149
 */
static int32_t  func_78(uint32_t  p_79, int16_t  p_80, int8_t  p_81, int8_t  p_82, const uint8_t  p_83)
{ /* block id: 80 */
    const int32_t l_105 = 1L;
    int8_t l_106[5];
    uint32_t l_107 = 0x33FCDF6EL;
    int16_t l_112[3];
    int32_t l_113 = 0L;
    uint32_t l_116[1];
    int16_t l_126 = (-1L);
    const uint32_t l_132[8] = {0UL,4294967290UL,0UL,4294967290UL,0UL,4294967290UL,0UL,4294967290UL};
    int32_t l_144 = 3L;
    int32_t l_145 = 0x7C2203A2L;
    int32_t l_147 = 0xF5B1C491L;
    int i;
    for (i = 0; i < 5; i++)
        l_106[i] = (-6L);
    for (i = 0; i < 3; i++)
        l_112[i] = 0x43F4L;
    for (i = 0; i < 1; i++)
        l_116[i] = 0x6083B57DL;
    l_107 = ((safe_sub_func_uint64_t_u_u((safe_mod_func_int32_t_s_s(((safe_lshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint16_t_u_u((safe_div_func_int16_t_s_s((((safe_div_func_int32_t_s_s(0x1F5D8E54L, l_105)) == 4294967293UL) && 1UL), g_47)), 12)), p_79)) || g_3), 65527UL)), g_46[3][0][4])) & 0x8B49L), l_106[2])), g_54[0][1])) != 1UL);
    if ((safe_lshift_func_int16_t_s_u(0x01D6L, p_82)))
    { /* block id: 82 */
        uint64_t l_110 = 0xCA155E7CE46079F8LL;
        int8_t l_111[5][6][8] = {{{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L},{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L}},{{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L},{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L}},{{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L},{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L}},{{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L},{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L}},{{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L},{1L,0x32L,0x22L,0xD9L,1L,0xD9L,0x22L,0x32L},{1L,0xD9L,0x22L,0x32L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0L,0x22L,0L},{1L,0L,0x22L,0L,1L,0x32L,0x22L,0xD9L}}};
        int32_t l_114[5][2] = {{0x6540EC61L,0x6540EC61L},{0x6540EC61L,0x6540EC61L},{0x6540EC61L,0x6540EC61L},{0x6540EC61L,0x6540EC61L},{0x6540EC61L,0x6540EC61L}};
        int i, j, k;
        l_110 = (g_54[0][1] ^ l_106[2]);
        --l_116[0];
        for (l_110 = 0; (l_110 <= 5); l_110 += 1)
        { /* block id: 87 */
            int i;
            l_113 = (safe_add_func_int32_t_s_s((!(safe_rshift_func_int8_t_s_s(((g_24[l_110] ^ 0L) , 0L), l_126))), g_46[6][1][6]));
            g_129 = (safe_lshift_func_uint8_t_u_s(((g_24[l_110] & 0x3BB164CBL) > p_83), 2));
        }
    }
    else
    { /* block id: 91 */
        uint32_t l_142[7] = {0x653F318AL,0x653F318AL,0x653F318AL,0x653F318AL,0x653F318AL,0x653F318AL,0x653F318AL};
        int i;
        for (l_113 = 22; (l_113 != (-6)); l_113 = safe_sub_func_uint8_t_u_u(l_113, 7))
        { /* block id: 94 */
            uint64_t l_141 = 0x003BC58EBAA32B3DLL;
            g_133 = l_132[3];
            l_142[1] &= (safe_lshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_s(((safe_mod_func_uint64_t_u_u((((+(0x29FCL <= 65534UL)) & l_141) != 0x9F6E7EE2L), l_141)) > 18446744073709551610UL), l_112[2])), 0));
        }
        return g_129;
    }
    ++g_149[0];
    return l_116[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_24[i], "g_24[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_46[i][j][k], "g_46[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_47, "g_47", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_54[i][j], "g_54[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    transparent_crc(g_133, "g_133", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_146[i][j], "g_146[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_148, "g_148", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_149[i], "g_149[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 56
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 63
   depth: 2, occurrence: 16
   depth: 3, occurrence: 3
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 76
XXX times a non-volatile is write: 38
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 53
XXX percentage of non-volatile access: 89.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 61
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 20
   depth: 2, occurrence: 25

XXX percentage a fresh-made variable is used: 45.5
XXX percentage an existing variable is used: 54.5
********************* end of statistics **********************/

