/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10105008525547092801
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2 = 0x53L;
static volatile uint32_t g_19 = 0x5860BC23L;/* VOLATILE GLOBAL g_19 */
static uint8_t g_23 = 0x84L;
static uint32_t g_24 = 0x05A42069L;
static uint32_t g_27 = 0xC6AEE34DL;
static uint64_t g_42 = 0x9ACCE3044B1310F0LL;
static int16_t g_49[2][6][9] = {{{0x95FFL,(-1L),0xA102L,(-2L),2L,0x618AL,2L,(-2L),0xA102L},{0L,0L,0x56C0L,0x22F2L,0x11B9L,0x5C08L,0xCD19L,(-8L),(-9L)},{0x212EL,0x83C5L,7L,0x618AL,(-8L),0L,(-1L),0x212EL,0x95FFL},{0x63FEL,0x95FFL,0x56C0L,0L,0x37B2L,1L,0L,0x618AL,0L},{3L,(-8L),0xA102L,0L,0xCD19L,0xCD19L,0L,0xA102L,(-8L)},{(-8L),0x5C08L,0xA02DL,2L,0L,0x9155L,0x5C08L,0x7D17L,0x37B2L}},{{(-6L),0L,0x9155L,0xA02DL,1L,(-6L),(-8L),0x212EL,0xC3D8L},{0xA102L,0x5C08L,0x22F2L,0x212EL,7L,0xD49AL,(-3L),0xA102L,0x63FEL},{2L,7L,7L,0xD49AL,(-4L),0xD49AL,7L,7L,2L},{0x618AL,0x212EL,0x7D17L,1L,0x11B9L,(-6L),0x63FEL,0x37B2L,0x212EL},{1L,3L,2L,(-1L),(-6L),0x9155L,0xCD19L,0xC3D8L,(-1L)},{0x618AL,0x11B9L,0x63FEL,0xA02DL,7L,(-8L),0x56C0L,0x63FEL,0x7D17L}}};
static volatile uint32_t g_50[4] = {0x7B8BBD03L,0x7B8BBD03L,0x7B8BBD03L,0x7B8BBD03L};


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int8_t  func_6(int8_t  p_7, const int8_t  p_8, int16_t  p_9);
static int8_t  func_30(uint32_t  p_31, int64_t  p_32, uint32_t  p_33, int64_t  p_34, int64_t  p_35);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_19 g_23 g_24 g_27 g_50
 * writes: g_19 g_2 g_23 g_24 g_27 g_42 g_49 g_50
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_3 = 3UL;
    int64_t l_12 = 1L;
    uint32_t l_13 = 18446744073709551609UL;
    int64_t l_14[2][4] = {{0x99958900FDB69689LL,0x99958900FDB69689LL,0x99958900FDB69689LL,0x99958900FDB69689LL},{0x99958900FDB69689LL,0x99958900FDB69689LL,0x99958900FDB69689LL,0x99958900FDB69689LL}};
    int32_t l_53 = 0x3FA32FBBL;
    int32_t l_57 = (-1L);
    int i, j;
    l_3 = g_2;
    for (l_3 = 19; (l_3 == 4); l_3--)
    { /* block id: 4 */
        const int8_t l_10 = 1L;
        l_13 = (func_6(l_3, l_10, l_3) , l_12);
    }
    for (l_3 = 0; (l_3 <= 1); l_3 += 1)
    { /* block id: 12 */
        volatile uint16_t l_22[10][4][4] = {{{9UL,65529UL,1UL,0xFB96L},{0xAE05L,0x7F1BL,1UL,0x1C25L},{0xE823L,0x5924L,7UL,65527UL},{1UL,65528UL,65529UL,65526UL}},{{65535UL,1UL,0x8592L,0x90B1L},{0x7A83L,65535UL,0xF0B9L,0x5E3AL},{0x5924L,0xFB96L,0xFB96L,0x5924L},{1UL,0x9C1CL,1UL,65535UL}},{{65531UL,6UL,0x5E3AL,0xEEE8L},{0x5ADFL,0x477AL,65529UL,0xEEE8L},{0x323FL,6UL,0x9A3EL,65535UL},{0x2AE4L,0x9C1CL,65535UL,0x5924L}},{{0x1C25L,0xFB96L,0x5ADFL,0x5E3AL},{0x40CCL,65535UL,0x1C25L,0x90B1L},{65529UL,1UL,0UL,65526UL},{65535UL,65528UL,65531UL,65527UL}},{{1UL,0x5924L,6UL,0x1C25L},{0xC443L,0x7F1BL,0xEEE8L,0xFB96L},{0xFB96L,65529UL,0xBDE5L,0xAE05L},{6UL,7UL,0xAE05L,7UL}},{{65535UL,0x2AE4L,0x3E5FL,65535UL},{0x5AB1L,0xE823L,0xC443L,65531UL},{0xF0B9L,0x90B1L,9UL,65535UL},{0xF0B9L,9UL,0xC443L,0UL}},{{0x5AB1L,65535UL,0x3E5FL,9UL},{65535UL,0x5AB1L,0xAE05L,5UL},{6UL,0x8592L,0xBDE5L,1UL},{0xFB96L,1UL,0xEEE8L,65531UL}},{{0xC443L,0xEEE8L,6UL,0xB9B9L},{1UL,65535UL,9UL,0xEEE8L},{0x5924L,0x1826L,65535UL,65527UL},{0x5ADFL,0x7F1BL,5UL,0xD924L}},{{0x7A83L,0x9A3EL,65535UL,65535UL},{5UL,5UL,9UL,0x7F1BL},{0xC443L,0x1C25L,0x4045L,65529UL},{0xEEE8L,0x5AB1L,65527UL,0x4045L}},{{65535UL,0x5AB1L,1UL,65529UL},{0x5AB1L,0x1C25L,1UL,0x7F1BL},{0x1826L,5UL,65535UL,65535UL},{0x477AL,0x9A3EL,0x1C25L,0xD924L}}};
        int32_t l_36 = 0x85C3B363L;
        int32_t l_56 = 0x3E709F62L;
        int i, j, k;
        if (((l_13 || l_14[0][1]) <= 0xBE92E3F9L))
        { /* block id: 13 */
            int32_t l_17[1];
            int i;
            for (i = 0; i < 1; i++)
                l_17[i] = 0x7B47E0FAL;
            if (g_2)
                break;
            l_17[0] = (safe_mul_func_int8_t_s_s((0x257392715EE56E31LL == g_2), 0xD3L));
        }
        else
        { /* block id: 16 */
            uint32_t l_18 = 0UL;
            l_18 = g_2;
            if (l_18)
                continue;
            ++g_19;
            l_22[8][3][0] = g_19;
        }
        for (g_2 = 0; (g_2 <= 1); g_2 += 1)
        { /* block id: 24 */
            g_23 = 1L;
            g_24 |= g_23;
            g_27 &= (safe_rshift_func_uint16_t_u_u(2UL, l_13));
        }
        l_53 = (safe_div_func_int8_t_s_s(func_30((l_22[1][3][2] , g_2), l_36, g_27, g_27, g_2), g_24));
        for (l_36 = 0; (l_36 <= 1); l_36 += 1)
        { /* block id: 58 */
            l_56 = ((safe_mul_func_uint8_t_u_u(l_22[8][3][0], g_24)) < 0x95L);
        }
    }
    return l_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int8_t  func_6(int8_t  p_7, const int8_t  p_8, int16_t  p_9)
{ /* block id: 5 */
    int64_t l_11 = 0x10789328A062B000LL;
    l_11 &= ((65535UL <= g_2) > p_8);
    return l_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_27 g_24 g_50
 * writes: g_42 g_27 g_2 g_49 g_50
 */
static int8_t  func_30(uint32_t  p_31, int64_t  p_32, uint32_t  p_33, int64_t  p_34, int64_t  p_35)
{ /* block id: 29 */
    uint16_t l_41[8] = {0x0654L,0x0654L,65529UL,0x0654L,0x0654L,65529UL,0x0654L,0x0654L};
    int32_t l_45 = 0x1AE7D512L;
    int i;
    g_42 = (safe_rshift_func_uint8_t_u_s(((safe_mod_func_uint64_t_u_u((g_2 || l_41[1]), 18446744073709551615UL)) , 0xF0L), p_33));
    for (g_27 = 0; (g_27 > 36); ++g_27)
    { /* block id: 33 */
        l_45 &= g_24;
        return p_34;
    }
    for (p_34 = 7; (p_34 >= 0); p_34 -= 1)
    { /* block id: 39 */
        int32_t l_48 = 0xFE74C19FL;
        int i;
        if (l_41[p_34])
            break;
        for (g_2 = 0; (g_2 <= 7); g_2 += 1)
        { /* block id: 43 */
            int i;
            return l_41[p_34];
        }
        g_49[0][3][4] = ((safe_mod_func_uint16_t_u_u(0x33B1L, l_48)) ^ p_33);
        for (g_27 = 0; (g_27 <= 7); g_27 += 1)
        { /* block id: 49 */
            --g_50[2];
            if (p_34)
                continue;
        }
    }
    return l_41[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_49[i][j][k], "g_49[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_50[i], "g_50[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 23
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 33
   depth: 2, occurrence: 9
   depth: 3, occurrence: 5
   depth: 5, occurrence: 2
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 43
XXX times a non-volatile is write: 21
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 19
XXX percentage of non-volatile access: 91.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 34
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 11
   depth: 2, occurrence: 13

XXX percentage a fresh-made variable is used: 44.2
XXX percentage an existing variable is used: 55.8
********************* end of statistics **********************/

