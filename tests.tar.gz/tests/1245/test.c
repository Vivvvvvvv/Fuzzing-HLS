/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16509990107115305961
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = (-1L);/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = 1L;
static volatile int32_t g_7 = (-1L);/* VOLATILE GLOBAL g_7 */
static volatile int32_t g_8 = (-1L);/* VOLATILE GLOBAL g_8 */
static int32_t g_9 = (-7L);
static volatile int8_t g_33 = 0L;/* VOLATILE GLOBAL g_33 */
static volatile int32_t g_34 = 0x187B35F1L;/* VOLATILE GLOBAL g_34 */
static int64_t g_36 = 0x81D68C2AFE2499E6LL;
static uint32_t g_38 = 0x3222C7E1L;
static uint16_t g_92[4] = {0x5C31L,0x5C31L,0x5C31L,0x5C31L};
static volatile uint64_t g_127 = 0x921F8CFEE4E9FC46LL;/* VOLATILE GLOBAL g_127 */
static volatile int32_t g_134[7] = {1L,1L,0xCA4AAA59L,1L,1L,0xCA4AAA59L,1L};
static int16_t g_135 = 0x204CL;
static volatile uint8_t g_136[2][7][9] = {{{0x7EL,0x98L,1UL,255UL,0x86L,0x7BL,0x7EL,0x78L,0x98L},{255UL,0x98L,0x40L,0x98L,2UL,0x67L,0xB7L,0xDFL,0x98L},{0x7EL,0x6FL,0x78L,0xB7L,0xA1L,0xA1L,0xB7L,0x78L,0x6FL},{0x3CL,1UL,0x58L,0xA2L,0xA1L,0x67L,0x7EL,1UL,9UL},{5UL,0x39L,0x13L,0xA1L,0x41L,246UL,0x86L,0x68L,0x39L},{5UL,9UL,0UL,5UL,0x90L,0x41L,0UL,0x68L,9UL},{0UL,251UL,0x6FL,0x67L,4UL,0x41L,0x86L,253UL,251UL}},{{2UL,0xECL,253UL,0x67L,0x90L,246UL,2UL,0UL,0xECL},{0x67L,0xECL,0x6FL,5UL,0x41L,4UL,0xA1L,4UL,0xECL},{2UL,251UL,0UL,0xA1L,247UL,247UL,0xA1L,0UL,251UL},{0UL,9UL,0x13L,0x86L,247UL,4UL,2UL,253UL,9UL},{5UL,0x39L,0x13L,0xA1L,0x41L,246UL,0x86L,0x68L,0x39L},{5UL,9UL,0UL,5UL,0x90L,0x41L,0UL,0x68L,9UL},{0UL,251UL,0x6FL,0x67L,4UL,0x41L,0x86L,253UL,251UL}}};
static volatile uint16_t g_161 = 0UL;/* VOLATILE GLOBAL g_161 */
static volatile uint64_t g_172[1][10] = {{0xCCD0575CF62B27B7LL,0x412926711C342DABLL,0x412926711C342DABLL,0xCCD0575CF62B27B7LL,0x412926711C342DABLL,0x412926711C342DABLL,0xCCD0575CF62B27B7LL,0x412926711C342DABLL,0x412926711C342DABLL,0xCCD0575CF62B27B7LL}};
static volatile uint64_t g_178 = 0x3EC21901E68239DELL;/* VOLATILE GLOBAL g_178 */
static int32_t g_191 = 0xA80814B8L;
static volatile int32_t g_230 = 0x64B60929L;/* VOLATILE GLOBAL g_230 */
static volatile int64_t g_243[3][4][5] = {{{0xDE7DC1E71E300602LL,1L,0L,0xDE7DC1E71E300602LL,1L},{0x64A772E67D206CC4LL,0L,0L,0x64A772E67D206CC4LL,(-1L)},{0x64A772E67D206CC4LL,1L,1L,0x64A772E67D206CC4LL,1L},{0xDE7DC1E71E300602LL,1L,0L,0xDE7DC1E71E300602LL,1L}},{{0x64A772E67D206CC4LL,0L,0L,0x64A772E67D206CC4LL,(-1L)},{0x64A772E67D206CC4LL,1L,1L,0x64A772E67D206CC4LL,1L},{0xDE7DC1E71E300602LL,1L,0L,0xDE7DC1E71E300602LL,1L},{0x64A772E67D206CC4LL,0L,0L,0x64A772E67D206CC4LL,(-1L)}},{{0x64A772E67D206CC4LL,1L,1L,0x64A772E67D206CC4LL,1L},{0xDE7DC1E71E300602LL,1L,0L,0xDE7DC1E71E300602LL,1L},{0x64A772E67D206CC4LL,0L,0L,0x64A772E67D206CC4LL,(-1L)},{0x64A772E67D206CC4LL,1L,1L,0x64A772E67D206CC4LL,1L}}};


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static int32_t  func_19(uint32_t  p_20);
static int16_t  func_43(int8_t  p_44, uint8_t  p_45, int8_t  p_46, int32_t  p_47);
static int32_t  func_55(int32_t  p_56, const int32_t  p_57);
static int32_t  func_62(int32_t  p_63, int32_t  p_64, int8_t  p_65, const uint32_t  p_66, int64_t  p_67);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_7 g_8 g_3 g_38 g_34 g_92 g_36 g_127 g_136 g_161 g_134 g_172 g_178 g_33 g_135 g_191 g_230
 * writes: g_3 g_4 g_9 g_38 g_34 g_8 g_7 g_36 g_127 g_136 g_161 g_172 g_178 g_191 g_230
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_2[1];
    uint64_t l_188 = 0xE258E6F13F4DB05CLL;
    int32_t l_206 = (-3L);
    int i;
    for (i = 0; i < 1; i++)
        l_2[i] = 0x8EL;
    for (g_3 = 0; g_3 < 1; g_3 += 1)
    {
        l_2[g_3] = 0x02L;
    }
    for (g_4 = (-3); (g_4 != (-24)); g_4 = safe_sub_func_int8_t_s_s(g_4, 7))
    { /* block id: 4 */
        int64_t l_21 = 5L;
        int32_t l_192 = 0x61564322L;
        for (g_9 = (-10); (g_9 <= 18); ++g_9)
        { /* block id: 7 */
            uint16_t l_12 = 2UL;
            ++l_12;
        }
        if (((l_2[0] & l_2[0]) || g_9))
        { /* block id: 10 */
            int32_t l_187 = (-9L);
            if (g_7)
                break;
            l_187 = (safe_div_func_int64_t_s_s((safe_div_func_uint32_t_u_u(((((func_19(l_21) == g_135) && g_38) | l_2[0]) <= l_2[0]), l_21)), 0x30346E159BBAF6B6LL));
        }
        else
        { /* block id: 116 */
            g_7 = (l_188 <= g_38);
        }
        for (l_21 = 8; (l_21 > (-23)); l_21 = safe_sub_func_uint32_t_u_u(l_21, 8))
        { /* block id: 121 */
            uint8_t l_193 = 0xCEL;
            int32_t l_204 = 0x2C7609B5L;
            l_193++;
            l_204 = ((((safe_mul_func_uint8_t_u_u(((safe_lshift_func_uint8_t_u_s((safe_mod_func_int32_t_s_s((safe_add_func_uint8_t_u_u(8UL, 255UL)), 1UL)), 6)) > 1UL), l_193)) ^ l_192) <= l_193) <= 0x3868103C05A9798ALL);
            l_204 = (g_161 && g_178);
        }
    }
    if (((l_2[0] != l_2[0]) | g_36))
    { /* block id: 127 */
        uint16_t l_212 = 0x814CL;
        int32_t l_217 = (-2L);
        int32_t l_218 = 0x1ACACCE1L;
        uint16_t l_220 = 1UL;
        uint8_t l_223[2];
        int i;
        for (i = 0; i < 2; i++)
            l_223[i] = 1UL;
lbl_224:
        if (l_2[0])
        { /* block id: 128 */
            uint32_t l_205 = 6UL;
            g_3 = ((((0x3232EF97L == g_178) , g_7) == l_205) < 0xA5975BB4L);
            l_206 = (((l_188 | 9L) , g_134[6]) != 4UL);
        }
        else
        { /* block id: 131 */
            int64_t l_209 = 5L;
            g_3 = (l_206 ^ g_191);
            g_9 ^= ((safe_mul_func_int16_t_s_s(l_206, g_172[0][3])) <= l_188);
            l_206 = (l_209 != 0x0A8C1EE95B8BEFA4LL);
        }
        if (((((safe_mul_func_int16_t_s_s(g_161, l_2[0])) == l_212) , l_212) , g_92[0]))
        { /* block id: 136 */
            return g_92[0];
        }
        else
        { /* block id: 138 */
            const uint8_t l_215[7] = {0xF2L,0xF2L,0xF2L,0xF2L,0xF2L,0xF2L,0xF2L};
            int32_t l_216 = 1L;
            int32_t l_219 = 0L;
            int i;
            g_9 |= ((((((((safe_mul_func_int8_t_s_s((((l_212 && 0L) && l_215[0]) == 0x9DL), g_178)) , 1L) > 0UL) && 1L) < g_135) , l_215[5]) , g_38) & 0x5286ADEA88920E44LL);
            l_220--;
            l_223[0] = (g_161 ^ l_212);
        }
        if (g_38)
            goto lbl_224;
        if (g_9)
            goto lbl_224;
    }
    else
    { /* block id: 145 */
        uint32_t l_227 = 0x7224A2D7L;
        int32_t l_231 = (-6L);
        int32_t l_232[2];
        uint16_t l_244 = 65528UL;
        int i;
        for (i = 0; i < 2; i++)
            l_232[i] = 0x669EC0A3L;
        for (g_191 = 29; (g_191 < 7); --g_191)
        { /* block id: 148 */
            l_206 = g_38;
            return l_227;
        }
        for (l_206 = 12; (l_206 < (-16)); l_206 = safe_sub_func_int16_t_s_s(l_206, 1))
        { /* block id: 154 */
            uint32_t l_233 = 18446744073709551615UL;
            int32_t l_236 = 0x752B4451L;
            l_233--;
            l_236 = l_227;
        }
        for (g_38 = (-21); (g_38 >= 54); g_38 = safe_add_func_int16_t_s_s(g_38, 9))
        { /* block id: 160 */
            int32_t l_247 = 0x222332E9L;
            g_4 ^= (safe_mul_func_int16_t_s_s(((((safe_mod_func_uint8_t_u_u((g_127 | g_9), 0x7EL)) , 0UL) , 0xC29661A5A5C426E1LL) , l_2[0]), (-4L)));
            ++l_244;
            l_247 = l_206;
            g_8 ^= l_227;
        }
    }
    g_230 |= ((safe_sub_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u(l_188, l_2[0])) | 18446744073709551609UL), 251UL)) != 1L);
    return g_136[1][4][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_8 g_3 g_38 g_7 g_4 g_34 g_92 g_36 g_127 g_136 g_161 g_134 g_172 g_178 g_33 g_135
 * writes: g_9 g_38 g_34 g_8 g_7 g_36 g_127 g_136 g_161 g_3 g_172 g_178
 */
static int32_t  func_19(uint32_t  p_20)
{ /* block id: 12 */
    int32_t l_25 = (-8L);
    int32_t l_27 = 2L;
    int32_t l_28[6];
    int i;
    for (i = 0; i < 6; i++)
        l_28[i] = 0x6A37D7C8L;
    for (g_9 = 0; (g_9 != (-14)); g_9 = safe_sub_func_uint8_t_u_u(g_9, 2))
    { /* block id: 15 */
        int64_t l_26 = 1L;
        int32_t l_29[7] = {0x28ABF8B2L,0x28ABF8B2L,0x29A275FFL,0x28ABF8B2L,0x28ABF8B2L,0x29A275FFL,0x28ABF8B2L};
        int8_t l_31 = 0x9CL;
        int i;
        if (((!g_8) || g_3))
        { /* block id: 16 */
            int64_t l_30 = (-1L);
            int32_t l_32 = (-8L);
            int32_t l_35 = 0x89AA5088L;
            int32_t l_37 = 0xC7A88FF7L;
            g_38--;
            if (l_27)
                break;
            l_35 = (safe_rshift_func_uint16_t_u_s((func_43(p_20, p_20, p_20, p_20) >= p_20), l_37));
        }
        else
        { /* block id: 105 */
            uint32_t l_177 = 0xE13DD652L;
            g_7 = ((((safe_sub_func_uint64_t_u_u(g_172[0][1], l_177)) , 0x8352772FB52A3243LL) , 0L) >= l_31);
            g_34 = p_20;
        }
        if (p_20)
            continue;
        g_178++;
    }
    g_3 = ((safe_rshift_func_int8_t_s_u((((safe_mod_func_uint32_t_u_u((((safe_mul_func_uint16_t_u_u((p_20 >= g_33), 1UL)) || l_28[2]) && 0x624CL), l_27)) < 9UL) <= g_135), 2)) == p_20);
    l_28[2] = (p_20 != l_25);
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_7 g_4 g_8 g_9 g_34 g_92 g_3 g_36 g_127 g_136 g_161 g_134 g_172
 * writes: g_38 g_34 g_8 g_7 g_36 g_127 g_136 g_161 g_3 g_172
 */
static int16_t  func_43(int8_t  p_44, uint8_t  p_45, int8_t  p_46, int32_t  p_47)
{ /* block id: 19 */
    int32_t l_50[4][6] = {{9L,0L,9L,0L,9L,0L},{1L,0L,1L,0L,1L,0L},{9L,0L,9L,0L,9L,0L},{1L,0L,1L,0L,1L,0L}};
    int i, j;
    for (g_38 = 0; (g_38 <= 48); g_38 = safe_add_func_uint64_t_u_u(g_38, 2))
    { /* block id: 22 */
        uint64_t l_53 = 0xCBF698BA832A49E8LL;
        int32_t l_169 = (-10L);
        for (p_46 = 0; (p_46 <= 3); p_46 += 1)
        { /* block id: 25 */
            return g_7;
        }
        if ((safe_rshift_func_uint16_t_u_s(l_53, l_53)))
        { /* block id: 28 */
            uint64_t l_164 = 0xE705E6A08047370DLL;
            int32_t l_167 = 0L;
            int32_t l_168 = 0xEDBDE703L;
            int32_t l_170 = 0x54895CB3L;
            int32_t l_171[1];
            int i;
            for (i = 0; i < 1; i++)
                l_171[i] = (-3L);
            l_164 = (+func_55((safe_lshift_func_uint8_t_u_u(p_45, 5)), p_47));
            g_3 = ((safe_mul_func_int16_t_s_s((((l_53 >= p_45) > g_134[3]) == p_46), 0x0D05L)) & p_46);
            ++g_172[0][3];
        }
        else
        { /* block id: 99 */
            return g_92[0];
        }
    }
    return g_172[0][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_4 g_8 g_9 g_34 g_38 g_92 g_3 g_36 g_127 g_136 g_161
 * writes: g_34 g_8 g_7 g_36 g_127 g_136 g_161
 */
static int32_t  func_55(int32_t  p_56, const int32_t  p_57)
{ /* block id: 29 */
    uint64_t l_115 = 0xC5F198F030F790E2LL;
    int32_t l_116 = 0x3620CEADL;
    int32_t l_132[9];
    int i;
    for (i = 0; i < 9; i++)
        l_132[i] = (-10L);
    if (((safe_lshift_func_uint16_t_u_u((1UL || g_7), p_56)) >= 0x7ECA51C18CC907F7LL))
    { /* block id: 30 */
        uint32_t l_70[7][9][4] = {{{0xC11D73CBL,0x2B336FDEL,18446744073709551612UL,1UL},{0xD9805F63L,0x32B805D3L,0xB1B2B150L,1UL},{0x55929734L,0x2B336FDEL,0xB72231B3L,0xC5D19E77L},{0xF5737FB6L,0xB1B5B3A0L,0xC11D73CBL,0xB72231B3L},{0x32B805D3L,18446744073709551615UL,2UL,18446744073709551615UL},{0xC11D73CBL,2UL,18446744073709551607UL,18446744073709551613UL},{8UL,0x32B805D3L,0xB1B5B3A0L,18446744073709551612UL},{0xEA99669DL,0xD726993CL,0xB72231B3L,0xB1B2B150L},{0xEA99669DL,0xC5D19E77L,0xB1B5B3A0L,0xB72231B3L}},{{8UL,0xB1B2B150L,18446744073709551607UL,0xC11D73CBL},{0xC11D73CBL,18446744073709551615UL,2UL,2UL},{0x32B805D3L,0x32B805D3L,0xC11D73CBL,18446744073709551607UL},{0xF5737FB6L,0x67A5E2B1L,0xB72231B3L,0xB1B5B3A0L},{0x55929734L,0xC11D73CBL,0xB1B2B150L,0xB72231B3L},{0xD9805F63L,0xC11D73CBL,18446744073709551612UL,0xB1B5B3A0L},{0xC11D73CBL,0x67A5E2B1L,18446744073709551613UL,18446744073709551607UL},{18446744073709551615UL,0x32B805D3L,18446744073709551615UL,2UL},{0xB72231B3L,18446744073709551615UL,0xB72231B3L,0xC11D73CBL}},{{0xBB84A8A6L,0xB1B2B150L,0xC5D19E77L,0xB72231B3L},{0x8F575434L,0xC5D19E77L,1UL,0xB1B2B150L},{0xC11D73CBL,0xD726993CL,1UL,18446744073709551612UL},{0x8F575434L,0x32B805D3L,0xC5D19E77L,18446744073709551613UL},{0xBB84A8A6L,2UL,0xB72231B3L,18446744073709551615UL},{0xB72231B3L,18446744073709551615UL,18446744073709551615UL,0xB72231B3L},{18446744073709551615UL,0xB1B5B3A0L,18446744073709551613UL,0xC5D19E77L},{0xC11D73CBL,0x2B336FDEL,18446744073709551612UL,1UL},{0xD9805F63L,0x32B805D3L,0xB1B2B150L,1UL}},{{0x55929734L,0x2B336FDEL,0xB72231B3L,0xC5D19E77L},{0xF5737FB6L,0xB1B5B3A0L,0xC11D73CBL,0xB72231B3L},{0x32B805D3L,18446744073709551615UL,2UL,18446744073709551615UL},{0xC11D73CBL,2UL,18446744073709551607UL,18446744073709551613UL},{8UL,0x32B805D3L,0xB1B5B3A0L,18446744073709551612UL},{0xEA99669DL,0xD726993CL,0xB72231B3L,0xB1B2B150L},{0xEA99669DL,0xC5D19E77L,0xB1B5B3A0L,0xB72231B3L},{8UL,0xB1B2B150L,18446744073709551607UL,0xC11D73CBL},{0xC11D73CBL,18446744073709551615UL,2UL,2UL}},{{0x32B805D3L,0x32B805D3L,0xC11D73CBL,18446744073709551607UL},{0xF5737FB6L,0x67A5E2B1L,0xB72231B3L,0xB1B5B3A0L},{0x55929734L,0xC11D73CBL,0xB1B2B150L,0xB72231B3L},{0xD9805F63L,0xC11D73CBL,18446744073709551612UL,0xB1B5B3A0L},{0xC11D73CBL,0x67A5E2B1L,18446744073709551613UL,18446744073709551607UL},{18446744073709551615UL,0x32B805D3L,18446744073709551615UL,2UL},{0xB72231B3L,18446744073709551615UL,0xB72231B3L,0xC11D73CBL},{0xBB84A8A6L,0xB1B2B150L,0xC5D19E77L,0xB72231B3L},{0x8F575434L,0xC5D19E77L,1UL,0xB1B2B150L}},{{0xC11D73CBL,0xD726993CL,2UL,0x67A5E2B1L},{0xB1B2B150L,0xC11D73CBL,0x55929734L,0xD726993CL},{18446744073709551613UL,18446744073709551615UL,1UL,0xB72231B3L},{1UL,0xB72231B3L,0xB72231B3L,1UL},{0xB1B5B3A0L,0xBB84A8A6L,0xD726993CL,0x55929734L},{0xEA99669DL,0x8F575434L,0x67A5E2B1L,2UL},{0xC5D19E77L,0xC11D73CBL,0xF5737FB6L,2UL},{2UL,0x8F575434L,1UL,0x55929734L},{18446744073709551612UL,0xBB84A8A6L,0xEA99669DL,1UL}},{{0xC11D73CBL,0xB72231B3L,18446744073709551615UL,0xB72231B3L},{0xEA99669DL,18446744073709551615UL,0x2B336FDEL,0xD726993CL},{18446744073709551615UL,0xC11D73CBL,0xBB84A8A6L,0x67A5E2B1L},{18446744073709551607UL,0xD9805F63L,1UL,0xF5737FB6L},{18446744073709551607UL,0x55929734L,0xBB84A8A6L,1UL},{18446744073709551615UL,0xF5737FB6L,0x2B336FDEL,0xEA99669DL},{0xEA99669DL,0x32B805D3L,18446744073709551615UL,18446744073709551615UL},{0xC11D73CBL,0xC11D73CBL,0xEA99669DL,0x2B336FDEL},{18446744073709551612UL,8UL,1UL,0xBB84A8A6L}}};
        int32_t l_107 = 9L;
        int16_t l_108 = (-10L);
        int i, j, k;
        l_107 = ((func_62((((((safe_rshift_func_int16_t_s_u((-1L), 8)) , p_56) , p_56) || l_70[3][1][0]) || g_4), g_8, l_70[3][1][0], g_9, p_56) , g_34) && l_70[2][6][0]);
        l_108 = p_56;
        if ((safe_div_func_int16_t_s_s(((safe_mul_func_int8_t_s_s(((safe_add_func_uint32_t_u_u(0x72254074L, p_56)) , 0xA0L), p_57)) | (-1L)), g_7)))
        { /* block id: 65 */
            l_115 = (((g_9 && g_4) == p_57) < g_9);
        }
        else
        { /* block id: 67 */
            return g_92[3];
        }
    }
    else
    { /* block id: 70 */
        uint16_t l_117 = 0x6F45L;
        l_117--;
        for (p_56 = 0; (p_56 <= 3); p_56 += 1)
        { /* block id: 74 */
            l_116 |= (-7L);
        }
    }
lbl_160:
    for (p_56 = 0; (p_56 != 0); p_56 = safe_add_func_uint16_t_u_u(p_56, 7))
    { /* block id: 80 */
        uint32_t l_122[8];
        int32_t l_125 = 0L;
        int32_t l_126 = 0xF6F5F90FL;
        int i;
        for (i = 0; i < 8; i++)
            l_122[i] = 0x75C0BC95L;
        if (l_122[4])
            break;
        for (g_36 = 7; (g_36 != 29); ++g_36)
        { /* block id: 84 */
            uint8_t l_130 = 0xF7L;
            int32_t l_131 = 0x61EEEE36L;
            int32_t l_133 = (-5L);
            --g_127;
            if (l_130)
                continue;
            g_136[1][4][4]++;
            g_8 = ((safe_mul_func_uint8_t_u_u((safe_sub_func_int16_t_s_s((safe_mul_func_uint8_t_u_u(0x3DL, 1UL)), l_122[2])), l_116)) || 18446744073709551615UL);
        }
        l_116 = (safe_div_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((+((safe_lshift_func_int8_t_s_u(((safe_lshift_func_int16_t_s_u((((safe_mul_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(l_122[4], l_122[4])), 0x7574L)) , p_56) , g_136[1][4][4]), g_92[2])) <= 0x7CBCL), 4)) > p_56)), 0x1EL)) || 0x35E0E559L), p_56)) , p_57), g_9));
        g_7 ^= ((((l_125 == 0L) < 0L) & p_56) ^ p_56);
        if (l_116)
            goto lbl_160;
    }
    --g_161;
    return g_136[1][4][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_7 g_38 g_92 g_3
 * writes: g_34 g_8 g_7
 */
static int32_t  func_62(int32_t  p_63, int32_t  p_64, int8_t  p_65, const uint32_t  p_66, int64_t  p_67)
{ /* block id: 31 */
    const uint16_t l_77[3][4][1] = {{{0x15DBL},{0x735DL},{0x15DBL},{0x735DL}},{{0x15DBL},{0x735DL},{0x15DBL},{0x735DL}},{{0x15DBL},{0x735DL},{0x15DBL},{0x735DL}}};
    int32_t l_83 = 0xAEBB8FA7L;
    int32_t l_87 = 6L;
    int i, j, k;
    for (p_65 = (-4); (p_65 < (-9)); p_65 = safe_sub_func_uint8_t_u_u(p_65, 1))
    { /* block id: 34 */
        uint32_t l_81[8];
        const int8_t l_82 = 0x89L;
        int i;
        for (i = 0; i < 8; i++)
            l_81[i] = 18446744073709551615UL;
        if ((safe_sub_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u((0xA2E55FDCL ^ 0x1F6B071CL), l_77[1][0][0])), g_34)))
        { /* block id: 35 */
            uint32_t l_80[5][2] = {{4UL,0x458B9948L},{4UL,0x458B9948L},{4UL,0x458B9948L},{4UL,0x458B9948L},{4UL,0x458B9948L}};
            int i, j;
            l_81[6] = ((((((safe_sub_func_int8_t_s_s(l_77[0][1][0], 0x25L)) == 0x896B3C83373E763FLL) , l_80[4][1]) ^ 0x452CFD91L) > 0x2B4D3A61L) == g_7);
            g_34 = l_81[4];
        }
        else
        { /* block id: 38 */
            l_83 = ((8UL ^ p_65) != l_82);
            if (g_38)
                continue;
        }
    }
    if ((((p_65 || p_64) ^ p_64) , p_67))
    { /* block id: 43 */
        int8_t l_88 = 1L;
        g_8 = (safe_rshift_func_int16_t_s_s((-7L), p_67));
        l_88 = (((+(0x4AAFL >= l_87)) >= g_38) | l_77[1][0][0]);
    }
    else
    { /* block id: 46 */
        uint32_t l_89 = 0x9EF6EAEAL;
        l_89 = p_66;
        l_83 ^= (safe_rshift_func_int16_t_s_u((p_65 | g_38), 3));
    }
    for (p_63 = 0; (p_63 <= 3); p_63 += 1)
    { /* block id: 52 */
        int32_t l_97[8][7] = {{0L,0x4CB4AB47L,0L,0L,0L,0x4CB4AB47L,0L},{0x3829EA9CL,0x335DC65FL,0x9706C822L,0x335DC65FL,0x3829EA9CL,0x3829EA9CL,0x335DC65FL},{0x25832669L,0x2031241CL,0x25832669L,0x313B5827L,0L,(-8L),0x54F23DFBL},{0x335DC65FL,0x47E9BEE6L,0x9706C822L,0x9706C822L,0x47E9BEE6L,0x335DC65FL,0x47E9BEE6L},{0x25832669L,0x313B5827L,0L,(-8L),0x54F23DFBL,(-8L),0L},{0x3829EA9CL,0x3829EA9CL,0x335DC65FL,0x9706C822L,0x335DC65FL,0x3829EA9CL,0x3829EA9CL},{0L,0x313B5827L,1L,0x313B5827L,0L,0x4CB4AB47L,0L},{0x7CA69BD5L,0x47E9BEE6L,0x7CA69BD5L,0x335DC65FL,0x335DC65FL,0x7CA69BD5L,0x47E9BEE6L}};
        int8_t l_106 = 0xC5L;
        int i, j;
        g_34 ^= g_92[p_63];
        for (p_64 = 0; (p_64 <= 3); p_64 += 1)
        { /* block id: 56 */
            int32_t l_95 = 0x94A777CCL;
            uint64_t l_96[2][2][4] = {{{0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL,0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL},{0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL,0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL}},{{0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL,0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL},{0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL,0x424A886803F40BDELL,0xF079C5DFBC4EB09ALL}}};
            int i, j, k;
            l_97[6][4] &= (((safe_add_func_uint8_t_u_u(((g_92[p_63] || l_95) , g_3), p_65)) && l_96[0][0][1]) ^ g_92[1]);
        }
        l_83 = (0x35086CD1L && l_87);
        g_7 |= (safe_sub_func_uint32_t_u_u((safe_sub_func_int32_t_s_s((safe_lshift_func_int16_t_s_u((safe_add_func_int8_t_s_s(p_64, l_106)), 10)), g_92[p_63])), p_64));
    }
    return l_77[0][0][0];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_92[i], "g_92[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_127, "g_127", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_134[i], "g_134[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_135, "g_135", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_136[i][j][k], "g_136[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_161, "g_161", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_172[i][j], "g_172[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_191, "g_191", print_hash_value);
    transparent_crc(g_230, "g_230", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_243[i][j][k], "g_243[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 82
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 97
   depth: 2, occurrence: 25
   depth: 3, occurrence: 5
   depth: 4, occurrence: 7
   depth: 5, occurrence: 7
   depth: 6, occurrence: 3
   depth: 7, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 150
XXX times a non-volatile is write: 49
XXX times a volatile is read: 28
XXX    times read thru a pointer: 0
XXX times a volatile is write: 20
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 142
XXX percentage of non-volatile access: 80.6

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 99
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 34
   depth: 2, occurrence: 46

XXX percentage a fresh-made variable is used: 24.4
XXX percentage an existing variable is used: 75.6
********************* end of statistics **********************/

