/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17153289861435700694
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_4 = 65529UL;/* VOLATILE GLOBAL g_4 */
static volatile int32_t g_27 = 0xE00C2553L;/* VOLATILE GLOBAL g_27 */
static int32_t g_28 = 9L;
static volatile uint16_t g_45 = 0xEB8AL;/* VOLATILE GLOBAL g_45 */
static int16_t g_66 = (-10L);
static int8_t g_72 = 0xBDL;
static volatile int8_t g_73 = (-1L);/* VOLATILE GLOBAL g_73 */
static volatile uint8_t g_79 = 1UL;/* VOLATILE GLOBAL g_79 */
static uint8_t g_98 = 0x6BL;
static int64_t g_110[8] = {0x5059AB7399A04901LL,0x5059AB7399A04901LL,0x5059AB7399A04901LL,0x5059AB7399A04901LL,0x5059AB7399A04901LL,0x5059AB7399A04901LL,0x5059AB7399A04901LL,0x5059AB7399A04901LL};
static uint16_t g_111 = 0x1CF3L;
static volatile int32_t g_124 = 0x6BD2DA30L;/* VOLATILE GLOBAL g_124 */
static uint64_t g_125 = 0UL;
static int8_t g_128 = 0x48L;
static int32_t g_129 = 0xD00CD1DBL;
static uint8_t g_130[7] = {0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL,0xDAL};
static volatile int8_t g_142 = 0xFFL;/* VOLATILE GLOBAL g_142 */
static uint8_t g_148 = 247UL;
static int16_t g_162 = (-1L);
static int32_t g_163 = 0xFB8437FCL;
static volatile uint32_t g_164 = 18446744073709551612UL;/* VOLATILE GLOBAL g_164 */
static volatile int32_t g_171 = (-5L);/* VOLATILE GLOBAL g_171 */
static uint8_t g_172 = 0x27L;


/* --- FORWARD DECLARATIONS --- */
static const int16_t  func_1(void);
static int16_t  func_18(const uint64_t  p_19);
static int32_t  func_22(int32_t  p_23);
static const int32_t  func_52(uint64_t  p_53, int32_t  p_54, const uint64_t  p_55);
static uint32_t  func_56(int16_t  p_57, uint8_t  p_58, int32_t  p_59);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_28 g_27 g_45 g_66 g_79 g_73 g_72 g_98 g_111 g_110 g_125 g_130 g_148 g_164 g_163 g_172 g_171
 * writes: g_4 g_28 g_45 g_27 g_79 g_98 g_111 g_125 g_130 g_72 g_148 g_164 g_172 g_171
 */
static const int16_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_5 = 0x19L;
    int32_t l_6[4][4][2] = {{{0x29EA4144L,(-1L)},{(-1L),0x29EA4144L},{(-1L),(-1L)},{0x29EA4144L,(-1L)}},{{(-1L),0x29EA4144L},{(-1L),(-1L)},{0x29EA4144L,(-1L)},{(-1L),0x29EA4144L}},{{(-1L),(-1L)},{0x29EA4144L,(-1L)},{(-1L),0x29EA4144L},{(-1L),(-1L)}},{{0x29EA4144L,(-1L)},{(-1L),0x29EA4144L},{(-1L),(-1L)},{0x29EA4144L,0x29EA4144L}}};
    int32_t l_14[10][8];
    int i, j, k;
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
            l_14[i][j] = 5L;
    }
    l_6[1][0][1] = ((safe_mul_func_uint16_t_u_u(g_4, l_5)) | 18446744073709551615UL);
    for (l_5 = 0; (l_5 > 1); ++l_5)
    { /* block id: 4 */
        uint8_t l_13 = 0xC3L;
        uint32_t l_15[9][10][2] = {{{4294967295UL,4UL},{1UL,1UL},{4294967286UL,0x467356A0L},{0x9C5A74D4L,2UL},{0UL,4294967292UL},{4294967295UL,4294967286UL},{1UL,0xA5FC0266L},{0UL,0x4B26D8F9L},{0xF9F41ADFL,4294967295UL},{0UL,4UL}},{{0xC3E8CE6FL,0UL},{4294967292UL,6UL},{0x4B26D8F9L,5UL},{1UL,0xEF339200L},{0x63C10B42L,1UL},{4294967295UL,0UL},{0x6AEBA4D3L,0xA553FC2FL},{4294967295UL,0UL},{0UL,0x92978D8EL},{9UL,4294967295UL}},{{4294967290UL,4UL},{0UL,4UL},{4294967290UL,4294967295UL},{9UL,0x92978D8EL},{0UL,0UL},{4294967295UL,0xA553FC2FL},{0x6AEBA4D3L,0UL},{4294967295UL,1UL},{0x63C10B42L,0xEF339200L},{1UL,5UL}},{{0x4B26D8F9L,6UL},{4294967292UL,0UL},{0xC3E8CE6FL,4UL},{0UL,4294967295UL},{0xF9F41ADFL,0x4B26D8F9L},{0UL,0xA5FC0266L},{1UL,4294967286UL},{4294967295UL,4294967292UL},{0UL,2UL},{0x9C5A74D4L,0x467356A0L}},{{4294967286UL,1UL},{1UL,4UL},{4294967295UL,4294967286UL},{4294967287UL,0xC3E8CE6FL},{0xEA3D8810L,0x6AEBA4D3L},{0x9918C6A8L,0UL},{0UL,4294967295UL},{8UL,0xB6478C38L},{5UL,4294967295UL},{4294967293UL,4294967290UL}},{{6UL,1UL},{4294967294UL,4294967294UL},{0xA5FC0266L,4294967295UL},{0x0461302DL,0xEA3D8810L},{0x9AFCA862L,0xF9F41ADFL},{0x2E607D19L,0x9AFCA862L},{4294967295UL,3UL},{4294967295UL,0x9AFCA862L},{0x2E607D19L,0xF9F41ADFL},{0x9AFCA862L,0xEA3D8810L}},{{0x0461302DL,4294967295UL},{0xA5FC0266L,4294967294UL},{4294967294UL,1UL},{6UL,4294967290UL},{4294967293UL,4294967295UL},{5UL,0xB6478C38L},{8UL,4294967295UL},{0UL,0UL},{0x9918C6A8L,0x6AEBA4D3L},{0xEA3D8810L,0xC3E8CE6FL}},{{4294967287UL,4294967286UL},{4294967295UL,4UL},{1UL,1UL},{4294967286UL,0x467356A0L},{0x9C5A74D4L,2UL},{0UL,4294967292UL},{4294967295UL,4294967286UL},{1UL,0xA5FC0266L},{0UL,0x4B26D8F9L},{0xF9F41ADFL,4294967295UL}},{{0UL,4UL},{0xC3E8CE6FL,0UL},{4294967292UL,6UL},{0x4B26D8F9L,5UL},{1UL,0xEF339200L},{0x63C10B42L,1UL},{4294967295UL,0UL},{0x6AEBA4D3L,0xA553FC2FL},{4294967295UL,0UL},{0UL,0x92978D8EL}}};
        int i, j, k;
        l_14[3][7] = (!((safe_sub_func_int8_t_s_s((~1UL), l_6[1][0][1])) , l_13));
        if (l_15[2][7][1])
        { /* block id: 6 */
            const uint32_t l_20 = 0x870C387CL;
            int32_t l_170[2];
            int i;
            for (i = 0; i < 2; i++)
                l_170[i] = 0x46CBE4C4L;
            l_170[1] = ((safe_sub_func_int16_t_s_s(func_18(l_20), (-1L))) & l_15[7][7][0]);
        }
        else
        { /* block id: 127 */
            g_28 ^= (g_163 == l_15[2][7][1]);
            g_172++;
        }
        return g_72;
    }
    g_171 &= ((safe_add_func_uint32_t_u_u((safe_unary_minus_func_uint64_t_u(1UL)), 0x11D43F70L)) , g_148);
    g_27 = 0x6194B454L;
    return g_72;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_27 g_45 g_66 g_79 g_73 g_72 g_4 g_98 g_111 g_110 g_125 g_130 g_148 g_164
 * writes: g_4 g_28 g_45 g_27 g_79 g_98 g_111 g_125 g_130 g_72 g_148 g_164
 */
static int16_t  func_18(const uint64_t  p_19)
{ /* block id: 7 */
    int8_t l_21[3];
    uint16_t l_139 = 0UL;
    int32_t l_140 = 0x93270430L;
    int32_t l_141 = 0xC6D1ADB1L;
    int32_t l_143 = 0xB0204598L;
    int32_t l_144 = 0x8C079A21L;
    int32_t l_145 = 0x90E8D41EL;
    int32_t l_146 = (-1L);
    int32_t l_147[6][5] = {{0x21F0273BL,0x21F0273BL,0x21F0273BL,0x21F0273BL,0x21F0273BL},{0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL},{0x21F0273BL,0x21F0273BL,0x21F0273BL,0x21F0273BL,0x21F0273BL},{0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL},{0x21F0273BL,0x21F0273BL,0x21F0273BL,0x21F0273BL,0x21F0273BL},{0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL,0x84F5D4ABL}};
    int8_t l_158 = 1L;
    int i, j;
    for (i = 0; i < 3; i++)
        l_21[i] = 0x49L;
    l_21[1] ^= p_19;
    l_139 = func_22(p_19);
    g_148++;
    if ((0x62A5L && 65535UL))
    { /* block id: 106 */
        int64_t l_157 = 1L;
        for (g_125 = (-29); (g_125 <= 56); g_125 = safe_add_func_int8_t_s_s(g_125, 2))
        { /* block id: 109 */
            g_28 &= ((((safe_add_func_int8_t_s_s((safe_add_func_int8_t_s_s(l_157, 248UL)), p_19)) != g_110[6]) ^ p_19) >= l_158);
        }
    }
    else
    { /* block id: 112 */
        int32_t l_161[6][2] = {{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)},{(-5L),(-5L)}};
        int i, j;
        for (g_125 = 0; (g_125 <= 8); g_125++)
        { /* block id: 115 */
            l_161[5][1] = (p_19 | g_28);
            g_28 = g_148;
            if (p_19)
                break;
        }
        g_28 = (p_19 & g_79);
        if (g_98)
            goto lbl_167;
lbl_167:
        --g_164;
        g_28 = (safe_mod_func_uint32_t_u_u(((p_19 <= (-1L)) > p_19), g_110[6]));
    }
    return p_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_27 g_45 g_66 g_79 g_73 g_72 g_4 g_98 g_111 g_110 g_125 g_130
 * writes: g_4 g_28 g_45 g_27 g_79 g_98 g_111 g_125 g_130 g_72
 */
static int32_t  func_22(int32_t  p_23)
{ /* block id: 9 */
    uint64_t l_24[8] = {0x357E8F5349DDA4ADLL,0xA5EB5A40A7B48FE2LL,0x357E8F5349DDA4ADLL,0xA5EB5A40A7B48FE2LL,0x357E8F5349DDA4ADLL,0xA5EB5A40A7B48FE2LL,0x357E8F5349DDA4ADLL,0xA5EB5A40A7B48FE2LL};
    int64_t l_87 = 0L;
    int32_t l_105 = 1L;
    int32_t l_109 = 0L;
    int64_t l_116 = 0xC307D3DBF9D0A132LL;
    int i;
    for (g_4 = 0; g_4 < 8; g_4 += 1)
    {
        l_24[g_4] = 0x610F121ADF561F66LL;
    }
lbl_48:
    for (p_23 = (-27); (p_23 >= 26); p_23++)
    { /* block id: 13 */
        for (g_28 = 3; (g_28 < 28); g_28 = safe_add_func_uint8_t_u_u(g_28, 2))
        { /* block id: 16 */
            uint32_t l_31 = 0xAFDF115CL;
            ++l_31;
        }
    }
    if ((safe_sub_func_int32_t_s_s((safe_div_func_int16_t_s_s((1UL >= p_23), g_27)), p_23)))
    { /* block id: 20 */
        int32_t l_42 = 1L;
        for (p_23 = 0; (p_23 < (-13)); p_23 = safe_sub_func_int32_t_s_s(p_23, 7))
        { /* block id: 23 */
            int64_t l_43 = 0x414E4A47BFE1A273LL;
            int32_t l_44 = 0x3B0F6051L;
            l_42 = (((safe_div_func_int16_t_s_s((l_42 && l_24[2]), l_24[1])) > g_27) | l_42);
            l_43 |= ((p_23 > p_23) ^ l_24[6]);
            ++g_45;
            if (l_42)
                goto lbl_48;
        }
    }
    else
    { /* block id: 29 */
        uint16_t l_103 = 0x6B03L;
        int32_t l_104 = 0x9F55D16FL;
        int32_t l_106 = 3L;
        int32_t l_107 = 0L;
        if ((safe_unary_minus_func_int16_t_s((-5L))))
        { /* block id: 30 */
            return g_45;
        }
        else
        { /* block id: 32 */
            uint64_t l_50[2][2][4] = {{{0x27FAAB159BBC08F5LL,0x27FAAB159BBC08F5LL,0x837B75AE7BE98B87LL,0x27FAAB159BBC08F5LL},{0x27FAAB159BBC08F5LL,0x1F28F68172882C65LL,0x1F28F68172882C65LL,0x27FAAB159BBC08F5LL}},{{0x1F28F68172882C65LL,0x27FAAB159BBC08F5LL,0x1F28F68172882C65LL,0x1F28F68172882C65LL},{0x27FAAB159BBC08F5LL,0x27FAAB159BBC08F5LL,0x837B75AE7BE98B87LL,0x27FAAB159BBC08F5LL}}};
            int32_t l_51 = 0x6697289FL;
            int32_t l_108[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int i, j, k;
            l_51 = l_50[0][0][3];
            l_103 = func_52(((((func_56((+0x0CL), p_23, g_28) , 0x50A8L) , p_23) || p_23) == l_87), l_50[0][0][3], g_72);
            l_104 = p_23;
            ++g_111;
        }
        for (l_103 = 0; (l_103 <= 7); l_103 += 1)
        { /* block id: 82 */
            int i;
            return g_110[l_103];
        }
    }
    if ((((0x34L == p_23) != g_79) >= 0xA4DE48ECL))
    { /* block id: 86 */
        return g_66;
    }
    else
    { /* block id: 88 */
        int32_t l_121 = 8L;
        int32_t l_122[6] = {3L,3L,3L,3L,3L,3L};
        int i;
        for (g_111 = 0; (g_111 > 41); g_111 = safe_add_func_uint16_t_u_u(g_111, 1))
        { /* block id: 91 */
            uint8_t l_117 = 0x7AL;
            int32_t l_120 = 0xBE68C9B4L;
            int32_t l_123[7] = {0xADDF9714L,0xADDF9714L,0xADDF9714L,0xADDF9714L,0xADDF9714L,0xADDF9714L,0xADDF9714L};
            int i;
            l_117--;
            g_125++;
            --g_130[2];
        }
        for (g_72 = (-17); (g_72 <= 10); g_72++)
        { /* block id: 98 */
            return p_23;
        }
        g_27 = (safe_rshift_func_uint16_t_u_s((safe_mod_func_uint16_t_u_u(1UL, 65535UL)), 12));
    }
    return p_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_73 g_66 g_98 g_28 g_45
 * writes: g_98
 */
static const int32_t  func_52(uint64_t  p_53, int32_t  p_54, const uint64_t  p_55)
{ /* block id: 62 */
    int8_t l_92 = 0x8DL;
    int32_t l_93 = (-4L);
    l_93 ^= (safe_sub_func_uint16_t_u_u(((safe_add_func_uint32_t_u_u((g_73 <= g_66), l_92)) && l_92), p_54));
    for (l_92 = (-30); (l_92 != (-10)); ++l_92)
    { /* block id: 66 */
        int8_t l_96[3][9] = {{0xFEL,0x20L,0x20L,0xFEL,(-1L),(-9L),0xFEL,(-9L),(-1L)},{0xFEL,0x20L,0x20L,0xFEL,(-1L),(-9L),0xFEL,(-9L),(-1L)},{0xFEL,0x20L,0x20L,0xFEL,(-1L),(-9L),0xFEL,(-9L),(-1L)}};
        int32_t l_97[3][2] = {{1L,1L},{1L,1L},{1L,1L}};
        int i, j;
        g_98++;
        if (g_28)
            continue;
    }
    for (l_92 = 28; (l_92 < (-15)); --l_92)
    { /* block id: 72 */
        return g_45;
    }
    return l_92;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_27 g_66 g_79 g_73 g_72 g_4
 * writes: g_28 g_27 g_79
 */
static uint32_t  func_56(int16_t  p_57, uint8_t  p_58, int32_t  p_59)
{ /* block id: 34 */
    uint64_t l_65 = 2UL;
    int32_t l_67[1][6];
    int64_t l_77 = 1L;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
            l_67[i][j] = 1L;
    }
lbl_82:
    for (p_59 = 15; (p_59 != (-13)); p_59--)
    { /* block id: 37 */
        for (g_28 = (-25); (g_28 > 10); g_28 = safe_add_func_int64_t_s_s(g_28, 5))
        { /* block id: 40 */
            if (l_65)
                break;
            g_27 |= 0xFFF67D69L;
        }
    }
    l_67[0][3] |= g_66;
    l_67[0][5] = ((((2UL >= 65529UL) >= g_27) , p_59) == l_67[0][2]);
    for (l_65 = 14; (l_65 > 60); ++l_65)
    { /* block id: 49 */
        int32_t l_70 = 1L;
        int32_t l_76 = 0x931B7303L;
        int32_t l_78[6] = {0xFE20FE05L,(-4L),(-4L),0xFE20FE05L,(-4L),(-4L)};
        int i;
        if (p_58)
        { /* block id: 50 */
            int16_t l_71 = 2L;
            int32_t l_74 = 1L;
            int32_t l_75[2];
            int i;
            for (i = 0; i < 2; i++)
                l_75[i] = 6L;
            --g_79;
            if (g_73)
                break;
            l_78[2] = l_75[0];
        }
        else
        { /* block id: 54 */
            if (g_27)
                break;
            if (l_65)
                goto lbl_82;
            l_76 = (safe_rshift_func_uint8_t_u_s((safe_mod_func_uint32_t_u_u(g_27, g_72)), 1));
            if (g_28)
                goto lbl_82;
        }
    }
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_45, "g_45", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_73, "g_73", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_110[i], "g_110[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_111, "g_111", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_125, "g_125", print_hash_value);
    transparent_crc(g_128, "g_128", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_130[i], "g_130[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_164, "g_164", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 73
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 79
   depth: 2, occurrence: 19
   depth: 3, occurrence: 6
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 77
XXX times a non-volatile is write: 43
XXX times a volatile is read: 13
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 95
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 1
XXX backward jumps: 3

XXX stmts: 77
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 24
   depth: 1, occurrence: 22
   depth: 2, occurrence: 31

XXX percentage a fresh-made variable is used: 38.8
XXX percentage an existing variable is used: 61.2
********************* end of statistics **********************/

