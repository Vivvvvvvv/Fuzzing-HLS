/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6030291857313328634
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_2 = (-1L);
static volatile uint32_t g_6 = 8UL;/* VOLATILE GLOBAL g_6 */
static volatile int64_t g_9 = 3L;/* VOLATILE GLOBAL g_9 */
static uint32_t g_10 = 0xB4837182L;
static int64_t g_19 = 6L;
static uint8_t g_21 = 0x8EL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_10 g_2 g_19 g_21
 * writes: g_6 g_10 g_21
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_3 = 1L;
    int32_t l_4 = 0L;
    int32_t l_5 = 0xFEBB6748L;
    int32_t l_20 = (-1L);
lbl_13:
    g_6--;
    if ((1L < 0xB6L))
    { /* block id: 2 */
        return l_3;
    }
    else
    { /* block id: 4 */
        --g_10;
        if (l_3)
            goto lbl_13;
        for (l_4 = 0; (l_4 >= (-27)); --l_4)
        { /* block id: 9 */
            uint16_t l_18 = 1UL;
            if (g_6)
                break;
            l_18 = (safe_add_func_int16_t_s_s(g_2, 0xD5A5L));
        }
    }
    l_20 ^= (g_19 , 0x807383CCL);
    g_21 |= (g_19 > 0xC520EA0CL);
    return l_3;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 11
   depth: 2, occurrence: 5

XXX total number of pointers: 0

XXX times a non-volatile is read: 6
XXX times a non-volatile is write: 5
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 84.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 11
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 5
   depth: 1, occurrence: 4
   depth: 2, occurrence: 2

XXX percentage a fresh-made variable is used: 68.8
XXX percentage an existing variable is used: 31.2
********************* end of statistics **********************/

