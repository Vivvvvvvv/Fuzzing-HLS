/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2586604265900111693
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int64_t g_2[7] = {(-4L),(-4L),(-4L),(-4L),(-4L),(-4L),(-4L)};
static int32_t g_3 = 0L;
static int32_t g_4 = 1L;
static uint32_t g_44 = 0UL;
static uint8_t g_59 = 5UL;
static int64_t g_63 = 3L;
static volatile uint16_t g_64 = 65534UL;/* VOLATILE GLOBAL g_64 */
static uint64_t g_70[9][6][4] = {{{1UL,0x79F6133985213603LL,18446744073709551614UL,0x759FFDB42E276980LL},{0x5B9E7DCD999CB54ALL,0x8E70C497A14F8299LL,18446744073709551607UL,0x8E70C497A14F8299LL},{0x10508B3DEF23EAFALL,0x5EF58E71DF66360CLL,1UL,18446744073709551615UL},{18446744073709551607UL,0x43423D51155E3342LL,18446744073709551615UL,1UL},{18446744073709551615UL,0UL,0x5B9E7DCD999CB54ALL,18446744073709551607UL},{18446744073709551615UL,1UL,18446744073709551615UL,3UL}},{{18446744073709551607UL,18446744073709551607UL,1UL,9UL},{0x10508B3DEF23EAFALL,0x759FFDB42E276980LL,18446744073709551607UL,18446744073709551613UL},{0x5B9E7DCD999CB54ALL,3UL,18446744073709551614UL,0UL},{1UL,1UL,0x773301997FBCB15ELL,18446744073709551613UL},{18446744073709551615UL,1UL,0x5B9E7DCD999CB54ALL,18446744073709551615UL},{0x10508B3DEF23EAFALL,0UL,0x10508B3DEF23EAFALL,1UL}},{{1UL,0x5EF58E71DF66360CLL,18446744073709551607UL,1UL},{0UL,0x897151158E584094LL,18446744073709551615UL,0x5EF58E71DF66360CLL},{1UL,0UL,18446744073709551615UL,0x379DE568C3B083FFLL},{0UL,1UL,18446744073709551607UL,9UL},{1UL,18446744073709551614UL,0x10508B3DEF23EAFALL,18446744073709551607UL},{0x10508B3DEF23EAFALL,18446744073709551607UL,0x5B9E7DCD999CB54ALL,0UL}},{{18446744073709551615UL,0x8E70C497A14F8299LL,1UL,0x79F6133985213603LL},{0x02D15FFE8FED2B77LL,0x8E70C497A14F8299LL,18446744073709551615UL,0UL},{6UL,18446744073709551607UL,0x7E88E1234CD2740DLL,18446744073709551607UL},{0xD8ED9CDEFDC0328ALL,18446744073709551614UL,0x773301997FBCB15ELL,9UL},{0x7E88E1234CD2740DLL,1UL,0xDF25DB31B8100404LL,0x379DE568C3B083FFLL},{18446744073709551607UL,0UL,6UL,0x5EF58E71DF66360CLL}},{{18446744073709551607UL,0x897151158E584094LL,0xDF25DB31B8100404LL,1UL},{0x7E88E1234CD2740DLL,0x5EF58E71DF66360CLL,0x773301997FBCB15ELL,1UL},{0xD8ED9CDEFDC0328ALL,0UL,0x7E88E1234CD2740DLL,18446744073709551615UL},{6UL,1UL,18446744073709551615UL,18446744073709551613UL},{0x02D15FFE8FED2B77LL,0x379DE568C3B083FFLL,1UL,18446744073709551613UL},{18446744073709551615UL,1UL,0x5B9E7DCD999CB54ALL,18446744073709551615UL}},{{0x10508B3DEF23EAFALL,0UL,0x10508B3DEF23EAFALL,1UL},{1UL,0x5EF58E71DF66360CLL,18446744073709551607UL,1UL},{0UL,0x897151158E584094LL,18446744073709551615UL,0x5EF58E71DF66360CLL},{1UL,0UL,18446744073709551615UL,0x379DE568C3B083FFLL},{0UL,1UL,18446744073709551607UL,9UL},{1UL,18446744073709551614UL,0x10508B3DEF23EAFALL,18446744073709551607UL}},{{0x10508B3DEF23EAFALL,18446744073709551607UL,0x5B9E7DCD999CB54ALL,0UL},{18446744073709551615UL,0x8E70C497A14F8299LL,1UL,0x79F6133985213603LL},{0x02D15FFE8FED2B77LL,0x8E70C497A14F8299LL,18446744073709551615UL,0UL},{6UL,18446744073709551607UL,0x7E88E1234CD2740DLL,18446744073709551607UL},{0xD8ED9CDEFDC0328ALL,18446744073709551614UL,0x773301997FBCB15ELL,9UL},{0x7E88E1234CD2740DLL,1UL,0xDF25DB31B8100404LL,0x379DE568C3B083FFLL}},{{18446744073709551607UL,0UL,6UL,0x5EF58E71DF66360CLL},{18446744073709551607UL,0x897151158E584094LL,0xDF25DB31B8100404LL,1UL},{0x7E88E1234CD2740DLL,0x5EF58E71DF66360CLL,0x773301997FBCB15ELL,1UL},{0xD8ED9CDEFDC0328ALL,0UL,0x7E88E1234CD2740DLL,18446744073709551615UL},{6UL,1UL,18446744073709551615UL,18446744073709551613UL},{0x02D15FFE8FED2B77LL,0x379DE568C3B083FFLL,1UL,18446744073709551613UL}},{{18446744073709551615UL,1UL,0x5B9E7DCD999CB54ALL,18446744073709551615UL},{0x10508B3DEF23EAFALL,0UL,0x10508B3DEF23EAFALL,1UL},{1UL,0x5EF58E71DF66360CLL,18446744073709551607UL,1UL},{0UL,0x897151158E584094LL,18446744073709551615UL,0x5EF58E71DF66360CLL},{1UL,0UL,18446744073709551615UL,0x379DE568C3B083FFLL},{0UL,1UL,18446744073709551607UL,9UL}}};
static int32_t g_78 = 1L;
static volatile uint64_t g_94 = 7UL;/* VOLATILE GLOBAL g_94 */
static uint16_t g_117 = 0xB72CL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int32_t  func_6(int16_t  p_7, int32_t  p_8, uint8_t  p_9, int8_t  p_10, uint8_t  p_11);
static int32_t  func_14(int32_t  p_15, int16_t  p_16, uint32_t  p_17, int32_t  p_18, uint64_t  p_19);
static int32_t  func_20(int16_t  p_21, int16_t  p_22, uint32_t  p_23);
static uint8_t  func_29(uint32_t  p_30, uint8_t  p_31);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_2 g_44 g_59 g_64 g_78 g_94 g_63 g_70 g_117
 * writes: g_3 g_4 g_44 g_59 g_63 g_64 g_70 g_78 g_94 g_117
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_13 = 0x6A3735B2L;
    int32_t l_86 = 7L;
    int32_t l_93 = 0x4CD9F8BFL;
    for (g_3 = 6; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        uint32_t l_12 = 18446744073709551615UL;
        int32_t l_85[7][3][10] = {{{0L,(-9L),0L,(-9L),0L,0x4E3E385CL,0xCF314C7EL,0L,0x36A8F31CL,0xE35C639BL},{6L,(-9L),0x0EB5B7D9L,0L,0x36A8F31CL,0x4E3E385CL,(-9L),(-1L),(-1L),(-9L)},{1L,0x05DAD87CL,0L,0L,0x05DAD87CL,1L,8L,0xD0F00198L,0x4E3E385CL,0L}},{{0x798753ECL,1L,0L,0x0EB5B7D9L,(-9L),6L,0x0EB5B7D9L,0x798753ECL,0L,0x798753ECL},{0x798753ECL,1L,(-1L),0x05DAD87CL,(-1L),1L,0x798753ECL,0x46AAE942L,1L,1L},{1L,0x798753ECL,0x46AAE942L,1L,1L,0x4E3E385CL,(-1L),0xD0F00198L,0x46AAE942L,0x46AAE942L}},{{1L,0x798753ECL,0xE35C639BL,(-9L),(-9L),0xE35C639BL,0x798753ECL,1L,0L,0x0EB5B7D9L},{0x05DAD87CL,1L,8L,0xD0F00198L,0x4E3E385CL,0L,0x0EB5B7D9L,0x4E3E385CL,1L,(-9L)},{(-1L),1L,8L,0x4E3E385CL,(-8L),0x4E3E385CL,8L,1L,(-1L),8L}},{{0xD0F00198L,0x05DAD87CL,0xE35C639BL,0x0EB5B7D9L,0x05DAD87CL,(-10L),(-9L),0xD0F00198L,0xCF314C7EL,0x0EB5B7D9L},{0x798753ECL,(-1L),0x46AAE942L,0x0EB5B7D9L,8L,8L,0x0EB5B7D9L,0x46AAE942L,(-1L),0x798753ECL},{0x46AAE942L,0xD0F00198L,(-1L),0x4E3E385CL,1L,1L,0x46AAE942L,0x798753ECL,1L,(-1L)}},{{0xD0F00198L,0x798753ECL,0L,0xD0F00198L,1L,0xCF314C7EL,1L,0xD0F00198L,0L,0x798753ECL},{1L,0x46AAE942L,0L,(-9L),8L,0L,0x798753ECL,(-1L),0x46AAE942L,0x0EB5B7D9L},{0x4E3E385CL,0xD0F00198L,8L,1L,0x05DAD87CL,0L,0L,0x05DAD87CL,1L,8L}},{{1L,1L,6L,0x05DAD87CL,(-8L),0xCF314C7EL,(-9L),1L,0L,(-9L)},{0xD0F00198L,0x4E3E385CL,0L,0x0EB5B7D9L,0x4E3E385CL,1L,(-9L),1L,0x4E3E385CL,0x0EB5B7D9L},{0x46AAE942L,1L,0x46AAE942L,0L,(-9L),8L,0L,0x798753ECL,(-1L),0x46AAE942L}},{{0x798753ECL,0xD0F00198L,0L,0x05DAD87CL,1L,(-10L),0x798753ECL,0x798753ECL,(-10L),1L},{0xD0F00198L,0x46AAE942L,0x46AAE942L,0xD0F00198L,(-1L),0x4E3E385CL,1L,1L,0x46AAE942L,0x798753ECL},{(-1L),0x798753ECL,0L,8L,(-1L),6L,0xCF314C7EL,0x36A8F31CL,0xCF314C7EL,6L}}};
        int i, j, k;
        for (g_4 = 6; (g_4 >= 0); g_4 -= 1)
        { /* block id: 6 */
            int i;
            l_85[4][0][9] = ((+(func_6(g_2[g_4], g_4, g_3, l_12, l_13) & 0x3D800CEEL)) && 0xE9A657C7L);
            l_86 ^= (0x84A0L >= g_2[g_4]);
            if (l_85[4][0][9])
                break;
            g_78 = (l_86 >= l_85[4][0][9]);
        }
        if (g_64)
        { /* block id: 51 */
            g_78 &= g_4;
            if (g_3)
                break;
            g_78 = (safe_lshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_s(0xAD6BL, 14)), g_3));
        }
        else
        { /* block id: 55 */
            int64_t l_91 = 0x9A06140C101F1329LL;
            int32_t l_92 = (-1L);
            --g_94;
            g_4 ^= (((safe_mod_func_int8_t_s_s(((0x6D64L >= g_63) , 1L), 0x0EL)) , g_70[7][2][2]) != 0xFBL);
            g_4 ^= ((((~0x1DL) & l_91) < l_86) == 0UL);
            l_92 &= l_93;
        }
        for (l_86 = 6; (l_86 >= 0); l_86 -= 1)
        { /* block id: 63 */
            int i;
            g_78 ^= 7L;
            return g_2[l_86];
        }
    }
    for (l_13 = 0; (l_13 == 23); l_13++)
    { /* block id: 70 */
        const uint32_t l_106 = 18446744073709551615UL;
        g_3 = (safe_div_func_int16_t_s_s(g_64, 65528UL));
        for (g_78 = 0; (g_78 > (-2)); --g_78)
        { /* block id: 74 */
            int64_t l_115 = 0L;
            g_4 = (l_106 , (-1L));
            g_3 = (safe_mul_func_uint16_t_u_u((safe_sub_func_int64_t_s_s((safe_add_func_int16_t_s_s(l_106, g_94)), 0xFDAF309D661093DFLL)), g_44));
            l_86 &= (safe_mod_func_uint16_t_u_u(l_115, g_78));
            if (l_106)
                break;
        }
        if (g_78)
        { /* block id: 80 */
            if (l_106)
                break;
        }
        else
        { /* block id: 82 */
            int32_t l_116[2];
            int i;
            for (i = 0; i < 2; i++)
                l_116[i] = 0x51B1567EL;
            l_86 |= g_63;
            g_117--;
        }
    }
    return g_44;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_4 g_44 g_59 g_64 g_78
 * writes: g_44 g_59 g_63 g_64 g_70 g_78
 */
static int32_t  func_6(int16_t  p_7, int32_t  p_8, uint8_t  p_9, int8_t  p_10, uint8_t  p_11)
{ /* block id: 7 */
    uint8_t l_24 = 0x9CL;
    uint64_t l_68 = 1UL;
    uint64_t l_73[6] = {0x4CD7CE17D650891FLL,0x4CD7CE17D650891FLL,0xE7F6E9516CEA6E34LL,0x4CD7CE17D650891FLL,0x4CD7CE17D650891FLL,0xE7F6E9516CEA6E34LL};
    int i;
    p_8 = func_14(func_20(l_24, g_3, p_7), g_2[4], l_24, l_68, g_4);
    if (((-1L) != 0UL))
    { /* block id: 37 */
        p_8 = (safe_add_func_int8_t_s_s((0x5A5E5293L ^ l_73[4]), l_24));
    }
    else
    { /* block id: 39 */
        int32_t l_83 = 1L;
        p_8 = ((((safe_mul_func_int8_t_s_s((0xEFF9D668L && p_10), p_7)) , 65528UL) > p_9) <= l_68);
        g_78 = (((safe_lshift_func_int8_t_s_u((g_3 <= g_3), l_73[4])) , 0x3E55L) >= l_73[4]);
        g_78 = ((safe_div_func_int8_t_s_s((((safe_sub_func_uint16_t_u_u(65535UL, 1UL)) && p_7) == g_59), 255UL)) , l_83);
    }
    g_78 ^= (~g_59);
    return p_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_70
 */
static int32_t  func_14(int32_t  p_15, int16_t  p_16, uint32_t  p_17, int32_t  p_18, uint64_t  p_19)
{ /* block id: 33 */
    uint32_t l_69 = 18446744073709551615UL;
    g_70[7][0][2] = l_69;
    return g_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_4 g_44 g_59 g_64
 * writes: g_44 g_59 g_63 g_64
 */
static int32_t  func_20(int16_t  p_21, int16_t  p_22, uint32_t  p_23)
{ /* block id: 8 */
    uint16_t l_38 = 65527UL;
    int32_t l_57 = 0L;
    uint64_t l_67 = 0xABD35EB13E27C213LL;
    if ((safe_mul_func_uint8_t_u_u(((safe_mul_func_int16_t_s_s(((func_29(((safe_rshift_func_int16_t_s_s(((safe_lshift_func_int8_t_s_u((safe_mod_func_int16_t_s_s(0xE6C8L, g_3)), p_21)) & l_38), g_3)) < g_2[5]), l_38) > p_23) >= p_23), l_38)) < g_4), 0x97L)))
    { /* block id: 13 */
        uint64_t l_58[1];
        int i;
        for (i = 0; i < 1; i++)
            l_58[i] = 0UL;
        for (p_22 = 0; (p_22 == (-27)); p_22--)
        { /* block id: 16 */
            int32_t l_60 = (-2L);
            l_57 &= (safe_add_func_uint8_t_u_u((!(((65526UL != l_38) || g_3) | g_4)), p_23));
            g_59 = ((g_2[2] == p_22) , l_58[0]);
            if (l_60)
                break;
            if (g_2[4])
                continue;
        }
        for (l_38 = 17; (l_38 > 53); ++l_38)
        { /* block id: 24 */
            g_63 = ((g_59 < 0x6CF3632EL) , g_2[5]);
            g_64++;
            return p_22;
        }
    }
    else
    { /* block id: 29 */
        l_57 = 0x50C16569L;
    }
    return l_67;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_44
 * writes: g_44
 */
static uint8_t  func_29(uint32_t  p_30, uint8_t  p_31)
{ /* block id: 9 */
    uint8_t l_43 = 0UL;
    int32_t l_51[6] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
    int i;
    g_44 &= (+((safe_unary_minus_func_int32_t_s((((((safe_add_func_uint32_t_u_u(l_43, g_2[0])) ^ g_4) > p_30) , p_30) | 0x21L))) != g_4));
    l_51[4] = (safe_sub_func_int64_t_s_s((safe_add_func_uint32_t_u_u((safe_sub_func_int16_t_s_s(l_43, 1L)), p_31)), g_2[5]));
    return l_51[4];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_44, "g_44", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_70[i][j][k], "g_70[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 30
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 55
   depth: 2, occurrence: 13
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 92
XXX times a non-volatile is write: 35
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 40
XXX percentage of non-volatile access: 96.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 54
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 13
   depth: 2, occurrence: 27

XXX percentage a fresh-made variable is used: 23.3
XXX percentage an existing variable is used: 76.7
********************* end of statistics **********************/

