/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4732786839282077209
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_2 = 18446744073709551615UL;/* VOLATILE GLOBAL g_2 */
static int64_t g_4[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static uint16_t g_5 = 0UL;
static int32_t g_15[6] = {0x9F08664AL,0x9F08664AL,0x9F08664AL,0x9F08664AL,0x9F08664AL,0x9F08664AL};
static int32_t g_28 = 6L;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_21(int16_t  p_22);
static int32_t  func_29(const int32_t  p_30, int64_t  p_31, int64_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_15 g_28 g_4
 * writes: g_5 g_15 g_28
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_3[3];
    uint32_t l_20 = 0x3D1AA12AL;
    int32_t l_59 = 0xB93B5720L;
    int i;
    for (i = 0; i < 3; i++)
        l_3[i] = 0xD4F2L;
    if (((g_2 == 0x446DF37DL) || l_3[2]))
    { /* block id: 1 */
        return g_2;
    }
    else
    { /* block id: 3 */
        uint32_t l_14 = 0x3DDCA272L;
        ++g_5;
        g_15[0] |= ((safe_rshift_func_uint16_t_u_s(((safe_div_func_uint32_t_u_u((safe_div_func_int16_t_s_s(0x7855L, l_3[2])), g_5)) || l_3[0]), l_14)) < 1L);
    }
    for (g_5 = 0; (g_5 >= 37); g_5 = safe_add_func_int8_t_s_s(g_5, 6))
    { /* block id: 9 */
        int32_t l_27 = 5L;
        int32_t l_56 = 0x3A39D8E7L;
        g_15[1] = (safe_sub_func_uint16_t_u_u(((l_3[1] != l_20) <= 0xF4L), g_15[0]));
        l_56 = func_21((safe_div_func_int32_t_s_s((safe_div_func_int16_t_s_s((l_27 , (-4L)), l_27)), 0x52BF390FL)));
    }
    l_59 = (safe_mul_func_uint16_t_u_u(0x391DL, g_4[2]));
    g_15[4] = ((safe_add_func_int8_t_s_s(l_20, l_3[1])) > l_59);
    return l_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_28 g_15 g_2 g_5 g_4
 * writes: g_28 g_15
 */
static int32_t  func_21(int16_t  p_22)
{ /* block id: 11 */
    const int64_t l_46 = 0x83EB999C826FFEA1LL;
    int32_t l_47 = 1L;
lbl_45:
    for (p_22 = 1; (p_22 <= 5); p_22 += 1)
    { /* block id: 14 */
        uint64_t l_40 = 0UL;
        int32_t l_41[5];
        int i;
        for (i = 0; i < 5; i++)
            l_41[i] = 0x256FAE7AL;
        for (g_28 = 5; (g_28 >= 0); g_28 -= 1)
        { /* block id: 17 */
            uint64_t l_42 = 0xCE17C927DB40437ELL;
            int i;
            g_15[g_28] = func_29((safe_sub_func_int16_t_s_s((+((safe_mod_func_int16_t_s_s((g_15[p_22] , g_2), 1L)) && p_22)), p_22)), g_15[4], p_22);
            g_15[0] = (((safe_lshift_func_uint16_t_u_s(g_5, l_40)) , g_15[p_22]) && l_40);
            l_41[2] = p_22;
            ++l_42;
        }
        if (g_28)
            goto lbl_45;
    }
    l_47 = l_46;
    l_47 = p_22;
    l_47 = ((((((((safe_div_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(((((safe_div_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((l_47 || g_15[2]), g_4[1])), p_22)) != 6L) & l_46) , g_4[3]), 7)), l_47)) , p_22) < 0x02L) & l_46) , l_46) , l_47) || 0UL) == 0x5688AFC0L);
    return l_46;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_29(const int32_t  p_30, int64_t  p_31, int64_t  p_32)
{ /* block id: 18 */
    return p_32;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_4[i], "g_4[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_15[i], "g_15[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_28, "g_28", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 23
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 43
XXX times a non-volatile is write: 16
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 95.2

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 22
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 7
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 25.9
XXX percentage an existing variable is used: 74.1
********************* end of statistics **********************/

