/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2480120837386246580
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_4 = (-1L);
static int32_t g_6 = (-1L);
static uint32_t g_14 = 4294967293UL;
static int64_t g_24 = (-1L);
static volatile int64_t g_25[8] = {(-1L),0xA8C98AAC1E0F758FLL,(-1L),(-1L),0xA8C98AAC1E0F758FLL,(-1L),(-1L),0xA8C98AAC1E0F758FLL};
static uint32_t g_31 = 0x3020F620L;
static volatile int32_t g_34 = 0L;/* VOLATILE GLOBAL g_34 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int16_t  func_7(uint16_t  p_8, int32_t  p_9, int64_t  p_10);
static int32_t  func_11(int32_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_6 g_14 g_31 g_25 g_24 g_34
 * writes: g_6 g_14 g_31 g_34
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_5[6];
    int i;
    for (i = 0; i < 6; i++)
        l_5[i] = 0xDE0B4074L;
    g_6 = (safe_mul_func_int8_t_s_s(g_4, l_5[5]));
    l_5[5] = (func_7(g_4, l_5[5], g_6) == 0xD12FL);
    g_34 = ((safe_div_func_int32_t_s_s((safe_rshift_func_uint16_t_u_s(65531UL, g_24)), l_5[3])) == g_34);
    return l_5[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_14 g_4 g_31 g_25
 * writes: g_14 g_31 g_34
 */
static int16_t  func_7(uint16_t  p_8, int32_t  p_9, int64_t  p_10)
{ /* block id: 2 */
    p_9 = func_11(g_6);
    return g_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_4 g_31 g_25
 * writes: g_14 g_31 g_34
 */
static int32_t  func_11(int32_t  p_12)
{ /* block id: 3 */
    int8_t l_13[10] = {0xAAL,0xAAL,0xAAL,0xAAL,0xAAL,0xAAL,0xAAL,0xAAL,0xAAL,0xAAL};
    int i;
    g_14 |= (l_13[1] | p_12);
    if (((safe_rshift_func_int8_t_s_s((((safe_rshift_func_uint8_t_u_s((((((((safe_lshift_func_uint16_t_u_s(((safe_sub_func_int16_t_s_s((((l_13[7] < p_12) == 0x7EL) & p_12), p_12)) , 65531UL), 11)) ^ 0UL) != l_13[0]) > 1UL) | p_12) & g_14) , p_12), 5)) <= g_4) <= l_13[1]), 6)) <= 0xEF3BL))
    { /* block id: 5 */
        uint32_t l_23[1];
        int i;
        for (i = 0; i < 1; i++)
            l_23[i] = 4294967290UL;
        l_23[0] |= g_4;
    }
    else
    { /* block id: 7 */
        int32_t l_26 = 0x47C914A3L;
        int64_t l_27 = 3L;
        int32_t l_28 = (-9L);
        int32_t l_29 = 0x52601C8DL;
        int32_t l_30 = 1L;
        --g_31;
        g_34 = g_25[2];
    }
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 24
XXX times a non-volatile is write: 6
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 88.2

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 35.7
XXX percentage an existing variable is used: 64.3
********************* end of statistics **********************/

