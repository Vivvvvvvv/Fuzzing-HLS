/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9259375367711260182
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_6 = 0x1EL;/* VOLATILE GLOBAL g_6 */
static const uint8_t g_7[2] = {255UL,255UL};
static int16_t g_8 = (-6L);
static volatile uint32_t g_25[6] = {0xEDF47F28L,0xEDF47F28L,0xEDF47F28L,0xEDF47F28L,0xEDF47F28L,0xEDF47F28L};
static uint64_t g_39[7] = {9UL,9UL,9UL,9UL,9UL,9UL,9UL};
static volatile int64_t g_40[7] = {0x8B036C8609E00C25LL,0x8B036C8609E00C25LL,0x8B036C8609E00C25LL,0x8B036C8609E00C25LL,0x8B036C8609E00C25LL,0x8B036C8609E00C25LL,0x8B036C8609E00C25LL};
static int32_t g_47 = 0xC37069E5L;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static const int32_t  func_17(const uint32_t  p_18, uint32_t  p_19, int8_t  p_20);
static const uint16_t  func_26(int8_t  p_27, int32_t  p_28);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_7 g_8 g_25 g_40 g_47 g_39
 * writes: g_8 g_25 g_39 g_47
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_5 = 0xC5A654FDDD3F4672LL;
    uint32_t l_9[1];
    int32_t l_15 = 0xDB785B64L;
    int32_t l_51 = 0L;
    int i;
    for (i = 0; i < 1; i++)
        l_9[i] = 0xFCC58A01L;
lbl_16:
    g_8 = (((+(safe_mod_func_int32_t_s_s(0L, l_5))) , g_6) == g_7[1]);
    for (l_5 = 0; (l_5 <= 0); l_5 += 1)
    { /* block id: 4 */
        int32_t l_14 = 7L;
        int i;
        l_15 = ((safe_add_func_uint64_t_u_u((safe_sub_func_int8_t_s_s((l_9[l_5] >= l_9[0]), 1UL)), l_9[l_5])) , l_14);
        for (l_15 = 0; (l_15 <= 0); l_15 += 1)
        { /* block id: 8 */
            if (l_15)
                goto lbl_16;
        }
    }
    l_51 &= func_17(((((+(((safe_mod_func_int8_t_s_s(1L, l_9[0])) < l_5) , 5UL)) , g_7[1]) <= 0x3EL) & 6L), l_15, l_15);
    for (l_5 = 0; (l_5 != 28); l_5++)
    { /* block id: 34 */
        uint64_t l_54[2];
        int i;
        for (i = 0; i < 2; i++)
            l_54[i] = 0x937B1BDA2DD44351LL;
        --l_54[0];
        l_15 |= ((l_54[0] & g_39[0]) , l_5);
    }
    return l_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_25 g_6 g_7 g_40 g_47 g_39
 * writes: g_8 g_25 g_39 g_47
 */
static const int32_t  func_17(const uint32_t  p_18, uint32_t  p_19, int8_t  p_20)
{ /* block id: 12 */
    uint64_t l_24[10] = {2UL,2UL,2UL,2UL,2UL,2UL,2UL,2UL,2UL,2UL};
    int32_t l_50 = (-10L);
    int i;
    for (g_8 = 7; (g_8 >= 0); g_8 -= 1)
    { /* block id: 15 */
        int i;
        if (l_24[g_8])
            break;
        g_25[0] ^= 0x9EC6EA3DL;
    }
    if (((func_26(p_20, g_25[0]) , 0x349DL) | l_24[4]))
    { /* block id: 23 */
        volatile uint64_t l_41 = 18446744073709551615UL;/* VOLATILE GLOBAL l_41 */
        l_41 = g_40[6];
        return p_20;
    }
    else
    { /* block id: 26 */
        int16_t l_46 = (-3L);
        g_47 &= (safe_div_func_int8_t_s_s(((safe_add_func_uint64_t_u_u(((g_7[1] & 0x71L) > 0UL), p_20)) , l_46), l_24[7]));
    }
    l_50 = ((safe_add_func_int32_t_s_s((l_24[0] == g_39[4]), g_7[0])) , 0xA5CD23E8L);
    return g_25[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_7
 * writes: g_39
 */
static const uint16_t  func_26(int8_t  p_27, int32_t  p_28)
{ /* block id: 19 */
    int64_t l_35 = 0L;
    int32_t l_36[8] = {(-1L),0x49124C6EL,0x49124C6EL,(-1L),0x49124C6EL,0x49124C6EL,(-1L),0x49124C6EL};
    int i;
    l_36[1] = (((safe_sub_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((safe_add_func_uint64_t_u_u((g_6 , p_28), 1L)), g_7[1])), 0x49CE5708L)) < p_28) >= l_35);
    g_39[0] = (((safe_add_func_int8_t_s_s(g_7[1], l_36[7])) || 0L) == (-8L));
    return p_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8, "g_8", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_40[i], "g_40[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_47, "g_47", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 20
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 37
XXX times a non-volatile is write: 13
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 20
XXX percentage of non-volatile access: 87.7

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 22
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 9
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 36.2
XXX percentage an existing variable is used: 63.8
********************* end of statistics **********************/

