/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2572511754463177865
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0xC6E5C7A0L;
static int32_t g_6 = (-9L);
static uint32_t g_15 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_7(uint8_t  p_8, int8_t  p_9, int16_t  p_10, int8_t  p_11, int8_t  p_12);
static int8_t  func_21(int64_t  p_22, int64_t  p_23, uint32_t  p_24);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_15
 * writes: g_2 g_6 g_15
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int64_t l_5[5] = {0x6C74AA0D72276B87LL,0x6C74AA0D72276B87LL,0x6C74AA0D72276B87LL,0x6C74AA0D72276B87LL,0x6C74AA0D72276B87LL};
    int i;
    for (g_2 = 0; (g_2 == 1); g_2++)
    { /* block id: 3 */
        uint32_t l_17 = 18446744073709551615UL;
        uint32_t l_25 = 0x37B187B3L;
        for (g_6 = 4; (g_6 >= 0); g_6 -= 1)
        { /* block id: 6 */
            int8_t l_16 = 4L;
            int32_t l_20 = 1L;
            if (g_6)
                break;
            g_15 = func_7(g_6, l_5[3], g_6, l_5[2], g_6);
            --l_17;
            l_20 ^= (g_15 != 0x7C71L);
        }
        g_6 = ((func_7(((func_21((g_2 , l_5[3]), l_25, g_2) == 1L) , l_5[0]), l_5[3], l_5[2], g_6, l_5[0]) , g_15) && 0xC7A8L);
    }
    return l_5[3];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_7(uint8_t  p_8, int8_t  p_9, int16_t  p_10, int8_t  p_11, int8_t  p_12)
{ /* block id: 8 */
    int64_t l_13 = 0x0EEC299E885DC1B6LL;
    int32_t l_14 = 3L;
    l_13 &= (0xA017779AL == p_12);
    l_14 = l_13;
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int8_t  func_21(int64_t  p_22, int64_t  p_23, uint32_t  p_24)
{ /* block id: 16 */
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 12
   depth: 2, occurrence: 4
   depth: 6, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 24
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 12
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 24.1
XXX percentage an existing variable is used: 75.9
********************* end of statistics **********************/

