/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11714694342925796396
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
   volatile int32_t  f1;
   volatile uint32_t  f2;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_12 = 18446744073709551615UL;
static uint32_t g_13[2] = {1UL,1UL};
static volatile int16_t g_26 = 0xB812L;/* VOLATILE GLOBAL g_26 */
static volatile uint8_t g_27 = 0x93L;/* VOLATILE GLOBAL g_27 */
static volatile struct S0 g_31 = {0UL,-8L,0x6F0D4A7CL};/* VOLATILE GLOBAL g_31 */
static uint8_t g_36[3] = {0x62L,0x62L,0x62L};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint16_t  func_2(int8_t  p_3);
static uint8_t  func_10(uint16_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_13 g_27 g_31 g_36
 * writes: g_13 g_27 g_36
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_20 = 0x270F9E3DL;
    volatile int32_t l_30 = 0xDF11CAF1L;/* VOLATILE GLOBAL l_30 */
    int16_t l_32 = 1L;
    int32_t l_33 = 5L;
    int32_t l_34 = 0x76DCB0C7L;
    int32_t l_35 = 0xC8D3FD90L;
    l_30 = ((func_2(((safe_add_func_int32_t_s_s((safe_mod_func_int8_t_s_s((safe_sub_func_int16_t_s_s((func_10(g_12) >= g_12), g_12)), g_12)), l_20)) , g_12)) < g_12) , g_27);
    l_30 = ((g_31 , l_20) && 65535UL);
    l_32 = (5UL < l_30);
    ++g_36[1];
    return l_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_27
 * writes: g_27
 */
static uint16_t  func_2(int8_t  p_3)
{ /* block id: 6 */
    uint8_t l_21 = 0UL;
    int32_t l_22 = 0xFBA2522AL;
    int8_t l_23 = 0x0DL;
    int8_t l_24 = 1L;
    int32_t l_25[2];
    int i;
    for (i = 0; i < 2; i++)
        l_25[i] = 1L;
    l_22 ^= ((((p_3 == 0x1DB6084EDC0223DELL) == p_3) , l_21) != 2L);
    g_27++;
    l_25[0] = p_3;
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_13
 * writes: g_13
 */
static uint8_t  func_10(uint16_t  p_11)
{ /* block id: 1 */
    int8_t l_14 = 0x66L;
    int32_t l_15 = 0x29EDCA8FL;
    g_13[0] ^= g_12;
    l_15 = ((l_14 && 0x27213EC752F67D50LL) , (-7L));
    l_15 &= (((safe_add_func_uint8_t_u_u((safe_mul_func_int8_t_s_s(g_13[0], p_11)), 0x69L)) & 0L) || g_13[1]);
    return g_12;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_31.f0, "g_31.f0", print_hash_value);
    transparent_crc(g_31.f1, "g_31.f1", print_hash_value);
    transparent_crc(g_31.f2, "g_31.f2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_36[i], "g_36[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 5, occurrence: 2
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 19
XXX times a non-volatile is write: 7
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 12
XXX percentage of non-volatile access: 78.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 13

XXX percentage a fresh-made variable is used: 40.4
XXX percentage an existing variable is used: 59.6
********************* end of statistics **********************/

