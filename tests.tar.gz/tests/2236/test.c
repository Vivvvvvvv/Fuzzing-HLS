/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17274091454995656746
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3[9] = {(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L),(-6L)};
static uint8_t g_26 = 0x16L;
static int16_t g_27 = (-1L);
static int64_t g_31[4] = {1L,1L,1L,1L};
static int32_t g_32 = 0x3BBA684AL;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint8_t  func_4(uint32_t  p_5, const uint64_t  p_6, int64_t  p_7, uint8_t  p_8, uint64_t  p_9);
static int32_t  func_10(const int32_t  p_11, int8_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_26 g_27 g_32
 * writes: g_3 g_26 g_27 g_31 g_32
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[5];
    int32_t l_33 = 2L;
    int i;
    for (i = 0; i < 5; i++)
        l_2[i] = 0xC93B4E1AL;
    for (g_3[5] = 1; (g_3[5] <= 4); g_3[5] += 1)
    { /* block id: 3 */
        int i;
        g_32 &= (func_4((((func_10((l_2[g_3[5]] && g_3[5]), l_2[g_3[5]]) & 7UL) ^ g_3[4]) , 6UL), l_2[g_3[5]], g_3[5], g_3[5], l_2[4]) > (-1L));
    }
    l_33 = l_2[4];
    return l_2[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_26 g_27 g_3
 * writes: g_26 g_27 g_31
 */
static uint8_t  func_4(uint32_t  p_5, const uint64_t  p_6, int64_t  p_7, uint8_t  p_8, uint64_t  p_9)
{ /* block id: 8 */
    uint32_t l_19[6] = {0x0090AE73L,0x0090AE73L,0UL,0x0090AE73L,0x0090AE73L,0UL};
    int i;
    for (p_7 = 5; (p_7 >= 0); p_7 -= 1)
    { /* block id: 11 */
        int32_t l_28 = 0x3B03C3FAL;
        int i;
        g_26 |= (safe_lshift_func_uint8_t_u_s((safe_sub_func_int8_t_s_s((safe_rshift_func_uint8_t_u_s(247UL, l_19[p_7])), l_19[p_7])), 2));
        g_27 &= (l_19[p_7] & l_19[p_7]);
        l_28 = 0x23A34071L;
        g_31[3] = ((safe_div_func_uint64_t_u_u(p_5, 18446744073709551615UL)) < p_6);
    }
    return g_3[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static int32_t  func_10(const int32_t  p_11, int8_t  p_12)
{ /* block id: 4 */
    int64_t l_13[7] = {0x9CF13E13A6C9CD49LL,0x9CF13E13A6C9CD49LL,0xCE008FB0B44CF592LL,0x9CF13E13A6C9CD49LL,0x9CF13E13A6C9CD49LL,0xCE008FB0B44CF592LL,0x9CF13E13A6C9CD49LL};
    int8_t l_14 = (-7L);
    int32_t l_15[7];
    const uint32_t l_18 = 0x82E77E81L;
    int i;
    for (i = 0; i < 7; i++)
        l_15[i] = 1L;
    l_15[0] ^= ((g_3[6] , l_13[1]) != l_14);
    l_15[5] = (safe_rshift_func_int8_t_s_u(l_18, g_3[5]));
    return l_15[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_31[i], "g_31[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_32, "g_32", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 38.5
XXX percentage an existing variable is used: 61.5
********************* end of statistics **********************/

