/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5016929673466415983
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int16_t g_11 = (-5L);
static int32_t g_20 = 0xA2F3817DL;
static int64_t g_22 = (-6L);
static volatile uint64_t g_24[7] = {8UL,8UL,8UL,8UL,8UL,8UL,8UL};


/* --- FORWARD DECLARATIONS --- */
static const uint16_t  func_1(void);
static int32_t  func_2(uint8_t  p_3, const uint8_t  p_4, int8_t  p_5, int64_t  p_6, uint16_t  p_7);
static int32_t  func_13(uint16_t  p_14, int32_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_22 g_24
 * writes: g_20 g_22 g_24
 */
static const uint16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_10 = (-2L);
    uint16_t l_12 = 65528UL;
    int32_t l_23 = 0x19A6FDD8L;
    g_22 ^= func_2((safe_rshift_func_uint8_t_u_s(((l_10 | (-8L)) , 0x92L), g_11)), g_11, l_12, g_11, g_11);
    g_24[6]--;
    l_23 = ((-1L) || 0x2DL);
    g_20 = 1L;
    return g_24[6];
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes: g_20
 */
static int32_t  func_2(uint8_t  p_3, const uint8_t  p_4, int8_t  p_5, int64_t  p_6, uint16_t  p_7)
{ /* block id: 1 */
    uint32_t l_21 = 0x3403CA95L;
    g_20 = func_13(g_11, p_4);
    g_20 = l_21;
    return l_21;
}


/* ------------------------------------------ */
/* 
 * reads : g_11
 * writes:
 */
static int32_t  func_13(uint16_t  p_14, int32_t  p_15)
{ /* block id: 2 */
    uint8_t l_18 = 248UL;
    uint16_t l_19 = 1UL;
    l_19 &= ((safe_div_func_uint64_t_u_u(0x70012AF0488F4F36LL, g_11)) == l_18);
    return l_18;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_24[i], "g_24[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 13
XXX times a non-volatile is write: 6
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2
XXX percentage of non-volatile access: 90.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 10
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 10

XXX percentage a fresh-made variable is used: 43.5
XXX percentage an existing variable is used: 56.5
********************* end of statistics **********************/

