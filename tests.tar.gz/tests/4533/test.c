/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13279223889863447401
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int32_t  f0;
   uint32_t  f1;
   const volatile uint32_t  f2;
   int16_t  f3;
   uint32_t  f4;
   int64_t  f5;
   const int32_t  f6;
   volatile uint8_t  f7;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_15 = 1UL;
static volatile uint8_t g_16 = 253UL;/* VOLATILE GLOBAL g_16 */
static uint8_t g_24 = 8UL;
static struct S0 g_25 = {0x1FAFBF26L,0x718BC698L,4294967295UL,0x9CA4L,18446744073709551615UL,1L,0x63372585L,1UL};/* VOLATILE GLOBAL g_25 */


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, int32_t  p_5, int8_t  p_6, uint32_t  p_7);
static uint8_t  func_10(uint8_t  p_11, int8_t  p_12, uint32_t  p_13, int32_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_16 g_24 g_25
 * writes: g_16 g_24
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int8_t l_19 = 0x79L;
    int32_t l_21 = (-1L);
    l_21 = func_2((safe_mul_func_uint8_t_u_u(func_10(g_15, g_15, g_15, g_15), g_15)), g_15, g_15, l_19, g_15);
    for (l_19 = 0; (l_19 != (-15)); l_19 = safe_sub_func_int64_t_s_s(l_19, 3))
    { /* block id: 10 */
        g_24 &= (((l_21 ^ l_19) > l_19) ^ 0x43L);
    }
    return g_25;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, int32_t  p_5, int8_t  p_6, uint32_t  p_7)
{ /* block id: 4 */
    int32_t l_20 = 0xC1B6EAB3L;
    l_20 = 0x1780EEC2L;
    return l_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_16
 * writes: g_16
 */
static uint8_t  func_10(uint8_t  p_11, int8_t  p_12, uint32_t  p_13, int32_t  p_14)
{ /* block id: 1 */
    g_16--;
    return g_16;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25.f0, "g_25.f0", print_hash_value);
    transparent_crc(g_25.f1, "g_25.f1", print_hash_value);
    transparent_crc(g_25.f2, "g_25.f2", print_hash_value);
    transparent_crc(g_25.f3, "g_25.f3", print_hash_value);
    transparent_crc(g_25.f4, "g_25.f4", print_hash_value);
    transparent_crc(g_25.f5, "g_25.f5", print_hash_value);
    transparent_crc(g_25.f6, "g_25.f6", print_hash_value);
    transparent_crc(g_25.f7, "g_25.f7", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 1
   depth: 4, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 15
XXX times a non-volatile is write: 4
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 3
XXX percentage of non-volatile access: 90.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 1

XXX percentage a fresh-made variable is used: 35
XXX percentage an existing variable is used: 65
********************* end of statistics **********************/

