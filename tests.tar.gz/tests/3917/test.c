/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13771231362948627393
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_9 = 0xB03629AAL;
static uint8_t g_38 = 0UL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint8_t  func_2(int64_t  p_3, uint16_t  p_4, int32_t  p_5, uint64_t  p_6, uint32_t  p_7);
static uint32_t  func_12(uint32_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_38
 * writes: g_38 g_9
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_8 = (-1L);
    int32_t l_41 = (-1L);
    l_41 = (func_2(l_8, g_9, g_9, g_9, l_8) ^ l_41);
lbl_45:
    g_9 = (!(((g_38 , 0xBDL) >= 0xBEL) & (-9L)));
    l_41 = ((safe_mod_func_int64_t_s_s(0x9B964069A3E2BE8CLL, l_41)) > 8L);
    if (l_41)
        goto lbl_45;
    return l_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_38
 * writes: g_38
 */
static uint8_t  func_2(int64_t  p_3, uint16_t  p_4, int32_t  p_5, uint64_t  p_6, uint32_t  p_7)
{ /* block id: 1 */
    uint16_t l_21 = 0UL;
    int32_t l_22 = 0x68AA2D34L;
    uint32_t l_33 = 0xB7BE2D3DL;
    l_22 = (safe_add_func_uint32_t_u_u(func_12(((safe_lshift_func_int16_t_s_u((safe_mul_func_uint8_t_u_u(0xD0L, 0x89L)), 2)) >= g_9)), l_21));
    for (l_21 = (-9); (l_21 < 27); ++l_21)
    { /* block id: 11 */
        uint8_t l_37 = 255UL;
        l_33 = (safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s((((safe_mul_func_int16_t_s_s(((safe_sub_func_int32_t_s_s(1L, 1UL)) & 1UL), p_3)) != l_22) <= l_22), 1)), p_4));
        if (p_6)
            continue;
        l_37 = ((((((safe_add_func_uint64_t_u_u((~(l_21 > 0xC4438182L)), p_6)) < 0x6BAE055AL) == l_21) <= p_5) <= g_9) , p_6);
        if (p_3)
            break;
    }
    --g_38;
    return l_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_9
 * writes:
 */
static uint32_t  func_12(uint32_t  p_13)
{ /* block id: 2 */
    uint32_t l_20 = 0UL;
    if (((safe_lshift_func_int16_t_s_u(p_13, l_20)) && g_9))
    { /* block id: 3 */
        return g_9;
    }
    else
    { /* block id: 5 */
        return l_20;
    }
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 30
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 16
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 6

XXX percentage a fresh-made variable is used: 23.7
XXX percentage an existing variable is used: 76.3
********************* end of statistics **********************/

