/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11139601966098252802
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 3L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = 1L;
static int32_t g_6 = 0L;
static volatile uint64_t g_11 = 18446744073709551609UL;/* VOLATILE GLOBAL g_11 */
static uint16_t g_14 = 0x8D19L;


/* --- FORWARD DECLARATIONS --- */
static const int32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_11 g_14 g_6
 * writes: g_3 g_11 g_14 g_6
 */
static const int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9 = 0x1D962EE6L;
    const uint32_t l_23 = 0UL;
    for (g_3 = 0; (g_3 >= 0); g_3--)
    { /* block id: 3 */
        int16_t l_7 = 0xB315L;
        int32_t l_8 = 0x0A77C874L;
        int32_t l_10 = 0x5A23E86FL;
        if (g_2)
        { /* block id: 4 */
            g_11--;
            if (g_11)
                break;
        }
        else
        { /* block id: 7 */
            const uint32_t l_17 = 1UL;
            g_14--;
            return l_17;
        }
    }
    for (g_6 = 1; (g_6 != 28); g_6 = safe_add_func_int16_t_s_s(g_6, 1))
    { /* block id: 14 */
        uint8_t l_20 = 254UL;
        l_20++;
    }
    return l_23;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_6, "g_6", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 2
breakdown:
   depth: 1, occurrence: 10
   depth: 2, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 4
XXX times a non-volatile is write: 4
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 9
XXX percentage of non-volatile access: 72.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 9
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 3
   depth: 1, occurrence: 2
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 66.7
XXX percentage an existing variable is used: 33.3
********************* end of statistics **********************/

