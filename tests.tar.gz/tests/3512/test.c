/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15863749575395789646
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_4 = 5L;/* VOLATILE GLOBAL g_4 */
static uint16_t g_5 = 0xB63EL;
static uint16_t g_23 = 0x10E5L;
static volatile int16_t g_24 = 1L;/* VOLATILE GLOBAL g_24 */
static volatile uint16_t g_26 = 0x8163L;/* VOLATILE GLOBAL g_26 */
static uint64_t g_33 = 0xB8CE22955D482642LL;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static const int32_t  func_8(uint16_t  p_9, int32_t  p_10, int32_t  p_11, uint8_t  p_12, int8_t  p_13);
static uint8_t  func_16(uint64_t  p_17, uint32_t  p_18, uint32_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_23 g_24 g_26
 * writes: g_5 g_23 g_24 g_26 g_33
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0xBE8E56F9L;
    int32_t l_3[4] = {0x9FB023EDL,0x9FB023EDL,0x9FB023EDL,0x9FB023EDL};
    int i;
    l_2 = 0x26BDDE0BL;
    l_3[1] = (l_2 , l_2);
    ++g_5;
    g_33 = func_8((safe_mod_func_uint64_t_u_u((func_16((l_3[3] , g_5), l_3[1], l_2) && g_23), l_3[1])), g_5, g_5, g_5, g_5);
    return l_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_26
 * writes: g_26
 */
static const int32_t  func_8(uint16_t  p_9, int32_t  p_10, int32_t  p_11, uint8_t  p_12, int8_t  p_13)
{ /* block id: 10 */
    int8_t l_31 = 6L;
    int32_t l_32 = 0xB503B5B0L;
    g_26++;
    l_32 = ((safe_mul_func_uint8_t_u_u(((l_31 || l_31) , 0xE5L), p_9)) > 0xDA19AE86A67606E8LL);
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_24
 * writes: g_23 g_24
 */
static uint8_t  func_16(uint64_t  p_17, uint32_t  p_18, uint32_t  p_19)
{ /* block id: 4 */
    int16_t l_22[8] = {0x07A3L,0x07A3L,0x4A04L,0x07A3L,0x07A3L,0x4A04L,0x07A3L,0x07A3L};
    int32_t l_25[9] = {(-1L),0x11FB8EB5L,(-1L),(-1L),0x11FB8EB5L,(-1L),(-1L),0x11FB8EB5L,(-1L)};
    int i;
    g_23 |= (safe_mul_func_uint16_t_u_u((p_17 | l_22[0]), (-10L)));
    g_24 = ((8L ^ l_22[6]) , 0L);
    l_25[1] = 6L;
    l_25[7] = p_17;
    return g_24;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 5, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 21
XXX times a non-volatile is write: 8
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 8
XXX percentage of non-volatile access: 90.6

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 13

XXX percentage a fresh-made variable is used: 35.3
XXX percentage an existing variable is used: 64.7
********************* end of statistics **********************/

