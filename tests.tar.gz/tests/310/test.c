/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4475032042561428855
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_9[4][8][3] = {{{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL}},{{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL}},{{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL}},{{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL},{0x6DD8D13034D00693LL,0x6DD8D13034D00693LL,0x6DD8D13034D00693LL},{8UL,0x1BCA9D6923607A98LL,8UL}}};
static uint8_t g_16 = 0x1CL;
static volatile int64_t g_21[10][3] = {{(-2L),0x2A907865E1BFEDAALL,0x2A907865E1BFEDAALL},{1L,1L,1L},{(-2L),(-2L),0x2A907865E1BFEDAALL},{(-3L),1L,(-3L)},{(-2L),0x2A907865E1BFEDAALL,0x2A907865E1BFEDAALL},{1L,1L,1L},{(-2L),(-2L),0x2A907865E1BFEDAALL},{(-3L),1L,(-3L)},{(-2L),0x2A907865E1BFEDAALL,0x2A907865E1BFEDAALL},{1L,1L,1L}};
static int32_t g_22 = 8L;
static int8_t g_40 = 6L;
static volatile uint32_t g_41 = 0UL;/* VOLATILE GLOBAL g_41 */
static int16_t g_51 = 0x4BBCL;
static uint32_t g_57 = 0x8449123DL;
static int16_t g_65 = 0x0ACBL;
static uint64_t g_100 = 0x8DF9F9BE492C6236LL;
static int16_t g_102[7][9][4] = {{{(-1L),(-1L),0x8455L,0x2A7AL},{0x7C4EL,(-10L),1L,0x8455L},{0x8455L,(-10L),1L,0x2A7AL},{(-10L),(-1L),(-10L),1L},{1L,1L,0x6C8BL,0x7C4EL},{0xC093L,1L,1L,1L},{0x2A7AL,0xDF8DL,1L,9L},{0xC093L,0x6C8BL,0x6C8BL,0xC093L},{1L,0x2A7AL,(-10L),(-2L)}},{{(-10L),(-2L),1L,0xDF8DL},{0x8455L,(-2L),1L,0xDF8DL},{0x7C4EL,(-2L),0x8455L,(-2L)},{(-1L),0x2A7AL,(-1L),0xC093L},{1L,0x6C8BL,0x7C4EL,9L},{(-2L),0xDF8DL,9L,1L},{(-2L),1L,0x7C4EL,0x7C4EL},{1L,1L,(-1L),1L},{(-1L),(-1L),0x8455L,0x2A7AL}},{{0x7C4EL,(-10L),1L,0x8455L},{0x8455L,(-10L),1L,0x2A7AL},{(-10L),(-1L),(-10L),1L},{1L,1L,0x6C8BL,0x7C4EL},{0xC093L,1L,1L,1L},{0x2A7AL,0xDF8DL,1L,9L},{0xC093L,0x6C8BL,0x6C8BL,0xC093L},{1L,0x2A7AL,(-10L),(-2L)},{(-10L),(-2L),1L,0xDF8DL}},{{0x8455L,(-2L),1L,(-2L)},{(-10L),1L,0x2A7AL,1L},{1L,0xC093L,0xDF8DL,(-1L)},{0x8455L,1L,(-10L),0x7C4EL},{(-2L),(-2L),0x7C4EL,0x8455L},{(-2L),0x6C8BL,(-10L),(-10L)},{0x8455L,0x8455L,0xDF8DL,1L},{1L,0xDF8DL,0x2A7AL,0xC093L},{(-10L),(-6L),9L,0x2A7AL}},{{0x2A7AL,(-6L),0x8455L,0xC093L},{(-6L),0xDF8DL,(-6L),1L},{0x6C8BL,0x8455L,1L,(-10L)},{(-1L),0x6C8BL,1L,0x8455L},{0xC093L,(-2L),1L,0x7C4EL},{(-1L),1L,1L,(-1L)},{0x6C8BL,0xC093L,(-6L),1L},{(-6L),1L,0x8455L,(-2L)},{0x2A7AL,(-2L),9L,(-2L)}},{{(-10L),1L,0x2A7AL,1L},{1L,0xC093L,0xDF8DL,(-1L)},{0x8455L,1L,(-10L),0x7C4EL},{(-2L),(-2L),0x7C4EL,0x8455L},{(-2L),0x6C8BL,(-10L),(-10L)},{0x8455L,0x8455L,0xDF8DL,1L},{1L,0xDF8DL,0x2A7AL,0xC093L},{(-10L),(-6L),9L,0x2A7AL},{0x2A7AL,(-6L),0x8455L,0xC093L}},{{(-6L),0xDF8DL,(-6L),1L},{0x6C8BL,0x8455L,1L,(-10L)},{(-1L),0x6C8BL,1L,0x8455L},{0xC093L,(-2L),1L,0x7C4EL},{(-1L),1L,1L,(-1L)},{0x6C8BL,0xC093L,(-6L),1L},{(-6L),1L,0x8455L,(-2L)},{0x2A7AL,(-2L),9L,(-2L)},{(-10L),1L,0x2A7AL,1L}}};
static volatile int16_t g_106 = 0xE4F1L;/* VOLATILE GLOBAL g_106 */
static volatile int16_t g_107 = (-1L);/* VOLATILE GLOBAL g_107 */
static int16_t g_108[3] = {(-1L),(-1L),(-1L)};
static volatile uint64_t g_109 = 0xD964AFFB0DC27877LL;/* VOLATILE GLOBAL g_109 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static const uint64_t  func_4(int64_t  p_5, const uint8_t  p_6, int8_t  p_7, int32_t  p_8);
static int32_t  func_17(const uint16_t  p_18);
static int32_t  func_23(uint32_t  p_24, int32_t  p_25, const uint32_t  p_26, int8_t  p_27, int16_t  p_28);
static int32_t  func_31(uint64_t  p_32);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_16 g_22 g_21 g_41 g_51 g_57 g_65 g_40 g_109 g_100 g_108
 * writes: g_16 g_21 g_22 g_41 g_51 g_57 g_65 g_100 g_102 g_109
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    const uint16_t l_10[5][6] = {{7UL,0UL,0xF989L,65535UL,65535UL,0xF989L},{7UL,7UL,65535UL,1UL,0xCC38L,1UL},{0UL,7UL,0UL,0xF989L,65535UL,65535UL},{0x0086L,0UL,0UL,0x0086L,7UL,1UL},{1UL,0x0086L,65535UL,0x0086L,1UL,0xF989L}};
    int16_t l_98 = 0x2897L;
    int32_t l_105 = 0xF9CC6DD0L;
    uint16_t l_114 = 65535UL;
    int i, j;
    if ((safe_div_func_int64_t_s_s((((((func_4(g_9[0][3][2], l_10[2][3], g_9[2][4][2], g_9[0][3][1]) , 1L) , g_9[0][3][2]) <= g_9[2][6][0]) && g_22) , g_21[7][2]), (-1L))))
    { /* block id: 67 */
        int32_t l_67 = 0xCF6402D6L;
        return l_67;
    }
    else
    { /* block id: 69 */
        int8_t l_68 = 0xA7L;
        int32_t l_82 = 0xBBA47006L;
        uint16_t l_83 = 1UL;
        for (g_16 = 0; (g_16 <= 2); g_16 += 1)
        { /* block id: 72 */
            const int16_t l_71 = 0xD012L;
            l_68 = g_9[0][3][2];
            g_22 = ((((((safe_div_func_int8_t_s_s(g_41, g_51)) & l_68) != 0x8EB8L) | l_71) == g_65) && l_68);
            return g_16;
        }
lbl_93:
        l_83 = (safe_sub_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(((safe_div_func_uint8_t_u_u((((safe_mod_func_int8_t_s_s(l_82, l_68)) < l_10[2][5]) && g_65), g_9[0][3][2])) <= g_16), l_68)), l_10[4][1])), l_82));
        for (g_51 = 6; (g_51 <= (-4)); --g_51)
        { /* block id: 80 */
            int16_t l_86 = 0x4679L;
            if (l_10[1][4])
                break;
            g_22 |= l_86;
            g_22 = (safe_mod_func_int16_t_s_s(((safe_mod_func_uint64_t_u_u(0UL, g_9[0][3][2])) == g_57), g_65));
            g_22 = (safe_mul_func_int8_t_s_s((0x6A876A48L && g_21[5][1]), g_40));
        }
        if (g_16)
            goto lbl_93;
    }
    for (g_22 = 0; (g_22 < (-25)); --g_22)
    { /* block id: 90 */
        uint32_t l_101 = 1UL;
        int32_t l_104[4][9][2] = {{{(-5L),(-9L)},{6L,0x65DCB784L},{(-2L),(-2L)},{0x65DCB784L,6L},{(-9L),(-5L)},{1L,(-2L)},{0x75D9B7F1L,1L},{6L,0xA941DAE9L},{0x65DCB784L,0xA941DAE9L}},{{0xABA0674BL,0x2A9BCAD3L},{0xA941DAE9L,(-1L)},{0xDCA8204FL,0x65DCB784L},{0x147E15CBL,0x2A9BCAD3L},{0x2A9BCAD3L,0x147E15CBL},{0x65DCB784L,0xDCA8204FL},{(-1L),0xA941DAE9L},{0x2A9BCAD3L,0xABA0674BL},{0xA941DAE9L,0x65DCB784L}},{{0x23E4D7B1L,0x65DCB784L},{0xA941DAE9L,0xABA0674BL},{0x2A9BCAD3L,0xA941DAE9L},{(-1L),0xDCA8204FL},{0x65DCB784L,0x147E15CBL},{0x2A9BCAD3L,0x2A9BCAD3L},{0x147E15CBL,0x65DCB784L},{0xDCA8204FL,(-1L)},{0xA941DAE9L,0x2A9BCAD3L}},{{0xABA0674BL,0xA941DAE9L},{0x65DCB784L,0x23E4D7B1L},{0x65DCB784L,0xA941DAE9L},{0xABA0674BL,0x2A9BCAD3L},{0xA941DAE9L,(-1L)},{0xDCA8204FL,0x65DCB784L},{0x147E15CBL,0x2A9BCAD3L},{0x2A9BCAD3L,0x147E15CBL},{0x65DCB784L,0xDCA8204FL}}};
        int i, j, k;
        for (g_16 = 19; (g_16 <= 42); g_16++)
        { /* block id: 93 */
            uint8_t l_99 = 1UL;
            int32_t l_103 = (-10L);
            g_100 = ((((l_98 == g_9[0][3][2]) , g_21[0][1]) != 0x47B2A2353B378580LL) < l_99);
            g_102[4][8][3] = ((l_99 > g_9[2][1][1]) , l_101);
            l_103 = (-5L);
        }
        ++g_109;
        if ((safe_mul_func_int8_t_s_s(1L, l_101)))
        { /* block id: 99 */
            if (g_100)
                break;
        }
        else
        { /* block id: 101 */
            return g_108[0];
        }
    }
    l_114 |= ((0xB2ABL & l_98) ^ l_10[0][1]);
    return l_114;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_16 g_22 g_21 g_41 g_51 g_57 g_65 g_40
 * writes: g_16 g_21 g_22 g_41 g_51 g_57 g_65
 */
static const uint64_t  func_4(int64_t  p_5, const uint8_t  p_6, int8_t  p_7, int32_t  p_8)
{ /* block id: 1 */
    int64_t l_13 = 1L;
    int32_t l_14 = 1L;
    l_14 = (safe_sub_func_uint64_t_u_u(g_9[0][3][2], l_13));
    if (p_5)
    { /* block id: 3 */
        uint16_t l_15 = 0UL;
        int32_t l_66 = 0x489D4C80L;
        g_16 ^= (l_15 < g_9[0][3][2]);
        g_65 &= func_17(((((g_16 > 2L) & p_7) , g_9[1][4][2]) , p_5));
        l_66 ^= p_7;
    }
    else
    { /* block id: 63 */
        l_14 = (p_5 >= 0x1BL);
    }
    return g_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_22 g_21 g_9 g_41 g_51 g_57
 * writes: g_16 g_21 g_22 g_41 g_51 g_57
 */
static int32_t  func_17(const uint16_t  p_18)
{ /* block id: 5 */
    const uint8_t l_34 = 0x97L;
    uint64_t l_64 = 1UL;
    for (g_16 = (-28); (g_16 == 38); g_16++)
    { /* block id: 8 */
        g_21[9][2] = 0x74BDBAF9L;
        for (g_22 = 0; (g_22 <= 2); g_22 += 1)
        { /* block id: 12 */
            int i, j;
            g_57 = (func_23(((((safe_div_func_int32_t_s_s(func_31(g_21[g_22][g_22]), g_9[0][3][2])) ^ l_34) < 18446744073709551611UL) , 18446744073709551614UL), p_18, g_16, g_16, p_18) ^ g_9[0][3][2]);
            return g_21[(g_22 + 3)][g_22];
        }
        for (g_57 = 24; (g_57 < 33); g_57++)
        { /* block id: 51 */
            uint32_t l_60 = 0x0ED5C0EBL;
            if (l_60)
                break;
        }
        for (g_22 = (-14); (g_22 != 24); ++g_22)
        { /* block id: 56 */
            uint16_t l_63 = 1UL;
            return l_63;
        }
    }
    return l_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_9 g_21 g_51
 * writes: g_41 g_51
 */
static int32_t  func_23(uint32_t  p_24, int32_t  p_25, const uint32_t  p_26, int8_t  p_27, int16_t  p_28)
{ /* block id: 15 */
    int64_t l_39 = (-3L);
    uint32_t l_56 = 0x4AA2EEDFL;
lbl_55:
    for (p_25 = 0; (p_25 >= 4); p_25 = safe_add_func_uint8_t_u_u(p_25, 9))
    { /* block id: 18 */
        uint64_t l_44 = 0UL;
        int32_t l_50 = 1L;
        for (p_24 = (-28); (p_24 <= 20); ++p_24)
        { /* block id: 21 */
            ++g_41;
            if (l_44)
                break;
        }
        if (g_9[1][6][2])
            break;
        for (l_39 = (-6); (l_39 >= 18); ++l_39)
        { /* block id: 28 */
            uint32_t l_47 = 0x0AF47DFBL;
            l_47 = (((l_44 || p_24) , 1L) & 65530UL);
            l_50 |= (safe_sub_func_uint8_t_u_u(l_39, g_9[0][3][2]));
            g_51 |= g_21[4][0];
            if (l_47)
                break;
        }
    }
    for (l_39 = 0; (l_39 != 16); l_39 = safe_add_func_uint16_t_u_u(l_39, 4))
    { /* block id: 37 */
        for (p_28 = 0; (p_28 <= 2); p_28 += 1)
        { /* block id: 40 */
            uint8_t l_54 = 0x60L;
            l_54 |= (-5L);
            if (p_25)
                goto lbl_55;
        }
    }
    return l_56;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_31(uint64_t  p_32)
{ /* block id: 13 */
    int16_t l_33[1][6][9] = {{{(-1L),0x6C1CL,0x6C1CL,(-1L),0xC245L,4L,0xC245L,(-1L),0x6C1CL},{0x448AL,0x448AL,(-9L),0xE629L,(-10L),0xE629L,(-9L),0x448AL,0x448AL},{0x6C1CL,(-1L),0xC245L,4L,0xC245L,(-1L),0x6C1CL,0x6C1CL,(-1L)},{0xE629L,3L,(-9L),3L,0xE629L,(-9L),(-9L),0xE629L,3L},{0x6C1CL,0xC245L,0x6C1CL,0xDA91L,(-10L),(-10L),0xDA91L,0x6C1CL,0xC245L},{0x448AL,0x3D43L,(-9L),(-9L),(-9L),(-9L),0x3D43L,0x448AL,0x3D43L}}};
    int i, j, k;
    return l_33[0][1][6];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_9[i][j][k], "g_9[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_21[i][j], "g_21[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_51, "g_51", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_102[i][j][k], "g_102[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_106, "g_106", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_108[i], "g_108[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_109, "g_109", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 43
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 51
   depth: 2, occurrence: 18
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 86
XXX times a non-volatile is write: 33
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 46
XXX percentage of non-volatile access: 92.2

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 57
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 20
   depth: 2, occurrence: 24

XXX percentage a fresh-made variable is used: 38.1
XXX percentage an existing variable is used: 61.9
********************* end of statistics **********************/

