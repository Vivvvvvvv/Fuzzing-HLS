/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7057062308850809129
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 1L;
static int8_t g_3 = 0L;
static volatile uint32_t g_4 = 0UL;/* VOLATILE GLOBAL g_4 */
static int64_t g_28 = 0x9229A275FF444262LL;
static volatile int8_t g_35 = 0L;/* VOLATILE GLOBAL g_35 */
static volatile uint8_t g_36 = 255UL;/* VOLATILE GLOBAL g_36 */
static int64_t g_56 = 0xC1F9C852071694A9LL;
static int32_t g_61 = 0x267A5E2BL;
static int8_t g_62 = 0x4AL;
static volatile int32_t g_63 = (-1L);/* VOLATILE GLOBAL g_63 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint8_t  func_8(uint64_t  p_9, int64_t  p_10, uint16_t  p_11, uint64_t  p_12, uint8_t  p_13);
static uint8_t  func_17(int32_t  p_18);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_2 g_3 g_36 g_35 g_28
 * writes: g_4 g_2 g_36
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_14[8] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};
    int8_t l_49 = 0xD5L;
    int32_t l_50 = 0xCC907F7AL;
    int32_t l_51 = 0x898A8014L;
    int32_t l_52 = 4L;
    int32_t l_53 = (-1L);
    int32_t l_54 = 1L;
    int32_t l_55 = (-1L);
    int32_t l_57 = 0x53A6575EL;
    int32_t l_58 = 0xD56B862BL;
    int32_t l_59 = 1L;
    int32_t l_60[9] = {(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L),(-3L)};
    uint32_t l_64[7] = {0UL,4294967293UL,4294967293UL,0UL,4294967293UL,4294967293UL,0UL};
    int i;
    ++g_4;
    l_49 |= (!func_8(l_14[2], g_4, l_14[2], g_2, l_14[2]));
    --l_64[2];
    l_51 = (safe_div_func_int8_t_s_s(((safe_mod_func_int64_t_s_s((safe_add_func_uint64_t_u_u((safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(l_14[2], 13)), l_51)), 0UL)), 1UL)) == g_28), l_60[6]));
    return l_14[2];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_36 g_35 g_28 g_4
 * writes: g_2 g_36
 */
static uint8_t  func_8(uint64_t  p_9, int64_t  p_10, uint16_t  p_11, uint64_t  p_12, uint8_t  p_13)
{ /* block id: 2 */
    int32_t l_39 = (-1L);
    uint32_t l_40[10];
    int i;
    for (i = 0; i < 10; i++)
        l_40[i] = 0xC7A88FF7L;
    l_39 = (safe_add_func_uint8_t_u_u(func_17(g_3), 0xC2L));
    for (p_10 = 9; (p_10 >= 3); p_10 -= 1)
    { /* block id: 11 */
        int i;
        if (l_40[p_10])
            break;
        if (l_40[p_10])
            break;
    }
    l_39 = (safe_rshift_func_int8_t_s_s(((((((g_35 >= g_3) >= l_40[1]) <= g_28) == 0x9EF5L) & 0x4FL) == 0xDE72L), 7));
    g_2 = ((safe_mod_func_uint64_t_u_u(((safe_add_func_uint64_t_u_u((((((safe_mod_func_uint8_t_u_u((g_4 >= g_3), g_3)) < 0x76L) , l_39) ^ 0L) & g_2), 0xCA44BAB92A1DD6B9LL)) , p_10), g_28)) , l_40[5]);
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_36
 * writes: g_2 g_36
 */
static uint8_t  func_17(int32_t  p_18)
{ /* block id: 3 */
    int16_t l_21 = 8L;
    int32_t l_22 = 0L;
    int32_t l_23 = (-10L);
    int32_t l_24 = 0xF2D6273DL;
    int32_t l_25 = (-1L);
    int32_t l_26 = (-5L);
    int32_t l_27 = 0x37D7C869L;
    int32_t l_29 = 0L;
    int32_t l_30 = 0x243E5EC3L;
    int32_t l_31 = 0x1FAFBF26L;
    int32_t l_32 = 0x698DC509L;
    int32_t l_33 = 0x702E6337L;
    int32_t l_34[3];
    int i;
    for (i = 0; i < 3; i++)
        l_34[i] = 0xFE44FA3FL;
    l_21 ^= (((safe_sub_func_int32_t_s_s(((0UL & p_18) || 9L), 0UL)) == p_18) , p_18);
    g_2 &= ((l_21 , l_21) && p_18);
    ++g_36;
    return p_18;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    transparent_crc(g_62, "g_62", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 37
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 18
   depth: 2, occurrence: 1
   depth: 3, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 31
XXX times a non-volatile is write: 9
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 17
XXX percentage of non-volatile access: 88.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 48.7
XXX percentage an existing variable is used: 51.3
********************* end of statistics **********************/

