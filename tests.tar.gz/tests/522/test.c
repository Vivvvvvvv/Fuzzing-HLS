/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13405270804969457181
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2 = 255UL;
static uint32_t g_32[1][3][8] = {{{3UL,0x065F4B3FL,0x41791E6EL,0x41791E6EL,0x065F4B3FL,3UL,0x065F4B3FL,0x41791E6EL},{0x42C512DCL,0x065F4B3FL,0x42C512DCL,3UL,3UL,0x42C512DCL,0x065F4B3FL,0x42C512DCL},{18446744073709551613UL,3UL,0x41791E6EL,3UL,18446744073709551613UL,18446744073709551613UL,3UL,0x41791E6EL}}};
static volatile int8_t g_36 = (-9L);/* VOLATILE GLOBAL g_36 */
static volatile uint64_t g_40 = 4UL;/* VOLATILE GLOBAL g_40 */
static uint32_t g_43 = 4UL;
static int32_t g_48 = (-4L);
static uint32_t g_49 = 1UL;
static volatile int8_t g_62[5][5][4] = {{{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L}},{{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L}},{{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L}},{{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L}},{{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L},{0x85L,0x85L,0x85L,0x85L}}};
static uint32_t g_67[6] = {0x8A5A2D53L,0x8A5A2D53L,0x8A5A2D53L,0x8A5A2D53L,0x8A5A2D53L,0x8A5A2D53L};
static uint64_t g_71 = 0UL;
static int32_t g_74 = 1L;
static uint32_t g_79 = 0x18D198D8L;
static uint32_t g_82 = 4294967295UL;
static int32_t g_87 = 0xD67D06F9L;
static uint32_t g_89 = 4294967295UL;
static uint8_t g_109[9][10] = {{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL},{5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL}};
static uint64_t g_116 = 0xDD4D5FF68F1F7CC5LL;
static uint64_t g_127 = 0UL;
static int8_t g_129 = (-9L);
static volatile int32_t g_130 = 9L;/* VOLATILE GLOBAL g_130 */
static volatile int8_t g_131 = 0xCEL;/* VOLATILE GLOBAL g_131 */
static uint64_t g_138[8][7][4] = {{{1UL,1UL,0UL,0xC82FA94D6089050ELL},{1UL,1UL,1UL,1UL},{18446744073709551615UL,0UL,1UL,0xE5EC640611769B01LL},{18446744073709551615UL,1UL,1UL,0xD330705DEFB49F98LL},{1UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xD330705DEFB49F98LL},{0xE5EC640611769B01LL,1UL,0xC0AAE426BEBBADE5LL,0xC82FA94D6089050ELL},{18446744073709551615UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xD330705DEFB49F98LL},{0xE5EC640611769B01LL,1UL,0xC0AAE426BEBBADE5LL,0xC82FA94D6089050ELL},{18446744073709551615UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xD330705DEFB49F98LL},{0xE5EC640611769B01LL,1UL,0xC0AAE426BEBBADE5LL,0xC82FA94D6089050ELL},{18446744073709551615UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xD330705DEFB49F98LL},{0xE5EC640611769B01LL,1UL,0xC0AAE426BEBBADE5LL,0xC82FA94D6089050ELL},{18446744073709551615UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xD330705DEFB49F98LL},{0xE5EC640611769B01LL,1UL,0xC0AAE426BEBBADE5LL,0xC82FA94D6089050ELL},{18446744073709551615UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xD330705DEFB49F98LL},{0xE5EC640611769B01LL,1UL,0xC0AAE426BEBBADE5LL,0xC82FA94D6089050ELL},{18446744073709551615UL,0UL,1UL,0xC82FA94D6089050ELL},{0x9B2BB32BA0D44C9CLL,1UL,1UL,0xD330705DEFB49F98LL},{0xD330705DEFB49F98LL,1UL,1UL,18446744073709551615UL}},{{0x9B2BB32BA0D44C9CLL,0xC0AAE426BEBBADE5LL,1UL,1UL},{18446744073709551615UL,0xC0AAE426BEBBADE5LL,0xC0AAE426BEBBADE5LL,18446744073709551615UL},{0xE5EC640611769B01LL,1UL,1UL,0xC82FA94D6089050ELL},{0xD330705DEFB49F98LL,0UL,0UL,1UL},{0xE5EC640611769B01LL,1UL,1UL,1UL},{1UL,0UL,1UL,0xC82FA94D6089050ELL},{0xC82FA94D6089050ELL,0xC0AAE426BEBBADE5LL,1UL,0xE5EC640611769B01LL}}};
static int32_t g_175[2][7][8] = {{{4L,0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL},{0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL,4L},{0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL},{4L,0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL},{0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL,4L},{0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL},{4L,0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL}},{{0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL,4L},{0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL},{4L,0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL},{0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL,4L},{0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL,0xC6F77066L,0x258E059BL,0x258E059BL},{4L,0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL},{0x258E059BL,4L,4L,0x258E059BL,4L,4L,0x258E059BL,4L}}};
static int32_t g_178 = (-5L);
static uint32_t g_180 = 4294967293UL;
static int32_t g_186 = 0L;
static int32_t g_187[2] = {0xCE4AA4CFL,0xCE4AA4CFL};
static uint8_t g_190 = 0x44L;
static uint16_t g_207[4][3][1] = {{{0x1316L},{0xAABBL},{0x1316L}},{{0xAABBL},{0x1316L},{0xAABBL}},{{0x1316L},{0xAABBL},{0x1316L}},{{0xAABBL},{0x1316L},{0xAABBL}}};
static int64_t g_210[3][8][5] = {{{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL}},{{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL}},{{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL},{0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL,0x3C90181276FF5385LL},{0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL,3L,0x0BAEE0F3894C1F6BLL}}};
static volatile uint8_t g_221 = 1UL;/* VOLATILE GLOBAL g_221 */
static int64_t g_232 = 0x6E1E9FAB29295381LL;
static int32_t g_240[4][2][7] = {{{0xF164A4B1L,0x3B5C7476L,0x70A1B23EL,0x91B169CCL,0x82D4F081L,0x007DB234L,0xF164A4B1L},{0x4B797742L,0x3B5C7476L,0L,(-2L),0x82D4F081L,0x0040767FL,0x4B797742L}},{{0x4B797742L,0x007DB234L,0x70A1B23EL,(-2L),0x70A1B23EL,0x007DB234L,0x4B797742L},{0xF164A4B1L,0x3B5C7476L,0x70A1B23EL,0x91B169CCL,0x82D4F081L,0x007DB234L,0xF164A4B1L}},{{0x4B797742L,0x3B5C7476L,0L,(-2L),0x82D4F081L,0x0040767FL,0x4B797742L},{0x4B797742L,0x007DB234L,0x70A1B23EL,(-2L),0x70A1B23EL,0x007DB234L,0x4B797742L}},{{0xF164A4B1L,0x3B5C7476L,0x70A1B23EL,0x91B169CCL,0x82D4F081L,0x007DB234L,0xF164A4B1L},{0x4B797742L,0x3B5C7476L,0L,(-2L),0x82D4F081L,0x0040767FL,0x4B797742L}}};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int16_t  func_5(int8_t  p_6, int64_t  p_7, uint64_t  p_8, int64_t  p_9, int32_t  p_10);
static int64_t  func_11(const uint8_t  p_12, int64_t  p_13, int8_t  p_14);
static const uint16_t  func_23(uint64_t  p_24, const uint64_t  p_25, uint32_t  p_26, int64_t  p_27);
static const uint16_t  func_52(uint32_t  p_53, uint32_t  p_54, const uint64_t  p_55, int16_t  p_56, int32_t  p_57);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_40 g_43 g_48 g_49 g_67 g_74 g_79 g_82 g_32 g_62 g_109 g_116 g_71 g_129 g_138 g_130 g_89 g_180 g_178 g_187 g_190 g_175 g_87 g_127 g_131 g_207 g_36 g_221 g_240
 * writes: g_2 g_40 g_43 g_48 g_49 g_67 g_71 g_74 g_79 g_82 g_87 g_89 g_109 g_116 g_127 g_129 g_138 g_180 g_186 g_187 g_190 g_207 g_210 g_221 g_232 g_240
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    const int32_t l_15 = 0L;
    int16_t l_16 = (-8L);
    int64_t l_193 = 0L;
    g_2--;
    g_240[2][0][4] = ((func_5((func_11(l_15, l_15, l_16) <= l_193), l_15, g_2, g_175[0][6][6], l_193) && l_16) == l_15);
    return g_138[6][4][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_87 g_127 g_187 g_32 g_49 g_131 g_178 g_207 g_138 g_2 g_36 g_221 g_129 g_67 g_89 g_190 g_240
 * writes: g_87 g_127 g_207 g_210 g_221 g_232 g_129 g_240 g_89 g_190
 */
static int16_t  func_5(int8_t  p_6, int64_t  p_7, uint64_t  p_8, int64_t  p_9, int32_t  p_10)
{ /* block id: 119 */
    int32_t l_206 = (-1L);
    int32_t l_218 = 0L;
    int32_t l_242 = 0x5A87531FL;
    int32_t l_243 = 0x247419DDL;
    int32_t l_244[10][4][4] = {{{0x89655006L,0xE396D189L,0xE396D189L,0x89655006L},{0x6FC31715L,0xE705DC70L,1L,3L},{1L,(-8L),0L,0xEC117ADEL},{0x1AE0B1E6L,0x340815C8L,1L,0xEC117ADEL}},{{(-4L),(-8L),9L,3L},{0L,0xE705DC70L,0xEB3BFC87L,0x89655006L},{(-1L),0xE396D189L,3L,0L},{(-4L),0x89655006L,(-4L),9L}},{{(-8L),0x5CAF21F3L,0L,(-1L)},{0x5CAF21F3L,0xE396D189L,0x340815C8L,0x5CAF21F3L},{0x6FC31715L,0L,0x340815C8L,3L},{0x5CAF21F3L,0xEC117ADEL,0L,(-8L)}},{{(-8L),0x340815C8L,(-4L),0x1AE0B1E6L},{(-4L),0x1AE0B1E6L,3L,3L},{(-1L),(-1L),0xEB3BFC87L,1L},{0L,0xE396D189L,9L,(-4L)}},{{0xF378282FL,0xE396D189L,0xC5EEC6CAL,(-1L)},{0xCB046F15L,0xE396D189L,0xE705DC70L,(-4L)},{0xE396D189L,1L,0xEB3BFC87L,0xE396D189L},{0x06BCCA87L,1L,1L,0x953DAA23L}},{{1L,0xCB046F15L,0xE705DC70L,0xCB046F15L},{3L,0L,0x06BCCA87L,9L},{0xF378282FL,3L,0xBF744FCCL,0x953DAA23L},{(-4L),0x6FC31715L,0L,0x340815C8L}},{{(-4L),1L,0xBF744FCCL,1L},{0xF378282FL,0x340815C8L,0x06BCCA87L,(-1L)},{3L,1L,0xE705DC70L,0x6FC31715L},{1L,1L,1L,1L}},{{0x06BCCA87L,(-4L),0xEB3BFC87L,0x953DAA23L},{0xE396D189L,9L,0xE705DC70L,3L},{0xCB046F15L,0L,0xC5EEC6CAL,3L},{0xF378282FL,9L,(-1L),0x953DAA23L}},{{0x6FC31715L,(-4L),0L,1L},{1L,1L,0x953DAA23L,0x6FC31715L},{0xF378282FL,1L,0xF378282FL,(-1L)},{9L,0x340815C8L,0xE705DC70L,1L}},{{0x340815C8L,1L,0L,0x340815C8L},{0x06BCCA87L,0x6FC31715L,0L,0x953DAA23L},{0x340815C8L,3L,0xE705DC70L,9L},{9L,0L,0xF378282FL,0xCB046F15L}}};
    uint8_t l_247 = 255UL;
    uint64_t l_255 = 18446744073709551612UL;
    uint8_t l_258[1];
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_258[i] = 0xF9L;
    for (g_87 = 0; (g_87 < 27); ++g_87)
    { /* block id: 122 */
        int16_t l_204 = 0xB905L;
        for (g_127 = 0; (g_127 <= 0); g_127 += 1)
        { /* block id: 125 */
            uint32_t l_205[2][1];
            int i, j;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                    l_205[i][j] = 0x480CB713L;
            }
            l_206 = (safe_lshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s((safe_rshift_func_int16_t_s_u(((safe_mod_func_int8_t_s_s((((g_187[(g_127 + 1)] < 1L) , p_7) != g_32[0][0][7]), l_204)) > l_205[0][0]), l_204)), g_49)), 0));
            g_207[2][0][0] = ((g_131 & 0xF8L) && 0x4094C64F2D8B73B3LL);
        }
        for (l_206 = 11; (l_206 != 9); --l_206)
        { /* block id: 131 */
            uint8_t l_211[4][5][10] = {{{0x29L,0x63L,255UL,0UL,0x30L,0UL,0UL,0x8AL,247UL,248UL},{0x74L,0x59L,255UL,0UL,1UL,0x9DL,0xADL,0x85L,0UL,1UL},{0xF5L,1UL,0xBBL,0x0BL,254UL,0x9DL,0xB4L,255UL,0x8EL,0x8FL},{0x74L,6UL,0x8AL,247UL,0xC6L,0UL,1UL,0x0AL,0x8EL,0x4FL},{0x29L,0UL,255UL,0x0BL,0x74L,0x74L,0x0BL,255UL,0UL,0x29L}},{{0x8DL,0UL,0xF3L,0UL,0x8FL,0x4FL,1UL,253UL,247UL,0x30L},{0x30L,6UL,0x5EL,0UL,0x8FL,248UL,0xB4L,0x8AL,247UL,0x29L},{0x8FL,1UL,0x5FL,0x63L,0x74L,0x8FL,0xADL,0x8AL,0x0BL,0x4FL},{0UL,0x59L,0x5EL,0xB8L,0xC6L,254UL,0UL,253UL,6UL,0x8FL},{0UL,0x63L,0xF3L,0xADL,6UL,0xB8L,0xDAL,0x5EL,6UL,247UL}},{{0xB8L,0xDAL,0x5EL,6UL,247UL,1UL,6UL,255UL,6UL,1UL},{0x63L,0x9BL,248UL,0x9BL,0x63L,0x8EL,6UL,0xE4L,0x21L,247UL},{0UL,0xDAL,0xD2L,1UL,1UL,0x0BL,0xDAL,0xA5L,255UL,247UL},{0UL,1UL,0xE4L,4UL,0x63L,0xADL,254UL,0x21L,0xDAL,1UL},{0x0BL,0x83L,0xE4L,254UL,247UL,0x59L,6UL,0xA5L,4UL,247UL}},{{247UL,0x88L,0xD2L,0x21L,6UL,0x59L,0x6FL,0xE4L,3UL,0xB8L},{0x0BL,6UL,248UL,0xDAL,0xB4L,0xADL,0x88L,255UL,3UL,0x8EL},{0UL,4UL,0x5EL,0x21L,0x0BL,0x0BL,0x21L,0x5EL,4UL,0UL},{0UL,4UL,0x05L,254UL,0xB8L,0x8EL,0x88L,246UL,0xDAL,0x63L},{0x63L,6UL,0UL,4UL,0xB8L,1UL,0x6FL,248UL,255UL,0UL}}};
            int i, j, k;
            g_210[2][7][2] = (p_8 < l_204);
            return l_211[1][0][4];
        }
    }
    if ((~((safe_add_func_int8_t_s_s(((safe_rshift_func_int8_t_s_u(g_178, 2)) >= g_207[1][0][0]), 9L)) , 4294967293UL)))
    { /* block id: 136 */
        int64_t l_217 = 0x0D56FBECB08BCFCFLL;
        if ((l_217 , p_6))
        { /* block id: 137 */
            return l_206;
        }
        else
        { /* block id: 139 */
            l_218 &= p_8;
            p_10 = (+p_9);
        }
        if (g_138[6][4][0])
        { /* block id: 143 */
            return g_207[2][1][0];
        }
        else
        { /* block id: 145 */
            return g_2;
        }
    }
    else
    { /* block id: 148 */
        if (g_87)
        { /* block id: 149 */
lbl_224:
            l_218 = ((+g_36) ^ 0x88L);
        }
        else
        { /* block id: 151 */
            uint16_t l_225 = 0xD36BL;
            ++g_221;
            if (g_87)
                goto lbl_224;
            --l_225;
        }
        g_232 = (safe_add_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(0UL, p_7)), l_206));
        for (g_129 = 25; (g_129 >= 12); --g_129)
        { /* block id: 159 */
            g_240[2][0][4] = (safe_mod_func_uint16_t_u_u((!(safe_rshift_func_uint16_t_u_u(g_187[1], 5))), p_6));
            if (l_218)
                break;
            if (p_7)
                break;
            if (g_67[5])
                continue;
        }
    }
    for (g_89 = 0; (g_89 <= 1); g_89 += 1)
    { /* block id: 168 */
        int64_t l_241 = 0x4B694AD86DD0FD29LL;
        int32_t l_245 = (-10L);
        int32_t l_246[10] = {0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL,0xFB8DCC1FL};
        int i;
        ++l_247;
        for (g_190 = 0; (g_190 <= 1); g_190 += 1)
        { /* block id: 172 */
            int32_t l_254 = (-1L);
            g_240[1][1][2] ^= (safe_mod_func_int32_t_s_s(((safe_lshift_func_int8_t_s_s((-1L), p_7)) != l_243), p_7));
            if (g_127)
                continue;
            l_254 |= ((p_9 < g_190) == g_178);
            p_10 &= g_32[0][2][1];
        }
    }
    l_255--;
    return l_258[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_40 g_43 g_48 g_49 g_67 g_74 g_79 g_82 g_32 g_62 g_109 g_116 g_71 g_129 g_138 g_130 g_89 g_180 g_178 g_187 g_190
 * writes: g_40 g_43 g_48 g_49 g_67 g_71 g_74 g_79 g_82 g_87 g_89 g_109 g_116 g_127 g_129 g_138 g_180 g_186 g_187 g_190
 */
static int64_t  func_11(const uint8_t  p_12, int64_t  p_13, int8_t  p_14)
{ /* block id: 2 */
    int32_t l_31 = (-8L);
    int32_t l_37 = 1L;
    int32_t l_150 = 7L;
    int32_t l_176[3][9][7] = {{{0x6F17F63BL,3L,(-7L),0x5AF58961L,0x5AF58961L,(-7L),3L},{7L,5L,0x454C0729L,0xC66AC990L,0L,(-3L),4L},{0x6F17F63BL,(-1L),(-7L),1L,0x5AF58961L,(-1L),3L},{0xC55FCEFCL,5L,1L,0xC66AC990L,0L,(-3L),0x4E45EC49L},{0x6F17F63BL,3L,(-7L),0x5AF58961L,0x5AF58961L,(-7L),3L},{7L,5L,0x454C0729L,0xC66AC990L,0L,(-3L),4L},{0x6F17F63BL,(-1L),(-7L),1L,0x5AF58961L,(-1L),3L},{0xC55FCEFCL,5L,1L,0xC66AC990L,0L,(-3L),0x4E45EC49L},{0x6F17F63BL,3L,(-7L),0x5AF58961L,0x5AF58961L,(-7L),3L}},{{7L,5L,0x454C0729L,0xC66AC990L,0L,(-3L),4L},{0x6F17F63BL,(-1L),(-7L),1L,0x6F17F63BL,0x5AF58961L,3L},{0xD12019ACL,0xEC2223EDL,0L,(-1L),0xC55FCEFCL,0xC66AC990L,0L},{6L,3L,1L,0x6F17F63BL,0x6F17F63BL,1L,3L},{0x84EFA1E0L,0xEC2223EDL,0L,(-1L),7L,0xC66AC990L,3L},{6L,0x1DD72E9DL,1L,(-1L),0x6F17F63BL,0x5AF58961L,3L},{0xD12019ACL,0xEC2223EDL,0L,(-1L),0xC55FCEFCL,0xC66AC990L,0L},{6L,3L,1L,0x6F17F63BL,0x6F17F63BL,1L,3L},{0x84EFA1E0L,0xEC2223EDL,0L,(-1L),7L,0xC66AC990L,3L}},{{6L,0x1DD72E9DL,1L,(-1L),0x6F17F63BL,0x5AF58961L,3L},{0xD12019ACL,0xEC2223EDL,0L,(-1L),0xC55FCEFCL,0xC66AC990L,0L},{6L,3L,1L,0x6F17F63BL,0x6F17F63BL,1L,3L},{0x84EFA1E0L,0xEC2223EDL,0L,(-1L),7L,0xC66AC990L,3L},{6L,0x1DD72E9DL,1L,(-1L),0x6F17F63BL,0x5AF58961L,3L},{0xD12019ACL,0xEC2223EDL,0L,(-1L),0xC55FCEFCL,0xC66AC990L,0L},{6L,3L,1L,0x6F17F63BL,0x6F17F63BL,1L,3L},{0x84EFA1E0L,0xEC2223EDL,0L,(-1L),7L,0xC66AC990L,3L},{6L,0x1DD72E9DL,1L,(-1L),0x6F17F63BL,0x5AF58961L,3L}}};
    int32_t l_189 = (-1L);
    int i, j, k;
    if (((safe_add_func_int32_t_s_s(((safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_u(func_23(g_2, p_13, p_14, g_2), 12)), g_2)) || l_31), 9UL)) == 0x29478C9DFFBE5849LL))
    { /* block id: 6 */
        return p_12;
    }
    else
    { /* block id: 8 */
        int32_t l_33 = (-2L);
        int32_t l_88 = (-1L);
        for (p_13 = 0; (p_13 <= 0); p_13 += 1)
        { /* block id: 11 */
            int32_t l_34 = (-7L);
            int32_t l_35 = (-1L);
            int32_t l_38 = 0x47AA2967L;
            int32_t l_39 = 0x0A644184L;
            g_40--;
            g_43 = (1UL | p_12);
            return p_13;
        }
        for (l_31 = 0; (l_31 >= 0); l_31 -= 1)
        { /* block id: 18 */
            l_37 = ((safe_div_func_int32_t_s_s((l_33 >= l_33), 0xE26A25A9L)) == p_14);
            g_48 ^= ((safe_mod_func_int64_t_s_s(g_43, 0x81FDF20BE86DE1F1LL)) >= 0x64F8L);
            ++g_49;
        }
        g_74 = (func_52((g_40 ^ l_31), p_12, l_33, p_13, p_12) <= p_14);
        if ((safe_mul_func_uint8_t_u_u((((safe_sub_func_uint8_t_u_u(g_67[5], p_14)) != g_74) < l_37), 0x2BL)))
        { /* block id: 42 */
            g_79++;
        }
        else
        { /* block id: 44 */
            int64_t l_93 = (-6L);
            ++g_82;
            g_87 = (((safe_lshift_func_int8_t_s_u((g_32[0][2][3] == p_13), 1)) , 0UL) , 0x032BE65AL);
            g_89 = l_88;
            l_37 = ((safe_mul_func_int16_t_s_s(((safe_unary_minus_func_int8_t_s(((l_93 | 1UL) | g_82))) < l_93), g_67[5])) >= l_93);
        }
    }
    if ((safe_rshift_func_int8_t_s_u(g_74, g_79)))
    { /* block id: 51 */
        uint16_t l_100 = 65535UL;
        if ((safe_sub_func_int16_t_s_s(((safe_add_func_int16_t_s_s((l_100 || g_74), p_13)) , (-6L)), g_79)))
        { /* block id: 52 */
            const uint8_t l_105 = 255UL;
            int32_t l_106 = 2L;
            l_106 &= (~((+(safe_rshift_func_uint16_t_u_s((g_62[0][2][1] == 0UL), l_105))) | 0UL));
        }
        else
        { /* block id: 54 */
            g_109[2][8] ^= ((safe_lshift_func_int16_t_s_u((-3L), 14)) >= 65535UL);
        }
        l_31 = (((((!((safe_add_func_int8_t_s_s(0xF1L, g_109[2][8])) | g_2)) , g_43) != g_62[4][4][2]) < 2L) | g_67[5]);
    }
    else
    { /* block id: 58 */
        uint32_t l_121 = 0x525E98B5L;
        int32_t l_128 = (-7L);
        uint8_t l_132 = 1UL;
        if (g_79)
        { /* block id: 59 */
            l_31 = (-1L);
        }
        else
        { /* block id: 61 */
            int64_t l_113 = 6L;
            int8_t l_114 = 1L;
            int32_t l_115[4] = {0xE483D774L,0xE483D774L,0xE483D774L,0xE483D774L};
            int i;
            l_37 ^= (g_48 & 0L);
            --g_116;
            l_121 = ((safe_div_func_uint16_t_u_u(g_67[5], g_71)) <= g_48);
        }
        for (l_31 = 2; (l_31 == 24); ++l_31)
        { /* block id: 68 */
            uint16_t l_124 = 0xF48DL;
            ++l_124;
            g_127 = l_124;
            if (l_121)
                continue;
            --l_132;
        }
        l_128 ^= (l_37 != p_13);
    }
    for (g_116 = 0; (g_116 <= 8); g_116 += 1)
    { /* block id: 78 */
        uint8_t l_135 = 0x0BL;
        int32_t l_136[7][7][5] = {{{(-6L),0L,3L,0L,8L},{1L,1L,0xEC2F7F93L,(-4L),1L},{8L,0L,(-4L),0xA2FD1301L,9L},{0x25E376B2L,8L,3L,6L,0xA732090DL},{0L,(-6L),9L,4L,1L},{0x948F0CD0L,0x0F86E789L,0x37489931L,1L,(-1L)},{0xD55268D4L,0xA3F67225L,0xC28541D7L,1L,6L}},{{1L,0x25E376B2L,0L,4L,8L},{0x78B5E36AL,4L,1L,6L,0xAF6BE207L},{0xA3F67225L,0L,1L,0xA2FD1301L,0xA2FD1301L},{0x88910D5BL,0xD55268D4L,0x88910D5BL,(-4L),0L},{(-1L),0x0F86E789L,9L,0L,0xAF6BE207L},{0x25E376B2L,0L,0xBB834B12L,1L,0xA3F67225L},{0x37489931L,0xA3F67225L,9L,0xAF6BE207L,0x04F267A0L}},{{(-6L),0L,0x742A4258L,0L,(-1L)},{0L,(-4L),0xA2FD1301L,9L,1L},{1L,0L,0xC28541D7L,2L,0x37489931L},{4L,0xE2B1DE1DL,(-3L),(-1L),2L},{(-4L),0L,8L,0x88910D5BL,0xEC2F7F93L},{0x742A4258L,0L,1L,0xF10FDB64L,0xA5162D90L},{0L,0xE2B1DE1DL,2L,0xEC2F7F93L,2L}},{{0x88910D5BL,0L,(-1L),0L,0xD849AB60L},{1L,(-4L),0xC0CCAC75L,0xC0CCAC75L,(-4L)},{0xD849AB60L,(-3L),4L,(-1L),2L},{4L,0xD849AB60L,(-1L),9L,0x6BD4EB13L},{0x5CE33710L,0x88910D5BL,0xBB834B12L,(-1L),0xEC2F7F93L},{4L,3L,0xE2B1DE1DL,1L,(-1L)},{0xD849AB60L,0xA5162D90L,8L,0xEC2F7F93L,1L}},{{1L,4L,0x742A4258L,(-1L),0xA5162D90L},{0x88910D5BL,1L,0xC0CCAC75L,0xBB3B6D22L,0xF10FDB64L},{0L,0L,0xA2FD1301L,0x6BD4EB13L,(-1L)},{0x742A4258L,0xD849AB60L,0L,0xC0CCAC75L,(-1L)},{(-4L),3L,0x0896F4A5L,0L,0xF10FDB64L},{4L,0L,0x979BA1A3L,(-4L),0xA5162D90L},{1L,0L,0xBB834B12L,0xF10FDB64L,1L}},{{0L,(-3L),(-3L),0L,(-1L)},{0L,1L,0xA2FD1301L,0xBB3B6D22L,0xEC2F7F93L},{1L,4L,4L,2L,0x6BD4EB13L},{0L,0xE2B1DE1DL,0L,0xBB3B6D22L,2L},{0xEC2F7F93L,0x88910D5BL,8L,0L,(-4L)},{0x742A4258L,0L,(-1L),0xF10FDB64L,0xD849AB60L},{0xD849AB60L,0xE2B1DE1DL,0x0896F4A5L,(-4L),2L}},{{0L,0xAF6BE207L,(-1L),0L,0xA5162D90L},{1L,0xEC2F7F93L,0xC28541D7L,0xC0CCAC75L,0xEC2F7F93L},{0xA5162D90L,(-3L),0xC28541D7L,0x6BD4EB13L,2L},{0xAF6BE207L,0xA5162D90L,(-1L),0xBB3B6D22L,0x37489931L},{0x5CE33710L,0L,0x0896F4A5L,(-1L),1L},{0L,3L,(-1L),0xEC2F7F93L,(-1L)},{0L,0L,8L,1L,4L}}};
        int i, j, k;
        l_135 = (1UL > p_14);
        for (g_129 = 5; (g_129 >= 0); g_129 -= 1)
        { /* block id: 82 */
            int32_t l_137 = 0x4C1B6DC2L;
            g_138[6][4][0]++;
            l_31 = 1L;
        }
    }
    if (g_116)
    { /* block id: 87 */
        int32_t l_149 = 0x6080F64FL;
        for (g_71 = 0; (g_71 <= 0); g_71 += 1)
        { /* block id: 90 */
            l_31 = (safe_mul_func_int16_t_s_s((safe_mul_func_int16_t_s_s((g_67[5] > p_14), g_67[5])), 4UL));
            l_31 = (safe_sub_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_u(((g_48 & 0xAF6D0226L) == g_130), g_79)) > p_12) != l_149), g_67[5]));
        }
        l_149 = l_150;
        if ((1L < 0x76DD06A0L))
        { /* block id: 95 */
            int32_t l_151 = 0xE3CBC813L;
            l_149 = l_149;
            l_31 = ((l_151 , g_129) & 0x6FA71761L);
            l_151 = ((p_14 < 0xF4DAL) & p_14);
        }
        else
        { /* block id: 99 */
            uint32_t l_152[6] = {4294967295UL,1UL,4294967295UL,4294967295UL,1UL,4294967295UL};
            int i;
            ++l_152[4];
        }
    }
    else
    { /* block id: 102 */
        int8_t l_157 = 0x2DL;
        int32_t l_170 = 1L;
        int32_t l_173 = 0L;
        int32_t l_177 = (-1L);
        int32_t l_179 = 0x66C474ECL;
        l_37 = ((((safe_sub_func_uint8_t_u_u((g_82 >= p_12), l_157)) < p_14) | l_150) || g_116);
        l_170 = ((safe_div_func_int32_t_s_s((safe_add_func_int8_t_s_s(((safe_div_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((safe_lshift_func_uint8_t_u_s(g_49, 0)), g_89)), 0xC6L)) == 0UL), 0x3CL)), 4294967295UL)) , p_12);
        for (l_31 = 26; (l_31 == 12); l_31--)
        { /* block id: 107 */
            int8_t l_174 = 1L;
            g_180++;
        }
        for (l_170 = (-4); (l_170 != 3); l_170++)
        { /* block id: 112 */
            int8_t l_188 = 4L;
            g_186 = ((((~9UL) < g_116) >= g_178) , p_14);
            g_187[1] &= (p_14 != 1L);
            g_190--;
        }
    }
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static const uint16_t  func_23(uint64_t  p_24, const uint64_t  p_25, uint32_t  p_26, int64_t  p_27)
{ /* block id: 3 */
    uint64_t l_28[4];
    int i;
    for (i = 0; i < 4; i++)
        l_28[i] = 0x0176DF7E44142B91LL;
    ++l_28[1];
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_48 g_40 g_67 g_49
 * writes: g_67 g_71
 */
static const uint16_t  func_52(uint32_t  p_53, uint32_t  p_54, const uint64_t  p_55, int16_t  p_56, int32_t  p_57)
{ /* block id: 23 */
    uint64_t l_60 = 18446744073709551615UL;
    int32_t l_63[4][10] = {{(-1L),(-1L),(-9L),(-9L),(-1L),(-1L),(-1L),(-9L),(-9L),(-1L)},{(-1L),(-1L),(-1L),(-1L),0x01F9D99DL,1L,0x01F9D99DL,(-1L),(-1L),0x01F9D99DL},{1L,0x01F9D99DL,(-1L),(-1L),0x01F9D99DL,1L,0x01F9D99DL,(-1L),(-1L),0x01F9D99DL},{1L,0x01F9D99DL,(-1L),(-1L),0x01F9D99DL,1L,0x01F9D99DL,(-1L),(-1L),0x01F9D99DL}};
    uint32_t l_72[4][5];
    int i, j;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
            l_72[i][j] = 6UL;
    }
    for (p_57 = 0; (p_57 <= 0); p_57 += 1)
    { /* block id: 26 */
        int8_t l_61[3][9] = {{(-1L),0x39L,0L,0L,0x39L,(-1L),0x39L,0L,0L},{0x6AL,0x6AL,1L,0xBDL,1L,0x6AL,0x6AL,1L,0xBDL},{1L,0x39L,1L,(-1L),(-1L),1L,0x39L,1L,(-1L)}};
        int i, j;
        if (((((safe_sub_func_uint32_t_u_u(((((l_60 , g_48) > g_48) | l_60) <= g_40), 0xC508211AL)) < l_60) | p_56) == l_61[0][3]))
        { /* block id: 27 */
            uint32_t l_64 = 6UL;
            int32_t l_68[1][1][8] = {{{9L,1L,9L,1L,9L,1L,9L,1L}}};
            int i, j, k;
            if (l_60)
                break;
            --l_64;
            g_67[5] &= l_63[3][1];
            l_68[0][0][1] |= (g_67[5] != 0x140B3566L);
        }
        else
        { /* block id: 32 */
            int64_t l_73 = 0x8BA66F8A59D77607LL;
            g_71 = (((((safe_mod_func_int16_t_s_s(g_49, l_61[0][3])) | p_54) & (-7L)) | 0UL) | p_56);
            if (l_72[0][1])
                continue;
            if (g_49)
                break;
            if (l_73)
                break;
        }
        return g_49;
    }
    return l_72[1][3];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_32[i][j][k], "g_32[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    transparent_crc(g_48, "g_48", print_hash_value);
    transparent_crc(g_49, "g_49", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_62[i][j][k], "g_62[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_67[i], "g_67[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_109[i][j], "g_109[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_138[i][j][k], "g_138[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_175[i][j][k], "g_175[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_178, "g_178", print_hash_value);
    transparent_crc(g_180, "g_180", print_hash_value);
    transparent_crc(g_186, "g_186", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_187[i], "g_187[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_190, "g_190", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_207[i][j][k], "g_207[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_210[i][j][k], "g_210[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_221, "g_221", print_hash_value);
    transparent_crc(g_232, "g_232", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_240[i][j][k], "g_240[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 95
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 114
   depth: 2, occurrence: 26
   depth: 3, occurrence: 9
   depth: 4, occurrence: 5
   depth: 5, occurrence: 4
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 164
XXX times a non-volatile is write: 73
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 125
XXX percentage of non-volatile access: 96.3

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 109
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 30
   depth: 2, occurrence: 62

XXX percentage a fresh-made variable is used: 32.1
XXX percentage an existing variable is used: 67.9
********************* end of statistics **********************/

