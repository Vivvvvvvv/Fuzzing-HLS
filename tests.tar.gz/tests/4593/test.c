/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      17781990154424992044
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x73838A1FL;
static volatile uint8_t g_5 = 0UL;/* VOLATILE GLOBAL g_5 */
static int64_t g_13 = 5L;
static int8_t g_27[3] = {0xDBL,0xDBL,0xDBL};
static uint32_t g_33 = 0xF30385D0L;
static uint32_t g_69 = 0x64312F30L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_14(int32_t  p_15, int32_t  p_16, int16_t  p_17, int16_t  p_18, uint32_t  p_19);
static uint16_t  func_24(uint8_t  p_25, int16_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3 g_13 g_27 g_33 g_69
 * writes: g_5 g_3 g_13 g_33 g_69
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0L;
    int32_t l_4[7] = {0L,0L,0L,0L,0L,0L,0L};
    uint32_t l_12 = 0xDC41FD9DL;
    uint8_t l_78[7] = {0x8CL,0x8CL,0x8CL,0x8CL,0x8CL,0x8CL,0x8CL};
    const uint8_t l_90 = 1UL;
    int i;
    g_5--;
    for (l_2 = 0; (l_2 <= 10); ++l_2)
    { /* block id: 4 */
        int16_t l_10[6] = {0xDB5CL,(-5L),(-5L),0xDB5CL,(-5L),(-5L)};
        int32_t l_77 = 0x3529C6F6L;
        int i;
        g_3 = l_10[1];
        if (((l_4[2] || l_10[4]) & 4UL))
        { /* block id: 6 */
            g_13 ^= ((!(l_10[4] && l_12)) == g_3);
        }
        else
        { /* block id: 8 */
            uint32_t l_58 = 0x90942075L;
            int32_t l_76[8] = {0L,(-1L),(-1L),0L,(-1L),(-1L),0L,(-1L)};
            int i;
            l_76[4] = func_14(((safe_rshift_func_uint8_t_u_u(((safe_mul_func_uint16_t_u_u(func_24(g_3, g_5), l_58)) ^ g_27[2]), 3)) , g_13), l_10[5], l_58, l_10[1], l_4[5]);
            if (l_10[1])
                continue;
            l_77 |= ((0xA8D4E4AFL >= g_69) == l_12);
        }
        if (l_10[3])
            break;
        if ((((0x5CL == l_78[1]) , 0x56BCC6B8L) == g_33))
        { /* block id: 52 */
            int8_t l_84 = (-1L);
            int32_t l_91 = 7L;
            l_84 = (safe_sub_func_uint8_t_u_u((!((safe_mul_func_uint16_t_u_u((g_5 & g_3), l_4[5])) >= 0x6978B3CFL)), l_4[1]));
            if (g_5)
                continue;
            l_77 &= 8L;
            l_91 = ((safe_lshift_func_uint16_t_u_s((safe_lshift_func_uint8_t_u_u((safe_unary_minus_func_uint32_t_u(((((-9L) | 1L) <= g_69) != l_77))), l_90)), l_10[3])) || 65532UL);
        }
        else
        { /* block id: 57 */
            uint16_t l_94 = 65534UL;
            g_3 = (safe_mul_func_uint8_t_u_u(((g_27[0] , l_94) >= 18446744073709551613UL), l_77));
            l_77 = ((safe_lshift_func_int16_t_s_s(((3UL || 0x2706CD285881B6A4LL) <= l_94), 12)) > g_33);
        }
    }
    g_3 = (safe_lshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u((((safe_mul_func_int16_t_s_s(((safe_mod_func_int64_t_s_s((safe_mul_func_uint16_t_u_u(((safe_mul_func_int16_t_s_s(l_4[2], g_13)) >= g_69), l_78[4])), 18446744073709551606UL)) | 0x76L), 0x230CL)) | 0x5401L) , 2UL), l_4[2])), 3));
    return g_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_5 g_3 g_69
 * writes: g_3 g_69
 */
static int32_t  func_14(int32_t  p_15, int32_t  p_16, int16_t  p_17, int16_t  p_18, uint32_t  p_19)
{ /* block id: 35 */
    uint32_t l_59 = 0xA0F96394L;
    int32_t l_62[4];
    int64_t l_67 = 2L;
    int32_t l_75 = 0x74211FA8L;
    int i;
    for (i = 0; i < 4; i++)
        l_62[i] = 0xCB45490AL;
    p_15 = p_15;
    if ((l_59 | l_59))
    { /* block id: 37 */
lbl_70:
        l_62[2] = (((safe_rshift_func_uint16_t_u_u((0x1B53A2AD41D66485LL || 9L), 6)) != 0x6F2DB44E93343DEFLL) , g_27[0]);
        return p_19;
    }
    else
    { /* block id: 40 */
        uint32_t l_68[6];
        int i;
        for (i = 0; i < 6; i++)
            l_68[i] = 0x8ADB298FL;
        g_3 = (g_5 ^ 1UL);
        g_69 |= (((safe_mod_func_uint32_t_u_u((((((safe_div_func_int16_t_s_s((-1L), l_67)) | 0x7EE7A741179D740FLL) , p_18) || p_17) & g_5), l_68[2])) ^ p_17) < g_3);
        if (p_18)
            goto lbl_70;
        p_15 = (((safe_rshift_func_int8_t_s_s(((safe_rshift_func_int8_t_s_s(p_18, 2)) ^ l_75), l_62[1])) & l_62[0]) | p_19);
    }
    return p_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_27 g_13 g_33
 * writes: g_3 g_33
 */
static uint16_t  func_24(uint8_t  p_25, int16_t  p_26)
{ /* block id: 9 */
    int32_t l_30 = (-1L);
    for (g_3 = 0; (g_3 <= 2); g_3 += 1)
    { /* block id: 12 */
        int i;
        l_30 |= (safe_add_func_uint16_t_u_u((g_27[g_3] | p_26), 65535UL));
        for (p_26 = 2; (p_26 >= 0); p_26 -= 1)
        { /* block id: 16 */
            if (p_26)
                break;
        }
    }
    if ((safe_mul_func_uint8_t_u_u(((p_26 == g_13) || l_30), p_26)))
    { /* block id: 20 */
        uint16_t l_44 = 0UL;
        int32_t l_53 = 7L;
        int32_t l_56[5] = {0x624E194EL,0x624E194EL,0x624E194EL,0x624E194EL,0x624E194EL};
        int i;
        --g_33;
        l_44 = (((((((safe_div_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u((((safe_add_func_uint64_t_u_u(0x79DEB4763523E24BLL, g_3)) && 0UL) ^ p_26), 0)), g_33)) != p_26) , 65535UL) >= p_26) || 1L) > 5L) ^ l_30);
        l_53 = (safe_add_func_int64_t_s_s(((((safe_div_func_uint32_t_u_u((safe_add_func_uint16_t_u_u(0x2097L, 0xBBC1L)), g_3)) , p_26) & g_13) && 0UL), 0x73E702B68169B2B2LL));
        for (p_26 = 0; (p_26 < (-17)); p_26 = safe_sub_func_int8_t_s_s(p_26, 8))
        { /* block id: 26 */
            g_3 = p_25;
            l_56[2] = p_26;
        }
    }
    else
    { /* block id: 30 */
        uint32_t l_57 = 0UL;
        return l_57;
    }
    g_3 = 0x0E5E2E4BL;
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_13, "g_13", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_27[i], "g_27[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 27
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 41
   depth: 2, occurrence: 6
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 79
XXX times a non-volatile is write: 26
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 38
XXX percentage of non-volatile access: 94.6

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 41
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 17
   depth: 2, occurrence: 13

XXX percentage a fresh-made variable is used: 25.2
XXX percentage an existing variable is used: 74.8
********************* end of statistics **********************/

