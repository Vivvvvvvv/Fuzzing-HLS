/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      10759339872108988676
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_15 = 0x7BL;
static volatile uint32_t g_57 = 1UL;/* VOLATILE GLOBAL g_57 */
static uint16_t g_60 = 65535UL;
static uint16_t g_69 = 0xAE9EL;
static uint16_t g_74 = 6UL;
static volatile int64_t g_82[5] = {0x84C52037B1C4CF87LL,0x84C52037B1C4CF87LL,0x84C52037B1C4CF87LL,0x84C52037B1C4CF87LL,0x84C52037B1C4CF87LL};
static int8_t g_84 = 9L;
static volatile int64_t g_86 = 0x85F22E389797D0E0LL;/* VOLATILE GLOBAL g_86 */
static volatile uint8_t g_87 = 255UL;/* VOLATILE GLOBAL g_87 */
static uint64_t g_94 = 18446744073709551615UL;
static int16_t g_113 = 0x5C07L;
static uint32_t g_118[8] = {0x33F92C7FL,0x33F92C7FL,0x33F92C7FL,0x33F92C7FL,0x33F92C7FL,0x33F92C7FL,0x33F92C7FL,0x33F92C7FL};
static int32_t g_130 = 0x1BA722A3L;
static int32_t g_148 = 8L;
static int16_t g_150 = 0x3A30L;
static int16_t g_151 = 0L;
static int32_t g_153 = 0xC3364891L;
static volatile int32_t g_157 = (-10L);/* VOLATILE GLOBAL g_157 */
static int64_t g_158[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int16_t g_160 = 0xB215L;
static volatile uint16_t g_161 = 65535UL;/* VOLATILE GLOBAL g_161 */


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint64_t  func_2(uint8_t  p_3, uint32_t  p_4, uint64_t  p_5);
static uint8_t  func_6(int8_t  p_7, uint64_t  p_8, int64_t  p_9, int32_t  p_10);
static int16_t  func_18(uint64_t  p_19, uint64_t  p_20, int16_t  p_21, const uint64_t  p_22);
static int64_t  func_38(int32_t  p_39, uint16_t  p_40, int32_t  p_41, uint16_t  p_42, const uint16_t  p_43);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_57 g_60 g_69 g_74 g_87 g_94 g_84 g_118 g_86 g_130 g_113 g_82 g_148 g_161 g_158 g_157 g_153
 * writes: g_57 g_60 g_69 g_74 g_87 g_94 g_113 g_118 g_130 g_148 g_161 g_153
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_14 = 1L;
    int32_t l_16 = 0L;
    int32_t l_147 = 0L;
    int16_t l_154 = 0xEDA0L;
    int32_t l_156 = (-10L);
    int32_t l_159 = 0xF2632C09L;
    uint32_t l_167[1][7][2] = {{{4UL,4UL},{0x620B5F74L,4UL},{4UL,0x620B5F74L},{4UL,4UL},{0x620B5F74L,4UL},{4UL,0x620B5F74L},{4UL,4UL}}};
    int i, j, k;
    if (((func_2(func_6((+(safe_lshift_func_uint16_t_u_s(0xC370L, 8))), l_14, g_15, l_16), l_16, l_16) != 3L) <= g_15))
    { /* block id: 90 */
        uint32_t l_146[3];
        int i;
        for (i = 0; i < 3; i++)
            l_146[i] = 0x3B544FA2L;
        for (g_74 = 5; (g_74 >= 52); ++g_74)
        { /* block id: 93 */
            l_146[0] = (((g_57 , g_74) && 0xB9L) || 65535UL);
            if (l_146[1])
                break;
            l_147 &= l_14;
        }
        return g_86;
    }
    else
    { /* block id: 99 */
        for (g_130 = 4; (g_130 >= 0); g_130 -= 1)
        { /* block id: 102 */
            volatile int32_t l_149 = (-1L);/* VOLATILE GLOBAL l_149 */
            int i;
            g_148 &= (0x8B7DADB20BFAB2E0LL || g_82[g_130]);
            l_149 = g_82[g_130];
        }
    }
    l_147 = g_148;
    for (g_148 = 4; (g_148 >= 0); g_148 -= 1)
    { /* block id: 110 */
        int32_t l_152 = 1L;
        int32_t l_155 = 0xE04F8DB9L;
        g_161++;
        for (g_69 = 0; (g_69 <= 7); g_69 += 1)
        { /* block id: 114 */
            uint8_t l_164[8] = {0x5AL,0UL,0x5AL,0x5AL,0UL,0x5AL,0x5AL,0UL};
            int i;
            return l_164[4];
        }
        for (l_159 = 1; (l_159 <= 7); l_159 += 1)
        { /* block id: 119 */
            int i;
            l_156 = (safe_mod_func_int32_t_s_s((0UL < g_158[(g_148 + 1)]), g_82[2]));
            g_153 ^= g_157;
        }
    }
    return l_167[0][2][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_74 g_57 g_87 g_84 g_118 g_86 g_130 g_69 g_113 g_15
 * writes: g_113 g_118 g_130
 */
static uint64_t  func_2(uint8_t  p_3, uint32_t  p_4, uint64_t  p_5)
{ /* block id: 65 */
    const int16_t l_105[1] = {0x4741L};
    int32_t l_122 = 0x8DAC292CL;
    uint8_t l_142 = 0x00L;
    uint8_t l_143 = 246UL;
    int i;
    if ((((((safe_mod_func_uint8_t_u_u((((safe_mod_func_int64_t_s_s(0L, p_5)) && 0xBD89D4EDL) || g_74), 255UL)) | l_105[0]) , 0L) , g_57) | 0xB7E8L))
    { /* block id: 66 */
        uint64_t l_108 = 0x1A7F23E4526E093ELL;
        int32_t l_109[1][3];
        uint64_t l_112 = 0x8353C78930F4DF5FLL;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 3; j++)
                l_109[i][j] = 0xD4602054L;
        }
        l_109[0][2] = ((((((((safe_div_func_int64_t_s_s(g_87, g_84)) , p_4) == 255UL) != p_3) >= p_5) || g_57) != 4UL) != l_108);
        if ((safe_add_func_int64_t_s_s((g_87 == 0L), l_112)))
        { /* block id: 68 */
            g_113 = (p_3 != g_84);
        }
        else
        { /* block id: 70 */
            int32_t l_121 = (-1L);
            l_109[0][2] = (safe_mod_func_int32_t_s_s((0xF83FL == 0x8EE9L), l_108));
            g_118[7] |= ((safe_sub_func_uint8_t_u_u((0xD9D29738L == 1L), (-1L))) || g_57);
            l_121 = ((safe_mod_func_uint32_t_u_u(0xCDFB547BL, p_5)) < p_5);
            l_122 = g_118[7];
        }
        l_109[0][2] = (safe_mod_func_int8_t_s_s(((p_5 || l_105[0]) ^ p_4), 1L));
        for (l_108 = 17; (l_108 != 30); l_108++)
        { /* block id: 79 */
            int8_t l_129 = (-4L);
            int32_t l_131[1][2];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_131[i][j] = 0x109A6A1CL;
            }
            g_130 &= ((((safe_div_func_uint8_t_u_u(g_118[7], (-5L))) || l_129) && 18446744073709551615UL) > g_86);
            l_131[0][1] = g_130;
            l_131[0][0] = (0x5F293FBDL == p_5);
        }
    }
    else
    { /* block id: 84 */
        g_130 = 0xFF5D3455L;
        l_143 = (safe_rshift_func_uint8_t_u_u(((safe_sub_func_int16_t_s_s((((safe_rshift_func_int16_t_s_u((safe_mod_func_uint8_t_u_u((safe_lshift_func_uint8_t_u_u((((((g_74 < l_142) ^ 1L) ^ l_105[0]) & g_87) != g_69), l_105[0])), p_4)), g_113)) ^ 0L) <= p_3), g_15)) || g_130), p_5));
    }
    l_122 = l_105[0];
    return l_105[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_57 g_60 g_69 g_74 g_87 g_94 g_84
 * writes: g_57 g_60 g_69 g_74 g_87 g_94
 */
static uint8_t  func_6(int8_t  p_7, uint64_t  p_8, int64_t  p_9, int32_t  p_10)
{ /* block id: 1 */
    uint32_t l_17 = 0xB4E76AB2L;
    l_17 = (g_15 == g_15);
    p_10 = (func_18(l_17, p_9, g_15, l_17) , p_8);
    return g_57;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_57 g_60 g_69 g_74 g_87 g_94 g_84
 * writes: g_57 g_60 g_69 g_74 g_87 g_94
 */
static int16_t  func_18(uint64_t  p_19, uint64_t  p_20, int16_t  p_21, const uint64_t  p_22)
{ /* block id: 3 */
    int8_t l_23 = 0x34L;
    int32_t l_65 = (-9L);
    int32_t l_71[4][10][6] = {{{0x21D6FFC8L,0xE19BE170L,0L,0xACAAAB22L,(-1L),0xE4F79C11L},{0x3B6D3E8DL,0x957098D2L,0L,0xF9076B3EL,0x9868D596L,0x816D4D43L},{(-2L),0xF8E48205L,(-10L),(-1L),1L,(-1L)},{(-1L),0x75EB9154L,1L,(-1L),0x347F8B30L,3L},{0L,1L,0x957098D2L,0xE4F79C11L,(-1L),0x62FBF910L},{0x84BB253DL,(-3L),0x7FB9BE98L,0x391BE15CL,0x391BE15CL,0x7FB9BE98L},{0xA1D57542L,0xA1D57542L,0xAD787CCBL,3L,0L,0L},{0L,(-5L),3L,0x529ADFF6L,0xACAAAB22L,0xAD787CCBL},{0x816D4D43L,0L,3L,0L,0xA1D57542L,0L},{0x3ABBA7F7L,0L,0xAD787CCBL,0x1765D423L,5L,0x7FB9BE98L}},{{0x1765D423L,5L,0x7FB9BE98L,0xF8E48205L,1L,0x62FBF910L},{0xD1C2D9EAL,0x889BFF34L,0x957098D2L,0x7FB9BE98L,0x0F2B0E74L,3L},{0x0F2B0E74L,0x74EA18A5L,1L,0x816D4D43L,0L,(-1L)},{0L,1L,(-10L),(-2L),0xE4F79C11L,0x816D4D43L},{0x0CE0BB6BL,0x9868D596L,0L,0x93412788L,0x529ADFF6L,0xE4F79C11L},{0L,0xD1F87359L,(-1L),0L,0x50D1B5CEL,1L},{0x74EA18A5L,0x93412788L,(-2L),5L,0x1D7193A8L,0x957098D2L},{0xE4F79C11L,0x50D1B5CEL,0x1765D423L,0L,0x1765D423L,0x50D1B5CEL},{0x582B275DL,(-1L),(-5L),1L,0L,1L},{0xE19BE170L,1L,0x3B6D3E8DL,4L,0L,0L}},{{5L,1L,(-1L),0x62FBF910L,0L,0L},{(-3L),(-1L),0x529ADFF6L,0x3B6D3E8DL,0x1765D423L,(-1L)},{0xAD787CCBL,0x50D1B5CEL,0xE19BE170L,0L,0x1D7193A8L,(-1L)},{0x9868D596L,0x93412788L,(-1L),1L,0x50D1B5CEL,0xD1F87359L},{(-5L),0xD1F87359L,1L,0x74EA18A5L,0x529ADFF6L,1L},{1L,0x9868D596L,(-3L),0xE19BE170L,0xE4F79C11L,0L},{0x75EB9154L,1L,0x347F8B30L,0L,0L,0x0F2B0E74L},{0L,0x74EA18A5L,1L,0xD1C2D9EAL,0x0F2B0E74L,0xF8E48205L},{1L,0x889BFF34L,0xA1D57542L,0L,1L,0xACAAAB22L},{0x6BCA32D9L,5L,0x758ACF15L,0x758ACF15L,5L,0x6BCA32D9L}},{{(-1L),0L,0xF9076B3EL,(-1L),0xA1D57542L,4L},{(-6L),0L,0x9868D596L,1L,0xACAAAB22L,0x74EA18A5L},{(-6L),(-5L),1L,0L,0x1D7193A8L,0L},{0x816D4D43L,0xF8E48205L,0L,3L,0xE4F79C11L,(-1L)},{0L,0L,0xD1F87359L,0x582B275DL,0xF9076B3EL,0L},{0xD1C2D9EAL,4L,0x8C86622CL,(-10L),0x529ADFF6L,0x347F8B30L},{(-1L),1L,0x75EB9154L,(-5L),0xAD787CCBL,5L},{1L,0L,3L,7L,0x93412788L,1L},{1L,0xA1D57542L,0x6BCA32D9L,0x3ABBA7F7L,0L,(-3L)},{(-1L),1L,0xE4F79C11L,1L,0L,(-1L)}}};
    int i, j, k;
    if ((0UL >= 65535UL))
    { /* block id: 4 */
        int64_t l_24 = 6L;
        int32_t l_25 = 0xE3CA3691L;
        l_24 = l_23;
        if (l_23)
            goto lbl_70;
        l_25 = (p_22 > l_23);
        l_25 &= (safe_rshift_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u(l_23, 4)), l_23));
        if ((safe_sub_func_int32_t_s_s(((1UL != l_23) > l_23), g_15)))
        { /* block id: 8 */
            g_60 ^= ((safe_sub_func_uint8_t_u_u(((safe_rshift_func_uint8_t_u_u((safe_sub_func_int64_t_s_s((((func_38((safe_mod_func_int8_t_s_s((((safe_lshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u(0x9AB8L, p_19)), 3)) | g_15) > l_25), l_23)), g_15, p_22, g_15, g_15) >= p_20) , g_15) != 0x21B0A093F7740323LL), p_22)), 3)) >= g_15), l_23)) ^ g_15);
        }
        else
        { /* block id: 26 */
            uint32_t l_61 = 0x76CD8568L;
            int8_t l_64 = 0x00L;
            int32_t l_66 = 0x11E6AC9CL;
            --l_61;
            l_65 = l_64;
            l_66 = ((l_24 , 18446744073709551612UL) & p_22);
        }
    }
    else
    { /* block id: 31 */
        g_69 ^= (safe_rshift_func_int8_t_s_s(g_15, 2));
    }
lbl_70:
    l_65 ^= ((((-3L) < 1L) < g_60) || p_19);
    for (g_69 = 0; (g_69 <= 3); g_69 += 1)
    { /* block id: 38 */
        int16_t l_72 = 0xDF46L;
        int32_t l_73 = 0x289E4144L;
        --g_74;
        l_65 ^= g_60;
        if ((((safe_div_func_uint32_t_u_u((safe_div_func_int64_t_s_s((safe_unary_minus_func_uint32_t_u(0xE2BE98DEL)), g_69)), l_73)) >= p_21) > p_22))
        { /* block id: 41 */
            int64_t l_83 = (-3L);
            int32_t l_85[1];
            int i;
            for (i = 0; i < 1; i++)
                l_85[i] = (-1L);
            --g_87;
            if (p_19)
                continue;
        }
        else
        { /* block id: 44 */
            l_73 ^= (safe_sub_func_uint16_t_u_u((+(((~l_65) || 0UL) != g_69)), g_69));
            g_94 &= g_74;
        }
        for (p_20 = 0; (p_20 <= 3); p_20 += 1)
        { /* block id: 50 */
            uint16_t l_95 = 0UL;
            ++l_95;
        }
        for (p_21 = 3; (p_21 >= 0); p_21 -= 1)
        { /* block id: 55 */
            int64_t l_98 = 1L;
            int32_t l_100[2];
            int i;
            for (i = 0; i < 2; i++)
                l_100[i] = 0xC4584B38L;
            if (l_73)
                break;
            l_98 ^= 0x0DE8C290L;
            l_100[1] = (+p_22);
            l_100[1] = ((p_19 & p_19) <= g_84);
        }
    }
    return g_84;
}


/* ------------------------------------------ */
/* 
 * reads : g_57
 * writes: g_57
 */
static int64_t  func_38(int32_t  p_39, uint16_t  p_40, int32_t  p_41, uint16_t  p_42, const uint16_t  p_43)
{ /* block id: 9 */
    int8_t l_50[6] = {1L,1L,1L,1L,1L,1L};
    int32_t l_53 = 0x5AF849FBL;
    int32_t l_54 = 0x2E26A8ACL;
    int32_t l_56 = 0xAD9F1AA4L;
    int i;
    for (p_41 = 5; (p_41 >= 0); p_41 -= 1)
    { /* block id: 12 */
        int32_t l_55[8][8][3] = {{{0x86CD98C7L,(-5L),0x86CD98C7L},{(-1L),1L,2L},{0xCAD70698L,0xE0AEE481L,0L},{0L,1L,2L},{0L,(-5L),0xB2E0AD50L},{0L,0x0C201006L,0L},{0xCAD70698L,0L,0xB2E0AD50L},{(-1L),0xF7828E97L,2L}},{{0x86CD98C7L,0L,0L},{2L,0x0C201006L,2L},{0x86CD98C7L,(-5L),0x86CD98C7L},{(-1L),1L,2L},{0xCAD70698L,0xE0AEE481L,0L},{0L,1L,2L},{0L,(-5L),0xB2E0AD50L},{0L,0x0C201006L,0L}},{{0xCAD70698L,0L,0xB2E0AD50L},{(-1L),0xF7828E97L,2L},{0x86CD98C7L,0L,0L},{2L,0x0C201006L,2L},{0x86CD98C7L,(-5L),0x86CD98C7L},{(-1L),1L,2L},{0xCAD70698L,0xE0AEE481L,0L},{0L,1L,2L}},{{0L,(-5L),0xB2E0AD50L},{0L,0x0C201006L,0L},{0xCAD70698L,0L,0xB2E0AD50L},{(-1L),0xF7828E97L,2L},{0x86CD98C7L,0L,0L},{2L,0x0C201006L,2L},{0x86CD98C7L,(-5L),0x86CD98C7L},{(-1L),1L,2L}},{{0xCAD70698L,0xE0AEE481L,0L},{0L,1L,2L},{0L,(-5L),0xB2E0AD50L},{0L,0x0C201006L,0L},{0xCAD70698L,0L,0xB2E0AD50L},{(-1L),0xF7828E97L,2L},{0x86CD98C7L,0L,0L},{2L,0x0C201006L,2L}},{{0x86CD98C7L,(-5L),0x86CD98C7L},{(-1L),1L,2L},{0xCAD70698L,0xE0AEE481L,0L},{0L,1L,2L},{0L,(-5L),0xB2E0AD50L},{0L,0x0C201006L,0L},{0xCAD70698L,0x86CD98C7L,0xE767E792L},{0xEE8E20E6L,3L,0L}},{{0x0786CB52L,0x86CD98C7L,2L},{0L,2L,0x1EB61364L},{0x0786CB52L,0xCAD70698L,0x0786CB52L},{0xEE8E20E6L,0x43232AF7L,0x1EB61364L},{4L,0L,2L},{7L,0x43232AF7L,0L},{2L,0xCAD70698L,0xE767E792L},{7L,2L,7L}},{{4L,0x86CD98C7L,0xE767E792L},{0xEE8E20E6L,3L,0L},{0x0786CB52L,0x86CD98C7L,2L},{0L,2L,0x1EB61364L},{0x0786CB52L,0xCAD70698L,0x0786CB52L},{0xEE8E20E6L,0x43232AF7L,0x1EB61364L},{4L,0L,2L},{7L,0x43232AF7L,0L}}};
        int i, j, k;
        p_39 = (1UL >= l_50[p_41]);
        l_54 = (safe_mod_func_uint16_t_u_u((l_50[p_41] && l_53), p_39));
        for (l_53 = 0; (l_53 <= 5); l_53 += 1)
        { /* block id: 17 */
            int i;
            if (l_50[p_41])
                break;
            --g_57;
            p_39 ^= 0x680EDED6L;
        }
        return l_50[0];
    }
    return l_56;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_74, "g_74", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_82[i], "g_82[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_84, "g_84", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    transparent_crc(g_94, "g_94", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_118[i], "g_118[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_130, "g_130", print_hash_value);
    transparent_crc(g_148, "g_148", print_hash_value);
    transparent_crc(g_150, "g_150", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    transparent_crc(g_153, "g_153", print_hash_value);
    transparent_crc(g_157, "g_157", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_158[i], "g_158[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_160, "g_160", print_hash_value);
    transparent_crc(g_161, "g_161", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 62
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 79
   depth: 2, occurrence: 19
   depth: 3, occurrence: 8
   depth: 4, occurrence: 6
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 9, occurrence: 2
   depth: 11, occurrence: 1
   depth: 14, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 117
XXX times a non-volatile is write: 52
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 60
XXX percentage of non-volatile access: 90.4

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 75
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 27
   depth: 2, occurrence: 32

XXX percentage a fresh-made variable is used: 33.2
XXX percentage an existing variable is used: 66.8
********************* end of statistics **********************/

