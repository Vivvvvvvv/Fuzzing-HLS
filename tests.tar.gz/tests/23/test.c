/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      486863973979950278
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_10 = 0x9D19AC19L;
static volatile uint32_t g_14 = 0UL;/* VOLATILE GLOBAL g_14 */
static int32_t g_33 = 0xB7E280BFL;
static uint32_t g_64 = 0xFD232038L;
static volatile uint64_t g_79 = 0UL;/* VOLATILE GLOBAL g_79 */
static uint64_t g_106[10] = {0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL,0x8006A5961B9AEE73LL};
static uint32_t g_120 = 9UL;
static int32_t g_149 = 0x84595356L;
static volatile int32_t g_150 = 8L;/* VOLATILE GLOBAL g_150 */
static int64_t g_151 = (-2L);
static volatile uint16_t g_152[8][5] = {{8UL,8UL,0xDE48L,8UL,8UL},{0UL,65535UL,0UL,0UL,65535UL},{8UL,0xA9DDL,0xA9DDL,8UL,0xA9DDL},{65535UL,65535UL,0UL,65535UL,65535UL},{0xA9DDL,8UL,0xA9DDL,0xA9DDL,8UL},{65535UL,0UL,0UL,65535UL,0UL},{8UL,8UL,0xDE48L,8UL,8UL},{0UL,0UL,0UL,0UL,0UL}};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int8_t  func_4(int32_t  p_5, int64_t  p_6, int32_t  p_7, const int64_t  p_8);
static int32_t  func_19(uint16_t  p_20, uint64_t  p_21, uint8_t  p_22, int32_t  p_23, uint32_t  p_24);
static uint16_t  func_25(int8_t  p_26, uint16_t  p_27, int64_t  p_28, uint8_t  p_29);
static int32_t  func_43(uint8_t  p_44, uint8_t  p_45, int8_t  p_46, uint8_t  p_47);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_14 g_33 g_64 g_79 g_106 g_152 g_151 g_120 g_149 g_150
 * writes: g_14 g_10 g_64 g_79 g_106 g_120 g_152
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int8_t l_9 = (-1L);
    int32_t l_124 = 0xE36C3AAFL;
    int32_t l_156 = 0x630C7D5CL;
    int32_t l_157[8][5] = {{5L,(-1L),5L,0L,0xACB9E114L},{(-1L),(-8L),0xACB9E114L,(-8L),(-1L)},{5L,(-8L),(-1L),(-1L),(-1L)},{(-1L),(-1L),0xACB9E114L,(-1L),(-5L)},{(-8L),5L,5L,(-8L),(-1L)},{(-8L),(-1L),0L,0L,(-1L)},{(-1L),5L,0L,0xACB9E114L,0xACB9E114L},{5L,(-1L),5L,0L,0xACB9E114L}};
    uint64_t l_168[2];
    int i, j;
    for (i = 0; i < 2; i++)
        l_168[i] = 0x0F894422981FDBEELL;
    if (((safe_lshift_func_int8_t_s_u(func_4((l_9 , g_10), l_9, l_9, l_9), 3)) == l_9))
    { /* block id: 55 */
        uint64_t l_105 = 2UL;
        int32_t l_112 = 0x93068B84L;
        int32_t l_119 = 8L;
        const int32_t l_123 = 0x3BBE6313L;
        g_106[2] = (((((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(0xAE6CL, l_105)), g_10)) >= l_9) && 0x19E5EE4ADB81C666LL) || 0x6EF7D18C36E20A5FLL) ^ g_33);
        for (l_9 = 0; (l_9 == 3); ++l_9)
        { /* block id: 59 */
            uint16_t l_111 = 1UL;
            l_112 &= (((safe_add_func_int64_t_s_s(0xE11B1975C8F0ABFALL, 0x8E3606EC16123697LL)) , 2L) || l_111);
        }
        for (g_10 = 0; (g_10 >= (-14)); g_10 = safe_sub_func_int64_t_s_s(g_10, 1))
        { /* block id: 64 */
            g_120 = (safe_lshift_func_int8_t_s_s((safe_rshift_func_int8_t_s_s(l_9, l_119)), 1));
            if (g_79)
                break;
        }
        l_124 = (safe_mod_func_int16_t_s_s(g_33, l_123));
    }
    else
    { /* block id: 69 */
        int32_t l_133 = 1L;
        int32_t l_148[5];
        int i;
        for (i = 0; i < 5; i++)
            l_148[i] = 0x03CF1BE4L;
        if (((safe_sub_func_uint16_t_u_u((g_33 > g_106[8]), (-10L))) <= l_124))
        { /* block id: 70 */
            l_124 &= ((safe_mul_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(((safe_add_func_uint8_t_u_u(g_14, 0x61L)) , 0x26D5L), g_106[2])), g_106[2])) < 0xA9312FBDL);
            l_133 = 0xC1896B7AL;
            if (g_64)
                goto lbl_134;
            return l_133;
        }
        else
        { /* block id: 74 */
lbl_134:
            g_10 = 0x369CA922L;
            g_10 = g_33;
            l_124 &= g_10;
        }
        l_124 = 2L;
        if (((safe_lshift_func_int8_t_s_s(l_9, g_33)) , l_133))
        { /* block id: 81 */
            uint16_t l_139[4][1][8] = {{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}},{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}},{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}},{{0UL,0UL,0UL,0UL,0UL,0UL,0UL,0UL}}};
            int i, j, k;
            l_124 = ((safe_sub_func_uint16_t_u_u(g_14, l_139[0][0][4])) , l_9);
            return g_79;
        }
        else
        { /* block id: 84 */
            uint8_t l_142 = 0xD9L;
            int32_t l_144 = 0xE641B022L;
            g_10 |= 0x3715829BL;
            if (g_10)
                goto lbl_143;
lbl_143:
            g_10 &= (safe_mul_func_uint8_t_u_u((l_133 , 8UL), l_142));
            l_144 ^= l_124;
            l_124 = (safe_sub_func_int16_t_s_s((+0x1726L), g_10));
        }
        g_152[0][3]--;
    }
    if (g_151)
    { /* block id: 93 */
        return g_14;
    }
    else
    { /* block id: 95 */
        int16_t l_155 = (-1L);
        int32_t l_163 = 0L;
        if (((((((0x4BA4E592539712D8LL & l_155) ^ g_106[6]) || g_120) != g_33) | g_120) > l_156))
        { /* block id: 96 */
            uint64_t l_158 = 9UL;
            ++l_158;
            l_163 = ((safe_mod_func_uint16_t_u_u(0xA04BL, l_158)) >= 1UL);
            l_157[4][2] = ((safe_div_func_int8_t_s_s(g_64, 1L)) >= g_64);
        }
        else
        { /* block id: 100 */
            return g_120;
        }
        l_168[0] |= ((((safe_mul_func_uint16_t_u_u(((0x498B4FF7L || g_79) & 0x7E7EL), 0x9A1AL)) || 0x7FL) && l_157[0][1]) || 0x76208AC86F730CBFLL);
    }
    l_157[0][1] = (g_149 > 0x2AL);
    l_124 |= (safe_lshift_func_int8_t_s_s(g_106[7], 4));
    return g_150;
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_10 g_33 g_64 g_79
 * writes: g_14 g_10 g_64 g_79
 */
static int8_t  func_4(int32_t  p_5, int64_t  p_6, int32_t  p_7, const int64_t  p_8)
{ /* block id: 1 */
    int16_t l_11[5] = {0x4AD7L,0x4AD7L,0x4AD7L,0x4AD7L,0x4AD7L};
    int32_t l_12 = (-1L);
    int32_t l_13[9] = {0x4B64B5C6L,0L,0x4B64B5C6L,0L,0x4B64B5C6L,0L,0x4B64B5C6L,0L,0x4B64B5C6L};
    int64_t l_73[10][5] = {{0xA95A2E206C165AAELL,(-8L),(-2L),0x4E288A3D85AA7F79LL,0x4E288A3D85AA7F79LL},{(-8L),0xA95A2E206C165AAELL,(-8L),(-2L),0x4E288A3D85AA7F79LL},{0xE7F6F8F643D9D76CLL,(-9L),0x4E288A3D85AA7F79LL,(-9L),0xE7F6F8F643D9D76CLL},{(-8L),(-9L),0xA95A2E206C165AAELL,0xE7F6F8F643D9D76CLL,0xA95A2E206C165AAELL},{0xA95A2E206C165AAELL,0xA95A2E206C165AAELL,0x4E288A3D85AA7F79LL,0xE7F6F8F643D9D76CLL,0L},{(-9L),(-8L),(-8L),(-9L),0xA95A2E206C165AAELL},{(-9L),0xE7F6F8F643D9D76CLL,(-2L),(-2L),0xE7F6F8F643D9D76CLL},{0xA95A2E206C165AAELL,(-8L),(-2L),0x4E288A3D85AA7F79LL,0x4E288A3D85AA7F79LL},{(-8L),0xA95A2E206C165AAELL,(-8L),(-2L),0x4E288A3D85AA7F79LL},{0xE7F6F8F643D9D76CLL,(-9L),0x4E288A3D85AA7F79LL,(-9L),0xE7F6F8F643D9D76CLL}};
    int i, j;
    g_14++;
    for (l_12 = 0; (l_12 != (-25)); l_12 = safe_sub_func_int8_t_s_s(l_12, 5))
    { /* block id: 5 */
        uint16_t l_36[9][2] = {{0x11B5L,65535UL},{0UL,0xD2FCL},{65535UL,0xD2FCL},{0UL,65535UL},{0x11B5L,0x11B5L},{0x11B5L,65535UL},{0UL,0xD2FCL},{65535UL,0xD2FCL},{0UL,65535UL}};
        int32_t l_48 = (-1L);
        int i, j;
        if (p_8)
            break;
        if (func_19(func_25((safe_mul_func_int8_t_s_s((g_10 ^ p_5), 0x8EL)), g_10, p_5, g_10), l_11[2], g_14, l_13[2], g_33))
        { /* block id: 13 */
            int8_t l_35[5];
            int i;
            for (i = 0; i < 5; i++)
                l_35[i] = 0xABL;
            if (g_10)
                break;
            l_36[0][0]++;
            l_48 |= ((safe_add_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u(((((func_43(l_36[5][1], g_10, l_35[4], g_14) != 4294967287UL) || l_11[1]) , 1UL) != 1UL), l_35[3])), 0UL)) == g_10);
            return l_11[1];
        }
        else
        { /* block id: 20 */
            if (g_10)
                break;
            g_10 ^= (safe_lshift_func_int16_t_s_s(((l_13[4] <= p_5) , l_11[4]), 11));
        }
        for (g_10 = 11; (g_10 == (-12)); --g_10)
        { /* block id: 26 */
            g_64 &= (safe_div_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((+(safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_sub_func_int64_t_s_s(l_36[0][0], l_36[2][1])), 255UL)), (-1L)))), 1L)), g_14));
            return g_33;
        }
    }
    g_10 = ((safe_div_func_uint32_t_u_u((safe_sub_func_uint16_t_u_u(l_11[1], p_6)), l_13[2])) == g_14);
    if (((((safe_add_func_int8_t_s_s(((safe_lshift_func_uint8_t_u_u(l_12, 2)) == l_73[9][2]), g_14)) > g_33) >= p_7) <= 0x2DL))
    { /* block id: 32 */
        p_7 = 1L;
        g_10 = ((safe_mul_func_uint16_t_u_u(g_10, 1L)) > l_13[2]);
        if (p_7)
        { /* block id: 35 */
            l_12 = (+((-4L) <= g_33));
        }
        else
        { /* block id: 37 */
            l_13[5] |= 0x05CE5052L;
        }
        g_10 &= (safe_mod_func_int64_t_s_s((p_8 && 0xFA00L), l_73[7][0]));
    }
    else
    { /* block id: 41 */
        int8_t l_92 = (-10L);
        g_79++;
        if ((safe_sub_func_uint32_t_u_u(l_12, p_5)))
        { /* block id: 43 */
            p_7 = ((safe_div_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((-1L), g_64)), 0x105CA7CEL)) != (-4L));
            g_10 = (safe_rshift_func_int16_t_s_s((safe_mod_func_int16_t_s_s(g_64, p_8)), l_92));
            l_13[0] = g_64;
            g_10 = (((g_79 ^ g_33) & 1L) <= 0x71001949L);
        }
        else
        { /* block id: 48 */
            int16_t l_97 = 2L;
            int8_t l_100 = 0xDEL;
            l_97 = (((((((safe_mul_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((g_64 && p_8), g_79)), 0L)) ^ l_92) < p_7) ^ l_92) , g_33) >= g_64) == p_5);
            p_5 = (safe_rshift_func_uint16_t_u_u(l_100, 5));
        }
        g_10 ^= p_6;
    }
    return g_10;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_19(uint16_t  p_20, uint64_t  p_21, uint8_t  p_22, int32_t  p_23, uint32_t  p_24)
{ /* block id: 11 */
    uint16_t l_34 = 0x9B46L;
    return l_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_10
 * writes: g_10
 */
static uint16_t  func_25(int8_t  p_26, uint16_t  p_27, int64_t  p_28, uint8_t  p_29)
{ /* block id: 7 */
    int32_t l_32 = 0x4B6046E7L;
    l_32 |= g_10;
    g_10 = l_32;
    return l_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_14
 * writes:
 */
static int32_t  func_43(uint8_t  p_44, uint8_t  p_45, int8_t  p_46, uint8_t  p_47)
{ /* block id: 16 */
    return g_14;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_64, "g_64", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_106[i], "g_106[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_120, "g_120", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_150, "g_150", print_hash_value);
    transparent_crc(g_151, "g_151", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_152[i][j], "g_152[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 41
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 80
   depth: 2, occurrence: 11
   depth: 3, occurrence: 9
   depth: 4, occurrence: 6
   depth: 6, occurrence: 2
   depth: 7, occurrence: 4
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 110
XXX times a non-volatile is write: 44
XXX times a volatile is read: 15
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 78
XXX percentage of non-volatile access: 89.5

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 73
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 15
   depth: 1, occurrence: 21
   depth: 2, occurrence: 37

XXX percentage a fresh-made variable is used: 22
XXX percentage an existing variable is used: 78
********************* end of statistics **********************/

