/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9671156541546540528
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static const int64_t g_10[4] = {0x8CCCDDD1D8F8F576LL,0x8CCCDDD1D8F8F576LL,0x8CCCDDD1D8F8F576LL,0x8CCCDDD1D8F8F576LL};
static uint32_t g_15 = 0x2BA7B7E8L;
static int8_t g_27 = 0x99L;
static uint32_t g_31 = 4294967295UL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int32_t  p_4, uint16_t  p_5, int16_t  p_6, int32_t  p_7);
static int64_t  func_22(uint32_t  p_23, uint32_t  p_24, uint8_t  p_25, uint32_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_15 g_27 g_31
 * writes: g_15 g_27 g_31
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_11 = 0UL;
    int32_t l_28 = (-1L);
    l_28 = func_2((((safe_sub_func_int32_t_s_s(((18446744073709551609UL | g_10[1]) | l_11), l_11)) ^ l_11) , g_10[3]), l_11, l_11, g_10[1], l_11);
    g_31 ^= (safe_mul_func_int16_t_s_s((((((l_28 >= l_28) & 0x8AL) >= g_27) , 0L) > g_27), 0xB962L));
    return l_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_10
 * writes: g_15 g_27
 */
static int32_t  func_2(int32_t  p_3, int32_t  p_4, uint16_t  p_5, int16_t  p_6, int32_t  p_7)
{ /* block id: 1 */
    int16_t l_12 = (-5L);
    int32_t l_13 = 0xCB8F6C21L;
    int32_t l_14 = 0xB0B4EF66L;
    g_15++;
    g_27 = (safe_div_func_int64_t_s_s((safe_mod_func_int64_t_s_s(func_22(l_14, l_14, g_15, p_5), p_4)), l_12));
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_10
 * writes:
 */
static int64_t  func_22(uint32_t  p_23, uint32_t  p_24, uint8_t  p_25, uint32_t  p_26)
{ /* block id: 3 */
    return g_10[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 8
   depth: 7, occurrence: 2
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 7
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 7

XXX percentage a fresh-made variable is used: 31
XXX percentage an existing variable is used: 69
********************* end of statistics **********************/

