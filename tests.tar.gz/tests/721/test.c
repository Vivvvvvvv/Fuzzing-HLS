/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16999393958744591323
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2[7] = {(-1L),0xD313DD33L,(-1L),(-1L),0xD313DD33L,(-1L),(-1L)};
static int32_t g_5 = 0L;
static int32_t g_11 = 0xCB24CE55L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_11
 * writes: g_2 g_5 g_11
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_24 = 0xE1L;
    for (g_2[0] = 0; (g_2[0] != 24); g_2[0] = safe_add_func_int8_t_s_s(g_2[0], 2))
    { /* block id: 3 */
        uint64_t l_10 = 0x8A94B2AB76D6092FLL;
        int32_t l_22 = 0x6FA4BC44L;
        int32_t l_23 = 0xBA928F0BL;
        for (g_5 = (-30); (g_5 <= 28); g_5++)
        { /* block id: 6 */
            g_11 &= (safe_lshift_func_int16_t_s_s(0xA20BL, l_10));
        }
        if ((((0xD5L > g_5) == g_11) , 0x813A3DBCL))
        { /* block id: 9 */
            int8_t l_16 = 0xB7L;
            uint16_t l_17 = 0xD87EL;
            g_5 &= (((safe_mul_func_int16_t_s_s((safe_mod_func_int8_t_s_s((g_2[0] < l_16), l_16)), (-1L))) & g_2[0]) , l_17);
            l_22 |= (((safe_mod_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(((0x73L != 0x28L) & 0L), 0x1724L)), g_2[0])) , 1UL) , g_11);
        }
        else
        { /* block id: 12 */
            l_23 &= (0x29EDL && (-6L));
            if (l_24)
                break;
            if (l_24)
                continue;
            g_5 = (safe_lshift_func_int16_t_s_s(0xCD25L, g_11));
        }
    }
    return g_11;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 8
   depth: 2, occurrence: 5
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 16
XXX times a non-volatile is write: 7
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 2
   depth: 1, occurrence: 2
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 36.8
XXX percentage an existing variable is used: 63.2
********************* end of statistics **********************/

