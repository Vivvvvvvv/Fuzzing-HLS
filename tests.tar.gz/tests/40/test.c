/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7163317832593544533
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 2L;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[2][2] = {{(-1L),(-1L)},{(-1L),(-1L)}};
static int32_t g_4 = 0x30F94F37L;
static volatile int32_t g_7 = 0xACCBAD86L;/* VOLATILE GLOBAL g_7 */
static volatile int32_t g_8 = (-2L);/* VOLATILE GLOBAL g_8 */
static int32_t g_9 = 1L;
static uint32_t g_69 = 2UL;
static uint16_t g_103 = 2UL;
static int32_t g_109[6] = {0x5C9911E2L,0x5C9911E2L,0x5C9911E2L,0x5C9911E2L,0x5C9911E2L,0x5C9911E2L};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int64_t  func_16(int8_t  p_17, uint8_t  p_18, uint64_t  p_19, uint8_t  p_20, int16_t  p_21);
static uint16_t  func_37(int64_t  p_38, int16_t  p_39, uint64_t  p_40, int8_t  p_41);
static uint64_t  func_44(const uint32_t  p_45, const uint16_t  p_46, int64_t  p_47, uint32_t  p_48, int32_t  p_49);
static int8_t  func_50(const uint64_t  p_51, const int64_t  p_52);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_9 g_2 g_3 g_7 g_8 g_69 g_103 g_109
 * writes: g_4 g_9 g_2 g_3 g_69 g_7 g_8 g_103 g_109
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_23 = 0x382BDB979CD329B3LL;
    int32_t l_113 = 0xA0E27A77L;
    int32_t l_114[10][9] = {{0xFC704608L,8L,6L,6L,8L,0xFC704608L,0xD7137552L,0xD7137552L,0xFC704608L},{1L,0xDAD61334L,0x374D1AA5L,0xDAD61334L,1L,0xDAD61334L,0x374D1AA5L,0xDAD61334L,1L},{8L,6L,6L,8L,0xFC704608L,0xD7137552L,0xD7137552L,0xFC704608L,8L},{0x0ACB108FL,0xDAD61334L,0x0ACB108FL,0x775BFFDCL,0x0ACB108FL,0xDAD61334L,0x0ACB108FL,0x775BFFDCL,0x0ACB108FL},{8L,8L,0xD7137552L,6L,0xFC704608L,0xFC704608L,6L,0xD7137552L,8L},{1L,0x775BFFDCL,0x374D1AA5L,0x775BFFDCL,1L,0x775BFFDCL,0x374D1AA5L,0x775BFFDCL,1L},{0xFC704608L,6L,0xD7137552L,8L,8L,0xD7137552L,6L,0xFC704608L,0xFC704608L},{0x0ACB108FL,0x775BFFDCL,0x0ACB108FL,0xDAD61334L,0x0ACB108FL,0x775BFFDCL,0x0ACB108FL,0xDAD61334L,0x0ACB108FL},{0xFC704608L,8L,6L,6L,8L,0xFC704608L,0xD7137552L,0xD7137552L,0xFC704608L},{1L,0xDAD61334L,0x374D1AA5L,0xDAD61334L,1L,0xDAD61334L,0x374D1AA5L,0xDAD61334L,1L}};
    int32_t l_115[5][8][6] = {{{0x7FE13056L,(-6L),0x36473322L,0x99C26CA6L,0x84563440L,0x74BC7CA1L},{0x9766CF4EL,0x7FE13056L,0x36473322L,(-5L),9L,0x9766CF4EL},{(-1L),(-5L),0x74BC7CA1L,0xF3236F7AL,0x370E5BB3L,0x34BAB51EL},{0xF3236F7AL,0x370E5BB3L,0x34BAB51EL,(-5L),0xF7A928B0L,(-1L)},{9L,0xE2E08AAFL,(-5L),0x99C26CA6L,0xF7A928B0L,0xE814EA1FL},{0xF7A928B0L,0x370E5BB3L,0x36473322L,0x36473322L,0x370E5BB3L,0xF7A928B0L},{0x9766CF4EL,(-5L),0xFC3C19ABL,0x7FE13056L,9L,0xE814EA1FL},{0xF3236F7AL,0x7FE13056L,0x74BC7CA1L,(-1L),0x84563440L,(-1L)}},{{0xF3236F7AL,(-6L),(-1L),0x7FE13056L,0xF7A928B0L,0x34BAB51EL},{0x9766CF4EL,9L,(-5L),0x36473322L,0x7FE13056L,0x9766CF4EL},{0xF7A928B0L,(-6L),0xFC3C19ABL,0x99C26CA6L,0x370E5BB3L,0x74BC7CA1L},{9L,0x7FE13056L,0xFC3C19ABL,(-5L),0x9766CF4EL,0x9766CF4EL},{0xF3236F7AL,(-5L),(-5L),0xF3236F7AL,0x84563440L,0x34BAB51EL},{(-1L),0x370E5BB3L,(-1L),(-5L),0x7FE13056L,(-1L)},{0x9766CF4EL,0xE2E08AAFL,0x74BC7CA1L,0x99C26CA6L,0x7FE13056L,0xE814EA1FL},{0x7FE13056L,0x370E5BB3L,0xFC3C19ABL,0x36473322L,0x84563440L,0xF7A928B0L}},{{9L,(-5L),0x36473322L,0x7FE13056L,0x9766CF4EL,0xE814EA1FL},{(-1L),0x7FE13056L,(-5L),(-1L),0x370E5BB3L,(-1L)},{(-1L),(-6L),0x34BAB51EL,0x7FE13056L,0x7FE13056L,0x34BAB51EL},{9L,9L,0x74BC7CA1L,0x36473322L,0xF7A928B0L,0x9766CF4EL},{0x7FE13056L,(-6L),0x36473322L,0x99C26CA6L,0x84563440L,0x74BC7CA1L},{0x9766CF4EL,0x7FE13056L,0x36473322L,(-5L),9L,0x9766CF4EL},{(-1L),(-5L),0x74BC7CA1L,0xF3236F7AL,0x370E5BB3L,0xFC3C19ABL},{0x99C26CA6L,9L,0xFC3C19ABL,(-1L),(-1L),0L}},{{0x7FE13056L,(-5L),(-1L),0x370E5BB3L,(-1L),0x74BC7CA1L},{(-1L),9L,(-6L),(-6L),9L,(-1L)},{0xF7A928B0L,(-1L),0xAB71BD0EL,0xF3236F7AL,0x7FE13056L,0x74BC7CA1L},{0x99C26CA6L,0xF3236F7AL,0x34BAB51EL,0x36473322L,0x9766CF4EL,0L},{0x99C26CA6L,0xE2E08AAFL,0x36473322L,0xF3236F7AL,(-1L),0xFC3C19ABL},{0xF7A928B0L,0x7FE13056L,(-1L),(-6L),0xF3236F7AL,0xF7A928B0L},{(-1L),0xE2E08AAFL,0xAB71BD0EL,0x370E5BB3L,9L,0x34BAB51EL},{0x7FE13056L,0xF3236F7AL,0xAB71BD0EL,(-1L),0xF7A928B0L,0xF7A928B0L}},{{0x99C26CA6L,(-1L),(-1L),0x99C26CA6L,0x9766CF4EL,0xFC3C19ABL},{0L,9L,0x36473322L,(-1L),0xF3236F7AL,0L},{0xF7A928B0L,(-5L),0x34BAB51EL,0x370E5BB3L,0xF3236F7AL,0x74BC7CA1L},{0xF3236F7AL,9L,0xAB71BD0EL,(-6L),0x9766CF4EL,(-1L)},{0x7FE13056L,(-1L),(-6L),0xF3236F7AL,0xF7A928B0L,0x74BC7CA1L},{0L,0xF3236F7AL,(-1L),0x36473322L,9L,0L},{0L,0xE2E08AAFL,0xFC3C19ABL,0xF3236F7AL,0xF3236F7AL,0xFC3C19ABL},{0x7FE13056L,0x7FE13056L,0x34BAB51EL,(-6L),(-1L),0xF7A928B0L}}};
    int64_t l_117 = 0xBBB44E860B7F1185LL;
    uint8_t l_119 = 4UL;
    int32_t l_126 = 0x55CD5D44L;
    int i, j, k;
    for (g_4 = 9; (g_4 == (-29)); g_4--)
    { /* block id: 3 */
        int32_t l_110 = (-1L);
        int32_t l_111 = (-1L);
        int32_t l_112[9][2][10] = {{{0xF0722DCAL,(-9L),6L,7L,7L,6L,(-9L),0xF0722DCAL,0xE76C9008L,(-1L)},{6L,(-9L),0xF0722DCAL,0xE76C9008L,(-1L),0xE76C9008L,0xF0722DCAL,(-9L),6L,7L}},{{0L,0xC4C94056L,0xF0722DCAL,(-1L),(-9L),(-9L),(-1L),0xF0722DCAL,0xC4C94056L,0L},{0xC4C94056L,0xE76C9008L,6L,(-1L),0x2A3456A0L,0L,0x2A3456A0L,(-1L),6L,0xE76C9008L}},{{7L,0xF0722DCAL,0L,0xE76C9008L,0x2A3456A0L,(-2L),(-2L),0x2A3456A0L,0xE76C9008L,0L},{0x2A3456A0L,0x2A3456A0L,0xC4C94056L,7L,(-9L),(-2L),6L,(-2L),(-9L),7L}},{{7L,8L,7L,(-2L),(-1L),0L,6L,6L,0L,(-1L)},{0xC4C94056L,0x2A3456A0L,0x2A3456A0L,0xC4C94056L,7L,(-9L),(-2L),6L,(-2L),(-9L)}},{{0L,0xF0722DCAL,7L,0xF0722DCAL,0L,0xE76C9008L,0x2A3456A0L,0xF0722DCAL,0xF0722DCAL,(-2L)},{7L,0xC4C94056L,0x2A3456A0L,0x2A3456A0L,0xC4C94056L,7L,(-9L),(-2L),6L,(-2L)}},{{8L,0x2A3456A0L,6L,0xF0722DCAL,6L,0x2A3456A0L,8L,(-9L),0L,0L},{8L,0L,7L,0xE76C9008L,0xE76C9008L,7L,0L,8L,0xC4C94056L,(-9L)}},{{7L,0L,8L,0xC4C94056L,(-9L),0xC4C94056L,8L,0L,7L,0xE76C9008L},{6L,0x2A3456A0L,8L,(-9L),0L,0L,(-9L),8L,0x2A3456A0L,6L}},{{0x2A3456A0L,0xC4C94056L,7L,(-9L),(-2L),6L,(-2L),(-9L),7L,0xC4C94056L},{0xE76C9008L,8L,6L,0xC4C94056L,(-2L),0xF0722DCAL,0xF0722DCAL,(-2L),0xC4C94056L,6L}},{{(-2L),(-2L),0x2A3456A0L,0xE76C9008L,0L,0xF0722DCAL,7L,0xF0722DCAL,0L,0xE76C9008L},{0xE76C9008L,(-1L),0xE76C9008L,0xF0722DCAL,(-9L),6L,7L,7L,6L,(-9L)}}};
        int64_t l_116 = (-9L);
        int32_t l_118 = (-7L);
        int8_t l_133[1][2];
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_133[i][j] = 0x68L;
        }
        for (g_9 = 0; (g_9 != 8); ++g_9)
        { /* block id: 6 */
            uint64_t l_22 = 0x6A715CC48B1647C2LL;
            g_109[4] ^= (safe_mod_func_int16_t_s_s((safe_div_func_uint64_t_u_u((func_16((l_22 || 0xEBF495E3L), l_23, l_22, g_2, g_4) | g_4), 0x3DC6D32E1AF327E2LL)), g_4));
            g_109[4] = l_110;
        }
        l_119--;
        if ((safe_lshift_func_uint8_t_u_s(((((((safe_rshift_func_int8_t_s_s(l_126, g_109[2])) , l_118) <= 0UL) == g_69) & g_4) > l_114[9][3]), l_119)))
        { /* block id: 58 */
            g_109[1] = g_9;
            if (g_7)
                break;
            if (g_7)
                break;
        }
        else
        { /* block id: 62 */
            g_8 = (safe_add_func_uint32_t_u_u((safe_add_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(1UL, l_133[0][1])), g_103)), l_110));
        }
    }
    if ((((safe_lshift_func_int16_t_s_u(0x2D19L, g_3[0][1])) ^ g_69) & 6L))
    { /* block id: 66 */
        uint8_t l_146 = 249UL;
        int32_t l_147 = (-9L);
        g_9 ^= (safe_rshift_func_int8_t_s_s((0x4BL <= g_3[0][1]), 5));
        l_147 &= ((((safe_rshift_func_int16_t_s_u((safe_sub_func_int32_t_s_s(((safe_mod_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u(l_146, 1)), l_146)) >= l_126), g_109[0])), 8)) <= g_3[0][1]) != g_109[4]) , l_119);
    }
    else
    { /* block id: 69 */
        uint8_t l_148 = 255UL;
        g_2 = ((g_103 > l_148) | (-1L));
        l_115[4][6][0] = 0xFB56803DL;
    }
    return g_69;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_9 g_7 g_2 g_4 g_8 g_69 g_103
 * writes: g_2 g_3 g_69 g_7 g_8 g_103
 */
static int64_t  func_16(int8_t  p_17, uint8_t  p_18, uint64_t  p_19, uint8_t  p_20, int16_t  p_21)
{ /* block id: 7 */
    uint32_t l_24 = 0x9CC099A5L;
    uint64_t l_29 = 0x08700D35DA2A0C0ELL;
    int32_t l_30 = (-1L);
    int32_t l_31 = 0x5CA2589DL;
    uint32_t l_34 = 0UL;
    int32_t l_81 = 1L;
    int32_t l_87 = 0x8491658DL;
    int32_t l_89 = 0x778613ABL;
    int32_t l_90 = 0x363893D9L;
    int32_t l_91 = (-1L);
    int32_t l_92 = 1L;
    int32_t l_93 = 0x589394F4L;
    int32_t l_94[4] = {(-8L),(-8L),(-8L),(-8L)};
    uint32_t l_95 = 0xB3A2D95AL;
    uint32_t l_99 = 0x78B72995L;
    int16_t l_102 = 0x7A52L;
    int i;
    l_24 = 0x75EE4C20L;
    if ((((safe_add_func_int64_t_s_s(((safe_div_func_uint32_t_u_u(l_29, 0x81DE9829L)) && g_3[0][1]), g_9)) > l_24) > p_18))
    { /* block id: 9 */
        int64_t l_32 = 0L;
        int32_t l_33 = 0xFCC86F80L;
        uint32_t l_82 = 0x622B4615L;
        int32_t l_84 = 0x890B8A2EL;
        int32_t l_85 = (-1L);
        int32_t l_86[6][8][2] = {{{0xC95B9239L,(-10L)},{0xEBF99C48L,0x1C21D012L},{0x38A5BFF8L,7L},{7L,0x10476CE5L},{0x8CFE7A21L,0xE3E38F49L},{0x617F2E32L,0xEBF99C48L},{(-7L),(-1L)},{(-10L),(-1L)}},{{(-7L),0xEBF99C48L},{0x617F2E32L,0xE3E38F49L},{0x8CFE7A21L,0x10476CE5L},{7L,7L},{0x38A5BFF8L,0x1C21D012L},{0xEBF99C48L,(-10L)},{0xC95B9239L,1L},{0x1C21D012L,0xC95B9239L}},{{0xE24E13FEL,1L},{0xE24E13FEL,0xC95B9239L},{0x1C21D012L,1L},{0xC95B9239L,(-10L)},{0xEBF99C48L,0x1C21D012L},{0x38A5BFF8L,7L},{7L,0x10476CE5L},{0x8CFE7A21L,0xE3E38F49L}},{{0x617F2E32L,0xEBF99C48L},{(-7L),(-1L)},{(-10L),(-1L)},{(-7L),0xEBF99C48L},{0x617F2E32L,0xE3E38F49L},{0x8CFE7A21L,0x10476CE5L},{7L,7L},{0x38A5BFF8L,0x1C21D012L}},{{0xEBF99C48L,(-10L)},{0xC95B9239L,1L},{0x1C21D012L,0xC95B9239L},{0xE24E13FEL,1L},{0xE24E13FEL,0xC95B9239L},{0x1C21D012L,1L},{0xC95B9239L,(-10L)},{0xEBF99C48L,0x1C21D012L}},{{0x38A5BFF8L,7L},{7L,0x10476CE5L},{0x8CFE7A21L,0xE3E38F49L},{0x617F2E32L,0xEBF99C48L},{(-7L),(-1L)},{(-10L),(-1L)},{(-7L),0xEBF99C48L},{5L,1L}}};
        int i, j, k;
        l_34--;
        if (l_30)
        { /* block id: 11 */
            const int8_t l_53 = 0L;
            l_33 = (func_37((safe_div_func_uint64_t_u_u(func_44(((func_50(g_7, l_53) > 0xC9L) < l_33), p_19, g_4, g_4, l_32), l_30)), l_30, l_34, g_4) <= l_32);
        }
        else
        { /* block id: 38 */
            return g_69;
        }
        for (l_30 = 0; (l_30 >= (-30)); l_30 = safe_sub_func_uint64_t_u_u(l_30, 8))
        { /* block id: 43 */
            uint32_t l_80 = 18446744073709551610UL;
            int32_t l_83 = 0xD895A5D7L;
            int32_t l_88[3][3][8] = {{{0L,0xA3E439E4L,0xEA311AD4L,0xEA311AD4L,0xA3E439E4L,0L,0xA3E439E4L,0xEA311AD4L},{7L,0xA3E439E4L,7L,0L,0L,7L,0xA3E439E4L,7L},{1L,0L,0xEA311AD4L,0L,1L,1L,0L,0xEA311AD4L}},{{1L,1L,0L,0xEA311AD4L,0L,1L,1L,0L},{7L,0L,0L,7L,0xA3E439E4L,7L,0L,0L},{0L,0xA3E439E4L,0xEA311AD4L,0xEA311AD4L,0xA3E439E4L,0L,0xA3E439E4L,0xEA311AD4L}},{{7L,0xA3E439E4L,7L,0L,0L,7L,0xA3E439E4L,7L},{1L,0L,0xEA311AD4L,0L,1L,1L,0L,0xEA311AD4L},{1L,1L,0L,0xEA311AD4L,0L,1L,1L,0L}}};
            int16_t l_98[4][2] = {{8L,7L},{8L,8L},{7L,8L},{8L,7L}};
            int i, j, k;
            g_8 = (((((((+(((safe_mod_func_uint32_t_u_u(l_80, l_81)) != p_19) , l_82)) == g_4) ^ 0x216FL) | 0x0590L) || 0xB2CC25678016B841LL) , 0x2BL) >= p_21);
            ++l_95;
            l_99++;
            g_103++;
        }
    }
    else
    { /* block id: 49 */
        int8_t l_106 = 0x1FL;
        return l_106;
    }
    g_3[0][1] = (safe_rshift_func_int16_t_s_u(0x262EL, l_90));
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_8
 * writes: g_3 g_2 g_8
 */
static uint16_t  func_37(int64_t  p_38, int16_t  p_39, uint64_t  p_40, int8_t  p_41)
{ /* block id: 22 */
    uint32_t l_71 = 0x53D3A1A9L;
    ++l_71;
    for (p_40 = 0; (p_40 <= 1); p_40 += 1)
    { /* block id: 26 */
        int64_t l_74[8][2];
        int i, j;
        for (i = 0; i < 8; i++)
        {
            for (j = 0; j < 2; j++)
                l_74[i][j] = (-1L);
        }
        for (l_71 = 0; (l_71 <= 1); l_71 += 1)
        { /* block id: 29 */
            int i, j;
            g_3[l_71][p_40] ^= l_74[6][0];
            g_2 = 0x110EA916L;
            g_3[l_71][p_40] = 0x0C7F1223L;
            g_8 |= l_74[3][1];
        }
    }
    return l_71;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_4 g_69 g_7 g_2
 * writes: g_3 g_69 g_7
 */
static uint64_t  func_44(const uint32_t  p_45, const uint16_t  p_46, int64_t  p_47, uint32_t  p_48, int32_t  p_49)
{ /* block id: 16 */
    uint16_t l_70 = 0xEF17L;
    g_3[0][1] = (~2UL);
    g_69 |= (((safe_rshift_func_int8_t_s_s(g_8, 6)) , (-1L)) < g_4);
    g_7 ^= (65527UL == l_70);
    p_49 = ((p_48 , l_70) == g_2);
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static int8_t  func_50(const uint64_t  p_51, const int64_t  p_52)
{ /* block id: 12 */
    int8_t l_62 = 0L;
    int32_t l_65 = 0x335A02A9L;
    g_2 = (safe_div_func_uint8_t_u_u((((safe_div_func_int8_t_s_s((safe_div_func_int64_t_s_s((((safe_rshift_func_int8_t_s_u(l_62, 7)) >= 0x2401L) , p_52), l_62)), 0x29L)) , g_2) || p_51), p_51));
    l_65 = ((safe_add_func_uint16_t_u_u(0x7C75L, l_62)) & (-8L));
    return p_52;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_109[i], "g_109[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 53
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 53
   depth: 2, occurrence: 7
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 2
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 74
XXX times a non-volatile is write: 22
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 11
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 134
XXX percentage of non-volatile access: 81.4

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 46
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 18
   depth: 1, occurrence: 12
   depth: 2, occurrence: 16

XXX percentage a fresh-made variable is used: 16
XXX percentage an existing variable is used: 84
********************* end of statistics **********************/

