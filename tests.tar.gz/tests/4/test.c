/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15929064753499582327
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint16_t  f0;
   uint32_t  f1;
   uint32_t  f2;
   const int32_t  f3;
   uint32_t  f4;
   int8_t  f5;
   volatile uint16_t  f6;
};

struct S1 {
   int8_t  f0;
   struct S0  f1;
   uint8_t  f2;
   uint64_t  f3;
   uint32_t  f4;
   const int32_t  f5;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[9][8][3] = {{{0xD0A3205FL,0L,0xD13D8C53L},{0x4AA41A80L,0x68BB4AADL,0xD0A3205FL},{0xD0A3205FL,0x3A3FC4B0L,0xB8E136DCL},{0x37ACED45L,8L,0xB8E136DCL},{0x0A29822CL,0xA2F617A9L,0xD0A3205FL},{0xDA37BB00L,(-2L),0xD13D8C53L},{0xB8E136DCL,0xA2F617A9L,0x8BD921B0L},{1L,8L,0x311C3FC0L}},{{1L,0x3A3FC4B0L,0xDA37BB00L},{0xB8E136DCL,0x68BB4AADL,0xCA9D6923L},{0xDA37BB00L,0L,0xDA37BB00L},{0x0A29822CL,0x89B1AB44L,0x311C3FC0L},{0x37ACED45L,0x89B1AB44L,0x8BD921B0L},{0xD0A3205FL,0L,0xD13D8C53L},{0x4AA41A80L,0x68BB4AADL,0xD0A3205FL},{0xD0A3205FL,0x311C3FC0L,0xBCEF054AL}},{{(-1L),0xD0A3205FL,0xBCEF054AL},{0x0C4365DEL,0x8BD921B0L,0x2CA96836L},{0xD52A42BBL,1L,(-1L)},{0xBCEF054AL,0x8BD921B0L,0x13E458C4L},{4L,0xD0A3205FL,0xE3869393L},{4L,0x311C3FC0L,0xD52A42BBL},{0xBCEF054AL,0x4AA41A80L,0L},{0xD52A42BBL,0x0A29822CL,0xD52A42BBL}},{{0x0C4365DEL,(-4L),0xE3869393L},{(-1L),(-4L),0x13E458C4L},{0x2CA96836L,0x0A29822CL,(-1L)},{7L,0x4AA41A80L,0x2CA96836L},{0x2CA96836L,0x311C3FC0L,0xBCEF054AL},{(-1L),0xD0A3205FL,0xBCEF054AL},{0x0C4365DEL,0x8BD921B0L,0x2CA96836L},{0xD52A42BBL,1L,(-1L)}},{{0xBCEF054AL,0x8BD921B0L,0x13E458C4L},{4L,0xD0A3205FL,0xE3869393L},{4L,0x311C3FC0L,0xD52A42BBL},{0xBCEF054AL,0x4AA41A80L,0L},{0xD52A42BBL,0x0A29822CL,0xD52A42BBL},{0x0C4365DEL,(-4L),0xE3869393L},{(-1L),(-4L),0x13E458C4L},{0x2CA96836L,0x0A29822CL,(-1L)}},{{7L,0x4AA41A80L,0x2CA96836L},{0x2CA96836L,0x311C3FC0L,0xBCEF054AL},{(-1L),0xD0A3205FL,0xBCEF054AL},{0x0C4365DEL,0x8BD921B0L,0x2CA96836L},{0xD52A42BBL,1L,(-1L)},{0xBCEF054AL,0x8BD921B0L,0x13E458C4L},{4L,0xD0A3205FL,0xE3869393L},{4L,0x311C3FC0L,0xD52A42BBL}},{{0xBCEF054AL,0x4AA41A80L,0L},{0xD52A42BBL,0x0A29822CL,0xD52A42BBL},{0x0C4365DEL,(-4L),0xE3869393L},{(-1L),(-4L),0x13E458C4L},{0x2CA96836L,0x0A29822CL,(-1L)},{7L,0x4AA41A80L,0x2CA96836L},{0x2CA96836L,0x311C3FC0L,0xBCEF054AL},{(-1L),0xD0A3205FL,0xBCEF054AL}},{{0x0C4365DEL,0x8BD921B0L,0x2CA96836L},{0xD52A42BBL,1L,(-1L)},{0xBCEF054AL,0x8BD921B0L,0x13E458C4L},{4L,0xD0A3205FL,0xE3869393L},{4L,0x311C3FC0L,0xD52A42BBL},{0xBCEF054AL,0x4AA41A80L,0L},{0xD52A42BBL,0x0A29822CL,0xD52A42BBL},{0x0C4365DEL,(-4L),0xE3869393L}},{{(-1L),(-4L),0x13E458C4L},{0x2CA96836L,0x0A29822CL,(-1L)},{7L,0x4AA41A80L,0x2CA96836L},{0x2CA96836L,0x311C3FC0L,0xBCEF054AL},{(-1L),0xD0A3205FL,0xBCEF054AL},{0x0C4365DEL,0x8BD921B0L,0x2CA96836L},{0xD52A42BBL,1L,(-1L)},{0xBCEF054AL,0x8BD921B0L,0x13E458C4L}}};
static volatile int32_t g_3[2][1][10] = {{{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L}},{{4L,4L,4L,4L,4L,4L,4L,4L,4L,4L}}};
static volatile int32_t g_4 = 0xE1BFEDAAL;/* VOLATILE GLOBAL g_4 */
static int32_t g_5[8] = {0L,1L,1L,(-6L),1L,1L,(-6L),1L};
static int32_t g_30[6] = {0xE56CDAA9L,0xE56CDAA9L,(-2L),0xE56CDAA9L,0xE56CDAA9L,(-2L)};
static int32_t g_37 = 4L;
static uint32_t g_48[7][9] = {{1UL,0x62C44F03L,18446744073709551615UL,0x48866363L,0x62C44F03L,18446744073709551612UL,0x62C44F03L,0x48866363L,18446744073709551615UL},{0x8AAF4532L,0x8AAF4532L,18446744073709551612UL,0x48866363L,1UL,0UL,0x8AAF4532L,1UL,18446744073709551615UL},{0UL,0x62C44F03L,18446744073709551615UL,1UL,1UL,18446744073709551615UL,0x62C44F03L,0UL,18446744073709551612UL},{0UL,1UL,18446744073709551612UL,0UL,0x62C44F03L,18446744073709551615UL,1UL,1UL,18446744073709551615UL},{0x8AAF4532L,1UL,18446744073709551615UL,1UL,0x8AAF4532L,0UL,1UL,0x48866363L,18446744073709551612UL},{1UL,0x62C44F03L,18446744073709551615UL,0x48866363L,0x62C44F03L,18446744073709551612UL,0x62C44F03L,0x48866363L,18446744073709551615UL},{0x8AAF4532L,0x8AAF4532L,18446744073709551612UL,0x48866363L,1UL,0UL,0x8AAF4532L,1UL,18446744073709551615UL}};
static const struct S1 g_121 = {1L,{0x74C2L,0x65F0A685L,4UL,0L,0xFE059428L,3L,65531UL},0x53L,0xFED00A9482F86C40LL,0xD13B53BBL,-2L};/* VOLATILE GLOBAL g_121 */


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);
static int16_t  func_8(uint64_t  p_9, uint16_t  p_10, uint8_t  p_11, uint8_t  p_12);
static int32_t  func_15(uint32_t  p_16, uint16_t  p_17);
static int32_t  func_23(uint64_t  p_24, int64_t  p_25);
static int32_t  func_33(int8_t  p_34);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_3 g_30 g_2 g_37 g_48 g_4 g_121
 * writes: g_5 g_30 g_37 g_4 g_48 g_2 g_3
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_13[8][9][3] = {{{1UL,8UL,6UL},{0x7CL,0x1FL,0x1FL},{0xD2L,253UL,0x1FL},{255UL,0x4FL,6UL},{255UL,255UL,1UL},{0x1CL,0x17L,253UL},{1UL,255UL,0UL},{0xFDL,0x4FL,0x7CL},{253UL,253UL,255UL}},{{253UL,0x1FL,1UL},{0xFDL,8UL,0UL},{1UL,0UL,0xFDL},{0x1CL,0xFDL,0UL},{255UL,6UL,1UL},{255UL,1UL,255UL},{0xD2L,1UL,0x7CL},{0x7CL,6UL,0UL},{1UL,0xFDL,253UL}},{{0x4FL,0UL,1UL},{1UL,8UL,6UL},{0x7CL,0x1FL,0x1FL},{0xD2L,253UL,0x1FL},{255UL,0x4FL,6UL},{255UL,255UL,1UL},{0x1CL,0x17L,253UL},{1UL,255UL,0UL},{0xFDL,0x4FL,0x7CL}},{{253UL,253UL,255UL},{253UL,0x1FL,1UL},{0xFDL,8UL,0UL},{1UL,0UL,0xFDL},{0x1CL,0xFDL,0UL},{255UL,6UL,1UL},{255UL,1UL,255UL},{0xD2L,1UL,0x7CL},{0x7CL,6UL,0UL}},{{1UL,0xFDL,253UL},{0x4FL,0UL,1UL},{0UL,6UL,0xFDL},{255UL,253UL,253UL},{8UL,0x1CL,253UL},{0xD2L,0x1FL,0xFDL},{1UL,0xD2L,1UL},{0xDEL,0UL,0x1CL},{0x7CL,0xD2L,255UL}},{{0x4FL,0x1FL,255UL},{0x1CL,0x1CL,0xD2L},{0x1CL,253UL,0x7CL},{0x4FL,6UL,1UL},{0x7CL,255UL,0x4FL},{0xDEL,0x4FL,1UL},{1UL,0x17L,0x7CL},{0xD2L,0UL,0xD2L},{8UL,0UL,255UL}},{{255UL,0x17L,255UL},{0UL,0x4FL,0x1CL},{0x1FL,255UL,1UL},{0UL,6UL,0xFDL},{255UL,253UL,253UL},{8UL,0x1CL,253UL},{0xD2L,0x1FL,0xFDL},{1UL,0xD2L,1UL},{0xDEL,0UL,0x1CL}},{{0x7CL,0xD2L,255UL},{0x4FL,0x1FL,255UL},{0x1CL,0x1CL,0xD2L},{0x1CL,253UL,0x7CL},{0x4FL,6UL,1UL},{0x7CL,255UL,0x4FL},{0xDEL,0x4FL,1UL},{1UL,0x17L,0x7CL},{0xD2L,0UL,0xD2L}}};
    int32_t l_114[7][8] = {{0L,0L,(-6L),1L,(-6L),0L,0L,(-6L)},{(-1L),(-6L),(-6L),(-1L),5L,(-1L),(-6L),(-6L)},{(-6L),5L,1L,1L,5L,(-6L),5L,1L},{(-1L),5L,(-1L),(-6L),(-6L),(-1L),5L,(-1L)},{0L,(-6L),1L,(-6L),0L,0L,(-6L),1L},{0L,0L,(-6L),1L,(-6L),0L,0L,(-6L)},{(-1L),(-6L),(-6L),(-1L),5L,(-1L),(-6L),(-6L)}};
    int8_t l_128 = 1L;
    uint8_t l_129 = 0x83L;
    uint64_t l_140 = 18446744073709551607UL;
    int8_t l_155 = 0x18L;
    int i, j, k;
    for (g_5[6] = 0; (g_5[6] >= 11); g_5[6] = safe_add_func_int64_t_s_s(g_5[6], 1))
    { /* block id: 3 */
        int16_t l_14 = 5L;
        int32_t l_118 = (-10L);
        if (((func_8(l_13[5][4][1], l_14, g_3[1][0][3], g_5[6]) && l_13[5][4][1]) , 0L))
        { /* block id: 111 */
            uint64_t l_111 = 3UL;
            g_30[0] ^= (((((~g_3[1][0][3]) > 0xC7CDL) ^ 0x39BAL) <= g_37) == 65535UL);
            l_111 = (safe_add_func_int8_t_s_s((g_4 | g_48[6][8]), l_13[5][4][1]));
            if (l_14)
                break;
            l_114[1][6] = (((((safe_sub_func_int16_t_s_s(l_13[4][3][2], l_13[5][4][1])) && 0xAFCFED7CL) > g_2[1][6][1]) >= 0L) ^ (-2L));
        }
        else
        { /* block id: 116 */
            const uint32_t l_115 = 4294967295UL;
            return l_115;
        }
        for (l_14 = (-9); (l_14 != (-19)); l_14 = safe_sub_func_int64_t_s_s(l_14, 5))
        { /* block id: 121 */
            l_118 &= g_3[1][0][3];
        }
        g_3[0][0][2] &= (0x14C3L != l_118);
    }
    if (((((safe_rshift_func_uint8_t_u_s(g_4, 2)) == 0x972A186CL) & 4294967295UL) || l_13[5][4][1]))
    { /* block id: 126 */
        uint8_t l_122[8] = {1UL,0xDBL,1UL,1UL,0xDBL,1UL,1UL,0xDBL};
        int i;
        if (g_3[1][0][3])
        { /* block id: 127 */
            uint64_t l_123[5][4] = {{0x1A3542F59D8B5C60LL,0xB9BCF21FBBDD6291LL,0x968B3883621335F7LL,0x968B3883621335F7LL},{0x9F2823213DDA549CLL,0x9F2823213DDA549CLL,0x4963A11E95E8B2C4LL,0xB9BCF21FBBDD6291LL},{0xB9BCF21FBBDD6291LL,0x1A3542F59D8B5C60LL,0x4963A11E95E8B2C4LL,0x1A3542F59D8B5C60LL},{0x9F2823213DDA549CLL,0x9C585CD7AFF6306CLL,0x968B3883621335F7LL,0x4963A11E95E8B2C4LL},{0x1A3542F59D8B5C60LL,0x9C585CD7AFF6306CLL,0x9C585CD7AFF6306CLL,0x1A3542F59D8B5C60LL}};
            int i, j;
            l_122[6] = (((g_121 , g_121.f1) , g_121.f5) != 65532UL);
            ++l_123[0][2];
        }
        else
        { /* block id: 130 */
            g_5[3] = 0x58306E76L;
            l_128 = (safe_mul_func_int8_t_s_s(g_121.f1.f0, g_4));
        }
    }
    else
    { /* block id: 134 */
        uint32_t l_130 = 18446744073709551615UL;
        int32_t l_133 = 0xBD89C7B4L;
        int32_t l_134 = 0x3908CA69L;
        int32_t l_135 = 0xD6A9AA89L;
        int32_t l_136 = 0x548FEC59L;
        int32_t l_137 = 0x895B54F2L;
        int32_t l_138 = 0L;
        int32_t l_139[3][3] = {{0L,(-7L),0L},{9L,9L,9L},{0L,(-7L),0L}};
        int i, j;
        l_129 = g_48[5][7];
        l_130--;
        l_140--;
        g_37 = (((-1L) > l_136) <= g_2[2][2][0]);
    }
    for (l_129 = 0; (l_129 <= 6); l_129 += 1)
    { /* block id: 142 */
        uint8_t l_158 = 8UL;
        for (g_37 = 6; (g_37 >= 2); g_37 -= 1)
        { /* block id: 145 */
            int i, j;
            l_114[l_129][l_129] = 0L;
            if (g_48[g_37][l_129])
                continue;
            l_114[1][6] = (((safe_mul_func_int16_t_s_s(g_48[l_129][(g_37 + 1)], l_114[l_129][(l_129 + 1)])) != g_121.f1.f5) | g_48[g_37][l_129]);
            g_5[6] = ((safe_sub_func_uint16_t_u_u(0xE140L, 0x19F1L)) , l_13[2][4][1]);
        }
        for (g_37 = 1; (g_37 <= 6); g_37 += 1)
        { /* block id: 153 */
            int i, j;
            l_114[g_37][g_37] = (((safe_add_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_u(g_48[l_129][(g_37 + 2)], 13)) , g_48[g_37][l_129]), 0x6A75L)) >= l_114[g_37][g_37]) > g_121.f4);
            l_114[g_37][g_37] = (-1L);
            l_155 = (safe_lshift_func_uint16_t_u_s((safe_add_func_int64_t_s_s(g_121.f1.f1, g_121.f3)), g_2[8][3][0]));
            g_30[5] = (safe_rshift_func_uint16_t_u_u((l_158 || 0xC5L), g_121.f1.f0));
        }
    }
    return l_13[5][4][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_30 g_2 g_37 g_48 g_5
 * writes: g_30 g_37 g_4 g_48 g_2 g_3
 */
static int16_t  func_8(uint64_t  p_9, uint16_t  p_10, uint8_t  p_11, uint8_t  p_12)
{ /* block id: 4 */
    uint8_t l_64[1][10];
    int32_t l_68[8][1][6] = {{{6L,0xF1C6CB56L,(-3L),0xF1C6CB56L,6L,(-7L)}},{{0xF1C6CB56L,6L,(-7L),(-7L),6L,0xF1C6CB56L}},{{0x15289768L,0xF1C6CB56L,0xB48DF9F9L,6L,0xB48DF9F9L,0xF1C6CB56L}},{{0xB48DF9F9L,0x15289768L,(-7L),(-3L),(-3L),(-7L)}},{{0xB48DF9F9L,0xB48DF9F9L,(-3L),6L,(-7L),6L}},{{0x15289768L,0xB48DF9F9L,0x15289768L,(-7L),(-3L),(-3L)}},{{0xF1C6CB56L,0x15289768L,0x15289768L,0xF1C6CB56L,0xB48DF9F9L,6L}},{{6L,0xF1C6CB56L,(-3L),0xF1C6CB56L,6L,(-7L)}}};
    int32_t l_91 = (-8L);
    const uint32_t l_94 = 0x52157428L;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
            l_64[i][j] = 0x1CL;
    }
    if (func_15((safe_add_func_uint8_t_u_u(p_12, p_12)), g_3[0][0][0]))
    { /* block id: 60 */
        int64_t l_65 = (-2L);
        const int32_t l_71 = 0L;
        l_65 = (((l_64[0][4] != p_9) <= g_30[2]) == g_5[5]);
        if (g_37)
            goto lbl_79;
        g_3[1][0][3] = ((((safe_mul_func_uint8_t_u_u(g_3[1][0][3], 8UL)) || p_12) | g_5[6]) >= l_68[3][0][5]);
        g_37 |= (((safe_sub_func_uint8_t_u_u(2UL, g_2[2][2][0])) & p_11) && l_71);
    }
    else
    { /* block id: 64 */
        for (p_9 = 0; (p_9 <= 52); p_9 = safe_add_func_uint32_t_u_u(p_9, 7))
        { /* block id: 67 */
            int16_t l_74[1][2];
            int i, j;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 2; j++)
                    l_74[i][j] = 0L;
            }
            return l_74[0][1];
        }
        for (p_9 = 16; (p_9 <= 52); p_9++)
        { /* block id: 72 */
            return l_68[3][0][5];
        }
lbl_79:
        for (g_37 = (-9); (g_37 == 9); g_37 = safe_add_func_int8_t_s_s(g_37, 4))
        { /* block id: 77 */
            return l_64[0][5];
        }
        for (g_37 = 5; (g_37 >= 0); g_37 -= 1)
        { /* block id: 83 */
            int16_t l_86 = 0L;
            int i;
            g_30[g_37] = (g_30[g_37] <= 0xEAL);
            g_30[g_37] = ((((safe_add_func_uint64_t_u_u((((p_10 | p_11) != p_9) == 0x35671B2AL), 18446744073709551615UL)) >= 18446744073709551615UL) | g_30[5]) < (-8L));
            g_2[0][3][2] = ((safe_add_func_uint64_t_u_u(((safe_add_func_uint64_t_u_u(0xCA8204F9F0789255LL, 18446744073709551615UL)) < p_9), l_86)) && l_86);
        }
    }
    for (p_10 = 0; (p_10 <= 2); p_10 += 1)
    { /* block id: 91 */
        int64_t l_90 = 0L;
        uint8_t l_95[4][4] = {{255UL,255UL,255UL,255UL},{255UL,255UL,255UL,255UL},{255UL,255UL,255UL,255UL},{255UL,255UL,255UL,255UL}};
        int32_t l_102 = 0xA7F69D75L;
        uint16_t l_104 = 65535UL;
        uint32_t l_106 = 0xD7B0DA77L;
        int i, j;
        l_90 = (safe_unary_minus_func_int64_t_s((safe_sub_func_int32_t_s_s(l_68[3][0][5], 0xE4D7B1BAL))));
        l_91 = l_90;
        l_95[1][1] = ((safe_mod_func_int32_t_s_s(g_2[2][2][0], p_12)) != l_94);
        for (g_37 = 0; (g_37 >= 0); g_37 -= 1)
        { /* block id: 97 */
            uint64_t l_96 = 6UL;
            g_2[2][2][0] = (0xB7L <= 0xFFL);
            return l_96;
        }
        for (p_9 = 0; (p_9 <= 2); p_9 += 1)
        { /* block id: 103 */
            uint16_t l_105 = 2UL;
            l_102 = ((~(safe_mod_func_int8_t_s_s((safe_div_func_int64_t_s_s((((-1L) && 0xBDL) > p_10), p_10)), 1L))) >= p_9);
            l_106 |= (((!(l_104 , 0x5459D1A1L)) ^ 0xB103L) ^ l_105);
            l_102 = g_30[5];
        }
    }
    g_30[3] = (safe_unary_minus_func_uint64_t_u(g_3[1][0][8]));
    return g_37;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_30 g_2 g_37 g_48 g_5
 * writes: g_30 g_37 g_4 g_48 g_2
 */
static int32_t  func_15(uint32_t  p_16, uint16_t  p_17)
{ /* block id: 5 */
    int32_t l_26 = 0xB430F0C8L;
    int32_t l_63 = 0x2F92BF7CL;
    if (((0L >= p_17) , 0xE497D6A5L))
    { /* block id: 6 */
        int16_t l_20[6];
        int i;
        for (i = 0; i < 6; i++)
            l_20[i] = 0x6953L;
        l_20[5] &= 0x41A4633BL;
    }
    else
    { /* block id: 8 */
        for (p_16 = 0; (p_16 == 49); p_16 = safe_add_func_int8_t_s_s(p_16, 1))
        { /* block id: 11 */
            l_63 |= func_23(l_26, g_3[1][0][3]);
        }
        return l_63;
    }
    return g_5[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_30 g_2 g_37 g_48 g_5
 * writes: g_30 g_37 g_4 g_48 g_2
 */
static int32_t  func_23(uint64_t  p_24, int64_t  p_25)
{ /* block id: 12 */
    const int32_t l_29 = 0x46B3257BL;
    int32_t l_54 = 0x4B2487F0L;
    g_30[2] |= (safe_lshift_func_int16_t_s_s(l_29, g_3[1][0][3]));
    for (p_25 = 29; (p_25 >= 10); p_25--)
    { /* block id: 16 */
        g_48[6][8] |= func_33((g_2[3][0][0] , 2L));
        if (((safe_div_func_int8_t_s_s(p_25, g_2[2][2][0])) != l_29))
        { /* block id: 33 */
            return l_29;
        }
        else
        { /* block id: 35 */
            g_30[2] = ((safe_unary_minus_func_int32_t_s(((((g_2[2][2][0] >= g_5[6]) <= p_25) != p_24) , p_25))) == l_29);
        }
    }
    for (p_24 = 0; (p_24 == 2); p_24 = safe_add_func_int8_t_s_s(p_24, 1))
    { /* block id: 41 */
        int8_t l_55 = (-1L);
        int32_t l_56 = 7L;
        l_54 = (((0x9AAE9A15L < p_25) >= g_30[2]) == 246UL);
        if (g_30[5])
            break;
        l_56 ^= (l_55 , 1L);
        if (((g_30[2] || 4294967292UL) | g_2[0][7][0]))
        { /* block id: 45 */
            int32_t l_59 = 8L;
            g_2[8][6][2] = (safe_lshift_func_uint8_t_u_s(g_2[1][2][0], 5));
            l_56 = g_48[3][7];
            if (l_59)
                continue;
            l_56 = (((safe_mod_func_uint32_t_u_u((!0x324EF461L), 0xE3A94630L)) <= p_24) != l_59);
        }
        else
        { /* block id: 50 */
            return p_24;
        }
    }
    return l_54;
}


/* ------------------------------------------ */
/* 
 * reads : g_37 g_3
 * writes: g_37 g_4 g_30
 */
static int32_t  func_33(int8_t  p_34)
{ /* block id: 17 */
    int8_t l_43 = 0L;
    int32_t l_45 = 0x1B3E233DL;
    int32_t l_47 = 0L;
    for (p_34 = 2; (p_34 < (-8)); p_34 = safe_sub_func_uint8_t_u_u(p_34, 5))
    { /* block id: 20 */
        int32_t l_44 = 0x15ACA64AL;
        for (g_37 = 9; (g_37 == 26); ++g_37)
        { /* block id: 23 */
            g_4 = (-8L);
        }
        g_30[2] = g_3[1][0][3];
        if (p_34)
            continue;
        l_45 = (safe_unary_minus_func_uint8_t_u((safe_mod_func_int32_t_s_s((l_43 > l_44), l_43))));
    }
    l_47 &= (!l_45);
    return p_34;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_3[i][j][k], "g_3[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_30[i], "g_30[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_37, "g_37", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_48[i][j], "g_48[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_121.f0, "g_121.f0", print_hash_value);
    transparent_crc(g_121.f1.f0, "g_121.f1.f0", print_hash_value);
    transparent_crc(g_121.f1.f1, "g_121.f1.f1", print_hash_value);
    transparent_crc(g_121.f1.f2, "g_121.f1.f2", print_hash_value);
    transparent_crc(g_121.f1.f3, "g_121.f1.f3", print_hash_value);
    transparent_crc(g_121.f1.f4, "g_121.f1.f4", print_hash_value);
    transparent_crc(g_121.f1.f5, "g_121.f1.f5", print_hash_value);
    transparent_crc(g_121.f1.f6, "g_121.f1.f6", print_hash_value);
    transparent_crc(g_121.f2, "g_121.f2", print_hash_value);
    transparent_crc(g_121.f3, "g_121.f3", print_hash_value);
    transparent_crc(g_121.f4, "g_121.f4", print_hash_value);
    transparent_crc(g_121.f5, "g_121.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 2
breakdown:
   depth: 0, occurrence: 50
   depth: 1, occurrence: 0
   depth: 2, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 84
   depth: 2, occurrence: 25
   depth: 3, occurrence: 12
   depth: 4, occurrence: 8
   depth: 5, occurrence: 4
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 115
XXX times a non-volatile is write: 59
XXX times a volatile is read: 23
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 95
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 91
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 36
   depth: 2, occurrence: 38

XXX percentage a fresh-made variable is used: 26.4
XXX percentage an existing variable is used: 73.6
********************* end of statistics **********************/

