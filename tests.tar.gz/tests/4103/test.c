/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12774502207222259820
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   uint32_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint64_t g_2 = 0x8A1F94964A53AA9ALL;/* VOLATILE GLOBAL g_2 */
static volatile int32_t g_3[3] = {0L,0L,0L};
static uint32_t g_12 = 0x90515466L;
static volatile int64_t g_16 = (-6L);/* VOLATILE GLOBAL g_16 */
static int16_t g_21 = 0L;
static volatile uint8_t g_22[3] = {0xF3L,0xF3L,0xF3L};
static int64_t g_29 = 0L;
static volatile uint64_t g_32[3] = {8UL,8UL,8UL};
static int32_t g_41 = 0x9B2B2933L;
static uint32_t g_55 = 0xD6648539L;
static uint32_t g_56 = 0xA6F2DB44L;


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint16_t  func_4(uint16_t  p_5, uint8_t  p_6, const struct S0  p_7, int16_t  p_8, int16_t  p_9);
static const struct S0  func_45(uint32_t  p_46, int8_t  p_47, const uint8_t  p_48, int16_t  p_49);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_12 g_22 g_3 g_21 g_29 g_32 g_56
 * writes: g_3 g_22 g_29 g_32 g_41 g_55 g_56
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_11[9] = {18446744073709551607UL,9UL,18446744073709551607UL,18446744073709551607UL,9UL,18446744073709551607UL,18446744073709551607UL,9UL,18446744073709551607UL};
    const struct S0 l_13 = {18446744073709551615UL};
    struct S0 l_61[3] = {{0x35EE8DA5L},{0x35EE8DA5L},{0x35EE8DA5L}};
    int i;
    g_3[0] = g_2;
    if (((func_4((!((((((0x8B0D193EL == g_2) , l_11[0]) > g_12) , 0x657E3B6FL) , l_11[0]) & l_11[0])), l_11[0], l_13, g_12, g_12) , l_13.f0) , g_21))
    { /* block id: 19 */
        int8_t l_40 = 1L;
        g_41 = ((safe_add_func_int64_t_s_s(g_3[2], 0xDB5CF63547A0585CLL)) , l_40);
    }
    else
    { /* block id: 21 */
        uint8_t l_44 = 2UL;
        l_44 = (safe_mul_func_uint8_t_u_u(((9UL | g_22[0]) >= g_21), 0x62L));
        l_61[2] = func_45(l_13.f0, l_44, l_11[0], l_44);
    }
    return l_11[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_3 g_12
 * writes: g_22 g_29 g_32
 */
static uint16_t  func_4(uint16_t  p_5, uint8_t  p_6, const struct S0  p_7, int16_t  p_8, int16_t  p_9)
{ /* block id: 2 */
    int64_t l_14 = 0x270E7AD53A38D067LL;
    int32_t l_15 = (-3L);
    int32_t l_17 = 0L;
    int32_t l_18 = 0L;
    int32_t l_19 = 0xE177C422L;
    int32_t l_20 = (-8L);
    g_22[0]++;
    g_29 = ((safe_rshift_func_int8_t_s_u((safe_mul_func_int16_t_s_s(((p_5 == l_18) <= (-3L)), p_9)), 6)) ^ l_18);
    l_15 = (safe_rshift_func_int8_t_s_s(g_22[0], p_6));
    for (p_8 = 0; (p_8 <= 2); p_8 += 1)
    { /* block id: 8 */
        int8_t l_35 = 0x8DL;
        int32_t l_36 = (-1L);
        for (p_6 = 0; (p_6 <= 2); p_6 += 1)
        { /* block id: 11 */
            int32_t l_37[7];
            int i;
            for (i = 0; i < 7; i++)
                l_37[i] = 0xA9B22354L;
            g_32[2] = g_22[p_8];
            l_36 = ((safe_sub_func_uint8_t_u_u((0x35CF455DBFE6B87CLL == g_3[p_6]), p_8)) ^ l_35);
            if (g_12)
                continue;
            l_37[4] = (-1L);
        }
    }
    return l_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_29 g_32 g_56
 * writes: g_55 g_56
 */
static const struct S0  func_45(uint32_t  p_46, int8_t  p_47, const uint8_t  p_48, int16_t  p_49)
{ /* block id: 23 */
    int32_t l_54 = 0x642A2CA0L;
    const struct S0 l_60 = {0x153ED870L};
lbl_59:
    g_55 = (((+(~((safe_mod_func_int16_t_s_s((((-3L) == g_22[2]) ^ l_54), 5L)) , g_29))) != 6UL) && g_32[2]);
    g_56++;
    if (g_29)
        goto lbl_59;
    return l_60;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_29, "g_29", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_32[i], "g_32[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_56, "g_56", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 24
   depth: 1, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 14
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 3
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 14, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 31
XXX times a non-volatile is write: 11
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 23
XXX percentage of non-volatile access: 77.8

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 20
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 4
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 47.4
XXX percentage an existing variable is used: 52.6
********************* end of statistics **********************/

