/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6161759287519250087
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x13B91020L;
static int32_t g_5 = 0x7937D8E6L;
static int16_t g_29 = 0x3995L;
static int8_t g_35[2] = {0x75L,0x75L};
static uint64_t g_36 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static const int8_t  func_1(void);
static int32_t  func_10(int32_t  p_11, int32_t  p_12, const int16_t  p_13);
static int32_t  func_20(int64_t  p_21, int32_t  p_22, uint32_t  p_23, uint32_t  p_24);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_5 g_36 g_35 g_29
 * writes: g_2 g_5 g_29 g_35 g_36
 */
static const int8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_14 = (-1L);
    int32_t l_41 = 0xB1BEBA42L;
    for (g_2 = (-5); (g_2 != 9); ++g_2)
    { /* block id: 3 */
        uint8_t l_9 = 0xE1L;
        int32_t l_39[5] = {0L,0L,0L,0L,0L};
        int i;
        for (g_5 = 0; (g_5 <= (-26)); g_5 = safe_sub_func_int64_t_s_s(g_5, 8))
        { /* block id: 6 */
            int64_t l_8 = 4L;
            l_9 = (l_8 || g_5);
            l_39[0] = func_10(l_14, g_2, g_2);
            return g_2;
        }
    }
    g_5 |= (((!g_35[0]) ^ 0xA1FDL) | 18446744073709551615UL);
    l_41 |= g_29;
    return l_41;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_36
 * writes: g_29 g_35 g_36
 */
static int32_t  func_10(int32_t  p_11, int32_t  p_12, const int16_t  p_13)
{ /* block id: 8 */
    uint32_t l_15[1];
    int32_t l_19 = 0xDBF0CF86L;
    int i;
    for (i = 0; i < 1; i++)
        l_15[i] = 0x33880E03L;
    for (p_11 = 0; (p_11 <= 0); p_11 += 1)
    { /* block id: 11 */
        int i;
        if (((safe_mul_func_int8_t_s_s(0L, l_15[p_11])) <= p_12))
        { /* block id: 12 */
            int16_t l_18 = 0x39D9L;
            l_18 = 0x1A93826AL;
            l_19 |= l_15[p_11];
        }
        else
        { /* block id: 15 */
            g_29 = func_20(g_5, l_15[p_11], g_2, g_2);
            l_19 = (safe_mod_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_s((g_2 & l_15[p_11]), 3)) ^ 6UL), 0x81D3L));
        }
        g_35[0] = ((safe_unary_minus_func_int8_t_s(0x59L)) != g_5);
    }
    ++g_36;
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static int32_t  func_20(int64_t  p_21, int32_t  p_22, uint32_t  p_23, uint32_t  p_24)
{ /* block id: 16 */
    int32_t l_25 = 0x20859495L;
    int32_t l_26 = 0xF35DD758L;
    uint32_t l_27 = 0UL;
lbl_28:
    l_26 &= l_25;
    l_27 = (1UL <= g_2);
    if (g_2)
        goto lbl_28;
    return p_24;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_35[i], "g_35[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_36, "g_36", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 13
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 5
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 6
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 3
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 37.1
XXX percentage an existing variable is used: 62.9
********************* end of statistics **********************/

