/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1079343807176762433
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0xC6A53D06L;/* VOLATILE GLOBAL g_2 */
static int8_t g_23 = 0x11L;
static int8_t g_24 = 0L;
static volatile int16_t g_25 = 0L;/* VOLATILE GLOBAL g_25 */
static volatile uint16_t g_27[5] = {1UL,1UL,1UL,1UL,1UL};
static int32_t g_30 = 0L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_9(uint16_t  p_10, int16_t  p_11);
static int8_t  func_16(int16_t  p_17, uint8_t  p_18, int64_t  p_19, uint32_t  p_20, int32_t  p_21);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_23 g_27 g_30
 * writes: g_2 g_27 g_30
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_3[1];
    int32_t l_6 = (-1L);
    uint32_t l_31 = 0x92715EE5L;
    int i;
    for (i = 0; i < 1; i++)
        l_3[i] = 0xDF251D69L;
    l_3[0]--;
    l_6 = (g_2 , 0L);
    l_6 &= (safe_mul_func_int16_t_s_s(g_2, 0x2830L));
    g_30 |= func_9(l_3[0], g_2);
    return l_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_23 g_27
 * writes: g_2 g_27
 */
static int32_t  func_9(uint16_t  p_10, int16_t  p_11)
{ /* block id: 4 */
    int64_t l_12[1];
    int32_t l_13 = 0L;
    int32_t l_26 = (-9L);
    int i;
    for (i = 0; i < 1; i++)
        l_12[i] = (-3L);
    l_13 = l_12[0];
    l_13 = (safe_mul_func_int8_t_s_s(func_16((+0x8900L), g_2, l_12[0], l_12[0], g_23), 0x34L));
    g_27[1]++;
    return l_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes: g_2
 */
static int8_t  func_16(int16_t  p_17, uint8_t  p_18, int64_t  p_19, uint32_t  p_20, int32_t  p_21)
{ /* block id: 6 */
    g_2 = 0x33356370L;
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_27[i], "g_27[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_30, "g_30", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 7
XXX times a non-volatile is write: 6
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 10
XXX percentage of non-volatile access: 65

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 11
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 11

XXX percentage a fresh-made variable is used: 46.2
XXX percentage an existing variable is used: 53.8
********************* end of statistics **********************/

