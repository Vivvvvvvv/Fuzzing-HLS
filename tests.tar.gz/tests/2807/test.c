/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7401600638307687117
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x3FCB50BFL;
static uint32_t g_6[9] = {0x6B471DFDL,0x6B471DFDL,0x6B471DFDL,0x6B471DFDL,0x6B471DFDL,0x6B471DFDL,0x6B471DFDL,0x6B471DFDL,0x6B471DFDL};
static volatile uint16_t g_13 = 0x1AA0L;/* VOLATILE GLOBAL g_13 */
static int64_t g_18[2] = {0x1E283D1F0DFBC43CLL,0x1E283D1F0DFBC43CLL};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint32_t  func_4(uint16_t  p_5);
static uint8_t  func_7(int16_t  p_8, int16_t  p_9, uint16_t  p_10, int32_t  p_11, int32_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_13 g_18
 * writes: g_2 g_13 g_18
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_3 = 9UL;
    int32_t l_23 = 0x782ECC90L;
    uint32_t l_24 = 0x21692869L;
    g_2 = ((g_2 & 0xDA0E60F951FE77DDLL) , l_3);
    l_23 = (func_4(l_3) || l_3);
    return l_24;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_6 g_13 g_18
 * writes: g_2 g_13 g_18
 */
static uint32_t  func_4(uint16_t  p_5)
{ /* block id: 2 */
    int32_t l_19 = 0x878ED7C3L;
    int32_t l_22 = 6L;
    for (g_2 = 3; (g_2 <= 8); g_2 += 1)
    { /* block id: 5 */
        int i;
        if (g_6[g_2])
            break;
        g_18[1] = (func_7(p_5, g_6[g_2], p_5, g_6[g_2], g_6[6]) <= 0UL);
    }
    l_19 = (p_5 & g_6[0]);
    l_22 &= ((((safe_div_func_uint32_t_u_u((l_19 & 0UL), g_18[1])) >= p_5) > p_5) , g_18[1]);
    return l_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_2
 * writes: g_13
 */
static uint8_t  func_7(int16_t  p_8, int16_t  p_9, uint16_t  p_10, int32_t  p_11, int32_t  p_12)
{ /* block id: 7 */
    int32_t l_16 = (-5L);
    int32_t l_17 = 0x157736D0L;
    ++g_13;
    l_16 = p_12;
    l_17 ^= p_12;
    return g_2;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13, "g_13", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 2
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 96.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

