/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16357821193474978517
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_2[5][2][2] = {{{250UL,0x2EL},{0x2EL,250UL}},{{0x2EL,0x2EL},{250UL,0x2EL}},{{0x2EL,250UL},{0x2EL,0x2EL}},{{250UL,0x2EL},{0x2EL,250UL}},{{0x2EL,0x2EL},{250UL,0x2EL}}};
static volatile int32_t g_21 = (-1L);/* VOLATILE GLOBAL g_21 */
static int32_t g_22 = 0xB236728AL;
static int8_t g_41 = 0x4DL;
static int16_t g_61 = 0L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_9(uint16_t  p_10, int16_t  p_11, uint8_t  p_12, uint8_t  p_13, uint32_t  p_14);
static uint8_t  func_15(uint16_t  p_16);
static int32_t  func_17(uint32_t  p_18);
static int32_t  func_19(int32_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_22 g_21 g_41 g_61
 * writes: g_2 g_22 g_21 g_41
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_7[1][10][10] = {{{0xB6D0374CL,3UL,7UL,0x9F58382BL,3UL,0xBD42CA8CL,18446744073709551612UL,7UL,7UL,18446744073709551612UL},{0xBD42CA8CL,18446744073709551612UL,7UL,7UL,18446744073709551612UL,0xBD42CA8CL,3UL,0x9F58382BL,7UL,3UL},{0xB6D0374CL,18446744073709551612UL,0x6A715CC4L,0x9F58382BL,18446744073709551612UL,18446744073709551607UL,1UL,3UL,18446744073709551612UL,1UL},{0xE3B372BAL,0x223FA3A9L,18446744073709551615UL,3UL,0x223FA3A9L,0x8B5131D8L,1UL,18446744073709551615UL,18446744073709551615UL,1UL},{0x8B5131D8L,1UL,18446744073709551615UL,18446744073709551615UL,1UL,0x8B5131D8L,0x223FA3A9L,3UL,18446744073709551615UL,0x223FA3A9L},{0xE3B372BAL,1UL,18446744073709551612UL,3UL,1UL,0xA2AE7B79L,1UL,3UL,18446744073709551612UL,1UL},{0xE3B372BAL,0x223FA3A9L,18446744073709551615UL,3UL,0x223FA3A9L,0x8B5131D8L,1UL,18446744073709551615UL,18446744073709551615UL,1UL},{0x8B5131D8L,1UL,18446744073709551615UL,18446744073709551615UL,1UL,0x8B5131D8L,0x223FA3A9L,3UL,18446744073709551615UL,0x223FA3A9L},{0xE3B372BAL,1UL,18446744073709551612UL,3UL,1UL,0xA2AE7B79L,1UL,3UL,18446744073709551612UL,1UL},{0xE3B372BAL,0x223FA3A9L,18446744073709551615UL,3UL,0x223FA3A9L,0x8B5131D8L,1UL,18446744073709551615UL,18446744073709551615UL,1UL}}};
    int32_t l_8 = 0xA2B82C44L;
    uint32_t l_47 = 0x96EA311AL;
    uint32_t l_55 = 0UL;
    int i, j, k;
    g_2[3][0][1]++;
    if (((safe_lshift_func_uint8_t_u_u((0xCB4C23AFL <= g_2[3][0][1]), 0)) ^ l_7[0][5][8]))
    { /* block id: 2 */
        int32_t l_42 = 0x8C0996BDL;
        l_8 = l_7[0][5][5];
        if (func_9(((func_15(l_7[0][5][8]) || g_21) | 0x09F1L), l_8, g_2[3][0][1], g_2[3][0][1], l_42))
        { /* block id: 30 */
            return l_42;
        }
        else
        { /* block id: 32 */
            l_42 |= (safe_mod_func_int8_t_s_s(g_22, g_22));
            return l_47;
        }
    }
    else
    { /* block id: 36 */
        uint64_t l_50 = 0x5992778613AB5F77LL;
        for (g_41 = 0; (g_41 == 7); ++g_41)
        { /* block id: 39 */
            ++l_50;
            g_22 = g_41;
            g_22 = 0x544848B2L;
        }
        for (l_8 = 29; (l_8 == (-9)); --l_8)
        { /* block id: 46 */
            int64_t l_60 = (-1L);
            l_55++;
            g_22 = ((safe_add_func_int32_t_s_s(((l_7[0][5][8] && l_60) <= 0x9122L), l_7[0][5][8])) | 8L);
        }
    }
    return g_61;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_9(uint16_t  p_10, int16_t  p_11, uint8_t  p_12, uint8_t  p_13, uint32_t  p_14)
{ /* block id: 27 */
    uint32_t l_43[3][8][8] = {{{0UL,0xA7A40015L,4294967295UL,4294967295UL,1UL,8UL,4294967295UL,1UL},{4294967295UL,4294967295UL,0x8491658DL,4294967295UL,4294967295UL,8UL,4294967295UL,0UL},{1UL,0xA7A40015L,1UL,0x5CA1D1A2L,4294967295UL,1UL,4294967295UL,0x5CA1D1A2L},{0UL,0x2DEFE8EBL,0x8491658DL,4294967295UL,0x5CA1D1A2L,4294967295UL,4294967295UL,0x5CA1D1A2L},{0x5CA1D1A2L,4294967295UL,4294967295UL,0x5CA1D1A2L,4294967295UL,0x8491658DL,0x2DEFE8EBL,0UL},{0x5CA1D1A2L,4294967295UL,1UL,4294967295UL,0x5CA1D1A2L,1UL,0xA7A40015L,1UL},{0UL,4294967295UL,8UL,4294967295UL,4294967295UL,0x8491658DL,4294967295UL,4294967295UL},{1UL,4294967295UL,8UL,1UL,4294967295UL,4294967295UL,0xA7A40015L,0UL}},{{4294967295UL,0x2DEFE8EBL,1UL,1UL,1UL,1UL,0x2DEFE8EBL,4294967295UL},{0UL,0xA7A40015L,4294967295UL,4294967295UL,1UL,8UL,4294967295UL,1UL},{4294967295UL,4294967295UL,0x8491658DL,4294967295UL,4294967295UL,8UL,4294967295UL,0UL},{1UL,0xA7A40015L,1UL,0x5CA1D1A2L,4294967295UL,1UL,4294967295UL,0x5CA1D1A2L},{0UL,0x2DEFE8EBL,0x8491658DL,4294967295UL,0x5CA1D1A2L,4294967295UL,4294967295UL,0x5CA1D1A2L},{0x5CA1D1A2L,4294967295UL,4294967295UL,0x5CA1D1A2L,4294967295UL,0x8491658DL,0x2DEFE8EBL,0UL},{0x5CA1D1A2L,4294967295UL,1UL,4294967295UL,0x5CA1D1A2L,0xA7A40015L,0x8491658DL,0UL},{4UL,8UL,0UL,0x47AD075FL,4294967295UL,0UL,1UL,4294967295UL}},{{0UL,1UL,0UL,0UL,0x47AD075FL,1UL,0x8491658DL,4UL},{4294967295UL,4294967295UL,0xA7A40015L,0UL,0UL,0xA7A40015L,4294967295UL,4294967295UL},{4UL,0x8491658DL,1UL,0x47AD075FL,0UL,0UL,1UL,0UL},{4294967295UL,1UL,0UL,4294967295UL,0x47AD075FL,0UL,8UL,4UL},{0UL,0x8491658DL,0xA7A40015L,0xF2F7BD12L,4294967295UL,0xA7A40015L,8UL,0xF2F7BD12L},{4UL,4294967295UL,0UL,0x47AD075FL,0xF2F7BD12L,1UL,1UL,0xF2F7BD12L},{0xF2F7BD12L,1UL,1UL,0xF2F7BD12L,0x47AD075FL,0UL,4294967295UL,4UL},{0xF2F7BD12L,8UL,0xA7A40015L,4294967295UL,0xF2F7BD12L,0xA7A40015L,0x8491658DL,0UL}}};
    int32_t l_44 = 0L;
    int i, j, k;
    l_44 = l_43[0][6][7];
    return l_43[0][6][7];
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_22 g_21 g_41
 * writes: g_22 g_21 g_41
 */
static uint8_t  func_15(uint16_t  p_16)
{ /* block id: 4 */
    g_41 ^= func_17(g_2[3][0][1]);
    return g_41;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_21 g_2
 * writes: g_22 g_21
 */
static int32_t  func_17(uint32_t  p_18)
{ /* block id: 5 */
    uint32_t l_40 = 18446744073709551615UL;
    l_40 = func_19((p_18 == p_18));
    return l_40;
}


/* ------------------------------------------ */
/* 
 * reads : g_22 g_21 g_2
 * writes: g_22 g_21
 */
static int32_t  func_19(int32_t  p_20)
{ /* block id: 6 */
    int8_t l_28 = 2L;
    int32_t l_36 = 0x309E69C1L;
    for (p_20 = 0; (p_20 <= 1); p_20 += 1)
    { /* block id: 9 */
        uint8_t l_27 = 7UL;
        int32_t l_39 = 0x575E7E8EL;
        if (p_20)
            break;
        for (g_22 = 1; (g_22 >= 0); g_22 -= 1)
        { /* block id: 13 */
            if (p_20)
                break;
            l_28 = (safe_mod_func_int16_t_s_s((((safe_mul_func_int8_t_s_s(((p_20 && 0x0D40A7FCL) , l_27), 255UL)) , (-1L)) && g_22), 2L));
            l_36 = ((((((safe_mul_func_int16_t_s_s((safe_div_func_int16_t_s_s(((((~((safe_rshift_func_int8_t_s_u(g_21, 3)) , g_2[3][0][1])) > l_28) & p_20) ^ 0x46L), 0xDAD2L)), 65532UL)) != l_27) && g_22) && p_20) >= p_20) >= 0x188A746CL);
            l_39 = ((((safe_lshift_func_uint16_t_u_u(((((p_20 < p_20) < p_20) >= 0xBBL) || p_20), 7)) & 0xAFL) & (-5L)) , g_22);
        }
    }
    g_21 = ((((((((-1L) || l_28) != l_28) , l_36) != l_28) , p_20) < l_36) , p_20);
    l_36 = g_22;
    return l_36;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_41, "g_41", print_hash_value);
    transparent_crc(g_61, "g_61", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 33
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 2
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 54
XXX times a non-volatile is write: 19
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 19
XXX percentage of non-volatile access: 96.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 31
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 6
   depth: 2, occurrence: 12

XXX percentage a fresh-made variable is used: 24.6
XXX percentage an existing variable is used: 75.4
********************* end of statistics **********************/

