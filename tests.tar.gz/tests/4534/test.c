/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12954020853794896388
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_8 = 0x83L;
static volatile int8_t g_22 = 0x8BL;/* VOLATILE GLOBAL g_22 */
static uint8_t g_31 = 1UL;
static uint64_t g_39 = 0x7511ECBFCF419C2BLL;
static int16_t g_40[9] = {0L,0L,0L,0L,0L,0L,0L,0L,0L};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_2(int32_t  p_3, int64_t  p_4, uint64_t  p_5, const int8_t  p_6, const uint16_t  p_7);
static int32_t  func_10(int8_t  p_11, int8_t  p_12, int8_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_31 g_39 g_40
 * writes: g_8 g_31 g_40
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_9 = 18446744073709551610UL;
    int32_t l_32 = (-8L);
    l_32 = func_2(g_8, l_9, g_8, l_9, g_8);
    g_40[1] |= (safe_add_func_uint64_t_u_u((((safe_lshift_func_uint8_t_u_s((safe_add_func_uint32_t_u_u(((l_32 || g_31) <= g_39), l_9)), 3)) != l_32) ^ g_8), 0xD55ADB51FD9AB8A8LL));
    l_32 = 1L;
    return g_8;
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_31
 * writes: g_8 g_31
 */
static int32_t  func_2(int32_t  p_3, int64_t  p_4, uint64_t  p_5, const int8_t  p_6, const uint16_t  p_7)
{ /* block id: 1 */
    int16_t l_16[8];
    uint16_t l_17[2];
    int i;
    for (i = 0; i < 8; i++)
        l_16[i] = 0xAEE5L;
    for (i = 0; i < 2; i++)
        l_17[i] = 1UL;
    g_31 &= func_10(((safe_lshift_func_uint8_t_u_u(((((p_5 , p_3) > 0x12265E3EL) >= 255UL) != l_16[6]), p_3)) , 0xE0L), g_8, l_17[0]);
    return l_17[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_8
 * writes: g_8
 */
static int32_t  func_10(int8_t  p_11, int8_t  p_12, int8_t  p_13)
{ /* block id: 2 */
    int64_t l_20 = 0L;
    int32_t l_23 = 0L;
    uint64_t l_24 = 4UL;
    for (g_8 = 0; (g_8 >= 14); g_8++)
    { /* block id: 5 */
        int64_t l_21 = 0xB821342F3D47941CLL;
        l_21 &= l_20;
        if (p_13)
            break;
    }
    l_24--;
    for (p_13 = 0; (p_13 > (-27)); p_13--)
    { /* block id: 12 */
        uint8_t l_29 = 0x85L;
        int32_t l_30 = 4L;
        l_30 = l_29;
        return l_30;
    }
    return l_20;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_40[i], "g_40[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 16
   depth: 2, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 26
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 6
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 4

XXX percentage a fresh-made variable is used: 45.5
XXX percentage an existing variable is used: 54.5
********************* end of statistics **********************/

