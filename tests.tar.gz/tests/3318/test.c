/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1266856945130412260
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_12 = (-4L);
static int8_t g_19 = (-1L);
static int8_t g_32 = (-5L);
static uint32_t g_34 = 0x89405DBDL;


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);
static int32_t  func_2(const uint32_t  p_3, int32_t  p_4, int16_t  p_5);
static int8_t  func_7(int32_t  p_8, const uint16_t  p_9, int32_t  p_10, int8_t  p_11);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_19 g_34 g_32
 * writes: g_19 g_34 g_12
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_13[6] = {0xDBC3707822E6E7F7LL,0xDBC3707822E6E7F7LL,0xDBC3707822E6E7F7LL,0xDBC3707822E6E7F7LL,0xDBC3707822E6E7F7LL,0xDBC3707822E6E7F7LL};
    uint16_t l_46 = 0x50A0L;
    int i;
    l_46 ^= func_2((~func_7(g_12, g_12, g_12, l_13[1])), l_13[1], l_13[1]);
    g_12 = (safe_lshift_func_uint8_t_u_s(g_32, g_32));
    g_12 = g_19;
    return g_32;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_34 g_12 g_32
 * writes: g_34
 */
static int32_t  func_2(const uint32_t  p_3, int32_t  p_4, int16_t  p_5)
{ /* block id: 5 */
    int32_t l_26 = 8L;
    int32_t l_27 = 8L;
    int32_t l_28 = 3L;
    int32_t l_29[7] = {0xC9BA5B04L,0xC9BA5B04L,0xC9BA5B04L,0xC9BA5B04L,0xC9BA5B04L,0xC9BA5B04L,0xC9BA5B04L};
    int i;
lbl_39:
    l_28 = (safe_div_func_uint32_t_u_u((((safe_add_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u(l_26, l_26)) <= 1L), p_3)) , p_3) | l_27), g_19));
    for (l_27 = 4; (l_27 >= 0); l_27 -= 1)
    { /* block id: 9 */
        int32_t l_31 = 0xBFCF419CL;
        int i;
        if (l_29[(l_27 + 1)])
        { /* block id: 10 */
            int8_t l_30 = (-1L);
            int32_t l_33 = (-1L);
            g_34++;
        }
        else
        { /* block id: 12 */
            l_28 ^= (safe_sub_func_int64_t_s_s((0UL && 1L), 18446744073709551614UL));
            if (g_12)
                break;
            if (p_5)
                continue;
        }
        for (g_34 = 0; (g_34 <= 6); g_34 += 1)
        { /* block id: 19 */
            int64_t l_40[2];
            int i;
            for (i = 0; i < 2; i++)
                l_40[i] = 0x66593C394A737B78LL;
            if (p_4)
                break;
            if (p_5)
                goto lbl_39;
            l_31 &= l_40[1];
        }
        l_31 = ((safe_sub_func_int64_t_s_s((((safe_lshift_func_uint16_t_u_s((((g_34 <= p_5) & l_31) && l_31), p_5)) || l_28) & g_19), g_34)) , g_19);
        l_28 = ((((~(0xAEE481DBL == g_19)) > (-7L)) , g_19) <= g_32);
    }
    return p_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_19
 * writes: g_19
 */
static int8_t  func_7(int32_t  p_8, const uint16_t  p_9, int32_t  p_10, int8_t  p_11)
{ /* block id: 1 */
    int8_t l_17 = 0x1EL;
    const int64_t l_18 = 0x76AB2AEE5A9864BALL;
    g_19 &= (((((((!l_17) , l_18) >= p_10) < 0x980DB959L) ^ 0UL) & g_12) && 0xB5L);
    p_10 &= (g_12 && g_12);
    return l_18;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 22
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 43
XXX times a non-volatile is write: 13
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 21
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 4
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 26.3
XXX percentage an existing variable is used: 73.7
********************* end of statistics **********************/

