/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7349834461351397361
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_16 = 1L;
static volatile int8_t g_21 = 1L;/* VOLATILE GLOBAL g_21 */
static int64_t g_28[1][6] = {{0x94D0E834AB462A77LL,0x94D0E834AB462A77LL,0x94D0E834AB462A77LL,0x94D0E834AB462A77LL,0x94D0E834AB462A77LL,0x94D0E834AB462A77LL}};
static volatile uint32_t g_41[1][6][7] = {{{0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L},{0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L},{0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L},{0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L},{0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L},{0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L,0x0D978029L}}};
static uint32_t g_67[7] = {0UL,0x5AD8EDCEL,0UL,0UL,0x5AD8EDCEL,0UL,0UL};
static uint32_t g_71[1] = {0xA8726ABEL};
static volatile int32_t g_72 = (-3L);/* VOLATILE GLOBAL g_72 */
static volatile int64_t g_82 = 0x591F806EB766298ALL;/* VOLATILE GLOBAL g_82 */
static uint8_t g_85 = 0xF6L;
static int32_t g_127 = 9L;
static int64_t g_130 = 0x7220935DC34743BDLL;
static uint64_t g_133[6][3] = {{0x08AEA66F312D9EA3LL,0xA393D43457D5AD65LL,0x0DC829B9F5A9ACF3LL},{0x47BAF77F40A761EALL,0xA393D43457D5AD65LL,18446744073709551607UL},{6UL,0xA393D43457D5AD65LL,0xA393D43457D5AD65LL},{0x08AEA66F312D9EA3LL,0xA393D43457D5AD65LL,0x0DC829B9F5A9ACF3LL},{0x47BAF77F40A761EALL,0xA393D43457D5AD65LL,18446744073709551607UL},{6UL,0xA393D43457D5AD65LL,0xA393D43457D5AD65LL}};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const uint64_t  func_8(uint64_t  p_9, uint16_t  p_10, uint8_t  p_11, uint32_t  p_12, int8_t  p_13);
static int64_t  func_14(int16_t  p_15);
static int32_t  func_29(uint64_t  p_30, int64_t  p_31);
static int16_t  func_44(int8_t  p_45, uint64_t  p_46);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_16 g_21 g_41 g_67 g_72 g_28 g_85 g_71 g_127 g_130 g_133 g_82
 * writes: g_16 g_21 g_28 g_41 g_67 g_71 g_72 g_85 g_127 g_133
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    const int8_t l_4[7] = {(-6L),0L,0L,(-6L),0L,0L,(-6L)};
    int32_t l_5 = 0x390197F0L;
    int32_t l_6[3][4];
    int32_t l_136[6][2][9] = {{{(-8L),0xBC00A24DL,0L,0xE95E56FBL,0L,0xBC00A24DL,(-8L),(-8L),0xBC00A24DL},{0x2BCF3F1EL,0xE10E1137L,4L,0xE10E1137L,0x2BCF3F1EL,1L,1L,0x2BCF3F1EL,0xE10E1137L}},{{(-8L),0L,(-8L),(-6L),1L,1L,(-6L),(-8L),0L},{0x9C2F3C20L,3L,1L,4L,4L,1L,3L,0x9C2F3C20L,3L}},{{0xBC00A24DL,0xE95E56FBL,(-6L),(-6L),0xE95E56FBL,0xBC00A24DL,1L,0xBC00A24DL,0xE95E56FBL},{0xE10E1137L,3L,3L,0xE10E1137L,0x9C2F3C20L,0x2BCF3F1EL,0x9C2F3C20L,0xE10E1137L,3L}},{{0L,0L,1L,0xE95E56FBL,0x1F4E4257L,0xE95E56FBL,1L,0L,0L},{3L,0xE10E1137L,0x9C2F3C20L,0x2BCF3F1EL,0x9C2F3C20L,0xE10E1137L,3L,3L,0xE10E1137L}},{{0xE95E56FBL,0xBC00A24DL,1L,0xBC00A24DL,0xE95E56FBL,(-6L),(-6L),0xE95E56FBL,0xBC00A24DL},{3L,0x9C2F3C20L,3L,1L,4L,4L,1L,3L,0x9C2F3C20L}},{{0L,(-8L),(-6L),1L,1L,(-6L),(-8L),0L,(-8L)},{0xE10E1137L,0x2BCF3F1EL,1L,1L,0x2BCF3F1EL,0xE10E1137L,4L,0xE10E1137L,0x2BCF3F1EL}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
            l_6[i][j] = 0x438BEA12L;
    }
    l_5 &= (safe_mod_func_uint8_t_u_u(255UL, l_4[3]));
    for (l_5 = 0; (l_5 <= 2); l_5 += 1)
    { /* block id: 4 */
        uint16_t l_129 = 0UL;
        int32_t l_131 = (-9L);
        int32_t l_132[4];
        int i;
        for (i = 0; i < 4; i++)
            l_132[i] = 0x49D4ABAFL;
        l_131 = (((((safe_unary_minus_func_uint64_t_u(func_8(((func_14(g_16) != (-10L)) , l_4[3]), l_129, l_129, g_130, g_130))) , g_16) > 0UL) ^ 65535UL) | g_130);
        for (l_131 = 2; (l_131 >= 0); l_131 -= 1)
        { /* block id: 101 */
            int i, j;
            g_133[5][0]--;
            g_127 = ((l_6[l_131][l_5] <= 0x2DCD109CL) <= l_129);
            return g_41[0][0][2];
        }
        l_136[2][1][7] = (g_72 < 0x40E8EEE9L);
    }
    l_136[2][1][7] = (safe_add_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((safe_rshift_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(0UL, l_136[3][0][6])) || 0x13L), g_85)), 3L)), 0x05CCL));
    l_136[5][0][5] = ((safe_add_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(l_136[2][1][7], g_28[0][1])), l_136[2][1][7])) <= 0xAA6BL);
    return g_82;
}


/* ------------------------------------------ */
/* 
 * reads : g_71
 * writes:
 */
static const uint64_t  func_8(uint64_t  p_9, uint16_t  p_10, uint8_t  p_11, uint32_t  p_12, int8_t  p_13)
{ /* block id: 96 */
    return g_71[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_21 g_41 g_67 g_72 g_28 g_85 g_71 g_127
 * writes: g_16 g_21 g_28 g_41 g_67 g_71 g_72 g_85 g_127
 */
static int64_t  func_14(int16_t  p_15)
{ /* block id: 5 */
    uint32_t l_17 = 1UL;
    int32_t l_107 = (-10L);
lbl_128:
    if (l_17)
    { /* block id: 6 */
        uint8_t l_20 = 255UL;
        int32_t l_106 = 1L;
        for (g_16 = 0; (g_16 <= 22); g_16 = safe_add_func_int8_t_s_s(g_16, 7))
        { /* block id: 9 */
            if (p_15)
                break;
            if (l_20)
                continue;
            g_21 &= 0L;
            if (g_16)
                break;
        }
        if ((((safe_lshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u((((safe_lshift_func_uint8_t_u_u(((g_21 == g_16) | 18446744073709551615UL), p_15)) , g_16) < p_15), p_15)), 9)) ^ l_20) , 0L))
        { /* block id: 15 */
            uint32_t l_108 = 0UL;
            g_28[0][1] = (-7L);
            l_106 ^= func_29(p_15, l_17);
            ++l_108;
            l_106 = (l_106 , g_85);
        }
        else
        { /* block id: 78 */
            g_72 = ((safe_lshift_func_int16_t_s_s(p_15, p_15)) , g_28[0][1]);
            g_72 = (safe_add_func_uint64_t_u_u(5UL, g_67[4]));
        }
        for (p_15 = 0; p_15 < 1; p_15 += 1)
        {
            for (g_72 = 0; g_72 < 6; g_72 += 1)
            {
                for (l_107 = 0; l_107 < 7; l_107 += 1)
                {
                    g_41[p_15][g_72][l_107] = 0x2DF22AE8L;
                }
            }
        }
        if (p_15)
        { /* block id: 83 */
            l_107 = ((safe_rshift_func_uint16_t_u_s((((safe_mul_func_uint8_t_u_u((safe_mul_func_int16_t_s_s(g_28[0][4], 0xD57BL)), l_106)) <= 65535UL) , p_15), l_17)) <= (-10L));
            g_72 = 0x7FB9E8BDL;
            l_106 = (safe_div_func_uint32_t_u_u((p_15 && l_17), 7UL));
        }
        else
        { /* block id: 87 */
            uint8_t l_123 = 0x66L;
            l_123 ^= g_71[0];
        }
    }
    else
    { /* block id: 90 */
        g_127 ^= ((!((safe_lshift_func_uint16_t_u_u((l_107 < p_15), g_16)) ^ g_41[0][0][2])) < p_15);
        if (g_127)
            goto lbl_128;
        l_107 = 1L;
    }
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_41 g_16 g_67 g_72 g_28 g_85
 * writes: g_41 g_67 g_16 g_71 g_72 g_85
 */
static int32_t  func_29(uint64_t  p_30, int64_t  p_31)
{ /* block id: 17 */
    const int64_t l_34 = 0x6E3268DD2AC30BCALL;
    int32_t l_38 = 0x6DCFF2FDL;
    int8_t l_39 = 0xFBL;
    for (p_30 = 0; (p_30 != 37); p_30 = safe_add_func_uint16_t_u_u(p_30, 1))
    { /* block id: 20 */
        if (l_34)
            break;
    }
    for (p_31 = 0; (p_31 == 2); p_31 = safe_add_func_uint16_t_u_u(p_31, 1))
    { /* block id: 25 */
        int32_t l_37 = (-1L);
        int32_t l_40 = (-3L);
        ++g_41[0][0][2];
        l_38 = ((func_44(p_31, p_31) == g_28[0][1]) < p_31);
        l_38 = (safe_lshift_func_int16_t_s_s((((safe_add_func_uint16_t_u_u((0x463C3EAA4BB8C655LL || 1UL), p_31)) == l_38) || 0x16D00E5BD8EBBB00LL), 1));
        if ((safe_div_func_int64_t_s_s((safe_rshift_func_int8_t_s_u(((safe_sub_func_int64_t_s_s(((safe_div_func_uint8_t_u_u(((g_41[0][0][2] | p_31) > l_38), 0xA2L)) || 0x39D0E3EEL), l_37)) , 0x19L), g_16)), g_67[5])))
        { /* block id: 68 */
            g_72 = 0xC47384F1L;
        }
        else
        { /* block id: 70 */
            return p_31;
        }
    }
    return l_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_67 g_72 g_28 g_41 g_85
 * writes: g_67 g_16 g_71 g_72 g_85
 */
static int16_t  func_44(int8_t  p_45, uint64_t  p_46)
{ /* block id: 27 */
    uint32_t l_56 = 18446744073709551608UL;
    int32_t l_57 = 0x6E8D2CA8L;
    int32_t l_83 = 0x9E278474L;
    int32_t l_84[2][8][8] = {{{(-8L),(-1L),0L,0x094D0414L,0x094D0414L,0L,(-1L),(-8L)},{0x094D0414L,0L,(-1L),(-8L),0x781FA89BL,0xE88CDAF7L,0x358B4D46L,(-1L)},{(-1L),0x4896031DL,0x89CFDD8CL,0x358B4D46L,(-8L),0xE88CDAF7L,1L,0x74354AF3L},{0xE88CDAF7L,0L,0x0CC824F9L,1L,0x0CC824F9L,0L,0xE88CDAF7L,(-6L)},{0x74354AF3L,(-1L),(-3L),0xB72BA733L,1L,0x817EA5CAL,0x89CFDD8CL,0x781FA89BL},{7L,0x89CFDD8CL,0xB72BA733L,(-1L),1L,0x094D0414L,1L,1L},{0x781FA89BL,0x4896031DL,(-6L),(-6L),0x4896031DL,0x781FA89BL,0x74354AF3L,(-3L)},{5L,0x89CFDD8CL,(-3L),0x358B4D46L,(-1L),0xB72BA733L,0x3862D450L,0L}},{{0x094D0414L,(-8L),0x74354AF3L,0x358B4D46L,(-6L),(-3L),(-1L),(-3L)},{7L,(-6L),0x98492E76L,(-6L),7L,0x0CC824F9L,(-1L),0x817EA5CAL},{(-1L),(-3L),0xB72BA733L,1L,0x817EA5CAL,0x89CFDD8CL,0x781FA89BL,(-6L)},{0x98492E76L,0x74354AF3L,0xB72BA733L,(-8L),0xB1CB69ACL,(-1L),(-1L),0xB1CB69ACL},{0x817EA5CAL,0x98492E76L,0x98492E76L,0x817EA5CAL,0x358B4D46L,0L,(-1L),0x781FA89BL},{(-8L),0xB72BA733L,0x74354AF3L,0x98492E76L,0L,0x4896031DL,0x3862D450L,1L},{1L,0xB72BA733L,(-3L),(-1L),0x74354AF3L,0L,0x74354AF3L,(-1L)},{(-6L),0x98492E76L,(-6L),7L,0x0CC824F9L,(-1L),0x817EA5CAL,0x74354AF3L}}};
    int i, j, k;
    l_57 = (safe_mod_func_int8_t_s_s((safe_add_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u((+255UL), 0)), l_56)), 18446744073709551611UL)), 0xADL));
    if ((safe_mul_func_uint8_t_u_u((safe_sub_func_int8_t_s_s(g_16, 0xA6L)), p_45)))
    { /* block id: 29 */
        int32_t l_66 = 0L;
        int32_t l_78 = 1L;
        for (l_56 = 0; (l_56 < 6); ++l_56)
        { /* block id: 32 */
            return l_56;
        }
        for (p_45 = 0; (p_45 <= 0); p_45 += 1)
        { /* block id: 37 */
            uint16_t l_68 = 1UL;
            g_67[3] |= ((((((safe_sub_func_uint64_t_u_u(1UL, l_66)) == p_46) | (-1L)) && l_57) < l_66) & p_45);
            l_68 &= g_67[0];
        }
        for (g_16 = 11; (g_16 <= 16); g_16 = safe_add_func_int16_t_s_s(g_16, 1))
        { /* block id: 43 */
            int32_t l_75 = 0L;
            g_71[0] = (0x8FF5L ^ 0x4A39L);
            g_72 ^= 1L;
            g_72 &= (safe_mod_func_int8_t_s_s((l_75 | g_28[0][1]), g_28[0][1]));
        }
        l_78 ^= (((safe_mod_func_uint16_t_u_u(0xBB39L, 3L)) , (-1L)) , 0x9B76FC49L);
    }
    else
    { /* block id: 49 */
        uint8_t l_79 = 0x62L;
        int32_t l_80 = 5L;
        int32_t l_81 = 0x012CFB79L;
        if (((((18446744073709551611UL | g_41[0][1][0]) < 0x28A5L) , 0xE902BA9AL) != 0xB00F59FBL))
        { /* block id: 50 */
            l_79 |= 0x484183AAL;
            g_85--;
        }
        else
        { /* block id: 53 */
            int32_t l_88[6][4][3] = {{{6L,0x9F347F2DL,(-4L)},{0xCDC4137EL,0x9F347F2DL,(-1L)},{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL},{6L,0x9F347F2DL,(-4L)}},{{0xCDC4137EL,0x9F347F2DL,(-1L)},{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL},{6L,0x9F347F2DL,(-4L)},{0xCDC4137EL,0x9F347F2DL,(-1L)}},{{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL},{6L,0x9F347F2DL,(-4L)},{0xCDC4137EL,0x9F347F2DL,(-1L)},{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL}},{{6L,0x9F347F2DL,(-4L)},{0xCDC4137EL,0x9F347F2DL,(-1L)},{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL},{6L,0x9F347F2DL,(-4L)}},{{0xCDC4137EL,0x9F347F2DL,(-1L)},{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL},{6L,0x9F347F2DL,(-4L)},{0xCDC4137EL,0x9F347F2DL,(-1L)}},{{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL},{6L,0x9F347F2DL,(-4L)},{0xCDC4137EL,0x9F347F2DL,(-1L)},{0xD2431EA7L,0x9F347F2DL,0x9F347F2DL}}};
            int i, j, k;
            g_72 = (l_88[3][3][0] != 4294967294UL);
            return l_79;
        }
        l_81 = (safe_add_func_int32_t_s_s((65535UL & g_16), 1UL));
        l_81 ^= (((g_67[3] < 255UL) > g_41[0][2][1]) > l_80);
        for (l_83 = 0; (l_83 != 17); l_83++)
        { /* block id: 61 */
            int32_t l_93 = 1L;
            return l_93;
        }
    }
    return g_41[0][1][5];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_28[i][j], "g_28[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_41[i][j][k], "g_41[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_67[i], "g_67[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_71[i], "g_71[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_130, "g_130", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_133[i][j], "g_133[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 42
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 13
breakdown:
   depth: 1, occurrence: 67
   depth: 2, occurrence: 15
   depth: 3, occurrence: 7
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 90
XXX times a non-volatile is write: 36
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 9
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 56
XXX percentage of non-volatile access: 87.5

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 67
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 23
   depth: 2, occurrence: 30

XXX percentage a fresh-made variable is used: 30
XXX percentage an existing variable is used: 70
********************* end of statistics **********************/

