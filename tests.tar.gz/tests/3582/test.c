/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      4754940526134511401
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint16_t g_3 = 1UL;/* VOLATILE GLOBAL g_3 */
static int64_t g_18 = 0x31FADACD7D393E75LL;
static int64_t g_23 = 1L;
static uint32_t g_27 = 4294967286UL;
static volatile uint32_t g_30[9] = {0x29A275FFL,0x29A275FFL,0x29A275FFL,0x29A275FFL,0x29A275FFL,0x29A275FFL,0x29A275FFL,0x29A275FFL,0x29A275FFL};
static int32_t g_50 = 1L;
static volatile uint64_t g_69[6] = {5UL,0xA8A623B0D726993CLL,5UL,5UL,0xA8A623B0D726993CLL,5UL};
static volatile uint32_t g_72 = 0xCB4EA996L;/* VOLATILE GLOBAL g_72 */
static uint32_t g_76 = 7UL;
static int32_t g_89 = 0xB8FA7600L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static const int32_t  func_6(const uint32_t  p_7);
static int8_t  func_10(uint64_t  p_11, int32_t  p_12, int32_t  p_13, const uint8_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_18 g_27 g_30 g_23 g_50 g_69 g_72 g_76
 * writes: g_3 g_23 g_27 g_30 g_50 g_69 g_72 g_76 g_89
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = 0L;
    uint32_t l_95 = 0xB341928BL;
    int32_t l_96 = 0x66D8DA35L;
    ++g_3;
    if (((0xCEL <= 0xBFL) , 0x53BC6E5CL))
    { /* block id: 2 */
        uint32_t l_92 = 0UL;
        g_89 = (func_6(g_3) , g_50);
        g_89 = (safe_lshift_func_uint8_t_u_u(l_2, l_92));
        g_89 = (0x6EL | g_72);
        g_50 = (safe_sub_func_uint16_t_u_u(l_2, l_2));
    }
    else
    { /* block id: 49 */
        g_89 = 0xBC7639B4L;
        return l_2;
    }
    l_96 = l_95;
    g_50 = 3L;
    return g_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_18 g_27 g_30 g_23 g_50 g_69 g_72 g_76
 * writes: g_23 g_27 g_30 g_50 g_69 g_72 g_76
 */
static const int32_t  func_6(const uint32_t  p_7)
{ /* block id: 3 */
    uint16_t l_17 = 3UL;
    int32_t l_64 = 0xD053A657L;
    int32_t l_65 = 0L;
    int32_t l_67 = 0x56A74AB7L;
    int8_t l_84 = 0x35L;
    if ((safe_mul_func_int8_t_s_s(func_10((safe_mul_func_int8_t_s_s(((((l_17 , 0x9BL) != p_7) , l_17) == g_3), 0L)), p_7, g_18, l_17), l_17)))
    { /* block id: 7 */
        int8_t l_26 = (-1L);
        int32_t l_52[2];
        int32_t l_56 = 1L;
        int8_t l_66 = (-7L);
        int32_t l_68[4] = {9L,9L,9L,9L};
        int i;
        for (i = 0; i < 2; i++)
            l_52[i] = (-1L);
        if ((safe_lshift_func_int16_t_s_s(g_18, g_3)))
        { /* block id: 8 */
            int8_t l_35 = 0x4FL;
            g_27++;
            g_30[1]--;
            l_35 = ((safe_rshift_func_int16_t_s_u(0L, 1)) & 0xFAFBF261718BC698LL);
            g_50 = (((safe_div_func_int16_t_s_s(((safe_unary_minus_func_uint32_t_u((safe_unary_minus_func_uint32_t_u((safe_mod_func_int16_t_s_s((safe_mul_func_int8_t_s_s((safe_div_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((((safe_add_func_uint64_t_u_u(g_30[4], g_23)) , p_7) != p_7), l_35)), 0x27L)), g_27)), p_7)))))) | p_7), (-5L))) != l_26) != (-4L));
        }
        else
        { /* block id: 13 */
            uint8_t l_51[6] = {0x7DL,0x7DL,0x95L,0x7DL,0x7DL,0x95L};
            int i;
            l_51[2] ^= 0x6C8400B8L;
            if (p_7)
                goto lbl_53;
lbl_53:
            l_52[0] = (-1L);
            l_56 &= (safe_mod_func_uint16_t_u_u(((l_52[0] < p_7) || l_51[4]), 0xD469L));
        }
        if (g_27)
            goto lbl_75;
        for (g_27 = 0; (g_27 <= 15); g_27 = safe_add_func_uint16_t_u_u(g_27, 5))
        { /* block id: 21 */
            uint32_t l_59 = 0x53483200L;
            l_52[0] = (p_7 & l_17);
            l_59 ^= ((((l_17 | p_7) | p_7) , p_7) && 0xC4L);
            g_50 = ((safe_sub_func_int8_t_s_s((((safe_mod_func_uint32_t_u_u(g_18, g_23)) , l_26) & 0x21L), g_30[1])) > g_50);
        }
        l_64 = (((p_7 , g_30[6]) , 4L) && g_18);
        g_69[4]--;
    }
    else
    { /* block id: 28 */
        l_67 = g_3;
        if (p_7)
        { /* block id: 30 */
lbl_75:
            --g_72;
            ++g_76;
        }
        else
        { /* block id: 34 */
            int8_t l_85[3];
            int i;
            for (i = 0; i < 3; i++)
                l_85[i] = 0x5AL;
            g_50 = (safe_mod_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u((((((!0xFDCF91F6L) == l_84) & p_7) == g_27) | 0xC2A7322E546EC709LL), p_7)), 1L));
            l_64 = ((p_7 || p_7) || l_85[2]);
            g_50 |= (~(5L | (-6L)));
            g_50 = l_67;
        }
    }
    l_65 = ((-1L) || g_30[1]);
    l_64 = (((safe_mod_func_uint8_t_u_u((g_69[4] | 0x34DBL), 255UL)) < 0xA3F7B2C8L) ^ l_84);
    l_64 = g_27;
    return p_7;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_23
 */
static int8_t  func_10(uint64_t  p_11, int32_t  p_12, int32_t  p_13, const uint8_t  p_14)
{ /* block id: 4 */
    g_23 = (safe_sub_func_uint32_t_u_u((safe_mod_func_int8_t_s_s(p_13, 0xECL)), g_3));
    return p_13;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_30[i], "g_30[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_50, "g_50", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_69[i], "g_69[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 28
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 8
   depth: 3, occurrence: 5
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 54
XXX times a non-volatile is write: 28
XXX times a volatile is read: 11
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 41
XXX percentage of non-volatile access: 84.5

XXX forward jumps: 2
XXX backward jumps: 0

XXX stmts: 42
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 13
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 23.5
XXX percentage an existing variable is used: 76.5
********************* end of statistics **********************/

