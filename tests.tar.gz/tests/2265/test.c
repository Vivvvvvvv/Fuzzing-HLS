/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1525801174872292200
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_7 = 0UL;
static int16_t g_11 = 1L;
static uint16_t g_24 = 0UL;
static uint64_t g_28 = 0xB38E5161E33ECDC0LL;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static uint64_t  func_5(uint32_t  p_6);
static int32_t  func_18(int16_t  p_19, uint32_t  p_20, const int8_t  p_21, const int32_t  p_22, int16_t  p_23);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_11 g_24 g_28
 * writes: g_11 g_24 g_28
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    const int32_t l_27 = 0xEB0A1172L;
    g_28 |= (safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_uint16_t_u((((((func_5(g_7) , 0x6B51F0EF2F37FC03LL) && g_7) != l_27) , g_24) | g_7))), l_27));
    return g_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_11 g_24
 * writes: g_11 g_24
 */
static uint64_t  func_5(uint32_t  p_6)
{ /* block id: 1 */
    int32_t l_8 = 2L;
    l_8 ^= p_6;
    g_11 = (safe_mul_func_int8_t_s_s(p_6, g_7));
    l_8 ^= ((p_6 == 0x9C25L) <= g_7);
    for (l_8 = (-14); (l_8 >= 24); ++l_8)
    { /* block id: 7 */
        uint16_t l_16 = 65532UL;
        int32_t l_25 = 0x28033590L;
        const uint32_t l_26 = 1UL;
        for (g_11 = 0; (g_11 <= (-12)); g_11 = safe_sub_func_uint64_t_u_u(g_11, 1))
        { /* block id: 10 */
            int16_t l_17 = 8L;
            l_16 = (65535UL ^ p_6);
            l_17 = ((-9L) | l_8);
            l_25 = func_18(p_6, p_6, p_6, p_6, p_6);
            if (l_26)
                continue;
        }
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_24
 * writes: g_24
 */
static int32_t  func_18(int16_t  p_19, uint32_t  p_20, const int8_t  p_21, const int32_t  p_22, int16_t  p_23)
{ /* block id: 13 */
    g_24 &= (0x2E809B4AL <= g_11);
    return g_24;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 6
   depth: 3, occurrence: 1
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 10
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 1
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 32.3
XXX percentage an existing variable is used: 67.7
********************* end of statistics **********************/

