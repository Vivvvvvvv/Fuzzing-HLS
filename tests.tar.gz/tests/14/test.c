/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      15397282046182704782
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2[2] = {0x26BDDE0BL,0x26BDDE0BL};
static volatile int32_t g_3[4][5][1] = {{{0x585B7F37L},{0x6318D581L},{0x05DAE5A6L},{0L},{0x05DAE5A6L}},{{0x6318D581L},{0x585B7F37L},{2L},{0xDBE8E56FL},{2L}},{{0x585B7F37L},{0x6318D581L},{0x05DAE5A6L},{0L},{0x05DAE5A6L}},{{0x6318D581L},{0x585B7F37L},{2L},{0xDBE8E56FL},{2L}}};
static volatile int32_t g_4 = 0xAD9BACC5L;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 0L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int8_t  func_8(uint32_t  p_9, int32_t  p_10, int64_t  p_11, int32_t  p_12, int32_t  p_13);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_4 g_3
 * writes: g_5 g_3
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_18 = (-1L);
    int32_t l_22[2];
    uint64_t l_23[2];
    uint16_t l_30 = 6UL;
    int i;
    for (i = 0; i < 2; i++)
        l_22[i] = 0L;
    for (i = 0; i < 2; i++)
        l_23[i] = 0x294B58FE4DE5A82ALL;
    for (g_5 = 0; (g_5 <= 1); g_5 += 1)
    { /* block id: 3 */
        int i;
        return g_2[g_5];
    }
    g_5 = ((0x0AL != 0x29L) , g_4);
    if ((safe_div_func_int8_t_s_s(func_8(((safe_mul_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u(((l_18 , 4294967295UL) < l_18), (-1L))), 0x6CL)) > (-1L)), g_5, g_2[0], g_5, g_3[1][4][0]), 1UL)))
    { /* block id: 10 */
        int8_t l_28 = 0x48L;
        int32_t l_29 = 0x8DC70E74L;
        int64_t l_36 = 0xFDEF05DE082ADE89LL;
        uint32_t l_37 = 1UL;
        --l_23[0];
        if ((0UL > g_3[2][0][0]))
        { /* block id: 12 */
            l_22[0] = (safe_div_func_uint64_t_u_u((0x67L == l_23[1]), g_3[3][2][0]));
        }
        else
        { /* block id: 14 */
            uint32_t l_35 = 0xD89BB643L;
            uint64_t l_40[8][7][4] = {{{0x4EA093EA4B5445D8LL,0x63704BAE9140DE19LL,0x647CF2842C5ACC8ELL,0x61C1CA36320CFA82LL},{18446744073709551607UL,0xAE2A06A03D0BAECBLL,0x2819455490EB022BLL,0x61C1CA36320CFA82LL},{0x8E356D6BBB239257LL,0x63704BAE9140DE19LL,0xD083830386B9BDD1LL,0xAE2A06A03D0BAECBLL},{18446744073709551607UL,18446744073709551607UL,18446744073709551611UL,18446744073709551607UL},{0x63704BAE9140DE19LL,1UL,0x2819455490EB022BLL,3UL},{18446744073709551612UL,0x4EA093EA4B5445D8LL,1UL,18446744073709551612UL},{0xAE2A06A03D0BAECBLL,1UL,18446744073709551611UL,0x2819455490EB022BLL}},{{0xAE2A06A03D0BAECBLL,9UL,5UL,0xD083830386B9BDD1LL},{0x647CF2842C5ACC8ELL,0x2819455490EB022BLL,18446744073709551611UL,18446744073709551611UL},{0xA871D1BA0576189ELL,0xA871D1BA0576189ELL,0x63704BAE9140DE19LL,0x2819455490EB022BLL},{0x2819455490EB022BLL,0x647CF2842C5ACC8ELL,0x037BAD6E3F992CE4LL,1UL},{9UL,0xAE2A06A03D0BAECBLL,18446744073709551611UL,0x037BAD6E3F992CE4LL},{1UL,0xAE2A06A03D0BAECBLL,18446744073709551607UL,1UL},{0xAE2A06A03D0BAECBLL,0x647CF2842C5ACC8ELL,9UL,0x2819455490EB022BLL}},{{5UL,0xA871D1BA0576189ELL,5UL,18446744073709551611UL},{1UL,0x2819455490EB022BLL,3UL,0xD083830386B9BDD1LL},{0xA871D1BA0576189ELL,9UL,0x037BAD6E3F992CE4LL,0x2819455490EB022BLL},{0xF3C25A1B5826CCE7LL,1UL,0x037BAD6E3F992CE4LL,0x647CF2842C5ACC8ELL},{0xA871D1BA0576189ELL,0xAE2A06A03D0BAECBLL,3UL,0x8E356D6BBB239257LL},{1UL,5UL,5UL,1UL},{5UL,1UL,9UL,0xF3C25A1B5826CCE7LL}},{{0xAE2A06A03D0BAECBLL,0xA871D1BA0576189ELL,18446744073709551607UL,0xD083830386B9BDD1LL},{1UL,0xF3C25A1B5826CCE7LL,18446744073709551611UL,0xD083830386B9BDD1LL},{9UL,0xA871D1BA0576189ELL,0x037BAD6E3F992CE4LL,0xF3C25A1B5826CCE7LL},{0x2819455490EB022BLL,1UL,0x63704BAE9140DE19LL,1UL},{0xA871D1BA0576189ELL,5UL,18446744073709551611UL,0x8E356D6BBB239257LL},{0x647CF2842C5ACC8ELL,0xAE2A06A03D0BAECBLL,5UL,0x647CF2842C5ACC8ELL},{0xAE2A06A03D0BAECBLL,1UL,18446744073709551611UL,0x2819455490EB022BLL}},{{0xAE2A06A03D0BAECBLL,9UL,5UL,0xD083830386B9BDD1LL},{0x647CF2842C5ACC8ELL,0x2819455490EB022BLL,18446744073709551611UL,18446744073709551611UL},{0xA871D1BA0576189ELL,0xA871D1BA0576189ELL,0x63704BAE9140DE19LL,0x2819455490EB022BLL},{0x2819455490EB022BLL,0x647CF2842C5ACC8ELL,0x037BAD6E3F992CE4LL,1UL},{9UL,0xAE2A06A03D0BAECBLL,18446744073709551611UL,0x037BAD6E3F992CE4LL},{1UL,0xAE2A06A03D0BAECBLL,18446744073709551607UL,1UL},{0xAE2A06A03D0BAECBLL,0x647CF2842C5ACC8ELL,9UL,0x2819455490EB022BLL}},{{5UL,0xA871D1BA0576189ELL,5UL,18446744073709551611UL},{1UL,0x2819455490EB022BLL,3UL,0xD083830386B9BDD1LL},{0xA871D1BA0576189ELL,9UL,0x037BAD6E3F992CE4LL,0x2819455490EB022BLL},{0xF3C25A1B5826CCE7LL,1UL,0x037BAD6E3F992CE4LL,0x647CF2842C5ACC8ELL},{0xA871D1BA0576189ELL,0xAE2A06A03D0BAECBLL,3UL,0x8E356D6BBB239257LL},{1UL,5UL,5UL,1UL},{5UL,1UL,9UL,0xF3C25A1B5826CCE7LL}},{{0xAE2A06A03D0BAECBLL,0xA871D1BA0576189ELL,18446744073709551607UL,0xD083830386B9BDD1LL},{1UL,0xF3C25A1B5826CCE7LL,18446744073709551611UL,0xD083830386B9BDD1LL},{9UL,0xA871D1BA0576189ELL,0x037BAD6E3F992CE4LL,0xF3C25A1B5826CCE7LL},{0x2819455490EB022BLL,1UL,0x63704BAE9140DE19LL,1UL},{0xA871D1BA0576189ELL,5UL,18446744073709551611UL,0x8E356D6BBB239257LL},{0x647CF2842C5ACC8ELL,0xAE2A06A03D0BAECBLL,5UL,0x647CF2842C5ACC8ELL},{0xAE2A06A03D0BAECBLL,1UL,18446744073709551611UL,0x2819455490EB022BLL}},{{0xAE2A06A03D0BAECBLL,9UL,5UL,0xD083830386B9BDD1LL},{0x647CF2842C5ACC8ELL,0x2819455490EB022BLL,18446744073709551611UL,18446744073709551611UL},{0xA871D1BA0576189ELL,0xA871D1BA0576189ELL,0x63704BAE9140DE19LL,0x2819455490EB022BLL},{0x2819455490EB022BLL,0x647CF2842C5ACC8ELL,0x037BAD6E3F992CE4LL,1UL},{9UL,0xAE2A06A03D0BAECBLL,18446744073709551611UL,18446744073709551611UL},{5UL,0xF3C25A1B5826CCE7LL,0x2819455490EB022BLL,5UL},{0xF3C25A1B5826CCE7LL,18446744073709551607UL,18446744073709551607UL,18446744073709551611UL}}};
            int i, j, k;
            ++l_30;
            l_35 = (safe_lshift_func_uint8_t_u_s((255UL && g_2[1]), 6));
            ++l_37;
            g_3[0][3][0] = l_40[2][4][1];
        }
        for (l_30 = 0; (l_30 <= 1); l_30 += 1)
        { /* block id: 22 */
            int8_t l_41 = 0xB3L;
            int i;
            l_22[l_30] = l_22[l_30];
            l_22[0] = func_8(l_41, g_2[1], l_22[l_30], l_22[1], g_3[1][4][0]);
            l_22[0] |= (safe_rshift_func_uint8_t_u_u((g_3[1][4][0] | l_37), l_30));
        }
    }
    else
    { /* block id: 27 */
        g_5 ^= ((safe_lshift_func_int8_t_s_s((0UL < l_22[0]), g_3[1][4][0])) <= 4UL);
        g_5 = g_2[1];
    }
    return g_5;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int8_t  func_8(uint32_t  p_9, int32_t  p_10, int64_t  p_11, int32_t  p_12, int32_t  p_13)
{ /* block id: 7 */
    uint32_t l_19 = 0x7B88CDF8L;
    --l_19;
    return p_9;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_3[i][j][k], "g_3[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 12
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 23
   depth: 2, occurrence: 3
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 22
XXX times a non-volatile is write: 14
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 32
XXX percentage of non-volatile access: 81.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 6
   depth: 2, occurrence: 8

XXX percentage a fresh-made variable is used: 20.3
XXX percentage an existing variable is used: 79.7
********************* end of statistics **********************/

