/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      7626782159881828374
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const volatile int32_t  f0;
   volatile uint32_t  f1;
   uint8_t  f2;
   volatile int64_t  f3;
   uint8_t  f4;
   volatile uint64_t  f5;
};

/* --- GLOBAL VARIABLES --- */
static uint64_t g_11 = 0UL;
static volatile struct S0 g_21 = {0x4593F6A0L,5UL,0xFBL,0xCC013CEF33920027LL,0xE5L,0xE623B26D5D64F689LL};/* VOLATILE GLOBAL g_21 */
static int32_t g_22[7] = {1L,0xD9918C6AL,1L,1L,0xD9918C6AL,1L,1L};


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int16_t  func_5(uint8_t  p_6, int32_t  p_7, int32_t  p_8, uint32_t  p_9, const uint64_t  p_10);
static int32_t  func_13(uint16_t  p_14, int32_t  p_15);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_11 g_21
 * writes: g_22
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_4[1];
    uint8_t l_12 = 1UL;
    uint32_t l_29 = 0xC0D357E8L;
    int32_t l_32 = 0x4814C7C7L;
    int i;
    for (i = 0; i < 1; i++)
        l_4[i] = 0x5912491E29EA4144LL;
    l_4[0] = (safe_sub_func_int16_t_s_s(0x5A65L, 0xDDD3L));
    l_29 = (((func_5((9L | 0x02L), g_11, l_12, l_4[0], l_12) ^ l_4[0]) > 250UL) < g_11);
    l_32 |= (((safe_mul_func_uint16_t_u_u(((g_11 & 0x03L) && g_21.f1), 0x5375L)) , 0x79L) > l_29);
    return g_21.f4;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_21
 * writes: g_22
 */
static int16_t  func_5(uint8_t  p_6, int32_t  p_7, int32_t  p_8, uint32_t  p_9, const uint64_t  p_10)
{ /* block id: 2 */
    int32_t l_16 = 2L;
    int32_t l_23 = 0x73EE49CEL;
    g_22[2] = func_13(p_7, l_16);
    if ((l_23 == l_16))
    { /* block id: 10 */
        l_23 = ((safe_add_func_int16_t_s_s((-6L), p_7)) < 1UL);
    }
    else
    { /* block id: 12 */
        uint8_t l_26 = 0xE1L;
        l_26--;
        l_16 = (0xB7203FCAL == 4294967291UL);
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_21
 * writes:
 */
static int32_t  func_13(uint16_t  p_14, int32_t  p_15)
{ /* block id: 3 */
    uint16_t l_17 = 1UL;
    int32_t l_18 = 0L;
    l_18 = (g_11 < l_17);
    l_18 ^= 0x068CD546L;
    l_18 ^= p_14;
    l_18 = (safe_mod_func_int8_t_s_s(((((((g_21 , 1UL) & p_15) | g_11) | g_11) < l_18) , 0x7FL), p_14));
    return p_15;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_21.f0, "g_21.f0", print_hash_value);
    transparent_crc(g_21.f1, "g_21.f1", print_hash_value);
    transparent_crc(g_21.f2, "g_21.f2", print_hash_value);
    transparent_crc(g_21.f3, "g_21.f3", print_hash_value);
    transparent_crc(g_21.f4, "g_21.f4", print_hash_value);
    transparent_crc(g_21.f5, "g_21.f5", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 17
   depth: 2, occurrence: 4
   depth: 3, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 11
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 91.9

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 32.4
XXX percentage an existing variable is used: 67.6
********************* end of statistics **********************/

