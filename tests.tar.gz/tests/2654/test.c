/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5267070462757476169
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_18[10] = {1UL,0x44L,1UL,1UL,0x44L,1UL,1UL,0x44L,1UL,1UL};
static uint8_t g_23 = 0x27L;
static int32_t g_30 = (-2L);


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint8_t  func_4(const int32_t  p_5, int32_t  p_6, int64_t  p_7);
static int32_t  func_12(int32_t  p_13, uint32_t  p_14, int64_t  p_15, int32_t  p_16, int16_t  p_17);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_18 g_23
 * writes: g_23 g_30
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_19 = 18446744073709551609UL;
    int8_t l_29 = (-10L);
    g_30 = (((safe_rshift_func_uint8_t_u_u(func_4((safe_rshift_func_uint8_t_u_s(((func_12(g_18[5], g_18[5], l_19, l_19, g_18[5]) && l_19) | 0UL), l_19)), l_29, l_29), g_18[3])) , 255UL) >= l_19);
    return g_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_18
 * writes:
 */
static uint8_t  func_4(const int32_t  p_5, int32_t  p_6, int64_t  p_7)
{ /* block id: 18 */
    p_6 = ((g_18[0] && p_5) , p_6);
    return g_18[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_18
 * writes: g_23
 */
static int32_t  func_12(int32_t  p_13, uint32_t  p_14, int64_t  p_15, int32_t  p_16, int16_t  p_17)
{ /* block id: 1 */
    uint8_t l_28 = 0x37L;
    p_13 = p_16;
    for (p_13 = 1; (p_13 <= 9); p_13 += 1)
    { /* block id: 5 */
        uint32_t l_20 = 9UL;
        int i;
        l_20 = (0x5ACEE61780EEC299LL > 0L);
        if (g_18[p_13])
            break;
        for (p_16 = 0; (p_16 <= 9); p_16 += 1)
        { /* block id: 10 */
            int32_t l_26[2];
            int i;
            for (i = 0; i < 2; i++)
                l_26[i] = 1L;
            g_23 = (safe_lshift_func_int16_t_s_s((0xA3L && 7L), 11));
            l_26[0] = (((safe_mod_func_int64_t_s_s((-1L), g_18[p_13])) <= g_18[p_16]) , g_18[p_13]);
            l_28 = (safe_unary_minus_func_int32_t_s(4L));
            return p_14;
        }
    }
    return p_15;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 14
   depth: 2, occurrence: 3
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 15, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 3
   depth: 2, occurrence: 4

XXX percentage a fresh-made variable is used: 30.8
XXX percentage an existing variable is used: 69.2
********************* end of statistics **********************/

