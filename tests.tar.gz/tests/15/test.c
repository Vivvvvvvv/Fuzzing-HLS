/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9570442489203108409
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[2][8][3] = {{{0L,4L,0x4E064826L},{4L,0x34E6D4F2L,0x34E6D4F2L},{(-10L),0L,0x4E064826L},{(-1L),0x29BE1D92L,0L},{(-1L),(-1L),4L},{(-10L),0xF2E5664DL,(-10L)},{4L,(-1L),(-1L)},{0L,0x29BE1D92L,(-1L)}},{{0x4E064826L,0L,(-10L)},{0x34E6D4F2L,0x34E6D4F2L,4L},{0x4E064826L,4L,0L},{0L,4L,0x4E064826L},{4L,0x34E6D4F2L,0x34E6D4F2L},{(-10L),0L,0x4E064826L},{(-1L),0x29BE1D92L,0L},{(-1L),4L,0x34E6D4F2L}}};
static int32_t g_3 = 1L;
static int32_t g_116 = (-7L);
static int32_t g_144 = 0x8BACA3D2L;
static const int8_t g_189 = 0x6BL;
static int8_t g_231 = 0x51L;
static int64_t g_247 = 7L;
static uint32_t g_263 = 0xCE4279E7L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint8_t  func_20(int32_t  p_21, uint16_t  p_22, const uint64_t  p_23, int32_t  p_24, int8_t  p_25);
static int32_t  func_26(const int32_t  p_27, int32_t  p_28);
static int16_t  func_42(uint8_t  p_43, int16_t  p_44, uint64_t  p_45);
static uint8_t  func_53(uint32_t  p_54, uint8_t  p_55, uint32_t  p_56, uint32_t  p_57, int16_t  p_58);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_116 g_144 g_189 g_231 g_263
 * writes: g_3 g_2 g_116 g_144 g_231
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int8_t l_9 = 0xFEL;
    int32_t l_12 = 0x289FFF12L;
    int32_t l_13 = 0x1600D549L;
    int32_t l_15[8][10][1] = {{{1L},{0xE0C0A103L},{0xCE17C927L},{0xD8169B41L},{(-5L)},{0x1D127A4EL},{(-2L)},{0xC6A3F0BDL},{2L},{1L}},{{0x67C8FA1BL},{0L},{(-3L)},{(-1L)},{(-2L)},{0xC88307B3L},{0L},{0L},{0L},{0xC88307B3L}},{{(-2L)},{(-1L)},{(-3L)},{0L},{0x67C8FA1BL},{1L},{2L},{0xC6A3F0BDL},{(-2L)},{0x1D127A4EL}},{{(-5L)},{0xD8169B41L},{0xCE17C927L},{0xE0C0A103L},{1L},{0xE0C0A103L},{0xCE17C927L},{0xD8169B41L},{(-5L)},{0x1D127A4EL}},{{(-2L)},{0xC6A3F0BDL},{2L},{1L},{0x67C8FA1BL},{0L},{(-3L)},{(-1L)},{(-2L)},{0xC88307B3L}},{{0L},{0L},{0L},{0xC88307B3L},{(-2L)},{(-1L)},{(-3L)},{0L},{0x67C8FA1BL},{1L}},{{2L},{0xC6A3F0BDL},{(-2L)},{0x1D127A4EL},{(-5L)},{0xD8169B41L},{0xCE17C927L},{0xE0C0A103L},{1L},{0xE0C0A103L}},{{0xCE17C927L},{0xD8169B41L},{(-5L)},{0x1D127A4EL},{(-2L)},{0xC6A3F0BDL},{2L},{1L},{0x67C8FA1BL},{0L}}};
    uint16_t l_16 = 65535UL;
    int16_t l_246 = 2L;
    int16_t l_250[1][4][8] = {{{5L,3L,(-4L),5L,1L,1L,5L,(-4L)},{0xAABBL,0xAABBL,0x3B17L,(-9L),5L,0x3B17L,5L,(-9L)},{(-4L),(-9L),(-4L),1L,(-9L),3L,3L,(-9L)},{(-9L),3L,3L,(-9L),1L,(-4L),(-9L),(-4L)}}};
    uint32_t l_252 = 0x91226863L;
    int i, j, k;
lbl_234:
    for (g_3 = 0; (g_3 < (-18)); g_3 = safe_sub_func_uint64_t_u_u(g_3, 1))
    { /* block id: 3 */
        int16_t l_8 = 0xFE46L;
        l_8 |= (safe_rshift_func_uint8_t_u_s((18446744073709551608UL != 1L), 5));
        if (l_8)
            goto lbl_262;
    }
    if ((l_9 != g_3))
    { /* block id: 6 */
        return g_3;
    }
    else
    { /* block id: 8 */
        int16_t l_10[6] = {(-1L),(-1L),(-5L),(-1L),(-1L),(-5L)};
        int32_t l_11 = (-1L);
        int8_t l_14[6][3][8] = {{{0x20L,0x4BL,7L,0x90L,0xEAL,(-1L),0x7CL,0x20L},{0L,0x1AL,0x12L,(-4L),0xEAL,0xBFL,(-5L),0xEAL},{0x20L,(-1L),(-1L),0x20L,1L,0xA0L,0x07L,0x79L}},{{0L,2L,0L,0xD8L,0xF8L,0xACL,0L,(-6L)},{0x4AL,8L,(-1L),0xA0L,0xC4L,0x6EL,0x12L,8L},{8L,(-1L),(-5L),0x7CL,0x5FL,(-3L),(-6L),0x4AL}},{{(-6L),0x20L,0x6AL,0x90L,8L,(-1L),0L,0L},{0x79L,0x90L,0xBFL,0xBFL,0x90L,0x79L,0x12L,0x20L},{0xEAL,9L,0x5FL,0x1AL,0xA0L,(-5L),0x90L,0x6EL}},{{0xD4L,0x6EL,0xEAL,(-1L),0L,0x90L,0x6CL,0xD4L},{9L,0L,0x4EL,0x75L,0x4AL,1L,0xACL,0L},{1L,(-1L),0x37L,0xBFL,(-4L),0L,1L,(-4L)}},{{0L,0L,8L,7L,1L,8L,0xA0L,0x6CL},{9L,(-1L),(-4L),0L,0x6CL,0L,0x4EL,0x6EL},{(-1L),7L,0xACL,0x12L,0L,0x3BL,7L,0x3BL}},{{(-5L),0xD4L,2L,0xD4L,(-5L),8L,(-1L),(-3L)},{0x3BL,0xA0L,(-7L),0xA9L,1L,0x6EL,(-1L),0xD4L},{0L,(-1L),(-7L),(-1L),1L,0x6AL,(-1L),9L}}};
        int32_t l_241 = (-1L);
        int8_t l_242 = 0L;
        int32_t l_243 = 0xB06F44EEL;
        int32_t l_244 = 0x8E840700L;
        int32_t l_245 = 0x40F32533L;
        int32_t l_248[3];
        int32_t l_249 = 1L;
        int32_t l_251 = (-3L);
        uint8_t l_256 = 0x29L;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_248[i] = 0xB2388B40L;
        ++l_16;
        if ((+func_20(func_26(g_2[1][1][1], l_10[3]), l_10[1], g_189, g_189, l_9)))
        { /* block id: 129 */
            int16_t l_228 = 0x08DDL;
            int32_t l_232[6][10] = {{(-10L),0L,0x72C3EF3CL,0x0BF1236BL,0L,0L,0L,0x0BF1236BL,0x72C3EF3CL,0L},{(-10L),0x2306FBF4L,0x96DF6385L,0x0BF1236BL,0x2306FBF4L,0x560489EAL,0L,0x96DF6385L,0x96DF6385L,0L},{0x560489EAL,0L,0x96DF6385L,0x96DF6385L,0L,0x560489EAL,0x2306FBF4L,0x0BF1236BL,0x96DF6385L,0x2306FBF4L},{(-10L),0L,0x72C3EF3CL,0x0BF1236BL,0L,0L,0L,0x0BF1236BL,0x72C3EF3CL,0L},{(-10L),0x2306FBF4L,0x96DF6385L,0x0BF1236BL,0x2306FBF4L,0x560489EAL,0L,0x96DF6385L,0x96DF6385L,0L},{0x560489EAL,0L,0x96DF6385L,0x96DF6385L,0L,0x560489EAL,0x2306FBF4L,0x0BF1236BL,0x96DF6385L,0x2306FBF4L}};
            int i, j;
            g_144 = (((((~(0xB50BL > l_228)) ^ l_15[4][9][0]) <= g_189) ^ 4L) < 0x22L);
            if (g_116)
                goto lbl_255;
            l_232[1][9] = ((safe_mod_func_int64_t_s_s((g_231 | l_228), g_2[0][5][0])) ^ g_3);
        }
        else
        { /* block id: 132 */
            uint8_t l_233 = 0x3CL;
            return l_233;
        }
lbl_255:
        for (l_9 = 0; (l_9 >= 0); l_9 -= 1)
        { /* block id: 137 */
            int32_t l_239[3][2];
            int32_t l_240 = 0xE08E61A9L;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_239[i][j] = 2L;
            }
            if (g_116)
                goto lbl_234;
            l_11 = (safe_sub_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((l_12 && l_13) == 0UL), g_3)), l_239[0][1]));
            ++l_252;
            if (g_116)
                break;
        }
        g_144 = l_256;
    }
lbl_262:
    for (g_231 = 0; (g_231 >= 0); g_231 -= 1)
    { /* block id: 148 */
        uint32_t l_258 = 0xF429D25AL;
        g_144 ^= ((~0L) , g_231);
        for (l_12 = 0; (l_12 >= 0); l_12 -= 1)
        { /* block id: 152 */
            uint32_t l_259 = 18446744073709551609UL;
            l_13 ^= l_9;
            if (l_246)
                continue;
            l_258 ^= (((18446744073709551608UL != g_2[1][1][1]) | l_12) <= 0xF185L);
            l_259++;
        }
    }
    return g_263;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3
 * writes: g_3
 */
static uint8_t  func_20(int32_t  p_21, uint16_t  p_22, const uint64_t  p_23, int32_t  p_24, int8_t  p_25)
{ /* block id: 108 */
    int32_t l_203[6][1] = {{0x5D73EC10L},{0xA4677E44L},{0x5D73EC10L},{0xA4677E44L},{0x5D73EC10L},{0xA4677E44L}};
    int64_t l_207 = 0x799F0F0D5E205D0ALL;
    uint16_t l_211 = 0UL;
    uint8_t l_215[2][7];
    uint8_t l_225 = 0x48L;
    const uint32_t l_226 = 0xFC5EE706L;
    int i, j;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 7; j++)
            l_215[i][j] = 0x4BL;
    }
    for (p_25 = 0; (p_25 >= 23); p_25++)
    { /* block id: 111 */
        int64_t l_199 = (-1L);
        for (p_24 = (-14); (p_24 < (-15)); --p_24)
        { /* block id: 114 */
            uint32_t l_198 = 4294967295UL;
            l_199 |= (safe_div_func_int64_t_s_s((safe_mod_func_int64_t_s_s(2L, l_198)), l_198));
        }
    }
    if ((safe_unary_minus_func_uint8_t_u((safe_lshift_func_int16_t_s_s(g_2[1][5][0], 0)))))
    { /* block id: 118 */
        int16_t l_204 = 0L;
        int32_t l_205 = 0xC68EEB7CL;
        int32_t l_206 = 0x3FEC30DDL;
        int32_t l_208 = 0x064F0C36L;
        int32_t l_209 = 0L;
        int32_t l_210[7][1][1];
        int32_t l_214 = 0x74FFD2ACL;
        int i, j, k;
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 1; j++)
            {
                for (k = 0; k < 1; k++)
                    l_210[i][j][k] = 0xFFC3AD43L;
            }
        }
        l_211--;
        l_203[2][0] = p_24;
        l_214 = (-1L);
        g_3 = p_22;
    }
    else
    { /* block id: 123 */
        l_215[0][0]++;
        l_203[5][0] |= ((+(((((p_23 < p_23) & 9UL) > p_22) , 0x0EL) != g_2[1][3][0])) ^ g_3);
    }
    l_203[2][0] |= (safe_sub_func_int16_t_s_s((safe_add_func_uint16_t_u_u((safe_div_func_int64_t_s_s(((((l_225 <= p_25) & p_21) & 0xE6FA056FA88BA8CFLL) , p_22), l_226)), p_22)), l_226));
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_116 g_144
 * writes: g_2 g_3 g_116 g_144
 */
static int32_t  func_26(const int32_t  p_27, int32_t  p_28)
{ /* block id: 10 */
    int32_t l_29 = 1L;
    int32_t l_30[5];
    int64_t l_160 = (-6L);
    int32_t l_162 = 0x86CCFD89L;
    uint8_t l_177 = 0xCCL;
    int32_t l_179 = 0x3FA38E5DL;
    int i;
    for (i = 0; i < 5; i++)
        l_30[i] = 1L;
lbl_32:
    g_2[0][7][1] = l_29;
    for (g_3 = 0; (g_3 <= 1); g_3 += 1)
    { /* block id: 14 */
        l_30[0] |= 0x68F781BEL;
        for (p_28 = 0; (p_28 <= 1); p_28 += 1)
        { /* block id: 18 */
            int64_t l_31 = (-1L);
            return l_31;
        }
        for (p_28 = 0; (p_28 <= 1); p_28 += 1)
        { /* block id: 23 */
            int16_t l_143[5][4][8] = {{{(-2L),0xF8E9L,0x2563L,0xF8E9L,(-2L),0L,0x0BB0L,0x102EL},{0xF8E9L,0x4F72L,0L,0x2563L,0x2563L,0L,0x4F72L,0xF8E9L},{(-1L),0L,0L,0x2F34L,0x0BB0L,(-2L),0x0BB0L,0x2F34L},{0x2563L,(-4L),0x2563L,0x102EL,0x2F34L,(-2L),0L,0L}},{{0L,0L,(-1L),(-1L),0L,0L,0x2F34L,0x0BB0L},{0L,0x4F72L,0xF8E9L,0L,0x2F34L,0L,0xF8E9L,0x4F72L},{0x2563L,0xF8E9L,(-2L),(-1L),0x102EL,0xF8E9L,0xF8E9L,0x102EL},{0x0BB0L,0x102EL,0x102EL,0x0BB0L,0L,(-2L),0xF8E9L,0x2563L}},{{(-4L),0x0BB0L,0L,0xF8E9L,0L,0x0BB0L,(-4L),0x4F72L},{0L,0x0BB0L,(-4L),0x4F72L,(-2L),(-2L),0x4F72L,(-4L)},{0x102EL,0x102EL,0x0BB0L,0L,(-2L),0xF8E9L,0x2563L,0xF8E9L},{0L,(-4L),0L,(-4L),0L,(-1L),0x102EL,0xF8E9L}},{{(-4L),(-2L),0x2563L,0L,0L,0x2563L,(-2L),(-4L)},{0x0BB0L,(-1L),0x2563L,0x4F72L,0x102EL,0L,0x102EL,0x4F72L},{0L,0x2F34L,0L,0xF8E9L,0x4F72L,0L,0x2563L,0x2563L},{0x2563L,(-1L),0x0BB0L,0x0BB0L,(-1L),0x2563L,0x4F72L,0x102EL}},{{0x2563L,(-2L),(-4L),(-1L),0x4F72L,(-1L),(-4L),(-2L)},{0L,(-4L),0L,(-1L),0x102EL,0xF8E9L,0xF8E9L,0x102EL},{0x0BB0L,0x102EL,0x102EL,0x0BB0L,0L,(-2L),0xF8E9L,0x2563L},{(-4L),0x0BB0L,0L,0xF8E9L,0L,0x0BB0L,(-4L),0x4F72L}}};
            int i, j, k;
            if (g_3)
                goto lbl_32;
            g_144 &= (safe_mul_func_int16_t_s_s((safe_sub_func_int8_t_s_s((safe_unary_minus_func_uint64_t_u(((((((safe_sub_func_int64_t_s_s((safe_mul_func_int16_t_s_s(func_42(((safe_mul_func_uint8_t_u_u(((p_28 , p_28) | (-9L)), 3L)) , g_3), g_2[1][4][1], g_3), g_3)), p_28)) ^ l_143[4][3][6]) , p_28) | l_143[4][3][6]) , 0L) && 1UL))), l_29)), g_3));
            g_116 = (-6L);
        }
    }
    if (g_2[0][1][1])
    { /* block id: 69 */
        int64_t l_148 = 0x5D2CA8022D0BAB9DLL;
        g_144 = 0x66CD422BL;
        for (p_28 = 0; (p_28 >= 13); ++p_28)
        { /* block id: 73 */
            uint64_t l_147 = 3UL;
            l_147 = l_29;
            if (l_148)
                continue;
            g_2[0][3][0] = (((g_144 <= p_27) >= 1L) & l_147);
        }
    }
    else
    { /* block id: 78 */
        int8_t l_152 = 3L;
        int32_t l_153 = 0x3E7098F6L;
        int32_t l_156 = 0x8687B3F2L;
        int32_t l_157[2];
        int8_t l_167 = 0x1EL;
        uint64_t l_168[2][3][4] = {{{1UL,0UL,0UL,1UL},{0UL,1UL,0UL,0UL},{1UL,1UL,18446744073709551606UL,1UL}},{{1UL,0UL,0UL,1UL},{0UL,1UL,0UL,0UL},{1UL,1UL,18446744073709551606UL,1UL}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_157[i] = 1L;
        for (g_3 = 0; (g_3 <= 1); g_3 += 1)
        { /* block id: 81 */
            uint8_t l_149 = 0x79L;
            int32_t l_154 = 1L;
            int32_t l_155 = 0x77165E9AL;
            int32_t l_158 = 0x0DE5B823L;
            int32_t l_159 = (-9L);
            int32_t l_161 = 1L;
            int32_t l_163 = 3L;
            int32_t l_164 = 0x3443E91BL;
            int32_t l_165 = 0xC4E51E7AL;
            int32_t l_166[7][2] = {{0xE1256EB5L,(-1L)},{0xE1256EB5L,0xE1256EB5L},{(-1L),0xE1256EB5L},{0xE1256EB5L,(-1L)},{0xE1256EB5L,0xE1256EB5L},{(-1L),0xE1256EB5L},{0xE1256EB5L,(-1L)}};
            int i, j;
            ++l_149;
            if (g_116)
                continue;
            --l_168[1][1][0];
        }
        g_144 &= (safe_sub_func_uint64_t_u_u(((((((((safe_lshift_func_int8_t_s_s((g_3 && p_28), 7)) <= 0x38L) == p_27) > g_2[0][1][0]) , l_157[0]) >= l_156) , p_27) , 8UL), 0x962CD732F0C697CCLL));
        l_157[0] = ((l_162 , 255UL) && l_157[1]);
        g_2[1][1][1] = ((l_162 >= l_153) & g_2[1][1][1]);
    }
    if ((((safe_lshift_func_uint8_t_u_u(((p_28 < 3L) >= p_28), l_177)) <= p_28) , 2L))
    { /* block id: 90 */
        int32_t l_178 = (-10L);
        int32_t l_182 = (-9L);
        l_178 &= (g_144 && l_162);
        for (p_28 = 1; (p_28 >= 0); p_28 -= 1)
        { /* block id: 94 */
            int i;
            l_179 ^= (l_30[(p_28 + 1)] | l_30[(p_28 + 3)]);
            l_30[0] &= ((safe_lshift_func_int16_t_s_s(g_144, 8)) < 0x3618L);
            return l_182;
        }
    }
    else
    { /* block id: 99 */
        if ((safe_add_func_uint8_t_u_u((((-5L) & 0x32L) > l_162), 0x57L)))
        { /* block id: 100 */
            int16_t l_185 = 0x4C0EL;
            return l_185;
        }
        else
        { /* block id: 102 */
            uint32_t l_186 = 18446744073709551615UL;
            l_186++;
            return l_30[4];
        }
    }
    return l_162;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_116
 * writes: g_2 g_116
 */
static int16_t  func_42(uint8_t  p_43, int16_t  p_44, uint64_t  p_45)
{ /* block id: 25 */
    uint32_t l_59 = 2UL;
    int8_t l_136 = 0x42L;
    for (p_43 = (-5); (p_43 != 34); p_43 = safe_add_func_uint64_t_u_u(p_43, 1))
    { /* block id: 28 */
        int8_t l_50 = 0xD9L;
        int32_t l_123 = (-9L);
        uint32_t l_131[9][5] = {{0xCD30ACD8L,0x34962E96L,1UL,0x34962E96L,0xCD30ACD8L},{0x8CFB8BCEL,18446744073709551615UL,0UL,0x39AB0C0BL,18446744073709551615UL},{0xCD30ACD8L,0UL,0UL,0xCD30ACD8L,0x39AB0C0BL},{0x34962E96L,0xCD30ACD8L,1UL,18446744073709551615UL,18446744073709551615UL},{0x8CFB8BCEL,0xCD30ACD8L,0x8CFB8BCEL,0x39AB0C0BL,0xCD30ACD8L},{18446744073709551615UL,0UL,0x39AB0C0BL,18446744073709551615UL,0x39AB0C0BL},{18446744073709551615UL,18446744073709551615UL,1UL,0xCD30ACD8L,0x34962E96L},{0x8CFB8BCEL,0x34962E96L,0x39AB0C0BL,0x39AB0C0BL,0x34962E96L},{0x34962E96L,0UL,0x8CFB8BCEL,0x34962E96L,0xC33512AAL}};
        int i, j;
        g_2[0][4][1] = l_50;
        g_116 ^= ((safe_add_func_uint8_t_u_u(func_53(g_2[1][1][1], l_59, l_50, p_44, p_43), g_3)) | g_3);
        for (l_50 = 25; (l_50 > 9); l_50 = safe_sub_func_int64_t_s_s(l_50, 8))
        { /* block id: 51 */
            uint32_t l_130 = 4294967287UL;
            l_123 = (((safe_add_func_uint16_t_u_u(((((safe_sub_func_int16_t_s_s(p_44, p_44)) & l_59) | 0x7B63B490L) & p_45), 0xABACL)) == l_59) ^ g_3);
            l_131[7][1] = ((((safe_sub_func_uint16_t_u_u((((safe_mul_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u(l_130, 1)) && 255UL), g_2[1][0][1])) > p_45) , 0xCEACL), 0x3EC6L)) <= p_43) <= l_123) >= l_59);
        }
        for (l_50 = 0; (l_50 == 9); ++l_50)
        { /* block id: 57 */
            uint8_t l_137 = 0x09L;
            if (p_44)
                break;
            l_137 = ((safe_mod_func_uint64_t_u_u(((9L == l_136) >= 0x22F18E3FL), g_116)) , p_44);
            if (g_3)
                continue;
        }
    }
    g_2[0][5][2] ^= (safe_sub_func_uint64_t_u_u((safe_sub_func_int8_t_s_s((safe_unary_minus_func_uint64_t_u(0x02B22ED0F463211CLL)), (-3L))), g_116));
    return l_59;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3
 * writes: g_2
 */
static uint8_t  func_53(uint32_t  p_54, uint8_t  p_55, uint32_t  p_56, uint32_t  p_57, int16_t  p_58)
{ /* block id: 30 */
    uint32_t l_62 = 0x30D26BC8L;
    int32_t l_63 = 0xDE0F7F7AL;
    int32_t l_90[4][8][1] = {{{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L},{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L}},{{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L},{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L}},{{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L},{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L}},{{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L},{(-7L)},{0x2EE8FFC0L},{0x0F1F8A70L},{0x2EE8FFC0L}}};
    int i, j, k;
    l_63 = (safe_mul_func_uint16_t_u_u(l_62, 0xECDEL));
    for (l_62 = (-3); (l_62 <= 48); l_62 = safe_add_func_uint8_t_u_u(l_62, 1))
    { /* block id: 34 */
        uint8_t l_66[5];
        int32_t l_85 = 0x418CD0E5L;
        int32_t l_91 = 0xC9215A14L;
        int32_t l_96 = 0xD514EF7FL;
        int32_t l_98 = (-1L);
        int32_t l_99 = 8L;
        int32_t l_101 = 0x2C3BF42EL;
        int32_t l_102 = (-6L);
        int32_t l_104 = 0x7DDA2347L;
        int32_t l_105 = 5L;
        int32_t l_107 = (-1L);
        int32_t l_109 = 0x0E459F6DL;
        int32_t l_111 = (-1L);
        int32_t l_112[10][5][5] = {{{(-3L),(-1L),0x957E0FD4L,0x4F864726L,0xA558AB68L},{(-8L),0xD07ABCEEL,0L,1L,0xA5772CECL},{1L,0x3748BFE3L,0x0C9214CFL,1L,0xA5772CECL},{1L,0x4F864726L,0L,(-6L),0xA558AB68L},{0x434A8DDDL,0x4D12FDF6L,0x4EBA52E2L,0x175EBDF0L,0x80E96666L}},{{0x1183D2F8L,1L,0xDD1E6761L,0x110A1B7EL,0xA558AB68L},{0x14440822L,0xD4F96F3BL,0x610154D0L,1L,0xA5772CECL},{0x80E96666L,0x143A8C46L,0x7F170005L,0x3B926A7FL,0xA5772CECL},{1L,1L,0x2A1A5AB3L,(-4L),0xA558AB68L},{0x34AC2647L,(-4L),0x9C76D5E0L,0xD07ABCEEL,0x80E96666L}},{{(-10L),1L,0xA48C8D2EL,(-1L),0xA558AB68L},{(-10L),3L,3L,(-1L),0xA5772CECL},{1L,1L,(-4L),0x143A8C46L,0xA5772CECL},{0x82869B1DL,0x110A1B7EL,0x917EEAFCL,0x44E6814EL,0xA558AB68L},{0x0C8CA251L,0x2EAA3756L,(-5L),3L,0x80E96666L}},{{0x66C6174CL,1L,0xE57973F9L,1L,0xA558AB68L},{0L,0x175EBDF0L,1L,1L,0xA5772CECL},{0xA5772CECL,0x4C988BF1L,3L,0x4C988BF1L,0xA5772CECL},{0xDD3C1BD1L,6L,0x72D929A3L,0x4D12FDF6L,0xA558AB68L},{0x8C05660FL,0x44E6814EL,0xAAE2E084L,0x1BF98911L,0x80E96666L}},{{(-1L),0xB5D631B4L,0xCD6F842CL,6L,0xA558AB68L},{0xDFD39EDEL,0x1BF98911L,8L,0xB5D631B4L,0xA5772CECL},{0xA558AB68L,0x3B926A7FL,1L,0x3748BFE3L,0xA5772CECL},{0x3D512287L,(-1L),0x9B19E1A9L,0x2EAA3756L,0xA558AB68L},{0x69A60226L,(-6L),0x3520E672L,0xD4F96F3BL,0x80E96666L}},{{(-3L),(-1L),0x957E0FD4L,0x4F864726L,0xA558AB68L},{(-8L),0xD07ABCEEL,0L,1L,0xA5772CECL},{1L,0x3748BFE3L,0x0C9214CFL,1L,0xA5772CECL},{1L,0x4F864726L,0L,(-6L),0xA558AB68L},{0x434A8DDDL,0x4D12FDF6L,0x4EBA52E2L,0x175EBDF0L,0x80E96666L}},{{0x1183D2F8L,1L,0xDD1E6761L,0x110A1B7EL,0xA558AB68L},{0x14440822L,0xD4F96F3BL,0x610154D0L,0xA304AAC6L,0xB5D631B4L},{1L,8L,0xC4FF355CL,(-3L),0xB5D631B4L},{(-1L),0x076EB19FL,0xDA19A237L,1L,1L},{3L,1L,1L,(-10L),1L}},{{0x4D12FDF6L,5L,0xD414D135L,0x7E7D7187L,1L},{0x3748BFE3L,(-4L),1L,1L,0xB5D631B4L},{1L,0xB4DCC518L,0x716F66F7L,8L,0xB5D631B4L},{0x110A1B7EL,0xFAEDEB9EL,(-8L),0xB0D9EFBCL,1L},{0xD07ABCEEL,8L,0x014FA95BL,(-4L),1L}},{{0x44E6814EL,0xA304AAC6L,0x02ECAC60L,0x076EB19FL,1L},{0x4C988BF1L,0x90E32AAFL,(-1L),5L,0xB5D631B4L},{0xB5D631B4L,0x00C7566DL,1L,0x00C7566DL,0xB5D631B4L},{0x4F864726L,0xC060409BL,0x50F0C8DFL,0x5BA64AAAL,1L},{0x175EBDF0L,0xB0D9EFBCL,0x0FD5536EL,0x636CF237L,1L}},{{(-4L),0x350C07B2L,(-9L),0xC060409BL,1L},{0x143A8C46L,0x636CF237L,1L,0x350C07B2L,0xB5D631B4L},{1L,(-3L),0x1CDEB978L,0L,0xB5D631B4L},{6L,0x7E7D7187L,(-1L),8L,1L},{0xD4F96F3BL,(-3L),0x841C190BL,0xEFE3DBA4L,1L}}};
        uint64_t l_113 = 18446744073709551610UL;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_66[i] = 0xE3L;
        if (l_66[4])
        { /* block id: 35 */
            int16_t l_83 = 0x8D37L;
            const uint16_t l_84[8] = {0xCDB2L,0x4373L,0xCDB2L,0x4373L,0xCDB2L,0x4373L,0xCDB2L,0x4373L};
            int i;
            if (g_2[1][1][1])
                break;
            if (l_66[4])
                continue;
            g_2[1][1][1] = ((safe_rshift_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((g_3 <= p_58), 7)), 1)) || p_54);
            l_85 = (safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u((safe_add_func_uint8_t_u_u((((safe_mul_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(l_66[0], p_58)), p_58)) && g_2[1][1][1]) && l_83), l_84[3])), p_55)) & 0UL), 8UL)), g_3));
        }
        else
        { /* block id: 40 */
            uint32_t l_88 = 0UL;
            int32_t l_89 = 0x2A742272L;
            int32_t l_92 = (-2L);
            int32_t l_93 = (-4L);
            int32_t l_94 = 1L;
            int32_t l_95 = 0x5734C638L;
            int32_t l_97 = 1L;
            int32_t l_100 = (-8L);
            int32_t l_103 = (-3L);
            int32_t l_106 = 0xF170B72FL;
            int16_t l_108 = 0xDAD0L;
            int32_t l_110[6][5][4] = {{{(-1L),4L,0xCF14D92DL,0x271CF4EEL},{3L,0L,(-1L),0L},{(-9L),(-1L),(-1L),0xCF14D92DL},{0x2D9FAADCL,0x28C401F3L,(-7L),0x8E20B3FDL},{(-1L),(-1L),(-1L),4L}},{{0xA40847A0L,(-9L),0xA40847A0L,(-7L)},{0xAC9C96BAL,(-1L),(-9L),(-1L)},{0L,0xEED5AC3CL,0x8E20B3FDL,(-1L)},{0xC6A208CAL,(-8L),0x8E20B3FDL,0L},{0L,0xFEE1C1FAL,(-9L),1L}},{{0xAC9C96BAL,3L,0xA40847A0L,7L},{0xA40847A0L,7L,(-1L),0xFEE1C1FAL},{(-1L),0xC6A208CAL,(-7L),(-7L)},{0x2D9FAADCL,0x2D9FAADCL,(-1L),3L},{(-9L),(-7L),(-1L),(-1L)}},{{3L,1L,0xCF14D92DL,(-1L)},{(-1L),1L,(-8L),(-1L)},{1L,(-7L),0xC6A208CAL,3L},{4L,0x2D9FAADCL,0x28C401F3L,(-7L)},{0xCF14D92DL,0xC6A208CAL,4L,0xFEE1C1FAL}},{{0x28C401F3L,7L,0xAC9C96BAL,7L},{(-1L),3L,0xFEE1C1FAL,1L},{0L,0xFEE1C1FAL,(-1L),0L},{0xC6A208CAL,(-9L),3L,7L},{0xC6A208CAL,(-7L),1L,0x2D9FAADCL}},{{(-1L),7L,0x271CF4EEL,(-8L)},{0x30BDFC58L,0xCF14D92DL,(-1L),0x8E20B3FDL},{0L,1L,0x8E20B3FDL,0xE6FF6BB9L},{0x28C401F3L,0L,0L,0x28C401F3L},{0xFEE1C1FAL,4L,(-7L),(-1L)}}};
            int i, j, k;
            g_2[1][1][1] = (0x06L ^ p_58);
            l_89 = ((safe_add_func_int32_t_s_s((((p_57 , l_88) | g_2[1][5][0]) != l_88), 0x7E6262DCL)) != g_3);
            ++l_113;
            g_2[1][1][1] = ((p_57 || p_54) < 247UL);
        }
    }
    return l_62;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_144, "g_144", print_hash_value);
    transparent_crc(g_189, "g_189", print_hash_value);
    transparent_crc(g_231, "g_231", print_hash_value);
    transparent_crc(g_247, "g_247", print_hash_value);
    transparent_crc(g_263, "g_263", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 118
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 17
breakdown:
   depth: 1, occurrence: 93
   depth: 2, occurrence: 23
   depth: 3, occurrence: 7
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 3
   depth: 7, occurrence: 1
   depth: 8, occurrence: 4
   depth: 10, occurrence: 2
   depth: 11, occurrence: 1
   depth: 17, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 147
XXX times a non-volatile is write: 56
XXX times a volatile is read: 14
XXX    times read thru a pointer: 0
XXX times a volatile is write: 8
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 227
XXX percentage of non-volatile access: 90.2

XXX forward jumps: 2
XXX backward jumps: 2

XXX stmts: 94
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 19
   depth: 1, occurrence: 33
   depth: 2, occurrence: 42

XXX percentage a fresh-made variable is used: 17.9
XXX percentage an existing variable is used: 82.1
********************* end of statistics **********************/

