/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13999081160106239785
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint16_t  f0;
   volatile uint32_t  f1;
   volatile uint8_t  f2;
   const uint64_t  f3;
   uint16_t  f4;
   const volatile int32_t  f5;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_7 = 18446744073709551615UL;
static volatile int64_t g_9 = 0x941FC9A57B5BF2D3LL;/* VOLATILE GLOBAL g_9 */
static volatile uint16_t g_10[3] = {0x4D14L,0x4D14L,0x4D14L};
static volatile int32_t g_13 = 1L;/* VOLATILE GLOBAL g_13 */
static volatile int64_t g_14 = 0x49B76EEA53061ECELL;/* VOLATILE GLOBAL g_14 */
static volatile uint32_t g_15 = 1UL;/* VOLATILE GLOBAL g_15 */
static uint16_t g_34 = 6UL;
static struct S0 g_37 = {0xD6C8L,2UL,0x8FL,0xBEC767DBF12959AFLL,0xC67AL,1L};/* VOLATILE GLOBAL g_37 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, int32_t  p_5);
static struct S0  func_18(int32_t  p_19, uint8_t  p_20);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_10 g_15 g_13 g_14 g_34 g_37 g_9
 * writes: g_10 g_15 g_13 g_34
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_6 = 8UL;
    int32_t l_39 = 1L;
    g_13 = (func_2(l_6, g_7, g_7) || l_6);
    if (l_6)
    { /* block id: 7 */
        int64_t l_38[5] = {3L,3L,3L,3L,3L};
        int i;
        l_39 = (func_2((func_18(l_6, g_7) , g_9), l_38[3], g_37.f3) || l_38[2]);
        l_39 &= ((l_38[3] ^ 0xAE7762969FBC0AE2LL) & 6UL);
    }
    else
    { /* block id: 27 */
        int8_t l_44 = 0xCAL;
        g_13 = ((safe_div_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u((255UL != g_37.f0), l_44)), 0xC18CL)) , g_37.f2);
        return g_37.f1;
    }
    g_13 ^= 1L;
    l_39 = (safe_add_func_uint64_t_u_u(0x1DABEE07F0936A74LL, 0xBF646D9140931BC1LL));
    return g_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_15
 * writes: g_10 g_15
 */
static int32_t  func_2(int32_t  p_3, uint32_t  p_4, int32_t  p_5)
{ /* block id: 1 */
    int32_t l_8 = 0x2276B87DL;
    --g_10[2];
    ++g_15;
    l_8 = l_8;
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_13 g_14 g_10 g_34 g_37
 * writes: g_13 g_34
 */
static struct S0  func_18(int32_t  p_19, uint8_t  p_20)
{ /* block id: 8 */
    uint16_t l_25 = 0x0670L;
    int32_t l_26 = 8L;
    uint32_t l_27 = 4294967289UL;
    g_13 |= ((safe_add_func_int32_t_s_s(g_7, 1L)) ^ 0x8217C7128ABF8B24LL);
    l_26 |= (safe_div_func_uint64_t_u_u(((p_19 , g_14) > l_25), g_7));
    ++l_27;
    for (l_26 = 2; (l_26 >= 0); l_26 -= 1)
    { /* block id: 14 */
        for (l_27 = 0; (l_27 <= 2); l_27 += 1)
        { /* block id: 17 */
            int32_t l_32 = 0L;
            int32_t l_33[5] = {(-3L),(-3L),(-3L),(-3L),(-3L)};
            int i;
            p_19 &= (safe_mod_func_int8_t_s_s(g_10[l_26], p_20));
            if (p_20)
                break;
            --g_34;
        }
        p_19 ^= (g_34 && p_20);
    }
    return g_37;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_9, "g_9", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_10[i], "g_10[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_37.f0, "g_37.f0", print_hash_value);
    transparent_crc(g_37.f1, "g_37.f1", print_hash_value);
    transparent_crc(g_37.f2, "g_37.f2", print_hash_value);
    transparent_crc(g_37.f3, "g_37.f3", print_hash_value);
    transparent_crc(g_37.f4, "g_37.f4", print_hash_value);
    transparent_crc(g_37.f5, "g_37.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 17
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 27
   depth: 2, occurrence: 5
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 25
XXX times a non-volatile is write: 11
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 28
XXX percentage of non-volatile access: 73.5

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 23
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 6
   depth: 2, occurrence: 3

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
********************* end of statistics **********************/

