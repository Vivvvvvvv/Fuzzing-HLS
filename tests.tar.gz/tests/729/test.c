/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      12029760426941933021
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2[8][4][7] = {{{0xF4B3F4B1L,(-9L),1L,(-10L),1L,(-1L),0xC7279C90L},{(-1L),0x4185A1FAL,0x7F5AEE0CL,1L,0x4185A1FAL,1L,(-1L)},{(-1L),0xF4B3F4B1L,0xB2F67AB6L,(-9L),(-3L),0xE7ED6F18L,0xE1A812C0L},{0xF4B3F4B1L,(-1L),0x69EC4279L,0L,0x0FE1CA29L,0xB6FE6D39L,(-3L)}},{{0x0FE1CA29L,(-1L),1L,0x151C8B9BL,0x151C8B9BL,1L,(-1L)},{0xC29478C9L,0x80643B8AL,(-10L),0x6E871D97L,0x9796A0B5L,1L,8L},{0L,(-9L),0x69EC4279L,(-1L),(-10L),0x0176DF7EL,5L},{0L,0xB2F67AB6L,0xE1A812C0L,0x4B969B42L,0x80643B8AL,0x4185A1FAL,0x4B969B42L}},{{0x9796A0B5L,5L,1L,(-1L),(-5L),6L,0xE7ED6F18L},{0xDC6D0F06L,1L,1L,5L,(-10L),0x47B80BE3L,(-9L)},{0x837BC752L,0x00CA3C47L,(-9L),(-1L),0L,(-1L),0xF4B3F4B1L},{(-1L),1L,5L,0x9796A0B5L,(-1L),(-5L),0xF4B3F4B1L}},{{1L,0x69EC4279L,0x307B5CA9L,0xC70BB743L,0xF4B3F4B1L,0x0176DF7EL,(-9L)},{0xB2F67AB6L,0x80643B8AL,0x0FE1CA29L,(-3L),0xCD953295L,0L,0xE7ED6F18L},{0x4B969B42L,0xC70BB743L,0x47B80BE3L,0xE7ED6F18L,0x47B80BE3L,0xC70BB743L,0x4B969B42L},{(-1L),0L,(-9L),6L,0x9796A0B5L,1L,5L}},{{0x837BC752L,0x80643B8AL,(-1L),1L,0xE7ED6F18L,(-1L),0x69EC4279L},{(-1L),0xC6088B92L,(-9L),(-1L),0xC70BB743L,0x7F5AEE0CL,1L},{1L,0x9796A0B5L,0x47B80BE3L,0x7F5AEE0CL,0x00CA3C47L,0x307B5CA9L,0x1F2E9667L},{0L,0x00CA3C47L,0x0FE1CA29L,1L,0x837BC752L,0xE1A812C0L,0x80643B8AL}},{{(-3L),0x0176DF7EL,0x307B5CA9L,0xF4B3F4B1L,1L,1L,0x00CA3C47L},{0xFFBE5849L,0x837BC752L,5L,0xFFBE5849L,0L,1L,0xBD004DDEL},{0xF4B3F4B1L,0xB2F67AB6L,(-9L),(-3L),0xE7ED6F18L,0xE1A812C0L,(-1L)},{1L,0xDC6D0F06L,1L,0L,1L,0x307B5CA9L,0L}},{{0x7F5AEE0CL,0xC7279C90L,1L,1L,0xC7279C90L,0x7F5AEE0CL,1L},{(-1L),1L,0xE1A812C0L,(-1L),0xCD953295L,(-1L),0x80643B8AL},{1L,0xBD004DDEL,(-5L),0x837BC752L,6L,1L,0xCD953295L},{6L,1L,0xC70BB743L,(-1L),(-1L),0xC70BB743L,(-9L)}},{{0xE7ED6F18L,0xC7279C90L,0x0D2F38D9L,0x4B969B42L,0L,0L,0x69EC4279L},{(-3L),0xDC6D0F06L,(-5L),0xB2F67AB6L,1L,0x0176DF7EL,0x837BC752L},{0xC70BB743L,0xB2F67AB6L,0xC6088B92L,1L,0x80643B8AL,(-5L),1L},{0x9796A0B5L,0x837BC752L,0xBFBD3AEBL,(-1L),0x80643B8AL,(-1L),0xE7ED6F18L}}};
static volatile int32_t g_3 = (-10L);/* VOLATILE GLOBAL g_3 */
static volatile int32_t g_4 = 0xEB300A9EL;/* VOLATILE GLOBAL g_4 */
static int32_t g_5 = 0xE1C2A911L;
static int64_t g_17 = 0xEB8A064F5774D2ADLL;
static int8_t g_18 = (-2L);
static int64_t g_87 = 0x93EF347DC9BE9680LL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int8_t  func_11(uint32_t  p_12, int16_t  p_13, const int32_t  p_14);
static int64_t  func_26(uint32_t  p_27, uint32_t  p_28, int8_t  p_29, uint32_t  p_30, int8_t  p_31);
static int64_t  func_36(int8_t  p_37, const int32_t  p_38, int32_t  p_39);
static const int64_t  func_63(uint16_t  p_64, uint8_t  p_65, int16_t  p_66);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_2 g_4 g_17 g_3 g_18 g_87
 * writes: g_5 g_17 g_18 g_2 g_87
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_21[6][9][4] = {{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}},{{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}}};
    int i, j, k;
    for (g_5 = 0; (g_5 != (-29)); --g_5)
    { /* block id: 3 */
        uint64_t l_8 = 18446744073709551615UL;
        int32_t l_10 = 0x5A955069L;
        if (l_8)
        { /* block id: 4 */
            uint32_t l_9 = 0x14356E3FL;
            l_10 = ((g_2[7][2][6] != l_8) || l_9);
            g_18 ^= (func_11(g_2[2][3][4], g_5, l_8) , g_3);
            l_21[2][2][3] = (g_18 == 0UL);
        }
        else
        { /* block id: 11 */
            return g_18;
        }
    }
    if ((((safe_mod_func_int32_t_s_s((safe_lshift_func_int8_t_s_s((((func_26(((func_11((g_5 > (-10L)), l_21[2][2][3], l_21[1][0][2]) , 18446744073709551607UL) | g_18), g_18, l_21[2][6][3], l_21[2][2][3], l_21[3][0][3]) , g_2[0][1][3]) & 0xBA86L) | 0x11B60CE2261CAE20LL), 2)), g_87)) > g_87) && g_18))
    { /* block id: 70 */
        for (g_87 = (-23); (g_87 <= 26); g_87 = safe_add_func_uint16_t_u_u(g_87, 6))
        { /* block id: 73 */
            int32_t l_92[1][7][2] = {{{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L},{1L,1L}}};
            int i, j, k;
            l_92[0][6][0] = (g_5 ^ 0L);
            g_5 = g_2[6][0][2];
            g_2[6][1][4] = ((g_3 | g_5) || l_92[0][1][0]);
        }
    }
    else
    { /* block id: 78 */
        const uint16_t l_93 = 65527UL;
        int32_t l_94 = 0xCD8C2604L;
        for (g_17 = 3; (g_17 >= 0); g_17 -= 1)
        { /* block id: 81 */
            l_94 = ((l_21[2][2][3] <= 0xA1L) && l_93);
            g_5 = g_2[0][0][0];
        }
    }
    return g_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_5 g_17
 * writes: g_17
 */
static int8_t  func_11(uint32_t  p_12, int16_t  p_13, const int32_t  p_14)
{ /* block id: 6 */
    g_17 ^= ((((safe_mul_func_uint8_t_u_u((65530UL || g_4), 0x83L)) , p_12) & p_12) == g_5);
    return g_4;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_4 g_18 g_5 g_2
 * writes: g_5 g_17 g_18 g_2
 */
static int64_t  func_26(uint32_t  p_27, uint32_t  p_28, int8_t  p_29, uint32_t  p_30, int8_t  p_31)
{ /* block id: 15 */
    int32_t l_42 = 6L;
    int32_t l_61 = (-1L);
    for (p_29 = 0; (p_29 > (-23)); p_29--)
    { /* block id: 18 */
        uint16_t l_58 = 0xFD92L;
        int32_t l_86 = 0x7A05A861L;
        g_5 = (g_17 | g_4);
        l_58 = ((safe_sub_func_int64_t_s_s(func_36((safe_sub_func_int32_t_s_s(g_4, p_29)), p_30, l_42), 1UL)) , g_5);
        for (g_18 = 0; (g_18 > (-27)); g_18 = safe_sub_func_int16_t_s_s(g_18, 1))
        { /* block id: 41 */
            if (l_58)
                break;
        }
        if (p_27)
        { /* block id: 44 */
            uint32_t l_62 = 4294967295UL;
            l_61 = 0x600A8D5EL;
            l_62 |= (p_28 | p_31);
        }
        else
        { /* block id: 47 */
            if (g_17)
                break;
            g_2[6][3][4] ^= 0x56EC41C9L;
            l_86 = ((func_63((safe_sub_func_uint8_t_u_u(((safe_sub_func_int8_t_s_s(0x44L, p_29)) & 0xD838L), g_2[6][1][0])), l_58, l_61) && g_2[2][3][4]) <= 0xE7L);
        }
    }
    return p_27;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_18
 * writes: g_17 g_18
 */
static int64_t  func_36(int8_t  p_37, const int32_t  p_38, int32_t  p_39)
{ /* block id: 20 */
    uint16_t l_46[7][4][2] = {{{0UL,0UL},{0UL,1UL},{0x9D77L,0x84C1L},{1UL,0x84C1L}},{{0x9D77L,1UL},{0UL,0UL},{0UL,1UL},{0x9D77L,0x84C1L}},{{1UL,0x84C1L},{0x9D77L,1UL},{0UL,0UL},{0UL,1UL}},{{0x9D77L,0x84C1L},{1UL,0x84C1L},{0x9D77L,1UL},{0UL,0UL}},{{0UL,1UL},{0x9D77L,0x84C1L},{1UL,0x84C1L},{0x9D77L,1UL}},{{0UL,0UL},{0UL,1UL},{0x9D77L,0x84C1L},{1UL,0x84C1L}},{{0x9D77L,1UL},{0UL,0UL},{0UL,1UL},{0x9D77L,0x84C1L}}};
    int32_t l_47 = (-10L);
    int32_t l_52 = 7L;
    int32_t l_53 = 1L;
    int i, j, k;
    for (g_17 = 3; (g_17 >= 0); g_17 -= 1)
    { /* block id: 23 */
        int16_t l_49 = 5L;
        int32_t l_54[7] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
        int i;
        for (p_39 = 0; (p_39 <= 3); p_39 += 1)
        { /* block id: 26 */
            uint8_t l_43 = 7UL;
            l_43++;
            return p_38;
        }
        l_46[0][1][1] = p_38;
        for (g_18 = 3; (g_18 >= 0); g_18 -= 1)
        { /* block id: 33 */
            int8_t l_48[1];
            int32_t l_50 = 4L;
            int32_t l_51[4][8] = {{(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L},{(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L},{(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L},{(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L,(-1L),0xE7CE9F33L}};
            uint32_t l_55 = 0x3870AF1AL;
            int i, j;
            for (i = 0; i < 1; i++)
                l_48[i] = 0x98L;
            ++l_55;
        }
    }
    return p_38;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_17 g_18 g_4 g_5
 * writes: g_2
 */
static const int64_t  func_63(uint16_t  p_64, uint8_t  p_65, int16_t  p_66)
{ /* block id: 50 */
    uint32_t l_75 = 8UL;
    int64_t l_76 = 0L;
    int32_t l_79 = 0x3E099908L;
lbl_85:
    g_2[2][3][4] = (((safe_sub_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(((g_2[2][3][4] , l_75) && 9UL), l_76)), l_75)) != p_65) > p_65);
    for (p_65 = 0; (p_65 <= 3); p_65 += 1)
    { /* block id: 54 */
        uint8_t l_80 = 0x39L;
        int32_t l_84 = 0L;
        l_79 ^= (safe_lshift_func_int8_t_s_s(p_66, 7));
        l_79 = ((((g_17 ^ g_2[2][3][4]) | g_18) < l_80) < l_75);
        for (l_76 = 0; (l_76 <= 3); l_76 += 1)
        { /* block id: 59 */
            uint64_t l_83 = 0x15B557241B9AD149LL;
            l_84 = ((((safe_add_func_int16_t_s_s((l_80 > p_66), l_83)) >= g_4) == g_5) , p_64);
            l_79 = l_84;
        }
    }
    if (g_18)
        goto lbl_85;
    return g_4;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2[i][j][k], "g_2[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_87, "g_87", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 32
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 43
   depth: 2, occurrence: 15
   depth: 3, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 9, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 70
XXX times a non-volatile is write: 30
XXX times a volatile is read: 17
XXX    times read thru a pointer: 0
XXX times a volatile is write: 3
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 54
XXX percentage of non-volatile access: 83.3

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 46
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 13
   depth: 2, occurrence: 20

XXX percentage a fresh-made variable is used: 27.6
XXX percentage an existing variable is used: 72.4
********************* end of statistics **********************/

