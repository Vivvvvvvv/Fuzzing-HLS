/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      3702070919093322342
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int8_t g_8 = 0xC1L;
static uint8_t g_18 = 0xA7L;
static int8_t g_21 = 0xA5L;
static volatile int32_t g_38[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
static int64_t g_211 = 0x32750AFB25AEB332LL;
static volatile int8_t g_222[6][2] = {{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L},{0L,0L}};
static int32_t g_287[3][2] = {{(-1L),(-1L)},{(-1L),(-1L)},{(-1L),(-1L)}};


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint16_t  func_2(int32_t  p_3, uint32_t  p_4, int8_t  p_5, int32_t  p_6);
static int32_t  func_26(int16_t  p_27, uint32_t  p_28, int64_t  p_29);
static uint64_t  func_45(uint64_t  p_46, uint16_t  p_47, int8_t  p_48, const int32_t  p_49, int32_t  p_50);
static int32_t  func_60(int32_t  p_61);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_8 g_18 g_21 g_38 g_211 g_222 g_287
 * writes: g_18 g_21 g_38 g_8 g_211
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_7 = 4294967289UL;
    uint16_t l_213 = 7UL;
    int16_t l_223[8] = {0L,0x1008L,0L,0x1008L,0L,0x1008L,0L,0x1008L};
    int32_t l_261[7] = {2L,2L,2L,2L,2L,2L,2L};
    int i;
    g_38[0] = (((func_2(l_7, g_8, l_7, g_8) <= l_7) , g_21) > g_211);
    if (l_7)
    { /* block id: 140 */
        int32_t l_212 = 0x1268E6D0L;
        int8_t l_240 = 3L;
        int32_t l_247 = (-6L);
        l_213--;
        if (g_211)
            goto lbl_264;
        if ((safe_add_func_uint64_t_u_u(l_213, g_211)))
        { /* block id: 142 */
            uint32_t l_224[4][5] = {{3UL,3UL,0x6DF9734EL,0x6DF9734EL,3UL},{18446744073709551610UL,0x5486D1CCL,18446744073709551610UL,0x5486D1CCL,18446744073709551610UL},{3UL,0x6DF9734EL,0x6DF9734EL,3UL,3UL},{0xB272FC51L,0x5486D1CCL,0xB272FC51L,0x5486D1CCL,0xB272FC51L}};
            int32_t l_241 = 0x2B58F86EL;
            int i, j;
            g_38[0] &= (((safe_div_func_int16_t_s_s(((safe_div_func_int16_t_s_s(((-1L) >= 8UL), 65530UL)) || (-2L)), g_18)) > 0xCC242C42L) ^ 7L);
            l_224[3][3]--;
            l_241 = (safe_mul_func_uint16_t_u_u((safe_rshift_func_int8_t_s_u(((safe_mod_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s((safe_mod_func_uint8_t_u_u((~l_240), (-1L))), 5)), 0x07L)), l_212)) != g_8), l_240)), 1UL));
            l_247 = (safe_rshift_func_int16_t_s_s((safe_mul_func_int16_t_s_s(((~l_213) <= g_21), g_38[0])), 0));
        }
        else
        { /* block id: 147 */
            l_247 = (safe_add_func_uint32_t_u_u(((safe_mul_func_int16_t_s_s(0L, 0x5C07L)) , 4294967292UL), 0x1DE2C0B9L));
        }
        return g_21;
    }
    else
    { /* block id: 151 */
        g_38[4] = (safe_sub_func_int16_t_s_s(g_38[0], (-8L)));
    }
    if (((safe_lshift_func_uint8_t_u_u((((safe_lshift_func_uint16_t_u_s(l_223[3], 12)) == 0x053E8E71L) , 0x0AL), g_8)) <= 0x39DCL))
    { /* block id: 154 */
        l_261[6] = (safe_add_func_uint16_t_u_u((+g_222[5][0]), l_213));
        if ((255UL ^ 0xE6L))
        { /* block id: 156 */
lbl_264:
            l_261[2] = (safe_mul_func_uint16_t_u_u(0x56D3L, l_261[6]));
            l_261[6] = (g_38[3] > 0x4904L);
            g_38[0] |= 0x4C7C6743L;
        }
        else
        { /* block id: 161 */
            int8_t l_273 = (-1L);
            g_38[1] &= (safe_div_func_int16_t_s_s((safe_sub_func_int32_t_s_s((safe_lshift_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((0x787415AF54D6FE35LL == l_273), g_18)) ^ 0x7BD2L), 3)), 0xAC14F028L)), 0x3001L));
        }
    }
    else
    { /* block id: 164 */
        int32_t l_274[2];
        int i;
        for (i = 0; i < 2; i++)
            l_274[i] = 0L;
        l_274[0] ^= 0x2672E03BL;
        for (g_211 = 0; (g_211 <= 1); g_211 += 1)
        { /* block id: 168 */
            int i;
            l_274[0] = (l_274[g_211] , g_211);
            return g_222[1][1];
        }
    }
    for (l_7 = 0; (l_7 < 54); l_7 = safe_add_func_int16_t_s_s(l_7, 8))
    { /* block id: 175 */
        uint16_t l_279 = 65529UL;
        int8_t l_286 = (-1L);
        for (l_213 = 0; (l_213 != 28); l_213++)
        { /* block id: 178 */
            g_38[2] = (((l_279 & l_279) || 0x8A50L) && l_223[5]);
            return g_222[5][0];
        }
        for (g_18 = 0; (g_18 >= 52); g_18 = safe_add_func_int32_t_s_s(g_18, 6))
        { /* block id: 184 */
            g_38[2] = (safe_rshift_func_uint8_t_u_u(((((safe_mod_func_uint64_t_u_u(0x8F2E103A3FB9E2A9LL, g_222[1][1])) , 0L) ^ l_286) == g_18), 4));
            if (g_38[1])
                break;
        }
    }
    return g_287[1][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_8 g_21 g_38
 * writes: g_18 g_21 g_38 g_8
 */
static uint16_t  func_2(int32_t  p_3, uint32_t  p_4, int8_t  p_5, int32_t  p_6)
{ /* block id: 1 */
    int32_t l_12 = 0x95768819L;
    int32_t l_210 = 0x03692621L;
    l_12 = (+(safe_add_func_uint64_t_u_u(l_12, 18446744073709551615UL)));
    for (p_4 = (-12); (p_4 <= 41); p_4 = safe_add_func_uint64_t_u_u(p_4, 2))
    { /* block id: 5 */
        uint32_t l_22 = 4294967292UL;
        uint16_t l_30 = 0UL;
        uint64_t l_31[10] = {0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL,0x7BB1A88AF16DE6EALL};
        int32_t l_209[6][4][5] = {{{0x9B94AA32L,0x7281CC88L,0L,0xB7A19678L,0x9D39CA9CL},{3L,(-1L),8L,0xA21F489CL,0xA21F489CL},{0L,(-4L),0L,0x9D39CA9CL,0xB7A19678L},{3L,0xC80131C0L,0L,0xA21F489CL,0x8A76D6EEL}},{{0x9B94AA32L,(-4L),(-2L),0xB7A19678L,0xB7A19678L},{0L,(-1L),0L,0x8A76D6EEL,0xA21F489CL},{0x9B94AA32L,0x7281CC88L,0L,0xB7A19678L,0x9D39CA9CL},{3L,(-1L),8L,0xA21F489CL,0xA21F489CL}},{{0L,(-4L),0L,0x9D39CA9CL,0xB7A19678L},{3L,0xC80131C0L,0L,0xA21F489CL,0x8A76D6EEL},{0x9B94AA32L,(-4L),(-2L),0xB7A19678L,0xB7A19678L},{0L,(-1L),0L,0x8A76D6EEL,0xA21F489CL}},{{0x9B94AA32L,0x7281CC88L,0L,0xB7A19678L,0x9D39CA9CL},{3L,(-1L),8L,0xA21F489CL,0xA21F489CL},{0L,(-4L),0L,0x9D39CA9CL,0xB7A19678L},{3L,0xC80131C0L,0L,0xA21F489CL,0x8A76D6EEL}},{{0x9B94AA32L,(-4L),(-2L),0xB7A19678L,0xB7A19678L},{0L,(-1L),0L,0x8A76D6EEL,0xA21F489CL},{0x9B94AA32L,0x7281CC88L,0L,0xB7A19678L,0x9D39CA9CL},{3L,(-1L),8L,0xA21F489CL,0xA21F489CL}},{{0L,(-4L),0L,0x9D39CA9CL,0xB7A19678L},{3L,0xC80131C0L,0L,0xA21F489CL,0x8A76D6EEL},{0x9B94AA32L,(-4L),(-2L),0xB7A19678L,0xB7A19678L},{0L,(-1L),0L,0x8A76D6EEL,0xA21F489CL}}};
        int i, j, k;
        for (p_3 = 0; (p_3 == (-26)); --p_3)
        { /* block id: 8 */
            int16_t l_17 = 0x9C71L;
            int32_t l_23 = 0x1B0FE2CFL;
            g_18--;
            g_21 = p_5;
            l_12 = (-6L);
            l_23 = ((((l_22 , p_4) , 6L) != g_8) | 1UL);
        }
        for (p_6 = 0; (p_6 <= 11); p_6++)
        { /* block id: 16 */
            if (g_21)
                break;
            l_209[3][2][3] = (func_26(l_30, l_31[6], g_8) != 0x365824EBL);
            g_38[0] = (g_18 | l_22);
        }
        l_209[3][2][3] = ((-1L) > g_38[0]);
    }
    return l_210;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_38 g_8 g_18
 * writes: g_21 g_38 g_18 g_8
 */
static int32_t  func_26(int16_t  p_27, uint32_t  p_28, int64_t  p_29)
{ /* block id: 18 */
    int32_t l_32 = 0xE50714BAL;
    int32_t l_40[8][2] = {{0L,(-5L)},{0xAEE51190L,(-5L)},{0L,0xAEE51190L},{(-7L),(-7L)},{(-7L),0xAEE51190L},{0L,(-5L)},{0xAEE51190L,(-5L)},{0L,0xAEE51190L}};
    int16_t l_205 = 0xD3DDL;
    uint8_t l_206[6];
    int i, j;
    for (i = 0; i < 6; i++)
        l_206[i] = 0x90L;
    if (l_32)
    { /* block id: 19 */
        uint8_t l_42 = 0x22L;
        for (g_21 = (-8); (g_21 < (-26)); --g_21)
        { /* block id: 22 */
            int32_t l_35 = (-8L);
            int32_t l_36 = (-3L);
            int32_t l_37 = 0xBCA3396DL;
            int32_t l_39 = 0x71CF717CL;
            int32_t l_41 = 6L;
            ++l_42;
            g_38[3] = (func_45((safe_mul_func_uint16_t_u_u((0x19AC4E69L < 0x75F7F777L), 0xFDA6L)), g_38[0], g_8, g_18, g_18) <= g_21);
            g_38[0] = 4L;
        }
    }
    else
    { /* block id: 121 */
        int8_t l_199 = 0x2CL;
        for (g_21 = 12; (g_21 > (-19)); g_21--)
        { /* block id: 124 */
            int16_t l_191 = 1L;
            int32_t l_200[1];
            int64_t l_204 = 1L;
            int i;
            for (i = 0; i < 1; i++)
                l_200[i] = 0x03560D2BL;
            l_191 = (safe_rshift_func_uint8_t_u_s(g_21, g_18));
            if (l_40[7][1])
                continue;
            l_200[0] = (!((safe_div_func_uint64_t_u_u(((safe_div_func_uint64_t_u_u(((((safe_lshift_func_int16_t_s_u(((l_199 && g_38[0]) && l_199), l_40[0][1])) <= l_40[5][0]) <= 18446744073709551612UL) || p_29), g_8)) || g_21), 6L)) < 0xB2L));
            l_200[0] = ((((safe_mod_func_uint8_t_u_u((+p_29), l_204)) , p_27) , g_38[3]) < l_205);
        }
    }
    ++l_206[2];
    return l_205;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_38 g_8 g_18
 * writes: g_38 g_18 g_8
 */
static uint64_t  func_45(uint64_t  p_46, uint16_t  p_47, int8_t  p_48, const int32_t  p_49, int32_t  p_50)
{ /* block id: 24 */
    int32_t l_57[2][7][9] = {{{0xA23986B2L,(-1L),(-7L),4L,0x6C2CF376L,5L,0L,(-2L),0x5AB2A44BL},{(-3L),(-2L),4L,0x5799D45EL,0x6C2CF376L,0x816884ADL,0x52A55CCBL,(-1L),0x52A55CCBL},{0xDE1722BBL,0xC3E505CEL,4L,4L,0xC3E505CEL,0xDE1722BBL,2L,0L,(-1L)},{0xDE1722BBL,(-2L),(-7L),0x5AAE70C3L,(-1L),0x086CC6B0L,1L,(-7L),1L},{0x239D1334L,0x70DAEE1FL,1L,0x288A3D85L,0x5AAE70C3L,0x2AFB55E8L,0x60D197A0L,0x70DAEE1FL,1L},{0x35DF961DL,(-7L),1L,0x288A3D85L,0x70DAEE1FL,3L,1L,0xA7F794FCL,0xE8CFB996L},{0x2AFB55E8L,(-7L),1L,0xA2E206C1L,4L,0x8FD23203L,7L,4L,0xE8CFB996L}},{{0x35DF961DL,0x70DAEE1FL,7L,0xC8506302L,3L,0L,7L,0xA7F794FCL,1L},{0x239D1334L,0xA7F794FCL,0xC8506302L,1L,3L,0x8FD23203L,1L,0x70DAEE1FL,1L},{3L,4L,0xC8506302L,0xC8506302L,4L,3L,0x60D197A0L,(-7L),1L},{3L,0xA7F794FCL,7L,0xA2E206C1L,0x70DAEE1FL,0x2AFB55E8L,1L,(-7L),1L},{0x239D1334L,0x70DAEE1FL,1L,0x288A3D85L,0x5AAE70C3L,0x2AFB55E8L,0x60D197A0L,0x70DAEE1FL,1L},{0x35DF961DL,(-7L),1L,0x288A3D85L,0x70DAEE1FL,3L,1L,0xA7F794FCL,0xE8CFB996L},{0x2AFB55E8L,(-7L),1L,0xA2E206C1L,4L,0x8FD23203L,7L,4L,0xE8CFB996L}}};
    int32_t l_158[9][9] = {{0x2DB0CE19L,(-1L),0x2DB0CE19L,0x4C6000C4L,0x14E0177BL,0x14E0177BL,0x4C6000C4L,0x2DB0CE19L,(-1L)},{0xCB42118BL,0x407BC3B0L,0x1E35D45CL,1L,(-4L),1L,(-2L),0xE97851F5L,(-2L)},{(-1L),(-10L),0x4C6000C4L,0x4C6000C4L,(-10L),(-1L),0x14E0177BL,(-1L),(-10L)},{0x27DD60BBL,0x407BC3B0L,(-2L),0x1DECDD12L,0xCB42118BL,(-1L),0xCB42118BL,0x1DECDD12L,(-2L)},{(-1L),(-1L),0x14E0177BL,(-10L),5L,(-10L),0x14E0177BL,(-1L),(-1L)},{(-2L),0x1DECDD12L,0xCB42118BL,(-1L),0xCB42118BL,0x1DECDD12L,(-2L),0x407BC3B0L,0x27DD60BBL},{(-10L),(-1L),0x14E0177BL,(-1L),(-10L),0x4C6000C4L,0x4C6000C4L,(-10L),(-1L)},{(-2L),0xE97851F5L,(-2L),1L,(-4L),1L,0x1E35D45CL,0x407BC3B0L,0xCB42118BL},{(-1L),0x2DB0CE19L,0x4C6000C4L,0x14E0177BL,0x14E0177BL,0x4C6000C4L,0x2DB0CE19L,(-1L),0x2DB0CE19L}};
    int i, j, k;
lbl_153:
    g_38[0] = (safe_rshift_func_uint16_t_u_u(((safe_lshift_func_int8_t_s_s((0x5470E987L ^ p_50), l_57[1][4][4])) || p_48), 12));
    if ((safe_mod_func_int32_t_s_s(func_60((safe_mod_func_int32_t_s_s((p_46 >= g_21), l_57[1][4][4]))), l_57[1][4][4])))
    { /* block id: 92 */
        int32_t l_147 = 0x32FC06C7L;
        l_147 = (l_57[1][4][4] <= 0xE31AC302L);
        for (g_18 = 0; (g_18 > 36); g_18 = safe_add_func_uint64_t_u_u(g_18, 9))
        { /* block id: 96 */
            uint64_t l_152 = 1UL;
            l_152 = (safe_sub_func_uint64_t_u_u(l_57[1][4][4], l_147));
            if (g_18)
                goto lbl_153;
            l_158[1][7] = ((safe_mul_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_u((((((8L || 0UL) & 1UL) | 0xF995CB7FL) || l_57[1][4][4]) , g_21), 14)) == 0x0EL), g_38[0])) , g_21);
        }
    }
    else
    { /* block id: 101 */
        uint32_t l_165 = 0UL;
        for (p_50 = (-19); (p_50 == (-9)); p_50 = safe_add_func_int8_t_s_s(p_50, 7))
        { /* block id: 104 */
            int32_t l_168 = (-9L);
            if (p_46)
                goto lbl_153;
            g_38[0] = (((safe_mul_func_int8_t_s_s((safe_div_func_int8_t_s_s(0x24L, g_8)), g_8)) == p_48) != l_165);
            l_168 = ((safe_add_func_int32_t_s_s(l_165, p_46)) != g_8);
        }
    }
    l_158[1][7] &= (((safe_mul_func_int8_t_s_s((safe_mod_func_int32_t_s_s((safe_mod_func_int64_t_s_s((safe_add_func_int32_t_s_s(((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u((g_38[0] == g_18), p_48)), 0)) || 0xBFL), 0xFDD9DDBCL)), l_57[1][4][4])), 0x58EEB3F8L)), 0x47L)) || 7UL) != 0xC2BEL);
    for (g_8 = (-10); (g_8 >= 2); g_8 = safe_add_func_int32_t_s_s(g_8, 8))
    { /* block id: 113 */
        p_50 = (safe_add_func_uint16_t_u_u(((safe_rshift_func_int16_t_s_s(g_38[0], g_18)) != g_8), g_21));
        l_158[7][0] &= ((p_48 == p_46) <= 0xBB4FL);
    }
    return p_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_8 g_18 g_21
 * writes: g_18 g_38 g_8
 */
static int32_t  func_60(int32_t  p_61)
{ /* block id: 26 */
    int32_t l_64 = 0x115BA09FL;
    int32_t l_98 = 7L;
    uint32_t l_107 = 4294967295UL;
    int64_t l_108 = 0x3715829BAEFF72AELL;
    const uint32_t l_121[2] = {1UL,1UL};
    int32_t l_129 = 0x8C321860L;
    int32_t l_131 = 0L;
    int32_t l_134 = 0x88B552A0L;
    uint8_t l_144 = 0xF9L;
    int i;
    if ((g_38[0] && l_64))
    { /* block id: 27 */
        for (p_61 = 0; (p_61 < 18); p_61++)
        { /* block id: 30 */
            int32_t l_67 = 0x5FA60710L;
            l_67 = (((0x4AF1L && 0x777EL) >= g_8) , 0L);
            l_64 ^= p_61;
        }
        for (g_18 = 0; (g_18 <= 4); g_18 += 1)
        { /* block id: 36 */
            int i;
            g_38[g_18] = ((safe_mul_func_uint16_t_u_u((g_38[g_18] && g_21), g_21)) <= g_21);
        }
    }
    else
    { /* block id: 39 */
        int64_t l_70 = 0x35785F4F6E08938CLL;
        return l_70;
    }
    if ((safe_div_func_uint32_t_u_u(((safe_mod_func_int32_t_s_s((safe_add_func_int64_t_s_s(((safe_mod_func_int16_t_s_s(((((g_38[3] == 65526UL) < 1L) & (-2L)) > p_61), g_18)) , l_64), l_64)), g_8)) > g_8), 0x768DD0F0L)))
    { /* block id: 42 */
        uint32_t l_83 = 4UL;
        for (g_18 = 22; (g_18 < 34); ++g_18)
        { /* block id: 45 */
            return l_64;
        }
        if ((((safe_mod_func_uint32_t_u_u((((((g_8 && p_61) || l_83) > 0x50866D82068EE181LL) , g_18) ^ l_64), 4294967295UL)) <= g_38[2]) , l_83))
        { /* block id: 48 */
            g_38[0] = (0x36L && (-5L));
            g_38[0] &= (p_61 | 3UL);
        }
        else
        { /* block id: 51 */
            return l_83;
        }
    }
    else
    { /* block id: 54 */
        uint32_t l_93 = 0x05796792L;
        int32_t l_94 = 0x77ACE7FEL;
        int32_t l_99 = 0L;
        uint8_t l_100[2][9][6] = {{{0xBDL,0UL,255UL,0x78L,0x28L,0x62L},{0x31L,255UL,0x82L,0xC6L,0UL,246UL},{0x31L,0x21L,0xB1L,0x28L,0xF2L,0xAFL},{0UL,0xAFL,249UL,255UL,0x13L,7UL},{0x21L,250UL,0x13L,0x43L,7UL,7UL},{252UL,249UL,249UL,252UL,255UL,0xAFL},{3UL,6UL,0xB1L,0x2AL,5UL,0x13L},{0UL,0x4DL,3UL,253UL,5UL,250UL},{248UL,6UL,2UL,255UL,255UL,0x4DL}},{{0x43L,249UL,0xF2L,4UL,7UL,255UL},{0x2AL,250UL,0UL,4UL,0x13L,0UL},{0x43L,0xAFL,6UL,255UL,0xF2L,2UL},{248UL,5UL,0xAFL,253UL,249UL,6UL},{0UL,2UL,0xAFL,0x2AL,0xAFL,2UL},{3UL,0xD5L,6UL,252UL,0x2EL,0UL},{252UL,0x2EL,0UL,0x43L,3UL,255UL},{0x21L,0x2EL,0xF2L,255UL,0x2EL,0x4DL},{0UL,0xD5L,2UL,0x28L,0xAFL,250UL}}};
        int i, j, k;
        l_94 = (+(safe_mul_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s((safe_mod_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u(l_93, p_61)) <= g_38[2]), 0x8475L)), 13)), l_64)));
        g_38[1] = (safe_sub_func_uint32_t_u_u(((+((g_8 > l_64) <= p_61)) <= l_64), 0x864248A5L));
        l_100[0][1][0]--;
        for (g_8 = 0; (g_8 >= 21); g_8 = safe_add_func_int64_t_s_s(g_8, 8))
        { /* block id: 60 */
            if (l_94)
                break;
            l_94 = p_61;
            if (p_61)
                continue;
        }
    }
    l_108 &= ((safe_sub_func_uint64_t_u_u(g_38[2], 1L)) < l_107);
    if (((p_61 & 1L) & l_108))
    { /* block id: 67 */
        int8_t l_111 = 0L;
        int32_t l_112 = 0x25571F9CL;
        const uint32_t l_116[3] = {0xB1DC0440L,0xB1DC0440L,0xB1DC0440L};
        int32_t l_125 = 1L;
        int64_t l_126 = 0xA4E592539712D87DLL;
        int32_t l_127 = 0L;
        int32_t l_128[10];
        int64_t l_133[4];
        int i;
        for (i = 0; i < 10; i++)
            l_128[i] = 1L;
        for (i = 0; i < 4; i++)
            l_133[i] = 0x1D9B9EA2DD67205CLL;
        for (l_108 = 20; (l_108 > (-25)); l_108 = safe_sub_func_uint32_t_u_u(l_108, 5))
        { /* block id: 70 */
            uint32_t l_113[10] = {18446744073709551615UL,0x343B4210L,0x343B4210L,18446744073709551615UL,0x343B4210L,0x343B4210L,18446744073709551615UL,0x343B4210L,0x343B4210L,18446744073709551615UL};
            int i;
            l_113[9]++;
        }
        if (l_116[0])
        { /* block id: 73 */
            p_61 = (safe_lshift_func_int16_t_s_s((safe_mod_func_int16_t_s_s(0L, l_121[0])), 9));
        }
        else
        { /* block id: 75 */
            int32_t l_122 = 1L;
            int32_t l_123 = 2L;
            int32_t l_124 = 0x57CAC61BL;
            int32_t l_130 = 0x01646CDBL;
            int32_t l_132 = 0xAFB31ACBL;
            uint16_t l_135[3];
            int i;
            for (i = 0; i < 3; i++)
                l_135[i] = 0UL;
            --l_135[2];
            return l_121[0];
        }
    }
    else
    { /* block id: 79 */
        uint16_t l_145 = 0x69CEL;
        int32_t l_146 = 6L;
        for (l_129 = 5; (l_129 == 8); l_129 = safe_add_func_int32_t_s_s(l_129, 6))
        { /* block id: 82 */
            g_38[3] ^= (safe_sub_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((l_144 == g_18), (-9L))), g_18));
            l_146 = l_145;
            return l_145;
        }
        l_146 = g_8;
        l_146 = (((l_108 , 1L) ^ 0L) || 0x0CL);
        g_38[0] &= (0x42L <= p_61);
    }
    return l_129;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_38[i], "g_38[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_211, "g_211", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_222[i][j], "g_222[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_287[i][j], "g_287[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 81
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 100
   depth: 2, occurrence: 35
   depth: 3, occurrence: 5
   depth: 4, occurrence: 8
   depth: 5, occurrence: 7
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 11, occurrence: 3

XXX total number of pointers: 0

XXX times a non-volatile is read: 158
XXX times a non-volatile is write: 59
XXX times a volatile is read: 21
XXX    times read thru a pointer: 0
XXX times a volatile is write: 18
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 83
XXX percentage of non-volatile access: 84.8

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 109
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 36
   depth: 2, occurrence: 52

XXX percentage a fresh-made variable is used: 28.5
XXX percentage an existing variable is used: 71.5
********************* end of statistics **********************/

