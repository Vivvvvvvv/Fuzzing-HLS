/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14039308584414538793
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_13 = 0x1651L;
static uint16_t g_26 = 0x9E88L;
static uint64_t g_27 = 0xB3CF81320F2D6273LL;
static uint32_t g_30 = 0xC6A37D7CL;
static uint8_t g_31 = 253UL;
static volatile int32_t g_39 = 0xBEB927EEL;/* VOLATILE GLOBAL g_39 */
static volatile uint64_t g_40 = 1UL;/* VOLATILE GLOBAL g_40 */
static uint32_t g_43 = 9UL;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int64_t  func_2(uint32_t  p_3, uint32_t  p_4, uint32_t  p_5, uint32_t  p_6);
static uint8_t  func_9(int16_t  p_10, int32_t  p_11, uint16_t  p_12);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_27 g_30 g_31 g_40 g_43 g_39
 * writes: g_13 g_26 g_27 g_30 g_40 g_43 g_39
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_14 = 6UL;
    uint64_t l_15 = 0x87D0FA5166941FC9LL;
    int32_t l_37 = 0L;
    int32_t l_38 = 0x12FD89D6L;
    l_37 = (func_2(((safe_div_func_uint8_t_u_u(func_9(g_13, l_14, l_15), g_31)) >= l_14), g_31, g_31, g_31) , 0x68FC786CL);
    --g_40;
    if (l_14)
        goto lbl_46;
lbl_46:
    g_43--;
    g_39 |= ((0L ^ l_15) != 0L);
    return g_39;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_30
 * writes:
 */
static int64_t  func_2(uint32_t  p_3, uint32_t  p_4, uint32_t  p_5, uint32_t  p_6)
{ /* block id: 11 */
    int64_t l_33 = 0xF261718BC698DC50LL;
    int32_t l_34 = 1L;
    l_34 |= ((safe_unary_minus_func_uint16_t_u(l_33)) == g_13);
    l_34 = ((p_4 && (-3L)) > 0x16L);
    l_34 = (safe_div_func_int8_t_s_s(g_30, l_33));
    return l_33;
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_27 g_30
 * writes: g_13 g_26 g_27 g_30
 */
static uint8_t  func_9(int16_t  p_10, int32_t  p_11, uint16_t  p_12)
{ /* block id: 1 */
    int8_t l_20 = 0L;
    int64_t l_21[3];
    int i;
    for (i = 0; i < 3; i++)
        l_21[i] = (-1L);
    p_11 = (safe_lshift_func_int8_t_s_u((safe_mul_func_int8_t_s_s(l_20, 0UL)), 0));
    for (g_13 = 0; (g_13 <= 2); g_13 += 1)
    { /* block id: 5 */
        int i;
        g_26 = (((safe_lshift_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_u(l_21[g_13], 7)), 10)) && l_21[g_13]) | 0x78L);
        g_27--;
    }
    g_30 &= 0x2F7C629CL;
    return p_10;
}




/* ---------------------------------------- */
int main (void)
{
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_26, "g_26", print_hash_value);
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_43, "g_43", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 15
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 19
   depth: 2, occurrence: 3
   depth: 3, occurrence: 3
   depth: 5, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 20
XXX times a non-volatile is write: 10
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 90.9

XXX forward jumps: 1
XXX backward jumps: 0

XXX stmts: 16
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 14
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 45.5
XXX percentage an existing variable is used: 54.5
********************* end of statistics **********************/

