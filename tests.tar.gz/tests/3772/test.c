/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14411365717029396118
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int64_t g_2 = (-1L);/* VOLATILE GLOBAL g_2 */
static volatile int8_t g_3 = 0x49L;/* VOLATILE GLOBAL g_3 */
static uint64_t g_7 = 0UL;
static int32_t g_26[8] = {0xD64F6899L,0xD64F6899L,0xD64F6899L,0xD64F6899L,0xD64F6899L,0xD64F6899L,0xD64F6899L,0xD64F6899L};


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static uint16_t  func_14(uint32_t  p_15);
static uint64_t  func_17(const uint32_t  p_18, uint32_t  p_19, uint8_t  p_20, int32_t  p_21);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_7 g_26
 * writes: g_3 g_7 g_26
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_6 = 1UL;
    g_3 = g_2;
    g_7 = ((safe_sub_func_int8_t_s_s((1UL & l_6), l_6)) < (-1L));
    g_26[3] = ((safe_lshift_func_uint16_t_u_u((safe_lshift_func_int16_t_s_u(((safe_lshift_func_uint16_t_u_s(func_14((safe_unary_minus_func_uint32_t_u((((l_6 != g_3) | g_7) && g_7)))), g_7)) == 5UL), l_6)), l_6)) | l_6);
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_7 g_2 g_26
 * writes: g_26
 */
static uint16_t  func_14(uint32_t  p_15)
{ /* block id: 3 */
    const uint64_t l_22[9] = {0x47CDEDFC3E8CE6FCLL,0x9FA553FC2F92E6C0LL,0x9FA553FC2F92E6C0LL,0x47CDEDFC3E8CE6FCLL,0x9FA553FC2F92E6C0LL,0x9FA553FC2F92E6C0LL,0x47CDEDFC3E8CE6FCLL,0x9FA553FC2F92E6C0LL,0x9FA553FC2F92E6C0LL};
    int32_t l_40 = 0L;
    int i;
    l_40 = (func_17(l_22[1], g_3, p_15, p_15) > l_22[1]);
    return p_15;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_3 g_2 g_26
 * writes: g_26
 */
static uint64_t  func_17(const uint32_t  p_18, uint32_t  p_19, uint8_t  p_20, int32_t  p_21)
{ /* block id: 4 */
    uint8_t l_25 = 2UL;
    uint64_t l_39 = 18446744073709551615UL;
    g_26[3] = (safe_div_func_uint8_t_u_u((l_25 , l_25), g_7));
    g_26[3] = ((((safe_add_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s(((safe_mod_func_uint32_t_u_u(((safe_mul_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u((((g_7 >= l_25) == l_25) , p_20), g_7)), l_25)), l_25)) ^ 0xFD020461L), p_20)) ^ p_18), g_3)) <= p_18), 0x10L)) ^ l_25) & l_39) , g_2);
    return g_26[6];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_26[i], "g_26[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 9
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 10
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 6, occurrence: 1
   depth: 10, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 31
XXX times a non-volatile is write: 5
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 14
XXX percentage of non-volatile access: 85.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 9
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 9

XXX percentage a fresh-made variable is used: 21.4
XXX percentage an existing variable is used: 78.6
********************* end of statistics **********************/

