/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      13643273896509107101
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_2[7] = {65535UL,0x2062L,65535UL,65535UL,0x2062L,65535UL,65535UL};
static int32_t g_3 = 0x743D837BL;
static volatile uint8_t g_42 = 0x3AL;/* VOLATILE GLOBAL g_42 */
static int32_t g_59 = 0L;
static uint32_t g_60 = 1UL;
static int16_t g_67 = 0xAFE1L;
static volatile uint32_t g_79 = 0xEBE84459L;/* VOLATILE GLOBAL g_79 */
static int8_t g_82[4][9][6] = {{{1L,0x32L,(-1L),0xE9L,0L,0xD9L},{0x8DL,0L,0xA2L,0xDDL,1L,(-3L)},{8L,0x93L,0x90L,0xDAL,0xB1L,1L},{0x93L,(-1L),0x8DL,3L,0xDAL,0L},{(-1L),3L,0xDAL,3L,(-1L),0xA2L},{0xE9L,(-1L),0L,0L,3L,0xC8L},{1L,0L,7L,1L,0L,0L},{8L,1L,(-9L),0x8DL,0x12L,0x90L},{0L,0xE9L,(-1L),0x32L,1L,3L}},{{(-2L),0x82L,7L,0xDAL,0xDDL,0x32L},{0x32L,(-6L),1L,0xA2L,0xF1L,0xF1L},{1L,0x90L,0x90L,1L,1L,(-1L)},{0L,8L,(-1L),4L,0x82L,0x35L},{0x90L,0xD9L,0xDDL,0xD3L,0x82L,0L},{(-1L),8L,0L,(-2L),1L,0xDAL},{(-9L),0x90L,0L,0xE9L,0xF1L,0x00L},{0xB1L,(-6L),0x8DL,0L,0xDDL,0L},{0x12L,0x82L,1L,0xC8L,1L,0xC8L}},{{0xD9L,0xE9L,0xD9L,0x93L,0x12L,(-2L)},{0x8DL,1L,0xE9L,0x12L,0L,4L},{1L,3L,0xC8L,0x12L,(-3L),0x93L},{0x8DL,1L,3L,0x93L,0xD3L,1L},{0xD9L,3L,0L,0xC8L,(-1L),0xDDL},{0x12L,1L,0xF1L,0L,0x35L,(-9L)},{0xB1L,(-1L),0x82L,0xE9L,0xE9L,0x82L},{(-9L),(-9L),0xB1L,(-2L),3L,0xA2L},{(-1L),0x12L,0x00L,0xD3L,1L,0xB1L}},{{0x90L,(-1L),0x00L,4L,(-9L),0xA2L},{0L,4L,0xB1L,1L,0x00L,0x82L},{1L,0x00L,0x82L,0xA2L,8L,(-9L)},{0x32L,0L,0xF1L,0xDAL,(-2L),0xDDL},{(-2L),1L,0L,0x32L,0L,1L},{0L,0xDAL,3L,0x8DL,(-1L),0x93L},{8L,(-3L),0xC8L,1L,0xC1L,4L},{0xDDL,(-3L),0xE9L,0x00L,(-1L),(-2L)},{0x82L,0xDAL,0xD9L,3L,0L,0xC8L}}};
static volatile uint8_t g_83 = 0xB5L;/* VOLATILE GLOBAL g_83 */
static uint64_t g_86 = 0UL;
static int64_t g_89 = (-1L);
static volatile uint32_t g_90[9] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint16_t  func_6(uint16_t  p_7);
static uint16_t  func_8(uint32_t  p_9, int32_t  p_10, uint64_t  p_11, uint32_t  p_12);
static uint32_t  func_25(int32_t  p_26, const int64_t  p_27, int32_t  p_28, int32_t  p_29, int32_t  p_30);
static int32_t  func_34(int8_t  p_35, uint64_t  p_36, uint64_t  p_37, uint32_t  p_38, const uint16_t  p_39);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2 g_42 g_60 g_79 g_83 g_86 g_89 g_90 g_59
 * writes: g_3 g_42 g_60 g_67 g_79 g_83 g_86 g_89 g_90 g_59
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_23 = 18446744073709551606UL;
    for (g_3 = 2; (g_3 <= 6); g_3 += 1)
    { /* block id: 3 */
        int16_t l_22 = 0x142BL;
        int i;
        g_89 ^= (safe_mod_func_uint16_t_u_u(func_6(func_8((((safe_div_func_int16_t_s_s((safe_mod_func_int16_t_s_s((safe_mod_func_int64_t_s_s(((safe_mul_func_int8_t_s_s((((+0xB060L) <= g_2[g_3]) || 0x8D927F7B6FE6D39CLL), g_2[g_3])) , g_2[g_3]), l_22)), 2L)), g_2[g_3])) | g_2[g_3]) == 0x7EBD004DDE9AB5C2LL), g_2[g_3], g_2[g_3], l_23)), 0x49E4L));
        g_90[2]++;
    }
    for (g_86 = 0; (g_86 <= 6); g_86 += 1)
    { /* block id: 66 */
        int16_t l_95 = (-1L);
        for (g_59 = 6; (g_59 >= 0); g_59 -= 1)
        { /* block id: 69 */
            int i;
            g_3 = (safe_rshift_func_uint16_t_u_s((0x61D9E462E6BC3FCBLL > g_2[g_86]), 14));
            return l_95;
        }
    }
    return g_90[2];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_6(uint16_t  p_7)
{ /* block id: 59 */
    uint8_t l_88 = 4UL;
    return l_88;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_3 g_42 g_60 g_79 g_83 g_86
 * writes: g_42 g_60 g_67 g_79 g_83 g_86
 */
static uint16_t  func_8(uint32_t  p_9, int32_t  p_10, uint64_t  p_11, uint32_t  p_12)
{ /* block id: 4 */
    int8_t l_31 = (-1L);
    int32_t l_87 = 1L;
    for (p_11 = 1; (p_11 <= 6); p_11 += 1)
    { /* block id: 7 */
        int i;
        return g_2[p_11];
    }
    for (p_12 = 0; (p_12 <= 6); p_12 += 1)
    { /* block id: 12 */
        int32_t l_71 = 0x91B61232L;
        int i;
        if ((+func_25(g_2[p_12], g_3, l_31, g_2[p_12], l_31)))
        { /* block id: 47 */
            int16_t l_78 = (-6L);
            l_71 ^= 0x29C70A11L;
            l_71 = (((safe_lshift_func_uint16_t_u_u((safe_sub_func_int8_t_s_s((((safe_rshift_func_uint16_t_u_s(0x6276L, 2)) || l_71) == 0x7CE9F33CL), g_3)), l_71)) != 0x96C0L) != p_11);
            g_79++;
        }
        else
        { /* block id: 51 */
            --g_83;
        }
        if (g_83)
            break;
    }
    g_86 &= ((p_11 == p_9) == p_10);
    l_87 = 5L;
    return l_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_42 g_2 g_60
 * writes: g_42 g_60 g_67
 */
static uint32_t  func_25(int32_t  p_26, const int64_t  p_27, int32_t  p_28, int32_t  p_29, int32_t  p_30)
{ /* block id: 13 */
    const int8_t l_41 = 1L;
    int32_t l_49 = 8L;
    int8_t l_68 = 1L;
    for (p_28 = (-10); (p_28 > 19); ++p_28)
    { /* block id: 16 */
        int16_t l_57 = (-7L);
        for (p_26 = 6; (p_26 >= 2); p_26 -= 1)
        { /* block id: 19 */
            int32_t l_40 = 0x2A911815L;
            l_49 = func_34(p_27, p_28, g_3, l_40, l_41);
            return g_42;
        }
        if ((safe_add_func_uint8_t_u_u(((safe_rshift_func_int16_t_s_u(((safe_add_func_uint16_t_u_u(p_29, l_41)) , 9L), 11)) , g_3), g_2[0])))
        { /* block id: 29 */
            uint64_t l_56 = 0xEAD4A2B52F109D40LL;
            int32_t l_58[8][7][1] = {{{1L},{0L},{1L},{3L},{1L},{0x1060F33EL},{1L}},{{5L},{(-10L)},{0x9D99D06DL},{1L},{0x4162A971L},{1L},{0x9D99D06DL}},{{(-10L)},{5L},{1L},{0x1060F33EL},{1L},{5L},{(-10L)}},{{0x9D99D06DL},{1L},{0x4162A971L},{1L},{0x9D99D06DL},{(-10L)},{5L}},{{1L},{0x1060F33EL},{1L},{5L},{(-10L)},{0x9D99D06DL},{1L}},{{0x4162A971L},{1L},{0x9D99D06DL},{(-10L)},{5L},{1L},{0x1060F33EL}},{{1L},{5L},{(-10L)},{0x9D99D06DL},{1L},{0x4162A971L},{1L}},{{0x9D99D06DL},{(-10L)},{5L},{1L},{0x1060F33EL},{1L},{5L}}};
            int i, j, k;
            if (p_30)
                break;
            l_58[1][1][0] = (((((l_56 , l_57) < (-8L)) > 0x21L) >= l_57) , p_29);
        }
        else
        { /* block id: 32 */
            ++g_60;
            l_49 ^= (safe_div_func_uint64_t_u_u((((safe_mul_func_int8_t_s_s(0x1FL, p_30)) <= 0x22FFL) | 1UL), 0x4B380B773B032F89LL));
        }
        if (((g_3 >= 1L) <= (-1L)))
        { /* block id: 36 */
            int16_t l_69 = 0x65A3L;
            int32_t l_70 = 0x60069ABCL;
            if (l_57)
                break;
            g_67 = 5L;
            l_49 &= l_68;
            l_70 &= ((l_69 || g_42) > l_49);
        }
        else
        { /* block id: 41 */
            if (g_60)
                break;
        }
        return l_68;
    }
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_42 g_2 g_3
 * writes: g_42
 */
static int32_t  func_34(int8_t  p_35, uint64_t  p_36, uint64_t  p_37, uint32_t  p_38, const uint16_t  p_39)
{ /* block id: 20 */
    int16_t l_47 = 0x3CBFL;
    int32_t l_48[8][3] = {{0x69FDB81FL,(-6L),0x69FDB81FL},{0x69FDB81FL,0xE86DE1F1L,4L},{0x69FDB81FL,1L,1L},{0x69FDB81FL,(-6L),0x69FDB81FL},{0x69FDB81FL,0xE86DE1F1L,4L},{0x69FDB81FL,1L,1L},{0x69FDB81FL,(-6L),0x69FDB81FL},{0x69FDB81FL,0xE86DE1F1L,4L}};
    int i, j;
    g_42--;
    l_47 = (safe_sub_func_uint32_t_u_u((((g_2[5] > p_36) ^ 5L) & p_37), g_42));
    l_48[0][0] = p_39;
    l_48[0][2] = 0x925F8A41L;
    return g_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2[i], "g_2[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_82[i][j][k], "g_82[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    transparent_crc(g_89, "g_89", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_90[i], "g_90[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 29
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 44
   depth: 2, occurrence: 7
   depth: 3, occurrence: 4
   depth: 5, occurrence: 2
   depth: 6, occurrence: 4
   depth: 8, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 61
XXX times a non-volatile is write: 23
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 24
XXX percentage of non-volatile access: 90.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 43
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 10
   depth: 2, occurrence: 17

XXX percentage a fresh-made variable is used: 37.2
XXX percentage an existing variable is used: 62.8
********************* end of statistics **********************/

