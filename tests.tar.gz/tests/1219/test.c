/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16799982557750866785
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_15 = 9UL;
static uint16_t g_24 = 0x3927L;
static volatile int8_t g_31 = 0x58L;/* VOLATILE GLOBAL g_31 */
static volatile int16_t g_35[5] = {0x53D2L,0x53D2L,0x53D2L,0x53D2L,0x53D2L};
static volatile uint32_t g_36 = 0x3818264DL;/* VOLATILE GLOBAL g_36 */
static int64_t g_53 = (-6L);
static int8_t g_68 = (-5L);
static uint64_t g_71 = 0UL;
static uint16_t g_78 = 0x5DE1L;
static volatile uint32_t g_98[1][9] = {{0x5886D350L,0x30E8C00DL,0x5886D350L,0x30E8C00DL,0x5886D350L,0x30E8C00DL,0x5886D350L,0x30E8C00DL,0x5886D350L}};
static volatile uint8_t g_104 = 0xAFL;/* VOLATILE GLOBAL g_104 */
static volatile int16_t g_107 = (-1L);/* VOLATILE GLOBAL g_107 */
static volatile uint32_t g_110 = 2UL;/* VOLATILE GLOBAL g_110 */
static int64_t g_113 = (-1L);
static int32_t g_116 = 0x11E678B1L;
static uint32_t g_120[5] = {0x60870670L,0x60870670L,0x60870670L,0x60870670L,0x60870670L};
static volatile int32_t g_169[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int32_t g_170 = 0x7E6B1039L;
static volatile uint8_t g_171 = 0x45L;/* VOLATILE GLOBAL g_171 */
static int16_t g_180 = 1L;
static volatile uint32_t g_181 = 18446744073709551606UL;/* VOLATILE GLOBAL g_181 */
static volatile int8_t g_201 = 4L;/* VOLATILE GLOBAL g_201 */
static uint32_t g_202 = 0x35C2736AL;
static int64_t g_209 = 0xE2A24FF47029A216LL;
static volatile int32_t g_214 = 1L;/* VOLATILE GLOBAL g_214 */
static volatile int32_t g_215[9][3][4] = {{{1L,0L,0x30B8F8A4L,4L},{1L,1L,1L,7L},{0x06102636L,4L,(-1L),7L}},{{0x30B8F8A4L,1L,(-1L),4L},{3L,0L,(-1L),0L},{0x30B8F8A4L,4L,(-1L),1L}},{{1L,4L,3L,0x641AC3D2L},{3L,0x641AC3D2L,0xCAE7AD8DL,7L},{3L,0xEFD13C66L,3L,(-1L)}},{{1L,7L,(-1L),(-1L)},{0xCAE7AD8DL,0xEFD13C66L,0x30B8F8A4L,7L},{(-1L),0x641AC3D2L,0x30B8F8A4L,0x641AC3D2L}},{{0xCAE7AD8DL,4L,(-1L),1L},{1L,4L,3L,0x641AC3D2L},{3L,0x641AC3D2L,0xCAE7AD8DL,7L}},{{3L,0xEFD13C66L,3L,(-1L)},{1L,7L,(-1L),(-1L)},{0xCAE7AD8DL,0xEFD13C66L,0x30B8F8A4L,7L}},{{(-1L),0x641AC3D2L,0x30B8F8A4L,0x641AC3D2L},{0xCAE7AD8DL,4L,(-1L),1L},{1L,4L,3L,0x641AC3D2L}},{{3L,0x641AC3D2L,0xCAE7AD8DL,7L},{3L,0xEFD13C66L,3L,(-1L)},{1L,7L,(-1L),(-1L)}},{{0xCAE7AD8DL,0xEFD13C66L,0x30B8F8A4L,7L},{(-1L),0x641AC3D2L,0x30B8F8A4L,0x641AC3D2L},{0xCAE7AD8DL,4L,(-1L),1L}}};
static volatile int8_t g_216 = (-1L);/* VOLATILE GLOBAL g_216 */
static uint64_t g_217 = 0x9A98EA977DB183CELL;
static volatile uint16_t g_220 = 0x72B4L;/* VOLATILE GLOBAL g_220 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_2(const uint16_t  p_3, uint64_t  p_4);
static uint16_t  func_5(int32_t  p_6, int64_t  p_7);
static const int64_t  func_11(uint8_t  p_12, uint16_t  p_13, uint16_t  p_14);
static int32_t  func_18(int16_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_15 g_36 g_35 g_24 g_53 g_31 g_71 g_68 g_78 g_98 g_104 g_110 g_120 g_116 g_113 g_171 g_169 g_181 g_180 g_202 g_107 g_217 g_220
 * writes: g_24 g_36 g_15 g_53 g_68 g_71 g_78 g_98 g_104 g_110 g_113 g_116 g_120 g_171 g_181 g_202 g_209 g_217 g_220 g_180
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_8 = 0x288A137BL;
    int32_t l_167 = 0x97A29FEDL;
    int32_t l_168[7][10][3] = {{{0xFC00A9F0L,(-5L),0x65012FDBL},{0x5B8B1024L,9L,0xE9EF75D2L},{0xEA8EEED4L,1L,(-1L)},{0xD9FA1170L,0x37F1ACA1L,0x5B8B1024L},{0x37AD7940L,(-1L),0xEB38440BL},{0L,(-1L),0L},{5L,0x92528784L,(-1L)},{0xA26C4C03L,0xD9FA1170L,0xA26C4C03L},{4L,0L,0x92528784L},{0L,(-1L),1L}},{{0x204A484DL,0xD7022298L,0xE1858157L},{(-1L),0xE9EF75D2L,1L},{0x204A484DL,0xA4C8627FL,0x37AD7940L},{0L,(-9L),(-1L)},{4L,1L,0L},{0xA26C4C03L,9L,0x37F1ACA1L},{5L,(-6L),0L},{0L,(-8L),(-8L)},{0x37AD7940L,0x204A484DL,1L},{0xD9FA1170L,1L,9L}},{{0xEA8EEED4L,0x4CD6FD9EL,6L},{0x5B8B1024L,0L,0L},{0xFC00A9F0L,0x4CD6FD9EL,(-6L)},{9L,1L,(-1L)},{0xEB38440BL,0x204A484DL,(-1L)},{0x09BD9AF4L,(-8L),(-1L)},{0L,(-6L),9L},{(-8L),9L,0L},{1L,1L,0xFAEDB387L},{0L,(-9L),0xD9FA1170L}},{{0xD7022298L,0xA4C8627FL,(-5L)},{9L,0xE9EF75D2L,0xC5B3E99CL},{0xFAEDB387L,0xD7022298L,(-5L)},{0x13A31308L,(-1L),0xD9FA1170L},{(-1L),0L,1L},{0x6C9C1765L,0L,1L},{0L,(-1L),6L},{9L,(-1L),0x37F1ACA1L},{0xEA8EEED4L,0xE1858157L,0xEA8EEED4L},{(-1L),3L,(-1L)}},{{0xFAEDB387L,0x1F83D26DL,0xD7022298L},{0L,0L,(-8L)},{(-1L),(-1L),0x65012FDBL},{0L,0L,0x6C9C1765L},{0xFAEDB387L,0xFC00A9F0L,0x1F83D26DL},{(-1L),1L,0x502F1E5DL},{0xEA8EEED4L,0x92528784L,4L},{9L,9L,3L},{0L,0xA4C8627FL,0xA4C8627FL},{0x6C9C1765L,0L,(-1L)}},{{0xE1858157L,(-5L),0L},{(-3L),1L,0xC5B3E99CL},{1L,6L,0L},{(-1L),1L,9L},{9L,(-5L),(-1L)},{1L,0L,0x13A31308L},{0xE8E6B678L,0xA4C8627FL,0L},{0x502F1E5DL,9L,1L},{0xA4C8627FL,0x92528784L,(-6L)},{1L,1L,0x09BD9AF4L}},{{(-6L),0xFC00A9F0L,0xE1858157L},{0L,0L,0xD9FA1170L},{0x92528784L,(-1L),0x204A484DL},{0x09BD9AF4L,0L,0xD9FA1170L},{0x094550C6L,0x1F83D26DL,0xE1858157L},{0L,3L,0x09BD9AF4L},{0L,0xE1858157L,(-6L)},{(-8L),(-1L),1L},{0xFC00A9F0L,(-1L),0L},{0x13A31308L,0L,0x13A31308L}}};
    uint16_t l_235 = 0x4C5DL;
    int i, j, k;
    l_167 |= func_2(func_5(l_8, l_8), l_8);
    ++g_171;
    g_116 = l_167;
    for (g_24 = 0; (g_24 <= 2); g_24 += 1)
    { /* block id: 134 */
        int32_t l_178 = 0x2E7E373BL;
        int32_t l_179[1][6] = {{8L,8L,0L,8L,8L,0L}};
        uint32_t l_210 = 0x97E8E832L;
        uint64_t l_211 = 0x7ECCD11747086616LL;
        int i, j;
        if ((safe_sub_func_uint8_t_u_u((safe_rshift_func_int16_t_s_u((g_169[(g_24 + 2)] != l_178), g_71)), 4L)))
        { /* block id: 135 */
            uint32_t l_186 = 0x10D4CFF4L;
            ++g_181;
            l_168[3][7][2] = g_36;
            g_116 = ((safe_div_func_int16_t_s_s((l_168[3][7][2] || l_186), (-1L))) > 4294967295UL);
            g_116 = l_179[0][2];
        }
        else
        { /* block id: 140 */
            uint64_t l_199[5];
            int32_t l_200 = 0x97C18678L;
            int i;
            for (i = 0; i < 5; i++)
                l_199[i] = 0x03FCF02AD15776B2LL;
            l_179[0][4] = (((safe_mul_func_int8_t_s_s(((safe_mul_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((((safe_add_func_uint64_t_u_u(((safe_div_func_uint64_t_u_u((safe_add_func_int32_t_s_s((((l_179[0][0] != g_169[3]) > 0xBAA57302E08C720ALL) , g_104), g_68)), 3L)) >= g_78), 0x800174E01C407795LL)) & 4294967293UL) < 0x4FL), g_113)), l_199[3])) , g_36), g_180)) <= g_15) & 0UL);
            g_202++;
        }
        for (g_116 = 2; (g_116 >= 0); g_116 -= 1)
        { /* block id: 146 */
            int32_t l_208 = 0xEFC972B0L;
            l_179[0][5] = (safe_mod_func_int32_t_s_s((((+(((l_8 == g_116) ^ g_107) | 0xBFL)) != 9UL) < l_208), 0xB683C2DDL));
            g_209 = g_68;
            l_211 = (0xF8L ^ l_210);
            l_179[0][5] |= (safe_sub_func_int16_t_s_s((5UL == g_180), l_168[3][7][2]));
        }
        --g_217;
        for (l_210 = 0; (l_210 <= 2); l_210 += 1)
        { /* block id: 155 */
            int32_t l_231 = (-1L);
            ++g_220;
            l_179[0][5] = (safe_rshift_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s((safe_mod_func_uint8_t_u_u(((0x4A5BL < g_220) == (-9L)), 1UL)), l_8)), l_231)) , g_31), 12));
        }
        for (g_180 = 0; (g_180 <= 2); g_180 += 1)
        { /* block id: 161 */
            uint64_t l_232 = 0x6947A59DDDC56D0BLL;
            l_232--;
            ++l_235;
            if (l_232)
                break;
        }
    }
    return l_235;
}


/* ------------------------------------------ */
/* 
 * reads : g_116 g_53 g_35 g_24 g_15 g_98 g_120 g_113 g_36 g_71 g_31
 * writes: g_116 g_53 g_24 g_113
 */
static int32_t  func_2(const uint16_t  p_3, uint64_t  p_4)
{ /* block id: 89 */
    uint8_t l_156[8] = {0x14L,0x14L,0x14L,0x14L,0x14L,0x14L,0x14L,0x14L};
    int32_t l_157[1][2][10] = {{{2L,2L,2L,2L,2L,2L,2L,2L,2L,2L},{2L,2L,2L,2L,2L,2L,2L,2L,2L,2L}}};
    int i, j, k;
    g_116 |= (safe_add_func_uint8_t_u_u((safe_rshift_func_int8_t_s_u(0x89L, p_4)), 0UL));
    for (p_4 = 0; (p_4 <= 0); p_4 += 1)
    { /* block id: 93 */
        uint64_t l_128 = 18446744073709551610UL;
        int32_t l_138[1][4] = {{0x85FE053DL,0x85FE053DL,0x85FE053DL,0x85FE053DL}};
        int i, j;
        l_128 = ((!0x31L) != 0x81L);
        for (g_53 = 3; (g_53 >= 1); g_53 -= 1)
        { /* block id: 97 */
            int i, j;
            l_138[0][1] = ((safe_div_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((safe_unary_minus_func_uint16_t_u((safe_mul_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((-10L) | g_35[g_53]), 13)), 0xE10CL)))), (-1L))), 0x6CL)) ^ p_4);
            return p_3;
        }
        for (g_24 = 0; (g_24 <= 4); g_24 += 1)
        { /* block id: 103 */
            int32_t l_147 = 0x1ECF65DDL;
            int32_t l_148[2];
            int32_t l_151 = 0x9626E4E1L;
            int i;
            for (i = 0; i < 2; i++)
                l_148[i] = 0xAA43C15CL;
            l_148[1] ^= (safe_mul_func_int8_t_s_s((safe_div_func_uint8_t_u_u(((safe_sub_func_int64_t_s_s((safe_mul_func_int16_t_s_s(g_116, p_3)), l_147)) ^ p_4), p_4)), 255UL));
            l_151 &= (safe_div_func_int32_t_s_s(((g_35[2] >= p_3) <= g_15), l_148[1]));
            g_116 = (((((safe_mul_func_uint8_t_u_u(((safe_rshift_func_uint16_t_u_u((p_3 || 7L), p_3)) , p_3), l_156[4])) == p_3) == g_98[0][4]) && 0xF1L) == g_120[2]);
        }
        l_157[0][0][3] = 0x06661588L;
        for (g_53 = 0; (g_53 >= 0); g_53 -= 1)
        { /* block id: 111 */
            l_138[0][0] = (0x240BL != 0xDE73L);
            g_116 = ((l_156[3] != 0xE9L) >= 0x6020L);
        }
    }
    for (g_113 = 0; (g_113 == 11); g_113++)
    { /* block id: 118 */
        int64_t l_160 = 1L;
        uint32_t l_166 = 0xA75F86E7L;
        l_160 = g_113;
        if (g_116)
            break;
        if ((((l_156[5] > g_36) , g_71) , 0x86C8505DL))
        { /* block id: 121 */
            const int32_t l_165 = 9L;
            l_157[0][1][5] |= (safe_div_func_int8_t_s_s((safe_lshift_func_int16_t_s_u(((l_165 >= l_160) || p_3), l_166)), g_31));
        }
        else
        { /* block id: 123 */
            g_116 = (0x022BA7A0367B5E8CLL <= 1UL);
            g_116 = (l_156[4] <= p_4);
        }
    }
    return g_35[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_36 g_35 g_24 g_53 g_31 g_71 g_68 g_78 g_98 g_104 g_110 g_120
 * writes: g_24 g_36 g_15 g_53 g_68 g_71 g_78 g_98 g_104 g_110 g_113 g_116 g_120
 */
static uint16_t  func_5(int32_t  p_6, int64_t  p_7)
{ /* block id: 1 */
    uint32_t l_16 = 0x10789328L;
    int32_t l_117 = 7L;
    int32_t l_118 = 0xDF714E35L;
    int32_t l_119 = 0x7DDF4F03L;
    for (p_6 = 0; (p_6 < 12); ++p_6)
    { /* block id: 4 */
        g_113 = (((func_11(g_15, p_7, l_16) == p_6) || p_6) , l_16);
    }
    g_116 = (safe_mod_func_uint64_t_u_u(((0xDE0D86AFL != g_31) != 0x916956DDL), (-1L)));
    g_120[2]--;
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_15 g_36 g_35 g_24 g_53 g_31 g_71 g_68 g_78 g_98 g_104 g_110
 * writes: g_24 g_36 g_15 g_53 g_68 g_71 g_78 g_98 g_104 g_110
 */
static const int64_t  func_11(uint8_t  p_12, uint16_t  p_13, uint16_t  p_14)
{ /* block id: 5 */
    int8_t l_39 = 0x24L;
    int32_t l_81 = 9L;
    int32_t l_97 = 0L;
    int16_t l_108[7];
    int i;
    for (i = 0; i < 7; i++)
        l_108[i] = 0L;
    if ((g_15 & 0L))
    { /* block id: 6 */
        return g_15;
    }
    else
    { /* block id: 8 */
        uint16_t l_17[7] = {0xA7BCL,0xA7BCL,0xA7BCL,0xA7BCL,0xA7BCL,0xA7BCL,0xA7BCL};
        int32_t l_44 = 9L;
        int32_t l_48 = 0x6511F0B9L;
        int i;
        for (p_12 = 0; (p_12 <= 6); p_12 += 1)
        { /* block id: 11 */
            int i;
            l_39 = func_18((((safe_mul_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_s((l_17[p_12] ^ l_17[p_12]), 4)) , 0xCBE9L), 0x9150L)) >= p_13) >= l_17[3]));
            return l_39;
        }
        for (g_15 = 0; (g_15 == 23); g_15 = safe_add_func_int16_t_s_s(g_15, 9))
        { /* block id: 22 */
            uint32_t l_42 = 18446744073709551615UL;
            int32_t l_43 = (-1L);
            l_43 &= l_42;
            l_44 &= (-1L);
        }
        for (l_44 = 0; (l_44 <= (-28)); l_44 = safe_sub_func_uint8_t_u_u(l_44, 7))
        { /* block id: 28 */
            int32_t l_47 = 0xBF7A8323L;
            l_47 |= 0xE5F88592L;
            l_48 = 3L;
        }
    }
    if (((+255UL) == l_39))
    { /* block id: 33 */
        int32_t l_52[7] = {1L,1L,8L,1L,1L,8L,1L};
        int i;
        if (((safe_add_func_int8_t_s_s((g_24 > 1UL), l_52[6])) & l_39))
        { /* block id: 34 */
            g_53 = ((((p_14 != p_12) < g_24) < l_39) > 1UL);
        }
        else
        { /* block id: 36 */
            int8_t l_59[4];
            int i;
            for (i = 0; i < 4; i++)
                l_59[i] = 4L;
            l_52[6] = (((safe_lshift_func_int8_t_s_u((((!(safe_div_func_int16_t_s_s(l_59[3], g_53))) >= 0x63070B7BL) || p_13), l_52[6])) > 7UL) <= g_53);
        }
        if ((safe_lshift_func_uint16_t_u_u(p_13, p_13)))
        { /* block id: 39 */
            return g_31;
        }
        else
        { /* block id: 41 */
            uint8_t l_62 = 0x3FL;
            l_62 |= ((p_14 & g_35[3]) != p_14);
            g_68 = (!(safe_mod_func_int16_t_s_s(((safe_add_func_uint64_t_u_u(((l_39 | 0x06462EF7C93E255FLL) || g_36), (-3L))) || l_39), p_12)));
        }
        l_52[6] &= (g_53 & g_15);
    }
    else
    { /* block id: 46 */
        int8_t l_72 = 0x9FL;
        int32_t l_75[9] = {5L,0x89A473F1L,0x89A473F1L,5L,0x89A473F1L,0x89A473F1L,5L,0x89A473F1L,0x89A473F1L};
        int i;
        for (g_15 = 0; (g_15 != 30); g_15 = safe_add_func_int32_t_s_s(g_15, 6))
        { /* block id: 49 */
            g_71 |= (0x95FF7D1D410A02D5LL > l_39);
            if (l_72)
                continue;
        }
        l_75[2] = (safe_lshift_func_uint16_t_u_s(l_72, g_68));
        for (p_13 = 1; (p_13 <= 4); p_13 += 1)
        { /* block id: 56 */
            int i;
            l_75[2] = (((g_35[p_13] < g_15) >= p_12) < l_75[0]);
            g_78 = ((safe_div_func_uint16_t_u_u((g_53 && 1UL), p_12)) < l_39);
            l_81 = (((safe_add_func_uint8_t_u_u((g_68 == g_35[3]), 0UL)) != g_68) || g_35[p_13]);
            if (g_31)
                break;
        }
        l_75[6] = (safe_sub_func_int32_t_s_s((safe_add_func_int8_t_s_s(g_53, p_13)), l_72));
    }
    for (g_71 = 0; (g_71 <= 4); g_71 += 1)
    { /* block id: 66 */
        uint32_t l_92 = 1UL;
        int32_t l_93 = 0xA6A61002L;
        int32_t l_103 = (-2L);
        if ((0xFDL >= 0x1FL))
        { /* block id: 67 */
            int i;
            l_92 = ((safe_mod_func_uint8_t_u_u(((safe_mul_func_int8_t_s_s((safe_div_func_uint8_t_u_u(0x34L, g_35[g_71])), 0L)) | g_78), p_12)) & 0x8A8812E5E4DFF3B7LL);
            l_93 = (0x1377L <= 1UL);
            if (g_35[g_71])
                continue;
        }
        else
        { /* block id: 71 */
            int32_t l_96 = 3L;
            l_81 = (safe_add_func_int32_t_s_s((2UL == p_12), 0x9D5A4BDFL));
            ++g_98[0][4];
        }
        for (l_39 = 27; (l_39 < 15); --l_39)
        { /* block id: 77 */
            int16_t l_109 = 0x2AC5L;
            g_104--;
            g_110++;
        }
        if (p_13)
            continue;
    }
    return p_13;
}


/* ------------------------------------------ */
/* 
 * reads : g_36 g_35
 * writes: g_24 g_36
 */
static int32_t  func_18(int16_t  p_19)
{ /* block id: 12 */
    int8_t l_25 = 2L;
    int32_t l_26 = 0x383DE467L;
    uint16_t l_27 = 6UL;
    int32_t l_30 = 0xE2D3D478L;
    int32_t l_32 = 0xCEA2FF3EL;
    int32_t l_33 = (-2L);
    int32_t l_34[2];
    int i;
    for (i = 0; i < 2; i++)
        l_34[i] = 1L;
    g_24 = 0L;
    --l_27;
    g_36--;
    return g_35[3];
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_15, "g_15", print_hash_value);
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_35[i], "g_35[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_36, "g_36", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_68, "g_68", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_98[i][j], "g_98[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_104, "g_104", print_hash_value);
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_120[i], "g_120[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_169[i], "g_169[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_170, "g_170", print_hash_value);
    transparent_crc(g_171, "g_171", print_hash_value);
    transparent_crc(g_180, "g_180", print_hash_value);
    transparent_crc(g_181, "g_181", print_hash_value);
    transparent_crc(g_201, "g_201", print_hash_value);
    transparent_crc(g_202, "g_202", print_hash_value);
    transparent_crc(g_209, "g_209", print_hash_value);
    transparent_crc(g_214, "g_214", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_215[i][j][k], "g_215[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_216, "g_216", print_hash_value);
    transparent_crc(g_217, "g_217", print_hash_value);
    transparent_crc(g_220, "g_220", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 83
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 16
breakdown:
   depth: 1, occurrence: 98
   depth: 2, occurrence: 30
   depth: 3, occurrence: 6
   depth: 4, occurrence: 8
   depth: 5, occurrence: 4
   depth: 6, occurrence: 3
   depth: 7, occurrence: 4
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 16, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 129
XXX times a non-volatile is write: 69
XXX times a volatile is read: 25
XXX    times read thru a pointer: 0
XXX times a volatile is write: 7
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 114
XXX percentage of non-volatile access: 86.1

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 98
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 28
   depth: 2, occurrence: 49

XXX percentage a fresh-made variable is used: 34.6
XXX percentage an existing variable is used: 65.4
********************* end of statistics **********************/

