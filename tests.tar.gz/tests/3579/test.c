/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1163467746644841172
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_6[3] = {0xC5534BF8L,0xC5534BF8L,0xC5534BF8L};
static uint64_t g_7[4] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static int32_t g_8 = 0x3203BD65L;
static volatile uint32_t g_25 = 18446744073709551612UL;/* VOLATILE GLOBAL g_25 */
static uint16_t g_30 = 0x19BDL;
static uint32_t g_31 = 4294967292UL;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_10(uint8_t  p_11, int64_t  p_12);
static uint16_t  func_15(int32_t  p_16, uint8_t  p_17, int8_t  p_18, int64_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_7 g_25 g_30
 * writes: g_7 g_8 g_25 g_30 g_31
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_5 = 0xC4L;
    g_7[2] = (safe_unary_minus_func_uint8_t_u(((safe_mul_func_int16_t_s_s((0xE0B4074DL || l_5), g_6[1])) >= l_5)));
    g_8 = (((0xF415D7249AAED6B6LL < g_6[1]) , g_7[2]) <= g_7[1]);
    for (l_5 = 0; (l_5 <= 2); l_5 += 1)
    { /* block id: 5 */
        int32_t l_9 = 0xC5A3D7F1L;
        int i;
        l_9 ^= (g_6[l_5] || 4L);
        g_31 = func_10(g_6[l_5], g_6[l_5]);
    }
    return g_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_25 g_6
 * writes: g_25 g_30
 */
static int32_t  func_10(uint8_t  p_11, int64_t  p_12)
{ /* block id: 7 */
    int64_t l_22 = 0L;
    int32_t l_23[9];
    int i;
    for (i = 0; i < 9; i++)
        l_23[i] = (-1L);
    l_23[7] = (safe_rshift_func_uint16_t_u_s(func_15((((((safe_div_func_uint32_t_u_u(1UL, l_22)) > g_7[2]) , 0x639EL) & p_12) >= 7UL), p_12, l_22, l_23[1]), 13));
    --g_25;
    for (l_22 = 0; (l_22 <= 2); l_22 += 1)
    { /* block id: 14 */
        int i;
        l_23[(l_22 + 4)] |= (g_6[l_22] > 0x2601L);
    }
    g_30 = ((safe_div_func_int16_t_s_s((0L < 8UL), g_6[2])) , p_11);
    return p_11;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_15(int32_t  p_16, uint8_t  p_17, int8_t  p_18, int64_t  p_19)
{ /* block id: 8 */
    uint32_t l_24 = 0xC5674FA7L;
    return l_24;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_6[i], "g_6[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 12
   depth: 2, occurrence: 4
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 9
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 5
XXX percentage of non-volatile access: 97

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 13
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 10
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 44
XXX percentage an existing variable is used: 56
********************* end of statistics **********************/

