/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9054552298083721936
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 0x42EB90DAL;
static int64_t g_14[2] = {5L,5L};
static uint16_t g_67 = 0xDC50L;
static int16_t g_95[10][6][4] = {{{0xC332L,0x7326L,0L,0x896CL},{(-1L),0x7326L,0xD6DAL,0L},{0x7326L,0x57B5L,0xD6DAL,0xD6DAL},{(-1L),(-1L),0L,0xD6DAL},{0xC332L,0x57B5L,0x896CL,0L},{0xC332L,0x7326L,0L,0x896CL}},{{(-1L),0x7326L,0xD6DAL,0L},{0x7326L,0x57B5L,0xD6DAL,0xD6DAL},{(-1L),(-1L),0L,0xD6DAL},{0xC332L,0x57B5L,0x896CL,0L},{0xC332L,0x7326L,0L,0x896CL},{0x7326L,0xC332L,0xB7C4L,0x896CL}},{{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L}},{{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L}},{{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL}},{{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL}},{{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL}},{{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L}},{{0x7326L,0x7326L,0x896CL,0xB7C4L},{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0xB7C4L}},{{(-1L),(-1L),0xD6DAL,0x896CL},{(-1L),0xC332L,0x896CL,0xD6DAL},{0x7326L,0xC332L,0xB7C4L,0x896CL},{0xC332L,(-1L),0xB7C4L,0xB7C4L},{0x7326L,0x7326L,0x896CL,0x4E19L},{0x57B5L,0x7326L,0xB7C4L,0xD6DAL}}};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_15(uint64_t  p_16, int32_t  p_17, int32_t  p_18);
static uint64_t  func_19(const int32_t  p_20, int64_t  p_21, uint16_t  p_22);
static uint16_t  func_30(int32_t  p_31, int16_t  p_32, const uint32_t  p_33);
static int32_t  func_36(int64_t  p_37, uint8_t  p_38, uint64_t  p_39, uint32_t  p_40, int32_t  p_41);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_14 g_67 g_95
 * writes: g_2 g_67 g_95
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_12 = 0x8F6C218EL;
    int32_t l_13 = 0x0B4EF66BL;
    if (g_2)
    { /* block id: 1 */
        uint32_t l_10 = 3UL;
        int32_t l_11 = 1L;
        g_2 = 3L;
        for (g_2 = 16; (g_2 <= 22); ++g_2)
        { /* block id: 5 */
            uint8_t l_9 = 254UL;
            l_11 &= (safe_add_func_int8_t_s_s((((safe_add_func_int16_t_s_s(l_9, 1L)) <= g_2) , l_10), 0xD0L));
            l_13 = (0x29ACL || l_12);
        }
    }
    else
    { /* block id: 9 */
        int16_t l_27 = 0xC84BL;
        int32_t l_88 = 0x0F83D54BL;
        for (l_12 = 0; (l_12 <= 1); l_12 += 1)
        { /* block id: 12 */
            int i;
            l_13 |= (-9L);
            l_88 = func_15(func_19((((safe_sub_func_uint64_t_u_u(((safe_div_func_int16_t_s_s(g_14[l_12], 0xF62CL)) | l_27), l_27)) , g_2) || g_14[1]), l_12, g_2), g_14[0], g_14[0]);
        }
        if (((((safe_add_func_uint32_t_u_u((0xF85E685AC0FE8B85LL ^ g_2), g_14[1])) || l_12) , g_67) != l_12))
        { /* block id: 73 */
            g_95[5][4][0] |= (((safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u(l_12, g_67)), l_12)) | g_2) < g_67);
            l_13 ^= g_14[0];
        }
        else
        { /* block id: 76 */
            g_2 |= (0xA5F02B52C7FF4120LL | 0UL);
        }
    }
    return l_12;
}


/* ------------------------------------------ */
/* 
 * reads : g_67 g_14 g_2
 * writes: g_67
 */
static int32_t  func_15(uint64_t  p_16, int32_t  p_17, int32_t  p_18)
{ /* block id: 49 */
    uint64_t l_80 = 1UL;
    for (g_67 = 5; (g_67 >= 36); g_67++)
    { /* block id: 52 */
        for (p_18 = 0; (p_18 < 2); p_18 = safe_add_func_uint16_t_u_u(p_18, 6))
        { /* block id: 55 */
            return p_16;
        }
        l_80 &= (safe_div_func_int8_t_s_s(((+(p_18 == g_14[1])) & 0x440AFAA93538B87BLL), p_16));
        if (((safe_add_func_int8_t_s_s(((~g_2) ^ 0x127326B3L), g_14[0])) | p_17))
        { /* block id: 59 */
            p_18 &= ((safe_lshift_func_int16_t_s_u((0x95D92507L != p_17), p_16)) & l_80);
        }
        else
        { /* block id: 61 */
            return p_17;
        }
    }
    for (p_16 = (-17); (p_16 >= 18); p_16++)
    { /* block id: 67 */
        return g_67;
    }
    return l_80;
}


/* ------------------------------------------ */
/* 
 * reads : g_2 g_14 g_67
 * writes: g_2 g_67
 */
static uint64_t  func_19(const int32_t  p_20, int64_t  p_21, uint16_t  p_22)
{ /* block id: 14 */
    uint8_t l_34[7][7][5] = {{{7UL,1UL,0xCEL,1UL,0xCEL},{0xE8L,0xE8L,0xC4L,1UL,254UL},{1UL,7UL,255UL,1UL,255UL},{0x05L,5UL,2UL,0UL,5UL},{255UL,7UL,0xB1L,0x84L,0x84L},{0UL,0xE8L,0UL,2UL,255UL},{1UL,1UL,0xA7L,0UL,0x53L}},{{255UL,0x05L,248UL,1UL,0xE8L},{0xCEL,255UL,0xA7L,0x53L,0x35L},{0x05L,0UL,0UL,0x05L,255UL},{0UL,1UL,0xB1L,0xAEL,1UL},{255UL,255UL,2UL,4UL,255UL},{7UL,0xCEL,255UL,0xAEL,0xA7L},{1UL,0x05L,0xC4L,0x05L,1UL}},{{255UL,0UL,0xCEL,0x53L,255UL},{0xE8L,255UL,4UL,1UL,0x73L},{0UL,7UL,0x72L,0UL,255UL},{0x10L,1UL,2UL,2UL,1UL},{255UL,255UL,255UL,0x84L,0xA7L},{255UL,0xE8L,0UL,0UL,255UL},{0x53L,0UL,0xA7L,1UL,1UL}},{{255UL,0x10L,255UL,1UL,255UL},{255UL,255UL,1UL,1UL,0x35L},{0x10L,255UL,0UL,0x10L,0xE8L},{0UL,0x53L,255UL,0xAEL,0x53L},{0xE8L,255UL,5UL,255UL,255UL},{255UL,255UL,255UL,255UL,0x84L},{1UL,0x10L,4UL,0x05L,5UL}},{{7UL,0UL,9UL,1UL,255UL},{255UL,0xE8L,4UL,5UL,254UL},{0UL,255UL,255UL,0UL,0xCEL},{0x05L,1UL,5UL,0UL,1UL},{0xCEL,7UL,255UL,0xA7L,0x84L},{255UL,255UL,0UL,0UL,4UL},{1UL,0UL,1UL,0UL,1UL}},{{0UL,0x05L,255UL,5UL,0xE8L},{255UL,0xCEL,0xA7L,1UL,0UL},{0UL,5UL,1UL,0UL,0x73L},{0x72L,255UL,1UL,1UL,255UL},{0x73L,0x17L,0xC4L,255UL,248UL},{0x53L,0UL,1UL,0xA7L,0xCEL},{5UL,0UL,248UL,0UL,2UL}},{{0x53L,0x72L,6UL,255UL,6UL},{0x73L,0x73L,0xE8L,2UL,0x10L},{0x72L,0x53L,0xBCL,0x72L,0UL},{0UL,5UL,0xC4L,4UL,5UL},{0UL,0x53L,0x84L,0xCEL,0xCEL},{0x17L,0x73L,0x17L,0xC4L,255UL},{255UL,0x72L,9UL,255UL,0xB1L}}};
    int32_t l_35 = 0x4C3DC4D7L;
    int32_t l_56[5];
    uint8_t l_57 = 0UL;
    uint16_t l_66 = 0xD02BL;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_56[i] = 0x2BF6251CL;
    g_2 = ((safe_lshift_func_uint16_t_u_s(func_30(((p_20 ^ l_34[6][0][4]) >= l_34[1][2][1]), p_21, l_34[6][6][0]), 1)) , l_34[6][0][4]);
    l_35 = (0xD17BA7DAL == 4294967294UL);
lbl_72:
    l_35 = func_30(func_30(func_36((safe_add_func_int32_t_s_s(((safe_rshift_func_uint8_t_u_u((((safe_add_func_int8_t_s_s(g_14[1], p_21)) ^ l_34[6][0][4]) <= 0x0A6FL), p_21)) >= g_2), g_14[0])), l_34[2][4][4], g_2, g_14[0], l_34[0][4][1]), g_2, g_14[0]), p_20, l_35);
    for (l_35 = 0; (l_35 == 3); l_35++)
    { /* block id: 29 */
        uint16_t l_60[7];
        int32_t l_63 = (-5L);
        int i;
        for (i = 0; i < 7; i++)
            l_60[i] = 0xBF08L;
        if ((safe_add_func_uint64_t_u_u((0x356723FF4914D865LL <= l_35), l_35)))
        { /* block id: 30 */
            if (g_2)
                break;
            ++l_57;
            l_60[1]--;
            return p_21;
        }
        else
        { /* block id: 35 */
            l_63 &= (1UL && g_14[0]);
        }
        if ((p_21 & (-6L)))
        { /* block id: 38 */
            l_63 = (safe_lshift_func_int8_t_s_s(l_34[0][6][3], 0));
            g_2 = l_56[0];
            l_66 = 1L;
            --g_67;
        }
        else
        { /* block id: 43 */
            l_63 = (safe_lshift_func_int16_t_s_s(l_63, 9));
        }
        if (l_57)
            goto lbl_72;
    }
    return g_67;
}


/* ------------------------------------------ */
/* 
 * reads : g_2
 * writes:
 */
static uint16_t  func_30(int32_t  p_31, int16_t  p_32, const uint32_t  p_33)
{ /* block id: 15 */
    return g_2;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_36(int64_t  p_37, uint8_t  p_38, uint64_t  p_39, uint32_t  p_40, int32_t  p_41)
{ /* block id: 19 */
    uint64_t l_51 = 18446744073709551607UL;
    for (p_38 = 0; (p_38 > 57); p_38 = safe_add_func_int16_t_s_s(p_38, 7))
    { /* block id: 22 */
        uint64_t l_50 = 6UL;
        return l_50;
    }
    return l_51;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_67, "g_67", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_95[i][j][k], "g_95[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 20
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 42
   depth: 2, occurrence: 14
   depth: 3, occurrence: 1
   depth: 4, occurrence: 3
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 12, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 79
XXX times a non-volatile is write: 28
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 45
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 13
   depth: 1, occurrence: 12
   depth: 2, occurrence: 20

XXX percentage a fresh-made variable is used: 21.3
XXX percentage an existing variable is used: 78.7
********************* end of statistics **********************/

