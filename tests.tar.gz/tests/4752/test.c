/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1113732025476980320
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_16 = 0x5950707DL;
static int16_t g_17[6] = {0x7FE6L,0x7FE6L,0x7FE6L,0x7FE6L,0x7FE6L,0x7FE6L};
static uint64_t g_19 = 0UL;
static uint32_t g_30 = 0x74CA7790L;
static uint8_t g_42 = 0xE8L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_8(int64_t  p_9);
static int64_t  func_10(int16_t  p_11, uint8_t  p_12, int32_t  p_13, int64_t  p_14);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_16 g_17 g_19 g_30 g_42
 * writes: g_19 g_16 g_30 g_42
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_15 = 0x7AB3921DL;
    int32_t l_43 = 5L;
    l_43 |= (safe_lshift_func_uint16_t_u_s((safe_lshift_func_int16_t_s_u((safe_div_func_int8_t_s_s(func_8(func_10(l_15, l_15, g_16, l_15)), l_15)), 13)), g_17[4]));
    return g_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_16 g_30 g_42
 * writes: g_16 g_30 g_42
 */
static int8_t  func_8(int64_t  p_9)
{ /* block id: 11 */
    uint64_t l_27[4] = {0x6085E0710DD013D0LL,0x6085E0710DD013D0LL,0x6085E0710DD013D0LL,0x6085E0710DD013D0LL};
    uint16_t l_41 = 0x0271L;
    int i;
    l_27[3] &= (safe_lshift_func_uint8_t_u_u(g_19, g_16));
    for (g_16 = (-8); (g_16 != (-30)); --g_16)
    { /* block id: 15 */
        if (g_19)
            break;
        g_30--;
    }
    g_42 |= (safe_sub_func_uint16_t_u_u((((safe_mul_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u(0x1EL, p_9)), l_41)) < p_9), l_41)) | p_9) || p_9), p_9));
    return p_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_19
 * writes: g_19
 */
static int64_t  func_10(int16_t  p_11, uint8_t  p_12, int32_t  p_13, int64_t  p_14)
{ /* block id: 1 */
    uint32_t l_22 = 18446744073709551609UL;
    for (p_13 = 4; (p_13 >= 0); p_13 -= 1)
    { /* block id: 4 */
        int32_t l_18 = 1L;
        int i;
        if (g_17[(p_13 + 1)])
            break;
        ++g_19;
        if (g_17[(p_13 + 1)])
            break;
    }
    l_22++;
    return l_22;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_17[i], "g_17[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_30, "g_30", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 10
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 9
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 23
XXX times a non-volatile is write: 8
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 14
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 5

XXX percentage a fresh-made variable is used: 37
XXX percentage an existing variable is used: 63
********************* end of statistics **********************/

