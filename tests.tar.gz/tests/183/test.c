/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      11786582646859287360
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_6 = 0x1265AB3EL;
static uint32_t g_47[3][3][9] = {{{0x86A8E7E6L,0x5435D7D2L,0x47C1471CL,0xB11082E7L,4294967292UL,0x039C1D55L,0x5435D7D2L,0xB11082E7L,0xB11082E7L},{0UL,7UL,0xC7E1EFC3L,0xAADAF8D9L,0xC7E1EFC3L,7UL,0UL,4294967293UL,0UL},{0UL,4294967292UL,0x4DCD7820L,0x039C1D55L,0x86A8E7E6L,0UL,0x5435D7D2L,0x4DCD7820L,0x86A8E7E6L}},{{4294967289UL,4294967293UL,4294967295UL,0x8A4122E7L,0xD6D23037L,0x8A4122E7L,4294967295UL,4294967293UL,4294967289UL},{4294967295UL,0x039C1D55L,0x47C1471CL,0x86A8E7E6L,4294967295UL,6UL,0x039C1D55L,0xB11082E7L,0x86A8E7E6L},{0xC7E1EFC3L,7UL,0UL,4294967292UL,0UL,0x8A4122E7L,0UL,4294967292UL,0UL}},{{0x86A8E7E6L,0x86A8E7E6L,0x4DCD7820L,0x5435D7D2L,0UL,0x86A8E7E6L,0x039C1D55L,0x4DCD7820L,4294967292UL},{0x458230B5L,7UL,0x458230B5L,0x8A4122E7L,4294967289UL,0xAADAF8D9L,0UL,0xAADAF8D9L,4294967289UL},{0xB11082E7L,0x4DCD7820L,0x4DCD7820L,0xB11082E7L,4294967295UL,0x47C1471CL,0x4DCD7820L,0UL,0xB11082E7L}}};
static int8_t g_76 = (-6L);
static int8_t g_77 = 0x09L;
static int16_t g_78 = 1L;
static volatile int16_t g_80 = 0x630FL;/* VOLATILE GLOBAL g_80 */
static volatile int64_t g_82[2] = {0x2E219839B2FD4BBALL,0x2E219839B2FD4BBALL};
static volatile int32_t g_85 = 0L;/* VOLATILE GLOBAL g_85 */
static volatile uint64_t g_86 = 0xF77C9A86FCAFA235LL;/* VOLATILE GLOBAL g_86 */


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static uint32_t  func_4(uint16_t  p_5);
static int32_t  func_9(uint32_t  p_10, int16_t  p_11, int16_t  p_12);
static uint8_t  func_15(int64_t  p_16, uint8_t  p_17, const int8_t  p_18, uint16_t  p_19);
static uint16_t  func_24(uint64_t  p_25, const int32_t  p_26, uint64_t  p_27);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_6 g_47 g_76 g_86 g_78
 * writes: g_6 g_47 g_76 g_77 g_86
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_90 = 0UL;
    int32_t l_91 = 0x7EB49816L;
    l_91 = ((safe_mod_func_uint8_t_u_u((func_4(g_6) >= l_90), g_78)) , 0L);
    return l_91;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_47 g_76 g_86
 * writes: g_6 g_47 g_76 g_77 g_86
 */
static uint32_t  func_4(uint16_t  p_5)
{ /* block id: 1 */
    int32_t l_83 = 0x45B60A5FL;
    int32_t l_89 = (-7L);
    for (g_6 = 0; (g_6 > 7); g_6 = safe_add_func_int32_t_s_s(g_6, 1))
    { /* block id: 4 */
        int32_t l_39 = (-7L);
        int32_t l_81 = 1L;
        int32_t l_84[7];
        int i;
        for (i = 0; i < 7; i++)
            l_84[i] = (-10L);
        if (g_6)
        { /* block id: 5 */
            const uint64_t l_38 = 0UL;
            int32_t l_79[9] = {0xB85C5578L,0xC6914174L,0xC6914174L,0xB85C5578L,0xC6914174L,0xC6914174L,0xB85C5578L,0xC6914174L,0xC6914174L};
            int i;
            g_77 = func_9((((((((safe_rshift_func_uint8_t_u_u(func_15(g_6, g_6, p_5, p_5), l_38)) , l_39) || g_6) <= p_5) < g_6) >= p_5) , 0x3F8DE905L), g_6, g_6);
            g_86--;
            return l_83;
        }
        else
        { /* block id: 58 */
            l_89 ^= 0x334EEA40L;
            return g_6;
        }
    }
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_47 g_76
 * writes: g_47 g_76
 */
static int32_t  func_9(uint32_t  p_10, int16_t  p_11, int16_t  p_12)
{ /* block id: 17 */
    int32_t l_46 = 1L;
    uint32_t l_63 = 8UL;
    uint32_t l_65 = 1UL;
lbl_69:
    for (p_10 = (-27); (p_10 < 31); p_10 = safe_add_func_uint8_t_u_u(p_10, 5))
    { /* block id: 20 */
        int32_t l_52 = (-1L);
        if ((((safe_div_func_uint32_t_u_u(((safe_sub_func_int16_t_s_s(((-5L) > (-8L)), 0x954EL)) , p_11), g_6)) , l_46) | 6L))
        { /* block id: 21 */
            l_46 = p_11;
            g_47[1][2][6] &= 0L;
        }
        else
        { /* block id: 24 */
            uint32_t l_51 = 0x56E035D6L;
            l_51 = (((safe_add_func_uint32_t_u_u((((!l_46) , g_47[1][2][6]) == g_47[1][2][6]), p_12)) < 0x27DBD1BDL) < p_11);
            l_52 = p_10;
        }
        if ((((((safe_lshift_func_int16_t_s_u((((safe_lshift_func_uint8_t_u_u(0UL, g_47[1][2][6])) , p_12) , 0x48FBL), l_46)) && 0xCCC4EFF443A54D8FLL) < l_46) , p_11) , (-1L)))
        { /* block id: 28 */
            uint16_t l_57 = 65528UL;
            uint64_t l_64[8] = {0UL,0x40CFCE320EC44CB1LL,0x40CFCE320EC44CB1LL,0UL,0x40CFCE320EC44CB1LL,0x40CFCE320EC44CB1LL,0UL,0x40CFCE320EC44CB1LL};
            int i;
            l_57 = p_12;
            l_46 = (p_11 < l_46);
            l_46 = ((safe_mul_func_int8_t_s_s((((safe_lshift_func_uint8_t_u_s((!(l_63 == g_6)), 0)) ^ p_11) , l_64[1]), 4UL)) == p_10);
            l_46 = g_47[1][2][6];
        }
        else
        { /* block id: 33 */
            if (l_65)
                break;
        }
    }
    for (l_63 = 0; (l_63 <= 2); l_63 += 1)
    { /* block id: 39 */
        uint64_t l_67 = 0xDEE2C54351128280LL;
        for (p_11 = 2; (p_11 >= 0); p_11 -= 1)
        { /* block id: 42 */
            int8_t l_66[1];
            int32_t l_68 = 1L;
            int i;
            for (i = 0; i < 1; i++)
                l_66[i] = 0xD1L;
            l_66[0] = 0x74A76864L;
            l_68 = (((((((p_11 , g_47[2][1][6]) , 0xA29CL) > p_12) , l_67) ^ 0xB9L) | 0xCEB51834L) == p_12);
            if (g_6)
                continue;
        }
        for (l_67 = 0; (l_67 <= 2); l_67 += 1)
        { /* block id: 49 */
            if (l_46)
                goto lbl_69;
            g_76 |= ((safe_lshift_func_uint16_t_u_s((safe_sub_func_int64_t_s_s((safe_add_func_uint64_t_u_u((g_6 | p_12), g_47[1][2][6])), 0xC4802A3EDB7DE593LL)), l_46)) >= p_12);
        }
    }
    return l_63;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint8_t  func_15(int64_t  p_16, uint8_t  p_17, const int8_t  p_18, uint16_t  p_19)
{ /* block id: 6 */
    int32_t l_34[3][7] = {{0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL},{(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)},{0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL,0x58AAE07EL}};
    int32_t l_35 = 0xAF9031EAL;
    int i, j;
    l_35 = (safe_lshift_func_uint16_t_u_s((((safe_mod_func_uint16_t_u_u(func_24((safe_sub_func_int64_t_s_s((safe_lshift_func_int8_t_s_u(((((safe_mod_func_uint8_t_u_u((7L > (-1L)), 0x4BL)) > l_34[0][1]) < g_6) & p_16), p_17)), g_6)), p_17, l_34[2][6]), l_34[0][6])) , l_34[0][1]) != 5L), 8));
    l_35 ^= (safe_mod_func_uint64_t_u_u((l_34[0][1] >= l_34[0][1]), 0xE58ED0BD2F23D37FLL));
    for (l_35 = 2; (l_35 >= 0); l_35 -= 1)
    { /* block id: 13 */
        return p_17;
    }
    return l_35;
}


/* ------------------------------------------ */
/* 
 * reads : g_6
 * writes:
 */
static uint16_t  func_24(uint64_t  p_25, const int32_t  p_26, uint64_t  p_27)
{ /* block id: 7 */
    return g_6;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_47[i][j][k], "g_47[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_77, "g_77", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_82[i], "g_82[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_85, "g_85", print_hash_value);
    transparent_crc(g_86, "g_86", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 30
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 15
breakdown:
   depth: 1, occurrence: 37
   depth: 2, occurrence: 7
   depth: 3, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 15, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 77
XXX times a non-volatile is write: 22
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 4
XXX percentage of non-volatile access: 99

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 37
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 6
   depth: 2, occurrence: 19

XXX percentage a fresh-made variable is used: 30.9
XXX percentage an existing variable is used: 69.1
********************* end of statistics **********************/

