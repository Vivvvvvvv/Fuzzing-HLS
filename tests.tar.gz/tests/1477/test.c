/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1937040548104584287
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_5 = 0x37L;/* VOLATILE GLOBAL g_5 */
static uint16_t g_7[9] = {65532UL,0UL,65532UL,65532UL,0UL,65532UL,65532UL,0UL,65532UL};
static int32_t g_31 = 3L;
static uint64_t g_38 = 0UL;
static int32_t g_39[7] = {5L,1L,5L,5L,1L,5L,5L};


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static int32_t  func_8(uint64_t  p_9, uint32_t  p_10, int16_t  p_11, int32_t  p_12);
static int32_t  func_22(const uint32_t  p_23, uint64_t  p_24, int32_t  p_25, int32_t  p_26);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_31 g_38 g_39
 * writes: g_31 g_38 g_39
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_4 = 0x40L;
    int32_t l_6[3];
    int32_t l_16 = 0L;
    int32_t l_54 = 0x0C327405L;
    int32_t l_56 = (-1L);
    int32_t l_57 = (-1L);
    int i;
    for (i = 0; i < 3; i++)
        l_6[i] = 0x2D76715FL;
    if ((safe_lshift_func_uint16_t_u_s(((((l_4 <= g_5) , g_5) <= l_6[2]) == 1L), g_7[5])))
    { /* block id: 1 */
        uint64_t l_21 = 0x6E86FF18EE85EC41LL;
        l_16 = func_8(l_4, g_5, g_7[5], g_7[5]);
        l_21 = (((safe_mul_func_uint16_t_u_u((safe_add_func_uint16_t_u_u(((g_7[1] == g_5) | g_7[5]), 0x6640L)), l_6[2])) , g_7[5]) , l_4);
        g_39[3] &= func_22(l_21, l_6[0], g_5, g_7[3]);
        g_39[6] = ((safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_uint16_t_u((((safe_sub_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(g_39[0], 1L)), g_7[7])) < 250UL) != 0xFB48L))), g_5)) & g_7[5]);
    }
    else
    { /* block id: 20 */
        int8_t l_53 = 0x07L;
        int32_t l_55 = 0xE5249F39L;
        uint16_t l_58 = 1UL;
        l_53 = ((safe_div_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s((safe_unary_minus_func_uint32_t_u(((~(7L < l_6[0])) || l_4))), 15)), 3UL)) & 0xCBL);
        --l_58;
        l_57 = (-1L);
        l_57 = 0xAE864EA5L;
    }
    g_39[4] = (safe_mul_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(((+(~(safe_rshift_func_int16_t_s_u((-2L), 14)))) >= 0L), g_31)) != 1L), l_4));
    return g_31;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_8(uint64_t  p_9, uint32_t  p_10, int16_t  p_11, int32_t  p_12)
{ /* block id: 2 */
    uint16_t l_13 = 0x7BE0L;
    l_13++;
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_31 g_38
 * writes: g_31 g_38
 */
static int32_t  func_22(const uint32_t  p_23, uint64_t  p_24, int32_t  p_25, int32_t  p_26)
{ /* block id: 7 */
    int16_t l_36 = 1L;
    int32_t l_37 = (-1L);
    g_31 = (safe_add_func_int64_t_s_s(((((((p_25 < 255UL) >= 0L) && g_5) == 0xC9F71D69L) > p_25) != 0x4AD1532D49ACB085LL), g_7[1]));
    for (g_31 = 0; (g_31 > 12); g_31++)
    { /* block id: 11 */
        l_37 = (safe_mul_func_int16_t_s_s(((0x33L | l_36) != 0x02A05008L), p_25));
        l_37 ^= 0x7D7A760EL;
        g_38 ^= 0xC1ED5297L;
        if (p_26)
            break;
    }
    return l_36;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_7[i], "g_7[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 31
XXX times a non-volatile is write: 15
XXX times a volatile is read: 7
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 21
XXX percentage of non-volatile access: 86.8

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 8
   depth: 1, occurrence: 12

XXX percentage a fresh-made variable is used: 30.5
XXX percentage an existing variable is used: 69.5
********************* end of statistics **********************/

