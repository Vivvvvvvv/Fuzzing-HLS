/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5536987987139346110
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint64_t g_5[7] = {0x8C443EB60693009CLL,0x8C443EB60693009CLL,0x8C443EB60693009CLL,0x8C443EB60693009CLL,0x8C443EB60693009CLL,0x8C443EB60693009CLL,0x8C443EB60693009CLL};
static uint32_t g_6 = 1UL;
static uint8_t g_9[7] = {0xC1L,0xC1L,0x47L,0xC1L,0xC1L,0x47L,0xC1L};
static int8_t g_15[3] = {(-8L),(-8L),(-8L)};
static int32_t g_16 = 0x86D6DBC1L;


/* --- FORWARD DECLARATIONS --- */
static int16_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_15
 * writes: g_6 g_9 g_15 g_16
 */
static int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_4 = 0xD2E8588DL;
    int32_t l_14 = 1L;
    uint16_t l_17[5];
    int i;
    for (i = 0; i < 5; i++)
        l_17[i] = 0x8AB7L;
    g_6 = ((safe_sub_func_int32_t_s_s(0L, l_4)) != g_5[4]);
    g_9[0] = ((safe_sub_func_int64_t_s_s(g_5[0], l_4)) | l_4);
    g_15[0] = ((safe_add_func_int64_t_s_s((safe_lshift_func_uint8_t_u_s(g_5[6], l_4)), l_14)) , l_4);
    g_16 = g_15[1];
    return l_17[1];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_9[i], "g_9[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_15[i], "g_15[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_16, "g_16", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 8
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 6
   depth: 3, occurrence: 2
   depth: 4, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 11
XXX times a non-volatile is write: 4
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 5
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 5

XXX percentage a fresh-made variable is used: 53.3
XXX percentage an existing variable is used: 46.7
********************* end of statistics **********************/

