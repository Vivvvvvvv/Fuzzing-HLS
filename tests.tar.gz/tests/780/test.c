/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      2392313738302766617
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int8_t g_13 = 7L;/* VOLATILE GLOBAL g_13 */
static volatile uint16_t g_14 = 5UL;/* VOLATILE GLOBAL g_14 */
static volatile int32_t g_15 = 0x45F5B1B6L;/* VOLATILE GLOBAL g_15 */
static int32_t g_16[4][6] = {{0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L},{0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L},{0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L},{0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L,0x3DDCA272L}};
static int32_t g_19 = 5L;
static uint64_t g_22 = 1UL;


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static uint8_t  func_2(int16_t  p_3, int16_t  p_4);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_13 g_16 g_19 g_22 g_14 g_15
 * writes: g_14 g_16 g_15 g_19 g_22
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_5[2][4] = {{0x44L,0L,0x44L,0x44L},{0L,0L,0xB0L,0L}};
    int32_t l_12[3][1][1];
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 1; k++)
                l_12[i][j][k] = 9L;
        }
    }
    l_12[0][0][0] = (func_2(l_5[0][1], l_5[0][1]) , l_5[0][1]);
lbl_25:
    g_14 = g_13;
    for (g_16[0][4] = 20; (g_16[0][4] == 14); g_16[0][4] = safe_sub_func_int16_t_s_s(g_16[0][4], 3))
    { /* block id: 8 */
        for (g_15 = 0; g_15 < 2; g_15 += 1)
        {
            for (g_14 = 0; g_14 < 4; g_14 += 1)
            {
                l_5[g_15][g_14] = 0x09L;
            }
        }
        for (g_19 = (-21); (g_19 > (-13)); ++g_19)
        { /* block id: 12 */
            ++g_22;
        }
        if (g_22)
            goto lbl_25;
        g_19 = func_2((l_5[0][1] <= g_14), l_12[0][0][0]);
    }
    g_15 |= g_19;
    return g_15;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint8_t  func_2(int16_t  p_3, int16_t  p_4)
{ /* block id: 1 */
    uint16_t l_10[8];
    int32_t l_11 = 1L;
    int i;
    for (i = 0; i < 8; i++)
        l_10[i] = 0xFE30L;
    l_11 = (safe_sub_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u((l_10[7] >= 0x97412DF3D37A5B7DLL), l_10[4])), l_10[3]));
    return p_3;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_13, "g_13", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_15, "g_15", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_16[i][j], "g_16[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 7
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 4
breakdown:
   depth: 1, occurrence: 13
   depth: 2, occurrence: 2
   depth: 4, occurrence: 3

XXX total number of pointers: 0

XXX times a non-volatile is read: 12
XXX times a non-volatile is write: 6
XXX times a volatile is read: 3
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 18
XXX percentage of non-volatile access: 78.3

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 12
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 7
   depth: 1, occurrence: 4
   depth: 2, occurrence: 1

XXX percentage a fresh-made variable is used: 35
XXX percentage an existing variable is used: 65
********************* end of statistics **********************/

