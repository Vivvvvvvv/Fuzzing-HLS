/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      6538235092902859048
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int32_t  f0;
   int64_t  f1;
   int16_t  f2;
   const uint8_t  f3;
   int16_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_3 = 1L;/* VOLATILE GLOBAL g_3 */
static int32_t g_4 = (-9L);
static struct S0 g_23 = {0x80335900L,-1L,7L,6UL,1L};/* VOLATILE GLOBAL g_23 */
static struct S0 g_34[4] = {{0L,0xF39F3C5A4A104ACDLL,-8L,0UL,0x4F6CL},{0L,0xF39F3C5A4A104ACDLL,-8L,0UL,0x4F6CL},{0L,0xF39F3C5A4A104ACDLL,-8L,0UL,0x4F6CL},{0L,0xF39F3C5A4A104ACDLL,-8L,0UL,0x4F6CL}};
static struct S0 g_47 = {0x4340421AL,0x6747B1D005767A06LL,1L,1UL,3L};/* VOLATILE GLOBAL g_47 */
static uint64_t g_52 = 4UL;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static struct S0  func_5(uint8_t  p_6, int8_t  p_7);
static const uint16_t  func_30(uint32_t  p_31, int32_t  p_32, int32_t  p_33);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_23 g_34 g_47 g_52
 * writes: g_4 g_47.f0 g_52 g_34.f0 g_3
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    uint8_t l_2[5] = {9UL,9UL,9UL,9UL,9UL};
    int32_t l_48 = 0x9421A0E5L;
    int32_t l_49 = 0xF68020C2L;
    int32_t l_51 = 1L;
    int64_t l_66 = 6L;
    int i;
    for (g_4 = 4; (g_4 >= 0); g_4 -= 1)
    { /* block id: 3 */
        int32_t l_50 = 0x56627F1AL;
        uint32_t l_60 = 18446744073709551608UL;
        uint8_t l_67 = 247UL;
        int32_t l_74[2];
        int i;
        for (i = 0; i < 2; i++)
            l_74[i] = 0xCB4F9107L;
        if ((func_5((~(safe_mul_func_int16_t_s_s(l_2[g_4], l_2[4]))), g_3) , g_34[2].f1))
        { /* block id: 22 */
            g_47.f0 |= g_23.f2;
            g_52++;
            if (l_50)
                break;
            g_47.f0 = ((l_50 , g_52) , l_50);
        }
        else
        { /* block id: 27 */
            uint32_t l_59 = 0x54CD8D27L;
            int32_t l_61 = 0x19D8D777L;
            uint16_t l_62 = 0xC29FL;
            l_61 = ((safe_rshift_func_int8_t_s_u(((safe_mul_func_int8_t_s_s((((((0x90L > g_47.f3) | l_51) < l_59) >= l_50) >= 0xFBL), 1L)) > l_60), 3)) && (-4L));
            ++l_62;
            g_34[2].f0 = (((((((+18446744073709551615UL) , 0L) || l_51) ^ g_47.f4) && l_48) != 0xDE3FE27FL) > l_61);
            l_67++;
        }
        g_34[2].f0 = ((safe_sub_func_int64_t_s_s((safe_add_func_int8_t_s_s((l_50 >= l_60), l_74[1])), g_23.f4)) || l_48);
        g_3 = ((safe_unary_minus_func_int32_t_s((1UL || 0x60987955L))) & 4294967294UL);
        if (g_47.f4)
            break;
    }
    g_34[2].f0 = (safe_add_func_uint8_t_u_u(255UL, g_47.f2));
    g_4 |= (safe_lshift_func_int16_t_s_u((g_3 <= 0x26L), 10));
    l_51 = 0x3FBECF30L;
    return l_2[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_4 g_23 g_34 g_47
 * writes:
 */
static struct S0  func_5(uint8_t  p_6, int8_t  p_7)
{ /* block id: 4 */
    const int8_t l_17[6] = {0x83L,0x83L,0x83L,0x83L,0x83L,0x83L};
    int32_t l_41 = 0L;
    int i;
    if ((safe_mul_func_int8_t_s_s((safe_add_func_uint64_t_u_u((safe_mul_func_int16_t_s_s((((p_6 <= g_3) || g_4) , l_17[1]), g_4)), 0xE360DE5741311E2DLL)), 0xBBL)))
    { /* block id: 5 */
        uint64_t l_28 = 0x09E149CFF29C214FLL;
        int32_t l_29 = 0x1E33ECDCL;
        for (p_7 = 11; (p_7 != 11); p_7 = safe_add_func_int16_t_s_s(p_7, 9))
        { /* block id: 8 */
            uint16_t l_22 = 0x374FL;
            l_22 |= (safe_lshift_func_uint8_t_u_s(p_6, g_4));
            return g_23;
        }
        l_29 = (safe_sub_func_uint32_t_u_u((safe_mul_func_int8_t_s_s(l_28, 0x36L)), g_23.f0));
    }
    else
    { /* block id: 13 */
        l_41 = (func_30((g_34[2] , p_7), p_7, p_6) , g_23.f1);
    }
    l_41 = (safe_rshift_func_int8_t_s_s((safe_sub_func_uint16_t_u_u((safe_unary_minus_func_uint32_t_u((((((l_17[1] <= 1L) < 0x10L) && g_34[2].f3) , 3L) && g_23.f1))), 65535UL)), g_34[2].f2));
    return g_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_23.f4
 * writes:
 */
static const uint16_t  func_30(uint32_t  p_31, int32_t  p_32, int32_t  p_33)
{ /* block id: 14 */
    uint16_t l_35 = 1UL;
    int32_t l_36 = (-10L);
    int32_t l_37[2];
    uint32_t l_38 = 4294967295UL;
    int i;
    for (i = 0; i < 2; i++)
        l_37[i] = (-1L);
    l_35 |= (((p_33 , g_23.f4) < p_31) == 0x4E48L);
    ++l_38;
    return l_37[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_23.f0, "g_23.f0", print_hash_value);
    transparent_crc(g_23.f1, "g_23.f1", print_hash_value);
    transparent_crc(g_23.f2, "g_23.f2", print_hash_value);
    transparent_crc(g_23.f3, "g_23.f3", print_hash_value);
    transparent_crc(g_23.f4, "g_23.f4", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_34[i].f0, "g_34[i].f0", print_hash_value);
        transparent_crc(g_34[i].f1, "g_34[i].f1", print_hash_value);
        transparent_crc(g_34[i].f2, "g_34[i].f2", print_hash_value);
        transparent_crc(g_34[i].f3, "g_34[i].f3", print_hash_value);
        transparent_crc(g_34[i].f4, "g_34[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_47.f0, "g_47.f0", print_hash_value);
    transparent_crc(g_47.f1, "g_47.f1", print_hash_value);
    transparent_crc(g_47.f2, "g_47.f2", print_hash_value);
    transparent_crc(g_47.f3, "g_47.f3", print_hash_value);
    transparent_crc(g_47.f4, "g_47.f4", print_hash_value);
    transparent_crc(g_52, "g_52", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 21
   depth: 1, occurrence: 3
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 10
breakdown:
   depth: 1, occurrence: 30
   depth: 2, occurrence: 4
   depth: 3, occurrence: 4
   depth: 4, occurrence: 1
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 49
XXX times a non-volatile is write: 14
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 35
XXX percentage of non-volatile access: 86.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 28
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 7
   depth: 2, occurrence: 10

XXX percentage a fresh-made variable is used: 28.6
XXX percentage an existing variable is used: 71.4
********************* end of statistics **********************/

