/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      5818906461293278538
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint8_t g_16 = 0x1AL;
static int32_t g_29 = 0x7E815F84L;
static uint32_t g_33 = 1UL;
static int16_t g_34[6] = {0xDC87L,0xA41BL,0xDC87L,0xDC87L,0xA41BL,0xDC87L};
static int64_t g_47[10] = {0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL,0x361131E34F9A325CLL};


/* --- FORWARD DECLARATIONS --- */
static uint64_t  func_1(void);
static int8_t  func_6(uint32_t  p_7, uint32_t  p_8, uint32_t  p_9, int64_t  p_10, uint32_t  p_11);
static int32_t  func_17(uint32_t  p_18, int16_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_16 g_29 g_33 g_34 g_47
 * writes: g_29 g_33 g_34 g_16
 */
static uint64_t  func_1(void)
{ /* block id: 0 */
    int8_t l_14 = 4L;
    int64_t l_15 = (-1L);
    int32_t l_39 = 0L;
    int32_t l_54[8];
    int32_t l_63 = 0x7039802EL;
    int i;
    for (i = 0; i < 8; i++)
        l_54[i] = 1L;
    g_34[1] = (~(safe_add_func_int32_t_s_s(((!((func_6((safe_mul_func_int16_t_s_s(0L, 0xA149L)), l_14, l_15, g_16, l_14) || g_29) , g_33)) < 0UL), 0x9D9E62B5L)));
    for (g_16 = (-5); (g_16 > 33); g_16 = safe_add_func_int16_t_s_s(g_16, 3))
    { /* block id: 12 */
        int16_t l_45 = (-6L);
        const uint16_t l_46 = 0x5DB0L;
        int32_t l_48 = 0xBA684A08L;
        uint8_t l_49 = 0x19L;
        uint32_t l_58 = 4294967291UL;
        for (g_33 = 4; (g_33 > 43); g_33 = safe_add_func_uint16_t_u_u(g_33, 4))
        { /* block id: 15 */
            uint16_t l_40 = 65528UL;
            --l_40;
            g_29 &= ((safe_lshift_func_uint8_t_u_u(l_45, l_46)) , g_33);
            l_49--;
        }
        l_54[4] ^= (safe_sub_func_uint64_t_u_u((l_39 || l_15), l_39));
        l_48 |= (safe_unary_minus_func_int64_t_s(((safe_mul_func_int16_t_s_s(l_58, l_54[0])) , 1L)));
        if (g_29)
        { /* block id: 22 */
            l_63 = ((safe_mul_func_uint16_t_u_u(((safe_lshift_func_uint16_t_u_s(g_34[1], l_54[4])) | 9L), g_33)) >= g_34[5]);
        }
        else
        { /* block id: 24 */
            g_29 = g_47[8];
            l_39 &= l_49;
            if (g_33)
                break;
        }
    }
    return g_34[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_29 g_33
 * writes: g_29 g_33
 */
static int8_t  func_6(uint32_t  p_7, uint32_t  p_8, uint32_t  p_9, int64_t  p_10, uint32_t  p_11)
{ /* block id: 1 */
    int16_t l_26 = 0L;
    g_33 |= (func_17(((safe_sub_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((safe_div_func_int64_t_s_s((l_26 || g_16), g_16)), 0x01L)), g_16)) ^ g_16), l_26) < g_16);
    g_29 = l_26;
    return p_11;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_29
 * writes: g_29
 */
static int32_t  func_17(uint32_t  p_18, int16_t  p_19)
{ /* block id: 2 */
    uint32_t l_30[5] = {0UL,0UL,0UL,0UL,0UL};
    int i;
    g_29 ^= (safe_mul_func_int8_t_s_s(g_16, 0x81L));
    ++l_30[2];
    return g_16;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_29, "g_29", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_34[i], "g_34[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_47[i], "g_47[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 18
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 11
breakdown:
   depth: 1, occurrence: 24
   depth: 2, occurrence: 3
   depth: 3, occurrence: 3
   depth: 5, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 36
XXX times a non-volatile is write: 15
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 20
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 4
   depth: 2, occurrence: 7

XXX percentage a fresh-made variable is used: 34
XXX percentage an existing variable is used: 66
********************* end of statistics **********************/

