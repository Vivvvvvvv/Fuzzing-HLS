/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1213138048382423583
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int32_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static volatile int16_t g_5[5] = {0xA4F4L,0xA4F4L,0xA4F4L,0xA4F4L,0xA4F4L};
static int32_t g_7 = 0xCC590F02L;
static struct S0 g_27 = {0xF18EE85EL};
static int32_t g_29[9] = {0x289C089CL,0x289C089CL,0x289C089CL,0x289C089CL,0x289C089CL,0x289C089CL,0x289C089CL,0x289C089CL,0x289C089CL};


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);
static int32_t  func_9(uint64_t  p_10, uint16_t  p_11, struct S0  p_12, uint64_t  p_13, int32_t  p_14);
static uint64_t  func_17(uint32_t  p_18, int8_t  p_19, uint32_t  p_20, struct S0  p_21);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_7 g_27
 * writes: g_29
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    int64_t l_4 = (-1L);
    volatile int32_t l_6 = 0x937A3A11L;/* VOLATILE GLOBAL l_6 */
    int32_t l_8 = 0xE6DC660FL;
    struct S0 l_24 = {0x097BC8B4L};
    if ((safe_rshift_func_int16_t_s_s(l_4, 12)))
    { /* block id: 1 */
        l_6 = g_5[0];
    }
    else
    { /* block id: 3 */
        l_8 &= ((g_5[0] == g_7) > g_7);
    }
    g_29[3] = func_9((safe_sub_func_uint64_t_u_u(func_17((safe_mod_func_uint8_t_u_u(l_4, l_4)), l_8, l_6, l_24), l_4)), l_4, g_27, g_27.f0, l_24.f0);
    return l_6;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_9(uint64_t  p_10, uint16_t  p_11, struct S0  p_12, uint64_t  p_13, int32_t  p_14)
{ /* block id: 9 */
    int64_t l_28 = (-1L);
    return l_28;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint64_t  func_17(uint32_t  p_18, int8_t  p_19, uint32_t  p_20, struct S0  p_21)
{ /* block id: 6 */
    uint8_t l_25 = 0UL;
    int32_t l_26 = (-9L);
    l_26 = l_25;
    return l_26;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_5[i], "g_5[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_7, "g_7", print_hash_value);
    transparent_crc(g_27.f0, "g_27.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_29[i], "g_29[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 9
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 9
   depth: 2, occurrence: 1
   depth: 3, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 15
XXX times a non-volatile is write: 3
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 7
XXX percentage of non-volatile access: 78.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 8
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 6
   depth: 1, occurrence: 2

XXX percentage a fresh-made variable is used: 47.8
XXX percentage an existing variable is used: 52.2
********************* end of statistics **********************/

