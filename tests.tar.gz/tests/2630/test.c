/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1178699133585024673
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_5 = 0xCCB03629L;/* VOLATILE GLOBAL g_5 */
static const uint8_t g_22[8] = {0x92L,0x92L,0x92L,0x92L,0x92L,0x92L,0x92L,0x92L};
static int32_t g_24 = 0L;
static int64_t g_25 = 1L;
static uint16_t g_39 = 0xB017L;
static uint8_t g_42 = 1UL;
static uint32_t g_44[3] = {0x1F8487B2L,0x1F8487B2L,0x1F8487B2L};


/* --- FORWARD DECLARATIONS --- */
static const int16_t  func_1(void);
static int16_t  func_11(int16_t  p_12, int32_t  p_13);
static uint32_t  func_32(uint32_t  p_33, int8_t  p_34, uint8_t  p_35, int32_t  p_36);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_22 g_25 g_39 g_24 g_42 g_44
 * writes: g_5 g_24 g_25 g_39 g_42 g_44
 */
static const int16_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2[4] = {(-1L),(-1L),(-1L),(-1L)};
    int32_t l_3 = 0x4288A137L;
    int32_t l_4 = (-10L);
    const uint32_t l_21 = 0x72A67F8BL;
    int32_t l_37 = (-4L);
    uint8_t l_47 = 0xD1L;
    int i;
    --g_5;
    l_3 |= (-1L);
    for (l_4 = (-12); (l_4 > 0); l_4 = safe_add_func_int64_t_s_s(l_4, 3))
    { /* block id: 5 */
        int8_t l_20 = 0x31L;
        g_25 = ((~func_11((safe_rshift_func_int8_t_s_u(((safe_lshift_func_int8_t_s_u(((safe_rshift_func_int8_t_s_s((((l_20 >= l_20) >= 0x6B6CL) , l_20), g_5)) != 0x4CAAL), l_21)) > g_22[0]), 6)), g_22[1])) & g_22[1]);
        g_44[1] &= (safe_add_func_uint64_t_u_u((safe_sub_func_int32_t_s_s((((safe_sub_func_uint32_t_u_u(func_32(l_37, l_21, g_22[3], g_25), g_25)) || 2UL) == g_25), g_22[0])), l_2[1]));
    }
    l_3 = ((((safe_lshift_func_uint8_t_u_s(g_22[3], l_47)) , g_22[0]) | g_25) != g_24);
    return l_2[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_22
 * writes: g_24
 */
static int16_t  func_11(int16_t  p_12, int32_t  p_13)
{ /* block id: 6 */
    int16_t l_23 = 1L;
    g_24 = (l_23 >= 0UL);
    p_13 = (0xE0FA1A8F1EDD1EDBLL & l_23);
    return g_22[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_39 g_24 g_42 g_5
 * writes: g_39 g_24 g_42
 */
static uint32_t  func_32(uint32_t  p_33, int8_t  p_34, uint8_t  p_35, int32_t  p_36)
{ /* block id: 11 */
    int8_t l_38 = 1L;
    int32_t l_43 = 1L;
    g_39 &= (l_38 != p_34);
    for (g_24 = 25; (g_24 < 11); --g_24)
    { /* block id: 15 */
        g_42 |= (l_38 & l_38);
    }
    l_43 = (g_5 & 0xB171C2502870B1B9LL);
    return g_24;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_5, "g_5", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_22[i], "g_22[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_24, "g_24", print_hash_value);
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_42, "g_42", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_44[i], "g_44[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 17
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 12
breakdown:
   depth: 1, occurrence: 15
   depth: 2, occurrence: 7
   depth: 5, occurrence: 1
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 31
XXX times a non-volatile is write: 11
XXX times a volatile is read: 2
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 16
XXX percentage of non-volatile access: 93.3

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 15
XXX max block depth: 1
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 3

XXX percentage a fresh-made variable is used: 38.6
XXX percentage an existing variable is used: 61.4
********************* end of statistics **********************/

