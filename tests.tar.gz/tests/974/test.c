/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14984576125171293300
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile uint32_t g_5[5][9] = {{4294967295UL,0x17B844A7L,0x21F90EF3L,4294967295UL,0x21F90EF3L,0x17B844A7L,4294967295UL,0xF5A9C4C8L,4294967295UL},{0xF5A9C4C8L,0x3C891C55L,4294967295UL,4294967295UL,4294967291UL,0x17B844A7L,4294967291UL,4294967295UL,4294967295UL},{4294967295UL,4294967295UL,1UL,0xAA6E6F7FL,4294967295UL,0x3C891C55L,0x17B844A7L,0xF5A9C4C8L,0x17B844A7L},{4294967295UL,4294967295UL,0x3C891C55L,0x3C891C55L,4294967295UL,4294967295UL,0xAA6E6F7FL,0x21F90EF3L,1UL},{0xF5A9C4C8L,4294967295UL,1UL,1UL,4294967295UL,4294967295UL,1UL,1UL,4294967295UL}};
static uint8_t g_6 = 0xAAL;
static uint32_t g_7[10][1][4] = {{{0UL,0x108531D1L,0x43C6FE23L,18446744073709551615UL}},{{0x491BA6B4L,0x108531D1L,0UL,0UL}},{{0x108531D1L,0x912530A9L,0x912530A9L,0x108531D1L}},{{0x43C6FE23L,0UL,0x912530A9L,18446744073709551615UL}},{{0x108531D1L,0x491BA6B4L,0UL,0x491BA6B4L}},{{0x491BA6B4L,0x912530A9L,0x43C6FE23L,0x491BA6B4L}},{{0x43C6FE23L,0x491BA6B4L,18446744073709551615UL,18446744073709551615UL}},{{0UL,0UL,0UL,0x108531D1L}},{{0UL,0x912530A9L,18446744073709551615UL,0UL}},{{0x43C6FE23L,0x108531D1L,0x43C6FE23L,18446744073709551615UL}}};
static uint64_t g_10 = 1UL;
static uint8_t g_18 = 0x1EL;
static volatile uint32_t g_41[5] = {0x7F0A061FL,0x7F0A061FL,0x7F0A061FL,0x7F0A061FL,0x7F0A061FL};
static uint8_t g_57 = 1UL;
static int32_t g_70 = 0x17922C1EL;
static int8_t g_103 = (-1L);
static int64_t g_105 = 0xB4A016C9CC5FAE8CLL;
static volatile int32_t g_108 = 0x68EBAD55L;/* VOLATILE GLOBAL g_108 */
static volatile uint32_t g_110 = 0x180DBEA5L;/* VOLATILE GLOBAL g_110 */


/* --- FORWARD DECLARATIONS --- */
static int64_t  func_1(void);
static const uint64_t  func_2(int32_t  p_3, int32_t  p_4);
static const uint16_t  func_16(uint64_t  p_17);
static const uint8_t  func_22(int64_t  p_23, uint64_t  p_24, int16_t  p_25);
static int8_t  func_35(int8_t  p_36, const int16_t  p_37, int32_t  p_38);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_5 g_6 g_7 g_10 g_18 g_41 g_57 g_70 g_103 g_110 g_105
 * writes: g_7 g_10 g_6 g_18 g_41 g_57 g_70 g_103 g_110 g_108
 */
static int64_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_99 = 18446744073709551615UL;
    int32_t l_104 = 1L;
    int32_t l_107 = 0x2E1657FBL;
    if (((func_2((g_5[4][0] >= 0L), g_6) != 0xADBCF703B84D8593LL) < 4294967293UL))
    { /* block id: 71 */
        int32_t l_98[2];
        int i;
        for (i = 0; i < 2; i++)
            l_98[i] = (-6L);
        for (g_70 = 0; (g_70 >= 0); g_70 -= 1)
        { /* block id: 74 */
            l_99 ^= ((g_57 | l_98[1]) | g_7[2][0][3]);
            if (g_5[3][4])
                break;
            g_103 |= (((+(safe_mul_func_int16_t_s_s(l_99, g_5[4][0]))) ^ l_98[1]) & g_70);
            if (g_10)
                continue;
        }
    }
    else
    { /* block id: 80 */
        int32_t l_109 = 0x9D6A3610L;
        l_104 = 0x425F0F44L;
        g_70 |= g_18;
        if (((l_104 >= g_70) && 0x13618026BCB33D27LL))
        { /* block id: 83 */
            int8_t l_106 = (-1L);
            g_110++;
        }
        else
        { /* block id: 85 */
            int32_t l_118 = (-1L);
            int32_t l_119 = 9L;
            g_108 = ((safe_lshift_func_int16_t_s_s(((safe_add_func_uint8_t_u_u((((~l_107) <= g_110) == l_107), (-1L))) & 0x09845791L), l_99)) && g_105);
            l_104 &= (1L <= 246UL);
            g_70 = l_107;
            l_119 |= ((l_118 > 4294967290UL) , g_70);
        }
    }
    g_108 = l_107;
    g_70 = (safe_mul_func_int8_t_s_s(((255UL >= 0UL) != 0xD785604A185305F7LL), g_110));
    return g_105;
}


/* ------------------------------------------ */
/* 
 * reads : g_7 g_10 g_6 g_18 g_41 g_57 g_5 g_70
 * writes: g_7 g_10 g_6 g_18 g_41 g_57 g_70
 */
static const uint64_t  func_2(int32_t  p_3, int32_t  p_4)
{ /* block id: 1 */
    int16_t l_19 = 6L;
    int64_t l_26 = 3L;
    int32_t l_94 = (-10L);
    ++g_7[8][0][2];
    g_10 &= g_7[4][0][3];
    for (g_10 = 7; (g_10 < 44); ++g_10)
    { /* block id: 6 */
        uint32_t l_15 = 0x6966EF3BL;
        int32_t l_97[3][5][4] = {{{1L,(-1L),0xD64B6C7FL,0xD64B6C7FL},{0xE5F3B424L,0xE5F3B424L,1L,0xD64B6C7FL},{0xE5B6057BL,(-1L),0xE5B6057BL,1L},{0xE5B6057BL,1L,1L,0xE5B6057BL},{0xE5F3B424L,1L,0xD64B6C7FL,1L}},{{1L,(-1L),0xD64B6C7FL,0xD64B6C7FL},{0xE5F3B424L,0xE5F3B424L,1L,0xD64B6C7FL},{0xE5B6057BL,(-1L),0xE5B6057BL,1L},{0xE5B6057BL,1L,1L,0xE5B6057BL},{0xE5F3B424L,1L,0xD64B6C7FL,1L}},{{1L,(-1L),0xD64B6C7FL,0xD64B6C7FL},{0xE5F3B424L,0xE5F3B424L,1L,0xD64B6C7FL},{0xE5B6057BL,(-1L),0xE5B6057BL,1L},{0xE5B6057BL,1L,1L,0xE5B6057BL},{0xE5F3B424L,1L,0xD64B6C7FL,1L}}};
        int i, j, k;
        for (g_6 = 0; (g_6 != 12); g_6 = safe_add_func_int32_t_s_s(g_6, 6))
        { /* block id: 9 */
            if (l_15)
                break;
            p_4 = (func_16(g_6) | l_19);
        }
        if (g_7[9][0][0])
            break;
        l_94 = (((safe_rshift_func_uint8_t_u_u(func_22(l_26, g_6, l_15), l_26)) <= p_4) < g_7[3][0][2]);
        if ((safe_rshift_func_int8_t_s_u((p_3 || 251UL), 7)))
        { /* block id: 63 */
            l_97[0][0][1] = p_4;
        }
        else
        { /* block id: 65 */
            if (g_6)
                break;
            if (g_5[4][5])
                continue;
        }
    }
    return l_26;
}


/* ------------------------------------------ */
/* 
 * reads : g_6 g_18
 * writes: g_18
 */
static const uint16_t  func_16(uint64_t  p_17)
{ /* block id: 11 */
    g_18 ^= (g_6 , p_17);
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_18 g_41 g_6 g_57 g_5 g_70 g_7
 * writes: g_18 g_41 g_57 g_70
 */
static const uint8_t  func_22(int64_t  p_23, uint64_t  p_24, int16_t  p_25)
{ /* block id: 17 */
    int16_t l_27 = 1L;
    uint8_t l_30 = 0xB6L;
    int32_t l_91 = 0xE342BA51L;
lbl_86:
    l_27 = 1L;
    if (((((safe_mod_func_int32_t_s_s(0x57F54AB1L, g_10)) && l_27) || 0xBF3F079038991F32LL) <= l_30))
    { /* block id: 19 */
        int8_t l_87 = (-5L);
        if ((safe_sub_func_uint64_t_u_u((safe_mul_func_int8_t_s_s(func_35(g_10, l_27, p_23), p_25)), 18446744073709551611UL)))
        { /* block id: 50 */
lbl_92:
            if (p_23)
                goto lbl_86;
            return p_24;
        }
        else
        { /* block id: 53 */
            int64_t l_90[6] = {0xE3B64D7EEACC2001LL,0x77BC7A95E7740573LL,0xE3B64D7EEACC2001LL,0xE3B64D7EEACC2001LL,0x77BC7A95E7740573LL,0xE3B64D7EEACC2001LL};
            int i;
            l_87 = g_7[9][0][0];
            l_91 = (safe_add_func_int16_t_s_s(l_90[1], 65532UL));
            if (g_70)
                goto lbl_92;
        }
        return p_24;
    }
    else
    { /* block id: 59 */
        const int16_t l_93 = 0xD0A3L;
        return l_93;
    }
}


/* ------------------------------------------ */
/* 
 * reads : g_18 g_41 g_6 g_57 g_5 g_70
 * writes: g_18 g_41 g_57 g_70
 */
static int8_t  func_35(int8_t  p_36, const int16_t  p_37, int32_t  p_38)
{ /* block id: 20 */
    uint16_t l_53 = 0xF412L;
    int32_t l_56 = 0L;
    for (g_18 = 0; (g_18 <= 13); g_18 = safe_add_func_uint16_t_u_u(g_18, 9))
    { /* block id: 23 */
        int64_t l_52 = 0x2489AFFF74B76FEFLL;
        int32_t l_55 = 0xBF520F09L;
        ++g_41[1];
        for (p_36 = 0; (p_36 >= 1); ++p_36)
        { /* block id: 27 */
            int32_t l_54[3];
            int i;
            for (i = 0; i < 3; i++)
                l_54[i] = 0xED9E8BD6L;
            l_54[2] = (safe_rshift_func_int8_t_s_u((safe_add_func_uint16_t_u_u((safe_mod_func_int64_t_s_s((p_36 >= 4UL), l_52)), l_53)), l_54[2]));
            l_55 = (g_6 & 18446744073709551614UL);
        }
    }
    g_57++;
    if (p_36)
    { /* block id: 33 */
        uint8_t l_60 = 246UL;
        l_60 = 0L;
    }
    else
    { /* block id: 35 */
        int32_t l_65 = 0x97E6E185L;
        uint32_t l_69 = 1UL;
        uint64_t l_71 = 0xFDB9CE086565EA9DLL;
        if (((safe_lshift_func_int8_t_s_u((safe_mul_func_int16_t_s_s(l_56, 6UL)), g_18)) >= g_5[4][8]))
        { /* block id: 36 */
            int32_t l_66 = 1L;
            l_66 = (g_41[1] > l_65);
            g_70 = (safe_sub_func_int32_t_s_s((l_69 >= 5UL), 0xF898D4EDL));
        }
        else
        { /* block id: 39 */
            uint8_t l_72 = 252UL;
            uint64_t l_80 = 0x1936EFE450DE0B5DLL;
            l_72 |= (l_71 , 0x6B3FA45FL);
            g_70 = (safe_div_func_int32_t_s_s((safe_div_func_uint32_t_u_u((+((safe_mul_func_uint8_t_u_u(g_5[1][5], g_57)) == l_80)), 4294967288UL)), p_36));
        }
        for (p_38 = 0; (p_38 <= 9); ++p_38)
        { /* block id: 45 */
            int32_t l_85 = 0L;
            g_70 ^= (safe_lshift_func_int8_t_s_u((l_53 >= p_38), l_85));
        }
    }
    return p_36;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_5[i][j], "g_5[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_6, "g_6", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_7[i][j][k], "g_7[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_41[i], "g_41[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_57, "g_57", print_hash_value);
    transparent_crc(g_70, "g_70", print_hash_value);
    transparent_crc(g_103, "g_103", print_hash_value);
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_108, "g_108", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 44
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 59
   depth: 2, occurrence: 12
   depth: 3, occurrence: 7
   depth: 4, occurrence: 3
   depth: 5, occurrence: 3
   depth: 6, occurrence: 2
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 74
XXX times a non-volatile is write: 32
XXX times a volatile is read: 9
XXX    times read thru a pointer: 0
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 45
XXX percentage of non-volatile access: 89.1

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 58
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 16
   depth: 2, occurrence: 26

XXX percentage a fresh-made variable is used: 37.9
XXX percentage an existing variable is used: 62.1
********************* end of statistics **********************/

