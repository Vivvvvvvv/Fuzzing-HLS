/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      1281825189886636832
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint16_t g_10 = 0xB8FAL;
static int32_t g_21[5] = {(-8L),(-8L),(-8L),(-8L),(-8L)};
static volatile uint16_t g_25 = 65535UL;/* VOLATILE GLOBAL g_25 */
static uint32_t g_31 = 6UL;
static int32_t g_32 = 0x3B8CFF26L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int16_t  func_4(uint16_t  p_5, uint32_t  p_6, int32_t  p_7, uint8_t  p_8);
static const int8_t  func_15(const int32_t  p_16, int8_t  p_17, int32_t  p_18, uint32_t  p_19);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_25 g_31 g_32
 * writes: g_21 g_25 g_32
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_9 = 0x65AB3E90L;
    g_32 |= (safe_sub_func_uint32_t_u_u((func_4(l_9, g_10, l_9, l_9) , g_31), l_9));
    return l_9;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_21 g_25
 * writes: g_21 g_25
 */
static int16_t  func_4(uint16_t  p_5, uint32_t  p_6, int32_t  p_7, uint8_t  p_8)
{ /* block id: 1 */
    int8_t l_23 = 6L;
    int32_t l_24[5];
    uint32_t l_28 = 0xC3F30B91L;
    int i;
    for (i = 0; i < 5; i++)
        l_24[i] = (-8L);
    l_24[3] |= ((safe_mul_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u(func_15(g_10, p_5, p_7, p_5), l_23)), 0x41L)) , l_23);
    l_24[3] = p_6;
    g_25++;
    l_28--;
    return g_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_21
 * writes: g_21
 */
static const int8_t  func_15(const int32_t  p_16, int8_t  p_17, int32_t  p_18, uint32_t  p_19)
{ /* block id: 2 */
    uint64_t l_20 = 0x5E0710DD013D0BB9LL;
    const uint32_t l_22 = 0x071A0513L;
    g_21[1] &= ((0x1245C8100C4307E4LL ^ 0x611BC383C67EE39FLL) && l_20);
    return l_22;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_21[i], "g_21[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_25, "g_25", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 11
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 8
breakdown:
   depth: 1, occurrence: 12
   depth: 3, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 17
XXX times a non-volatile is write: 5
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 95.7

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 9
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 9

XXX percentage a fresh-made variable is used: 47.8
XXX percentage an existing variable is used: 52.2
********************* end of statistics **********************/

