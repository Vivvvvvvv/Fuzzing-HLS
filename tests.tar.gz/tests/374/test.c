/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      14353926304499795803
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint32_t  f0;
   volatile uint64_t  f1;
   uint32_t  f2;
   const volatile uint64_t  f3;
   uint8_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0L;
static uint32_t g_35 = 0UL;
static int32_t g_53 = 0xEE22E7E1L;
static uint32_t g_80 = 0xF313C854L;
static int32_t g_115 = (-2L);
static int16_t g_116 = 0x0344L;
static volatile uint16_t g_117 = 0x297CL;/* VOLATILE GLOBAL g_117 */
static int8_t g_131 = (-7L);
static int16_t g_132 = 0x49EDL;
static volatile int32_t g_134 = 7L;/* VOLATILE GLOBAL g_134 */
static int32_t g_136[8][6][4] = {{{(-1L),0x83CBDCB8L,0x6A2F1C6AL,0x63805CA1L},{0L,0x896CD410L,0xD3911739L,0x63805CA1L},{8L,0x83CBDCB8L,0x5700571AL,0x096ABDE1L},{0xCCA4C161L,1L,(-7L),(-9L)},{8L,1L,0x1988AFCEL,0x896CD410L},{(-1L),9L,0L,0x7B099B75L}},{{0x5BE4CFF9L,0L,0L,0x2D762005L},{(-1L),(-1L),(-8L),0xE01A2308L},{0L,0x63805CA1L,0x7F53FFDEL,1L},{0xBEFC3FFFL,0x5700571AL,(-1L),0xBC596D85L},{0xBC596D85L,1L,0x1B918F6EL,0xCCA4C161L},{0x683EEDB4L,(-1L),0x896CD410L,4L}},{{9L,8L,8L,1L},{(-4L),(-7L),8L,(-7L)},{1L,0xD3911739L,0L,0xC67237AFL},{0x734BBECAL,0xBD5E56ADL,(-7L),0x896CD410L},{0x5700571AL,0xE7EC8F53L,(-1L),0xE01A2308L},{0x5700571AL,0L,(-7L),0x83CBDCB8L}},{{0x734BBECAL,0xE01A2308L,0L,0x49199376L},{1L,1L,8L,(-8L)},{(-4L),0xCD35FECEL,8L,0x683EEDB4L},{9L,1L,0x896CD410L,0xE7EC8F53L},{0xC67237AFL,0xBC596D85L,0x995BFD21L,0x7B099B75L},{8L,0x598BD184L,0xE3999123L,8L}},{{0xBD5E56ADL,0x1B918F6EL,(-1L),(-7L)},{0L,0x1988AFCEL,0x97C9880EL,0xE3999123L},{0xD3911739L,0x896CD410L,0L,0xBEFC3FFFL},{8L,0x096ABDE1L,0x49199376L,1L},{0xBEFC3FFFL,0xAEADAD78L,0L,0L},{(-7L),(-7L),4L,(-2L)}},{{0x6A2F1C6AL,0xC67237AFL,0x63805CA1L,0L},{0xE01A2308L,0xE8B728ABL,0xCCA4C161L,0x63805CA1L},{0xBC596D85L,0xE8B728ABL,0x683EEDB4L,0L},{0xE8B728ABL,0xC67237AFL,1L,(-2L)},{1L,(-7L),(-9L),0L},{0L,0xAEADAD78L,0xE8B728ABL,1L}},{{0xCCA4C161L,0x096ABDE1L,1L,0xBEFC3FFFL},{(-5L),0x896CD410L,0L,0xE3999123L},{4L,0x1988AFCEL,0xD3911739L,(-7L)},{0x94AE63F1L,0x1B918F6EL,9L,8L},{0x5BE4CFF9L,0x598BD184L,0x6A2F1C6AL,0x7B099B75L},{0x7F53FFDEL,0xBC596D85L,0x096ABDE1L,0xE7EC8F53L}},{{0xAEADAD78L,1L,0xCD35FECEL,0x683EEDB4L},{(-1L),0xCD35FECEL,0xC67237AFL,(-8L)},{0xE7EC8F53L,1L,0xE7EC8F53L,0x49199376L},{4L,0xE01A2308L,9L,0x83CBDCB8L},{1L,0L,0x94AE63F1L,0xE01A2308L},{0x2D762005L,0xE7EC8F53L,0x94AE63F1L,0x896CD410L}}};
static int32_t g_137 = 0x849EEB4EL;
static uint64_t g_142 = 1UL;
static uint64_t g_194 = 0x822B181F6309FADELL;
static struct S0 g_197 = {0x092F33C9L,18446744073709551615UL,0x94D4D053L,0UL,1UL};/* VOLATILE GLOBAL g_197 */


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static int32_t  func_11(const uint32_t  p_12, int64_t  p_13, uint32_t  p_14, uint32_t  p_15);
static int32_t  func_62(uint64_t  p_63, int64_t  p_64, int8_t  p_65, int64_t  p_66, int32_t  p_67);
static int32_t  func_72(int16_t  p_73, const int32_t  p_74, uint16_t  p_75);
static uint32_t  func_101(uint16_t  p_102, uint32_t  p_103);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_35 g_53 g_80 g_117 g_115 g_142 g_137 g_136 g_131 g_116 g_194 g_197 g_134
 * writes: g_3 g_35 g_53 g_80 g_117 g_142 g_115 g_137 g_194
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint64_t l_2[3][3] = {{0xAFE01BD97A888ADALL,0xAFE01BD97A888ADALL,0xAFE01BD97A888ADALL},{0x3690F1D8987F2FB5LL,0x3690F1D8987F2FB5LL,0x3690F1D8987F2FB5LL},{0xAFE01BD97A888ADALL,0xAFE01BD97A888ADALL,0xAFE01BD97A888ADALL}};
    int32_t l_4 = 0L;
    int i, j;
    for (g_3 = 0; (g_3 <= 2); g_3 += 1)
    { /* block id: 3 */
        l_4 = g_3;
        for (l_4 = 2; (l_4 >= 0); l_4 -= 1)
        { /* block id: 7 */
            int i, j;
            return l_2[g_3][g_3];
        }
    }
    if (((((safe_rshift_func_uint8_t_u_s(((safe_rshift_func_int16_t_s_u((safe_add_func_uint32_t_u_u(l_2[0][1], l_2[0][0])), l_2[0][2])) > g_3), g_3)) >= g_3) > 0x67D926128F3B8C10LL) < 0x83D8L))
    { /* block id: 11 */
        const uint16_t l_46 = 0x66DFL;
        int16_t l_59 = (-3L);
        if (func_11((safe_rshift_func_int8_t_s_s(g_3, l_2[0][1])), g_3, g_3, g_3))
        { /* block id: 30 */
            int16_t l_40 = 0x97A0L;
            int32_t l_41 = 0x3EC6B9FEL;
            ++g_35;
            l_41 = (safe_sub_func_uint8_t_u_u((g_3 && 0L), l_40));
            g_3 = (safe_lshift_func_int8_t_s_u(((safe_mul_func_uint16_t_u_u(l_46, 0xB87EL)) > 9UL), l_41));
        }
        else
        { /* block id: 34 */
            return l_46;
        }
lbl_61:
        for (g_3 = (-9); (g_3 < 10); g_3 = safe_add_func_uint8_t_u_u(g_3, 5))
        { /* block id: 39 */
            if (g_35)
                break;
            g_53 = (safe_lshift_func_int8_t_s_s(((safe_add_func_int8_t_s_s(l_46, 250UL)) != 0xEAL), l_4));
        }
        g_3 &= ((l_2[2][2] != g_53) , 0x6F1A7E1FL);
        for (l_4 = (-29); (l_4 <= (-30)); l_4--)
        { /* block id: 46 */
            uint16_t l_60 = 0UL;
            g_53 = (safe_lshift_func_int8_t_s_u(((+l_59) || l_60), l_60));
            if (l_59)
                goto lbl_61;
            g_53 = g_53;
        }
    }
    else
    { /* block id: 51 */
        int32_t l_71 = (-4L);
        int32_t l_190 = 0xB425780FL;
        int32_t l_191 = (-1L);
        int32_t l_192 = 0x71C73E29L;
        if (func_62((safe_unary_minus_func_int32_t_s((safe_mod_func_uint16_t_u_u((func_11((l_2[1][1] != l_4), l_4, g_53, l_2[0][0]) != l_2[1][0]), l_4)))), g_35, l_71, g_53, l_71))
        { /* block id: 127 */
            g_137 = (l_71 > g_142);
            return l_71;
        }
        else
        { /* block id: 130 */
            uint16_t l_187[3];
            int32_t l_193[7][8][4] = {{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}},{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}},{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}},{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}},{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}},{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}},{{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)},{0L,3L,(-10L),(-1L)},{(-10L),(-1L),(-10L),3L},{0L,(-2L),(-10L),0xB51EEAC5L},{(-10L),0xB51EEAC5L,(-10L),(-2L)}}};
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_187[i] = 0x4569L;
            --l_187[2];
            g_194++;
            return g_194;
        }
    }
    g_3 ^= ((g_197 , g_134) < (-5L));
    return g_131;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_3
 */
static int32_t  func_11(const uint32_t  p_12, int64_t  p_13, uint32_t  p_14, uint32_t  p_15)
{ /* block id: 12 */
    uint32_t l_30[8][8] = {{4294967290UL,0x4FCD58F2L,1UL,0x2F82966BL,0UL,1UL,4294967290UL,0xEFEC1A2CL},{1UL,4294967287UL,0UL,4294967290UL,1UL,4294967289UL,0x2F82966BL,0x2F82966BL},{0x4FCD58F2L,0UL,0UL,0UL,0UL,0x4FCD58F2L,4294967290UL,1UL},{1UL,1UL,1UL,0xEFEC1A2CL,0x2F82966BL,4294967290UL,0x4FCD58F2L,1UL},{1UL,0x279191D4L,1UL,0xEFEC1A2CL,1UL,0x279191D4L,1UL,1UL},{0UL,1UL,4294967287UL,0UL,4294967290UL,1UL,4294967289UL,0x2F82966BL},{0xEFEC1A2CL,0x117A540FL,1UL,4294967290UL,4294967290UL,1UL,0x117A540FL,0xEFEC1A2CL},{0UL,0xEFEC1A2CL,0x279191D4L,0x2F82966BL,1UL,0x117A540FL,4294967287UL,1UL}};
    uint16_t l_34 = 2UL;
    int i, j;
    for (p_13 = 0; (p_13 >= (-15)); p_13 = safe_sub_func_uint64_t_u_u(p_13, 3))
    { /* block id: 15 */
        uint32_t l_29 = 8UL;
        for (p_14 = 11; (p_14 >= 13); p_14++)
        { /* block id: 18 */
            int32_t l_28[9] = {0x151CD25BL,0xCCE1CC0EL,0x151CD25BL,0x151CD25BL,0xCCE1CC0EL,0x151CD25BL,0x151CD25BL,0xCCE1CC0EL,0x151CD25BL};
            int32_t l_31[10][5] = {{0x253245E3L,5L,5L,0x253245E3L,0x74D9070AL},{0x605DD88BL,3L,6L,0x219FF40BL,0x32F4BB0FL},{1L,0x54F90BF5L,0x74D9070AL,0x54F90BF5L,1L},{3L,0L,(-6L),0x219FF40BL,(-5L)},{(-2L),0xCE4EC6F9L,0x253245E3L,0x253245E3L,0xCE4EC6F9L},{3L,6L,0x605DD88BL,0L,(-5L)},{0x54F90BF5L,0x253245E3L,1L,1L,1L},{(-5L),(-5L),3L,3L,0x32F4BB0FL},{0x54F90BF5L,1L,(-2L),0x74D9070AL,0x74D9070AL},{3L,0x18639784L,3L,0L,0x219FF40BL}};
            int i, j;
            l_30[6][3] &= (safe_mod_func_uint64_t_u_u((((safe_rshift_func_int16_t_s_s((safe_lshift_func_uint8_t_u_s((p_13 && l_28[4]), l_29)), 3)) == l_28[3]) , 18446744073709551614UL), g_3));
            if (p_14)
                continue;
            l_31[7][3] = p_14;
        }
        for (p_15 = 1; (p_15 <= 7); p_15 += 1)
        { /* block id: 25 */
            int i, j;
            g_3 &= ((safe_sub_func_uint32_t_u_u((0x61160DD4L >= l_30[p_15][p_15]), 0x0BBE90AEL)) , l_30[2][1]);
        }
    }
    return l_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_53 g_80 g_35 g_3 g_117 g_115 g_142 g_137 g_136 g_131 g_116
 * writes: g_80 g_3 g_117 g_53 g_142 g_115 g_35
 */
static int32_t  func_62(uint64_t  p_63, int64_t  p_64, int8_t  p_65, int64_t  p_66, int32_t  p_67)
{ /* block id: 52 */
    uint16_t l_76 = 0x5CE9L;
    int32_t l_141 = 0xFA489413L;
    int32_t l_145 = 3L;
    int32_t l_154 = 0xC9105A86L;
    int32_t l_155 = (-5L);
    int32_t l_161 = 6L;
    if (g_53)
    { /* block id: 53 */
        p_67 = func_72(l_76, l_76, p_63);
    }
    else
    { /* block id: 84 */
        int32_t l_130 = 0L;
        int32_t l_135[10] = {0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L,0xE3CA85F2L};
        uint16_t l_146 = 0x90A7L;
        int i;
        if (((-4L) & (-10L)))
        { /* block id: 85 */
            p_67 &= (safe_add_func_int8_t_s_s(0x5CL, g_115));
            g_53 |= ((safe_sub_func_int8_t_s_s((safe_add_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s(p_64, 13)), 1L)), l_76)) || 1L);
            p_67 |= 0x6ABAFA49L;
        }
        else
        { /* block id: 89 */
            int16_t l_129 = 1L;
            int32_t l_133 = (-1L);
            int32_t l_138 = 8L;
            int32_t l_139 = 1L;
            int32_t l_140 = (-9L);
            l_129 = g_3;
            g_142--;
            l_146++;
            p_67 = (p_63 == 0xC362L);
        }
    }
    if ((0x7DD5A8A1F86F2637LL <= p_63))
    { /* block id: 96 */
        int8_t l_151[6][7] = {{0xE1L,(-1L),(-9L),(-1L),(-5L),(-1L),(-9L)},{(-5L),(-5L),(-6L),1L,0x54L,(-1L),(-1L)},{0xC1L,(-6L),(-1L),0xF2L,0xE1L,0x54L,0L},{(-1L),0xABL,0x54L,(-1L),0x54L,0xABL,(-1L)},{0x2CL,(-1L),0L,(-1L),(-5L),0L,0xF2L},{(-7L),0L,(-1L),0xF2L,0x2CL,0xE1L,0xE1L}};
        int32_t l_153[4] = {(-5L),(-5L),(-5L),(-5L)};
        uint32_t l_157 = 1UL;
        int32_t l_168 = 0x2E47CAD9L;
        int i, j;
        g_3 = (0x7F9BL == 0UL);
        for (g_53 = 0; (g_53 == 29); g_53++)
        { /* block id: 100 */
            int32_t l_152 = 0xE16DA6D5L;
            int32_t l_156[1][5][1] = {{{0xE02593A3L},{0x3DF7CF63L},{0xE02593A3L},{0x3DF7CF63L},{0xE02593A3L}}};
            int i, j, k;
            --l_157;
            l_161 = ((+p_64) > 0x5F34EB0AL);
            g_3 = (((l_152 , l_153[3]) ^ l_157) > g_35);
            if (g_137)
                break;
        }
        l_168 = ((safe_sub_func_uint16_t_u_u(((((safe_add_func_int32_t_s_s((((safe_lshift_func_int8_t_s_u(g_115, g_136[6][3][0])) , p_64) != 0x5590E784L), p_64)) != g_131) , p_65) , 0x218EL), p_64)) && l_76);
    }
    else
    { /* block id: 107 */
        int32_t l_175[6] = {0x9FEE0006L,0xC1BD7C0AL,0x9FEE0006L,0x9FEE0006L,0xC1BD7C0AL,0x9FEE0006L};
        int i;
        l_161 = (safe_div_func_uint16_t_u_u((p_65 | 2L), g_142));
        p_67 = (g_116 & 0xE4L);
        for (g_115 = 0; (g_115 > (-13)); g_115 = safe_sub_func_uint32_t_u_u(g_115, 1))
        { /* block id: 112 */
            int32_t l_176[2][6] = {{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)},{(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)}};
            int i, j;
            l_155 = (safe_sub_func_int64_t_s_s(((((5L && l_175[5]) || p_63) ^ l_176[1][3]) , (-1L)), 1UL));
        }
    }
    for (g_115 = 0; (g_115 > (-9)); --g_115)
    { /* block id: 118 */
        uint32_t l_179 = 0UL;
        ++l_179;
        for (g_35 = 0; (g_35 >= 48); g_35 = safe_add_func_int8_t_s_s(g_35, 1))
        { /* block id: 122 */
            uint8_t l_186 = 0xF0L;
            p_67 = (safe_mul_func_int16_t_s_s(g_115, l_186));
        }
    }
    return p_66;
}


/* ------------------------------------------ */
/* 
 * reads : g_80 g_53 g_35 g_3 g_117
 * writes: g_80 g_3 g_117
 */
static int32_t  func_72(int16_t  p_73, const int32_t  p_74, uint16_t  p_75)
{ /* block id: 54 */
    int64_t l_77 = 0x4770C58F83956885LL;
    int32_t l_78 = 0xB4BAC794L;
    int32_t l_79 = 0x960388C0L;
    uint16_t l_120[2];
    int i;
    for (i = 0; i < 2; i++)
        l_120[i] = 0xB064L;
    l_77 = 0xA3631A0DL;
    ++g_80;
    for (p_75 = (-14); (p_75 == 10); ++p_75)
    { /* block id: 59 */
        l_79 = 7L;
    }
    for (p_73 = 13; (p_73 != (-27)); p_73 = safe_sub_func_uint8_t_u_u(p_73, 5))
    { /* block id: 64 */
        uint32_t l_93 = 0x5864DC94L;
        const int32_t l_95 = 0L;
        int32_t l_114[1];
        int i;
        for (i = 0; i < 1; i++)
            l_114[i] = (-1L);
        if (g_80)
        { /* block id: 65 */
            int8_t l_94[5][3][9] = {{{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L},{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)},{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L}},{{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)},{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L},{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)}},{{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L},{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)},{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L}},{{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)},{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L},{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)}},{{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L},{7L,(-1L),0xDAL,0xDAL,(-1L),7L,(-7L),(-1L),(-7L)},{0xF5L,0x1DL,0xC4L,0xF8L,0xEEL,0x9BL,1L,0x1DL,1L}}};
            int32_t l_96 = 0xCA49BD5BL;
            int i, j, k;
            l_96 ^= ((((((safe_rshift_func_uint16_t_u_s((safe_add_func_uint8_t_u_u((((safe_add_func_uint32_t_u_u((((p_74 == l_93) , 0x49L) && 0L), l_94[2][1][5])) == g_80) , 1UL), g_53)), 3)) > 65535UL) != l_93) != g_80) >= l_95) , l_77);
        }
        else
        { /* block id: 67 */
            uint8_t l_112 = 0xF2L;
            int32_t l_113[2][2][5] = {{{0L,(-4L),(-4L),0L,0x535C36BFL},{7L,1L,1L,7L,0x005CC3D6L}},{{0L,(-4L),(-4L),0L,0x535C36BFL},{7L,1L,1L,7L,0x005CC3D6L}}};
            int i, j, k;
            l_78 = func_11((((safe_add_func_int32_t_s_s(((func_101(((safe_add_func_uint32_t_u_u((safe_mul_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((((safe_mul_func_uint8_t_u_u((((g_80 & g_35) | g_53) | g_53), p_73)) > p_75) == 0x8388ADF120AA4486LL), p_74)) < 0x5DL), g_35)), g_80)) & (-4L)), g_80) && p_74) <= p_73), 1L)) <= 0UL) || l_112), p_73, p_73, l_112);
            if (p_75)
                break;
            if (p_75)
                break;
            l_113[1][0][2] = l_95;
        }
        g_117--;
        if ((g_35 || 1L))
        { /* block id: 76 */
            return p_75;
        }
        else
        { /* block id: 78 */
            return p_74;
        }
    }
    return l_120[0];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint32_t  func_101(uint16_t  p_102, uint32_t  p_103)
{ /* block id: 68 */
    return p_102;
}




/* ---------------------------------------- */
int main (void)
{
    int i, j, k;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_35, "g_35", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_80, "g_80", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    transparent_crc(g_132, "g_132", print_hash_value);
    transparent_crc(g_134, "g_134", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_136[i][j][k], "g_136[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_194, "g_194", print_hash_value);
    transparent_crc(g_197.f0, "g_197.f0", print_hash_value);
    transparent_crc(g_197.f1, "g_197.f1", print_hash_value);
    transparent_crc(g_197.f2, "g_197.f2", print_hash_value);
    transparent_crc(g_197.f3, "g_197.f3", print_hash_value);
    transparent_crc(g_197.f4, "g_197.f4", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 65
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 23
breakdown:
   depth: 1, occurrence: 76
   depth: 2, occurrence: 23
   depth: 3, occurrence: 5
   depth: 4, occurrence: 5
   depth: 5, occurrence: 1
   depth: 6, occurrence: 2
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 10, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 23, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 134
XXX times a non-volatile is write: 52
XXX times a volatile is read: 1
XXX    times read thru a pointer: 0
XXX times a volatile is write: 1
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 40
XXX percentage of non-volatile access: 98.9

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 78
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 16
   depth: 1, occurrence: 23
   depth: 2, occurrence: 39

XXX percentage a fresh-made variable is used: 30.7
XXX percentage an existing variable is used: 69.3
********************* end of statistics **********************/

