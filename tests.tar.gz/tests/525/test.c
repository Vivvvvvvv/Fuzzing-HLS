/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 3 --max-funcs 5 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9501143220230171223
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile int32_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_3 = 0UL;
static uint32_t g_13[7] = {1UL,1UL,1UL,1UL,1UL,1UL,1UL};
static int32_t g_17 = 1L;
static uint32_t g_18 = 0x7C5B1510L;
static volatile int32_t g_23 = 0x80D1C1D6L;/* VOLATILE GLOBAL g_23 */
static int8_t g_25[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
static int8_t g_27 = 0x19L;
static uint16_t g_28 = 2UL;
static uint32_t g_106 = 4294967295UL;
static struct S0 g_121[9] = {{-1L},{0x22096152L},{-1L},{0x22096152L},{-1L},{0x22096152L},{-1L},{0x22096152L},{-1L}};
static uint32_t g_140[3] = {0x86CBB3E6L,0x86CBB3E6L,0x86CBB3E6L};


/* --- FORWARD DECLARATIONS --- */
static const uint32_t  func_1(void);
static uint16_t  func_8(uint64_t  p_9);
static int16_t  func_32(int32_t  p_33, uint16_t  p_34);
static uint8_t  func_41(uint64_t  p_42);
static int64_t  func_53(int8_t  p_54, uint32_t  p_55);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_13 g_18 g_28 g_25 g_23 g_27 g_17 g_121 g_106 g_140
 * writes: g_3 g_18 g_28 g_17 g_27 g_23 g_106 g_140
 */
static const uint32_t  func_1(void)
{ /* block id: 0 */
    int32_t l_2 = (-9L);
    g_3--;
    l_2 = ((safe_add_func_uint16_t_u_u(func_8(l_2), (-4L))) & g_25[6]);
    g_17 = 0x9428FE1CL;
    g_23 = (safe_add_func_int8_t_s_s(0x86L, g_140[1]));
    return g_28;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_13 g_18 g_28 g_25 g_23 g_27 g_17 g_121 g_106 g_140
 * writes: g_3 g_18 g_28 g_17 g_27 g_23 g_106 g_140
 */
static uint16_t  func_8(uint64_t  p_9)
{ /* block id: 2 */
    int16_t l_14 = 0x93DDL;
    int32_t l_16[9] = {(-1L),(-2L),(-1L),(-2L),(-1L),(-2L),(-1L),(-2L),(-1L)};
    int8_t l_40 = 0x8BL;
    int i;
    for (p_9 = 0; (p_9 < 13); p_9 = safe_add_func_int16_t_s_s(p_9, 1))
    { /* block id: 5 */
        const int64_t l_12 = 0L;
        const int32_t l_21 = 0xDC99220CL;
        int32_t l_31 = 0x5E1BFEDAL;
        if (l_12)
            break;
        for (g_3 = 2; (g_3 <= 6); g_3 += 1)
        { /* block id: 9 */
            int32_t l_15 = 0xB4AAD9DDL;
            l_15 = (l_14 , g_13[1]);
            if (p_9)
                break;
            g_18++;
        }
        if (((l_14 >= p_9) , l_21))
        { /* block id: 14 */
            int16_t l_22 = 0x233FL;
            int32_t l_24 = (-1L);
            int32_t l_26 = 0x3E458C45L;
            g_28++;
        }
        else
        { /* block id: 16 */
            uint64_t l_114 = 0x83D25ECE1F0CC2D3LL;
            l_31 = 0x9EB11DE2L;
            l_31 = ((func_32(((safe_mod_func_uint64_t_u_u((((((safe_add_func_int16_t_s_s((+l_40), l_12)) < p_9) == g_25[0]) , g_28) , g_28), p_9)) | 1UL), g_18) , l_16[1]) != l_40);
            l_114++;
            g_17 |= (safe_rshift_func_int16_t_s_u(0x0A4DL, l_16[6]));
        }
        for (l_14 = 5; (l_14 >= 0); l_14 -= 1)
        { /* block id: 89 */
            int i;
            return g_13[(l_14 + 1)];
        }
    }
    for (p_9 = 0; (p_9 < 22); p_9 = safe_add_func_int8_t_s_s(p_9, 4))
    { /* block id: 95 */
        uint16_t l_122 = 0x9715L;
        int32_t l_123 = 1L;
        l_16[7] |= (((g_121[5] , g_3) > p_9) < g_27);
        l_123 = (l_122 , p_9);
        return g_121[5].f0;
    }
    for (g_106 = 0; (g_106 > 3); ++g_106)
    { /* block id: 102 */
        g_23 = (safe_div_func_uint32_t_u_u((p_9 ^ p_9), 0x5441C1EEL));
    }
    for (g_28 = 1; (g_28 <= 8); g_28 += 1)
    { /* block id: 107 */
        int64_t l_132 = 0x200A6F42BAF640DELL;
        int32_t l_137 = (-10L);
        int i;
        for (g_3 = 2; (g_3 <= 7); g_3 += 1)
        { /* block id: 110 */
            int i;
            l_132 &= ((((((safe_rshift_func_uint8_t_u_s(((safe_sub_func_int16_t_s_s(((g_25[g_3] ^ l_16[g_28]) , p_9), 0xF2E4L)) <= g_13[1]), p_9)) < l_14) < g_3) || p_9) >= l_16[g_28]) & p_9);
            g_17 &= g_23;
            l_137 = ((safe_add_func_uint64_t_u_u(((safe_lshift_func_uint16_t_u_s((l_40 & g_121[5].f0), 11)) | 0xD1FBCF3AL), g_3)) , 0x4005F240L);
            l_137 &= 0x9149AC58L;
        }
        l_16[g_28] &= (safe_rshift_func_int8_t_s_u(p_9, 7));
        --g_140[0];
        l_16[g_28] = (((-4L) & p_9) , l_16[g_28]);
    }
    return g_18;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_13 g_27 g_3 g_17 g_25 g_28 g_18
 * writes: g_17 g_27 g_23 g_28 g_18 g_106
 */
static int16_t  func_32(int32_t  p_33, uint16_t  p_34)
{ /* block id: 18 */
    int32_t l_43[2];
    int16_t l_113 = 0x596FL;
    int i;
    for (i = 0; i < 2; i++)
        l_43[i] = (-1L);
    if ((func_41(((((((l_43[1] , l_43[1]) && p_34) != 65535UL) || l_43[1]) & 0xAFE4L) & l_43[1])) || l_43[1]))
    { /* block id: 63 */
        uint64_t l_99 = 0x8E61696E83D70680LL;
        if (g_3)
        { /* block id: 64 */
            uint8_t l_93 = 0xB9L;
            ++l_93;
        }
        else
        { /* block id: 66 */
            l_99 = (safe_mul_func_int8_t_s_s((((((!(0xFBEBL <= 0xEB3EL)) != 0xAD590955L) > g_25[6]) == 0UL) < p_33), p_34));
        }
    }
    else
    { /* block id: 69 */
        uint16_t l_100 = 1UL;
        int8_t l_101 = 0x47L;
        for (g_18 = 0; (g_18 <= 1); g_18 += 1)
        { /* block id: 72 */
            int i;
            l_100 = (g_13[(g_18 + 4)] & 0L);
            if (g_25[6])
                continue;
            l_101 |= (g_17 , 0x02147657L);
        }
        g_23 = (((safe_rshift_func_uint8_t_u_s((safe_lshift_func_int16_t_s_s((l_100 & p_33), 7)), 1)) != p_34) , 0L);
        g_106 = g_17;
    }
    p_33 ^= (safe_lshift_func_int16_t_s_u((safe_lshift_func_int8_t_s_s((safe_sub_func_int8_t_s_s(((0x7EL != (-7L)) & p_34), g_27)), l_113)), 5));
    p_33 |= g_25[6];
    return p_34;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_13 g_27 g_3 g_17 g_25 g_28 g_18
 * writes: g_17 g_27 g_23 g_28 g_18
 */
static uint8_t  func_41(uint64_t  p_42)
{ /* block id: 19 */
    int16_t l_48 = 0xA84DL;
    int32_t l_92[7][2][2] = {{{0xD1EC869DL,0L},{0L,0xD1EC869DL}},{{0xB9DF8DAFL,0xDC4BEA28L},{0xB9DF8DAFL,0xD1EC869DL}},{{0L,0L},{0xDC4BEA28L,0xD1EC869DL}},{{(-1L),0xD1EC869DL},{0xDC4BEA28L,(-1L)}},{{(-1L),0xDC4BEA28L},{0xD1EC869DL,(-1L)}},{{0xD1EC869DL,0xDC4BEA28L},{(-1L),(-1L)}},{{0xDC4BEA28L,0xD1EC869DL},{(-1L),0xD1EC869DL}}};
    int i, j, k;
    if ((safe_mul_func_int8_t_s_s((safe_add_func_uint8_t_u_u(p_42, l_48)), l_48)))
    { /* block id: 20 */
        return g_23;
    }
    else
    { /* block id: 22 */
        uint32_t l_91[10][6][4] = {{{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L}},{{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L}},{{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL}},{{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L}},{{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L}},{{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L}},{{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L},{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,1UL,0xE6A876A4L,0x0BD68869L},{0x0BD68869L,0xAFA15260L,0xE6A876A4L,0x37858094L},{0x23AF2BE4L,7UL,1UL,0x37858094L},{4294967286UL,0xAFA15260L,4294967294UL,0x0BD68869L}},{{4294967286UL,1UL,1UL,4294967286UL},{0x23AF2BE4L,4294967294UL,0xAFA15260L,4294967286UL},{4294967286UL,7UL,0xAFA15260L,1UL},{0x0BD68869L,1UL,4294967294UL,1UL},{0x37858094L,7UL,0xE6A876A4L,4294967286UL},{0x37858094L,4294967294UL,4294967294UL,0x37858094L}},{{0x0BD68869L,4294967294UL,0xAFA15260L,4294967286UL},{4294967286UL,7UL,0xAFA15260L,1UL},{0x0BD68869L,1UL,4294967294UL,1UL},{0x37858094L,7UL,0xE6A876A4L,4294967286UL},{0x37858094L,4294967294UL,4294967294UL,0x37858094L},{0x0BD68869L,4294967294UL,0xAFA15260L,4294967286UL}},{{4294967286UL,7UL,0xAFA15260L,1UL},{0x0BD68869L,1UL,4294967294UL,1UL},{0x37858094L,7UL,0xE6A876A4L,4294967286UL},{0x37858094L,4294967294UL,4294967294UL,0x37858094L},{0x0BD68869L,4294967294UL,0xAFA15260L,4294967286UL},{4294967286UL,7UL,0xAFA15260L,1UL}}};
        int i, j, k;
        l_91[9][1][1] |= (safe_div_func_int32_t_s_s((safe_lshift_func_uint8_t_u_u(((((func_53(p_42, g_13[4]) , 65535UL) | 0xC078L) , p_42) <= 0x7867F40E302F92BFLL), p_42)), l_48));
        l_92[1][0][1] = p_42;
    }
    return l_92[1][0][1];
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_3 g_17 g_25 g_23 g_28 g_13 g_18
 * writes: g_17 g_27 g_23 g_28 g_18
 */
static int64_t  func_53(int8_t  p_54, uint32_t  p_55)
{ /* block id: 23 */
    uint16_t l_60 = 1UL;
    int32_t l_61 = 0L;
lbl_64:
    l_61 |= (safe_mod_func_uint32_t_u_u(((((safe_mod_func_uint8_t_u_u(255UL, g_27)) , p_55) < g_3) , l_60), l_60));
lbl_90:
    for (g_17 = 0; (g_17 == 6); ++g_17)
    { /* block id: 27 */
        uint64_t l_65 = 5UL;
        int32_t l_72[9] = {6L,6L,0L,6L,6L,0L,6L,6L,0L};
        uint32_t l_73 = 0xAD05572BL;
        int i;
        for (g_27 = 7; (g_27 >= 0); g_27 -= 1)
        { /* block id: 30 */
            int i;
            g_23 ^= g_25[g_27];
            if (g_28)
                break;
            if (l_60)
                goto lbl_64;
            g_23 ^= 0L;
        }
        if (l_65)
            break;
        if ((((safe_add_func_int32_t_s_s(((((((safe_unary_minus_func_uint64_t_u((safe_div_func_int8_t_s_s(p_54, p_55)))) , p_55) , 0xF0L) > (-7L)) , l_65) , 1L), g_17)) > g_27) ^ g_13[1]))
        { /* block id: 37 */
            int16_t l_71[6];
            int i;
            for (i = 0; i < 6; i++)
                l_71[i] = 2L;
            l_71[0] = 0xB40ACB48L;
            ++l_73;
            l_72[2] &= (l_73 < p_54);
        }
        else
        { /* block id: 41 */
            g_23 = l_60;
            if (g_3)
                continue;
        }
    }
    for (g_28 = 0; (g_28 < 20); g_28++)
    { /* block id: 48 */
        for (g_18 = 2; (g_18 <= 7); g_18 += 1)
        { /* block id: 51 */
            uint16_t l_89 = 0xA03DL;
            l_61 ^= ((((((safe_add_func_uint16_t_u_u((((((safe_add_func_int32_t_s_s(((safe_mod_func_int32_t_s_s((safe_mod_func_uint8_t_u_u((((safe_div_func_uint64_t_u_u((+g_25[6]), p_54)) , p_55) ^ g_18), p_55)), 0x6110BDBEL)) < l_89), g_18)) < g_18) >= g_25[6]) & (-1L)) , 1UL), 3L)) , g_27) , 1L) >= p_55) == 0xE546L) || 0x5F2AL);
            if (p_54)
                break;
            l_61 = p_54;
            if (g_28)
                goto lbl_90;
        }
    }
    return g_28;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_13[i], "g_13[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_17, "g_17", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_25[i], "g_25[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_27, "g_27", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    transparent_crc(g_106, "g_106", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_121[i].f0, "g_121[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_140[i], "g_140[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 41
   depth: 1, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 18
breakdown:
   depth: 1, occurrence: 77
   depth: 2, occurrence: 20
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 6, occurrence: 4
   depth: 7, occurrence: 1
   depth: 9, occurrence: 2
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 18, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 124
XXX times a non-volatile is write: 46
XXX times a volatile is read: 4
XXX    times read thru a pointer: 0
XXX times a volatile is write: 6
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 64
XXX percentage of non-volatile access: 94.4

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 74
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 20
   depth: 1, occurrence: 23
   depth: 2, occurrence: 31

XXX percentage a fresh-made variable is used: 23.9
XXX percentage an existing variable is used: 76.1
********************* end of statistics **********************/

