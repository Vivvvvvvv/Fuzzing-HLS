/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      16793184126176085794
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile uint64_t  f0;
   const int8_t  f1;
   volatile uint16_t  f2;
   int16_t  f3;
   int32_t  f4;
   uint8_t  f5;
};

struct S1 {
   uint16_t  f0;
};

/* --- GLOBAL VARIABLES --- */
static uint16_t g_10 = 0x8C7BL;
static uint32_t g_12 = 1UL;
static uint32_t g_17 = 0x858905B8L;
static uint16_t g_18[8] = {0xC700L,0xC700L,0xC700L,0xC700L,0xC700L,0xC700L,0xC700L,0xC700L};
static int8_t g_33 = 0xBEL;
static uint64_t g_50 = 0xEA59F7C1AE2EFAADLL;
static uint8_t g_53[1] = {255UL};
static int16_t g_63[3] = {0x0406L,0x0406L,0x0406L};
static struct S0 g_64 = {0x56A9E5FAF1BECDE8LL,0x19L,0xB9DBL,0xDF1DL,3L,1UL};/* VOLATILE GLOBAL g_64 */


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static uint8_t  func_4(int32_t  p_5, uint32_t  p_6, int32_t  p_7, int16_t  p_8, int8_t  p_9);
static const int32_t  func_27(uint32_t  p_28, uint32_t  p_29);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_12 g_18 g_17 g_50 g_64
 * writes: g_12 g_10 g_17 g_18 g_33 g_50 g_53 g_63
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    uint16_t l_11 = 0x9BD6L;
    int16_t l_62 = 1L;
    g_53[0] = (safe_add_func_uint8_t_u_u(func_4(g_10, g_10, g_10, l_11, l_11), 0x34L));
    g_63[1] = (safe_mul_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((((safe_mod_func_int8_t_s_s(0x72L, l_62)) && (-10L)) ^ 0UL), (-1L))), l_11));
    return g_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_12 g_10 g_18 g_17 g_50
 * writes: g_12 g_10 g_17 g_18 g_33 g_50
 */
static uint8_t  func_4(int32_t  p_5, uint32_t  p_6, int32_t  p_7, int16_t  p_8, int8_t  p_9)
{ /* block id: 1 */
    const uint32_t l_21 = 4294967295UL;
    int32_t l_22 = 5L;
lbl_24:
    ++g_12;
    for (g_10 = 0; (g_10 <= 23); g_10++)
    { /* block id: 5 */
        int32_t l_23 = 0x64EA33A4L;
        g_17 = 0x95D1C58BL;
        ++g_18[1];
        if (p_9)
        { /* block id: 8 */
            l_22 = (l_21 , g_18[1]);
            if (l_23)
                continue;
            if (p_6)
                break;
        }
        else
        { /* block id: 12 */
            uint8_t l_30 = 251UL;
            int32_t l_47 = 1L;
            if (p_9)
                goto lbl_24;
            l_47 = (safe_rshift_func_int8_t_s_s((((func_27(l_30, p_7) <= g_12) | l_21) <= p_5), 1));
            l_23 = p_6;
        }
        if (p_5)
            break;
    }
    l_22 = (safe_add_func_int8_t_s_s(p_6, 0x5BL));
    for (p_5 = 5; (p_5 >= 0); p_5 -= 1)
    { /* block id: 37 */
        int i;
        g_50++;
        if (g_18[(p_5 + 2)])
            break;
    }
    return p_6;
}


/* ------------------------------------------ */
/* 
 * reads : g_17 g_10 g_18
 * writes: g_33 g_17
 */
static const int32_t  func_27(uint32_t  p_28, uint32_t  p_29)
{ /* block id: 14 */
    uint32_t l_36 = 0x50E8F7CFL;
    struct S1 l_43 = {0UL};
    uint32_t l_44[6] = {0x92FF8224L,0x1E525036L,0x92FF8224L,0x92FF8224L,0x1E525036L,0x92FF8224L};
    int8_t l_45 = 0x5BL;
    int32_t l_46 = 0xD0615A03L;
    int i;
    if (p_28)
    { /* block id: 15 */
        g_33 = ((safe_mul_func_uint8_t_u_u((0x4ADC6F79B347D170LL | (-8L)), p_28)) , p_28);
    }
    else
    { /* block id: 17 */
        uint32_t l_40 = 0UL;
        int32_t l_41 = 0xCBF77624L;
        for (g_17 = (-6); (g_17 <= 7); g_17 = safe_add_func_int64_t_s_s(g_17, 7))
        { /* block id: 20 */
            uint32_t l_39 = 18446744073709551615UL;
            l_36--;
            if (l_39)
                continue;
            l_41 = ((g_10 && 0L) == l_40);
        }
        l_44[2] &= (((!((l_43 , g_10) != l_36)) & p_28) != p_29);
    }
    l_46 = l_45;
    return g_18[0];
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_17, "g_17", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_18[i], "g_18[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_33, "g_33", print_hash_value);
    transparent_crc(g_50, "g_50", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_53[i], "g_53[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_63[i], "g_63[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_64.f0, "g_64.f0", print_hash_value);
    transparent_crc(g_64.f1, "g_64.f1", print_hash_value);
    transparent_crc(g_64.f2, "g_64.f2", print_hash_value);
    transparent_crc(g_64.f3, "g_64.f3", print_hash_value);
    transparent_crc(g_64.f4, "g_64.f4", print_hash_value);
    transparent_crc(g_64.f5, "g_64.f5", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 22
   depth: 1, occurrence: 2
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 7
breakdown:
   depth: 1, occurrence: 33
   depth: 2, occurrence: 5
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2

XXX total number of pointers: 0

XXX times a non-volatile is read: 39
XXX times a non-volatile is write: 18
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 0
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 1

XXX stmts: 29
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 11
   depth: 1, occurrence: 9
   depth: 2, occurrence: 9

XXX percentage a fresh-made variable is used: 48
XXX percentage an existing variable is used: 52
********************* end of statistics **********************/

