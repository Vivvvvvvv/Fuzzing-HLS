/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.3.0
 * Git version: 30dccd7
 * Options:   --probability-configuration prob.txt --no-argc --max-array-dim 1 --max-funcs 3 --max-expr-complexity 2 --no-float --no-embedded-assigns --max-block-depth 2 --no-unions --no-packed-struct --no-const-pointers --no-pointers --strict-const-arrays
 * Seed:      9430344819270900485
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int16_t g_2 = 0xC9E5L;/* VOLATILE GLOBAL g_2 */
static uint64_t g_4 = 0UL;
static uint16_t g_8 = 65528UL;
static volatile int64_t g_19 = (-1L);/* VOLATILE GLOBAL g_19 */
static int8_t g_20 = 0x24L;
static volatile uint16_t g_22 = 6UL;/* VOLATILE GLOBAL g_22 */
static volatile uint32_t g_53 = 0x7B094C65L;/* VOLATILE GLOBAL g_53 */
static uint32_t g_66[3] = {9UL,9UL,9UL};
static uint16_t g_69[2] = {0x7F47L,0x7F47L};


/* --- FORWARD DECLARATIONS --- */
static const uint16_t  func_1(void);
static uint16_t  func_27(const int32_t  p_28, int32_t  p_29, int64_t  p_30, int32_t  p_31);
static uint16_t  func_38(const int8_t  p_39, int16_t  p_40);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_8 g_22 g_20 g_19 g_53 g_69
 * writes: g_4 g_8 g_22 g_53 g_20 g_66 g_69
 */
static const uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_3 = (-1L);
    uint8_t l_7 = 0UL;
    uint64_t l_11 = 18446744073709551610UL;
    int32_t l_13 = (-4L);
    if ((g_2 , l_3))
    { /* block id: 1 */
        uint32_t l_12 = 0x586FD5D7L;
        int32_t l_18 = 0x1434A938L;
        --g_4;
        g_8 |= (l_7 ^ g_4);
        l_13 = (safe_mul_func_uint16_t_u_u(l_11, l_12));
        if ((g_2 != l_12))
        { /* block id: 5 */
            uint16_t l_17[9] = {0x85BDL,2UL,2UL,0x85BDL,2UL,2UL,0x85BDL,2UL,2UL};
            int i;
            l_18 = (((safe_unary_minus_func_int64_t_s((safe_add_func_int32_t_s_s((0x2401L <= g_2), l_17[3])))) <= l_12) , l_12);
        }
        else
        { /* block id: 7 */
            int16_t l_21 = 1L;
            --g_22;
lbl_67:
            l_18 &= (((safe_lshift_func_int8_t_s_s(1L, 0)) && 0xE6DAL) | 65533UL);
            g_66[2] = (func_27((safe_div_func_int32_t_s_s(((safe_mod_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_u(func_38((safe_div_func_int32_t_s_s((safe_mod_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(((g_22 || 65535UL) > 0x364F2CA12535B5B0LL), g_8)), g_20)), l_11)), g_4), 13)) , l_21) ^ l_18), g_8)) != 0xBDL), g_8)), g_8, g_4, l_12) & 0L);
            if (g_4)
                goto lbl_67;
        }
    }
    else
    { /* block id: 29 */
        uint32_t l_68 = 0x3317A7F3L;
        g_69[1] = (l_68 , (-7L));
    }
    l_13 = (safe_mod_func_uint16_t_u_u((6L > 1L), l_13));
    l_13 = g_69[1];
    return g_69[0];
}


/* ------------------------------------------ */
/* 
 * reads : g_8 g_53 g_20 g_4
 * writes: g_53 g_20
 */
static uint16_t  func_27(const int32_t  p_28, int32_t  p_29, int64_t  p_30, int32_t  p_31)
{ /* block id: 14 */
    const uint32_t l_51 = 0x655505F4L;
    int8_t l_52 = 0x6FL;
    int32_t l_64 = (-9L);
lbl_65:
    l_52 = (safe_mod_func_uint64_t_u_u((0x3AD3L ^ g_8), l_51));
    g_53++;
    for (g_20 = 0; (g_20 < 27); g_20 = safe_add_func_int64_t_s_s(g_20, 5))
    { /* block id: 19 */
        int32_t l_58 = 0xE38EDFC7L;
        int32_t l_59 = 0xF1B6398CL;
        l_59 &= l_58;
        l_58 = g_4;
        p_29 = ((safe_add_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((l_51 , 0x3401L) >= g_4), g_4)), l_64)) && 0L);
    }
    if (l_64)
        goto lbl_65;
    return l_64;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_20
 * writes:
 */
static uint16_t  func_38(const int8_t  p_39, int16_t  p_40)
{ /* block id: 10 */
    int32_t l_47 = (-1L);
    int32_t l_48 = 1L;
    l_47 ^= (g_19 , p_40);
    l_48 = (((-10L) && (-3L)) == g_20);
    return p_39;
}




/* ---------------------------------------- */
int main (void)
{
    int i;
    int print_hash_value = 0;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_20, "g_20", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_66[i], "g_66[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_69[i], "g_69[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 25
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 19
breakdown:
   depth: 1, occurrence: 28
   depth: 2, occurrence: 7
   depth: 3, occurrence: 3
   depth: 4, occurrence: 1
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 19, occurrence: 1

XXX total number of pointers: 0

XXX times a non-volatile is read: 37
XXX times a non-volatile is write: 16
XXX times a volatile is read: 5
XXX    times read thru a pointer: 0
XXX times a volatile is write: 2
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 22
XXX percentage of non-volatile access: 88.3

XXX forward jumps: 0
XXX backward jumps: 2

XXX stmts: 25
XXX max block depth: 2
breakdown:
   depth: 0, occurrence: 12
   depth: 1, occurrence: 8
   depth: 2, occurrence: 5

XXX percentage a fresh-made variable is used: 40.3
XXX percentage an existing variable is used: 59.7
********************* end of statistics **********************/

